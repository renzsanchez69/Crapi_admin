<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
   <head>
      <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
      <title>FORTE-EIGHT CATERING</title>
      <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
   <body style="font-family:arial;">
      <table width="800" align="center" cellspacing="0" cellpadding="10" border="0" style="border:solid 1px #ccc;">
         <tr>
            <td style="font-size:15px; padding:20px; color:#333; line-height:19px;">
               <?php echo $message;?>
               <br><br><br><br>
               Thanks & Regards,<br>
               Forte-eight Catering Team
            </td>
         </tr>
         <tr>
            <td bgcolor="#f5f5f5" style="font-size:12px;" align="center">&copy; 2018 Forte-eight Catering All Rights Reserved.</td>
         </tr>
      </table>
   </body>
</html>