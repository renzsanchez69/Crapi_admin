<nav class="navbar navbar-light fixed-top bg-light flex-md-nowrap p-0 shadow">
	<a class="navbar-brand col-sm-3 col-md-2 mr-0" href="<?php echo base_url('admin') ?>">CRAPI APPLICATION</a>
	<ul class="navbar-nav px-3">
		<li class="nav-item">
			<a class="btn btn-md btn-danger" href="<?php echo base_url('admin/account/logout') ?>"> Logout</a>
		</li>
	</ul>
</nav>