<?php $this->layout('layouts::base') ?>

<?=$this->section('content')?>