<?php $this->layout('layouts::default') ?>
<h1>Welcome to admin dashboard</h1>