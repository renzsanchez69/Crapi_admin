<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-06-27 00:01:08 --> Helper loaded: language_helper
INFO - 2019-06-27 00:01:08 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 00:01:08 --> Model Class Initialized
INFO - 2019-06-27 00:01:08 --> Model Class Initialized
INFO - 2019-06-27 00:01:08 --> Model Class Initialized
INFO - 2019-06-27 00:01:08 --> Model Class Initialized
INFO - 2019-06-27 00:01:08 --> Model Class Initialized
INFO - 2019-06-27 00:01:08 --> Final output sent to browser
DEBUG - 2019-06-27 00:01:08 --> Total execution time: 0.4440
INFO - 2019-06-27 00:01:08 --> Helper loaded: language_helper
INFO - 2019-06-27 00:01:08 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 00:01:08 --> Model Class Initialized
INFO - 2019-06-27 00:01:08 --> Model Class Initialized
INFO - 2019-06-27 00:01:08 --> Model Class Initialized
INFO - 2019-06-27 00:01:08 --> Model Class Initialized
INFO - 2019-06-27 00:01:08 --> Model Class Initialized
INFO - 2019-06-27 00:01:08 --> Final output sent to browser
DEBUG - 2019-06-27 00:01:08 --> Total execution time: 0.5388
INFO - 2019-06-27 00:01:08 --> Helper loaded: language_helper
INFO - 2019-06-27 00:01:08 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 00:01:08 --> Model Class Initialized
INFO - 2019-06-27 00:01:08 --> Model Class Initialized
INFO - 2019-06-27 00:01:08 --> Model Class Initialized
INFO - 2019-06-27 00:01:08 --> Model Class Initialized
INFO - 2019-06-27 00:01:08 --> Model Class Initialized
INFO - 2019-06-27 00:01:08 --> Final output sent to browser
DEBUG - 2019-06-27 00:01:08 --> Total execution time: 0.3203
INFO - 2019-06-27 00:01:10 --> Helper loaded: language_helper
INFO - 2019-06-27 00:01:10 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 00:01:10 --> Model Class Initialized
INFO - 2019-06-27 00:01:10 --> Model Class Initialized
INFO - 2019-06-27 00:01:10 --> Model Class Initialized
INFO - 2019-06-27 00:01:10 --> Model Class Initialized
INFO - 2019-06-27 00:01:10 --> Model Class Initialized
INFO - 2019-06-27 00:01:10 --> Final output sent to browser
DEBUG - 2019-06-27 00:01:10 --> Total execution time: 0.3521
INFO - 2019-06-27 00:01:10 --> Helper loaded: language_helper
INFO - 2019-06-27 00:01:10 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 00:01:10 --> Model Class Initialized
INFO - 2019-06-27 00:01:10 --> Model Class Initialized
INFO - 2019-06-27 00:01:10 --> Model Class Initialized
INFO - 2019-06-27 00:01:10 --> Model Class Initialized
INFO - 2019-06-27 00:01:10 --> Model Class Initialized
INFO - 2019-06-27 00:01:10 --> Final output sent to browser
DEBUG - 2019-06-27 00:01:10 --> Total execution time: 0.4595
INFO - 2019-06-27 00:01:10 --> Helper loaded: language_helper
INFO - 2019-06-27 00:01:10 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 00:01:10 --> Model Class Initialized
INFO - 2019-06-27 00:01:10 --> Model Class Initialized
INFO - 2019-06-27 00:01:10 --> Model Class Initialized
INFO - 2019-06-27 00:01:10 --> Model Class Initialized
INFO - 2019-06-27 00:01:10 --> Model Class Initialized
INFO - 2019-06-27 00:01:10 --> Final output sent to browser
DEBUG - 2019-06-27 00:01:10 --> Total execution time: 0.3090
INFO - 2019-06-27 00:01:14 --> Helper loaded: language_helper
INFO - 2019-06-27 00:01:14 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 00:01:14 --> Model Class Initialized
INFO - 2019-06-27 00:01:14 --> Model Class Initialized
INFO - 2019-06-27 00:01:14 --> Model Class Initialized
INFO - 2019-06-27 00:01:14 --> Model Class Initialized
INFO - 2019-06-27 00:01:14 --> Model Class Initialized
INFO - 2019-06-27 00:01:14 --> Final output sent to browser
DEBUG - 2019-06-27 00:01:14 --> Total execution time: 0.4306
INFO - 2019-06-27 00:01:15 --> Helper loaded: language_helper
INFO - 2019-06-27 00:01:15 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 00:01:15 --> Model Class Initialized
INFO - 2019-06-27 00:01:15 --> Model Class Initialized
INFO - 2019-06-27 00:01:15 --> Model Class Initialized
INFO - 2019-06-27 00:01:15 --> Model Class Initialized
INFO - 2019-06-27 00:01:15 --> Model Class Initialized
INFO - 2019-06-27 00:01:15 --> Final output sent to browser
DEBUG - 2019-06-27 00:01:15 --> Total execution time: 0.5639
INFO - 2019-06-27 00:01:15 --> Helper loaded: language_helper
INFO - 2019-06-27 00:01:15 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 00:01:15 --> Model Class Initialized
INFO - 2019-06-27 00:01:15 --> Model Class Initialized
INFO - 2019-06-27 00:01:15 --> Model Class Initialized
INFO - 2019-06-27 00:01:15 --> Model Class Initialized
INFO - 2019-06-27 00:01:15 --> Model Class Initialized
INFO - 2019-06-27 00:01:15 --> Final output sent to browser
DEBUG - 2019-06-27 00:01:15 --> Total execution time: 0.3124
INFO - 2019-06-27 00:01:26 --> Helper loaded: language_helper
INFO - 2019-06-27 00:01:26 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 00:01:27 --> Model Class Initialized
INFO - 2019-06-27 00:01:27 --> Model Class Initialized
INFO - 2019-06-27 00:01:27 --> Model Class Initialized
INFO - 2019-06-27 00:01:27 --> Model Class Initialized
INFO - 2019-06-27 00:01:27 --> Model Class Initialized
INFO - 2019-06-27 00:01:27 --> Final output sent to browser
DEBUG - 2019-06-27 00:01:27 --> Total execution time: 0.3300
INFO - 2019-06-27 00:01:27 --> Helper loaded: language_helper
INFO - 2019-06-27 00:01:27 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 00:01:27 --> Model Class Initialized
INFO - 2019-06-27 00:01:27 --> Model Class Initialized
INFO - 2019-06-27 00:01:27 --> Model Class Initialized
INFO - 2019-06-27 00:01:27 --> Model Class Initialized
INFO - 2019-06-27 00:01:27 --> Model Class Initialized
INFO - 2019-06-27 00:01:27 --> Final output sent to browser
DEBUG - 2019-06-27 00:01:27 --> Total execution time: 0.4030
INFO - 2019-06-27 00:01:27 --> Helper loaded: language_helper
INFO - 2019-06-27 00:01:27 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 00:01:27 --> Model Class Initialized
INFO - 2019-06-27 00:01:27 --> Model Class Initialized
INFO - 2019-06-27 00:01:27 --> Model Class Initialized
INFO - 2019-06-27 00:01:27 --> Model Class Initialized
INFO - 2019-06-27 00:01:27 --> Model Class Initialized
INFO - 2019-06-27 00:01:27 --> Final output sent to browser
DEBUG - 2019-06-27 00:01:27 --> Total execution time: 0.3535
INFO - 2019-06-27 00:01:28 --> Helper loaded: language_helper
INFO - 2019-06-27 00:01:28 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 00:01:28 --> Model Class Initialized
INFO - 2019-06-27 00:01:28 --> Model Class Initialized
INFO - 2019-06-27 00:01:28 --> Model Class Initialized
INFO - 2019-06-27 00:01:28 --> Model Class Initialized
INFO - 2019-06-27 00:01:28 --> Model Class Initialized
INFO - 2019-06-27 00:01:28 --> Final output sent to browser
DEBUG - 2019-06-27 00:01:28 --> Total execution time: 0.3185
INFO - 2019-06-27 00:01:30 --> Helper loaded: language_helper
INFO - 2019-06-27 00:01:30 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 00:01:30 --> Model Class Initialized
INFO - 2019-06-27 00:01:30 --> Model Class Initialized
INFO - 2019-06-27 00:01:30 --> Model Class Initialized
INFO - 2019-06-27 00:01:30 --> Model Class Initialized
INFO - 2019-06-27 00:01:30 --> Model Class Initialized
INFO - 2019-06-27 00:01:30 --> Final output sent to browser
DEBUG - 2019-06-27 00:01:30 --> Total execution time: 0.3244
INFO - 2019-06-27 00:01:31 --> Helper loaded: language_helper
INFO - 2019-06-27 00:01:31 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 00:01:31 --> Model Class Initialized
INFO - 2019-06-27 00:01:31 --> Model Class Initialized
INFO - 2019-06-27 00:01:31 --> Model Class Initialized
INFO - 2019-06-27 00:01:31 --> Model Class Initialized
INFO - 2019-06-27 00:01:31 --> Model Class Initialized
INFO - 2019-06-27 00:01:31 --> Final output sent to browser
DEBUG - 2019-06-27 00:01:31 --> Total execution time: 0.3165
INFO - 2019-06-27 00:01:32 --> Helper loaded: language_helper
INFO - 2019-06-27 00:01:32 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 00:01:32 --> Model Class Initialized
INFO - 2019-06-27 00:01:32 --> Model Class Initialized
INFO - 2019-06-27 00:01:32 --> Model Class Initialized
INFO - 2019-06-27 00:01:32 --> Model Class Initialized
INFO - 2019-06-27 00:01:32 --> Model Class Initialized
INFO - 2019-06-27 00:01:32 --> Final output sent to browser
DEBUG - 2019-06-27 00:01:32 --> Total execution time: 0.3162
INFO - 2019-06-27 00:01:33 --> Helper loaded: language_helper
INFO - 2019-06-27 00:01:33 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 00:01:33 --> Model Class Initialized
INFO - 2019-06-27 00:01:33 --> Model Class Initialized
INFO - 2019-06-27 00:01:33 --> Model Class Initialized
INFO - 2019-06-27 00:01:33 --> Model Class Initialized
INFO - 2019-06-27 00:01:33 --> Model Class Initialized
INFO - 2019-06-27 00:01:33 --> Final output sent to browser
DEBUG - 2019-06-27 00:01:33 --> Total execution time: 0.3187
INFO - 2019-06-27 00:01:34 --> Helper loaded: language_helper
INFO - 2019-06-27 00:01:34 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 00:01:34 --> Model Class Initialized
INFO - 2019-06-27 00:01:34 --> Model Class Initialized
INFO - 2019-06-27 00:01:34 --> Model Class Initialized
INFO - 2019-06-27 00:01:34 --> Model Class Initialized
INFO - 2019-06-27 00:01:34 --> Model Class Initialized
INFO - 2019-06-27 00:01:34 --> Final output sent to browser
DEBUG - 2019-06-27 00:01:34 --> Total execution time: 0.3170
INFO - 2019-06-27 14:36:04 --> Config Class Initialized
INFO - 2019-06-27 14:36:04 --> Hooks Class Initialized
DEBUG - 2019-06-27 14:36:04 --> UTF-8 Support Enabled
INFO - 2019-06-27 14:36:04 --> Utf8 Class Initialized
INFO - 2019-06-27 14:36:04 --> URI Class Initialized
DEBUG - 2019-06-27 14:36:04 --> No URI present. Default controller set.
INFO - 2019-06-27 14:36:04 --> Router Class Initialized
INFO - 2019-06-27 14:36:04 --> Output Class Initialized
INFO - 2019-06-27 14:36:04 --> Security Class Initialized
DEBUG - 2019-06-27 14:36:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 14:36:04 --> Input Class Initialized
INFO - 2019-06-27 14:36:04 --> Language Class Initialized
INFO - 2019-06-27 14:36:06 --> Final output sent to browser
DEBUG - 2019-06-27 14:36:06 --> Total execution time: 1.5493
INFO - 2019-06-27 14:36:12 --> Config Class Initialized
INFO - 2019-06-27 14:36:12 --> Hooks Class Initialized
DEBUG - 2019-06-27 14:36:12 --> UTF-8 Support Enabled
INFO - 2019-06-27 14:36:12 --> Utf8 Class Initialized
INFO - 2019-06-27 14:36:12 --> URI Class Initialized
DEBUG - 2019-06-27 14:36:12 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/routes.php
INFO - 2019-06-27 14:36:12 --> Router Class Initialized
INFO - 2019-06-27 14:36:12 --> Output Class Initialized
INFO - 2019-06-27 14:36:12 --> Security Class Initialized
DEBUG - 2019-06-27 14:36:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 14:36:12 --> Input Class Initialized
INFO - 2019-06-27 14:36:12 --> Language Class Initialized
INFO - 2019-06-27 14:36:12 --> Language Class Initialized
INFO - 2019-06-27 14:36:12 --> Config Class Initialized
INFO - 2019-06-27 14:36:12 --> Loader Class Initialized
DEBUG - 2019-06-27 14:36:12 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/site.php
INFO - 2019-06-27 14:36:12 --> Helper loaded: url_helper
INFO - 2019-06-27 14:36:12 --> Helper loaded: inflector_helper
INFO - 2019-06-27 14:36:12 --> Helper loaded: string_helper
INFO - 2019-06-27 14:36:12 --> Helper loaded: array_helper
INFO - 2019-06-27 14:36:12 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 14:36:12 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/autoload.php
DEBUG - 2019-06-27 14:36:12 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/helpers/adminlte_helper.php
INFO - 2019-06-27 14:36:12 --> Database Driver Class Initialized
ERROR - 2019-06-27 14:36:12 --> Severity: Warning --> mysqli::real_connect(): (HY000/1049): Unknown database 'crapi' C:\xampp\htdocs\crapi_admin\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2019-06-27 14:36:12 --> Unable to connect to the database
INFO - 2019-06-27 14:36:12 --> Language file loaded: language/english/db_lang.php
INFO - 2019-06-27 14:39:01 --> Config Class Initialized
INFO - 2019-06-27 14:39:01 --> Hooks Class Initialized
DEBUG - 2019-06-27 14:39:01 --> UTF-8 Support Enabled
INFO - 2019-06-27 14:39:01 --> Utf8 Class Initialized
INFO - 2019-06-27 14:39:01 --> URI Class Initialized
DEBUG - 2019-06-27 14:39:01 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/routes.php
INFO - 2019-06-27 14:39:01 --> Router Class Initialized
INFO - 2019-06-27 14:39:01 --> Output Class Initialized
INFO - 2019-06-27 14:39:01 --> Security Class Initialized
DEBUG - 2019-06-27 14:39:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 14:39:01 --> Input Class Initialized
INFO - 2019-06-27 14:39:01 --> Language Class Initialized
INFO - 2019-06-27 14:39:01 --> Language Class Initialized
INFO - 2019-06-27 14:39:01 --> Config Class Initialized
INFO - 2019-06-27 14:39:01 --> Loader Class Initialized
DEBUG - 2019-06-27 14:39:01 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/site.php
INFO - 2019-06-27 14:39:01 --> Helper loaded: url_helper
INFO - 2019-06-27 14:39:01 --> Helper loaded: inflector_helper
INFO - 2019-06-27 14:39:01 --> Helper loaded: string_helper
INFO - 2019-06-27 14:39:01 --> Helper loaded: array_helper
INFO - 2019-06-27 14:39:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 14:39:01 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/autoload.php
DEBUG - 2019-06-27 14:39:01 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/helpers/adminlte_helper.php
INFO - 2019-06-27 14:39:01 --> Database Driver Class Initialized
DEBUG - 2019-06-27 14:39:01 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/libraries/Crud.php
INFO - 2019-06-27 14:39:01 --> Helper loaded: form_helper
DEBUG - 2019-06-27 14:39:01 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-06-27 14:39:01 --> Form Validation Class Initialized
DEBUG - 2019-06-27 14:39:01 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-06-27 14:39:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-06-27 14:39:01 --> Pagination Class Initialized
INFO - 2019-06-27 14:39:01 --> Controller Class Initialized
INFO - 2019-06-27 20:39:02 --> Final output sent to browser
DEBUG - 2019-06-27 20:39:02 --> Total execution time: 0.3933
INFO - 2019-06-27 14:39:09 --> Config Class Initialized
INFO - 2019-06-27 14:39:09 --> Hooks Class Initialized
DEBUG - 2019-06-27 14:39:09 --> UTF-8 Support Enabled
INFO - 2019-06-27 14:39:09 --> Utf8 Class Initialized
INFO - 2019-06-27 14:39:09 --> URI Class Initialized
INFO - 2019-06-27 14:39:09 --> Router Class Initialized
INFO - 2019-06-27 14:39:09 --> Output Class Initialized
INFO - 2019-06-27 14:39:09 --> Security Class Initialized
DEBUG - 2019-06-27 14:39:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 14:39:09 --> Input Class Initialized
INFO - 2019-06-27 14:39:09 --> Language Class Initialized
INFO - 2019-06-27 14:39:09 --> Language Class Initialized
INFO - 2019-06-27 14:39:09 --> Config Class Initialized
INFO - 2019-06-27 14:39:09 --> Loader Class Initialized
DEBUG - 2019-06-27 14:39:10 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 14:39:10 --> Helper loaded: url_helper
INFO - 2019-06-27 14:39:10 --> Helper loaded: inflector_helper
INFO - 2019-06-27 14:39:10 --> Helper loaded: string_helper
INFO - 2019-06-27 14:39:10 --> Helper loaded: array_helper
INFO - 2019-06-27 14:39:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 14:39:10 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 14:39:10 --> Database Driver Class Initialized
INFO - 2019-06-27 14:39:10 --> Controller Class Initialized
INFO - 2019-06-27 20:39:10 --> Helper loaded: language_helper
INFO - 2019-06-27 20:39:10 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 20:39:10 --> Model Class Initialized
INFO - 2019-06-27 20:39:10 --> Model Class Initialized
INFO - 2019-06-27 20:39:10 --> Model Class Initialized
INFO - 2019-06-27 20:39:10 --> Model Class Initialized
INFO - 2019-06-27 20:39:10 --> Final output sent to browser
DEBUG - 2019-06-27 20:39:10 --> Total execution time: 0.2886
INFO - 2019-06-27 14:39:11 --> Config Class Initialized
INFO - 2019-06-27 14:39:11 --> Hooks Class Initialized
DEBUG - 2019-06-27 14:39:11 --> UTF-8 Support Enabled
INFO - 2019-06-27 14:39:11 --> Utf8 Class Initialized
INFO - 2019-06-27 14:39:11 --> URI Class Initialized
INFO - 2019-06-27 14:39:11 --> Router Class Initialized
INFO - 2019-06-27 14:39:11 --> Output Class Initialized
INFO - 2019-06-27 14:39:11 --> Security Class Initialized
DEBUG - 2019-06-27 14:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 14:39:11 --> Input Class Initialized
INFO - 2019-06-27 14:39:11 --> Language Class Initialized
INFO - 2019-06-27 14:39:11 --> Language Class Initialized
INFO - 2019-06-27 14:39:11 --> Config Class Initialized
INFO - 2019-06-27 14:39:11 --> Loader Class Initialized
DEBUG - 2019-06-27 14:39:11 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 14:39:11 --> Helper loaded: url_helper
INFO - 2019-06-27 14:39:11 --> Helper loaded: inflector_helper
INFO - 2019-06-27 14:39:11 --> Helper loaded: string_helper
INFO - 2019-06-27 14:39:11 --> Helper loaded: array_helper
INFO - 2019-06-27 14:39:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 14:39:11 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 14:39:11 --> Database Driver Class Initialized
INFO - 2019-06-27 14:39:11 --> Controller Class Initialized
INFO - 2019-06-27 20:39:11 --> Helper loaded: language_helper
INFO - 2019-06-27 20:39:11 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 20:39:11 --> Model Class Initialized
INFO - 2019-06-27 20:39:11 --> Model Class Initialized
INFO - 2019-06-27 20:39:11 --> Model Class Initialized
INFO - 2019-06-27 20:39:11 --> Model Class Initialized
INFO - 2019-06-27 20:39:11 --> Final output sent to browser
DEBUG - 2019-06-27 20:39:11 --> Total execution time: 0.2139
INFO - 2019-06-27 14:39:32 --> Config Class Initialized
INFO - 2019-06-27 14:39:32 --> Hooks Class Initialized
DEBUG - 2019-06-27 14:39:32 --> UTF-8 Support Enabled
INFO - 2019-06-27 14:39:32 --> Utf8 Class Initialized
INFO - 2019-06-27 14:39:32 --> URI Class Initialized
INFO - 2019-06-27 14:39:32 --> Router Class Initialized
INFO - 2019-06-27 14:39:32 --> Output Class Initialized
INFO - 2019-06-27 14:39:32 --> Security Class Initialized
DEBUG - 2019-06-27 14:39:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 14:39:32 --> Input Class Initialized
INFO - 2019-06-27 14:39:32 --> Language Class Initialized
INFO - 2019-06-27 14:39:32 --> Language Class Initialized
INFO - 2019-06-27 14:39:32 --> Config Class Initialized
INFO - 2019-06-27 14:39:32 --> Loader Class Initialized
DEBUG - 2019-06-27 14:39:32 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 14:39:32 --> Helper loaded: url_helper
INFO - 2019-06-27 14:39:32 --> Helper loaded: inflector_helper
INFO - 2019-06-27 14:39:32 --> Helper loaded: string_helper
INFO - 2019-06-27 14:39:32 --> Helper loaded: array_helper
INFO - 2019-06-27 14:39:32 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 14:39:32 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 14:39:32 --> Database Driver Class Initialized
INFO - 2019-06-27 14:39:32 --> Controller Class Initialized
INFO - 2019-06-27 20:39:32 --> Helper loaded: language_helper
INFO - 2019-06-27 20:39:32 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 20:39:32 --> Model Class Initialized
INFO - 2019-06-27 20:39:32 --> Model Class Initialized
INFO - 2019-06-27 20:39:32 --> Model Class Initialized
INFO - 2019-06-27 20:39:32 --> Model Class Initialized
INFO - 2019-06-27 20:39:32 --> Final output sent to browser
DEBUG - 2019-06-27 20:39:32 --> Total execution time: 0.1971
INFO - 2019-06-27 14:39:42 --> Config Class Initialized
INFO - 2019-06-27 14:39:42 --> Hooks Class Initialized
DEBUG - 2019-06-27 14:39:42 --> UTF-8 Support Enabled
INFO - 2019-06-27 14:39:42 --> Utf8 Class Initialized
INFO - 2019-06-27 14:39:42 --> URI Class Initialized
DEBUG - 2019-06-27 14:39:42 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/routes.php
INFO - 2019-06-27 14:39:42 --> Router Class Initialized
INFO - 2019-06-27 14:39:42 --> Output Class Initialized
INFO - 2019-06-27 14:39:42 --> Security Class Initialized
DEBUG - 2019-06-27 14:39:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 14:39:42 --> Input Class Initialized
INFO - 2019-06-27 14:39:42 --> Language Class Initialized
INFO - 2019-06-27 14:39:42 --> Language Class Initialized
INFO - 2019-06-27 14:39:42 --> Config Class Initialized
INFO - 2019-06-27 14:39:42 --> Loader Class Initialized
DEBUG - 2019-06-27 14:39:42 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/site.php
INFO - 2019-06-27 14:39:42 --> Helper loaded: url_helper
INFO - 2019-06-27 14:39:42 --> Helper loaded: inflector_helper
INFO - 2019-06-27 14:39:42 --> Helper loaded: string_helper
INFO - 2019-06-27 14:39:42 --> Helper loaded: array_helper
INFO - 2019-06-27 14:39:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 14:39:42 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/autoload.php
DEBUG - 2019-06-27 14:39:42 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/helpers/adminlte_helper.php
INFO - 2019-06-27 14:39:42 --> Database Driver Class Initialized
DEBUG - 2019-06-27 14:39:42 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/libraries/Crud.php
INFO - 2019-06-27 14:39:42 --> Helper loaded: form_helper
DEBUG - 2019-06-27 14:39:42 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-06-27 14:39:42 --> Form Validation Class Initialized
DEBUG - 2019-06-27 14:39:42 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-06-27 14:39:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-06-27 14:39:42 --> Pagination Class Initialized
INFO - 2019-06-27 14:39:42 --> Controller Class Initialized
INFO - 2019-06-27 20:39:42 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-06-27 20:39:42 --> Model Class Initialized
INFO - 2019-06-27 20:39:42 --> Model Class Initialized
INFO - 2019-06-27 14:39:42 --> Config Class Initialized
INFO - 2019-06-27 14:39:42 --> Hooks Class Initialized
DEBUG - 2019-06-27 14:39:42 --> UTF-8 Support Enabled
INFO - 2019-06-27 14:39:42 --> Utf8 Class Initialized
INFO - 2019-06-27 14:39:42 --> URI Class Initialized
DEBUG - 2019-06-27 14:39:42 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/routes.php
INFO - 2019-06-27 14:39:42 --> Router Class Initialized
INFO - 2019-06-27 14:39:42 --> Output Class Initialized
INFO - 2019-06-27 14:39:42 --> Security Class Initialized
DEBUG - 2019-06-27 14:39:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 14:39:42 --> Input Class Initialized
INFO - 2019-06-27 14:39:42 --> Language Class Initialized
INFO - 2019-06-27 14:39:42 --> Language Class Initialized
INFO - 2019-06-27 14:39:42 --> Config Class Initialized
INFO - 2019-06-27 14:39:42 --> Loader Class Initialized
DEBUG - 2019-06-27 14:39:42 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/site.php
INFO - 2019-06-27 14:39:42 --> Helper loaded: url_helper
INFO - 2019-06-27 14:39:42 --> Helper loaded: inflector_helper
INFO - 2019-06-27 14:39:42 --> Helper loaded: string_helper
INFO - 2019-06-27 14:39:42 --> Helper loaded: array_helper
INFO - 2019-06-27 14:39:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 14:39:42 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/autoload.php
DEBUG - 2019-06-27 14:39:42 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/helpers/adminlte_helper.php
INFO - 2019-06-27 14:39:42 --> Database Driver Class Initialized
DEBUG - 2019-06-27 14:39:42 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/libraries/Crud.php
INFO - 2019-06-27 14:39:42 --> Helper loaded: form_helper
DEBUG - 2019-06-27 14:39:42 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-06-27 14:39:42 --> Form Validation Class Initialized
DEBUG - 2019-06-27 14:39:42 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-06-27 14:39:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-06-27 14:39:42 --> Pagination Class Initialized
INFO - 2019-06-27 14:39:42 --> Controller Class Initialized
INFO - 2019-06-27 20:39:43 --> Final output sent to browser
DEBUG - 2019-06-27 20:39:43 --> Total execution time: 0.2810
INFO - 2019-06-27 14:39:46 --> Config Class Initialized
INFO - 2019-06-27 14:39:46 --> Hooks Class Initialized
DEBUG - 2019-06-27 14:39:46 --> UTF-8 Support Enabled
INFO - 2019-06-27 14:39:46 --> Utf8 Class Initialized
INFO - 2019-06-27 14:39:46 --> URI Class Initialized
DEBUG - 2019-06-27 14:39:46 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/routes.php
INFO - 2019-06-27 14:39:46 --> Router Class Initialized
INFO - 2019-06-27 14:39:46 --> Output Class Initialized
INFO - 2019-06-27 14:39:46 --> Security Class Initialized
DEBUG - 2019-06-27 14:39:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 14:39:46 --> Input Class Initialized
INFO - 2019-06-27 14:39:46 --> Language Class Initialized
INFO - 2019-06-27 14:39:46 --> Language Class Initialized
INFO - 2019-06-27 14:39:46 --> Config Class Initialized
INFO - 2019-06-27 14:39:46 --> Loader Class Initialized
DEBUG - 2019-06-27 14:39:46 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/site.php
INFO - 2019-06-27 14:39:46 --> Helper loaded: url_helper
INFO - 2019-06-27 14:39:46 --> Helper loaded: inflector_helper
INFO - 2019-06-27 14:39:46 --> Helper loaded: string_helper
INFO - 2019-06-27 14:39:46 --> Helper loaded: array_helper
INFO - 2019-06-27 14:39:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 14:39:46 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/autoload.php
DEBUG - 2019-06-27 14:39:46 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/helpers/adminlte_helper.php
INFO - 2019-06-27 14:39:46 --> Database Driver Class Initialized
DEBUG - 2019-06-27 14:39:46 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/libraries/Crud.php
INFO - 2019-06-27 14:39:46 --> Helper loaded: form_helper
DEBUG - 2019-06-27 14:39:46 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-06-27 14:39:46 --> Form Validation Class Initialized
DEBUG - 2019-06-27 14:39:46 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-06-27 14:39:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-06-27 14:39:46 --> Pagination Class Initialized
INFO - 2019-06-27 14:39:46 --> Controller Class Initialized
INFO - 2019-06-27 20:39:46 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-06-27 20:39:46 --> Model Class Initialized
INFO - 2019-06-27 20:39:46 --> Model Class Initialized
INFO - 2019-06-27 14:39:46 --> Config Class Initialized
INFO - 2019-06-27 14:39:46 --> Hooks Class Initialized
DEBUG - 2019-06-27 14:39:46 --> UTF-8 Support Enabled
INFO - 2019-06-27 14:39:46 --> Utf8 Class Initialized
INFO - 2019-06-27 14:39:46 --> URI Class Initialized
DEBUG - 2019-06-27 14:39:46 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/routes.php
INFO - 2019-06-27 14:39:46 --> Router Class Initialized
INFO - 2019-06-27 14:39:46 --> Output Class Initialized
INFO - 2019-06-27 14:39:46 --> Security Class Initialized
DEBUG - 2019-06-27 14:39:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 14:39:46 --> Input Class Initialized
INFO - 2019-06-27 14:39:46 --> Language Class Initialized
INFO - 2019-06-27 14:39:46 --> Language Class Initialized
INFO - 2019-06-27 14:39:46 --> Config Class Initialized
INFO - 2019-06-27 14:39:46 --> Loader Class Initialized
DEBUG - 2019-06-27 14:39:46 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/site.php
INFO - 2019-06-27 14:39:46 --> Helper loaded: url_helper
INFO - 2019-06-27 14:39:46 --> Helper loaded: inflector_helper
INFO - 2019-06-27 14:39:46 --> Helper loaded: string_helper
INFO - 2019-06-27 14:39:46 --> Helper loaded: array_helper
INFO - 2019-06-27 14:39:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 14:39:46 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/autoload.php
DEBUG - 2019-06-27 14:39:46 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/helpers/adminlte_helper.php
INFO - 2019-06-27 14:39:46 --> Database Driver Class Initialized
DEBUG - 2019-06-27 14:39:46 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/libraries/Crud.php
INFO - 2019-06-27 14:39:46 --> Helper loaded: form_helper
DEBUG - 2019-06-27 14:39:46 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-06-27 14:39:46 --> Form Validation Class Initialized
DEBUG - 2019-06-27 14:39:46 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-06-27 14:39:46 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-06-27 14:39:46 --> Pagination Class Initialized
INFO - 2019-06-27 14:39:46 --> Controller Class Initialized
INFO - 2019-06-27 20:39:46 --> Final output sent to browser
DEBUG - 2019-06-27 20:39:46 --> Total execution time: 0.2714
INFO - 2019-06-27 14:39:49 --> Config Class Initialized
INFO - 2019-06-27 14:39:49 --> Hooks Class Initialized
DEBUG - 2019-06-27 14:39:49 --> UTF-8 Support Enabled
INFO - 2019-06-27 14:39:49 --> Utf8 Class Initialized
INFO - 2019-06-27 14:39:49 --> URI Class Initialized
DEBUG - 2019-06-27 14:39:49 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/routes.php
INFO - 2019-06-27 14:39:49 --> Router Class Initialized
INFO - 2019-06-27 14:39:49 --> Output Class Initialized
INFO - 2019-06-27 14:39:49 --> Security Class Initialized
DEBUG - 2019-06-27 14:39:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 14:39:49 --> Input Class Initialized
INFO - 2019-06-27 14:39:49 --> Language Class Initialized
INFO - 2019-06-27 14:39:49 --> Language Class Initialized
INFO - 2019-06-27 14:39:49 --> Config Class Initialized
INFO - 2019-06-27 14:39:49 --> Loader Class Initialized
DEBUG - 2019-06-27 14:39:49 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/site.php
INFO - 2019-06-27 14:39:49 --> Helper loaded: url_helper
INFO - 2019-06-27 14:39:49 --> Helper loaded: inflector_helper
INFO - 2019-06-27 14:39:49 --> Helper loaded: string_helper
INFO - 2019-06-27 14:39:49 --> Helper loaded: array_helper
INFO - 2019-06-27 14:39:49 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 14:39:49 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/autoload.php
DEBUG - 2019-06-27 14:39:49 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/helpers/adminlte_helper.php
INFO - 2019-06-27 14:39:49 --> Database Driver Class Initialized
DEBUG - 2019-06-27 14:39:49 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/libraries/Crud.php
INFO - 2019-06-27 14:39:49 --> Helper loaded: form_helper
DEBUG - 2019-06-27 14:39:49 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-06-27 14:39:49 --> Form Validation Class Initialized
DEBUG - 2019-06-27 14:39:49 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-06-27 14:39:49 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-06-27 14:39:49 --> Pagination Class Initialized
INFO - 2019-06-27 14:39:49 --> Controller Class Initialized
INFO - 2019-06-27 20:39:49 --> Model Class Initialized
INFO - 2019-06-27 20:39:49 --> Model Class Initialized
INFO - 2019-06-27 20:39:49 --> Final output sent to browser
DEBUG - 2019-06-27 20:39:49 --> Total execution time: 0.2820
INFO - 2019-06-27 14:40:03 --> Config Class Initialized
INFO - 2019-06-27 14:40:03 --> Hooks Class Initialized
DEBUG - 2019-06-27 14:40:03 --> UTF-8 Support Enabled
INFO - 2019-06-27 14:40:03 --> Utf8 Class Initialized
INFO - 2019-06-27 14:40:03 --> URI Class Initialized
DEBUG - 2019-06-27 14:40:03 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/routes.php
INFO - 2019-06-27 14:40:03 --> Router Class Initialized
INFO - 2019-06-27 14:40:03 --> Output Class Initialized
INFO - 2019-06-27 14:40:03 --> Security Class Initialized
DEBUG - 2019-06-27 14:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 14:40:03 --> Input Class Initialized
INFO - 2019-06-27 14:40:03 --> Language Class Initialized
INFO - 2019-06-27 14:40:03 --> Language Class Initialized
INFO - 2019-06-27 14:40:03 --> Config Class Initialized
INFO - 2019-06-27 14:40:03 --> Loader Class Initialized
DEBUG - 2019-06-27 14:40:03 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/site.php
INFO - 2019-06-27 14:40:03 --> Helper loaded: url_helper
INFO - 2019-06-27 14:40:03 --> Helper loaded: inflector_helper
INFO - 2019-06-27 14:40:03 --> Helper loaded: string_helper
INFO - 2019-06-27 14:40:03 --> Helper loaded: array_helper
INFO - 2019-06-27 14:40:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 14:40:04 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/autoload.php
DEBUG - 2019-06-27 14:40:04 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/helpers/adminlte_helper.php
INFO - 2019-06-27 14:40:04 --> Database Driver Class Initialized
DEBUG - 2019-06-27 14:40:04 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/libraries/Crud.php
INFO - 2019-06-27 14:40:04 --> Helper loaded: form_helper
DEBUG - 2019-06-27 14:40:04 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-06-27 14:40:04 --> Form Validation Class Initialized
DEBUG - 2019-06-27 14:40:04 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-06-27 14:40:04 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-06-27 14:40:04 --> Pagination Class Initialized
INFO - 2019-06-27 14:40:04 --> Controller Class Initialized
INFO - 2019-06-27 20:40:04 --> Model Class Initialized
INFO - 2019-06-27 20:40:04 --> Model Class Initialized
INFO - 2019-06-27 20:40:04 --> Final output sent to browser
DEBUG - 2019-06-27 20:40:04 --> Total execution time: 0.2601
INFO - 2019-06-27 14:40:27 --> Config Class Initialized
INFO - 2019-06-27 14:40:27 --> Hooks Class Initialized
DEBUG - 2019-06-27 14:40:27 --> UTF-8 Support Enabled
INFO - 2019-06-27 14:40:27 --> Utf8 Class Initialized
INFO - 2019-06-27 14:40:27 --> URI Class Initialized
DEBUG - 2019-06-27 14:40:27 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/routes.php
INFO - 2019-06-27 14:40:27 --> Router Class Initialized
INFO - 2019-06-27 14:40:27 --> Output Class Initialized
INFO - 2019-06-27 14:40:27 --> Security Class Initialized
DEBUG - 2019-06-27 14:40:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 14:40:27 --> Input Class Initialized
INFO - 2019-06-27 14:40:27 --> Language Class Initialized
INFO - 2019-06-27 14:40:27 --> Language Class Initialized
INFO - 2019-06-27 14:40:27 --> Config Class Initialized
INFO - 2019-06-27 14:40:27 --> Loader Class Initialized
DEBUG - 2019-06-27 14:40:27 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/site.php
INFO - 2019-06-27 14:40:27 --> Helper loaded: url_helper
INFO - 2019-06-27 14:40:27 --> Helper loaded: inflector_helper
INFO - 2019-06-27 14:40:27 --> Helper loaded: string_helper
INFO - 2019-06-27 14:40:27 --> Helper loaded: array_helper
INFO - 2019-06-27 14:40:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 14:40:27 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/autoload.php
DEBUG - 2019-06-27 14:40:27 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/helpers/adminlte_helper.php
INFO - 2019-06-27 14:40:27 --> Database Driver Class Initialized
DEBUG - 2019-06-27 14:40:27 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/libraries/Crud.php
INFO - 2019-06-27 14:40:27 --> Helper loaded: form_helper
DEBUG - 2019-06-27 14:40:27 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-06-27 14:40:27 --> Form Validation Class Initialized
DEBUG - 2019-06-27 14:40:27 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-06-27 14:40:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-06-27 14:40:27 --> Pagination Class Initialized
INFO - 2019-06-27 14:40:27 --> Controller Class Initialized
INFO - 2019-06-27 20:40:27 --> Model Class Initialized
INFO - 2019-06-27 20:40:27 --> Model Class Initialized
INFO - 2019-06-27 14:40:27 --> Config Class Initialized
INFO - 2019-06-27 14:40:27 --> Hooks Class Initialized
DEBUG - 2019-06-27 14:40:27 --> UTF-8 Support Enabled
INFO - 2019-06-27 14:40:27 --> Utf8 Class Initialized
INFO - 2019-06-27 14:40:27 --> URI Class Initialized
DEBUG - 2019-06-27 14:40:27 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/routes.php
INFO - 2019-06-27 14:40:27 --> Router Class Initialized
INFO - 2019-06-27 14:40:27 --> Output Class Initialized
INFO - 2019-06-27 14:40:27 --> Security Class Initialized
DEBUG - 2019-06-27 14:40:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 14:40:27 --> Input Class Initialized
INFO - 2019-06-27 14:40:27 --> Language Class Initialized
INFO - 2019-06-27 14:40:27 --> Language Class Initialized
INFO - 2019-06-27 14:40:27 --> Config Class Initialized
INFO - 2019-06-27 14:40:27 --> Loader Class Initialized
DEBUG - 2019-06-27 14:40:27 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/site.php
INFO - 2019-06-27 14:40:27 --> Helper loaded: url_helper
INFO - 2019-06-27 14:40:27 --> Helper loaded: inflector_helper
INFO - 2019-06-27 14:40:27 --> Helper loaded: string_helper
INFO - 2019-06-27 14:40:27 --> Helper loaded: array_helper
INFO - 2019-06-27 14:40:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 14:40:27 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/autoload.php
DEBUG - 2019-06-27 14:40:27 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/helpers/adminlte_helper.php
INFO - 2019-06-27 14:40:27 --> Database Driver Class Initialized
DEBUG - 2019-06-27 14:40:27 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/libraries/Crud.php
INFO - 2019-06-27 14:40:27 --> Helper loaded: form_helper
DEBUG - 2019-06-27 14:40:27 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-06-27 14:40:27 --> Form Validation Class Initialized
DEBUG - 2019-06-27 14:40:27 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-06-27 14:40:27 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-06-27 14:40:27 --> Pagination Class Initialized
INFO - 2019-06-27 14:40:27 --> Controller Class Initialized
INFO - 2019-06-27 20:40:27 --> Model Class Initialized
INFO - 2019-06-27 20:40:28 --> Model Class Initialized
INFO - 2019-06-27 20:40:28 --> Final output sent to browser
DEBUG - 2019-06-27 20:40:28 --> Total execution time: 0.2404
INFO - 2019-06-27 14:42:11 --> Config Class Initialized
INFO - 2019-06-27 14:42:11 --> Hooks Class Initialized
DEBUG - 2019-06-27 14:42:11 --> UTF-8 Support Enabled
INFO - 2019-06-27 14:42:11 --> Utf8 Class Initialized
INFO - 2019-06-27 14:42:11 --> URI Class Initialized
INFO - 2019-06-27 14:42:11 --> Router Class Initialized
INFO - 2019-06-27 14:42:11 --> Output Class Initialized
INFO - 2019-06-27 14:42:11 --> Security Class Initialized
DEBUG - 2019-06-27 14:42:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 14:42:11 --> Input Class Initialized
INFO - 2019-06-27 14:42:11 --> Language Class Initialized
INFO - 2019-06-27 14:42:11 --> Language Class Initialized
INFO - 2019-06-27 14:42:11 --> Config Class Initialized
INFO - 2019-06-27 14:42:11 --> Loader Class Initialized
DEBUG - 2019-06-27 14:42:11 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 14:42:11 --> Helper loaded: url_helper
INFO - 2019-06-27 14:42:11 --> Helper loaded: inflector_helper
INFO - 2019-06-27 14:42:11 --> Helper loaded: string_helper
INFO - 2019-06-27 14:42:11 --> Helper loaded: array_helper
INFO - 2019-06-27 14:42:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 14:42:11 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 14:42:11 --> Database Driver Class Initialized
INFO - 2019-06-27 14:42:11 --> Controller Class Initialized
INFO - 2019-06-27 20:42:11 --> Helper loaded: language_helper
INFO - 2019-06-27 20:42:11 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 20:42:11 --> Model Class Initialized
INFO - 2019-06-27 20:42:11 --> Model Class Initialized
INFO - 2019-06-27 20:42:11 --> Model Class Initialized
INFO - 2019-06-27 20:42:11 --> Model Class Initialized
INFO - 2019-06-27 20:42:11 --> Final output sent to browser
DEBUG - 2019-06-27 20:42:11 --> Total execution time: 0.2539
INFO - 2019-06-27 14:42:12 --> Config Class Initialized
INFO - 2019-06-27 14:42:12 --> Hooks Class Initialized
DEBUG - 2019-06-27 14:42:12 --> UTF-8 Support Enabled
INFO - 2019-06-27 14:42:12 --> Utf8 Class Initialized
INFO - 2019-06-27 14:42:12 --> URI Class Initialized
INFO - 2019-06-27 14:42:12 --> Router Class Initialized
INFO - 2019-06-27 14:42:12 --> Output Class Initialized
INFO - 2019-06-27 14:42:12 --> Security Class Initialized
DEBUG - 2019-06-27 14:42:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 14:42:12 --> Input Class Initialized
INFO - 2019-06-27 14:42:12 --> Language Class Initialized
INFO - 2019-06-27 14:42:12 --> Language Class Initialized
INFO - 2019-06-27 14:42:12 --> Config Class Initialized
INFO - 2019-06-27 14:42:12 --> Loader Class Initialized
DEBUG - 2019-06-27 14:42:12 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 14:42:12 --> Helper loaded: url_helper
INFO - 2019-06-27 14:42:12 --> Helper loaded: inflector_helper
INFO - 2019-06-27 14:42:12 --> Helper loaded: string_helper
INFO - 2019-06-27 14:42:12 --> Helper loaded: array_helper
INFO - 2019-06-27 14:42:12 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 14:42:12 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 14:42:12 --> Database Driver Class Initialized
INFO - 2019-06-27 14:42:12 --> Controller Class Initialized
INFO - 2019-06-27 20:42:12 --> Helper loaded: language_helper
INFO - 2019-06-27 20:42:12 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 20:42:12 --> Model Class Initialized
INFO - 2019-06-27 20:42:12 --> Model Class Initialized
INFO - 2019-06-27 20:42:12 --> Model Class Initialized
INFO - 2019-06-27 20:42:12 --> Model Class Initialized
INFO - 2019-06-27 20:42:12 --> Model Class Initialized
INFO - 2019-06-27 20:42:12 --> Final output sent to browser
DEBUG - 2019-06-27 20:42:12 --> Total execution time: 0.2344
INFO - 2019-06-27 14:42:15 --> Config Class Initialized
INFO - 2019-06-27 14:42:15 --> Hooks Class Initialized
DEBUG - 2019-06-27 14:42:15 --> UTF-8 Support Enabled
INFO - 2019-06-27 14:42:15 --> Utf8 Class Initialized
INFO - 2019-06-27 14:42:15 --> URI Class Initialized
INFO - 2019-06-27 14:42:15 --> Router Class Initialized
INFO - 2019-06-27 14:42:15 --> Output Class Initialized
INFO - 2019-06-27 14:42:15 --> Security Class Initialized
DEBUG - 2019-06-27 14:42:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 14:42:15 --> Input Class Initialized
INFO - 2019-06-27 14:42:15 --> Language Class Initialized
INFO - 2019-06-27 14:42:15 --> Language Class Initialized
INFO - 2019-06-27 14:42:15 --> Config Class Initialized
INFO - 2019-06-27 14:42:15 --> Loader Class Initialized
DEBUG - 2019-06-27 14:42:15 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 14:42:15 --> Helper loaded: url_helper
INFO - 2019-06-27 14:42:15 --> Helper loaded: inflector_helper
INFO - 2019-06-27 14:42:15 --> Helper loaded: string_helper
INFO - 2019-06-27 14:42:15 --> Helper loaded: array_helper
INFO - 2019-06-27 14:42:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 14:42:15 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 14:42:15 --> Database Driver Class Initialized
INFO - 2019-06-27 14:42:15 --> Controller Class Initialized
INFO - 2019-06-27 20:42:15 --> Helper loaded: language_helper
INFO - 2019-06-27 20:42:15 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 20:42:15 --> Model Class Initialized
INFO - 2019-06-27 20:42:15 --> Model Class Initialized
INFO - 2019-06-27 20:42:15 --> Model Class Initialized
INFO - 2019-06-27 20:42:16 --> Model Class Initialized
INFO - 2019-06-27 20:42:16 --> Helper loaded: form_helper
INFO - 2019-06-27 20:42:16 --> Form Validation Class Initialized
DEBUG - 2019-06-27 20:42:16 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-27 20:42:16 --> Model Class Initialized
INFO - 2019-06-27 20:42:16 --> Model Class Initialized
INFO - 2019-06-27 20:42:16 --> Final output sent to browser
DEBUG - 2019-06-27 20:42:16 --> Total execution time: 0.3121
INFO - 2019-06-27 14:42:18 --> Config Class Initialized
INFO - 2019-06-27 14:42:18 --> Hooks Class Initialized
DEBUG - 2019-06-27 14:42:18 --> UTF-8 Support Enabled
INFO - 2019-06-27 14:42:18 --> Utf8 Class Initialized
INFO - 2019-06-27 14:42:18 --> URI Class Initialized
INFO - 2019-06-27 14:42:18 --> Router Class Initialized
INFO - 2019-06-27 14:42:18 --> Output Class Initialized
INFO - 2019-06-27 14:42:18 --> Security Class Initialized
DEBUG - 2019-06-27 14:42:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 14:42:18 --> Input Class Initialized
INFO - 2019-06-27 14:42:18 --> Language Class Initialized
INFO - 2019-06-27 14:42:18 --> Language Class Initialized
INFO - 2019-06-27 14:42:18 --> Config Class Initialized
INFO - 2019-06-27 14:42:18 --> Loader Class Initialized
DEBUG - 2019-06-27 14:42:18 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 14:42:18 --> Helper loaded: url_helper
INFO - 2019-06-27 14:42:18 --> Helper loaded: inflector_helper
INFO - 2019-06-27 14:42:18 --> Helper loaded: string_helper
INFO - 2019-06-27 14:42:18 --> Helper loaded: array_helper
INFO - 2019-06-27 14:42:18 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 14:42:18 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 14:42:18 --> Database Driver Class Initialized
INFO - 2019-06-27 14:42:18 --> Controller Class Initialized
INFO - 2019-06-27 20:42:18 --> Helper loaded: language_helper
INFO - 2019-06-27 20:42:18 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 20:42:18 --> Model Class Initialized
INFO - 2019-06-27 20:42:18 --> Model Class Initialized
INFO - 2019-06-27 20:42:18 --> Model Class Initialized
INFO - 2019-06-27 20:42:18 --> Model Class Initialized
INFO - 2019-06-27 20:42:18 --> Model Class Initialized
INFO - 2019-06-27 20:42:18 --> Final output sent to browser
DEBUG - 2019-06-27 20:42:18 --> Total execution time: 0.2323
INFO - 2019-06-27 14:42:19 --> Config Class Initialized
INFO - 2019-06-27 14:42:19 --> Hooks Class Initialized
DEBUG - 2019-06-27 14:42:19 --> UTF-8 Support Enabled
INFO - 2019-06-27 14:42:19 --> Utf8 Class Initialized
INFO - 2019-06-27 14:42:19 --> URI Class Initialized
INFO - 2019-06-27 14:42:19 --> Router Class Initialized
INFO - 2019-06-27 14:42:19 --> Output Class Initialized
INFO - 2019-06-27 14:42:19 --> Security Class Initialized
DEBUG - 2019-06-27 14:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 14:42:19 --> Input Class Initialized
INFO - 2019-06-27 14:42:19 --> Language Class Initialized
INFO - 2019-06-27 14:42:19 --> Language Class Initialized
INFO - 2019-06-27 14:42:19 --> Config Class Initialized
INFO - 2019-06-27 14:42:19 --> Loader Class Initialized
DEBUG - 2019-06-27 14:42:19 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 14:42:19 --> Helper loaded: url_helper
INFO - 2019-06-27 14:42:19 --> Helper loaded: inflector_helper
INFO - 2019-06-27 14:42:19 --> Helper loaded: string_helper
INFO - 2019-06-27 14:42:19 --> Helper loaded: array_helper
INFO - 2019-06-27 14:42:19 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 14:42:19 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 14:42:19 --> Database Driver Class Initialized
INFO - 2019-06-27 14:42:19 --> Controller Class Initialized
INFO - 2019-06-27 20:42:19 --> Helper loaded: language_helper
INFO - 2019-06-27 20:42:19 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 20:42:19 --> Model Class Initialized
INFO - 2019-06-27 20:42:19 --> Model Class Initialized
INFO - 2019-06-27 20:42:19 --> Model Class Initialized
INFO - 2019-06-27 20:42:19 --> Model Class Initialized
INFO - 2019-06-27 20:42:19 --> Helper loaded: form_helper
INFO - 2019-06-27 20:42:19 --> Form Validation Class Initialized
DEBUG - 2019-06-27 20:42:19 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-27 20:42:19 --> Model Class Initialized
INFO - 2019-06-27 20:42:19 --> Model Class Initialized
INFO - 2019-06-27 20:42:19 --> Final output sent to browser
DEBUG - 2019-06-27 20:42:19 --> Total execution time: 0.2953
INFO - 2019-06-27 14:42:20 --> Config Class Initialized
INFO - 2019-06-27 14:42:20 --> Hooks Class Initialized
DEBUG - 2019-06-27 14:42:20 --> UTF-8 Support Enabled
INFO - 2019-06-27 14:42:20 --> Utf8 Class Initialized
INFO - 2019-06-27 14:42:20 --> URI Class Initialized
INFO - 2019-06-27 14:42:20 --> Router Class Initialized
INFO - 2019-06-27 14:42:20 --> Output Class Initialized
INFO - 2019-06-27 14:42:20 --> Security Class Initialized
DEBUG - 2019-06-27 14:42:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 14:42:20 --> Input Class Initialized
INFO - 2019-06-27 14:42:20 --> Language Class Initialized
INFO - 2019-06-27 14:42:20 --> Language Class Initialized
INFO - 2019-06-27 14:42:20 --> Config Class Initialized
INFO - 2019-06-27 14:42:20 --> Loader Class Initialized
DEBUG - 2019-06-27 14:42:20 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 14:42:20 --> Helper loaded: url_helper
INFO - 2019-06-27 14:42:20 --> Helper loaded: inflector_helper
INFO - 2019-06-27 14:42:20 --> Helper loaded: string_helper
INFO - 2019-06-27 14:42:20 --> Helper loaded: array_helper
INFO - 2019-06-27 14:42:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 14:42:20 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 14:42:20 --> Database Driver Class Initialized
INFO - 2019-06-27 14:42:20 --> Controller Class Initialized
INFO - 2019-06-27 20:42:20 --> Helper loaded: language_helper
INFO - 2019-06-27 20:42:20 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 20:42:20 --> Model Class Initialized
INFO - 2019-06-27 20:42:20 --> Model Class Initialized
INFO - 2019-06-27 20:42:20 --> Model Class Initialized
INFO - 2019-06-27 20:42:20 --> Model Class Initialized
INFO - 2019-06-27 20:42:20 --> Model Class Initialized
INFO - 2019-06-27 20:42:20 --> Final output sent to browser
DEBUG - 2019-06-27 20:42:20 --> Total execution time: 0.2448
INFO - 2019-06-27 14:42:20 --> Config Class Initialized
INFO - 2019-06-27 14:42:20 --> Hooks Class Initialized
DEBUG - 2019-06-27 14:42:20 --> UTF-8 Support Enabled
INFO - 2019-06-27 14:42:20 --> Utf8 Class Initialized
INFO - 2019-06-27 14:42:20 --> URI Class Initialized
INFO - 2019-06-27 14:42:20 --> Router Class Initialized
INFO - 2019-06-27 14:42:20 --> Output Class Initialized
INFO - 2019-06-27 14:42:20 --> Security Class Initialized
DEBUG - 2019-06-27 14:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 14:42:21 --> Input Class Initialized
INFO - 2019-06-27 14:42:21 --> Language Class Initialized
INFO - 2019-06-27 14:42:21 --> Language Class Initialized
INFO - 2019-06-27 14:42:21 --> Config Class Initialized
INFO - 2019-06-27 14:42:21 --> Loader Class Initialized
DEBUG - 2019-06-27 14:42:21 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 14:42:21 --> Helper loaded: url_helper
INFO - 2019-06-27 14:42:21 --> Helper loaded: inflector_helper
INFO - 2019-06-27 14:42:21 --> Helper loaded: string_helper
INFO - 2019-06-27 14:42:21 --> Helper loaded: array_helper
INFO - 2019-06-27 14:42:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 14:42:21 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 14:42:21 --> Database Driver Class Initialized
INFO - 2019-06-27 14:42:21 --> Controller Class Initialized
INFO - 2019-06-27 20:42:21 --> Helper loaded: language_helper
INFO - 2019-06-27 20:42:21 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 20:42:21 --> Model Class Initialized
INFO - 2019-06-27 20:42:21 --> Model Class Initialized
INFO - 2019-06-27 20:42:21 --> Model Class Initialized
INFO - 2019-06-27 20:42:21 --> Model Class Initialized
INFO - 2019-06-27 20:42:21 --> Model Class Initialized
INFO - 2019-06-27 20:42:21 --> Final output sent to browser
DEBUG - 2019-06-27 20:42:21 --> Total execution time: 0.2051
INFO - 2019-06-27 14:42:31 --> Config Class Initialized
INFO - 2019-06-27 14:42:31 --> Hooks Class Initialized
DEBUG - 2019-06-27 14:42:31 --> UTF-8 Support Enabled
INFO - 2019-06-27 14:42:31 --> Utf8 Class Initialized
INFO - 2019-06-27 14:42:31 --> URI Class Initialized
DEBUG - 2019-06-27 14:42:31 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/routes.php
INFO - 2019-06-27 14:42:31 --> Router Class Initialized
INFO - 2019-06-27 14:42:31 --> Output Class Initialized
INFO - 2019-06-27 14:42:31 --> Security Class Initialized
DEBUG - 2019-06-27 14:42:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 14:42:31 --> Input Class Initialized
INFO - 2019-06-27 14:42:31 --> Language Class Initialized
INFO - 2019-06-27 14:42:31 --> Language Class Initialized
INFO - 2019-06-27 14:42:31 --> Config Class Initialized
INFO - 2019-06-27 14:42:31 --> Loader Class Initialized
DEBUG - 2019-06-27 14:42:31 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/site.php
INFO - 2019-06-27 14:42:31 --> Helper loaded: url_helper
INFO - 2019-06-27 14:42:31 --> Helper loaded: inflector_helper
INFO - 2019-06-27 14:42:31 --> Helper loaded: string_helper
INFO - 2019-06-27 14:42:31 --> Helper loaded: array_helper
INFO - 2019-06-27 14:42:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 14:42:31 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/autoload.php
DEBUG - 2019-06-27 14:42:31 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/helpers/adminlte_helper.php
INFO - 2019-06-27 14:42:31 --> Database Driver Class Initialized
DEBUG - 2019-06-27 14:42:31 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/libraries/Crud.php
INFO - 2019-06-27 14:42:31 --> Helper loaded: form_helper
DEBUG - 2019-06-27 14:42:31 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-06-27 14:42:31 --> Form Validation Class Initialized
DEBUG - 2019-06-27 14:42:31 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-06-27 14:42:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-06-27 14:42:31 --> Pagination Class Initialized
INFO - 2019-06-27 14:42:31 --> Controller Class Initialized
INFO - 2019-06-27 20:42:31 --> Model Class Initialized
INFO - 2019-06-27 20:42:31 --> Model Class Initialized
INFO - 2019-06-27 20:42:31 --> Final output sent to browser
DEBUG - 2019-06-27 20:42:31 --> Total execution time: 0.2677
INFO - 2019-06-27 14:42:46 --> Config Class Initialized
INFO - 2019-06-27 14:42:46 --> Hooks Class Initialized
DEBUG - 2019-06-27 14:42:46 --> UTF-8 Support Enabled
INFO - 2019-06-27 14:42:46 --> Utf8 Class Initialized
INFO - 2019-06-27 14:42:46 --> URI Class Initialized
INFO - 2019-06-27 14:42:46 --> Router Class Initialized
INFO - 2019-06-27 14:42:46 --> Output Class Initialized
INFO - 2019-06-27 14:42:46 --> Security Class Initialized
DEBUG - 2019-06-27 14:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 14:42:46 --> Input Class Initialized
INFO - 2019-06-27 14:42:46 --> Language Class Initialized
INFO - 2019-06-27 14:42:46 --> Language Class Initialized
INFO - 2019-06-27 14:42:46 --> Config Class Initialized
INFO - 2019-06-27 14:42:46 --> Loader Class Initialized
DEBUG - 2019-06-27 14:42:46 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 14:42:46 --> Helper loaded: url_helper
INFO - 2019-06-27 14:42:46 --> Helper loaded: inflector_helper
INFO - 2019-06-27 14:42:46 --> Helper loaded: string_helper
INFO - 2019-06-27 14:42:46 --> Helper loaded: array_helper
INFO - 2019-06-27 14:42:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 14:42:46 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 14:42:46 --> Database Driver Class Initialized
INFO - 2019-06-27 14:42:46 --> Controller Class Initialized
INFO - 2019-06-27 20:42:46 --> Helper loaded: language_helper
INFO - 2019-06-27 20:42:46 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 20:42:46 --> Model Class Initialized
INFO - 2019-06-27 20:42:46 --> Model Class Initialized
INFO - 2019-06-27 20:42:46 --> Model Class Initialized
INFO - 2019-06-27 20:42:46 --> Model Class Initialized
INFO - 2019-06-27 20:42:46 --> Final output sent to browser
DEBUG - 2019-06-27 20:42:46 --> Total execution time: 0.2597
INFO - 2019-06-27 14:42:46 --> Config Class Initialized
INFO - 2019-06-27 14:42:46 --> Hooks Class Initialized
DEBUG - 2019-06-27 14:42:46 --> UTF-8 Support Enabled
INFO - 2019-06-27 14:42:46 --> Utf8 Class Initialized
INFO - 2019-06-27 14:42:46 --> URI Class Initialized
INFO - 2019-06-27 14:42:46 --> Router Class Initialized
INFO - 2019-06-27 14:42:46 --> Output Class Initialized
INFO - 2019-06-27 14:42:46 --> Security Class Initialized
DEBUG - 2019-06-27 14:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 14:42:46 --> Input Class Initialized
INFO - 2019-06-27 14:42:46 --> Language Class Initialized
INFO - 2019-06-27 14:42:46 --> Language Class Initialized
INFO - 2019-06-27 14:42:46 --> Config Class Initialized
INFO - 2019-06-27 14:42:46 --> Loader Class Initialized
DEBUG - 2019-06-27 14:42:46 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 14:42:46 --> Helper loaded: url_helper
INFO - 2019-06-27 14:42:46 --> Helper loaded: inflector_helper
INFO - 2019-06-27 14:42:46 --> Helper loaded: string_helper
INFO - 2019-06-27 14:42:46 --> Helper loaded: array_helper
INFO - 2019-06-27 14:42:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 14:42:46 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 14:42:46 --> Database Driver Class Initialized
INFO - 2019-06-27 14:42:46 --> Controller Class Initialized
INFO - 2019-06-27 20:42:46 --> Helper loaded: language_helper
INFO - 2019-06-27 20:42:46 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 20:42:46 --> Model Class Initialized
INFO - 2019-06-27 20:42:46 --> Model Class Initialized
INFO - 2019-06-27 20:42:46 --> Model Class Initialized
INFO - 2019-06-27 20:42:46 --> Model Class Initialized
INFO - 2019-06-27 20:42:46 --> Model Class Initialized
INFO - 2019-06-27 20:42:46 --> Final output sent to browser
DEBUG - 2019-06-27 20:42:46 --> Total execution time: 0.2170
INFO - 2019-06-27 14:42:50 --> Config Class Initialized
INFO - 2019-06-27 14:42:50 --> Hooks Class Initialized
DEBUG - 2019-06-27 14:42:50 --> UTF-8 Support Enabled
INFO - 2019-06-27 14:42:50 --> Utf8 Class Initialized
INFO - 2019-06-27 14:42:50 --> URI Class Initialized
INFO - 2019-06-27 14:42:50 --> Router Class Initialized
INFO - 2019-06-27 14:42:50 --> Output Class Initialized
INFO - 2019-06-27 14:42:50 --> Security Class Initialized
DEBUG - 2019-06-27 14:42:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 14:42:50 --> Input Class Initialized
INFO - 2019-06-27 14:42:50 --> Language Class Initialized
INFO - 2019-06-27 14:42:50 --> Language Class Initialized
INFO - 2019-06-27 14:42:50 --> Config Class Initialized
INFO - 2019-06-27 14:42:50 --> Loader Class Initialized
DEBUG - 2019-06-27 14:42:50 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 14:42:50 --> Helper loaded: url_helper
INFO - 2019-06-27 14:42:50 --> Helper loaded: inflector_helper
INFO - 2019-06-27 14:42:50 --> Helper loaded: string_helper
INFO - 2019-06-27 14:42:50 --> Helper loaded: array_helper
INFO - 2019-06-27 14:42:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 14:42:50 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 14:42:50 --> Database Driver Class Initialized
INFO - 2019-06-27 14:42:50 --> Controller Class Initialized
INFO - 2019-06-27 20:42:50 --> Helper loaded: language_helper
INFO - 2019-06-27 20:42:50 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 20:42:50 --> Model Class Initialized
INFO - 2019-06-27 20:42:50 --> Model Class Initialized
INFO - 2019-06-27 20:42:50 --> Model Class Initialized
INFO - 2019-06-27 20:42:50 --> Model Class Initialized
INFO - 2019-06-27 20:42:50 --> Helper loaded: form_helper
INFO - 2019-06-27 20:42:50 --> Form Validation Class Initialized
DEBUG - 2019-06-27 20:42:50 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-27 20:42:50 --> Model Class Initialized
INFO - 2019-06-27 20:42:50 --> Model Class Initialized
INFO - 2019-06-27 20:42:50 --> Final output sent to browser
DEBUG - 2019-06-27 20:42:50 --> Total execution time: 0.2459
INFO - 2019-06-27 14:42:51 --> Config Class Initialized
INFO - 2019-06-27 14:42:51 --> Hooks Class Initialized
DEBUG - 2019-06-27 14:42:51 --> UTF-8 Support Enabled
INFO - 2019-06-27 14:42:52 --> Utf8 Class Initialized
INFO - 2019-06-27 14:42:52 --> URI Class Initialized
INFO - 2019-06-27 14:42:52 --> Router Class Initialized
INFO - 2019-06-27 14:42:52 --> Output Class Initialized
INFO - 2019-06-27 14:42:52 --> Security Class Initialized
DEBUG - 2019-06-27 14:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 14:42:52 --> Input Class Initialized
INFO - 2019-06-27 14:42:52 --> Language Class Initialized
INFO - 2019-06-27 14:42:52 --> Language Class Initialized
INFO - 2019-06-27 14:42:52 --> Config Class Initialized
INFO - 2019-06-27 14:42:52 --> Loader Class Initialized
DEBUG - 2019-06-27 14:42:52 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 14:42:52 --> Helper loaded: url_helper
INFO - 2019-06-27 14:42:52 --> Helper loaded: inflector_helper
INFO - 2019-06-27 14:42:52 --> Helper loaded: string_helper
INFO - 2019-06-27 14:42:52 --> Helper loaded: array_helper
INFO - 2019-06-27 14:42:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 14:42:52 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 14:42:52 --> Database Driver Class Initialized
INFO - 2019-06-27 14:42:52 --> Controller Class Initialized
INFO - 2019-06-27 20:42:52 --> Helper loaded: language_helper
INFO - 2019-06-27 20:42:52 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 20:42:52 --> Model Class Initialized
INFO - 2019-06-27 20:42:52 --> Model Class Initialized
INFO - 2019-06-27 20:42:52 --> Model Class Initialized
INFO - 2019-06-27 20:42:52 --> Model Class Initialized
INFO - 2019-06-27 20:42:52 --> Model Class Initialized
INFO - 2019-06-27 20:42:52 --> Final output sent to browser
DEBUG - 2019-06-27 20:42:52 --> Total execution time: 0.2169
INFO - 2019-06-27 14:42:53 --> Config Class Initialized
INFO - 2019-06-27 14:42:53 --> Hooks Class Initialized
DEBUG - 2019-06-27 14:42:53 --> UTF-8 Support Enabled
INFO - 2019-06-27 14:42:53 --> Utf8 Class Initialized
INFO - 2019-06-27 14:42:53 --> URI Class Initialized
INFO - 2019-06-27 14:42:53 --> Router Class Initialized
INFO - 2019-06-27 14:42:53 --> Output Class Initialized
INFO - 2019-06-27 14:42:53 --> Security Class Initialized
DEBUG - 2019-06-27 14:42:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 14:42:53 --> Input Class Initialized
INFO - 2019-06-27 14:42:53 --> Language Class Initialized
INFO - 2019-06-27 14:42:53 --> Language Class Initialized
INFO - 2019-06-27 14:42:53 --> Config Class Initialized
INFO - 2019-06-27 14:42:53 --> Loader Class Initialized
DEBUG - 2019-06-27 14:42:53 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 14:42:53 --> Helper loaded: url_helper
INFO - 2019-06-27 14:42:53 --> Helper loaded: inflector_helper
INFO - 2019-06-27 14:42:53 --> Helper loaded: string_helper
INFO - 2019-06-27 14:42:53 --> Helper loaded: array_helper
INFO - 2019-06-27 14:42:53 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 14:42:53 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 14:42:53 --> Database Driver Class Initialized
INFO - 2019-06-27 14:42:53 --> Controller Class Initialized
INFO - 2019-06-27 20:42:53 --> Helper loaded: language_helper
INFO - 2019-06-27 20:42:53 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 20:42:53 --> Model Class Initialized
INFO - 2019-06-27 20:42:53 --> Model Class Initialized
INFO - 2019-06-27 20:42:53 --> Model Class Initialized
INFO - 2019-06-27 20:42:53 --> Model Class Initialized
INFO - 2019-06-27 20:42:53 --> Model Class Initialized
INFO - 2019-06-27 20:42:53 --> Final output sent to browser
DEBUG - 2019-06-27 20:42:53 --> Total execution time: 0.2438
INFO - 2019-06-27 14:46:41 --> Config Class Initialized
INFO - 2019-06-27 14:46:41 --> Hooks Class Initialized
DEBUG - 2019-06-27 14:46:41 --> UTF-8 Support Enabled
INFO - 2019-06-27 14:46:41 --> Utf8 Class Initialized
INFO - 2019-06-27 14:46:41 --> URI Class Initialized
DEBUG - 2019-06-27 14:46:41 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/routes.php
INFO - 2019-06-27 14:46:41 --> Router Class Initialized
INFO - 2019-06-27 14:46:41 --> Output Class Initialized
INFO - 2019-06-27 14:46:41 --> Security Class Initialized
DEBUG - 2019-06-27 14:46:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 14:46:41 --> Input Class Initialized
INFO - 2019-06-27 14:46:41 --> Language Class Initialized
INFO - 2019-06-27 14:46:41 --> Language Class Initialized
INFO - 2019-06-27 14:46:41 --> Config Class Initialized
INFO - 2019-06-27 14:46:41 --> Loader Class Initialized
DEBUG - 2019-06-27 14:46:41 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/site.php
INFO - 2019-06-27 14:46:41 --> Helper loaded: url_helper
INFO - 2019-06-27 14:46:41 --> Helper loaded: inflector_helper
INFO - 2019-06-27 14:46:41 --> Helper loaded: string_helper
INFO - 2019-06-27 14:46:41 --> Helper loaded: array_helper
INFO - 2019-06-27 14:46:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 14:46:41 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/autoload.php
DEBUG - 2019-06-27 14:46:41 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/helpers/adminlte_helper.php
INFO - 2019-06-27 14:46:41 --> Database Driver Class Initialized
DEBUG - 2019-06-27 14:46:41 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/libraries/Crud.php
INFO - 2019-06-27 14:46:41 --> Helper loaded: form_helper
DEBUG - 2019-06-27 14:46:41 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-06-27 14:46:41 --> Form Validation Class Initialized
DEBUG - 2019-06-27 14:46:41 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-06-27 14:46:41 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-06-27 14:46:41 --> Pagination Class Initialized
INFO - 2019-06-27 14:46:41 --> Controller Class Initialized
INFO - 2019-06-27 20:46:41 --> Model Class Initialized
INFO - 2019-06-27 20:46:41 --> Model Class Initialized
INFO - 2019-06-27 20:46:41 --> Model Class Initialized
INFO - 2019-06-27 20:46:41 --> Final output sent to browser
DEBUG - 2019-06-27 20:46:41 --> Total execution time: 0.4242
INFO - 2019-06-27 14:46:44 --> Config Class Initialized
INFO - 2019-06-27 14:46:44 --> Hooks Class Initialized
DEBUG - 2019-06-27 14:46:44 --> UTF-8 Support Enabled
INFO - 2019-06-27 14:46:44 --> Utf8 Class Initialized
INFO - 2019-06-27 14:46:44 --> URI Class Initialized
DEBUG - 2019-06-27 14:46:44 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/routes.php
INFO - 2019-06-27 14:46:44 --> Router Class Initialized
INFO - 2019-06-27 14:46:44 --> Output Class Initialized
INFO - 2019-06-27 14:46:44 --> Security Class Initialized
DEBUG - 2019-06-27 14:46:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 14:46:44 --> Input Class Initialized
INFO - 2019-06-27 14:46:44 --> Language Class Initialized
INFO - 2019-06-27 14:46:44 --> Language Class Initialized
INFO - 2019-06-27 14:46:44 --> Config Class Initialized
INFO - 2019-06-27 14:46:44 --> Loader Class Initialized
DEBUG - 2019-06-27 14:46:44 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/site.php
INFO - 2019-06-27 14:46:44 --> Helper loaded: url_helper
INFO - 2019-06-27 14:46:44 --> Helper loaded: inflector_helper
INFO - 2019-06-27 14:46:44 --> Helper loaded: string_helper
INFO - 2019-06-27 14:46:44 --> Helper loaded: array_helper
INFO - 2019-06-27 14:46:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 14:46:44 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/autoload.php
DEBUG - 2019-06-27 14:46:44 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/helpers/adminlte_helper.php
INFO - 2019-06-27 14:46:44 --> Database Driver Class Initialized
DEBUG - 2019-06-27 14:46:44 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/libraries/Crud.php
INFO - 2019-06-27 14:46:44 --> Helper loaded: form_helper
DEBUG - 2019-06-27 14:46:44 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-06-27 14:46:44 --> Form Validation Class Initialized
DEBUG - 2019-06-27 14:46:44 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-06-27 14:46:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-06-27 14:46:44 --> Pagination Class Initialized
INFO - 2019-06-27 14:46:44 --> Controller Class Initialized
INFO - 2019-06-27 20:46:44 --> Model Class Initialized
INFO - 2019-06-27 20:46:44 --> Model Class Initialized
INFO - 2019-06-27 20:46:44 --> Model Class Initialized
INFO - 2019-06-27 20:46:44 --> Final output sent to browser
DEBUG - 2019-06-27 20:46:44 --> Total execution time: 0.3510
INFO - 2019-06-27 14:46:56 --> Config Class Initialized
INFO - 2019-06-27 14:46:56 --> Hooks Class Initialized
DEBUG - 2019-06-27 14:46:56 --> UTF-8 Support Enabled
INFO - 2019-06-27 14:46:56 --> Utf8 Class Initialized
INFO - 2019-06-27 14:46:56 --> URI Class Initialized
INFO - 2019-06-27 14:46:56 --> Router Class Initialized
INFO - 2019-06-27 14:46:56 --> Output Class Initialized
INFO - 2019-06-27 14:46:56 --> Security Class Initialized
DEBUG - 2019-06-27 14:46:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 14:46:56 --> Input Class Initialized
INFO - 2019-06-27 14:46:56 --> Language Class Initialized
INFO - 2019-06-27 14:46:56 --> Language Class Initialized
INFO - 2019-06-27 14:46:56 --> Config Class Initialized
INFO - 2019-06-27 14:46:56 --> Loader Class Initialized
DEBUG - 2019-06-27 14:46:56 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 14:46:56 --> Helper loaded: url_helper
INFO - 2019-06-27 14:46:56 --> Helper loaded: inflector_helper
INFO - 2019-06-27 14:46:56 --> Helper loaded: string_helper
INFO - 2019-06-27 14:46:56 --> Helper loaded: array_helper
INFO - 2019-06-27 14:46:56 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 14:46:56 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 14:46:56 --> Database Driver Class Initialized
INFO - 2019-06-27 14:46:56 --> Controller Class Initialized
INFO - 2019-06-27 20:46:56 --> Helper loaded: language_helper
INFO - 2019-06-27 20:46:56 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 20:46:56 --> Model Class Initialized
INFO - 2019-06-27 20:46:56 --> Model Class Initialized
INFO - 2019-06-27 20:46:56 --> Model Class Initialized
INFO - 2019-06-27 20:46:56 --> Model Class Initialized
INFO - 2019-06-27 20:46:56 --> Model Class Initialized
INFO - 2019-06-27 20:46:56 --> Final output sent to browser
DEBUG - 2019-06-27 20:46:56 --> Total execution time: 0.2385
INFO - 2019-06-27 14:47:46 --> Config Class Initialized
INFO - 2019-06-27 14:47:46 --> Hooks Class Initialized
DEBUG - 2019-06-27 14:47:46 --> UTF-8 Support Enabled
INFO - 2019-06-27 14:47:46 --> Utf8 Class Initialized
INFO - 2019-06-27 14:47:46 --> URI Class Initialized
INFO - 2019-06-27 14:47:46 --> Router Class Initialized
INFO - 2019-06-27 14:47:46 --> Output Class Initialized
INFO - 2019-06-27 14:47:46 --> Security Class Initialized
DEBUG - 2019-06-27 14:47:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 14:47:46 --> Input Class Initialized
INFO - 2019-06-27 14:47:46 --> Language Class Initialized
INFO - 2019-06-27 14:47:46 --> Language Class Initialized
INFO - 2019-06-27 14:47:46 --> Config Class Initialized
INFO - 2019-06-27 14:47:46 --> Loader Class Initialized
DEBUG - 2019-06-27 14:47:46 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 14:47:46 --> Helper loaded: url_helper
INFO - 2019-06-27 14:47:46 --> Helper loaded: inflector_helper
INFO - 2019-06-27 14:47:46 --> Helper loaded: string_helper
INFO - 2019-06-27 14:47:46 --> Helper loaded: array_helper
INFO - 2019-06-27 14:47:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 14:47:46 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 14:47:46 --> Database Driver Class Initialized
INFO - 2019-06-27 14:47:46 --> Controller Class Initialized
INFO - 2019-06-27 20:47:46 --> Helper loaded: language_helper
INFO - 2019-06-27 20:47:46 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 20:47:46 --> Model Class Initialized
INFO - 2019-06-27 20:47:46 --> Model Class Initialized
INFO - 2019-06-27 20:47:46 --> Model Class Initialized
INFO - 2019-06-27 20:47:46 --> Model Class Initialized
INFO - 2019-06-27 20:47:46 --> Model Class Initialized
INFO - 2019-06-27 20:47:46 --> Final output sent to browser
DEBUG - 2019-06-27 20:47:46 --> Total execution time: 0.2950
INFO - 2019-06-27 14:51:04 --> Config Class Initialized
INFO - 2019-06-27 14:51:04 --> Hooks Class Initialized
DEBUG - 2019-06-27 14:51:04 --> UTF-8 Support Enabled
INFO - 2019-06-27 14:51:04 --> Utf8 Class Initialized
INFO - 2019-06-27 14:51:04 --> URI Class Initialized
INFO - 2019-06-27 14:51:04 --> Router Class Initialized
INFO - 2019-06-27 14:51:04 --> Output Class Initialized
INFO - 2019-06-27 14:51:04 --> Security Class Initialized
DEBUG - 2019-06-27 14:51:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 14:51:04 --> Input Class Initialized
INFO - 2019-06-27 14:51:04 --> Language Class Initialized
INFO - 2019-06-27 14:51:04 --> Language Class Initialized
INFO - 2019-06-27 14:51:04 --> Config Class Initialized
INFO - 2019-06-27 14:51:04 --> Loader Class Initialized
DEBUG - 2019-06-27 14:51:04 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 14:51:04 --> Helper loaded: url_helper
INFO - 2019-06-27 14:51:04 --> Helper loaded: inflector_helper
INFO - 2019-06-27 14:51:04 --> Helper loaded: string_helper
INFO - 2019-06-27 14:51:04 --> Helper loaded: array_helper
INFO - 2019-06-27 14:51:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 14:51:04 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 14:51:04 --> Database Driver Class Initialized
INFO - 2019-06-27 14:51:04 --> Controller Class Initialized
INFO - 2019-06-27 20:51:04 --> Helper loaded: language_helper
INFO - 2019-06-27 20:51:04 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 20:51:04 --> Model Class Initialized
INFO - 2019-06-27 20:51:05 --> Model Class Initialized
INFO - 2019-06-27 20:51:05 --> Model Class Initialized
INFO - 2019-06-27 20:51:05 --> Model Class Initialized
INFO - 2019-06-27 20:51:05 --> Model Class Initialized
INFO - 2019-06-27 20:51:05 --> Final output sent to browser
DEBUG - 2019-06-27 20:51:05 --> Total execution time: 0.3205
INFO - 2019-06-27 14:54:13 --> Config Class Initialized
INFO - 2019-06-27 14:54:13 --> Hooks Class Initialized
DEBUG - 2019-06-27 14:54:13 --> UTF-8 Support Enabled
INFO - 2019-06-27 14:54:13 --> Utf8 Class Initialized
INFO - 2019-06-27 14:54:13 --> URI Class Initialized
INFO - 2019-06-27 14:54:13 --> Router Class Initialized
INFO - 2019-06-27 14:54:13 --> Output Class Initialized
INFO - 2019-06-27 14:54:13 --> Security Class Initialized
DEBUG - 2019-06-27 14:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 14:54:13 --> Input Class Initialized
INFO - 2019-06-27 14:54:13 --> Language Class Initialized
INFO - 2019-06-27 14:54:13 --> Language Class Initialized
INFO - 2019-06-27 14:54:13 --> Config Class Initialized
INFO - 2019-06-27 14:54:13 --> Loader Class Initialized
DEBUG - 2019-06-27 14:54:13 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 14:54:13 --> Helper loaded: url_helper
INFO - 2019-06-27 14:54:13 --> Helper loaded: inflector_helper
INFO - 2019-06-27 14:54:13 --> Helper loaded: string_helper
INFO - 2019-06-27 14:54:13 --> Helper loaded: array_helper
INFO - 2019-06-27 14:54:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 14:54:13 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 14:54:14 --> Database Driver Class Initialized
INFO - 2019-06-27 14:54:14 --> Controller Class Initialized
INFO - 2019-06-27 20:54:14 --> Helper loaded: language_helper
INFO - 2019-06-27 20:54:14 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 20:54:14 --> Model Class Initialized
INFO - 2019-06-27 20:54:14 --> Model Class Initialized
INFO - 2019-06-27 20:54:14 --> Model Class Initialized
INFO - 2019-06-27 20:54:14 --> Model Class Initialized
INFO - 2019-06-27 20:54:14 --> Model Class Initialized
INFO - 2019-06-27 20:54:14 --> Final output sent to browser
DEBUG - 2019-06-27 20:54:14 --> Total execution time: 0.2399
INFO - 2019-06-27 14:56:19 --> Config Class Initialized
INFO - 2019-06-27 14:56:19 --> Hooks Class Initialized
DEBUG - 2019-06-27 14:56:19 --> UTF-8 Support Enabled
INFO - 2019-06-27 14:56:19 --> Utf8 Class Initialized
INFO - 2019-06-27 14:56:20 --> URI Class Initialized
INFO - 2019-06-27 14:56:20 --> Router Class Initialized
INFO - 2019-06-27 14:56:20 --> Output Class Initialized
INFO - 2019-06-27 14:56:20 --> Security Class Initialized
DEBUG - 2019-06-27 14:56:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 14:56:20 --> Input Class Initialized
INFO - 2019-06-27 14:56:20 --> Language Class Initialized
INFO - 2019-06-27 14:56:20 --> Language Class Initialized
INFO - 2019-06-27 14:56:20 --> Config Class Initialized
INFO - 2019-06-27 14:56:20 --> Loader Class Initialized
DEBUG - 2019-06-27 14:56:20 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 14:56:20 --> Helper loaded: url_helper
INFO - 2019-06-27 14:56:20 --> Helper loaded: inflector_helper
INFO - 2019-06-27 14:56:20 --> Helper loaded: string_helper
INFO - 2019-06-27 14:56:20 --> Helper loaded: array_helper
INFO - 2019-06-27 14:56:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 14:56:20 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 14:56:20 --> Database Driver Class Initialized
INFO - 2019-06-27 14:56:20 --> Controller Class Initialized
INFO - 2019-06-27 20:56:20 --> Helper loaded: language_helper
INFO - 2019-06-27 20:56:20 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 20:56:20 --> Model Class Initialized
INFO - 2019-06-27 20:56:20 --> Model Class Initialized
INFO - 2019-06-27 20:56:20 --> Model Class Initialized
INFO - 2019-06-27 20:56:20 --> Model Class Initialized
INFO - 2019-06-27 20:56:20 --> Model Class Initialized
INFO - 2019-06-27 20:56:20 --> Final output sent to browser
DEBUG - 2019-06-27 20:56:20 --> Total execution time: 0.2704
INFO - 2019-06-27 14:56:53 --> Config Class Initialized
INFO - 2019-06-27 14:56:53 --> Hooks Class Initialized
DEBUG - 2019-06-27 14:56:53 --> UTF-8 Support Enabled
INFO - 2019-06-27 14:56:53 --> Utf8 Class Initialized
INFO - 2019-06-27 14:56:53 --> URI Class Initialized
INFO - 2019-06-27 14:56:53 --> Router Class Initialized
INFO - 2019-06-27 14:56:53 --> Output Class Initialized
INFO - 2019-06-27 14:56:53 --> Security Class Initialized
DEBUG - 2019-06-27 14:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 14:56:53 --> Input Class Initialized
INFO - 2019-06-27 14:56:53 --> Language Class Initialized
INFO - 2019-06-27 14:56:53 --> Language Class Initialized
INFO - 2019-06-27 14:56:53 --> Config Class Initialized
INFO - 2019-06-27 14:56:53 --> Loader Class Initialized
DEBUG - 2019-06-27 14:56:53 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 14:56:53 --> Helper loaded: url_helper
INFO - 2019-06-27 14:56:53 --> Helper loaded: inflector_helper
INFO - 2019-06-27 14:56:53 --> Helper loaded: string_helper
INFO - 2019-06-27 14:56:53 --> Helper loaded: array_helper
INFO - 2019-06-27 14:56:53 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 14:56:53 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 14:56:53 --> Database Driver Class Initialized
INFO - 2019-06-27 14:56:53 --> Controller Class Initialized
INFO - 2019-06-27 20:56:53 --> Helper loaded: language_helper
INFO - 2019-06-27 20:56:53 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 20:56:53 --> Model Class Initialized
INFO - 2019-06-27 20:56:53 --> Model Class Initialized
INFO - 2019-06-27 20:56:53 --> Model Class Initialized
INFO - 2019-06-27 20:56:53 --> Model Class Initialized
INFO - 2019-06-27 20:56:53 --> Model Class Initialized
INFO - 2019-06-27 20:56:53 --> Final output sent to browser
DEBUG - 2019-06-27 20:56:53 --> Total execution time: 0.2486
INFO - 2019-06-27 14:57:35 --> Config Class Initialized
INFO - 2019-06-27 14:57:35 --> Hooks Class Initialized
DEBUG - 2019-06-27 14:57:35 --> UTF-8 Support Enabled
INFO - 2019-06-27 14:57:35 --> Utf8 Class Initialized
INFO - 2019-06-27 14:57:35 --> URI Class Initialized
INFO - 2019-06-27 14:57:35 --> Router Class Initialized
INFO - 2019-06-27 14:57:35 --> Output Class Initialized
INFO - 2019-06-27 14:57:35 --> Security Class Initialized
DEBUG - 2019-06-27 14:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 14:57:35 --> Input Class Initialized
INFO - 2019-06-27 14:57:35 --> Language Class Initialized
INFO - 2019-06-27 14:57:35 --> Language Class Initialized
INFO - 2019-06-27 14:57:35 --> Config Class Initialized
INFO - 2019-06-27 14:57:35 --> Loader Class Initialized
DEBUG - 2019-06-27 14:57:35 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 14:57:35 --> Helper loaded: url_helper
INFO - 2019-06-27 14:57:35 --> Helper loaded: inflector_helper
INFO - 2019-06-27 14:57:35 --> Helper loaded: string_helper
INFO - 2019-06-27 14:57:35 --> Helper loaded: array_helper
INFO - 2019-06-27 14:57:35 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 14:57:35 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 14:57:35 --> Database Driver Class Initialized
INFO - 2019-06-27 14:57:35 --> Controller Class Initialized
INFO - 2019-06-27 20:57:35 --> Helper loaded: language_helper
INFO - 2019-06-27 20:57:35 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 20:57:35 --> Model Class Initialized
INFO - 2019-06-27 20:57:35 --> Model Class Initialized
INFO - 2019-06-27 20:57:35 --> Model Class Initialized
INFO - 2019-06-27 20:57:35 --> Model Class Initialized
INFO - 2019-06-27 20:57:35 --> Model Class Initialized
INFO - 2019-06-27 20:57:35 --> Final output sent to browser
DEBUG - 2019-06-27 20:57:35 --> Total execution time: 0.2919
INFO - 2019-06-27 14:57:38 --> Config Class Initialized
INFO - 2019-06-27 14:57:38 --> Hooks Class Initialized
DEBUG - 2019-06-27 14:57:38 --> UTF-8 Support Enabled
INFO - 2019-06-27 14:57:38 --> Utf8 Class Initialized
INFO - 2019-06-27 14:57:38 --> URI Class Initialized
INFO - 2019-06-27 14:57:38 --> Router Class Initialized
INFO - 2019-06-27 14:57:38 --> Output Class Initialized
INFO - 2019-06-27 14:57:38 --> Security Class Initialized
DEBUG - 2019-06-27 14:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 14:57:38 --> Input Class Initialized
INFO - 2019-06-27 14:57:38 --> Language Class Initialized
INFO - 2019-06-27 14:57:38 --> Language Class Initialized
INFO - 2019-06-27 14:57:38 --> Config Class Initialized
INFO - 2019-06-27 14:57:38 --> Loader Class Initialized
DEBUG - 2019-06-27 14:57:38 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 14:57:38 --> Helper loaded: url_helper
INFO - 2019-06-27 14:57:38 --> Helper loaded: inflector_helper
INFO - 2019-06-27 14:57:38 --> Helper loaded: string_helper
INFO - 2019-06-27 14:57:38 --> Helper loaded: array_helper
INFO - 2019-06-27 14:57:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 14:57:38 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 14:57:38 --> Database Driver Class Initialized
INFO - 2019-06-27 14:57:38 --> Controller Class Initialized
INFO - 2019-06-27 20:57:38 --> Helper loaded: language_helper
INFO - 2019-06-27 20:57:38 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 20:57:38 --> Model Class Initialized
INFO - 2019-06-27 20:57:38 --> Model Class Initialized
INFO - 2019-06-27 20:57:38 --> Model Class Initialized
INFO - 2019-06-27 20:57:38 --> Model Class Initialized
INFO - 2019-06-27 20:57:38 --> Model Class Initialized
INFO - 2019-06-27 20:57:38 --> Final output sent to browser
DEBUG - 2019-06-27 20:57:38 --> Total execution time: 0.3484
INFO - 2019-06-27 14:57:50 --> Config Class Initialized
INFO - 2019-06-27 14:57:50 --> Hooks Class Initialized
DEBUG - 2019-06-27 14:57:50 --> UTF-8 Support Enabled
INFO - 2019-06-27 14:57:50 --> Utf8 Class Initialized
INFO - 2019-06-27 14:57:50 --> URI Class Initialized
INFO - 2019-06-27 14:57:50 --> Router Class Initialized
INFO - 2019-06-27 14:57:50 --> Output Class Initialized
INFO - 2019-06-27 14:57:50 --> Security Class Initialized
DEBUG - 2019-06-27 14:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 14:57:50 --> Input Class Initialized
INFO - 2019-06-27 14:57:50 --> Language Class Initialized
INFO - 2019-06-27 14:57:50 --> Language Class Initialized
INFO - 2019-06-27 14:57:50 --> Config Class Initialized
INFO - 2019-06-27 14:57:50 --> Loader Class Initialized
DEBUG - 2019-06-27 14:57:50 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 14:57:50 --> Helper loaded: url_helper
INFO - 2019-06-27 14:57:50 --> Helper loaded: inflector_helper
INFO - 2019-06-27 14:57:50 --> Helper loaded: string_helper
INFO - 2019-06-27 14:57:50 --> Helper loaded: array_helper
INFO - 2019-06-27 14:57:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 14:57:50 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 14:57:50 --> Database Driver Class Initialized
INFO - 2019-06-27 14:57:50 --> Controller Class Initialized
INFO - 2019-06-27 20:57:50 --> Helper loaded: language_helper
INFO - 2019-06-27 20:57:50 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 20:57:50 --> Model Class Initialized
INFO - 2019-06-27 20:57:50 --> Model Class Initialized
INFO - 2019-06-27 20:57:50 --> Model Class Initialized
INFO - 2019-06-27 20:57:50 --> Model Class Initialized
INFO - 2019-06-27 20:57:50 --> Model Class Initialized
INFO - 2019-06-27 20:57:50 --> Final output sent to browser
DEBUG - 2019-06-27 20:57:50 --> Total execution time: 0.2413
INFO - 2019-06-27 14:58:29 --> Config Class Initialized
INFO - 2019-06-27 14:58:29 --> Hooks Class Initialized
DEBUG - 2019-06-27 14:58:29 --> UTF-8 Support Enabled
INFO - 2019-06-27 14:58:29 --> Utf8 Class Initialized
INFO - 2019-06-27 14:58:29 --> URI Class Initialized
INFO - 2019-06-27 14:58:29 --> Router Class Initialized
INFO - 2019-06-27 14:58:29 --> Output Class Initialized
INFO - 2019-06-27 14:58:29 --> Security Class Initialized
DEBUG - 2019-06-27 14:58:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 14:58:29 --> Input Class Initialized
INFO - 2019-06-27 14:58:29 --> Language Class Initialized
INFO - 2019-06-27 14:58:29 --> Language Class Initialized
INFO - 2019-06-27 14:58:29 --> Config Class Initialized
INFO - 2019-06-27 14:58:29 --> Loader Class Initialized
DEBUG - 2019-06-27 14:58:29 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 14:58:29 --> Helper loaded: url_helper
INFO - 2019-06-27 14:58:29 --> Helper loaded: inflector_helper
INFO - 2019-06-27 14:58:29 --> Helper loaded: string_helper
INFO - 2019-06-27 14:58:29 --> Helper loaded: array_helper
INFO - 2019-06-27 14:58:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 14:58:29 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 14:58:29 --> Database Driver Class Initialized
INFO - 2019-06-27 14:58:29 --> Controller Class Initialized
INFO - 2019-06-27 20:58:29 --> Helper loaded: language_helper
INFO - 2019-06-27 20:58:29 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 20:58:29 --> Model Class Initialized
INFO - 2019-06-27 20:58:29 --> Model Class Initialized
INFO - 2019-06-27 20:58:29 --> Model Class Initialized
INFO - 2019-06-27 20:58:29 --> Model Class Initialized
INFO - 2019-06-27 20:58:29 --> Model Class Initialized
INFO - 2019-06-27 20:58:29 --> Final output sent to browser
DEBUG - 2019-06-27 20:58:29 --> Total execution time: 0.3139
INFO - 2019-06-27 14:58:41 --> Config Class Initialized
INFO - 2019-06-27 14:58:41 --> Hooks Class Initialized
DEBUG - 2019-06-27 14:58:41 --> UTF-8 Support Enabled
INFO - 2019-06-27 14:58:41 --> Utf8 Class Initialized
INFO - 2019-06-27 14:58:41 --> URI Class Initialized
INFO - 2019-06-27 14:58:41 --> Router Class Initialized
INFO - 2019-06-27 14:58:41 --> Output Class Initialized
INFO - 2019-06-27 14:58:41 --> Security Class Initialized
DEBUG - 2019-06-27 14:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 14:58:41 --> Input Class Initialized
INFO - 2019-06-27 14:58:41 --> Language Class Initialized
INFO - 2019-06-27 14:58:41 --> Language Class Initialized
INFO - 2019-06-27 14:58:41 --> Config Class Initialized
INFO - 2019-06-27 14:58:41 --> Loader Class Initialized
DEBUG - 2019-06-27 14:58:41 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 14:58:41 --> Helper loaded: url_helper
INFO - 2019-06-27 14:58:41 --> Helper loaded: inflector_helper
INFO - 2019-06-27 14:58:41 --> Helper loaded: string_helper
INFO - 2019-06-27 14:58:41 --> Helper loaded: array_helper
INFO - 2019-06-27 14:58:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 14:58:41 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 14:58:41 --> Database Driver Class Initialized
INFO - 2019-06-27 14:58:41 --> Controller Class Initialized
INFO - 2019-06-27 20:58:41 --> Helper loaded: language_helper
INFO - 2019-06-27 20:58:41 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 20:58:41 --> Model Class Initialized
INFO - 2019-06-27 20:58:41 --> Model Class Initialized
INFO - 2019-06-27 20:58:41 --> Model Class Initialized
INFO - 2019-06-27 20:58:41 --> Model Class Initialized
INFO - 2019-06-27 20:58:41 --> Model Class Initialized
INFO - 2019-06-27 20:58:41 --> Final output sent to browser
DEBUG - 2019-06-27 20:58:41 --> Total execution time: 0.2470
INFO - 2019-06-27 15:01:17 --> Config Class Initialized
INFO - 2019-06-27 15:01:17 --> Hooks Class Initialized
DEBUG - 2019-06-27 15:01:17 --> UTF-8 Support Enabled
INFO - 2019-06-27 15:01:17 --> Utf8 Class Initialized
INFO - 2019-06-27 15:01:17 --> URI Class Initialized
INFO - 2019-06-27 15:01:17 --> Router Class Initialized
INFO - 2019-06-27 15:01:17 --> Output Class Initialized
INFO - 2019-06-27 15:01:17 --> Security Class Initialized
DEBUG - 2019-06-27 15:01:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 15:01:17 --> Input Class Initialized
INFO - 2019-06-27 15:01:17 --> Language Class Initialized
INFO - 2019-06-27 15:01:17 --> Language Class Initialized
INFO - 2019-06-27 15:01:17 --> Config Class Initialized
INFO - 2019-06-27 15:01:17 --> Loader Class Initialized
DEBUG - 2019-06-27 15:01:17 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 15:01:17 --> Helper loaded: url_helper
INFO - 2019-06-27 15:01:17 --> Helper loaded: inflector_helper
INFO - 2019-06-27 15:01:17 --> Helper loaded: string_helper
INFO - 2019-06-27 15:01:17 --> Helper loaded: array_helper
INFO - 2019-06-27 15:01:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 15:01:17 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 15:01:17 --> Database Driver Class Initialized
INFO - 2019-06-27 15:01:17 --> Controller Class Initialized
INFO - 2019-06-27 21:01:17 --> Helper loaded: language_helper
INFO - 2019-06-27 21:01:17 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 21:01:17 --> Model Class Initialized
INFO - 2019-06-27 21:01:17 --> Model Class Initialized
INFO - 2019-06-27 21:01:17 --> Model Class Initialized
INFO - 2019-06-27 21:01:17 --> Model Class Initialized
INFO - 2019-06-27 21:01:18 --> Model Class Initialized
INFO - 2019-06-27 21:01:18 --> Final output sent to browser
DEBUG - 2019-06-27 21:01:18 --> Total execution time: 0.2576
INFO - 2019-06-27 15:01:41 --> Config Class Initialized
INFO - 2019-06-27 15:01:41 --> Hooks Class Initialized
DEBUG - 2019-06-27 15:01:41 --> UTF-8 Support Enabled
INFO - 2019-06-27 15:01:41 --> Utf8 Class Initialized
INFO - 2019-06-27 15:01:41 --> URI Class Initialized
INFO - 2019-06-27 15:01:41 --> Router Class Initialized
INFO - 2019-06-27 15:01:41 --> Output Class Initialized
INFO - 2019-06-27 15:01:41 --> Security Class Initialized
DEBUG - 2019-06-27 15:01:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 15:01:41 --> Input Class Initialized
INFO - 2019-06-27 15:01:42 --> Language Class Initialized
INFO - 2019-06-27 15:01:42 --> Language Class Initialized
INFO - 2019-06-27 15:01:42 --> Config Class Initialized
INFO - 2019-06-27 15:01:42 --> Loader Class Initialized
DEBUG - 2019-06-27 15:01:42 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 15:01:42 --> Helper loaded: url_helper
INFO - 2019-06-27 15:01:42 --> Helper loaded: inflector_helper
INFO - 2019-06-27 15:01:42 --> Helper loaded: string_helper
INFO - 2019-06-27 15:01:42 --> Helper loaded: array_helper
INFO - 2019-06-27 15:01:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 15:01:42 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 15:01:42 --> Database Driver Class Initialized
INFO - 2019-06-27 15:01:42 --> Controller Class Initialized
INFO - 2019-06-27 21:01:42 --> Helper loaded: language_helper
INFO - 2019-06-27 21:01:42 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 21:01:42 --> Model Class Initialized
INFO - 2019-06-27 21:01:42 --> Model Class Initialized
INFO - 2019-06-27 21:01:42 --> Model Class Initialized
INFO - 2019-06-27 21:01:42 --> Model Class Initialized
INFO - 2019-06-27 21:01:42 --> Model Class Initialized
INFO - 2019-06-27 21:01:42 --> Final output sent to browser
DEBUG - 2019-06-27 21:01:42 --> Total execution time: 0.3383
INFO - 2019-06-27 15:01:55 --> Config Class Initialized
INFO - 2019-06-27 15:01:55 --> Hooks Class Initialized
DEBUG - 2019-06-27 15:01:55 --> UTF-8 Support Enabled
INFO - 2019-06-27 15:01:55 --> Utf8 Class Initialized
INFO - 2019-06-27 15:01:55 --> URI Class Initialized
INFO - 2019-06-27 15:01:55 --> Router Class Initialized
INFO - 2019-06-27 15:01:55 --> Output Class Initialized
INFO - 2019-06-27 15:01:55 --> Security Class Initialized
DEBUG - 2019-06-27 15:01:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 15:01:55 --> Input Class Initialized
INFO - 2019-06-27 15:01:55 --> Language Class Initialized
INFO - 2019-06-27 15:01:55 --> Language Class Initialized
INFO - 2019-06-27 15:01:55 --> Config Class Initialized
INFO - 2019-06-27 15:01:55 --> Loader Class Initialized
DEBUG - 2019-06-27 15:01:55 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 15:01:55 --> Helper loaded: url_helper
INFO - 2019-06-27 15:01:55 --> Helper loaded: inflector_helper
INFO - 2019-06-27 15:01:55 --> Helper loaded: string_helper
INFO - 2019-06-27 15:01:55 --> Helper loaded: array_helper
INFO - 2019-06-27 15:01:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 15:01:55 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 15:01:55 --> Database Driver Class Initialized
INFO - 2019-06-27 15:01:55 --> Controller Class Initialized
INFO - 2019-06-27 21:01:55 --> Helper loaded: language_helper
INFO - 2019-06-27 21:01:55 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 21:01:55 --> Model Class Initialized
INFO - 2019-06-27 21:01:55 --> Model Class Initialized
INFO - 2019-06-27 21:01:55 --> Model Class Initialized
INFO - 2019-06-27 21:01:55 --> Model Class Initialized
INFO - 2019-06-27 21:01:55 --> Model Class Initialized
INFO - 2019-06-27 21:01:55 --> Final output sent to browser
DEBUG - 2019-06-27 21:01:55 --> Total execution time: 0.2567
INFO - 2019-06-27 15:01:57 --> Config Class Initialized
INFO - 2019-06-27 15:01:57 --> Hooks Class Initialized
DEBUG - 2019-06-27 15:01:57 --> UTF-8 Support Enabled
INFO - 2019-06-27 15:01:57 --> Utf8 Class Initialized
INFO - 2019-06-27 15:01:57 --> URI Class Initialized
INFO - 2019-06-27 15:01:57 --> Router Class Initialized
INFO - 2019-06-27 15:01:57 --> Output Class Initialized
INFO - 2019-06-27 15:01:57 --> Security Class Initialized
DEBUG - 2019-06-27 15:01:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 15:01:57 --> Input Class Initialized
INFO - 2019-06-27 15:01:57 --> Language Class Initialized
INFO - 2019-06-27 15:01:57 --> Language Class Initialized
INFO - 2019-06-27 15:01:57 --> Config Class Initialized
INFO - 2019-06-27 15:01:57 --> Loader Class Initialized
DEBUG - 2019-06-27 15:01:57 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 15:01:57 --> Helper loaded: url_helper
INFO - 2019-06-27 15:01:57 --> Helper loaded: inflector_helper
INFO - 2019-06-27 15:01:57 --> Helper loaded: string_helper
INFO - 2019-06-27 15:01:57 --> Helper loaded: array_helper
INFO - 2019-06-27 15:01:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 15:01:57 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 15:01:57 --> Database Driver Class Initialized
INFO - 2019-06-27 15:01:57 --> Controller Class Initialized
INFO - 2019-06-27 21:01:57 --> Helper loaded: language_helper
INFO - 2019-06-27 21:01:57 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 21:01:57 --> Model Class Initialized
INFO - 2019-06-27 21:01:57 --> Model Class Initialized
INFO - 2019-06-27 21:01:57 --> Model Class Initialized
INFO - 2019-06-27 21:01:57 --> Model Class Initialized
INFO - 2019-06-27 21:01:57 --> Model Class Initialized
INFO - 2019-06-27 21:01:57 --> Final output sent to browser
DEBUG - 2019-06-27 21:01:57 --> Total execution time: 0.2580
INFO - 2019-06-27 15:02:00 --> Config Class Initialized
INFO - 2019-06-27 15:02:00 --> Hooks Class Initialized
DEBUG - 2019-06-27 15:02:00 --> UTF-8 Support Enabled
INFO - 2019-06-27 15:02:00 --> Utf8 Class Initialized
INFO - 2019-06-27 15:02:00 --> URI Class Initialized
INFO - 2019-06-27 15:02:00 --> Router Class Initialized
INFO - 2019-06-27 15:02:00 --> Output Class Initialized
INFO - 2019-06-27 15:02:00 --> Security Class Initialized
DEBUG - 2019-06-27 15:02:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 15:02:00 --> Input Class Initialized
INFO - 2019-06-27 15:02:00 --> Language Class Initialized
INFO - 2019-06-27 15:02:00 --> Language Class Initialized
INFO - 2019-06-27 15:02:00 --> Config Class Initialized
INFO - 2019-06-27 15:02:00 --> Loader Class Initialized
DEBUG - 2019-06-27 15:02:00 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 15:02:00 --> Helper loaded: url_helper
INFO - 2019-06-27 15:02:00 --> Helper loaded: inflector_helper
INFO - 2019-06-27 15:02:00 --> Helper loaded: string_helper
INFO - 2019-06-27 15:02:00 --> Helper loaded: array_helper
INFO - 2019-06-27 15:02:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 15:02:00 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 15:02:00 --> Database Driver Class Initialized
INFO - 2019-06-27 15:02:00 --> Controller Class Initialized
INFO - 2019-06-27 21:02:00 --> Helper loaded: language_helper
INFO - 2019-06-27 21:02:00 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 21:02:00 --> Model Class Initialized
INFO - 2019-06-27 21:02:00 --> Model Class Initialized
INFO - 2019-06-27 21:02:00 --> Model Class Initialized
INFO - 2019-06-27 21:02:00 --> Model Class Initialized
INFO - 2019-06-27 21:02:00 --> Model Class Initialized
INFO - 2019-06-27 21:02:00 --> Final output sent to browser
DEBUG - 2019-06-27 21:02:00 --> Total execution time: 0.2376
INFO - 2019-06-27 15:02:05 --> Config Class Initialized
INFO - 2019-06-27 15:02:05 --> Hooks Class Initialized
DEBUG - 2019-06-27 15:02:05 --> UTF-8 Support Enabled
INFO - 2019-06-27 15:02:05 --> Utf8 Class Initialized
INFO - 2019-06-27 15:02:05 --> URI Class Initialized
INFO - 2019-06-27 15:02:05 --> Router Class Initialized
INFO - 2019-06-27 15:02:05 --> Output Class Initialized
INFO - 2019-06-27 15:02:05 --> Security Class Initialized
DEBUG - 2019-06-27 15:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 15:02:05 --> Input Class Initialized
INFO - 2019-06-27 15:02:05 --> Language Class Initialized
INFO - 2019-06-27 15:02:05 --> Language Class Initialized
INFO - 2019-06-27 15:02:05 --> Config Class Initialized
INFO - 2019-06-27 15:02:05 --> Loader Class Initialized
DEBUG - 2019-06-27 15:02:05 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 15:02:05 --> Helper loaded: url_helper
INFO - 2019-06-27 15:02:05 --> Helper loaded: inflector_helper
INFO - 2019-06-27 15:02:05 --> Helper loaded: string_helper
INFO - 2019-06-27 15:02:05 --> Helper loaded: array_helper
INFO - 2019-06-27 15:02:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 15:02:05 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 15:02:05 --> Database Driver Class Initialized
INFO - 2019-06-27 15:02:05 --> Controller Class Initialized
INFO - 2019-06-27 21:02:05 --> Helper loaded: language_helper
INFO - 2019-06-27 21:02:05 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 21:02:05 --> Model Class Initialized
INFO - 2019-06-27 21:02:05 --> Model Class Initialized
INFO - 2019-06-27 21:02:05 --> Model Class Initialized
INFO - 2019-06-27 21:02:05 --> Model Class Initialized
INFO - 2019-06-27 21:02:05 --> Helper loaded: form_helper
INFO - 2019-06-27 21:02:06 --> Form Validation Class Initialized
DEBUG - 2019-06-27 21:02:06 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-27 21:02:06 --> Model Class Initialized
INFO - 2019-06-27 21:02:06 --> Model Class Initialized
INFO - 2019-06-27 21:02:06 --> Final output sent to browser
DEBUG - 2019-06-27 21:02:06 --> Total execution time: 0.3166
INFO - 2019-06-27 15:02:08 --> Config Class Initialized
INFO - 2019-06-27 15:02:08 --> Hooks Class Initialized
DEBUG - 2019-06-27 15:02:08 --> UTF-8 Support Enabled
INFO - 2019-06-27 15:02:08 --> Utf8 Class Initialized
INFO - 2019-06-27 15:02:08 --> URI Class Initialized
INFO - 2019-06-27 15:02:08 --> Router Class Initialized
INFO - 2019-06-27 15:02:08 --> Output Class Initialized
INFO - 2019-06-27 15:02:08 --> Security Class Initialized
DEBUG - 2019-06-27 15:02:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 15:02:08 --> Input Class Initialized
INFO - 2019-06-27 15:02:08 --> Language Class Initialized
INFO - 2019-06-27 15:02:08 --> Language Class Initialized
INFO - 2019-06-27 15:02:08 --> Config Class Initialized
INFO - 2019-06-27 15:02:08 --> Loader Class Initialized
DEBUG - 2019-06-27 15:02:08 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 15:02:08 --> Helper loaded: url_helper
INFO - 2019-06-27 15:02:08 --> Helper loaded: inflector_helper
INFO - 2019-06-27 15:02:08 --> Helper loaded: string_helper
INFO - 2019-06-27 15:02:08 --> Helper loaded: array_helper
INFO - 2019-06-27 15:02:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 15:02:08 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 15:02:08 --> Database Driver Class Initialized
INFO - 2019-06-27 15:02:08 --> Controller Class Initialized
INFO - 2019-06-27 21:02:08 --> Helper loaded: language_helper
INFO - 2019-06-27 21:02:08 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 21:02:08 --> Model Class Initialized
INFO - 2019-06-27 21:02:08 --> Model Class Initialized
INFO - 2019-06-27 21:02:08 --> Model Class Initialized
INFO - 2019-06-27 21:02:08 --> Model Class Initialized
INFO - 2019-06-27 21:02:08 --> Helper loaded: form_helper
INFO - 2019-06-27 21:02:08 --> Form Validation Class Initialized
DEBUG - 2019-06-27 21:02:08 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-27 21:02:08 --> Model Class Initialized
INFO - 2019-06-27 21:02:08 --> Model Class Initialized
INFO - 2019-06-27 21:02:08 --> Final output sent to browser
DEBUG - 2019-06-27 21:02:08 --> Total execution time: 0.2856
INFO - 2019-06-27 15:02:11 --> Config Class Initialized
INFO - 2019-06-27 15:02:11 --> Hooks Class Initialized
DEBUG - 2019-06-27 15:02:11 --> UTF-8 Support Enabled
INFO - 2019-06-27 15:02:11 --> Utf8 Class Initialized
INFO - 2019-06-27 15:02:11 --> URI Class Initialized
INFO - 2019-06-27 15:02:11 --> Router Class Initialized
INFO - 2019-06-27 15:02:11 --> Output Class Initialized
INFO - 2019-06-27 15:02:11 --> Security Class Initialized
DEBUG - 2019-06-27 15:02:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 15:02:11 --> Input Class Initialized
INFO - 2019-06-27 15:02:11 --> Language Class Initialized
INFO - 2019-06-27 15:02:11 --> Language Class Initialized
INFO - 2019-06-27 15:02:11 --> Config Class Initialized
INFO - 2019-06-27 15:02:11 --> Loader Class Initialized
DEBUG - 2019-06-27 15:02:11 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 15:02:11 --> Helper loaded: url_helper
INFO - 2019-06-27 15:02:11 --> Helper loaded: inflector_helper
INFO - 2019-06-27 15:02:11 --> Helper loaded: string_helper
INFO - 2019-06-27 15:02:11 --> Helper loaded: array_helper
INFO - 2019-06-27 15:02:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 15:02:11 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 15:02:11 --> Database Driver Class Initialized
INFO - 2019-06-27 15:02:11 --> Controller Class Initialized
INFO - 2019-06-27 21:02:11 --> Helper loaded: language_helper
INFO - 2019-06-27 21:02:11 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 21:02:11 --> Model Class Initialized
INFO - 2019-06-27 21:02:11 --> Model Class Initialized
INFO - 2019-06-27 21:02:11 --> Model Class Initialized
INFO - 2019-06-27 21:02:12 --> Model Class Initialized
INFO - 2019-06-27 21:02:12 --> Helper loaded: form_helper
INFO - 2019-06-27 21:02:12 --> Form Validation Class Initialized
DEBUG - 2019-06-27 21:02:12 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-27 21:02:12 --> Model Class Initialized
INFO - 2019-06-27 21:02:12 --> Model Class Initialized
INFO - 2019-06-27 21:02:12 --> Final output sent to browser
DEBUG - 2019-06-27 21:02:12 --> Total execution time: 0.3075
INFO - 2019-06-27 15:02:13 --> Config Class Initialized
INFO - 2019-06-27 15:02:13 --> Hooks Class Initialized
DEBUG - 2019-06-27 15:02:13 --> UTF-8 Support Enabled
INFO - 2019-06-27 15:02:13 --> Utf8 Class Initialized
INFO - 2019-06-27 15:02:13 --> URI Class Initialized
INFO - 2019-06-27 15:02:13 --> Router Class Initialized
INFO - 2019-06-27 15:02:13 --> Output Class Initialized
INFO - 2019-06-27 15:02:13 --> Security Class Initialized
DEBUG - 2019-06-27 15:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 15:02:13 --> Input Class Initialized
INFO - 2019-06-27 15:02:13 --> Language Class Initialized
INFO - 2019-06-27 15:02:13 --> Language Class Initialized
INFO - 2019-06-27 15:02:13 --> Config Class Initialized
INFO - 2019-06-27 15:02:13 --> Loader Class Initialized
DEBUG - 2019-06-27 15:02:13 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 15:02:13 --> Helper loaded: url_helper
INFO - 2019-06-27 15:02:13 --> Helper loaded: inflector_helper
INFO - 2019-06-27 15:02:13 --> Helper loaded: string_helper
INFO - 2019-06-27 15:02:13 --> Helper loaded: array_helper
INFO - 2019-06-27 15:02:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 15:02:13 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 15:02:13 --> Database Driver Class Initialized
INFO - 2019-06-27 15:02:13 --> Controller Class Initialized
INFO - 2019-06-27 21:02:13 --> Helper loaded: language_helper
INFO - 2019-06-27 21:02:13 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 21:02:13 --> Model Class Initialized
INFO - 2019-06-27 21:02:13 --> Model Class Initialized
INFO - 2019-06-27 21:02:13 --> Model Class Initialized
INFO - 2019-06-27 21:02:13 --> Model Class Initialized
INFO - 2019-06-27 21:02:13 --> Helper loaded: form_helper
INFO - 2019-06-27 21:02:13 --> Form Validation Class Initialized
DEBUG - 2019-06-27 21:02:13 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-27 21:02:13 --> Model Class Initialized
INFO - 2019-06-27 21:02:13 --> Model Class Initialized
INFO - 2019-06-27 21:02:13 --> Final output sent to browser
DEBUG - 2019-06-27 21:02:13 --> Total execution time: 0.3268
INFO - 2019-06-27 15:04:44 --> Config Class Initialized
INFO - 2019-06-27 15:04:44 --> Hooks Class Initialized
DEBUG - 2019-06-27 15:04:44 --> UTF-8 Support Enabled
INFO - 2019-06-27 15:04:44 --> Utf8 Class Initialized
INFO - 2019-06-27 15:04:44 --> URI Class Initialized
INFO - 2019-06-27 15:04:44 --> Router Class Initialized
INFO - 2019-06-27 15:04:44 --> Output Class Initialized
INFO - 2019-06-27 15:04:44 --> Security Class Initialized
DEBUG - 2019-06-27 15:04:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 15:04:44 --> Input Class Initialized
INFO - 2019-06-27 15:04:44 --> Language Class Initialized
INFO - 2019-06-27 15:04:44 --> Language Class Initialized
INFO - 2019-06-27 15:04:44 --> Config Class Initialized
INFO - 2019-06-27 15:04:44 --> Loader Class Initialized
DEBUG - 2019-06-27 15:04:44 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 15:04:44 --> Helper loaded: url_helper
INFO - 2019-06-27 15:04:44 --> Helper loaded: inflector_helper
INFO - 2019-06-27 15:04:45 --> Helper loaded: string_helper
INFO - 2019-06-27 15:04:45 --> Helper loaded: array_helper
INFO - 2019-06-27 15:04:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 15:04:45 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 15:04:45 --> Database Driver Class Initialized
INFO - 2019-06-27 15:04:45 --> Controller Class Initialized
INFO - 2019-06-27 21:04:45 --> Helper loaded: language_helper
INFO - 2019-06-27 21:04:45 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 21:04:45 --> Model Class Initialized
INFO - 2019-06-27 21:04:45 --> Model Class Initialized
INFO - 2019-06-27 21:04:45 --> Model Class Initialized
INFO - 2019-06-27 21:04:45 --> Model Class Initialized
INFO - 2019-06-27 21:04:45 --> Model Class Initialized
INFO - 2019-06-27 21:04:45 --> Final output sent to browser
DEBUG - 2019-06-27 21:04:45 --> Total execution time: 0.2600
INFO - 2019-06-27 15:04:53 --> Config Class Initialized
INFO - 2019-06-27 15:04:53 --> Hooks Class Initialized
DEBUG - 2019-06-27 15:04:53 --> UTF-8 Support Enabled
INFO - 2019-06-27 15:04:53 --> Utf8 Class Initialized
INFO - 2019-06-27 15:04:53 --> URI Class Initialized
INFO - 2019-06-27 15:04:53 --> Router Class Initialized
INFO - 2019-06-27 15:04:53 --> Output Class Initialized
INFO - 2019-06-27 15:04:53 --> Security Class Initialized
DEBUG - 2019-06-27 15:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 15:04:53 --> Input Class Initialized
INFO - 2019-06-27 15:04:53 --> Language Class Initialized
INFO - 2019-06-27 15:04:53 --> Language Class Initialized
INFO - 2019-06-27 15:04:53 --> Config Class Initialized
INFO - 2019-06-27 15:04:53 --> Loader Class Initialized
DEBUG - 2019-06-27 15:04:53 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 15:04:53 --> Helper loaded: url_helper
INFO - 2019-06-27 15:04:53 --> Helper loaded: inflector_helper
INFO - 2019-06-27 15:04:53 --> Helper loaded: string_helper
INFO - 2019-06-27 15:04:53 --> Helper loaded: array_helper
INFO - 2019-06-27 15:04:53 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 15:04:53 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 15:04:53 --> Database Driver Class Initialized
INFO - 2019-06-27 15:04:53 --> Controller Class Initialized
INFO - 2019-06-27 21:04:53 --> Helper loaded: language_helper
INFO - 2019-06-27 21:04:53 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 21:04:53 --> Model Class Initialized
INFO - 2019-06-27 21:04:53 --> Model Class Initialized
INFO - 2019-06-27 21:04:53 --> Model Class Initialized
INFO - 2019-06-27 21:04:53 --> Model Class Initialized
INFO - 2019-06-27 21:04:53 --> Helper loaded: form_helper
INFO - 2019-06-27 21:04:53 --> Form Validation Class Initialized
DEBUG - 2019-06-27 21:04:53 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-27 21:04:53 --> Model Class Initialized
INFO - 2019-06-27 21:04:53 --> Model Class Initialized
INFO - 2019-06-27 21:04:53 --> Final output sent to browser
DEBUG - 2019-06-27 21:04:53 --> Total execution time: 0.2762
INFO - 2019-06-27 15:05:09 --> Config Class Initialized
INFO - 2019-06-27 15:05:09 --> Hooks Class Initialized
DEBUG - 2019-06-27 15:05:09 --> UTF-8 Support Enabled
INFO - 2019-06-27 15:05:09 --> Utf8 Class Initialized
INFO - 2019-06-27 15:05:09 --> URI Class Initialized
INFO - 2019-06-27 15:05:09 --> Router Class Initialized
INFO - 2019-06-27 15:05:09 --> Output Class Initialized
INFO - 2019-06-27 15:05:09 --> Security Class Initialized
DEBUG - 2019-06-27 15:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 15:05:09 --> Input Class Initialized
INFO - 2019-06-27 15:05:09 --> Language Class Initialized
INFO - 2019-06-27 15:05:09 --> Language Class Initialized
INFO - 2019-06-27 15:05:09 --> Config Class Initialized
INFO - 2019-06-27 15:05:09 --> Loader Class Initialized
DEBUG - 2019-06-27 15:05:09 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 15:05:09 --> Helper loaded: url_helper
INFO - 2019-06-27 15:05:09 --> Helper loaded: inflector_helper
INFO - 2019-06-27 15:05:09 --> Helper loaded: string_helper
INFO - 2019-06-27 15:05:09 --> Helper loaded: array_helper
INFO - 2019-06-27 15:05:09 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 15:05:09 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 15:05:09 --> Database Driver Class Initialized
INFO - 2019-06-27 15:05:09 --> Controller Class Initialized
INFO - 2019-06-27 21:05:09 --> Helper loaded: language_helper
INFO - 2019-06-27 21:05:09 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 21:05:09 --> Model Class Initialized
INFO - 2019-06-27 21:05:09 --> Model Class Initialized
INFO - 2019-06-27 21:05:09 --> Model Class Initialized
INFO - 2019-06-27 21:05:09 --> Model Class Initialized
INFO - 2019-06-27 21:05:09 --> Model Class Initialized
INFO - 2019-06-27 21:05:09 --> Final output sent to browser
DEBUG - 2019-06-27 21:05:09 --> Total execution time: 0.2988
INFO - 2019-06-27 15:05:10 --> Config Class Initialized
INFO - 2019-06-27 15:05:10 --> Hooks Class Initialized
DEBUG - 2019-06-27 15:05:10 --> UTF-8 Support Enabled
INFO - 2019-06-27 15:05:10 --> Utf8 Class Initialized
INFO - 2019-06-27 15:05:10 --> URI Class Initialized
INFO - 2019-06-27 15:05:10 --> Router Class Initialized
INFO - 2019-06-27 15:05:10 --> Output Class Initialized
INFO - 2019-06-27 15:05:10 --> Security Class Initialized
DEBUG - 2019-06-27 15:05:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 15:05:10 --> Input Class Initialized
INFO - 2019-06-27 15:05:10 --> Language Class Initialized
INFO - 2019-06-27 15:05:10 --> Language Class Initialized
INFO - 2019-06-27 15:05:10 --> Config Class Initialized
INFO - 2019-06-27 15:05:10 --> Loader Class Initialized
DEBUG - 2019-06-27 15:05:10 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 15:05:10 --> Helper loaded: url_helper
INFO - 2019-06-27 15:05:10 --> Helper loaded: inflector_helper
INFO - 2019-06-27 15:05:10 --> Helper loaded: string_helper
INFO - 2019-06-27 15:05:10 --> Helper loaded: array_helper
INFO - 2019-06-27 15:05:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 15:05:10 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 15:05:10 --> Database Driver Class Initialized
INFO - 2019-06-27 15:05:10 --> Controller Class Initialized
INFO - 2019-06-27 21:05:10 --> Helper loaded: language_helper
INFO - 2019-06-27 21:05:10 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 21:05:10 --> Model Class Initialized
INFO - 2019-06-27 21:05:10 --> Model Class Initialized
INFO - 2019-06-27 21:05:10 --> Model Class Initialized
INFO - 2019-06-27 21:05:10 --> Model Class Initialized
INFO - 2019-06-27 21:05:10 --> Helper loaded: form_helper
INFO - 2019-06-27 21:05:10 --> Form Validation Class Initialized
DEBUG - 2019-06-27 21:05:10 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-27 21:05:10 --> Model Class Initialized
INFO - 2019-06-27 21:05:10 --> Model Class Initialized
INFO - 2019-06-27 21:05:10 --> Final output sent to browser
DEBUG - 2019-06-27 21:05:10 --> Total execution time: 0.2997
INFO - 2019-06-27 15:05:11 --> Config Class Initialized
INFO - 2019-06-27 15:05:11 --> Hooks Class Initialized
DEBUG - 2019-06-27 15:05:11 --> UTF-8 Support Enabled
INFO - 2019-06-27 15:05:11 --> Utf8 Class Initialized
INFO - 2019-06-27 15:05:11 --> URI Class Initialized
INFO - 2019-06-27 15:05:11 --> Router Class Initialized
INFO - 2019-06-27 15:05:11 --> Output Class Initialized
INFO - 2019-06-27 15:05:11 --> Security Class Initialized
DEBUG - 2019-06-27 15:05:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 15:05:11 --> Input Class Initialized
INFO - 2019-06-27 15:05:11 --> Language Class Initialized
INFO - 2019-06-27 15:05:11 --> Language Class Initialized
INFO - 2019-06-27 15:05:11 --> Config Class Initialized
INFO - 2019-06-27 15:05:11 --> Loader Class Initialized
DEBUG - 2019-06-27 15:05:11 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 15:05:11 --> Helper loaded: url_helper
INFO - 2019-06-27 15:05:11 --> Helper loaded: inflector_helper
INFO - 2019-06-27 15:05:11 --> Helper loaded: string_helper
INFO - 2019-06-27 15:05:11 --> Helper loaded: array_helper
INFO - 2019-06-27 15:05:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 15:05:11 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 15:05:11 --> Database Driver Class Initialized
INFO - 2019-06-27 15:05:11 --> Controller Class Initialized
INFO - 2019-06-27 21:05:11 --> Helper loaded: language_helper
INFO - 2019-06-27 21:05:11 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 21:05:11 --> Model Class Initialized
INFO - 2019-06-27 21:05:11 --> Model Class Initialized
INFO - 2019-06-27 21:05:11 --> Model Class Initialized
INFO - 2019-06-27 21:05:11 --> Model Class Initialized
INFO - 2019-06-27 21:05:11 --> Helper loaded: form_helper
INFO - 2019-06-27 21:05:11 --> Form Validation Class Initialized
DEBUG - 2019-06-27 21:05:11 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-27 21:05:11 --> Model Class Initialized
INFO - 2019-06-27 21:05:11 --> Model Class Initialized
INFO - 2019-06-27 21:05:11 --> Final output sent to browser
DEBUG - 2019-06-27 21:05:11 --> Total execution time: 0.2670
INFO - 2019-06-27 15:05:29 --> Config Class Initialized
INFO - 2019-06-27 15:05:29 --> Hooks Class Initialized
DEBUG - 2019-06-27 15:05:29 --> UTF-8 Support Enabled
INFO - 2019-06-27 15:05:29 --> Utf8 Class Initialized
INFO - 2019-06-27 15:05:29 --> URI Class Initialized
INFO - 2019-06-27 15:05:29 --> Router Class Initialized
INFO - 2019-06-27 15:05:29 --> Output Class Initialized
INFO - 2019-06-27 15:05:29 --> Security Class Initialized
DEBUG - 2019-06-27 15:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 15:05:29 --> Input Class Initialized
INFO - 2019-06-27 15:05:29 --> Language Class Initialized
INFO - 2019-06-27 15:05:29 --> Language Class Initialized
INFO - 2019-06-27 15:05:29 --> Config Class Initialized
INFO - 2019-06-27 15:05:29 --> Loader Class Initialized
DEBUG - 2019-06-27 15:05:29 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 15:05:29 --> Helper loaded: url_helper
INFO - 2019-06-27 15:05:29 --> Helper loaded: inflector_helper
INFO - 2019-06-27 15:05:29 --> Helper loaded: string_helper
INFO - 2019-06-27 15:05:29 --> Helper loaded: array_helper
INFO - 2019-06-27 15:05:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 15:05:29 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 15:05:29 --> Database Driver Class Initialized
INFO - 2019-06-27 15:05:29 --> Controller Class Initialized
INFO - 2019-06-27 21:05:29 --> Helper loaded: language_helper
INFO - 2019-06-27 21:05:29 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 21:05:29 --> Model Class Initialized
INFO - 2019-06-27 21:05:30 --> Model Class Initialized
INFO - 2019-06-27 21:05:30 --> Model Class Initialized
INFO - 2019-06-27 21:05:30 --> Model Class Initialized
INFO - 2019-06-27 21:05:30 --> Helper loaded: form_helper
INFO - 2019-06-27 21:05:30 --> Form Validation Class Initialized
DEBUG - 2019-06-27 21:05:30 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-27 21:05:30 --> Model Class Initialized
INFO - 2019-06-27 21:05:30 --> Model Class Initialized
INFO - 2019-06-27 21:05:30 --> Final output sent to browser
DEBUG - 2019-06-27 21:05:30 --> Total execution time: 0.3071
INFO - 2019-06-27 15:05:32 --> Config Class Initialized
INFO - 2019-06-27 15:05:32 --> Hooks Class Initialized
DEBUG - 2019-06-27 15:05:32 --> UTF-8 Support Enabled
INFO - 2019-06-27 15:05:32 --> Utf8 Class Initialized
INFO - 2019-06-27 15:05:32 --> URI Class Initialized
INFO - 2019-06-27 15:05:32 --> Router Class Initialized
INFO - 2019-06-27 15:05:32 --> Output Class Initialized
INFO - 2019-06-27 15:05:32 --> Security Class Initialized
DEBUG - 2019-06-27 15:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 15:05:33 --> Input Class Initialized
INFO - 2019-06-27 15:05:33 --> Language Class Initialized
INFO - 2019-06-27 15:05:33 --> Language Class Initialized
INFO - 2019-06-27 15:05:33 --> Config Class Initialized
INFO - 2019-06-27 15:05:33 --> Loader Class Initialized
DEBUG - 2019-06-27 15:05:33 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 15:05:33 --> Helper loaded: url_helper
INFO - 2019-06-27 15:05:33 --> Helper loaded: inflector_helper
INFO - 2019-06-27 15:05:33 --> Helper loaded: string_helper
INFO - 2019-06-27 15:05:33 --> Helper loaded: array_helper
INFO - 2019-06-27 15:05:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 15:05:33 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 15:05:33 --> Database Driver Class Initialized
INFO - 2019-06-27 15:05:33 --> Controller Class Initialized
INFO - 2019-06-27 21:05:33 --> Helper loaded: language_helper
INFO - 2019-06-27 21:05:33 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 21:05:33 --> Model Class Initialized
INFO - 2019-06-27 21:05:33 --> Model Class Initialized
INFO - 2019-06-27 21:05:33 --> Model Class Initialized
INFO - 2019-06-27 21:05:33 --> Model Class Initialized
INFO - 2019-06-27 21:05:33 --> Helper loaded: form_helper
INFO - 2019-06-27 21:05:33 --> Form Validation Class Initialized
DEBUG - 2019-06-27 21:05:33 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-27 21:05:33 --> Model Class Initialized
INFO - 2019-06-27 21:05:33 --> Model Class Initialized
INFO - 2019-06-27 21:05:33 --> Final output sent to browser
DEBUG - 2019-06-27 21:05:33 --> Total execution time: 0.3396
INFO - 2019-06-27 15:18:42 --> Config Class Initialized
INFO - 2019-06-27 15:18:42 --> Hooks Class Initialized
DEBUG - 2019-06-27 15:18:42 --> UTF-8 Support Enabled
INFO - 2019-06-27 15:18:42 --> Utf8 Class Initialized
INFO - 2019-06-27 15:18:42 --> URI Class Initialized
INFO - 2019-06-27 15:18:42 --> Router Class Initialized
INFO - 2019-06-27 15:18:42 --> Output Class Initialized
INFO - 2019-06-27 15:18:42 --> Security Class Initialized
DEBUG - 2019-06-27 15:18:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 15:18:42 --> Input Class Initialized
INFO - 2019-06-27 15:18:42 --> Language Class Initialized
INFO - 2019-06-27 15:18:42 --> Language Class Initialized
INFO - 2019-06-27 15:18:42 --> Config Class Initialized
INFO - 2019-06-27 15:18:42 --> Loader Class Initialized
DEBUG - 2019-06-27 15:18:42 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 15:18:42 --> Helper loaded: url_helper
INFO - 2019-06-27 15:18:42 --> Helper loaded: inflector_helper
INFO - 2019-06-27 15:18:42 --> Helper loaded: string_helper
INFO - 2019-06-27 15:18:42 --> Helper loaded: array_helper
INFO - 2019-06-27 15:18:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 15:18:42 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 15:18:42 --> Database Driver Class Initialized
INFO - 2019-06-27 15:18:42 --> Controller Class Initialized
INFO - 2019-06-27 21:18:42 --> Helper loaded: language_helper
INFO - 2019-06-27 21:18:42 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 21:18:42 --> Model Class Initialized
INFO - 2019-06-27 21:18:42 --> Model Class Initialized
INFO - 2019-06-27 21:18:42 --> Model Class Initialized
INFO - 2019-06-27 21:18:42 --> Model Class Initialized
INFO - 2019-06-27 21:18:42 --> Model Class Initialized
INFO - 2019-06-27 21:18:42 --> Final output sent to browser
DEBUG - 2019-06-27 21:18:42 --> Total execution time: 0.2608
INFO - 2019-06-27 15:19:35 --> Config Class Initialized
INFO - 2019-06-27 15:19:35 --> Hooks Class Initialized
DEBUG - 2019-06-27 15:19:35 --> UTF-8 Support Enabled
INFO - 2019-06-27 15:19:35 --> Utf8 Class Initialized
INFO - 2019-06-27 15:19:35 --> URI Class Initialized
INFO - 2019-06-27 15:19:35 --> Router Class Initialized
INFO - 2019-06-27 15:19:35 --> Output Class Initialized
INFO - 2019-06-27 15:19:35 --> Security Class Initialized
DEBUG - 2019-06-27 15:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 15:19:35 --> Input Class Initialized
INFO - 2019-06-27 15:19:35 --> Language Class Initialized
INFO - 2019-06-27 15:19:35 --> Language Class Initialized
INFO - 2019-06-27 15:19:35 --> Config Class Initialized
INFO - 2019-06-27 15:19:35 --> Loader Class Initialized
DEBUG - 2019-06-27 15:19:35 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 15:19:35 --> Helper loaded: url_helper
INFO - 2019-06-27 15:19:35 --> Helper loaded: inflector_helper
INFO - 2019-06-27 15:19:35 --> Helper loaded: string_helper
INFO - 2019-06-27 15:19:35 --> Helper loaded: array_helper
INFO - 2019-06-27 15:19:35 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 15:19:35 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 15:19:35 --> Database Driver Class Initialized
INFO - 2019-06-27 15:19:35 --> Controller Class Initialized
INFO - 2019-06-27 21:19:35 --> Helper loaded: language_helper
INFO - 2019-06-27 21:19:35 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 21:19:35 --> Model Class Initialized
INFO - 2019-06-27 21:19:35 --> Model Class Initialized
INFO - 2019-06-27 21:19:35 --> Model Class Initialized
INFO - 2019-06-27 21:19:35 --> Model Class Initialized
INFO - 2019-06-27 21:19:35 --> Final output sent to browser
DEBUG - 2019-06-27 21:19:35 --> Total execution time: 0.3564
INFO - 2019-06-27 15:19:35 --> Config Class Initialized
INFO - 2019-06-27 15:19:35 --> Hooks Class Initialized
DEBUG - 2019-06-27 15:19:35 --> UTF-8 Support Enabled
INFO - 2019-06-27 15:19:35 --> Utf8 Class Initialized
INFO - 2019-06-27 15:19:35 --> URI Class Initialized
INFO - 2019-06-27 15:19:35 --> Router Class Initialized
INFO - 2019-06-27 15:19:35 --> Output Class Initialized
INFO - 2019-06-27 15:19:35 --> Security Class Initialized
DEBUG - 2019-06-27 15:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 15:19:35 --> Input Class Initialized
INFO - 2019-06-27 15:19:35 --> Language Class Initialized
INFO - 2019-06-27 15:19:35 --> Language Class Initialized
INFO - 2019-06-27 15:19:35 --> Config Class Initialized
INFO - 2019-06-27 15:19:35 --> Loader Class Initialized
DEBUG - 2019-06-27 15:19:35 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 15:19:35 --> Helper loaded: url_helper
INFO - 2019-06-27 15:19:35 --> Helper loaded: inflector_helper
INFO - 2019-06-27 15:19:35 --> Helper loaded: string_helper
INFO - 2019-06-27 15:19:35 --> Helper loaded: array_helper
INFO - 2019-06-27 15:19:35 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 15:19:35 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 15:19:35 --> Database Driver Class Initialized
INFO - 2019-06-27 15:19:35 --> Controller Class Initialized
INFO - 2019-06-27 21:19:35 --> Helper loaded: language_helper
INFO - 2019-06-27 21:19:35 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 21:19:35 --> Model Class Initialized
INFO - 2019-06-27 21:19:35 --> Model Class Initialized
INFO - 2019-06-27 21:19:35 --> Model Class Initialized
INFO - 2019-06-27 21:19:35 --> Model Class Initialized
INFO - 2019-06-27 21:19:35 --> Model Class Initialized
INFO - 2019-06-27 21:19:35 --> Final output sent to browser
DEBUG - 2019-06-27 21:19:35 --> Total execution time: 0.2937
INFO - 2019-06-27 15:19:44 --> Config Class Initialized
INFO - 2019-06-27 15:19:44 --> Hooks Class Initialized
DEBUG - 2019-06-27 15:19:44 --> UTF-8 Support Enabled
INFO - 2019-06-27 15:19:44 --> Utf8 Class Initialized
INFO - 2019-06-27 15:19:44 --> URI Class Initialized
INFO - 2019-06-27 15:19:44 --> Router Class Initialized
INFO - 2019-06-27 15:19:44 --> Output Class Initialized
INFO - 2019-06-27 15:19:44 --> Security Class Initialized
DEBUG - 2019-06-27 15:19:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 15:19:44 --> Input Class Initialized
INFO - 2019-06-27 15:19:44 --> Language Class Initialized
INFO - 2019-06-27 15:19:44 --> Language Class Initialized
INFO - 2019-06-27 15:19:44 --> Config Class Initialized
INFO - 2019-06-27 15:19:44 --> Loader Class Initialized
DEBUG - 2019-06-27 15:19:44 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 15:19:45 --> Helper loaded: url_helper
INFO - 2019-06-27 15:19:45 --> Helper loaded: inflector_helper
INFO - 2019-06-27 15:19:45 --> Helper loaded: string_helper
INFO - 2019-06-27 15:19:45 --> Helper loaded: array_helper
INFO - 2019-06-27 15:19:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 15:19:45 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 15:19:45 --> Database Driver Class Initialized
INFO - 2019-06-27 15:19:45 --> Controller Class Initialized
INFO - 2019-06-27 21:19:45 --> Helper loaded: language_helper
INFO - 2019-06-27 21:19:45 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 21:19:45 --> Model Class Initialized
INFO - 2019-06-27 21:19:45 --> Model Class Initialized
INFO - 2019-06-27 21:19:45 --> Model Class Initialized
INFO - 2019-06-27 21:19:45 --> Model Class Initialized
INFO - 2019-06-27 21:19:45 --> Model Class Initialized
INFO - 2019-06-27 21:19:45 --> Final output sent to browser
DEBUG - 2019-06-27 21:19:45 --> Total execution time: 0.2532
INFO - 2019-06-27 15:20:26 --> Config Class Initialized
INFO - 2019-06-27 15:20:26 --> Hooks Class Initialized
DEBUG - 2019-06-27 15:20:26 --> UTF-8 Support Enabled
INFO - 2019-06-27 15:20:26 --> Utf8 Class Initialized
INFO - 2019-06-27 15:20:26 --> URI Class Initialized
INFO - 2019-06-27 15:20:26 --> Router Class Initialized
INFO - 2019-06-27 15:20:26 --> Output Class Initialized
INFO - 2019-06-27 15:20:26 --> Security Class Initialized
DEBUG - 2019-06-27 15:20:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 15:20:26 --> Input Class Initialized
INFO - 2019-06-27 15:20:26 --> Language Class Initialized
INFO - 2019-06-27 15:20:26 --> Language Class Initialized
INFO - 2019-06-27 15:20:26 --> Config Class Initialized
INFO - 2019-06-27 15:20:26 --> Loader Class Initialized
DEBUG - 2019-06-27 15:20:26 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 15:20:26 --> Helper loaded: url_helper
INFO - 2019-06-27 15:20:26 --> Helper loaded: inflector_helper
INFO - 2019-06-27 15:20:26 --> Helper loaded: string_helper
INFO - 2019-06-27 15:20:26 --> Helper loaded: array_helper
INFO - 2019-06-27 15:20:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 15:20:26 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 15:20:26 --> Database Driver Class Initialized
INFO - 2019-06-27 15:20:26 --> Controller Class Initialized
INFO - 2019-06-27 21:20:26 --> Helper loaded: language_helper
INFO - 2019-06-27 21:20:26 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 21:20:26 --> Model Class Initialized
INFO - 2019-06-27 21:20:26 --> Model Class Initialized
INFO - 2019-06-27 21:20:26 --> Model Class Initialized
INFO - 2019-06-27 21:20:26 --> Model Class Initialized
INFO - 2019-06-27 21:20:26 --> Helper loaded: form_helper
INFO - 2019-06-27 21:20:26 --> Form Validation Class Initialized
DEBUG - 2019-06-27 21:20:26 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-27 21:20:26 --> Model Class Initialized
INFO - 2019-06-27 21:20:26 --> Model Class Initialized
INFO - 2019-06-27 21:20:26 --> Final output sent to browser
DEBUG - 2019-06-27 21:20:26 --> Total execution time: 0.3000
INFO - 2019-06-27 15:20:33 --> Config Class Initialized
INFO - 2019-06-27 15:20:33 --> Hooks Class Initialized
DEBUG - 2019-06-27 15:20:33 --> UTF-8 Support Enabled
INFO - 2019-06-27 15:20:33 --> Utf8 Class Initialized
INFO - 2019-06-27 15:20:33 --> URI Class Initialized
INFO - 2019-06-27 15:20:33 --> Router Class Initialized
INFO - 2019-06-27 15:20:33 --> Output Class Initialized
INFO - 2019-06-27 15:20:33 --> Security Class Initialized
DEBUG - 2019-06-27 15:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 15:20:33 --> Input Class Initialized
INFO - 2019-06-27 15:20:33 --> Language Class Initialized
INFO - 2019-06-27 15:20:33 --> Language Class Initialized
INFO - 2019-06-27 15:20:33 --> Config Class Initialized
INFO - 2019-06-27 15:20:33 --> Loader Class Initialized
DEBUG - 2019-06-27 15:20:33 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 15:20:33 --> Helper loaded: url_helper
INFO - 2019-06-27 15:20:33 --> Helper loaded: inflector_helper
INFO - 2019-06-27 15:20:33 --> Helper loaded: string_helper
INFO - 2019-06-27 15:20:33 --> Helper loaded: array_helper
INFO - 2019-06-27 15:20:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 15:20:33 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 15:20:33 --> Database Driver Class Initialized
INFO - 2019-06-27 15:20:33 --> Controller Class Initialized
INFO - 2019-06-27 21:20:33 --> Helper loaded: language_helper
INFO - 2019-06-27 21:20:33 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 21:20:33 --> Model Class Initialized
INFO - 2019-06-27 21:20:33 --> Model Class Initialized
INFO - 2019-06-27 21:20:33 --> Model Class Initialized
INFO - 2019-06-27 21:20:33 --> Model Class Initialized
INFO - 2019-06-27 21:20:33 --> Model Class Initialized
INFO - 2019-06-27 21:20:33 --> Final output sent to browser
DEBUG - 2019-06-27 21:20:33 --> Total execution time: 0.3229
INFO - 2019-06-27 15:22:04 --> Config Class Initialized
INFO - 2019-06-27 15:22:04 --> Hooks Class Initialized
DEBUG - 2019-06-27 15:22:04 --> UTF-8 Support Enabled
INFO - 2019-06-27 15:22:04 --> Utf8 Class Initialized
INFO - 2019-06-27 15:22:04 --> URI Class Initialized
INFO - 2019-06-27 15:22:04 --> Router Class Initialized
INFO - 2019-06-27 15:22:04 --> Output Class Initialized
INFO - 2019-06-27 15:22:04 --> Security Class Initialized
DEBUG - 2019-06-27 15:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 15:22:04 --> Input Class Initialized
INFO - 2019-06-27 15:22:04 --> Language Class Initialized
INFO - 2019-06-27 15:22:04 --> Language Class Initialized
INFO - 2019-06-27 15:22:04 --> Config Class Initialized
INFO - 2019-06-27 15:22:04 --> Loader Class Initialized
DEBUG - 2019-06-27 15:22:04 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 15:22:04 --> Helper loaded: url_helper
INFO - 2019-06-27 15:22:04 --> Helper loaded: inflector_helper
INFO - 2019-06-27 15:22:04 --> Helper loaded: string_helper
INFO - 2019-06-27 15:22:04 --> Helper loaded: array_helper
INFO - 2019-06-27 15:22:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 15:22:04 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 15:22:04 --> Database Driver Class Initialized
INFO - 2019-06-27 15:22:04 --> Controller Class Initialized
INFO - 2019-06-27 21:22:04 --> Helper loaded: language_helper
INFO - 2019-06-27 21:22:04 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 21:22:04 --> Model Class Initialized
INFO - 2019-06-27 21:22:04 --> Model Class Initialized
INFO - 2019-06-27 21:22:04 --> Model Class Initialized
INFO - 2019-06-27 21:22:04 --> Model Class Initialized
INFO - 2019-06-27 21:22:04 --> Helper loaded: form_helper
INFO - 2019-06-27 21:22:04 --> Form Validation Class Initialized
DEBUG - 2019-06-27 21:22:04 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-27 21:22:04 --> Model Class Initialized
INFO - 2019-06-27 21:22:04 --> Model Class Initialized
INFO - 2019-06-27 21:22:04 --> Final output sent to browser
DEBUG - 2019-06-27 21:22:04 --> Total execution time: 0.3472
INFO - 2019-06-27 15:22:05 --> Config Class Initialized
INFO - 2019-06-27 15:22:05 --> Hooks Class Initialized
DEBUG - 2019-06-27 15:22:05 --> UTF-8 Support Enabled
INFO - 2019-06-27 15:22:05 --> Utf8 Class Initialized
INFO - 2019-06-27 15:22:05 --> URI Class Initialized
INFO - 2019-06-27 15:22:05 --> Router Class Initialized
INFO - 2019-06-27 15:22:05 --> Output Class Initialized
INFO - 2019-06-27 15:22:05 --> Security Class Initialized
DEBUG - 2019-06-27 15:22:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 15:22:05 --> Input Class Initialized
INFO - 2019-06-27 15:22:05 --> Language Class Initialized
INFO - 2019-06-27 15:22:05 --> Language Class Initialized
INFO - 2019-06-27 15:22:05 --> Config Class Initialized
INFO - 2019-06-27 15:22:05 --> Loader Class Initialized
DEBUG - 2019-06-27 15:22:05 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 15:22:05 --> Helper loaded: url_helper
INFO - 2019-06-27 15:22:05 --> Helper loaded: inflector_helper
INFO - 2019-06-27 15:22:05 --> Helper loaded: string_helper
INFO - 2019-06-27 15:22:05 --> Helper loaded: array_helper
INFO - 2019-06-27 15:22:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 15:22:06 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 15:22:06 --> Database Driver Class Initialized
INFO - 2019-06-27 15:22:06 --> Controller Class Initialized
INFO - 2019-06-27 21:22:06 --> Helper loaded: language_helper
INFO - 2019-06-27 21:22:06 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 21:22:06 --> Model Class Initialized
INFO - 2019-06-27 21:22:06 --> Model Class Initialized
INFO - 2019-06-27 21:22:06 --> Model Class Initialized
INFO - 2019-06-27 21:22:06 --> Model Class Initialized
INFO - 2019-06-27 21:22:06 --> Helper loaded: form_helper
INFO - 2019-06-27 21:22:06 --> Form Validation Class Initialized
DEBUG - 2019-06-27 21:22:06 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-27 21:22:06 --> Model Class Initialized
INFO - 2019-06-27 21:22:06 --> Model Class Initialized
INFO - 2019-06-27 21:22:06 --> Final output sent to browser
DEBUG - 2019-06-27 21:22:06 --> Total execution time: 0.3431
INFO - 2019-06-27 15:22:32 --> Config Class Initialized
INFO - 2019-06-27 15:22:32 --> Hooks Class Initialized
DEBUG - 2019-06-27 15:22:32 --> UTF-8 Support Enabled
INFO - 2019-06-27 15:22:32 --> Utf8 Class Initialized
INFO - 2019-06-27 15:22:32 --> URI Class Initialized
INFO - 2019-06-27 15:22:32 --> Router Class Initialized
INFO - 2019-06-27 15:22:32 --> Output Class Initialized
INFO - 2019-06-27 15:22:32 --> Security Class Initialized
DEBUG - 2019-06-27 15:22:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 15:22:32 --> Input Class Initialized
INFO - 2019-06-27 15:22:32 --> Language Class Initialized
INFO - 2019-06-27 15:22:32 --> Language Class Initialized
INFO - 2019-06-27 15:22:32 --> Config Class Initialized
INFO - 2019-06-27 15:22:32 --> Loader Class Initialized
DEBUG - 2019-06-27 15:22:32 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 15:22:32 --> Helper loaded: url_helper
INFO - 2019-06-27 15:22:32 --> Helper loaded: inflector_helper
INFO - 2019-06-27 15:22:32 --> Helper loaded: string_helper
INFO - 2019-06-27 15:22:32 --> Helper loaded: array_helper
INFO - 2019-06-27 15:22:32 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 15:22:32 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 15:22:32 --> Database Driver Class Initialized
INFO - 2019-06-27 15:22:32 --> Controller Class Initialized
INFO - 2019-06-27 21:22:32 --> Helper loaded: language_helper
INFO - 2019-06-27 21:22:32 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 21:22:32 --> Model Class Initialized
INFO - 2019-06-27 21:22:32 --> Model Class Initialized
INFO - 2019-06-27 21:22:32 --> Model Class Initialized
INFO - 2019-06-27 21:22:32 --> Model Class Initialized
INFO - 2019-06-27 21:22:33 --> Helper loaded: form_helper
INFO - 2019-06-27 21:22:33 --> Form Validation Class Initialized
DEBUG - 2019-06-27 21:22:33 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-27 21:22:33 --> Model Class Initialized
INFO - 2019-06-27 21:22:33 --> Model Class Initialized
INFO - 2019-06-27 21:22:33 --> Final output sent to browser
DEBUG - 2019-06-27 21:22:33 --> Total execution time: 0.3923
INFO - 2019-06-27 15:22:33 --> Config Class Initialized
INFO - 2019-06-27 15:22:33 --> Hooks Class Initialized
DEBUG - 2019-06-27 15:22:33 --> UTF-8 Support Enabled
INFO - 2019-06-27 15:22:33 --> Utf8 Class Initialized
INFO - 2019-06-27 15:22:33 --> URI Class Initialized
INFO - 2019-06-27 15:22:33 --> Router Class Initialized
INFO - 2019-06-27 15:22:33 --> Output Class Initialized
INFO - 2019-06-27 15:22:33 --> Security Class Initialized
DEBUG - 2019-06-27 15:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 15:22:33 --> Input Class Initialized
INFO - 2019-06-27 15:22:33 --> Language Class Initialized
INFO - 2019-06-27 15:22:33 --> Language Class Initialized
INFO - 2019-06-27 15:22:33 --> Config Class Initialized
INFO - 2019-06-27 15:22:33 --> Loader Class Initialized
DEBUG - 2019-06-27 15:22:33 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 15:22:34 --> Helper loaded: url_helper
INFO - 2019-06-27 15:22:34 --> Helper loaded: inflector_helper
INFO - 2019-06-27 15:22:34 --> Helper loaded: string_helper
INFO - 2019-06-27 15:22:34 --> Helper loaded: array_helper
INFO - 2019-06-27 15:22:34 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 15:22:34 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 15:22:34 --> Database Driver Class Initialized
INFO - 2019-06-27 15:22:34 --> Controller Class Initialized
INFO - 2019-06-27 21:22:34 --> Helper loaded: language_helper
INFO - 2019-06-27 21:22:34 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 21:22:34 --> Model Class Initialized
INFO - 2019-06-27 21:22:34 --> Model Class Initialized
INFO - 2019-06-27 21:22:34 --> Model Class Initialized
INFO - 2019-06-27 21:22:34 --> Model Class Initialized
INFO - 2019-06-27 21:22:34 --> Model Class Initialized
INFO - 2019-06-27 21:22:34 --> Final output sent to browser
DEBUG - 2019-06-27 21:22:34 --> Total execution time: 0.3577
INFO - 2019-06-27 15:22:34 --> Config Class Initialized
INFO - 2019-06-27 15:22:34 --> Hooks Class Initialized
DEBUG - 2019-06-27 15:22:34 --> UTF-8 Support Enabled
INFO - 2019-06-27 15:22:34 --> Utf8 Class Initialized
INFO - 2019-06-27 15:22:34 --> URI Class Initialized
INFO - 2019-06-27 15:22:34 --> Router Class Initialized
INFO - 2019-06-27 15:22:34 --> Output Class Initialized
INFO - 2019-06-27 15:22:34 --> Security Class Initialized
DEBUG - 2019-06-27 15:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 15:22:34 --> Input Class Initialized
INFO - 2019-06-27 15:22:34 --> Language Class Initialized
INFO - 2019-06-27 15:22:34 --> Language Class Initialized
INFO - 2019-06-27 15:22:34 --> Config Class Initialized
INFO - 2019-06-27 15:22:34 --> Loader Class Initialized
DEBUG - 2019-06-27 15:22:34 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 15:22:34 --> Helper loaded: url_helper
INFO - 2019-06-27 15:22:34 --> Helper loaded: inflector_helper
INFO - 2019-06-27 15:22:34 --> Helper loaded: string_helper
INFO - 2019-06-27 15:22:34 --> Helper loaded: array_helper
INFO - 2019-06-27 15:22:34 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 15:22:34 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 15:22:34 --> Database Driver Class Initialized
INFO - 2019-06-27 15:22:34 --> Controller Class Initialized
INFO - 2019-06-27 21:22:34 --> Helper loaded: language_helper
INFO - 2019-06-27 21:22:34 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 21:22:34 --> Model Class Initialized
INFO - 2019-06-27 21:22:34 --> Model Class Initialized
INFO - 2019-06-27 21:22:34 --> Model Class Initialized
INFO - 2019-06-27 21:22:34 --> Model Class Initialized
INFO - 2019-06-27 21:22:34 --> Helper loaded: form_helper
INFO - 2019-06-27 21:22:34 --> Form Validation Class Initialized
DEBUG - 2019-06-27 21:22:34 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-27 21:22:34 --> Model Class Initialized
INFO - 2019-06-27 21:22:34 --> Model Class Initialized
INFO - 2019-06-27 21:22:34 --> Final output sent to browser
DEBUG - 2019-06-27 21:22:34 --> Total execution time: 0.3442
INFO - 2019-06-27 15:22:35 --> Config Class Initialized
INFO - 2019-06-27 15:22:35 --> Hooks Class Initialized
DEBUG - 2019-06-27 15:22:35 --> UTF-8 Support Enabled
INFO - 2019-06-27 15:22:35 --> Utf8 Class Initialized
INFO - 2019-06-27 15:22:35 --> URI Class Initialized
INFO - 2019-06-27 15:22:35 --> Router Class Initialized
INFO - 2019-06-27 15:22:35 --> Output Class Initialized
INFO - 2019-06-27 15:22:35 --> Security Class Initialized
DEBUG - 2019-06-27 15:22:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 15:22:35 --> Input Class Initialized
INFO - 2019-06-27 15:22:35 --> Language Class Initialized
INFO - 2019-06-27 15:22:35 --> Language Class Initialized
INFO - 2019-06-27 15:22:35 --> Config Class Initialized
INFO - 2019-06-27 15:22:35 --> Loader Class Initialized
DEBUG - 2019-06-27 15:22:35 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 15:22:35 --> Helper loaded: url_helper
INFO - 2019-06-27 15:22:35 --> Helper loaded: inflector_helper
INFO - 2019-06-27 15:22:35 --> Helper loaded: string_helper
INFO - 2019-06-27 15:22:35 --> Helper loaded: array_helper
INFO - 2019-06-27 15:22:35 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 15:22:35 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 15:22:35 --> Database Driver Class Initialized
INFO - 2019-06-27 15:22:35 --> Controller Class Initialized
INFO - 2019-06-27 21:22:35 --> Helper loaded: language_helper
INFO - 2019-06-27 21:22:35 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 21:22:35 --> Model Class Initialized
INFO - 2019-06-27 21:22:35 --> Model Class Initialized
INFO - 2019-06-27 21:22:35 --> Model Class Initialized
INFO - 2019-06-27 21:22:35 --> Model Class Initialized
INFO - 2019-06-27 21:22:35 --> Model Class Initialized
INFO - 2019-06-27 21:22:35 --> Final output sent to browser
DEBUG - 2019-06-27 21:22:35 --> Total execution time: 0.2776
INFO - 2019-06-27 15:22:36 --> Config Class Initialized
INFO - 2019-06-27 15:22:36 --> Hooks Class Initialized
DEBUG - 2019-06-27 15:22:36 --> UTF-8 Support Enabled
INFO - 2019-06-27 15:22:36 --> Utf8 Class Initialized
INFO - 2019-06-27 15:22:36 --> URI Class Initialized
INFO - 2019-06-27 15:22:36 --> Router Class Initialized
INFO - 2019-06-27 15:22:36 --> Output Class Initialized
INFO - 2019-06-27 15:22:36 --> Security Class Initialized
DEBUG - 2019-06-27 15:22:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 15:22:36 --> Input Class Initialized
INFO - 2019-06-27 15:22:36 --> Language Class Initialized
INFO - 2019-06-27 15:22:36 --> Language Class Initialized
INFO - 2019-06-27 15:22:36 --> Config Class Initialized
INFO - 2019-06-27 15:22:36 --> Loader Class Initialized
DEBUG - 2019-06-27 15:22:36 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 15:22:36 --> Helper loaded: url_helper
INFO - 2019-06-27 15:22:36 --> Helper loaded: inflector_helper
INFO - 2019-06-27 15:22:36 --> Helper loaded: string_helper
INFO - 2019-06-27 15:22:36 --> Helper loaded: array_helper
INFO - 2019-06-27 15:22:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 15:22:36 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 15:22:36 --> Database Driver Class Initialized
INFO - 2019-06-27 15:22:36 --> Controller Class Initialized
INFO - 2019-06-27 21:22:36 --> Helper loaded: language_helper
INFO - 2019-06-27 21:22:36 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 21:22:36 --> Model Class Initialized
INFO - 2019-06-27 21:22:36 --> Model Class Initialized
INFO - 2019-06-27 21:22:36 --> Model Class Initialized
INFO - 2019-06-27 21:22:36 --> Model Class Initialized
INFO - 2019-06-27 21:22:36 --> Model Class Initialized
INFO - 2019-06-27 21:22:36 --> Final output sent to browser
DEBUG - 2019-06-27 21:22:36 --> Total execution time: 0.2703
INFO - 2019-06-27 15:22:37 --> Config Class Initialized
INFO - 2019-06-27 15:22:37 --> Hooks Class Initialized
DEBUG - 2019-06-27 15:22:37 --> UTF-8 Support Enabled
INFO - 2019-06-27 15:22:37 --> Utf8 Class Initialized
INFO - 2019-06-27 15:22:37 --> URI Class Initialized
INFO - 2019-06-27 15:22:37 --> Router Class Initialized
INFO - 2019-06-27 15:22:37 --> Output Class Initialized
INFO - 2019-06-27 15:22:37 --> Security Class Initialized
DEBUG - 2019-06-27 15:22:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 15:22:37 --> Input Class Initialized
INFO - 2019-06-27 15:22:37 --> Language Class Initialized
INFO - 2019-06-27 15:22:37 --> Language Class Initialized
INFO - 2019-06-27 15:22:37 --> Config Class Initialized
INFO - 2019-06-27 15:22:37 --> Loader Class Initialized
DEBUG - 2019-06-27 15:22:37 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 15:22:37 --> Helper loaded: url_helper
INFO - 2019-06-27 15:22:37 --> Helper loaded: inflector_helper
INFO - 2019-06-27 15:22:37 --> Helper loaded: string_helper
INFO - 2019-06-27 15:22:37 --> Helper loaded: array_helper
INFO - 2019-06-27 15:22:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 15:22:37 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 15:22:37 --> Database Driver Class Initialized
INFO - 2019-06-27 15:22:37 --> Controller Class Initialized
INFO - 2019-06-27 21:22:37 --> Helper loaded: language_helper
INFO - 2019-06-27 21:22:37 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 21:22:37 --> Model Class Initialized
INFO - 2019-06-27 21:22:37 --> Model Class Initialized
INFO - 2019-06-27 21:22:37 --> Model Class Initialized
INFO - 2019-06-27 21:22:37 --> Model Class Initialized
INFO - 2019-06-27 21:22:37 --> Helper loaded: form_helper
INFO - 2019-06-27 21:22:37 --> Form Validation Class Initialized
DEBUG - 2019-06-27 21:22:37 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-27 21:22:37 --> Model Class Initialized
INFO - 2019-06-27 21:22:37 --> Model Class Initialized
INFO - 2019-06-27 21:22:37 --> Final output sent to browser
DEBUG - 2019-06-27 21:22:37 --> Total execution time: 0.3209
INFO - 2019-06-27 15:33:04 --> Config Class Initialized
INFO - 2019-06-27 15:33:04 --> Hooks Class Initialized
DEBUG - 2019-06-27 15:33:04 --> UTF-8 Support Enabled
INFO - 2019-06-27 15:33:04 --> Utf8 Class Initialized
INFO - 2019-06-27 15:33:04 --> URI Class Initialized
INFO - 2019-06-27 15:33:04 --> Router Class Initialized
INFO - 2019-06-27 15:33:04 --> Output Class Initialized
INFO - 2019-06-27 15:33:04 --> Security Class Initialized
DEBUG - 2019-06-27 15:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 15:33:04 --> Input Class Initialized
INFO - 2019-06-27 15:33:04 --> Language Class Initialized
INFO - 2019-06-27 15:33:04 --> Language Class Initialized
INFO - 2019-06-27 15:33:04 --> Config Class Initialized
INFO - 2019-06-27 15:33:04 --> Loader Class Initialized
DEBUG - 2019-06-27 15:33:04 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 15:33:04 --> Helper loaded: url_helper
INFO - 2019-06-27 15:33:04 --> Helper loaded: inflector_helper
INFO - 2019-06-27 15:33:04 --> Helper loaded: string_helper
INFO - 2019-06-27 15:33:04 --> Helper loaded: array_helper
INFO - 2019-06-27 15:33:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 15:33:04 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 15:33:04 --> Database Driver Class Initialized
INFO - 2019-06-27 15:33:04 --> Controller Class Initialized
INFO - 2019-06-27 21:33:04 --> Helper loaded: language_helper
INFO - 2019-06-27 21:33:04 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 21:33:04 --> Model Class Initialized
INFO - 2019-06-27 21:33:04 --> Model Class Initialized
INFO - 2019-06-27 21:33:04 --> Model Class Initialized
INFO - 2019-06-27 21:33:04 --> Model Class Initialized
INFO - 2019-06-27 21:33:04 --> Helper loaded: form_helper
INFO - 2019-06-27 21:33:04 --> Form Validation Class Initialized
DEBUG - 2019-06-27 21:33:04 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-27 21:33:04 --> Model Class Initialized
INFO - 2019-06-27 21:33:04 --> Model Class Initialized
INFO - 2019-06-27 21:33:04 --> Final output sent to browser
DEBUG - 2019-06-27 21:33:04 --> Total execution time: 0.4032
INFO - 2019-06-27 15:33:06 --> Config Class Initialized
INFO - 2019-06-27 15:33:06 --> Hooks Class Initialized
DEBUG - 2019-06-27 15:33:06 --> UTF-8 Support Enabled
INFO - 2019-06-27 15:33:06 --> Utf8 Class Initialized
INFO - 2019-06-27 15:33:06 --> URI Class Initialized
INFO - 2019-06-27 15:33:06 --> Router Class Initialized
INFO - 2019-06-27 15:33:06 --> Output Class Initialized
INFO - 2019-06-27 15:33:06 --> Security Class Initialized
DEBUG - 2019-06-27 15:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 15:33:06 --> Input Class Initialized
INFO - 2019-06-27 15:33:06 --> Language Class Initialized
INFO - 2019-06-27 15:33:06 --> Language Class Initialized
INFO - 2019-06-27 15:33:06 --> Config Class Initialized
INFO - 2019-06-27 15:33:06 --> Loader Class Initialized
DEBUG - 2019-06-27 15:33:06 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 15:33:06 --> Helper loaded: url_helper
INFO - 2019-06-27 15:33:06 --> Helper loaded: inflector_helper
INFO - 2019-06-27 15:33:06 --> Helper loaded: string_helper
INFO - 2019-06-27 15:33:06 --> Helper loaded: array_helper
INFO - 2019-06-27 15:33:06 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 15:33:06 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 15:33:06 --> Database Driver Class Initialized
INFO - 2019-06-27 15:33:06 --> Controller Class Initialized
INFO - 2019-06-27 21:33:07 --> Helper loaded: language_helper
INFO - 2019-06-27 21:33:07 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 21:33:07 --> Model Class Initialized
INFO - 2019-06-27 21:33:07 --> Model Class Initialized
INFO - 2019-06-27 21:33:07 --> Model Class Initialized
INFO - 2019-06-27 21:33:07 --> Model Class Initialized
INFO - 2019-06-27 21:33:07 --> Helper loaded: form_helper
INFO - 2019-06-27 21:33:07 --> Form Validation Class Initialized
DEBUG - 2019-06-27 21:33:07 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-27 21:33:07 --> Model Class Initialized
INFO - 2019-06-27 21:33:07 --> Model Class Initialized
INFO - 2019-06-27 21:33:07 --> Final output sent to browser
DEBUG - 2019-06-27 21:33:07 --> Total execution time: 0.3288
INFO - 2019-06-27 15:36:51 --> Config Class Initialized
INFO - 2019-06-27 15:36:51 --> Hooks Class Initialized
DEBUG - 2019-06-27 15:36:51 --> UTF-8 Support Enabled
INFO - 2019-06-27 15:36:51 --> Utf8 Class Initialized
INFO - 2019-06-27 15:36:51 --> URI Class Initialized
INFO - 2019-06-27 15:36:51 --> Router Class Initialized
INFO - 2019-06-27 15:36:51 --> Output Class Initialized
INFO - 2019-06-27 15:36:51 --> Security Class Initialized
DEBUG - 2019-06-27 15:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 15:36:51 --> Input Class Initialized
INFO - 2019-06-27 15:36:51 --> Language Class Initialized
INFO - 2019-06-27 15:36:51 --> Language Class Initialized
INFO - 2019-06-27 15:36:51 --> Config Class Initialized
INFO - 2019-06-27 15:36:51 --> Loader Class Initialized
DEBUG - 2019-06-27 15:36:52 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 15:36:52 --> Helper loaded: url_helper
INFO - 2019-06-27 15:36:52 --> Helper loaded: inflector_helper
INFO - 2019-06-27 15:36:52 --> Helper loaded: string_helper
INFO - 2019-06-27 15:36:52 --> Helper loaded: array_helper
INFO - 2019-06-27 15:36:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 15:36:52 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 15:36:52 --> Database Driver Class Initialized
INFO - 2019-06-27 15:36:52 --> Controller Class Initialized
INFO - 2019-06-27 21:36:52 --> Helper loaded: language_helper
INFO - 2019-06-27 21:36:52 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 21:36:52 --> Model Class Initialized
INFO - 2019-06-27 21:36:52 --> Model Class Initialized
INFO - 2019-06-27 21:36:52 --> Model Class Initialized
INFO - 2019-06-27 21:36:52 --> Model Class Initialized
INFO - 2019-06-27 21:36:52 --> Helper loaded: form_helper
INFO - 2019-06-27 21:36:52 --> Form Validation Class Initialized
DEBUG - 2019-06-27 21:36:52 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-27 21:36:52 --> Model Class Initialized
INFO - 2019-06-27 21:36:52 --> Model Class Initialized
INFO - 2019-06-27 21:36:52 --> Final output sent to browser
DEBUG - 2019-06-27 21:36:52 --> Total execution time: 0.3285
INFO - 2019-06-27 15:36:53 --> Config Class Initialized
INFO - 2019-06-27 15:36:53 --> Hooks Class Initialized
DEBUG - 2019-06-27 15:36:53 --> UTF-8 Support Enabled
INFO - 2019-06-27 15:36:53 --> Utf8 Class Initialized
INFO - 2019-06-27 15:36:53 --> URI Class Initialized
INFO - 2019-06-27 15:36:53 --> Router Class Initialized
INFO - 2019-06-27 15:36:53 --> Output Class Initialized
INFO - 2019-06-27 15:36:53 --> Security Class Initialized
DEBUG - 2019-06-27 15:36:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 15:36:53 --> Input Class Initialized
INFO - 2019-06-27 15:36:53 --> Language Class Initialized
INFO - 2019-06-27 15:36:53 --> Language Class Initialized
INFO - 2019-06-27 15:36:53 --> Config Class Initialized
INFO - 2019-06-27 15:36:53 --> Loader Class Initialized
DEBUG - 2019-06-27 15:36:53 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 15:36:53 --> Helper loaded: url_helper
INFO - 2019-06-27 15:36:53 --> Helper loaded: inflector_helper
INFO - 2019-06-27 15:36:53 --> Helper loaded: string_helper
INFO - 2019-06-27 15:36:53 --> Helper loaded: array_helper
INFO - 2019-06-27 15:36:53 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 15:36:53 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 15:36:53 --> Database Driver Class Initialized
INFO - 2019-06-27 15:36:53 --> Controller Class Initialized
INFO - 2019-06-27 21:36:53 --> Helper loaded: language_helper
INFO - 2019-06-27 21:36:53 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 21:36:53 --> Model Class Initialized
INFO - 2019-06-27 21:36:53 --> Model Class Initialized
INFO - 2019-06-27 21:36:53 --> Model Class Initialized
INFO - 2019-06-27 21:36:53 --> Model Class Initialized
INFO - 2019-06-27 21:36:53 --> Helper loaded: form_helper
INFO - 2019-06-27 21:36:53 --> Form Validation Class Initialized
DEBUG - 2019-06-27 21:36:53 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-27 21:36:53 --> Model Class Initialized
INFO - 2019-06-27 21:36:53 --> Model Class Initialized
INFO - 2019-06-27 21:36:53 --> Final output sent to browser
DEBUG - 2019-06-27 21:36:53 --> Total execution time: 0.3599
INFO - 2019-06-27 15:38:54 --> Config Class Initialized
INFO - 2019-06-27 15:38:54 --> Hooks Class Initialized
DEBUG - 2019-06-27 15:38:54 --> UTF-8 Support Enabled
INFO - 2019-06-27 15:38:54 --> Utf8 Class Initialized
INFO - 2019-06-27 15:38:54 --> URI Class Initialized
INFO - 2019-06-27 15:38:54 --> Router Class Initialized
INFO - 2019-06-27 15:38:54 --> Output Class Initialized
INFO - 2019-06-27 15:38:54 --> Security Class Initialized
DEBUG - 2019-06-27 15:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 15:38:54 --> Input Class Initialized
INFO - 2019-06-27 15:38:54 --> Language Class Initialized
INFO - 2019-06-27 15:38:54 --> Language Class Initialized
INFO - 2019-06-27 15:38:54 --> Config Class Initialized
INFO - 2019-06-27 15:38:54 --> Loader Class Initialized
DEBUG - 2019-06-27 15:38:54 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 15:38:54 --> Helper loaded: url_helper
INFO - 2019-06-27 15:38:54 --> Helper loaded: inflector_helper
INFO - 2019-06-27 15:38:54 --> Helper loaded: string_helper
INFO - 2019-06-27 15:38:54 --> Helper loaded: array_helper
INFO - 2019-06-27 15:38:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 15:38:54 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 15:38:54 --> Database Driver Class Initialized
INFO - 2019-06-27 15:38:54 --> Controller Class Initialized
INFO - 2019-06-27 21:38:54 --> Helper loaded: language_helper
INFO - 2019-06-27 21:38:54 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 21:38:54 --> Model Class Initialized
INFO - 2019-06-27 21:38:54 --> Model Class Initialized
INFO - 2019-06-27 21:38:54 --> Model Class Initialized
INFO - 2019-06-27 21:38:54 --> Model Class Initialized
INFO - 2019-06-27 21:38:54 --> Helper loaded: form_helper
INFO - 2019-06-27 21:38:55 --> Form Validation Class Initialized
DEBUG - 2019-06-27 21:38:55 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-27 21:38:55 --> Model Class Initialized
INFO - 2019-06-27 21:38:55 --> Model Class Initialized
INFO - 2019-06-27 21:38:55 --> Final output sent to browser
DEBUG - 2019-06-27 21:38:55 --> Total execution time: 0.3376
INFO - 2019-06-27 15:43:55 --> Config Class Initialized
INFO - 2019-06-27 15:43:55 --> Hooks Class Initialized
DEBUG - 2019-06-27 15:43:55 --> UTF-8 Support Enabled
INFO - 2019-06-27 15:43:55 --> Utf8 Class Initialized
INFO - 2019-06-27 15:43:55 --> URI Class Initialized
INFO - 2019-06-27 15:43:55 --> Router Class Initialized
INFO - 2019-06-27 15:43:55 --> Output Class Initialized
INFO - 2019-06-27 15:43:55 --> Security Class Initialized
DEBUG - 2019-06-27 15:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 15:43:55 --> Input Class Initialized
INFO - 2019-06-27 15:43:55 --> Language Class Initialized
INFO - 2019-06-27 15:43:55 --> Language Class Initialized
INFO - 2019-06-27 15:43:55 --> Config Class Initialized
INFO - 2019-06-27 15:43:55 --> Loader Class Initialized
DEBUG - 2019-06-27 15:43:55 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 15:43:55 --> Helper loaded: url_helper
INFO - 2019-06-27 15:43:55 --> Helper loaded: inflector_helper
INFO - 2019-06-27 15:43:55 --> Helper loaded: string_helper
INFO - 2019-06-27 15:43:55 --> Helper loaded: array_helper
INFO - 2019-06-27 15:43:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 15:43:55 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 15:43:55 --> Database Driver Class Initialized
INFO - 2019-06-27 15:43:55 --> Controller Class Initialized
INFO - 2019-06-27 21:43:55 --> Helper loaded: language_helper
INFO - 2019-06-27 21:43:55 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 21:43:55 --> Model Class Initialized
INFO - 2019-06-27 21:43:55 --> Model Class Initialized
INFO - 2019-06-27 21:43:55 --> Model Class Initialized
INFO - 2019-06-27 21:43:55 --> Model Class Initialized
INFO - 2019-06-27 21:43:55 --> Helper loaded: form_helper
INFO - 2019-06-27 21:43:55 --> Form Validation Class Initialized
DEBUG - 2019-06-27 21:43:55 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-27 21:43:55 --> Model Class Initialized
INFO - 2019-06-27 21:43:55 --> Model Class Initialized
INFO - 2019-06-27 21:43:55 --> Final output sent to browser
DEBUG - 2019-06-27 21:43:55 --> Total execution time: 0.3086
INFO - 2019-06-27 15:45:42 --> Config Class Initialized
INFO - 2019-06-27 15:45:42 --> Hooks Class Initialized
DEBUG - 2019-06-27 15:45:42 --> UTF-8 Support Enabled
INFO - 2019-06-27 15:45:42 --> Utf8 Class Initialized
INFO - 2019-06-27 15:45:42 --> URI Class Initialized
INFO - 2019-06-27 15:45:42 --> Router Class Initialized
INFO - 2019-06-27 15:45:42 --> Output Class Initialized
INFO - 2019-06-27 15:45:42 --> Security Class Initialized
DEBUG - 2019-06-27 15:45:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 15:45:42 --> Input Class Initialized
INFO - 2019-06-27 15:45:42 --> Language Class Initialized
INFO - 2019-06-27 15:45:42 --> Language Class Initialized
INFO - 2019-06-27 15:45:42 --> Config Class Initialized
INFO - 2019-06-27 15:45:42 --> Loader Class Initialized
DEBUG - 2019-06-27 15:45:42 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 15:45:42 --> Helper loaded: url_helper
INFO - 2019-06-27 15:45:42 --> Helper loaded: inflector_helper
INFO - 2019-06-27 15:45:42 --> Helper loaded: string_helper
INFO - 2019-06-27 15:45:42 --> Helper loaded: array_helper
INFO - 2019-06-27 15:45:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 15:45:42 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 15:45:42 --> Database Driver Class Initialized
INFO - 2019-06-27 15:45:42 --> Controller Class Initialized
INFO - 2019-06-27 21:45:42 --> Helper loaded: language_helper
INFO - 2019-06-27 21:45:42 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 21:45:42 --> Model Class Initialized
INFO - 2019-06-27 21:45:42 --> Model Class Initialized
INFO - 2019-06-27 21:45:42 --> Model Class Initialized
INFO - 2019-06-27 21:45:42 --> Model Class Initialized
INFO - 2019-06-27 21:45:42 --> Helper loaded: form_helper
INFO - 2019-06-27 21:45:42 --> Form Validation Class Initialized
DEBUG - 2019-06-27 21:45:42 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-27 21:45:42 --> Model Class Initialized
INFO - 2019-06-27 21:45:42 --> Model Class Initialized
INFO - 2019-06-27 21:45:42 --> Final output sent to browser
DEBUG - 2019-06-27 21:45:42 --> Total execution time: 0.3712
INFO - 2019-06-27 15:45:44 --> Config Class Initialized
INFO - 2019-06-27 15:45:44 --> Hooks Class Initialized
DEBUG - 2019-06-27 15:45:44 --> UTF-8 Support Enabled
INFO - 2019-06-27 15:45:44 --> Utf8 Class Initialized
INFO - 2019-06-27 15:45:44 --> URI Class Initialized
INFO - 2019-06-27 15:45:44 --> Router Class Initialized
INFO - 2019-06-27 15:45:44 --> Output Class Initialized
INFO - 2019-06-27 15:45:44 --> Security Class Initialized
DEBUG - 2019-06-27 15:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 15:45:44 --> Input Class Initialized
INFO - 2019-06-27 15:45:44 --> Language Class Initialized
INFO - 2019-06-27 15:45:44 --> Language Class Initialized
INFO - 2019-06-27 15:45:44 --> Config Class Initialized
INFO - 2019-06-27 15:45:44 --> Loader Class Initialized
DEBUG - 2019-06-27 15:45:44 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 15:45:44 --> Helper loaded: url_helper
INFO - 2019-06-27 15:45:44 --> Helper loaded: inflector_helper
INFO - 2019-06-27 15:45:44 --> Helper loaded: string_helper
INFO - 2019-06-27 15:45:44 --> Helper loaded: array_helper
INFO - 2019-06-27 15:45:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 15:45:44 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 15:45:44 --> Database Driver Class Initialized
INFO - 2019-06-27 15:45:44 --> Controller Class Initialized
INFO - 2019-06-27 21:45:44 --> Helper loaded: language_helper
INFO - 2019-06-27 21:45:44 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 21:45:44 --> Model Class Initialized
INFO - 2019-06-27 21:45:44 --> Model Class Initialized
INFO - 2019-06-27 21:45:44 --> Model Class Initialized
INFO - 2019-06-27 21:45:44 --> Model Class Initialized
INFO - 2019-06-27 21:45:44 --> Model Class Initialized
ERROR - 2019-06-27 21:45:44 --> Query error: Unknown column 'resto_id' in 'where clause' - Invalid query: SELECT * FROM products WHERE resto_id = "1" ORDER BY products.id DESC
INFO - 2019-06-27 21:45:44 --> Language file loaded: language/english/db_lang.php
INFO - 2019-06-27 15:46:13 --> Config Class Initialized
INFO - 2019-06-27 15:46:13 --> Hooks Class Initialized
DEBUG - 2019-06-27 15:46:13 --> UTF-8 Support Enabled
INFO - 2019-06-27 15:46:13 --> Utf8 Class Initialized
INFO - 2019-06-27 15:46:13 --> URI Class Initialized
INFO - 2019-06-27 15:46:13 --> Router Class Initialized
INFO - 2019-06-27 15:46:13 --> Output Class Initialized
INFO - 2019-06-27 15:46:13 --> Security Class Initialized
DEBUG - 2019-06-27 15:46:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 15:46:13 --> Input Class Initialized
INFO - 2019-06-27 15:46:13 --> Language Class Initialized
INFO - 2019-06-27 15:46:13 --> Language Class Initialized
INFO - 2019-06-27 15:46:13 --> Config Class Initialized
INFO - 2019-06-27 15:46:13 --> Loader Class Initialized
DEBUG - 2019-06-27 15:46:13 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 15:46:13 --> Helper loaded: url_helper
INFO - 2019-06-27 15:46:13 --> Helper loaded: inflector_helper
INFO - 2019-06-27 15:46:14 --> Helper loaded: string_helper
INFO - 2019-06-27 15:46:14 --> Helper loaded: array_helper
INFO - 2019-06-27 15:46:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 15:46:14 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 15:46:14 --> Database Driver Class Initialized
INFO - 2019-06-27 15:46:14 --> Controller Class Initialized
INFO - 2019-06-27 21:46:14 --> Helper loaded: language_helper
INFO - 2019-06-27 21:46:14 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 21:46:14 --> Model Class Initialized
INFO - 2019-06-27 21:46:14 --> Model Class Initialized
INFO - 2019-06-27 21:46:14 --> Model Class Initialized
INFO - 2019-06-27 21:46:14 --> Model Class Initialized
INFO - 2019-06-27 21:46:14 --> Helper loaded: form_helper
INFO - 2019-06-27 21:46:14 --> Form Validation Class Initialized
DEBUG - 2019-06-27 21:46:14 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-27 21:46:14 --> Model Class Initialized
INFO - 2019-06-27 21:46:14 --> Model Class Initialized
INFO - 2019-06-27 21:46:14 --> Final output sent to browser
DEBUG - 2019-06-27 21:46:14 --> Total execution time: 0.2957
INFO - 2019-06-27 15:46:21 --> Config Class Initialized
INFO - 2019-06-27 15:46:21 --> Hooks Class Initialized
DEBUG - 2019-06-27 15:46:21 --> UTF-8 Support Enabled
INFO - 2019-06-27 15:46:21 --> Utf8 Class Initialized
INFO - 2019-06-27 15:46:21 --> URI Class Initialized
INFO - 2019-06-27 15:46:21 --> Router Class Initialized
INFO - 2019-06-27 15:46:21 --> Output Class Initialized
INFO - 2019-06-27 15:46:22 --> Security Class Initialized
DEBUG - 2019-06-27 15:46:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 15:46:22 --> Input Class Initialized
INFO - 2019-06-27 15:46:22 --> Language Class Initialized
INFO - 2019-06-27 15:46:22 --> Language Class Initialized
INFO - 2019-06-27 15:46:22 --> Config Class Initialized
INFO - 2019-06-27 15:46:22 --> Loader Class Initialized
DEBUG - 2019-06-27 15:46:22 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 15:46:22 --> Helper loaded: url_helper
INFO - 2019-06-27 15:46:22 --> Helper loaded: inflector_helper
INFO - 2019-06-27 15:46:22 --> Helper loaded: string_helper
INFO - 2019-06-27 15:46:22 --> Helper loaded: array_helper
INFO - 2019-06-27 15:46:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 15:46:22 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 15:46:22 --> Database Driver Class Initialized
INFO - 2019-06-27 15:46:22 --> Controller Class Initialized
INFO - 2019-06-27 21:46:22 --> Helper loaded: language_helper
INFO - 2019-06-27 21:46:22 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 21:46:22 --> Model Class Initialized
INFO - 2019-06-27 21:46:22 --> Model Class Initialized
INFO - 2019-06-27 21:46:22 --> Model Class Initialized
INFO - 2019-06-27 21:46:22 --> Model Class Initialized
INFO - 2019-06-27 21:46:22 --> Helper loaded: form_helper
INFO - 2019-06-27 21:46:22 --> Form Validation Class Initialized
DEBUG - 2019-06-27 21:46:22 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-27 21:46:22 --> Model Class Initialized
INFO - 2019-06-27 21:46:22 --> Model Class Initialized
INFO - 2019-06-27 21:46:22 --> Final output sent to browser
DEBUG - 2019-06-27 21:46:22 --> Total execution time: 0.3316
INFO - 2019-06-27 15:46:22 --> Config Class Initialized
INFO - 2019-06-27 15:46:22 --> Hooks Class Initialized
DEBUG - 2019-06-27 15:46:22 --> UTF-8 Support Enabled
INFO - 2019-06-27 15:46:22 --> Utf8 Class Initialized
INFO - 2019-06-27 15:46:22 --> URI Class Initialized
INFO - 2019-06-27 15:46:22 --> Router Class Initialized
INFO - 2019-06-27 15:46:22 --> Output Class Initialized
INFO - 2019-06-27 15:46:22 --> Security Class Initialized
DEBUG - 2019-06-27 15:46:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 15:46:22 --> Input Class Initialized
INFO - 2019-06-27 15:46:22 --> Language Class Initialized
INFO - 2019-06-27 15:46:22 --> Language Class Initialized
INFO - 2019-06-27 15:46:22 --> Config Class Initialized
INFO - 2019-06-27 15:46:22 --> Loader Class Initialized
DEBUG - 2019-06-27 15:46:22 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 15:46:22 --> Helper loaded: url_helper
INFO - 2019-06-27 15:46:22 --> Helper loaded: inflector_helper
INFO - 2019-06-27 15:46:22 --> Helper loaded: string_helper
INFO - 2019-06-27 15:46:22 --> Helper loaded: array_helper
INFO - 2019-06-27 15:46:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 15:46:22 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 15:46:22 --> Database Driver Class Initialized
INFO - 2019-06-27 15:46:22 --> Controller Class Initialized
INFO - 2019-06-27 21:46:22 --> Helper loaded: language_helper
INFO - 2019-06-27 21:46:22 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 21:46:22 --> Model Class Initialized
INFO - 2019-06-27 21:46:22 --> Model Class Initialized
INFO - 2019-06-27 21:46:22 --> Model Class Initialized
INFO - 2019-06-27 21:46:22 --> Model Class Initialized
INFO - 2019-06-27 21:46:22 --> Model Class Initialized
INFO - 2019-06-27 21:46:22 --> Final output sent to browser
DEBUG - 2019-06-27 21:46:22 --> Total execution time: 0.3406
INFO - 2019-06-27 15:46:25 --> Config Class Initialized
INFO - 2019-06-27 15:46:25 --> Hooks Class Initialized
DEBUG - 2019-06-27 15:46:25 --> UTF-8 Support Enabled
INFO - 2019-06-27 15:46:25 --> Utf8 Class Initialized
INFO - 2019-06-27 15:46:25 --> URI Class Initialized
INFO - 2019-06-27 15:46:25 --> Router Class Initialized
INFO - 2019-06-27 15:46:25 --> Output Class Initialized
INFO - 2019-06-27 15:46:25 --> Security Class Initialized
DEBUG - 2019-06-27 15:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 15:46:25 --> Input Class Initialized
INFO - 2019-06-27 15:46:25 --> Language Class Initialized
INFO - 2019-06-27 15:46:25 --> Language Class Initialized
INFO - 2019-06-27 15:46:25 --> Config Class Initialized
INFO - 2019-06-27 15:46:25 --> Loader Class Initialized
DEBUG - 2019-06-27 15:46:25 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 15:46:25 --> Helper loaded: url_helper
INFO - 2019-06-27 15:46:25 --> Helper loaded: inflector_helper
INFO - 2019-06-27 15:46:25 --> Helper loaded: string_helper
INFO - 2019-06-27 15:46:25 --> Helper loaded: array_helper
INFO - 2019-06-27 15:46:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 15:46:25 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 15:46:25 --> Database Driver Class Initialized
INFO - 2019-06-27 15:46:25 --> Controller Class Initialized
INFO - 2019-06-27 21:46:25 --> Helper loaded: language_helper
INFO - 2019-06-27 21:46:25 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 21:46:25 --> Model Class Initialized
INFO - 2019-06-27 21:46:25 --> Model Class Initialized
INFO - 2019-06-27 21:46:25 --> Model Class Initialized
INFO - 2019-06-27 21:46:25 --> Model Class Initialized
INFO - 2019-06-27 21:46:25 --> Helper loaded: form_helper
INFO - 2019-06-27 21:46:25 --> Form Validation Class Initialized
DEBUG - 2019-06-27 21:46:25 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-27 21:46:25 --> Model Class Initialized
INFO - 2019-06-27 21:46:25 --> Model Class Initialized
INFO - 2019-06-27 21:46:25 --> Final output sent to browser
DEBUG - 2019-06-27 21:46:25 --> Total execution time: 0.3237
INFO - 2019-06-27 15:46:28 --> Config Class Initialized
INFO - 2019-06-27 15:46:28 --> Hooks Class Initialized
DEBUG - 2019-06-27 15:46:28 --> UTF-8 Support Enabled
INFO - 2019-06-27 15:46:28 --> Utf8 Class Initialized
INFO - 2019-06-27 15:46:28 --> URI Class Initialized
INFO - 2019-06-27 15:46:28 --> Router Class Initialized
INFO - 2019-06-27 15:46:28 --> Output Class Initialized
INFO - 2019-06-27 15:46:28 --> Security Class Initialized
DEBUG - 2019-06-27 15:46:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 15:46:28 --> Input Class Initialized
INFO - 2019-06-27 15:46:28 --> Language Class Initialized
INFO - 2019-06-27 15:46:28 --> Language Class Initialized
INFO - 2019-06-27 15:46:28 --> Config Class Initialized
INFO - 2019-06-27 15:46:28 --> Loader Class Initialized
DEBUG - 2019-06-27 15:46:28 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 15:46:28 --> Helper loaded: url_helper
INFO - 2019-06-27 15:46:28 --> Helper loaded: inflector_helper
INFO - 2019-06-27 15:46:28 --> Helper loaded: string_helper
INFO - 2019-06-27 15:46:28 --> Helper loaded: array_helper
INFO - 2019-06-27 15:46:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 15:46:28 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 15:46:28 --> Database Driver Class Initialized
INFO - 2019-06-27 15:46:28 --> Controller Class Initialized
INFO - 2019-06-27 21:46:28 --> Helper loaded: language_helper
INFO - 2019-06-27 21:46:28 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 21:46:28 --> Model Class Initialized
INFO - 2019-06-27 21:46:28 --> Model Class Initialized
INFO - 2019-06-27 21:46:28 --> Model Class Initialized
INFO - 2019-06-27 21:46:28 --> Model Class Initialized
INFO - 2019-06-27 21:46:28 --> Model Class Initialized
ERROR - 2019-06-27 21:46:28 --> Query error: Unknown column 'resto_id' in 'where clause' - Invalid query: SELECT * FROM products WHERE resto_id = "1" ORDER BY products.id DESC
INFO - 2019-06-27 21:46:29 --> Language file loaded: language/english/db_lang.php
INFO - 2019-06-27 15:47:11 --> Config Class Initialized
INFO - 2019-06-27 15:47:11 --> Hooks Class Initialized
DEBUG - 2019-06-27 15:47:11 --> UTF-8 Support Enabled
INFO - 2019-06-27 15:47:11 --> Utf8 Class Initialized
INFO - 2019-06-27 15:47:11 --> URI Class Initialized
INFO - 2019-06-27 15:47:11 --> Router Class Initialized
INFO - 2019-06-27 15:47:11 --> Output Class Initialized
INFO - 2019-06-27 15:47:11 --> Security Class Initialized
DEBUG - 2019-06-27 15:47:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 15:47:11 --> Input Class Initialized
INFO - 2019-06-27 15:47:11 --> Language Class Initialized
INFO - 2019-06-27 15:47:11 --> Language Class Initialized
INFO - 2019-06-27 15:47:11 --> Config Class Initialized
INFO - 2019-06-27 15:47:11 --> Loader Class Initialized
DEBUG - 2019-06-27 15:47:11 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 15:47:11 --> Helper loaded: url_helper
INFO - 2019-06-27 15:47:11 --> Helper loaded: inflector_helper
INFO - 2019-06-27 15:47:11 --> Helper loaded: string_helper
INFO - 2019-06-27 15:47:11 --> Helper loaded: array_helper
INFO - 2019-06-27 15:47:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 15:47:11 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 15:47:11 --> Database Driver Class Initialized
INFO - 2019-06-27 15:47:11 --> Controller Class Initialized
INFO - 2019-06-27 21:47:11 --> Helper loaded: language_helper
INFO - 2019-06-27 21:47:11 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 21:47:11 --> Model Class Initialized
INFO - 2019-06-27 21:47:11 --> Model Class Initialized
INFO - 2019-06-27 21:47:11 --> Model Class Initialized
INFO - 2019-06-27 21:47:11 --> Model Class Initialized
INFO - 2019-06-27 21:47:11 --> Helper loaded: form_helper
INFO - 2019-06-27 21:47:11 --> Form Validation Class Initialized
DEBUG - 2019-06-27 21:47:11 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-27 21:47:11 --> Model Class Initialized
INFO - 2019-06-27 21:47:11 --> Model Class Initialized
INFO - 2019-06-27 21:47:11 --> Final output sent to browser
DEBUG - 2019-06-27 21:47:11 --> Total execution time: 0.3921
INFO - 2019-06-27 15:47:15 --> Config Class Initialized
INFO - 2019-06-27 15:47:15 --> Hooks Class Initialized
DEBUG - 2019-06-27 15:47:15 --> UTF-8 Support Enabled
INFO - 2019-06-27 15:47:15 --> Utf8 Class Initialized
INFO - 2019-06-27 15:47:15 --> URI Class Initialized
INFO - 2019-06-27 15:47:15 --> Router Class Initialized
INFO - 2019-06-27 15:47:15 --> Output Class Initialized
INFO - 2019-06-27 15:47:15 --> Security Class Initialized
DEBUG - 2019-06-27 15:47:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 15:47:15 --> Input Class Initialized
INFO - 2019-06-27 15:47:15 --> Language Class Initialized
INFO - 2019-06-27 15:47:15 --> Language Class Initialized
INFO - 2019-06-27 15:47:15 --> Config Class Initialized
INFO - 2019-06-27 15:47:15 --> Loader Class Initialized
DEBUG - 2019-06-27 15:47:15 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 15:47:15 --> Helper loaded: url_helper
INFO - 2019-06-27 15:47:15 --> Helper loaded: inflector_helper
INFO - 2019-06-27 15:47:15 --> Helper loaded: string_helper
INFO - 2019-06-27 15:47:15 --> Helper loaded: array_helper
INFO - 2019-06-27 15:47:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 15:47:15 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 15:47:15 --> Database Driver Class Initialized
INFO - 2019-06-27 15:47:15 --> Controller Class Initialized
INFO - 2019-06-27 21:47:15 --> Helper loaded: language_helper
INFO - 2019-06-27 21:47:15 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 21:47:15 --> Model Class Initialized
INFO - 2019-06-27 21:47:15 --> Model Class Initialized
INFO - 2019-06-27 21:47:15 --> Model Class Initialized
INFO - 2019-06-27 21:47:15 --> Model Class Initialized
INFO - 2019-06-27 21:47:15 --> Model Class Initialized
INFO - 2019-06-27 21:47:15 --> Final output sent to browser
DEBUG - 2019-06-27 21:47:15 --> Total execution time: 0.4568
INFO - 2019-06-27 15:47:16 --> Config Class Initialized
INFO - 2019-06-27 15:47:16 --> Hooks Class Initialized
DEBUG - 2019-06-27 15:47:17 --> UTF-8 Support Enabled
INFO - 2019-06-27 15:47:17 --> Utf8 Class Initialized
INFO - 2019-06-27 15:47:17 --> URI Class Initialized
INFO - 2019-06-27 15:47:17 --> Router Class Initialized
INFO - 2019-06-27 15:47:17 --> Output Class Initialized
INFO - 2019-06-27 15:47:17 --> Security Class Initialized
DEBUG - 2019-06-27 15:47:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 15:47:17 --> Input Class Initialized
INFO - 2019-06-27 15:47:17 --> Language Class Initialized
INFO - 2019-06-27 15:47:17 --> Language Class Initialized
INFO - 2019-06-27 15:47:17 --> Config Class Initialized
INFO - 2019-06-27 15:47:17 --> Loader Class Initialized
DEBUG - 2019-06-27 15:47:17 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 15:47:17 --> Helper loaded: url_helper
INFO - 2019-06-27 15:47:17 --> Helper loaded: inflector_helper
INFO - 2019-06-27 15:47:17 --> Helper loaded: string_helper
INFO - 2019-06-27 15:47:17 --> Helper loaded: array_helper
INFO - 2019-06-27 15:47:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 15:47:17 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 15:47:17 --> Database Driver Class Initialized
INFO - 2019-06-27 15:47:17 --> Controller Class Initialized
INFO - 2019-06-27 21:47:17 --> Helper loaded: language_helper
INFO - 2019-06-27 21:47:17 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 21:47:17 --> Model Class Initialized
INFO - 2019-06-27 21:47:17 --> Model Class Initialized
INFO - 2019-06-27 21:47:17 --> Model Class Initialized
INFO - 2019-06-27 21:47:17 --> Model Class Initialized
INFO - 2019-06-27 21:47:17 --> Helper loaded: form_helper
INFO - 2019-06-27 21:47:17 --> Form Validation Class Initialized
DEBUG - 2019-06-27 21:47:17 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-27 21:47:17 --> Model Class Initialized
INFO - 2019-06-27 21:47:17 --> Model Class Initialized
INFO - 2019-06-27 21:47:17 --> Final output sent to browser
DEBUG - 2019-06-27 21:47:17 --> Total execution time: 0.3916
INFO - 2019-06-27 15:47:39 --> Config Class Initialized
INFO - 2019-06-27 15:47:39 --> Hooks Class Initialized
DEBUG - 2019-06-27 15:47:39 --> UTF-8 Support Enabled
INFO - 2019-06-27 15:47:39 --> Utf8 Class Initialized
INFO - 2019-06-27 15:47:39 --> URI Class Initialized
INFO - 2019-06-27 15:47:39 --> Router Class Initialized
INFO - 2019-06-27 15:47:39 --> Output Class Initialized
INFO - 2019-06-27 15:47:39 --> Security Class Initialized
DEBUG - 2019-06-27 15:47:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 15:47:39 --> Input Class Initialized
INFO - 2019-06-27 15:47:39 --> Language Class Initialized
INFO - 2019-06-27 15:47:39 --> Language Class Initialized
INFO - 2019-06-27 15:47:39 --> Config Class Initialized
INFO - 2019-06-27 15:47:39 --> Loader Class Initialized
DEBUG - 2019-06-27 15:47:39 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 15:47:39 --> Helper loaded: url_helper
INFO - 2019-06-27 15:47:39 --> Helper loaded: inflector_helper
INFO - 2019-06-27 15:47:39 --> Helper loaded: string_helper
INFO - 2019-06-27 15:47:39 --> Helper loaded: array_helper
INFO - 2019-06-27 15:47:39 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 15:47:39 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 15:47:39 --> Database Driver Class Initialized
INFO - 2019-06-27 15:47:39 --> Controller Class Initialized
INFO - 2019-06-27 21:47:39 --> Helper loaded: language_helper
INFO - 2019-06-27 21:47:39 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 21:47:39 --> Model Class Initialized
INFO - 2019-06-27 21:47:39 --> Model Class Initialized
INFO - 2019-06-27 21:47:39 --> Model Class Initialized
INFO - 2019-06-27 21:47:39 --> Model Class Initialized
INFO - 2019-06-27 21:47:39 --> Model Class Initialized
INFO - 2019-06-27 21:47:39 --> Final output sent to browser
DEBUG - 2019-06-27 21:47:39 --> Total execution time: 0.3560
INFO - 2019-06-27 15:47:40 --> Config Class Initialized
INFO - 2019-06-27 15:47:40 --> Hooks Class Initialized
DEBUG - 2019-06-27 15:47:40 --> UTF-8 Support Enabled
INFO - 2019-06-27 15:47:40 --> Utf8 Class Initialized
INFO - 2019-06-27 15:47:40 --> URI Class Initialized
INFO - 2019-06-27 15:47:40 --> Router Class Initialized
INFO - 2019-06-27 15:47:40 --> Output Class Initialized
INFO - 2019-06-27 15:47:40 --> Security Class Initialized
DEBUG - 2019-06-27 15:47:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 15:47:41 --> Input Class Initialized
INFO - 2019-06-27 15:47:41 --> Language Class Initialized
INFO - 2019-06-27 15:47:41 --> Language Class Initialized
INFO - 2019-06-27 15:47:41 --> Config Class Initialized
INFO - 2019-06-27 15:47:41 --> Loader Class Initialized
DEBUG - 2019-06-27 15:47:41 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 15:47:41 --> Helper loaded: url_helper
INFO - 2019-06-27 15:47:41 --> Helper loaded: inflector_helper
INFO - 2019-06-27 15:47:41 --> Helper loaded: string_helper
INFO - 2019-06-27 15:47:41 --> Helper loaded: array_helper
INFO - 2019-06-27 15:47:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 15:47:41 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 15:47:41 --> Database Driver Class Initialized
INFO - 2019-06-27 15:47:41 --> Controller Class Initialized
INFO - 2019-06-27 21:47:41 --> Helper loaded: language_helper
INFO - 2019-06-27 21:47:41 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 21:47:41 --> Model Class Initialized
INFO - 2019-06-27 21:47:41 --> Model Class Initialized
INFO - 2019-06-27 21:47:41 --> Model Class Initialized
INFO - 2019-06-27 21:47:41 --> Model Class Initialized
INFO - 2019-06-27 21:47:41 --> Helper loaded: form_helper
INFO - 2019-06-27 21:47:41 --> Form Validation Class Initialized
DEBUG - 2019-06-27 21:47:41 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-27 21:47:41 --> Model Class Initialized
INFO - 2019-06-27 21:47:41 --> Model Class Initialized
INFO - 2019-06-27 21:47:41 --> Final output sent to browser
DEBUG - 2019-06-27 21:47:41 --> Total execution time: 0.3423
INFO - 2019-06-27 15:47:50 --> Config Class Initialized
INFO - 2019-06-27 15:47:50 --> Hooks Class Initialized
DEBUG - 2019-06-27 15:47:50 --> UTF-8 Support Enabled
INFO - 2019-06-27 15:47:50 --> Utf8 Class Initialized
INFO - 2019-06-27 15:47:50 --> URI Class Initialized
INFO - 2019-06-27 15:47:50 --> Router Class Initialized
INFO - 2019-06-27 15:47:50 --> Output Class Initialized
INFO - 2019-06-27 15:47:50 --> Security Class Initialized
DEBUG - 2019-06-27 15:47:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 15:47:50 --> Input Class Initialized
INFO - 2019-06-27 15:47:50 --> Language Class Initialized
INFO - 2019-06-27 15:47:50 --> Language Class Initialized
INFO - 2019-06-27 15:47:50 --> Config Class Initialized
INFO - 2019-06-27 15:47:50 --> Loader Class Initialized
DEBUG - 2019-06-27 15:47:50 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 15:47:50 --> Helper loaded: url_helper
INFO - 2019-06-27 15:47:50 --> Helper loaded: inflector_helper
INFO - 2019-06-27 15:47:50 --> Helper loaded: string_helper
INFO - 2019-06-27 15:47:50 --> Helper loaded: array_helper
INFO - 2019-06-27 15:47:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 15:47:50 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 15:47:50 --> Database Driver Class Initialized
INFO - 2019-06-27 15:47:50 --> Controller Class Initialized
INFO - 2019-06-27 21:47:50 --> Helper loaded: language_helper
INFO - 2019-06-27 21:47:50 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 21:47:50 --> Model Class Initialized
INFO - 2019-06-27 21:47:50 --> Model Class Initialized
INFO - 2019-06-27 21:47:50 --> Model Class Initialized
INFO - 2019-06-27 21:47:50 --> Model Class Initialized
INFO - 2019-06-27 21:47:50 --> Model Class Initialized
INFO - 2019-06-27 21:47:50 --> Final output sent to browser
DEBUG - 2019-06-27 21:47:50 --> Total execution time: 0.3253
INFO - 2019-06-27 15:50:57 --> Config Class Initialized
INFO - 2019-06-27 15:50:57 --> Hooks Class Initialized
DEBUG - 2019-06-27 15:50:57 --> UTF-8 Support Enabled
INFO - 2019-06-27 15:50:57 --> Utf8 Class Initialized
INFO - 2019-06-27 15:50:57 --> URI Class Initialized
INFO - 2019-06-27 15:50:57 --> Router Class Initialized
INFO - 2019-06-27 15:50:57 --> Output Class Initialized
INFO - 2019-06-27 15:50:57 --> Security Class Initialized
DEBUG - 2019-06-27 15:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 15:50:57 --> Input Class Initialized
INFO - 2019-06-27 15:50:57 --> Language Class Initialized
INFO - 2019-06-27 15:50:57 --> Language Class Initialized
INFO - 2019-06-27 15:50:57 --> Config Class Initialized
INFO - 2019-06-27 15:50:57 --> Loader Class Initialized
DEBUG - 2019-06-27 15:50:57 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 15:50:57 --> Helper loaded: url_helper
INFO - 2019-06-27 15:50:57 --> Helper loaded: inflector_helper
INFO - 2019-06-27 15:50:57 --> Helper loaded: string_helper
INFO - 2019-06-27 15:50:57 --> Helper loaded: array_helper
INFO - 2019-06-27 15:50:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 15:50:57 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 15:50:57 --> Database Driver Class Initialized
INFO - 2019-06-27 15:50:57 --> Controller Class Initialized
INFO - 2019-06-27 21:50:57 --> Helper loaded: language_helper
INFO - 2019-06-27 21:50:57 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 21:50:57 --> Model Class Initialized
INFO - 2019-06-27 21:50:57 --> Model Class Initialized
INFO - 2019-06-27 21:50:57 --> Model Class Initialized
INFO - 2019-06-27 21:50:57 --> Model Class Initialized
INFO - 2019-06-27 21:50:57 --> Helper loaded: form_helper
INFO - 2019-06-27 21:50:57 --> Form Validation Class Initialized
DEBUG - 2019-06-27 21:50:57 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-27 21:50:57 --> Model Class Initialized
INFO - 2019-06-27 21:50:57 --> Model Class Initialized
INFO - 2019-06-27 21:50:57 --> Final output sent to browser
DEBUG - 2019-06-27 21:50:57 --> Total execution time: 0.3385
INFO - 2019-06-27 16:04:46 --> Config Class Initialized
INFO - 2019-06-27 16:04:46 --> Hooks Class Initialized
DEBUG - 2019-06-27 16:04:46 --> UTF-8 Support Enabled
INFO - 2019-06-27 16:04:46 --> Utf8 Class Initialized
INFO - 2019-06-27 16:04:46 --> URI Class Initialized
INFO - 2019-06-27 16:04:46 --> Router Class Initialized
INFO - 2019-06-27 16:04:46 --> Output Class Initialized
INFO - 2019-06-27 16:04:46 --> Security Class Initialized
DEBUG - 2019-06-27 16:04:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 16:04:46 --> Input Class Initialized
INFO - 2019-06-27 16:04:46 --> Language Class Initialized
INFO - 2019-06-27 16:04:46 --> Language Class Initialized
INFO - 2019-06-27 16:04:46 --> Config Class Initialized
INFO - 2019-06-27 16:04:46 --> Loader Class Initialized
DEBUG - 2019-06-27 16:04:46 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 16:04:46 --> Helper loaded: url_helper
INFO - 2019-06-27 16:04:46 --> Helper loaded: inflector_helper
INFO - 2019-06-27 16:04:46 --> Helper loaded: string_helper
INFO - 2019-06-27 16:04:46 --> Helper loaded: array_helper
INFO - 2019-06-27 16:04:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 16:04:46 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 16:04:46 --> Database Driver Class Initialized
INFO - 2019-06-27 16:04:46 --> Controller Class Initialized
INFO - 2019-06-27 22:04:46 --> Helper loaded: language_helper
INFO - 2019-06-27 22:04:46 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 22:04:46 --> Model Class Initialized
INFO - 2019-06-27 22:04:46 --> Model Class Initialized
INFO - 2019-06-27 22:04:46 --> Model Class Initialized
INFO - 2019-06-27 22:04:46 --> Model Class Initialized
INFO - 2019-06-27 22:04:46 --> Helper loaded: form_helper
INFO - 2019-06-27 22:04:46 --> Form Validation Class Initialized
DEBUG - 2019-06-27 22:04:46 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-27 22:04:46 --> Model Class Initialized
INFO - 2019-06-27 22:04:46 --> Model Class Initialized
INFO - 2019-06-27 22:04:46 --> Final output sent to browser
DEBUG - 2019-06-27 22:04:46 --> Total execution time: 0.3662
INFO - 2019-06-27 16:05:47 --> Config Class Initialized
INFO - 2019-06-27 16:05:47 --> Hooks Class Initialized
DEBUG - 2019-06-27 16:05:47 --> UTF-8 Support Enabled
INFO - 2019-06-27 16:05:47 --> Utf8 Class Initialized
INFO - 2019-06-27 16:05:47 --> URI Class Initialized
INFO - 2019-06-27 16:05:47 --> Router Class Initialized
INFO - 2019-06-27 16:05:47 --> Output Class Initialized
INFO - 2019-06-27 16:05:47 --> Security Class Initialized
DEBUG - 2019-06-27 16:05:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 16:05:47 --> Input Class Initialized
INFO - 2019-06-27 16:05:47 --> Language Class Initialized
INFO - 2019-06-27 16:05:47 --> Language Class Initialized
INFO - 2019-06-27 16:05:47 --> Config Class Initialized
INFO - 2019-06-27 16:05:47 --> Loader Class Initialized
DEBUG - 2019-06-27 16:05:47 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 16:05:47 --> Helper loaded: url_helper
INFO - 2019-06-27 16:05:47 --> Helper loaded: inflector_helper
INFO - 2019-06-27 16:05:47 --> Helper loaded: string_helper
INFO - 2019-06-27 16:05:47 --> Helper loaded: array_helper
INFO - 2019-06-27 16:05:47 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 16:05:47 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 16:05:47 --> Database Driver Class Initialized
INFO - 2019-06-27 16:05:47 --> Controller Class Initialized
INFO - 2019-06-27 22:05:47 --> Helper loaded: language_helper
INFO - 2019-06-27 22:05:47 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 22:05:47 --> Model Class Initialized
INFO - 2019-06-27 22:05:47 --> Model Class Initialized
INFO - 2019-06-27 22:05:47 --> Model Class Initialized
INFO - 2019-06-27 22:05:47 --> Model Class Initialized
INFO - 2019-06-27 22:05:47 --> Helper loaded: form_helper
INFO - 2019-06-27 22:05:47 --> Form Validation Class Initialized
DEBUG - 2019-06-27 22:05:47 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-27 22:05:47 --> Model Class Initialized
INFO - 2019-06-27 22:05:47 --> Model Class Initialized
INFO - 2019-06-27 22:05:47 --> Final output sent to browser
DEBUG - 2019-06-27 22:05:47 --> Total execution time: 0.3691
INFO - 2019-06-27 16:08:36 --> Config Class Initialized
INFO - 2019-06-27 16:08:36 --> Hooks Class Initialized
DEBUG - 2019-06-27 16:08:36 --> UTF-8 Support Enabled
INFO - 2019-06-27 16:08:36 --> Utf8 Class Initialized
INFO - 2019-06-27 16:08:36 --> URI Class Initialized
INFO - 2019-06-27 16:08:36 --> Router Class Initialized
INFO - 2019-06-27 16:08:36 --> Output Class Initialized
INFO - 2019-06-27 16:08:36 --> Security Class Initialized
DEBUG - 2019-06-27 16:08:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 16:08:36 --> Input Class Initialized
INFO - 2019-06-27 16:08:36 --> Language Class Initialized
INFO - 2019-06-27 16:08:36 --> Language Class Initialized
INFO - 2019-06-27 16:08:36 --> Config Class Initialized
INFO - 2019-06-27 16:08:36 --> Loader Class Initialized
DEBUG - 2019-06-27 16:08:36 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 16:08:36 --> Helper loaded: url_helper
INFO - 2019-06-27 16:08:36 --> Helper loaded: inflector_helper
INFO - 2019-06-27 16:08:36 --> Helper loaded: string_helper
INFO - 2019-06-27 16:08:36 --> Helper loaded: array_helper
INFO - 2019-06-27 16:08:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 16:08:36 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 16:08:36 --> Database Driver Class Initialized
INFO - 2019-06-27 16:08:36 --> Controller Class Initialized
INFO - 2019-06-27 22:08:36 --> Helper loaded: language_helper
INFO - 2019-06-27 22:08:36 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 22:08:36 --> Model Class Initialized
INFO - 2019-06-27 22:08:36 --> Model Class Initialized
INFO - 2019-06-27 22:08:36 --> Model Class Initialized
INFO - 2019-06-27 22:08:36 --> Model Class Initialized
INFO - 2019-06-27 22:08:36 --> Helper loaded: form_helper
INFO - 2019-06-27 22:08:36 --> Form Validation Class Initialized
DEBUG - 2019-06-27 22:08:36 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-27 22:08:36 --> Model Class Initialized
INFO - 2019-06-27 22:08:36 --> Model Class Initialized
INFO - 2019-06-27 22:08:36 --> Final output sent to browser
DEBUG - 2019-06-27 22:08:36 --> Total execution time: 0.3763
INFO - 2019-06-27 16:09:43 --> Config Class Initialized
INFO - 2019-06-27 16:09:43 --> Hooks Class Initialized
DEBUG - 2019-06-27 16:09:43 --> UTF-8 Support Enabled
INFO - 2019-06-27 16:09:43 --> Utf8 Class Initialized
INFO - 2019-06-27 16:09:43 --> URI Class Initialized
INFO - 2019-06-27 16:09:43 --> Router Class Initialized
INFO - 2019-06-27 16:09:43 --> Output Class Initialized
INFO - 2019-06-27 16:09:43 --> Security Class Initialized
DEBUG - 2019-06-27 16:09:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 16:09:43 --> Input Class Initialized
INFO - 2019-06-27 16:09:43 --> Language Class Initialized
INFO - 2019-06-27 16:09:43 --> Language Class Initialized
INFO - 2019-06-27 16:09:43 --> Config Class Initialized
INFO - 2019-06-27 16:09:43 --> Loader Class Initialized
DEBUG - 2019-06-27 16:09:43 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 16:09:43 --> Helper loaded: url_helper
INFO - 2019-06-27 16:09:43 --> Helper loaded: inflector_helper
INFO - 2019-06-27 16:09:43 --> Helper loaded: string_helper
INFO - 2019-06-27 16:09:43 --> Helper loaded: array_helper
INFO - 2019-06-27 16:09:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 16:09:43 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 16:09:43 --> Database Driver Class Initialized
INFO - 2019-06-27 16:09:43 --> Controller Class Initialized
INFO - 2019-06-27 22:09:43 --> Helper loaded: language_helper
INFO - 2019-06-27 22:09:43 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 22:09:43 --> Model Class Initialized
INFO - 2019-06-27 22:09:43 --> Model Class Initialized
INFO - 2019-06-27 22:09:43 --> Model Class Initialized
INFO - 2019-06-27 22:09:43 --> Model Class Initialized
INFO - 2019-06-27 22:09:43 --> Helper loaded: form_helper
INFO - 2019-06-27 22:09:43 --> Form Validation Class Initialized
DEBUG - 2019-06-27 22:09:43 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-27 22:09:43 --> Model Class Initialized
INFO - 2019-06-27 22:09:43 --> Model Class Initialized
INFO - 2019-06-27 22:09:43 --> Final output sent to browser
DEBUG - 2019-06-27 22:09:43 --> Total execution time: 0.3130
INFO - 2019-06-27 16:09:51 --> Config Class Initialized
INFO - 2019-06-27 16:09:51 --> Hooks Class Initialized
DEBUG - 2019-06-27 16:09:51 --> UTF-8 Support Enabled
INFO - 2019-06-27 16:09:51 --> Utf8 Class Initialized
INFO - 2019-06-27 16:09:51 --> URI Class Initialized
INFO - 2019-06-27 16:09:51 --> Router Class Initialized
INFO - 2019-06-27 16:09:51 --> Output Class Initialized
INFO - 2019-06-27 16:09:51 --> Security Class Initialized
DEBUG - 2019-06-27 16:09:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 16:09:51 --> Input Class Initialized
INFO - 2019-06-27 16:09:51 --> Language Class Initialized
INFO - 2019-06-27 16:09:51 --> Language Class Initialized
INFO - 2019-06-27 16:09:51 --> Config Class Initialized
INFO - 2019-06-27 16:09:51 --> Loader Class Initialized
DEBUG - 2019-06-27 16:09:51 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 16:09:51 --> Helper loaded: url_helper
INFO - 2019-06-27 16:09:51 --> Helper loaded: inflector_helper
INFO - 2019-06-27 16:09:51 --> Helper loaded: string_helper
INFO - 2019-06-27 16:09:51 --> Helper loaded: array_helper
INFO - 2019-06-27 16:09:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 16:09:51 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 16:09:51 --> Database Driver Class Initialized
INFO - 2019-06-27 16:09:51 --> Controller Class Initialized
INFO - 2019-06-27 22:09:51 --> Helper loaded: language_helper
INFO - 2019-06-27 22:09:51 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 22:09:51 --> Model Class Initialized
INFO - 2019-06-27 22:09:51 --> Model Class Initialized
INFO - 2019-06-27 22:09:51 --> Model Class Initialized
INFO - 2019-06-27 22:09:51 --> Model Class Initialized
INFO - 2019-06-27 22:09:51 --> Helper loaded: form_helper
INFO - 2019-06-27 22:09:51 --> Form Validation Class Initialized
DEBUG - 2019-06-27 22:09:51 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-27 22:09:51 --> Model Class Initialized
INFO - 2019-06-27 22:09:51 --> Model Class Initialized
INFO - 2019-06-27 22:09:51 --> Final output sent to browser
DEBUG - 2019-06-27 22:09:51 --> Total execution time: 0.3176
INFO - 2019-06-27 16:09:56 --> Config Class Initialized
INFO - 2019-06-27 16:09:56 --> Hooks Class Initialized
DEBUG - 2019-06-27 16:09:56 --> UTF-8 Support Enabled
INFO - 2019-06-27 16:09:56 --> Utf8 Class Initialized
INFO - 2019-06-27 16:09:56 --> URI Class Initialized
INFO - 2019-06-27 16:09:57 --> Router Class Initialized
INFO - 2019-06-27 16:09:57 --> Output Class Initialized
INFO - 2019-06-27 16:09:57 --> Security Class Initialized
DEBUG - 2019-06-27 16:09:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 16:09:57 --> Input Class Initialized
INFO - 2019-06-27 16:09:57 --> Language Class Initialized
INFO - 2019-06-27 16:09:57 --> Language Class Initialized
INFO - 2019-06-27 16:09:57 --> Config Class Initialized
INFO - 2019-06-27 16:09:57 --> Loader Class Initialized
DEBUG - 2019-06-27 16:09:57 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 16:09:57 --> Helper loaded: url_helper
INFO - 2019-06-27 16:09:57 --> Helper loaded: inflector_helper
INFO - 2019-06-27 16:09:57 --> Helper loaded: string_helper
INFO - 2019-06-27 16:09:57 --> Helper loaded: array_helper
INFO - 2019-06-27 16:09:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 16:09:57 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 16:09:57 --> Database Driver Class Initialized
INFO - 2019-06-27 16:09:57 --> Controller Class Initialized
INFO - 2019-06-27 22:09:57 --> Helper loaded: language_helper
INFO - 2019-06-27 22:09:57 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 22:09:57 --> Model Class Initialized
INFO - 2019-06-27 22:09:57 --> Model Class Initialized
INFO - 2019-06-27 22:09:57 --> Model Class Initialized
INFO - 2019-06-27 22:09:57 --> Model Class Initialized
INFO - 2019-06-27 22:09:57 --> Helper loaded: form_helper
INFO - 2019-06-27 22:09:57 --> Form Validation Class Initialized
DEBUG - 2019-06-27 22:09:57 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-27 22:09:57 --> Model Class Initialized
INFO - 2019-06-27 22:09:57 --> Model Class Initialized
INFO - 2019-06-27 22:09:57 --> Final output sent to browser
DEBUG - 2019-06-27 22:09:57 --> Total execution time: 0.3456
INFO - 2019-06-27 16:10:00 --> Config Class Initialized
INFO - 2019-06-27 16:10:00 --> Hooks Class Initialized
DEBUG - 2019-06-27 16:10:00 --> UTF-8 Support Enabled
INFO - 2019-06-27 16:10:00 --> Utf8 Class Initialized
INFO - 2019-06-27 16:10:00 --> URI Class Initialized
INFO - 2019-06-27 16:10:00 --> Router Class Initialized
INFO - 2019-06-27 16:10:00 --> Output Class Initialized
INFO - 2019-06-27 16:10:00 --> Security Class Initialized
DEBUG - 2019-06-27 16:10:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 16:10:00 --> Input Class Initialized
INFO - 2019-06-27 16:10:00 --> Language Class Initialized
INFO - 2019-06-27 16:10:00 --> Language Class Initialized
INFO - 2019-06-27 16:10:00 --> Config Class Initialized
INFO - 2019-06-27 16:10:00 --> Loader Class Initialized
DEBUG - 2019-06-27 16:10:00 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 16:10:00 --> Helper loaded: url_helper
INFO - 2019-06-27 16:10:00 --> Helper loaded: inflector_helper
INFO - 2019-06-27 16:10:00 --> Helper loaded: string_helper
INFO - 2019-06-27 16:10:00 --> Helper loaded: array_helper
INFO - 2019-06-27 16:10:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 16:10:00 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 16:10:00 --> Database Driver Class Initialized
INFO - 2019-06-27 16:10:00 --> Controller Class Initialized
INFO - 2019-06-27 22:10:00 --> Helper loaded: language_helper
INFO - 2019-06-27 22:10:00 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 22:10:00 --> Model Class Initialized
INFO - 2019-06-27 22:10:00 --> Model Class Initialized
INFO - 2019-06-27 22:10:00 --> Model Class Initialized
INFO - 2019-06-27 22:10:00 --> Model Class Initialized
INFO - 2019-06-27 22:10:00 --> Helper loaded: form_helper
INFO - 2019-06-27 22:10:00 --> Form Validation Class Initialized
DEBUG - 2019-06-27 22:10:00 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-27 22:10:00 --> Model Class Initialized
INFO - 2019-06-27 22:10:00 --> Model Class Initialized
INFO - 2019-06-27 22:10:00 --> Final output sent to browser
DEBUG - 2019-06-27 22:10:00 --> Total execution time: 0.3648
INFO - 2019-06-27 17:05:14 --> Config Class Initialized
INFO - 2019-06-27 17:05:14 --> Hooks Class Initialized
DEBUG - 2019-06-27 17:05:14 --> UTF-8 Support Enabled
INFO - 2019-06-27 17:05:14 --> Utf8 Class Initialized
INFO - 2019-06-27 17:05:14 --> URI Class Initialized
INFO - 2019-06-27 17:05:14 --> Router Class Initialized
INFO - 2019-06-27 17:05:14 --> Output Class Initialized
INFO - 2019-06-27 17:05:14 --> Security Class Initialized
DEBUG - 2019-06-27 17:05:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 17:05:14 --> Input Class Initialized
INFO - 2019-06-27 17:05:14 --> Language Class Initialized
INFO - 2019-06-27 17:05:14 --> Language Class Initialized
INFO - 2019-06-27 17:05:14 --> Config Class Initialized
INFO - 2019-06-27 17:05:14 --> Loader Class Initialized
DEBUG - 2019-06-27 17:05:14 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 17:05:14 --> Helper loaded: url_helper
INFO - 2019-06-27 17:05:14 --> Helper loaded: inflector_helper
INFO - 2019-06-27 17:05:14 --> Helper loaded: string_helper
INFO - 2019-06-27 17:05:14 --> Helper loaded: array_helper
INFO - 2019-06-27 17:05:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 17:05:14 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 17:05:14 --> Database Driver Class Initialized
INFO - 2019-06-27 17:05:14 --> Controller Class Initialized
INFO - 2019-06-27 23:05:14 --> Helper loaded: language_helper
INFO - 2019-06-27 23:05:14 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 23:05:14 --> Model Class Initialized
INFO - 2019-06-27 23:05:14 --> Model Class Initialized
INFO - 2019-06-27 23:05:14 --> Model Class Initialized
INFO - 2019-06-27 23:05:14 --> Model Class Initialized
INFO - 2019-06-27 23:05:14 --> Helper loaded: form_helper
INFO - 2019-06-27 23:05:14 --> Form Validation Class Initialized
DEBUG - 2019-06-27 23:05:14 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-27 23:05:14 --> Model Class Initialized
INFO - 2019-06-27 23:05:14 --> Model Class Initialized
INFO - 2019-06-27 23:05:14 --> Final output sent to browser
DEBUG - 2019-06-27 23:05:14 --> Total execution time: 0.3302
INFO - 2019-06-27 17:07:58 --> Config Class Initialized
INFO - 2019-06-27 17:07:59 --> Hooks Class Initialized
DEBUG - 2019-06-27 17:07:59 --> UTF-8 Support Enabled
INFO - 2019-06-27 17:07:59 --> Utf8 Class Initialized
INFO - 2019-06-27 17:07:59 --> URI Class Initialized
INFO - 2019-06-27 17:07:59 --> Router Class Initialized
INFO - 2019-06-27 17:07:59 --> Output Class Initialized
INFO - 2019-06-27 17:07:59 --> Security Class Initialized
DEBUG - 2019-06-27 17:07:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 17:07:59 --> Input Class Initialized
INFO - 2019-06-27 17:07:59 --> Language Class Initialized
INFO - 2019-06-27 17:07:59 --> Language Class Initialized
INFO - 2019-06-27 17:07:59 --> Config Class Initialized
INFO - 2019-06-27 17:07:59 --> Loader Class Initialized
DEBUG - 2019-06-27 17:07:59 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 17:07:59 --> Helper loaded: url_helper
INFO - 2019-06-27 17:07:59 --> Helper loaded: inflector_helper
INFO - 2019-06-27 17:07:59 --> Helper loaded: string_helper
INFO - 2019-06-27 17:07:59 --> Helper loaded: array_helper
INFO - 2019-06-27 17:07:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 17:07:59 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 17:07:59 --> Database Driver Class Initialized
INFO - 2019-06-27 17:07:59 --> Controller Class Initialized
INFO - 2019-06-27 23:07:59 --> Helper loaded: language_helper
INFO - 2019-06-27 23:07:59 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 23:07:59 --> Model Class Initialized
INFO - 2019-06-27 23:07:59 --> Model Class Initialized
INFO - 2019-06-27 23:07:59 --> Model Class Initialized
INFO - 2019-06-27 23:07:59 --> Model Class Initialized
INFO - 2019-06-27 23:07:59 --> Helper loaded: form_helper
INFO - 2019-06-27 23:07:59 --> Form Validation Class Initialized
DEBUG - 2019-06-27 23:07:59 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-27 23:07:59 --> Model Class Initialized
INFO - 2019-06-27 23:07:59 --> Model Class Initialized
INFO - 2019-06-27 23:07:59 --> Final output sent to browser
DEBUG - 2019-06-27 23:07:59 --> Total execution time: 0.3530
INFO - 2019-06-27 17:08:00 --> Config Class Initialized
INFO - 2019-06-27 17:08:00 --> Hooks Class Initialized
DEBUG - 2019-06-27 17:08:00 --> UTF-8 Support Enabled
INFO - 2019-06-27 17:08:00 --> Utf8 Class Initialized
INFO - 2019-06-27 17:08:00 --> URI Class Initialized
INFO - 2019-06-27 17:08:00 --> Router Class Initialized
INFO - 2019-06-27 17:08:00 --> Output Class Initialized
INFO - 2019-06-27 17:08:00 --> Security Class Initialized
DEBUG - 2019-06-27 17:08:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 17:08:00 --> Input Class Initialized
INFO - 2019-06-27 17:08:00 --> Language Class Initialized
INFO - 2019-06-27 17:08:00 --> Language Class Initialized
INFO - 2019-06-27 17:08:00 --> Config Class Initialized
INFO - 2019-06-27 17:08:00 --> Loader Class Initialized
DEBUG - 2019-06-27 17:08:00 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 17:08:00 --> Helper loaded: url_helper
INFO - 2019-06-27 17:08:00 --> Helper loaded: inflector_helper
INFO - 2019-06-27 17:08:00 --> Helper loaded: string_helper
INFO - 2019-06-27 17:08:00 --> Helper loaded: array_helper
INFO - 2019-06-27 17:08:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 17:08:00 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 17:08:00 --> Database Driver Class Initialized
INFO - 2019-06-27 17:08:00 --> Controller Class Initialized
INFO - 2019-06-27 23:08:00 --> Helper loaded: language_helper
INFO - 2019-06-27 23:08:00 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 23:08:00 --> Model Class Initialized
INFO - 2019-06-27 23:08:00 --> Model Class Initialized
INFO - 2019-06-27 23:08:00 --> Model Class Initialized
INFO - 2019-06-27 23:08:00 --> Model Class Initialized
INFO - 2019-06-27 23:08:00 --> Final output sent to browser
DEBUG - 2019-06-27 23:08:00 --> Total execution time: 0.3205
INFO - 2019-06-27 17:08:21 --> Config Class Initialized
INFO - 2019-06-27 17:08:21 --> Hooks Class Initialized
DEBUG - 2019-06-27 17:08:21 --> UTF-8 Support Enabled
INFO - 2019-06-27 17:08:21 --> Utf8 Class Initialized
INFO - 2019-06-27 17:08:21 --> URI Class Initialized
INFO - 2019-06-27 17:08:21 --> Router Class Initialized
INFO - 2019-06-27 17:08:21 --> Output Class Initialized
INFO - 2019-06-27 17:08:21 --> Security Class Initialized
DEBUG - 2019-06-27 17:08:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 17:08:21 --> Input Class Initialized
INFO - 2019-06-27 17:08:21 --> Language Class Initialized
INFO - 2019-06-27 17:08:21 --> Language Class Initialized
INFO - 2019-06-27 17:08:21 --> Config Class Initialized
INFO - 2019-06-27 17:08:21 --> Loader Class Initialized
DEBUG - 2019-06-27 17:08:21 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 17:08:21 --> Config Class Initialized
INFO - 2019-06-27 17:08:21 --> Helper loaded: url_helper
INFO - 2019-06-27 17:08:21 --> Hooks Class Initialized
INFO - 2019-06-27 17:08:21 --> Helper loaded: inflector_helper
DEBUG - 2019-06-27 17:08:21 --> UTF-8 Support Enabled
INFO - 2019-06-27 17:08:21 --> Helper loaded: string_helper
INFO - 2019-06-27 17:08:21 --> Utf8 Class Initialized
INFO - 2019-06-27 17:08:21 --> Helper loaded: array_helper
INFO - 2019-06-27 17:08:21 --> URI Class Initialized
INFO - 2019-06-27 17:08:21 --> Session: Class initialized using 'files' driver.
INFO - 2019-06-27 17:08:21 --> Router Class Initialized
DEBUG - 2019-06-27 17:08:21 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 17:08:21 --> Output Class Initialized
INFO - 2019-06-27 17:08:21 --> Database Driver Class Initialized
INFO - 2019-06-27 17:08:21 --> Security Class Initialized
INFO - 2019-06-27 17:08:21 --> Controller Class Initialized
DEBUG - 2019-06-27 17:08:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 23:08:21 --> Helper loaded: language_helper
INFO - 2019-06-27 17:08:21 --> Input Class Initialized
INFO - 2019-06-27 23:08:22 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 17:08:22 --> Language Class Initialized
INFO - 2019-06-27 23:08:22 --> Model Class Initialized
INFO - 2019-06-27 17:08:22 --> Language Class Initialized
INFO - 2019-06-27 23:08:22 --> Model Class Initialized
INFO - 2019-06-27 17:08:22 --> Config Class Initialized
INFO - 2019-06-27 17:08:22 --> Loader Class Initialized
INFO - 2019-06-27 23:08:22 --> Model Class Initialized
DEBUG - 2019-06-27 17:08:22 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 23:08:22 --> Model Class Initialized
INFO - 2019-06-27 17:08:22 --> Helper loaded: url_helper
INFO - 2019-06-27 23:08:22 --> Final output sent to browser
DEBUG - 2019-06-27 23:08:22 --> Total execution time: 0.5287
INFO - 2019-06-27 17:08:22 --> Helper loaded: inflector_helper
INFO - 2019-06-27 17:08:22 --> Helper loaded: string_helper
INFO - 2019-06-27 17:08:22 --> Helper loaded: array_helper
INFO - 2019-06-27 17:08:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 17:08:22 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 17:08:22 --> Database Driver Class Initialized
INFO - 2019-06-27 17:08:22 --> Controller Class Initialized
INFO - 2019-06-27 23:08:22 --> Helper loaded: language_helper
INFO - 2019-06-27 23:08:22 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 23:08:22 --> Model Class Initialized
INFO - 2019-06-27 23:08:22 --> Model Class Initialized
INFO - 2019-06-27 23:08:22 --> Model Class Initialized
INFO - 2019-06-27 23:08:22 --> Model Class Initialized
INFO - 2019-06-27 23:08:22 --> Final output sent to browser
DEBUG - 2019-06-27 23:08:22 --> Total execution time: 0.4639
INFO - 2019-06-27 17:08:24 --> Config Class Initialized
INFO - 2019-06-27 17:08:24 --> Hooks Class Initialized
DEBUG - 2019-06-27 17:08:24 --> UTF-8 Support Enabled
INFO - 2019-06-27 17:08:24 --> Utf8 Class Initialized
INFO - 2019-06-27 17:08:24 --> URI Class Initialized
INFO - 2019-06-27 17:08:24 --> Router Class Initialized
INFO - 2019-06-27 17:08:24 --> Output Class Initialized
INFO - 2019-06-27 17:08:24 --> Security Class Initialized
DEBUG - 2019-06-27 17:08:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 17:08:24 --> Input Class Initialized
INFO - 2019-06-27 17:08:24 --> Language Class Initialized
INFO - 2019-06-27 17:08:24 --> Language Class Initialized
INFO - 2019-06-27 17:08:24 --> Config Class Initialized
INFO - 2019-06-27 17:08:24 --> Loader Class Initialized
DEBUG - 2019-06-27 17:08:24 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 17:08:24 --> Helper loaded: url_helper
INFO - 2019-06-27 17:08:24 --> Helper loaded: inflector_helper
INFO - 2019-06-27 17:08:24 --> Helper loaded: string_helper
INFO - 2019-06-27 17:08:24 --> Helper loaded: array_helper
INFO - 2019-06-27 17:08:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 17:08:24 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 17:08:24 --> Database Driver Class Initialized
INFO - 2019-06-27 17:08:24 --> Controller Class Initialized
INFO - 2019-06-27 23:08:24 --> Helper loaded: language_helper
INFO - 2019-06-27 23:08:24 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 23:08:24 --> Model Class Initialized
INFO - 2019-06-27 23:08:24 --> Model Class Initialized
INFO - 2019-06-27 23:08:24 --> Model Class Initialized
INFO - 2019-06-27 23:08:25 --> Model Class Initialized
INFO - 2019-06-27 23:08:25 --> Helper loaded: form_helper
INFO - 2019-06-27 23:08:25 --> Form Validation Class Initialized
DEBUG - 2019-06-27 23:08:25 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-27 23:08:25 --> Model Class Initialized
INFO - 2019-06-27 23:08:25 --> Model Class Initialized
INFO - 2019-06-27 23:08:25 --> Final output sent to browser
DEBUG - 2019-06-27 23:08:25 --> Total execution time: 0.3900
INFO - 2019-06-27 17:08:25 --> Config Class Initialized
INFO - 2019-06-27 17:08:25 --> Hooks Class Initialized
DEBUG - 2019-06-27 17:08:25 --> UTF-8 Support Enabled
INFO - 2019-06-27 17:08:25 --> Utf8 Class Initialized
INFO - 2019-06-27 17:08:25 --> URI Class Initialized
INFO - 2019-06-27 17:08:25 --> Router Class Initialized
INFO - 2019-06-27 17:08:25 --> Output Class Initialized
INFO - 2019-06-27 17:08:25 --> Security Class Initialized
DEBUG - 2019-06-27 17:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 17:08:25 --> Input Class Initialized
INFO - 2019-06-27 17:08:25 --> Language Class Initialized
INFO - 2019-06-27 17:08:25 --> Language Class Initialized
INFO - 2019-06-27 17:08:25 --> Config Class Initialized
INFO - 2019-06-27 17:08:25 --> Loader Class Initialized
DEBUG - 2019-06-27 17:08:25 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 17:08:25 --> Helper loaded: url_helper
INFO - 2019-06-27 17:08:25 --> Helper loaded: inflector_helper
INFO - 2019-06-27 17:08:25 --> Helper loaded: string_helper
INFO - 2019-06-27 17:08:25 --> Helper loaded: array_helper
INFO - 2019-06-27 17:08:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 17:08:25 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 17:08:25 --> Database Driver Class Initialized
INFO - 2019-06-27 17:08:25 --> Controller Class Initialized
INFO - 2019-06-27 23:08:25 --> Helper loaded: language_helper
INFO - 2019-06-27 23:08:25 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 23:08:25 --> Model Class Initialized
INFO - 2019-06-27 23:08:26 --> Model Class Initialized
INFO - 2019-06-27 23:08:26 --> Model Class Initialized
INFO - 2019-06-27 23:08:26 --> Model Class Initialized
INFO - 2019-06-27 23:08:26 --> Final output sent to browser
DEBUG - 2019-06-27 23:08:26 --> Total execution time: 0.3056
INFO - 2019-06-27 17:08:48 --> Config Class Initialized
INFO - 2019-06-27 17:08:48 --> Hooks Class Initialized
DEBUG - 2019-06-27 17:08:48 --> UTF-8 Support Enabled
INFO - 2019-06-27 17:08:48 --> Utf8 Class Initialized
INFO - 2019-06-27 17:08:48 --> URI Class Initialized
INFO - 2019-06-27 17:08:48 --> Router Class Initialized
INFO - 2019-06-27 17:08:48 --> Output Class Initialized
INFO - 2019-06-27 17:08:49 --> Security Class Initialized
DEBUG - 2019-06-27 17:08:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 17:08:49 --> Input Class Initialized
INFO - 2019-06-27 17:08:49 --> Language Class Initialized
INFO - 2019-06-27 17:08:49 --> Language Class Initialized
INFO - 2019-06-27 17:08:49 --> Config Class Initialized
INFO - 2019-06-27 17:08:49 --> Loader Class Initialized
DEBUG - 2019-06-27 17:08:49 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 17:08:49 --> Helper loaded: url_helper
INFO - 2019-06-27 17:08:49 --> Helper loaded: inflector_helper
INFO - 2019-06-27 17:08:49 --> Helper loaded: string_helper
INFO - 2019-06-27 17:08:49 --> Helper loaded: array_helper
INFO - 2019-06-27 17:08:49 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 17:08:49 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 17:08:49 --> Database Driver Class Initialized
INFO - 2019-06-27 17:08:49 --> Controller Class Initialized
INFO - 2019-06-27 23:08:49 --> Helper loaded: language_helper
INFO - 2019-06-27 23:08:49 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 23:08:49 --> Model Class Initialized
INFO - 2019-06-27 23:08:49 --> Model Class Initialized
INFO - 2019-06-27 23:08:49 --> Model Class Initialized
INFO - 2019-06-27 23:08:49 --> Model Class Initialized
INFO - 2019-06-27 23:08:49 --> Final output sent to browser
DEBUG - 2019-06-27 23:08:49 --> Total execution time: 0.3547
INFO - 2019-06-27 17:08:49 --> Config Class Initialized
INFO - 2019-06-27 17:08:49 --> Hooks Class Initialized
DEBUG - 2019-06-27 17:08:49 --> UTF-8 Support Enabled
INFO - 2019-06-27 17:08:49 --> Utf8 Class Initialized
INFO - 2019-06-27 17:08:49 --> URI Class Initialized
INFO - 2019-06-27 17:08:49 --> Router Class Initialized
INFO - 2019-06-27 17:08:49 --> Output Class Initialized
INFO - 2019-06-27 17:08:49 --> Security Class Initialized
DEBUG - 2019-06-27 17:08:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 17:08:49 --> Input Class Initialized
INFO - 2019-06-27 17:08:49 --> Language Class Initialized
INFO - 2019-06-27 17:08:49 --> Language Class Initialized
INFO - 2019-06-27 17:08:49 --> Config Class Initialized
INFO - 2019-06-27 17:08:49 --> Loader Class Initialized
DEBUG - 2019-06-27 17:08:49 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 17:08:49 --> Helper loaded: url_helper
INFO - 2019-06-27 17:08:49 --> Helper loaded: inflector_helper
INFO - 2019-06-27 17:08:49 --> Helper loaded: string_helper
INFO - 2019-06-27 17:08:49 --> Helper loaded: array_helper
INFO - 2019-06-27 17:08:49 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 17:08:49 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 17:08:49 --> Database Driver Class Initialized
INFO - 2019-06-27 17:08:49 --> Controller Class Initialized
INFO - 2019-06-27 23:08:49 --> Helper loaded: language_helper
INFO - 2019-06-27 23:08:49 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 23:08:49 --> Model Class Initialized
INFO - 2019-06-27 23:08:49 --> Model Class Initialized
INFO - 2019-06-27 23:08:49 --> Model Class Initialized
INFO - 2019-06-27 23:08:49 --> Model Class Initialized
INFO - 2019-06-27 23:08:49 --> Model Class Initialized
INFO - 2019-06-27 23:08:49 --> Final output sent to browser
DEBUG - 2019-06-27 23:08:49 --> Total execution time: 0.3722
INFO - 2019-06-27 17:08:53 --> Config Class Initialized
INFO - 2019-06-27 17:08:53 --> Hooks Class Initialized
DEBUG - 2019-06-27 17:08:53 --> UTF-8 Support Enabled
INFO - 2019-06-27 17:08:53 --> Utf8 Class Initialized
INFO - 2019-06-27 17:08:53 --> URI Class Initialized
INFO - 2019-06-27 17:08:53 --> Router Class Initialized
INFO - 2019-06-27 17:08:53 --> Output Class Initialized
INFO - 2019-06-27 17:08:54 --> Security Class Initialized
DEBUG - 2019-06-27 17:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 17:08:54 --> Input Class Initialized
INFO - 2019-06-27 17:08:54 --> Language Class Initialized
INFO - 2019-06-27 17:08:54 --> Language Class Initialized
INFO - 2019-06-27 17:08:54 --> Config Class Initialized
INFO - 2019-06-27 17:08:54 --> Loader Class Initialized
DEBUG - 2019-06-27 17:08:54 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 17:08:54 --> Helper loaded: url_helper
INFO - 2019-06-27 17:08:54 --> Helper loaded: inflector_helper
INFO - 2019-06-27 17:08:54 --> Helper loaded: string_helper
INFO - 2019-06-27 17:08:54 --> Helper loaded: array_helper
INFO - 2019-06-27 17:08:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 17:08:54 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 17:08:54 --> Database Driver Class Initialized
INFO - 2019-06-27 17:08:54 --> Controller Class Initialized
INFO - 2019-06-27 23:08:54 --> Helper loaded: language_helper
INFO - 2019-06-27 23:08:54 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 23:08:54 --> Model Class Initialized
INFO - 2019-06-27 23:08:54 --> Model Class Initialized
INFO - 2019-06-27 23:08:54 --> Model Class Initialized
INFO - 2019-06-27 23:08:54 --> Model Class Initialized
INFO - 2019-06-27 23:08:54 --> Helper loaded: form_helper
INFO - 2019-06-27 23:08:54 --> Form Validation Class Initialized
DEBUG - 2019-06-27 23:08:54 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-27 23:08:54 --> Model Class Initialized
INFO - 2019-06-27 23:08:54 --> Model Class Initialized
INFO - 2019-06-27 23:08:54 --> Final output sent to browser
DEBUG - 2019-06-27 23:08:54 --> Total execution time: 0.3446
INFO - 2019-06-27 17:08:55 --> Config Class Initialized
INFO - 2019-06-27 17:08:55 --> Hooks Class Initialized
DEBUG - 2019-06-27 17:08:55 --> UTF-8 Support Enabled
INFO - 2019-06-27 17:08:55 --> Utf8 Class Initialized
INFO - 2019-06-27 17:08:55 --> URI Class Initialized
INFO - 2019-06-27 17:08:55 --> Router Class Initialized
INFO - 2019-06-27 17:08:55 --> Output Class Initialized
INFO - 2019-06-27 17:08:55 --> Security Class Initialized
DEBUG - 2019-06-27 17:08:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 17:08:55 --> Input Class Initialized
INFO - 2019-06-27 17:08:55 --> Language Class Initialized
INFO - 2019-06-27 17:08:55 --> Language Class Initialized
INFO - 2019-06-27 17:08:55 --> Config Class Initialized
INFO - 2019-06-27 17:08:55 --> Loader Class Initialized
DEBUG - 2019-06-27 17:08:55 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 17:08:55 --> Helper loaded: url_helper
INFO - 2019-06-27 17:08:55 --> Helper loaded: inflector_helper
INFO - 2019-06-27 17:08:55 --> Helper loaded: string_helper
INFO - 2019-06-27 17:08:55 --> Helper loaded: array_helper
INFO - 2019-06-27 17:08:56 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 17:08:56 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 17:08:56 --> Database Driver Class Initialized
INFO - 2019-06-27 17:08:56 --> Controller Class Initialized
INFO - 2019-06-27 23:08:56 --> Helper loaded: language_helper
INFO - 2019-06-27 23:08:56 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 23:08:56 --> Model Class Initialized
INFO - 2019-06-27 23:08:56 --> Model Class Initialized
INFO - 2019-06-27 23:08:56 --> Model Class Initialized
INFO - 2019-06-27 23:08:56 --> Model Class Initialized
INFO - 2019-06-27 23:08:56 --> Helper loaded: form_helper
INFO - 2019-06-27 23:08:56 --> Form Validation Class Initialized
DEBUG - 2019-06-27 23:08:56 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-27 23:08:56 --> Model Class Initialized
INFO - 2019-06-27 23:08:56 --> Model Class Initialized
INFO - 2019-06-27 23:08:56 --> Final output sent to browser
DEBUG - 2019-06-27 23:08:56 --> Total execution time: 0.3859
INFO - 2019-06-27 17:08:57 --> Config Class Initialized
INFO - 2019-06-27 17:08:57 --> Hooks Class Initialized
DEBUG - 2019-06-27 17:08:57 --> UTF-8 Support Enabled
INFO - 2019-06-27 17:08:57 --> Utf8 Class Initialized
INFO - 2019-06-27 17:08:57 --> URI Class Initialized
INFO - 2019-06-27 17:08:57 --> Router Class Initialized
INFO - 2019-06-27 17:08:57 --> Output Class Initialized
INFO - 2019-06-27 17:08:57 --> Security Class Initialized
DEBUG - 2019-06-27 17:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 17:08:57 --> Input Class Initialized
INFO - 2019-06-27 17:08:57 --> Language Class Initialized
INFO - 2019-06-27 17:08:57 --> Language Class Initialized
INFO - 2019-06-27 17:08:57 --> Config Class Initialized
INFO - 2019-06-27 17:08:57 --> Loader Class Initialized
DEBUG - 2019-06-27 17:08:57 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 17:08:57 --> Helper loaded: url_helper
INFO - 2019-06-27 17:08:57 --> Helper loaded: inflector_helper
INFO - 2019-06-27 17:08:57 --> Helper loaded: string_helper
INFO - 2019-06-27 17:08:57 --> Helper loaded: array_helper
INFO - 2019-06-27 17:08:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 17:08:57 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 17:08:57 --> Database Driver Class Initialized
INFO - 2019-06-27 17:08:57 --> Controller Class Initialized
INFO - 2019-06-27 23:08:57 --> Helper loaded: language_helper
INFO - 2019-06-27 23:08:57 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 23:08:57 --> Model Class Initialized
INFO - 2019-06-27 23:08:57 --> Model Class Initialized
INFO - 2019-06-27 23:08:57 --> Model Class Initialized
INFO - 2019-06-27 23:08:57 --> Model Class Initialized
INFO - 2019-06-27 23:08:57 --> Helper loaded: form_helper
INFO - 2019-06-27 23:08:57 --> Form Validation Class Initialized
DEBUG - 2019-06-27 23:08:57 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-27 23:08:57 --> Model Class Initialized
INFO - 2019-06-27 23:08:57 --> Model Class Initialized
INFO - 2019-06-27 23:08:57 --> Final output sent to browser
DEBUG - 2019-06-27 23:08:57 --> Total execution time: 0.4548
INFO - 2019-06-27 17:08:58 --> Config Class Initialized
INFO - 2019-06-27 17:08:58 --> Hooks Class Initialized
DEBUG - 2019-06-27 17:08:58 --> UTF-8 Support Enabled
INFO - 2019-06-27 17:08:58 --> Utf8 Class Initialized
INFO - 2019-06-27 17:08:58 --> URI Class Initialized
INFO - 2019-06-27 17:08:58 --> Router Class Initialized
INFO - 2019-06-27 17:08:58 --> Output Class Initialized
INFO - 2019-06-27 17:08:58 --> Security Class Initialized
DEBUG - 2019-06-27 17:08:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 17:08:58 --> Input Class Initialized
INFO - 2019-06-27 17:08:58 --> Language Class Initialized
INFO - 2019-06-27 17:08:58 --> Language Class Initialized
INFO - 2019-06-27 17:08:58 --> Config Class Initialized
INFO - 2019-06-27 17:08:58 --> Loader Class Initialized
DEBUG - 2019-06-27 17:08:58 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 17:08:58 --> Helper loaded: url_helper
INFO - 2019-06-27 17:08:58 --> Helper loaded: inflector_helper
INFO - 2019-06-27 17:08:58 --> Helper loaded: string_helper
INFO - 2019-06-27 17:08:58 --> Helper loaded: array_helper
INFO - 2019-06-27 17:08:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 17:08:58 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 17:08:58 --> Database Driver Class Initialized
INFO - 2019-06-27 17:08:58 --> Controller Class Initialized
INFO - 2019-06-27 23:08:58 --> Helper loaded: language_helper
INFO - 2019-06-27 23:08:58 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 23:08:58 --> Model Class Initialized
INFO - 2019-06-27 23:08:58 --> Model Class Initialized
INFO - 2019-06-27 23:08:58 --> Model Class Initialized
INFO - 2019-06-27 23:08:58 --> Model Class Initialized
INFO - 2019-06-27 23:08:58 --> Helper loaded: form_helper
INFO - 2019-06-27 23:08:58 --> Form Validation Class Initialized
DEBUG - 2019-06-27 23:08:58 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-27 23:08:58 --> Model Class Initialized
INFO - 2019-06-27 23:08:58 --> Model Class Initialized
INFO - 2019-06-27 23:08:58 --> Final output sent to browser
DEBUG - 2019-06-27 23:08:58 --> Total execution time: 0.5085
INFO - 2019-06-27 17:08:59 --> Config Class Initialized
INFO - 2019-06-27 17:08:59 --> Hooks Class Initialized
DEBUG - 2019-06-27 17:08:59 --> UTF-8 Support Enabled
INFO - 2019-06-27 17:08:59 --> Utf8 Class Initialized
INFO - 2019-06-27 17:08:59 --> URI Class Initialized
INFO - 2019-06-27 17:08:59 --> Router Class Initialized
INFO - 2019-06-27 17:08:59 --> Output Class Initialized
INFO - 2019-06-27 17:08:59 --> Security Class Initialized
DEBUG - 2019-06-27 17:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 17:08:59 --> Input Class Initialized
INFO - 2019-06-27 17:08:59 --> Language Class Initialized
INFO - 2019-06-27 17:08:59 --> Language Class Initialized
INFO - 2019-06-27 17:08:59 --> Config Class Initialized
INFO - 2019-06-27 17:08:59 --> Loader Class Initialized
DEBUG - 2019-06-27 17:08:59 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 17:08:59 --> Helper loaded: url_helper
INFO - 2019-06-27 17:08:59 --> Helper loaded: inflector_helper
INFO - 2019-06-27 17:08:59 --> Helper loaded: string_helper
INFO - 2019-06-27 17:08:59 --> Helper loaded: array_helper
INFO - 2019-06-27 17:08:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 17:08:59 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 17:08:59 --> Database Driver Class Initialized
INFO - 2019-06-27 17:08:59 --> Controller Class Initialized
INFO - 2019-06-27 23:09:00 --> Helper loaded: language_helper
INFO - 2019-06-27 23:09:00 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 23:09:00 --> Model Class Initialized
INFO - 2019-06-27 23:09:00 --> Model Class Initialized
INFO - 2019-06-27 23:09:00 --> Model Class Initialized
INFO - 2019-06-27 23:09:00 --> Model Class Initialized
INFO - 2019-06-27 23:09:00 --> Helper loaded: form_helper
INFO - 2019-06-27 23:09:00 --> Form Validation Class Initialized
DEBUG - 2019-06-27 23:09:00 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-27 23:09:00 --> Model Class Initialized
INFO - 2019-06-27 23:09:00 --> Model Class Initialized
INFO - 2019-06-27 23:09:00 --> Final output sent to browser
DEBUG - 2019-06-27 23:09:00 --> Total execution time: 0.3533
INFO - 2019-06-27 17:09:00 --> Config Class Initialized
INFO - 2019-06-27 17:09:00 --> Hooks Class Initialized
DEBUG - 2019-06-27 17:09:00 --> UTF-8 Support Enabled
INFO - 2019-06-27 17:09:00 --> Utf8 Class Initialized
INFO - 2019-06-27 17:09:00 --> URI Class Initialized
INFO - 2019-06-27 17:09:00 --> Router Class Initialized
INFO - 2019-06-27 17:09:00 --> Output Class Initialized
INFO - 2019-06-27 17:09:00 --> Security Class Initialized
DEBUG - 2019-06-27 17:09:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 17:09:01 --> Input Class Initialized
INFO - 2019-06-27 17:09:01 --> Language Class Initialized
INFO - 2019-06-27 17:09:01 --> Language Class Initialized
INFO - 2019-06-27 17:09:01 --> Config Class Initialized
INFO - 2019-06-27 17:09:01 --> Loader Class Initialized
DEBUG - 2019-06-27 17:09:01 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 17:09:01 --> Helper loaded: url_helper
INFO - 2019-06-27 17:09:01 --> Helper loaded: inflector_helper
INFO - 2019-06-27 17:09:01 --> Helper loaded: string_helper
INFO - 2019-06-27 17:09:01 --> Helper loaded: array_helper
INFO - 2019-06-27 17:09:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 17:09:01 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 17:09:01 --> Database Driver Class Initialized
INFO - 2019-06-27 17:09:01 --> Controller Class Initialized
INFO - 2019-06-27 23:09:01 --> Helper loaded: language_helper
INFO - 2019-06-27 23:09:01 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 23:09:01 --> Model Class Initialized
INFO - 2019-06-27 23:09:01 --> Model Class Initialized
INFO - 2019-06-27 23:09:01 --> Model Class Initialized
INFO - 2019-06-27 23:09:01 --> Model Class Initialized
INFO - 2019-06-27 23:09:01 --> Helper loaded: form_helper
INFO - 2019-06-27 23:09:01 --> Form Validation Class Initialized
DEBUG - 2019-06-27 23:09:01 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-27 23:09:01 --> Model Class Initialized
INFO - 2019-06-27 23:09:01 --> Model Class Initialized
INFO - 2019-06-27 23:09:01 --> Final output sent to browser
DEBUG - 2019-06-27 23:09:01 --> Total execution time: 0.3504
INFO - 2019-06-27 17:09:02 --> Config Class Initialized
INFO - 2019-06-27 17:09:02 --> Hooks Class Initialized
DEBUG - 2019-06-27 17:09:02 --> UTF-8 Support Enabled
INFO - 2019-06-27 17:09:02 --> Utf8 Class Initialized
INFO - 2019-06-27 17:09:02 --> URI Class Initialized
INFO - 2019-06-27 17:09:02 --> Router Class Initialized
INFO - 2019-06-27 17:09:02 --> Output Class Initialized
INFO - 2019-06-27 17:09:02 --> Security Class Initialized
DEBUG - 2019-06-27 17:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 17:09:02 --> Input Class Initialized
INFO - 2019-06-27 17:09:02 --> Language Class Initialized
INFO - 2019-06-27 17:09:02 --> Language Class Initialized
INFO - 2019-06-27 17:09:02 --> Config Class Initialized
INFO - 2019-06-27 17:09:02 --> Loader Class Initialized
DEBUG - 2019-06-27 17:09:02 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 17:09:02 --> Helper loaded: url_helper
INFO - 2019-06-27 17:09:02 --> Helper loaded: inflector_helper
INFO - 2019-06-27 17:09:02 --> Helper loaded: string_helper
INFO - 2019-06-27 17:09:02 --> Helper loaded: array_helper
INFO - 2019-06-27 17:09:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 17:09:02 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 17:09:02 --> Database Driver Class Initialized
INFO - 2019-06-27 17:09:02 --> Controller Class Initialized
INFO - 2019-06-27 23:09:02 --> Helper loaded: language_helper
INFO - 2019-06-27 23:09:02 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 23:09:02 --> Model Class Initialized
INFO - 2019-06-27 23:09:02 --> Model Class Initialized
INFO - 2019-06-27 23:09:02 --> Model Class Initialized
INFO - 2019-06-27 23:09:02 --> Model Class Initialized
INFO - 2019-06-27 23:09:02 --> Helper loaded: form_helper
INFO - 2019-06-27 23:09:02 --> Form Validation Class Initialized
DEBUG - 2019-06-27 23:09:02 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-27 23:09:02 --> Model Class Initialized
INFO - 2019-06-27 23:09:02 --> Model Class Initialized
INFO - 2019-06-27 23:09:02 --> Final output sent to browser
DEBUG - 2019-06-27 23:09:02 --> Total execution time: 0.3758
INFO - 2019-06-27 17:09:03 --> Config Class Initialized
INFO - 2019-06-27 17:09:03 --> Hooks Class Initialized
DEBUG - 2019-06-27 17:09:03 --> UTF-8 Support Enabled
INFO - 2019-06-27 17:09:03 --> Utf8 Class Initialized
INFO - 2019-06-27 17:09:03 --> URI Class Initialized
INFO - 2019-06-27 17:09:03 --> Router Class Initialized
INFO - 2019-06-27 17:09:03 --> Output Class Initialized
INFO - 2019-06-27 17:09:03 --> Security Class Initialized
DEBUG - 2019-06-27 17:09:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 17:09:03 --> Input Class Initialized
INFO - 2019-06-27 17:09:03 --> Language Class Initialized
INFO - 2019-06-27 17:09:03 --> Language Class Initialized
INFO - 2019-06-27 17:09:03 --> Config Class Initialized
INFO - 2019-06-27 17:09:03 --> Loader Class Initialized
DEBUG - 2019-06-27 17:09:03 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 17:09:03 --> Helper loaded: url_helper
INFO - 2019-06-27 17:09:03 --> Helper loaded: inflector_helper
INFO - 2019-06-27 17:09:03 --> Helper loaded: string_helper
INFO - 2019-06-27 17:09:03 --> Helper loaded: array_helper
INFO - 2019-06-27 17:09:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 17:09:03 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 17:09:03 --> Database Driver Class Initialized
INFO - 2019-06-27 17:09:03 --> Controller Class Initialized
INFO - 2019-06-27 23:09:03 --> Helper loaded: language_helper
INFO - 2019-06-27 23:09:03 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 23:09:03 --> Model Class Initialized
INFO - 2019-06-27 23:09:03 --> Model Class Initialized
INFO - 2019-06-27 23:09:03 --> Model Class Initialized
INFO - 2019-06-27 23:09:03 --> Model Class Initialized
INFO - 2019-06-27 23:09:03 --> Helper loaded: form_helper
INFO - 2019-06-27 23:09:03 --> Form Validation Class Initialized
DEBUG - 2019-06-27 23:09:03 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-27 23:09:03 --> Model Class Initialized
INFO - 2019-06-27 23:09:03 --> Model Class Initialized
INFO - 2019-06-27 23:09:03 --> Final output sent to browser
DEBUG - 2019-06-27 23:09:03 --> Total execution time: 0.3529
INFO - 2019-06-27 17:09:03 --> Config Class Initialized
INFO - 2019-06-27 17:09:03 --> Hooks Class Initialized
DEBUG - 2019-06-27 17:09:04 --> UTF-8 Support Enabled
INFO - 2019-06-27 17:09:04 --> Utf8 Class Initialized
INFO - 2019-06-27 17:09:04 --> URI Class Initialized
INFO - 2019-06-27 17:09:04 --> Router Class Initialized
INFO - 2019-06-27 17:09:04 --> Output Class Initialized
INFO - 2019-06-27 17:09:04 --> Security Class Initialized
DEBUG - 2019-06-27 17:09:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 17:09:04 --> Input Class Initialized
INFO - 2019-06-27 17:09:04 --> Language Class Initialized
INFO - 2019-06-27 17:09:04 --> Language Class Initialized
INFO - 2019-06-27 17:09:04 --> Config Class Initialized
INFO - 2019-06-27 17:09:04 --> Loader Class Initialized
DEBUG - 2019-06-27 17:09:04 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 17:09:04 --> Helper loaded: url_helper
INFO - 2019-06-27 17:09:04 --> Helper loaded: inflector_helper
INFO - 2019-06-27 17:09:04 --> Helper loaded: string_helper
INFO - 2019-06-27 17:09:04 --> Helper loaded: array_helper
INFO - 2019-06-27 17:09:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 17:09:04 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 17:09:04 --> Database Driver Class Initialized
INFO - 2019-06-27 17:09:04 --> Controller Class Initialized
INFO - 2019-06-27 23:09:04 --> Helper loaded: language_helper
INFO - 2019-06-27 23:09:04 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 23:09:04 --> Model Class Initialized
INFO - 2019-06-27 23:09:04 --> Model Class Initialized
INFO - 2019-06-27 23:09:04 --> Model Class Initialized
INFO - 2019-06-27 23:09:04 --> Model Class Initialized
INFO - 2019-06-27 23:09:04 --> Model Class Initialized
INFO - 2019-06-27 23:09:04 --> Final output sent to browser
DEBUG - 2019-06-27 23:09:04 --> Total execution time: 0.3549
INFO - 2019-06-27 17:09:06 --> Config Class Initialized
INFO - 2019-06-27 17:09:06 --> Hooks Class Initialized
DEBUG - 2019-06-27 17:09:06 --> UTF-8 Support Enabled
INFO - 2019-06-27 17:09:06 --> Utf8 Class Initialized
INFO - 2019-06-27 17:09:06 --> URI Class Initialized
INFO - 2019-06-27 17:09:06 --> Router Class Initialized
INFO - 2019-06-27 17:09:06 --> Output Class Initialized
INFO - 2019-06-27 17:09:06 --> Security Class Initialized
DEBUG - 2019-06-27 17:09:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 17:09:06 --> Input Class Initialized
INFO - 2019-06-27 17:09:06 --> Language Class Initialized
INFO - 2019-06-27 17:09:06 --> Language Class Initialized
INFO - 2019-06-27 17:09:06 --> Config Class Initialized
INFO - 2019-06-27 17:09:06 --> Loader Class Initialized
DEBUG - 2019-06-27 17:09:06 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 17:09:06 --> Helper loaded: url_helper
INFO - 2019-06-27 17:09:06 --> Helper loaded: inflector_helper
INFO - 2019-06-27 17:09:06 --> Helper loaded: string_helper
INFO - 2019-06-27 17:09:06 --> Helper loaded: array_helper
INFO - 2019-06-27 17:09:06 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 17:09:06 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 17:09:06 --> Database Driver Class Initialized
INFO - 2019-06-27 17:09:06 --> Controller Class Initialized
INFO - 2019-06-27 23:09:06 --> Helper loaded: language_helper
INFO - 2019-06-27 23:09:06 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 23:09:06 --> Model Class Initialized
INFO - 2019-06-27 23:09:06 --> Model Class Initialized
INFO - 2019-06-27 23:09:07 --> Model Class Initialized
INFO - 2019-06-27 23:09:07 --> Model Class Initialized
INFO - 2019-06-27 23:09:07 --> Helper loaded: form_helper
INFO - 2019-06-27 23:09:07 --> Form Validation Class Initialized
DEBUG - 2019-06-27 23:09:07 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-27 23:09:07 --> Model Class Initialized
INFO - 2019-06-27 23:09:07 --> Model Class Initialized
INFO - 2019-06-27 23:09:07 --> Final output sent to browser
DEBUG - 2019-06-27 23:09:07 --> Total execution time: 0.4369
INFO - 2019-06-27 17:09:10 --> Config Class Initialized
INFO - 2019-06-27 17:09:10 --> Hooks Class Initialized
DEBUG - 2019-06-27 17:09:10 --> UTF-8 Support Enabled
INFO - 2019-06-27 17:09:10 --> Utf8 Class Initialized
INFO - 2019-06-27 17:09:10 --> URI Class Initialized
INFO - 2019-06-27 17:09:10 --> Router Class Initialized
INFO - 2019-06-27 17:09:10 --> Output Class Initialized
INFO - 2019-06-27 17:09:10 --> Security Class Initialized
DEBUG - 2019-06-27 17:09:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 17:09:10 --> Input Class Initialized
INFO - 2019-06-27 17:09:10 --> Language Class Initialized
INFO - 2019-06-27 17:09:10 --> Language Class Initialized
INFO - 2019-06-27 17:09:10 --> Config Class Initialized
INFO - 2019-06-27 17:09:10 --> Loader Class Initialized
DEBUG - 2019-06-27 17:09:10 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 17:09:10 --> Helper loaded: url_helper
INFO - 2019-06-27 17:09:10 --> Helper loaded: inflector_helper
INFO - 2019-06-27 17:09:10 --> Helper loaded: string_helper
INFO - 2019-06-27 17:09:10 --> Helper loaded: array_helper
INFO - 2019-06-27 17:09:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 17:09:10 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 17:09:10 --> Database Driver Class Initialized
INFO - 2019-06-27 17:09:10 --> Controller Class Initialized
INFO - 2019-06-27 23:09:10 --> Helper loaded: language_helper
INFO - 2019-06-27 23:09:10 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 23:09:10 --> Model Class Initialized
INFO - 2019-06-27 23:09:10 --> Model Class Initialized
INFO - 2019-06-27 23:09:10 --> Model Class Initialized
INFO - 2019-06-27 23:09:10 --> Model Class Initialized
INFO - 2019-06-27 23:09:10 --> Model Class Initialized
INFO - 2019-06-27 23:09:10 --> Final output sent to browser
DEBUG - 2019-06-27 23:09:10 --> Total execution time: 0.3995
INFO - 2019-06-27 17:09:17 --> Config Class Initialized
INFO - 2019-06-27 17:09:17 --> Hooks Class Initialized
DEBUG - 2019-06-27 17:09:17 --> UTF-8 Support Enabled
INFO - 2019-06-27 17:09:17 --> Utf8 Class Initialized
INFO - 2019-06-27 17:09:17 --> URI Class Initialized
INFO - 2019-06-27 17:09:17 --> Router Class Initialized
INFO - 2019-06-27 17:09:17 --> Output Class Initialized
INFO - 2019-06-27 17:09:17 --> Security Class Initialized
DEBUG - 2019-06-27 17:09:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 17:09:17 --> Input Class Initialized
INFO - 2019-06-27 17:09:17 --> Language Class Initialized
INFO - 2019-06-27 17:09:17 --> Language Class Initialized
INFO - 2019-06-27 17:09:17 --> Config Class Initialized
INFO - 2019-06-27 17:09:17 --> Loader Class Initialized
DEBUG - 2019-06-27 17:09:17 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 17:09:17 --> Helper loaded: url_helper
INFO - 2019-06-27 17:09:17 --> Helper loaded: inflector_helper
INFO - 2019-06-27 17:09:17 --> Helper loaded: string_helper
INFO - 2019-06-27 17:09:17 --> Helper loaded: array_helper
INFO - 2019-06-27 17:09:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 17:09:17 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 17:09:17 --> Database Driver Class Initialized
INFO - 2019-06-27 17:09:17 --> Controller Class Initialized
INFO - 2019-06-27 23:09:17 --> Helper loaded: language_helper
INFO - 2019-06-27 23:09:17 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 23:09:17 --> Model Class Initialized
INFO - 2019-06-27 23:09:17 --> Model Class Initialized
INFO - 2019-06-27 23:09:17 --> Model Class Initialized
INFO - 2019-06-27 23:09:18 --> Model Class Initialized
INFO - 2019-06-27 23:09:18 --> Helper loaded: form_helper
INFO - 2019-06-27 23:09:18 --> Form Validation Class Initialized
DEBUG - 2019-06-27 23:09:18 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-27 23:09:18 --> Model Class Initialized
INFO - 2019-06-27 23:09:18 --> Model Class Initialized
INFO - 2019-06-27 23:09:18 --> Final output sent to browser
DEBUG - 2019-06-27 23:09:18 --> Total execution time: 0.3452
INFO - 2019-06-27 17:09:25 --> Config Class Initialized
INFO - 2019-06-27 17:09:25 --> Hooks Class Initialized
DEBUG - 2019-06-27 17:09:25 --> UTF-8 Support Enabled
INFO - 2019-06-27 17:09:25 --> Utf8 Class Initialized
INFO - 2019-06-27 17:09:25 --> URI Class Initialized
INFO - 2019-06-27 17:09:25 --> Router Class Initialized
INFO - 2019-06-27 17:09:25 --> Output Class Initialized
INFO - 2019-06-27 17:09:25 --> Security Class Initialized
DEBUG - 2019-06-27 17:09:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 17:09:25 --> Input Class Initialized
INFO - 2019-06-27 17:09:25 --> Language Class Initialized
INFO - 2019-06-27 17:09:25 --> Language Class Initialized
INFO - 2019-06-27 17:09:25 --> Config Class Initialized
INFO - 2019-06-27 17:09:25 --> Loader Class Initialized
DEBUG - 2019-06-27 17:09:25 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 17:09:25 --> Helper loaded: url_helper
INFO - 2019-06-27 17:09:25 --> Helper loaded: inflector_helper
INFO - 2019-06-27 17:09:25 --> Helper loaded: string_helper
INFO - 2019-06-27 17:09:25 --> Helper loaded: array_helper
INFO - 2019-06-27 17:09:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 17:09:25 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 17:09:25 --> Database Driver Class Initialized
INFO - 2019-06-27 17:09:25 --> Controller Class Initialized
INFO - 2019-06-27 23:09:25 --> Helper loaded: language_helper
INFO - 2019-06-27 23:09:25 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 23:09:25 --> Model Class Initialized
INFO - 2019-06-27 23:09:25 --> Model Class Initialized
INFO - 2019-06-27 23:09:25 --> Model Class Initialized
INFO - 2019-06-27 23:09:25 --> Model Class Initialized
INFO - 2019-06-27 23:09:25 --> Helper loaded: form_helper
INFO - 2019-06-27 23:09:25 --> Form Validation Class Initialized
DEBUG - 2019-06-27 23:09:25 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-27 23:09:25 --> Model Class Initialized
INFO - 2019-06-27 23:09:25 --> Model Class Initialized
INFO - 2019-06-27 23:09:25 --> Final output sent to browser
DEBUG - 2019-06-27 23:09:25 --> Total execution time: 0.3481
INFO - 2019-06-27 17:11:53 --> Config Class Initialized
INFO - 2019-06-27 17:11:53 --> Hooks Class Initialized
DEBUG - 2019-06-27 17:11:53 --> UTF-8 Support Enabled
INFO - 2019-06-27 17:11:53 --> Utf8 Class Initialized
INFO - 2019-06-27 17:11:53 --> URI Class Initialized
INFO - 2019-06-27 17:11:53 --> Router Class Initialized
INFO - 2019-06-27 17:11:53 --> Output Class Initialized
INFO - 2019-06-27 17:11:53 --> Security Class Initialized
DEBUG - 2019-06-27 17:11:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-27 17:11:53 --> Input Class Initialized
INFO - 2019-06-27 17:11:53 --> Language Class Initialized
INFO - 2019-06-27 17:11:53 --> Language Class Initialized
INFO - 2019-06-27 17:11:53 --> Config Class Initialized
INFO - 2019-06-27 17:11:53 --> Loader Class Initialized
DEBUG - 2019-06-27 17:11:53 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-27 17:11:53 --> Helper loaded: url_helper
INFO - 2019-06-27 17:11:53 --> Helper loaded: inflector_helper
INFO - 2019-06-27 17:11:53 --> Helper loaded: string_helper
INFO - 2019-06-27 17:11:53 --> Helper loaded: array_helper
INFO - 2019-06-27 17:11:53 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-27 17:11:53 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-27 17:11:53 --> Database Driver Class Initialized
INFO - 2019-06-27 17:11:53 --> Controller Class Initialized
INFO - 2019-06-27 23:11:53 --> Helper loaded: language_helper
INFO - 2019-06-27 23:11:53 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-27 23:11:53 --> Model Class Initialized
INFO - 2019-06-27 23:11:53 --> Model Class Initialized
INFO - 2019-06-27 23:11:53 --> Model Class Initialized
INFO - 2019-06-27 23:11:53 --> Model Class Initialized
INFO - 2019-06-27 23:11:53 --> Helper loaded: form_helper
INFO - 2019-06-27 23:11:53 --> Form Validation Class Initialized
DEBUG - 2019-06-27 23:11:53 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-27 23:11:53 --> Model Class Initialized
INFO - 2019-06-27 23:11:53 --> Model Class Initialized
INFO - 2019-06-27 23:11:53 --> Final output sent to browser
DEBUG - 2019-06-27 23:11:53 --> Total execution time: 0.3932
