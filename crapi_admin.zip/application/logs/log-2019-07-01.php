<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-07-01 13:03:59 --> Config Class Initialized
INFO - 2019-07-01 13:03:59 --> Hooks Class Initialized
DEBUG - 2019-07-01 13:04:00 --> UTF-8 Support Enabled
INFO - 2019-07-01 13:04:00 --> Utf8 Class Initialized
INFO - 2019-07-01 13:04:00 --> URI Class Initialized
INFO - 2019-07-01 13:04:00 --> Router Class Initialized
INFO - 2019-07-01 13:04:00 --> Output Class Initialized
INFO - 2019-07-01 13:04:00 --> Security Class Initialized
DEBUG - 2019-07-01 13:04:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 13:04:00 --> Input Class Initialized
INFO - 2019-07-01 13:04:00 --> Language Class Initialized
INFO - 2019-07-01 13:04:00 --> Language Class Initialized
INFO - 2019-07-01 13:04:00 --> Config Class Initialized
INFO - 2019-07-01 13:04:00 --> Loader Class Initialized
DEBUG - 2019-07-01 13:04:00 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 13:04:00 --> Helper loaded: url_helper
INFO - 2019-07-01 13:04:00 --> Helper loaded: inflector_helper
INFO - 2019-07-01 13:04:00 --> Helper loaded: string_helper
INFO - 2019-07-01 13:04:00 --> Helper loaded: array_helper
INFO - 2019-07-01 13:04:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 13:04:00 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 13:04:00 --> Database Driver Class Initialized
INFO - 2019-07-01 13:04:00 --> Controller Class Initialized
INFO - 2019-07-01 19:04:00 --> Helper loaded: language_helper
INFO - 2019-07-01 19:04:00 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 19:04:00 --> Model Class Initialized
INFO - 2019-07-01 19:04:00 --> Model Class Initialized
INFO - 2019-07-01 19:04:00 --> Model Class Initialized
INFO - 2019-07-01 19:04:00 --> Model Class Initialized
INFO - 2019-07-01 19:04:00 --> Final output sent to browser
DEBUG - 2019-07-01 19:04:00 --> Total execution time: 1.0365
INFO - 2019-07-01 13:04:01 --> Config Class Initialized
INFO - 2019-07-01 13:04:01 --> Hooks Class Initialized
DEBUG - 2019-07-01 13:04:01 --> UTF-8 Support Enabled
INFO - 2019-07-01 13:04:01 --> Utf8 Class Initialized
INFO - 2019-07-01 13:04:01 --> URI Class Initialized
INFO - 2019-07-01 13:04:01 --> Router Class Initialized
INFO - 2019-07-01 13:04:01 --> Output Class Initialized
INFO - 2019-07-01 13:04:01 --> Security Class Initialized
DEBUG - 2019-07-01 13:04:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 13:04:01 --> Input Class Initialized
INFO - 2019-07-01 13:04:01 --> Language Class Initialized
INFO - 2019-07-01 13:04:01 --> Language Class Initialized
INFO - 2019-07-01 13:04:01 --> Config Class Initialized
INFO - 2019-07-01 13:04:01 --> Loader Class Initialized
DEBUG - 2019-07-01 13:04:01 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 13:04:01 --> Helper loaded: url_helper
INFO - 2019-07-01 13:04:01 --> Helper loaded: inflector_helper
INFO - 2019-07-01 13:04:01 --> Helper loaded: string_helper
INFO - 2019-07-01 13:04:01 --> Helper loaded: array_helper
INFO - 2019-07-01 13:04:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 13:04:01 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 13:04:01 --> Database Driver Class Initialized
INFO - 2019-07-01 13:04:01 --> Controller Class Initialized
INFO - 2019-07-01 19:04:01 --> Helper loaded: language_helper
INFO - 2019-07-01 19:04:01 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 19:04:01 --> Model Class Initialized
INFO - 2019-07-01 19:04:01 --> Model Class Initialized
INFO - 2019-07-01 19:04:01 --> Model Class Initialized
INFO - 2019-07-01 19:04:01 --> Model Class Initialized
INFO - 2019-07-01 19:04:01 --> Model Class Initialized
INFO - 2019-07-01 19:04:01 --> Final output sent to browser
DEBUG - 2019-07-01 19:04:01 --> Total execution time: 0.3328
INFO - 2019-07-01 13:08:49 --> Config Class Initialized
INFO - 2019-07-01 13:08:49 --> Hooks Class Initialized
DEBUG - 2019-07-01 13:08:49 --> UTF-8 Support Enabled
INFO - 2019-07-01 13:08:49 --> Utf8 Class Initialized
INFO - 2019-07-01 13:08:49 --> URI Class Initialized
INFO - 2019-07-01 13:08:49 --> Router Class Initialized
INFO - 2019-07-01 13:08:49 --> Output Class Initialized
INFO - 2019-07-01 13:08:49 --> Security Class Initialized
DEBUG - 2019-07-01 13:08:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 13:08:49 --> Input Class Initialized
INFO - 2019-07-01 13:08:49 --> Language Class Initialized
INFO - 2019-07-01 13:08:49 --> Language Class Initialized
INFO - 2019-07-01 13:08:49 --> Config Class Initialized
INFO - 2019-07-01 13:08:49 --> Loader Class Initialized
DEBUG - 2019-07-01 13:08:49 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 13:08:49 --> Helper loaded: url_helper
INFO - 2019-07-01 13:08:49 --> Helper loaded: inflector_helper
INFO - 2019-07-01 13:08:49 --> Helper loaded: string_helper
INFO - 2019-07-01 13:08:49 --> Helper loaded: array_helper
INFO - 2019-07-01 13:08:49 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 13:08:49 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 13:08:49 --> Database Driver Class Initialized
INFO - 2019-07-01 13:08:49 --> Controller Class Initialized
INFO - 2019-07-01 19:08:49 --> Helper loaded: language_helper
INFO - 2019-07-01 19:08:49 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 19:08:49 --> Model Class Initialized
INFO - 2019-07-01 19:08:49 --> Model Class Initialized
INFO - 2019-07-01 19:08:49 --> Model Class Initialized
INFO - 2019-07-01 19:08:49 --> Model Class Initialized
INFO - 2019-07-01 19:08:49 --> Final output sent to browser
DEBUG - 2019-07-01 19:08:49 --> Total execution time: 0.6200
INFO - 2019-07-01 13:10:19 --> Config Class Initialized
INFO - 2019-07-01 13:10:19 --> Hooks Class Initialized
DEBUG - 2019-07-01 13:10:19 --> UTF-8 Support Enabled
INFO - 2019-07-01 13:10:19 --> Utf8 Class Initialized
INFO - 2019-07-01 13:10:19 --> URI Class Initialized
DEBUG - 2019-07-01 13:10:19 --> No URI present. Default controller set.
INFO - 2019-07-01 13:10:19 --> Router Class Initialized
INFO - 2019-07-01 13:10:19 --> Output Class Initialized
INFO - 2019-07-01 13:10:19 --> Security Class Initialized
DEBUG - 2019-07-01 13:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 13:10:19 --> Input Class Initialized
INFO - 2019-07-01 13:10:19 --> Language Class Initialized
INFO - 2019-07-01 13:10:21 --> Final output sent to browser
DEBUG - 2019-07-01 13:10:21 --> Total execution time: 1.9711
INFO - 2019-07-01 13:10:21 --> Config Class Initialized
INFO - 2019-07-01 13:10:21 --> Hooks Class Initialized
DEBUG - 2019-07-01 13:10:21 --> UTF-8 Support Enabled
INFO - 2019-07-01 13:10:21 --> Utf8 Class Initialized
INFO - 2019-07-01 13:10:21 --> URI Class Initialized
DEBUG - 2019-07-01 13:10:21 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/routes.php
INFO - 2019-07-01 13:10:22 --> Router Class Initialized
INFO - 2019-07-01 13:10:22 --> Output Class Initialized
INFO - 2019-07-01 13:10:22 --> Security Class Initialized
DEBUG - 2019-07-01 13:10:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 13:10:22 --> Input Class Initialized
INFO - 2019-07-01 13:10:22 --> Language Class Initialized
INFO - 2019-07-01 13:10:22 --> Language Class Initialized
INFO - 2019-07-01 13:10:22 --> Config Class Initialized
INFO - 2019-07-01 13:10:22 --> Loader Class Initialized
DEBUG - 2019-07-01 13:10:22 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/site.php
INFO - 2019-07-01 13:10:22 --> Helper loaded: url_helper
INFO - 2019-07-01 13:10:22 --> Helper loaded: inflector_helper
INFO - 2019-07-01 13:10:22 --> Helper loaded: string_helper
INFO - 2019-07-01 13:10:22 --> Helper loaded: array_helper
INFO - 2019-07-01 13:10:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 13:10:22 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/autoload.php
DEBUG - 2019-07-01 13:10:22 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/helpers/adminlte_helper.php
INFO - 2019-07-01 13:10:22 --> Database Driver Class Initialized
DEBUG - 2019-07-01 13:10:22 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/libraries/Crud.php
INFO - 2019-07-01 13:10:22 --> Helper loaded: form_helper
DEBUG - 2019-07-01 13:10:22 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-07-01 13:10:22 --> Form Validation Class Initialized
DEBUG - 2019-07-01 13:10:22 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-07-01 13:10:22 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-07-01 13:10:22 --> Pagination Class Initialized
INFO - 2019-07-01 13:10:22 --> Controller Class Initialized
INFO - 2019-07-01 19:10:22 --> Final output sent to browser
DEBUG - 2019-07-01 19:10:22 --> Total execution time: 0.9468
INFO - 2019-07-01 13:10:22 --> Config Class Initialized
INFO - 2019-07-01 13:10:22 --> Hooks Class Initialized
DEBUG - 2019-07-01 13:10:22 --> UTF-8 Support Enabled
INFO - 2019-07-01 13:10:22 --> Utf8 Class Initialized
INFO - 2019-07-01 13:10:22 --> URI Class Initialized
DEBUG - 2019-07-01 13:10:22 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/routes.php
INFO - 2019-07-01 13:10:23 --> Router Class Initialized
INFO - 2019-07-01 13:10:23 --> Output Class Initialized
INFO - 2019-07-01 13:10:23 --> Security Class Initialized
DEBUG - 2019-07-01 13:10:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 13:10:23 --> Input Class Initialized
INFO - 2019-07-01 13:10:23 --> Language Class Initialized
INFO - 2019-07-01 13:10:23 --> Language Class Initialized
INFO - 2019-07-01 13:10:23 --> Config Class Initialized
INFO - 2019-07-01 13:10:23 --> Loader Class Initialized
DEBUG - 2019-07-01 13:10:23 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/site.php
INFO - 2019-07-01 13:10:23 --> Helper loaded: url_helper
INFO - 2019-07-01 13:10:23 --> Helper loaded: inflector_helper
INFO - 2019-07-01 13:10:23 --> Helper loaded: string_helper
INFO - 2019-07-01 13:10:23 --> Helper loaded: array_helper
INFO - 2019-07-01 13:10:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 13:10:23 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/autoload.php
DEBUG - 2019-07-01 13:10:23 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/helpers/adminlte_helper.php
INFO - 2019-07-01 13:10:23 --> Database Driver Class Initialized
DEBUG - 2019-07-01 13:10:23 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/libraries/Crud.php
INFO - 2019-07-01 13:10:23 --> Helper loaded: form_helper
DEBUG - 2019-07-01 13:10:23 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-07-01 13:10:23 --> Form Validation Class Initialized
DEBUG - 2019-07-01 13:10:23 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-07-01 13:10:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-07-01 13:10:23 --> Pagination Class Initialized
INFO - 2019-07-01 13:10:23 --> Controller Class Initialized
INFO - 2019-07-01 19:10:23 --> Final output sent to browser
DEBUG - 2019-07-01 19:10:23 --> Total execution time: 0.5462
INFO - 2019-07-01 13:10:24 --> Config Class Initialized
INFO - 2019-07-01 13:10:24 --> Hooks Class Initialized
DEBUG - 2019-07-01 13:10:24 --> UTF-8 Support Enabled
INFO - 2019-07-01 13:10:24 --> Utf8 Class Initialized
INFO - 2019-07-01 13:10:24 --> URI Class Initialized
DEBUG - 2019-07-01 13:10:24 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/routes.php
INFO - 2019-07-01 13:10:24 --> Router Class Initialized
INFO - 2019-07-01 13:10:24 --> Output Class Initialized
INFO - 2019-07-01 13:10:25 --> Security Class Initialized
DEBUG - 2019-07-01 13:10:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 13:10:25 --> Input Class Initialized
INFO - 2019-07-01 13:10:25 --> Language Class Initialized
INFO - 2019-07-01 13:10:25 --> Language Class Initialized
INFO - 2019-07-01 13:10:25 --> Config Class Initialized
INFO - 2019-07-01 13:10:25 --> Loader Class Initialized
DEBUG - 2019-07-01 13:10:25 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/site.php
INFO - 2019-07-01 13:10:25 --> Helper loaded: url_helper
INFO - 2019-07-01 13:10:25 --> Helper loaded: inflector_helper
INFO - 2019-07-01 13:10:25 --> Helper loaded: string_helper
INFO - 2019-07-01 13:10:25 --> Helper loaded: array_helper
INFO - 2019-07-01 13:10:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 13:10:25 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/autoload.php
DEBUG - 2019-07-01 13:10:25 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/helpers/adminlte_helper.php
INFO - 2019-07-01 13:10:25 --> Database Driver Class Initialized
DEBUG - 2019-07-01 13:10:25 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/libraries/Crud.php
INFO - 2019-07-01 13:10:25 --> Helper loaded: form_helper
DEBUG - 2019-07-01 13:10:25 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-07-01 13:10:25 --> Form Validation Class Initialized
DEBUG - 2019-07-01 13:10:25 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-07-01 13:10:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-07-01 13:10:25 --> Pagination Class Initialized
INFO - 2019-07-01 13:10:25 --> Controller Class Initialized
INFO - 2019-07-01 19:10:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-07-01 19:10:25 --> Model Class Initialized
INFO - 2019-07-01 19:10:25 --> Model Class Initialized
INFO - 2019-07-01 13:10:25 --> Config Class Initialized
INFO - 2019-07-01 13:10:25 --> Hooks Class Initialized
DEBUG - 2019-07-01 13:10:25 --> UTF-8 Support Enabled
INFO - 2019-07-01 13:10:25 --> Utf8 Class Initialized
INFO - 2019-07-01 13:10:25 --> URI Class Initialized
DEBUG - 2019-07-01 13:10:25 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/routes.php
INFO - 2019-07-01 13:10:25 --> Router Class Initialized
INFO - 2019-07-01 13:10:25 --> Output Class Initialized
INFO - 2019-07-01 13:10:25 --> Security Class Initialized
DEBUG - 2019-07-01 13:10:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 13:10:25 --> Input Class Initialized
INFO - 2019-07-01 13:10:25 --> Language Class Initialized
INFO - 2019-07-01 13:10:25 --> Language Class Initialized
INFO - 2019-07-01 13:10:25 --> Config Class Initialized
INFO - 2019-07-01 13:10:25 --> Loader Class Initialized
DEBUG - 2019-07-01 13:10:25 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/site.php
INFO - 2019-07-01 13:10:25 --> Helper loaded: url_helper
INFO - 2019-07-01 13:10:25 --> Helper loaded: inflector_helper
INFO - 2019-07-01 13:10:25 --> Helper loaded: string_helper
INFO - 2019-07-01 13:10:25 --> Helper loaded: array_helper
INFO - 2019-07-01 13:10:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 13:10:25 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/autoload.php
DEBUG - 2019-07-01 13:10:25 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/helpers/adminlte_helper.php
INFO - 2019-07-01 13:10:25 --> Database Driver Class Initialized
DEBUG - 2019-07-01 13:10:25 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/libraries/Crud.php
INFO - 2019-07-01 13:10:25 --> Helper loaded: form_helper
DEBUG - 2019-07-01 13:10:25 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-07-01 13:10:25 --> Form Validation Class Initialized
DEBUG - 2019-07-01 13:10:25 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-07-01 13:10:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-07-01 13:10:25 --> Pagination Class Initialized
INFO - 2019-07-01 13:10:25 --> Controller Class Initialized
INFO - 2019-07-01 19:10:25 --> Final output sent to browser
DEBUG - 2019-07-01 19:10:25 --> Total execution time: 0.5108
INFO - 2019-07-01 13:10:51 --> Config Class Initialized
INFO - 2019-07-01 13:10:51 --> Hooks Class Initialized
DEBUG - 2019-07-01 13:10:51 --> UTF-8 Support Enabled
INFO - 2019-07-01 13:10:51 --> Utf8 Class Initialized
INFO - 2019-07-01 13:10:51 --> URI Class Initialized
INFO - 2019-07-01 13:10:51 --> Router Class Initialized
INFO - 2019-07-01 13:10:51 --> Output Class Initialized
INFO - 2019-07-01 13:10:51 --> Security Class Initialized
DEBUG - 2019-07-01 13:10:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 13:10:51 --> Input Class Initialized
INFO - 2019-07-01 13:10:51 --> Language Class Initialized
INFO - 2019-07-01 13:10:51 --> Language Class Initialized
INFO - 2019-07-01 13:10:51 --> Config Class Initialized
INFO - 2019-07-01 13:10:51 --> Loader Class Initialized
DEBUG - 2019-07-01 13:10:51 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 13:10:51 --> Helper loaded: url_helper
INFO - 2019-07-01 13:10:51 --> Helper loaded: inflector_helper
INFO - 2019-07-01 13:10:51 --> Helper loaded: string_helper
INFO - 2019-07-01 13:10:51 --> Helper loaded: array_helper
INFO - 2019-07-01 13:10:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 13:10:51 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 13:10:51 --> Database Driver Class Initialized
INFO - 2019-07-01 13:10:51 --> Controller Class Initialized
INFO - 2019-07-01 19:10:51 --> Helper loaded: language_helper
INFO - 2019-07-01 19:10:51 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 19:10:51 --> Model Class Initialized
INFO - 2019-07-01 19:10:51 --> Model Class Initialized
INFO - 2019-07-01 19:10:51 --> Model Class Initialized
INFO - 2019-07-01 19:10:51 --> Model Class Initialized
INFO - 2019-07-01 19:10:51 --> Final output sent to browser
DEBUG - 2019-07-01 19:10:51 --> Total execution time: 0.4290
INFO - 2019-07-01 13:10:53 --> Config Class Initialized
INFO - 2019-07-01 13:10:53 --> Hooks Class Initialized
DEBUG - 2019-07-01 13:10:53 --> UTF-8 Support Enabled
INFO - 2019-07-01 13:10:53 --> Utf8 Class Initialized
INFO - 2019-07-01 13:10:53 --> URI Class Initialized
INFO - 2019-07-01 13:10:53 --> Router Class Initialized
INFO - 2019-07-01 13:10:53 --> Output Class Initialized
INFO - 2019-07-01 13:10:53 --> Security Class Initialized
DEBUG - 2019-07-01 13:10:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 13:10:53 --> Input Class Initialized
INFO - 2019-07-01 13:10:53 --> Language Class Initialized
INFO - 2019-07-01 13:10:53 --> Language Class Initialized
INFO - 2019-07-01 13:10:53 --> Config Class Initialized
INFO - 2019-07-01 13:10:53 --> Loader Class Initialized
DEBUG - 2019-07-01 13:10:53 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 13:10:53 --> Helper loaded: url_helper
INFO - 2019-07-01 13:10:53 --> Helper loaded: inflector_helper
INFO - 2019-07-01 13:10:53 --> Helper loaded: string_helper
INFO - 2019-07-01 13:10:53 --> Helper loaded: array_helper
INFO - 2019-07-01 13:10:53 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 13:10:53 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 13:10:53 --> Database Driver Class Initialized
INFO - 2019-07-01 13:10:53 --> Controller Class Initialized
INFO - 2019-07-01 19:10:53 --> Helper loaded: language_helper
INFO - 2019-07-01 19:10:53 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 19:10:53 --> Model Class Initialized
INFO - 2019-07-01 19:10:53 --> Model Class Initialized
INFO - 2019-07-01 19:10:53 --> Model Class Initialized
INFO - 2019-07-01 19:10:53 --> Model Class Initialized
INFO - 2019-07-01 19:10:53 --> Helper loaded: form_helper
INFO - 2019-07-01 19:10:54 --> Form Validation Class Initialized
DEBUG - 2019-07-01 19:10:54 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 19:10:54 --> Model Class Initialized
INFO - 2019-07-01 19:10:54 --> Model Class Initialized
INFO - 2019-07-01 19:10:54 --> Final output sent to browser
DEBUG - 2019-07-01 19:10:54 --> Total execution time: 0.4831
INFO - 2019-07-01 13:11:39 --> Config Class Initialized
INFO - 2019-07-01 13:11:39 --> Hooks Class Initialized
DEBUG - 2019-07-01 13:11:39 --> UTF-8 Support Enabled
INFO - 2019-07-01 13:11:39 --> Utf8 Class Initialized
INFO - 2019-07-01 13:11:39 --> URI Class Initialized
INFO - 2019-07-01 13:11:39 --> Router Class Initialized
INFO - 2019-07-01 13:11:39 --> Output Class Initialized
INFO - 2019-07-01 13:11:39 --> Security Class Initialized
DEBUG - 2019-07-01 13:11:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 13:11:39 --> Input Class Initialized
INFO - 2019-07-01 13:11:39 --> Language Class Initialized
INFO - 2019-07-01 13:11:39 --> Language Class Initialized
INFO - 2019-07-01 13:11:39 --> Config Class Initialized
INFO - 2019-07-01 13:11:39 --> Loader Class Initialized
DEBUG - 2019-07-01 13:11:39 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 13:11:39 --> Helper loaded: url_helper
INFO - 2019-07-01 13:11:40 --> Helper loaded: inflector_helper
INFO - 2019-07-01 13:11:40 --> Helper loaded: string_helper
INFO - 2019-07-01 13:11:40 --> Helper loaded: array_helper
INFO - 2019-07-01 13:11:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 13:11:40 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 13:11:40 --> Database Driver Class Initialized
INFO - 2019-07-01 13:11:40 --> Controller Class Initialized
INFO - 2019-07-01 19:11:40 --> Helper loaded: language_helper
INFO - 2019-07-01 19:11:40 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 19:11:40 --> Model Class Initialized
INFO - 2019-07-01 19:11:40 --> Model Class Initialized
INFO - 2019-07-01 19:11:40 --> Model Class Initialized
INFO - 2019-07-01 19:11:40 --> Model Class Initialized
INFO - 2019-07-01 19:11:40 --> Final output sent to browser
DEBUG - 2019-07-01 19:11:40 --> Total execution time: 0.2381
INFO - 2019-07-01 13:12:10 --> Config Class Initialized
INFO - 2019-07-01 13:12:10 --> Hooks Class Initialized
DEBUG - 2019-07-01 13:12:10 --> UTF-8 Support Enabled
INFO - 2019-07-01 13:12:10 --> Utf8 Class Initialized
INFO - 2019-07-01 13:12:10 --> URI Class Initialized
INFO - 2019-07-01 13:12:10 --> Router Class Initialized
INFO - 2019-07-01 13:12:10 --> Output Class Initialized
INFO - 2019-07-01 13:12:10 --> Security Class Initialized
DEBUG - 2019-07-01 13:12:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 13:12:10 --> Input Class Initialized
INFO - 2019-07-01 13:12:10 --> Language Class Initialized
INFO - 2019-07-01 13:12:10 --> Language Class Initialized
INFO - 2019-07-01 13:12:10 --> Config Class Initialized
INFO - 2019-07-01 13:12:10 --> Loader Class Initialized
DEBUG - 2019-07-01 13:12:10 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 13:12:10 --> Helper loaded: url_helper
INFO - 2019-07-01 13:12:10 --> Helper loaded: inflector_helper
INFO - 2019-07-01 13:12:10 --> Helper loaded: string_helper
INFO - 2019-07-01 13:12:10 --> Helper loaded: array_helper
INFO - 2019-07-01 13:12:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 13:12:10 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 13:12:10 --> Database Driver Class Initialized
INFO - 2019-07-01 13:12:10 --> Controller Class Initialized
INFO - 2019-07-01 19:12:10 --> Helper loaded: language_helper
INFO - 2019-07-01 19:12:10 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 19:12:10 --> Model Class Initialized
INFO - 2019-07-01 19:12:10 --> Model Class Initialized
INFO - 2019-07-01 19:12:10 --> Model Class Initialized
INFO - 2019-07-01 19:12:10 --> Model Class Initialized
INFO - 2019-07-01 19:12:10 --> Helper loaded: form_helper
INFO - 2019-07-01 19:12:10 --> Form Validation Class Initialized
DEBUG - 2019-07-01 19:12:10 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 19:12:10 --> Model Class Initialized
INFO - 2019-07-01 19:12:10 --> Model Class Initialized
INFO - 2019-07-01 19:12:10 --> Final output sent to browser
DEBUG - 2019-07-01 19:12:10 --> Total execution time: 0.2986
INFO - 2019-07-01 13:12:21 --> Config Class Initialized
INFO - 2019-07-01 13:12:21 --> Hooks Class Initialized
DEBUG - 2019-07-01 13:12:21 --> UTF-8 Support Enabled
INFO - 2019-07-01 13:12:21 --> Utf8 Class Initialized
INFO - 2019-07-01 13:12:21 --> URI Class Initialized
INFO - 2019-07-01 13:12:21 --> Router Class Initialized
INFO - 2019-07-01 13:12:21 --> Output Class Initialized
INFO - 2019-07-01 13:12:21 --> Security Class Initialized
DEBUG - 2019-07-01 13:12:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 13:12:21 --> Input Class Initialized
INFO - 2019-07-01 13:12:21 --> Language Class Initialized
INFO - 2019-07-01 13:12:21 --> Language Class Initialized
INFO - 2019-07-01 13:12:21 --> Config Class Initialized
INFO - 2019-07-01 13:12:21 --> Loader Class Initialized
DEBUG - 2019-07-01 13:12:21 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 13:12:21 --> Helper loaded: url_helper
INFO - 2019-07-01 13:12:21 --> Helper loaded: inflector_helper
INFO - 2019-07-01 13:12:21 --> Helper loaded: string_helper
INFO - 2019-07-01 13:12:21 --> Helper loaded: array_helper
INFO - 2019-07-01 13:12:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 13:12:21 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 13:12:21 --> Database Driver Class Initialized
INFO - 2019-07-01 13:12:21 --> Controller Class Initialized
INFO - 2019-07-01 19:12:21 --> Helper loaded: language_helper
INFO - 2019-07-01 19:12:21 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 19:12:21 --> Model Class Initialized
INFO - 2019-07-01 19:12:21 --> Model Class Initialized
INFO - 2019-07-01 19:12:21 --> Model Class Initialized
INFO - 2019-07-01 19:12:21 --> Model Class Initialized
INFO - 2019-07-01 19:12:21 --> Final output sent to browser
DEBUG - 2019-07-01 19:12:21 --> Total execution time: 0.4357
INFO - 2019-07-01 13:12:21 --> Config Class Initialized
INFO - 2019-07-01 13:12:21 --> Hooks Class Initialized
DEBUG - 2019-07-01 13:12:21 --> UTF-8 Support Enabled
INFO - 2019-07-01 13:12:21 --> Utf8 Class Initialized
INFO - 2019-07-01 13:12:21 --> URI Class Initialized
INFO - 2019-07-01 13:12:21 --> Router Class Initialized
INFO - 2019-07-01 13:12:21 --> Output Class Initialized
INFO - 2019-07-01 13:12:21 --> Security Class Initialized
DEBUG - 2019-07-01 13:12:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 13:12:21 --> Input Class Initialized
INFO - 2019-07-01 13:12:21 --> Language Class Initialized
INFO - 2019-07-01 13:12:21 --> Language Class Initialized
INFO - 2019-07-01 13:12:21 --> Config Class Initialized
INFO - 2019-07-01 13:12:21 --> Loader Class Initialized
DEBUG - 2019-07-01 13:12:21 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 13:12:22 --> Helper loaded: url_helper
INFO - 2019-07-01 13:12:22 --> Helper loaded: inflector_helper
INFO - 2019-07-01 13:12:22 --> Helper loaded: string_helper
INFO - 2019-07-01 13:12:22 --> Helper loaded: array_helper
INFO - 2019-07-01 13:12:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 13:12:22 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 13:12:22 --> Database Driver Class Initialized
INFO - 2019-07-01 13:12:22 --> Controller Class Initialized
INFO - 2019-07-01 19:12:22 --> Helper loaded: language_helper
INFO - 2019-07-01 19:12:22 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 19:12:22 --> Model Class Initialized
INFO - 2019-07-01 19:12:22 --> Model Class Initialized
INFO - 2019-07-01 19:12:22 --> Model Class Initialized
INFO - 2019-07-01 19:12:22 --> Model Class Initialized
INFO - 2019-07-01 19:12:22 --> Model Class Initialized
INFO - 2019-07-01 19:12:22 --> Final output sent to browser
DEBUG - 2019-07-01 19:12:22 --> Total execution time: 0.5604
INFO - 2019-07-01 13:12:28 --> Config Class Initialized
INFO - 2019-07-01 13:12:28 --> Hooks Class Initialized
DEBUG - 2019-07-01 13:12:28 --> UTF-8 Support Enabled
INFO - 2019-07-01 13:12:28 --> Utf8 Class Initialized
INFO - 2019-07-01 13:12:28 --> URI Class Initialized
INFO - 2019-07-01 13:12:28 --> Router Class Initialized
INFO - 2019-07-01 13:12:28 --> Output Class Initialized
INFO - 2019-07-01 13:12:28 --> Security Class Initialized
DEBUG - 2019-07-01 13:12:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 13:12:28 --> Input Class Initialized
INFO - 2019-07-01 13:12:28 --> Language Class Initialized
INFO - 2019-07-01 13:12:28 --> Language Class Initialized
INFO - 2019-07-01 13:12:28 --> Config Class Initialized
INFO - 2019-07-01 13:12:28 --> Loader Class Initialized
DEBUG - 2019-07-01 13:12:28 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 13:12:28 --> Helper loaded: url_helper
INFO - 2019-07-01 13:12:28 --> Helper loaded: inflector_helper
INFO - 2019-07-01 13:12:28 --> Helper loaded: string_helper
INFO - 2019-07-01 13:12:28 --> Helper loaded: array_helper
INFO - 2019-07-01 13:12:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 13:12:28 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 13:12:28 --> Database Driver Class Initialized
INFO - 2019-07-01 13:12:28 --> Controller Class Initialized
INFO - 2019-07-01 19:12:28 --> Helper loaded: language_helper
INFO - 2019-07-01 19:12:28 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 19:12:28 --> Model Class Initialized
INFO - 2019-07-01 19:12:28 --> Model Class Initialized
INFO - 2019-07-01 19:12:28 --> Model Class Initialized
INFO - 2019-07-01 19:12:28 --> Model Class Initialized
INFO - 2019-07-01 19:12:28 --> Helper loaded: form_helper
INFO - 2019-07-01 19:12:28 --> Form Validation Class Initialized
DEBUG - 2019-07-01 19:12:28 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 19:12:28 --> Model Class Initialized
INFO - 2019-07-01 19:12:28 --> Model Class Initialized
INFO - 2019-07-01 19:12:28 --> Final output sent to browser
DEBUG - 2019-07-01 19:12:28 --> Total execution time: 0.4186
INFO - 2019-07-01 13:12:35 --> Config Class Initialized
INFO - 2019-07-01 13:12:35 --> Hooks Class Initialized
DEBUG - 2019-07-01 13:12:35 --> UTF-8 Support Enabled
INFO - 2019-07-01 13:12:35 --> Utf8 Class Initialized
INFO - 2019-07-01 13:12:35 --> URI Class Initialized
INFO - 2019-07-01 13:12:35 --> Router Class Initialized
INFO - 2019-07-01 13:12:35 --> Output Class Initialized
INFO - 2019-07-01 13:12:35 --> Security Class Initialized
DEBUG - 2019-07-01 13:12:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 13:12:35 --> Input Class Initialized
INFO - 2019-07-01 13:12:35 --> Language Class Initialized
INFO - 2019-07-01 13:12:35 --> Language Class Initialized
INFO - 2019-07-01 13:12:35 --> Config Class Initialized
INFO - 2019-07-01 13:12:35 --> Loader Class Initialized
DEBUG - 2019-07-01 13:12:35 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 13:12:35 --> Helper loaded: url_helper
INFO - 2019-07-01 13:12:35 --> Helper loaded: inflector_helper
INFO - 2019-07-01 13:12:35 --> Helper loaded: string_helper
INFO - 2019-07-01 13:12:35 --> Helper loaded: array_helper
INFO - 2019-07-01 13:12:35 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 13:12:35 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 13:12:35 --> Database Driver Class Initialized
INFO - 2019-07-01 13:12:35 --> Controller Class Initialized
INFO - 2019-07-01 19:12:35 --> Helper loaded: language_helper
INFO - 2019-07-01 19:12:35 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 19:12:35 --> Model Class Initialized
INFO - 2019-07-01 19:12:35 --> Model Class Initialized
INFO - 2019-07-01 19:12:35 --> Model Class Initialized
INFO - 2019-07-01 19:12:35 --> Model Class Initialized
INFO - 2019-07-01 19:12:35 --> Model Class Initialized
INFO - 2019-07-01 19:12:35 --> Final output sent to browser
DEBUG - 2019-07-01 19:12:35 --> Total execution time: 0.3252
INFO - 2019-07-01 13:12:50 --> Config Class Initialized
INFO - 2019-07-01 13:12:50 --> Hooks Class Initialized
DEBUG - 2019-07-01 13:12:50 --> UTF-8 Support Enabled
INFO - 2019-07-01 13:12:50 --> Utf8 Class Initialized
INFO - 2019-07-01 13:12:50 --> URI Class Initialized
INFO - 2019-07-01 13:12:51 --> Router Class Initialized
INFO - 2019-07-01 13:12:51 --> Output Class Initialized
INFO - 2019-07-01 13:12:51 --> Security Class Initialized
DEBUG - 2019-07-01 13:12:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 13:12:51 --> Input Class Initialized
INFO - 2019-07-01 13:12:51 --> Language Class Initialized
INFO - 2019-07-01 13:12:51 --> Language Class Initialized
INFO - 2019-07-01 13:12:51 --> Config Class Initialized
INFO - 2019-07-01 13:12:51 --> Loader Class Initialized
DEBUG - 2019-07-01 13:12:51 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 13:12:51 --> Helper loaded: url_helper
INFO - 2019-07-01 13:12:51 --> Helper loaded: inflector_helper
INFO - 2019-07-01 13:12:51 --> Helper loaded: string_helper
INFO - 2019-07-01 13:12:51 --> Helper loaded: array_helper
INFO - 2019-07-01 13:12:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 13:12:51 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 13:12:51 --> Database Driver Class Initialized
INFO - 2019-07-01 13:12:51 --> Controller Class Initialized
INFO - 2019-07-01 19:12:51 --> Helper loaded: language_helper
INFO - 2019-07-01 19:12:51 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 19:12:51 --> Model Class Initialized
INFO - 2019-07-01 19:12:51 --> Model Class Initialized
INFO - 2019-07-01 19:12:51 --> Model Class Initialized
INFO - 2019-07-01 19:12:51 --> Model Class Initialized
INFO - 2019-07-01 19:12:51 --> Helper loaded: form_helper
INFO - 2019-07-01 19:12:51 --> Form Validation Class Initialized
DEBUG - 2019-07-01 19:12:51 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 19:12:51 --> Model Class Initialized
INFO - 2019-07-01 19:12:51 --> Model Class Initialized
INFO - 2019-07-01 19:12:51 --> Final output sent to browser
DEBUG - 2019-07-01 19:12:51 --> Total execution time: 0.5293
INFO - 2019-07-01 13:15:01 --> Config Class Initialized
INFO - 2019-07-01 13:15:01 --> Hooks Class Initialized
DEBUG - 2019-07-01 13:15:01 --> UTF-8 Support Enabled
INFO - 2019-07-01 13:15:01 --> Utf8 Class Initialized
INFO - 2019-07-01 13:15:01 --> URI Class Initialized
INFO - 2019-07-01 13:15:01 --> Router Class Initialized
INFO - 2019-07-01 13:15:01 --> Output Class Initialized
INFO - 2019-07-01 13:15:01 --> Security Class Initialized
DEBUG - 2019-07-01 13:15:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 13:15:01 --> Input Class Initialized
INFO - 2019-07-01 13:15:01 --> Language Class Initialized
INFO - 2019-07-01 13:15:01 --> Language Class Initialized
INFO - 2019-07-01 13:15:01 --> Config Class Initialized
INFO - 2019-07-01 13:15:01 --> Loader Class Initialized
DEBUG - 2019-07-01 13:15:01 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 13:15:01 --> Helper loaded: url_helper
INFO - 2019-07-01 13:15:01 --> Helper loaded: inflector_helper
INFO - 2019-07-01 13:15:01 --> Helper loaded: string_helper
INFO - 2019-07-01 13:15:01 --> Helper loaded: array_helper
INFO - 2019-07-01 13:15:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 13:15:01 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 13:15:01 --> Database Driver Class Initialized
INFO - 2019-07-01 13:15:01 --> Controller Class Initialized
INFO - 2019-07-01 19:15:01 --> Helper loaded: language_helper
INFO - 2019-07-01 19:15:01 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 19:15:01 --> Model Class Initialized
INFO - 2019-07-01 19:15:01 --> Model Class Initialized
INFO - 2019-07-01 19:15:01 --> Model Class Initialized
INFO - 2019-07-01 19:15:01 --> Model Class Initialized
INFO - 2019-07-01 19:15:01 --> Helper loaded: form_helper
INFO - 2019-07-01 19:15:01 --> Form Validation Class Initialized
DEBUG - 2019-07-01 19:15:01 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 19:15:01 --> Model Class Initialized
INFO - 2019-07-01 19:15:01 --> Model Class Initialized
INFO - 2019-07-01 19:15:01 --> Final output sent to browser
DEBUG - 2019-07-01 19:15:01 --> Total execution time: 0.3488
INFO - 2019-07-01 13:15:04 --> Config Class Initialized
INFO - 2019-07-01 13:15:04 --> Hooks Class Initialized
DEBUG - 2019-07-01 13:15:04 --> UTF-8 Support Enabled
INFO - 2019-07-01 13:15:04 --> Utf8 Class Initialized
INFO - 2019-07-01 13:15:04 --> URI Class Initialized
INFO - 2019-07-01 13:15:04 --> Router Class Initialized
INFO - 2019-07-01 13:15:04 --> Output Class Initialized
INFO - 2019-07-01 13:15:04 --> Security Class Initialized
DEBUG - 2019-07-01 13:15:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 13:15:04 --> Input Class Initialized
INFO - 2019-07-01 13:15:04 --> Language Class Initialized
INFO - 2019-07-01 13:15:04 --> Language Class Initialized
INFO - 2019-07-01 13:15:04 --> Config Class Initialized
INFO - 2019-07-01 13:15:04 --> Loader Class Initialized
DEBUG - 2019-07-01 13:15:04 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 13:15:04 --> Helper loaded: url_helper
INFO - 2019-07-01 13:15:04 --> Helper loaded: inflector_helper
INFO - 2019-07-01 13:15:04 --> Helper loaded: string_helper
INFO - 2019-07-01 13:15:04 --> Helper loaded: array_helper
INFO - 2019-07-01 13:15:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 13:15:04 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 13:15:04 --> Database Driver Class Initialized
INFO - 2019-07-01 13:15:04 --> Controller Class Initialized
INFO - 2019-07-01 19:15:04 --> Helper loaded: language_helper
INFO - 2019-07-01 19:15:04 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 19:15:04 --> Model Class Initialized
INFO - 2019-07-01 19:15:04 --> Model Class Initialized
INFO - 2019-07-01 19:15:04 --> Model Class Initialized
INFO - 2019-07-01 19:15:04 --> Model Class Initialized
INFO - 2019-07-01 19:15:04 --> Helper loaded: form_helper
INFO - 2019-07-01 19:15:04 --> Form Validation Class Initialized
DEBUG - 2019-07-01 19:15:04 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 19:15:04 --> Model Class Initialized
INFO - 2019-07-01 19:15:04 --> Model Class Initialized
INFO - 2019-07-01 19:15:04 --> Final output sent to browser
DEBUG - 2019-07-01 19:15:04 --> Total execution time: 0.3838
INFO - 2019-07-01 13:15:08 --> Config Class Initialized
INFO - 2019-07-01 13:15:08 --> Hooks Class Initialized
DEBUG - 2019-07-01 13:15:08 --> UTF-8 Support Enabled
INFO - 2019-07-01 13:15:08 --> Utf8 Class Initialized
INFO - 2019-07-01 13:15:08 --> URI Class Initialized
INFO - 2019-07-01 13:15:08 --> Router Class Initialized
INFO - 2019-07-01 13:15:08 --> Output Class Initialized
INFO - 2019-07-01 13:15:08 --> Security Class Initialized
DEBUG - 2019-07-01 13:15:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 13:15:08 --> Input Class Initialized
INFO - 2019-07-01 13:15:08 --> Language Class Initialized
INFO - 2019-07-01 13:15:08 --> Language Class Initialized
INFO - 2019-07-01 13:15:08 --> Config Class Initialized
INFO - 2019-07-01 13:15:08 --> Loader Class Initialized
DEBUG - 2019-07-01 13:15:08 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 13:15:08 --> Helper loaded: url_helper
INFO - 2019-07-01 13:15:08 --> Helper loaded: inflector_helper
INFO - 2019-07-01 13:15:08 --> Helper loaded: string_helper
INFO - 2019-07-01 13:15:08 --> Helper loaded: array_helper
INFO - 2019-07-01 13:15:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 13:15:08 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 13:15:08 --> Database Driver Class Initialized
INFO - 2019-07-01 13:15:08 --> Controller Class Initialized
INFO - 2019-07-01 19:15:08 --> Helper loaded: language_helper
INFO - 2019-07-01 19:15:08 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 19:15:08 --> Model Class Initialized
INFO - 2019-07-01 19:15:08 --> Model Class Initialized
INFO - 2019-07-01 19:15:08 --> Model Class Initialized
INFO - 2019-07-01 19:15:08 --> Model Class Initialized
INFO - 2019-07-01 19:15:08 --> Model Class Initialized
INFO - 2019-07-01 19:15:08 --> Final output sent to browser
DEBUG - 2019-07-01 19:15:08 --> Total execution time: 0.2158
INFO - 2019-07-01 13:15:17 --> Config Class Initialized
INFO - 2019-07-01 13:15:17 --> Hooks Class Initialized
DEBUG - 2019-07-01 13:15:17 --> UTF-8 Support Enabled
INFO - 2019-07-01 13:15:17 --> Utf8 Class Initialized
INFO - 2019-07-01 13:15:17 --> URI Class Initialized
INFO - 2019-07-01 13:15:17 --> Router Class Initialized
INFO - 2019-07-01 13:15:17 --> Output Class Initialized
INFO - 2019-07-01 13:15:17 --> Security Class Initialized
DEBUG - 2019-07-01 13:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 13:15:17 --> Input Class Initialized
INFO - 2019-07-01 13:15:17 --> Language Class Initialized
INFO - 2019-07-01 13:15:17 --> Language Class Initialized
INFO - 2019-07-01 13:15:17 --> Config Class Initialized
INFO - 2019-07-01 13:15:17 --> Loader Class Initialized
DEBUG - 2019-07-01 13:15:17 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 13:15:17 --> Helper loaded: url_helper
INFO - 2019-07-01 13:15:17 --> Helper loaded: inflector_helper
INFO - 2019-07-01 13:15:17 --> Helper loaded: string_helper
INFO - 2019-07-01 13:15:17 --> Helper loaded: array_helper
INFO - 2019-07-01 13:15:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 13:15:17 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 13:15:17 --> Database Driver Class Initialized
INFO - 2019-07-01 13:15:17 --> Controller Class Initialized
INFO - 2019-07-01 19:15:17 --> Helper loaded: language_helper
INFO - 2019-07-01 19:15:17 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 19:15:17 --> Model Class Initialized
INFO - 2019-07-01 19:15:17 --> Model Class Initialized
INFO - 2019-07-01 19:15:17 --> Model Class Initialized
INFO - 2019-07-01 19:15:17 --> Model Class Initialized
INFO - 2019-07-01 19:15:17 --> Final output sent to browser
DEBUG - 2019-07-01 19:15:17 --> Total execution time: 0.3101
INFO - 2019-07-01 13:15:46 --> Config Class Initialized
INFO - 2019-07-01 13:15:46 --> Hooks Class Initialized
DEBUG - 2019-07-01 13:15:46 --> UTF-8 Support Enabled
INFO - 2019-07-01 13:15:46 --> Utf8 Class Initialized
INFO - 2019-07-01 13:15:46 --> URI Class Initialized
INFO - 2019-07-01 13:15:47 --> Router Class Initialized
INFO - 2019-07-01 13:15:47 --> Output Class Initialized
INFO - 2019-07-01 13:15:47 --> Security Class Initialized
DEBUG - 2019-07-01 13:15:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 13:15:47 --> Input Class Initialized
INFO - 2019-07-01 13:15:47 --> Language Class Initialized
INFO - 2019-07-01 13:15:47 --> Language Class Initialized
INFO - 2019-07-01 13:15:47 --> Config Class Initialized
INFO - 2019-07-01 13:15:47 --> Loader Class Initialized
DEBUG - 2019-07-01 13:15:47 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 13:15:47 --> Helper loaded: url_helper
INFO - 2019-07-01 13:15:47 --> Helper loaded: inflector_helper
INFO - 2019-07-01 13:15:47 --> Helper loaded: string_helper
INFO - 2019-07-01 13:15:47 --> Helper loaded: array_helper
INFO - 2019-07-01 13:15:47 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 13:15:47 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 13:15:47 --> Database Driver Class Initialized
INFO - 2019-07-01 13:15:47 --> Controller Class Initialized
INFO - 2019-07-01 19:15:47 --> Helper loaded: language_helper
INFO - 2019-07-01 19:15:47 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 19:15:47 --> Model Class Initialized
INFO - 2019-07-01 19:15:47 --> Model Class Initialized
INFO - 2019-07-01 19:15:47 --> Model Class Initialized
INFO - 2019-07-01 19:15:47 --> Model Class Initialized
INFO - 2019-07-01 19:15:47 --> Helper loaded: form_helper
INFO - 2019-07-01 19:15:47 --> Form Validation Class Initialized
DEBUG - 2019-07-01 19:15:47 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 19:15:47 --> Model Class Initialized
INFO - 2019-07-01 19:15:47 --> Model Class Initialized
INFO - 2019-07-01 19:15:47 --> Final output sent to browser
DEBUG - 2019-07-01 19:15:47 --> Total execution time: 0.4121
INFO - 2019-07-01 13:20:33 --> Config Class Initialized
INFO - 2019-07-01 13:20:33 --> Hooks Class Initialized
DEBUG - 2019-07-01 13:20:33 --> UTF-8 Support Enabled
INFO - 2019-07-01 13:20:33 --> Utf8 Class Initialized
INFO - 2019-07-01 13:20:33 --> URI Class Initialized
INFO - 2019-07-01 13:20:33 --> Router Class Initialized
INFO - 2019-07-01 13:20:33 --> Output Class Initialized
INFO - 2019-07-01 13:20:33 --> Security Class Initialized
DEBUG - 2019-07-01 13:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 13:20:33 --> Input Class Initialized
INFO - 2019-07-01 13:20:33 --> Language Class Initialized
INFO - 2019-07-01 13:20:33 --> Language Class Initialized
INFO - 2019-07-01 13:20:33 --> Config Class Initialized
INFO - 2019-07-01 13:20:33 --> Loader Class Initialized
DEBUG - 2019-07-01 13:20:33 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 13:20:33 --> Helper loaded: url_helper
INFO - 2019-07-01 13:20:33 --> Helper loaded: inflector_helper
INFO - 2019-07-01 13:20:33 --> Helper loaded: string_helper
INFO - 2019-07-01 13:20:33 --> Helper loaded: array_helper
INFO - 2019-07-01 13:20:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 13:20:33 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 13:20:33 --> Database Driver Class Initialized
INFO - 2019-07-01 13:20:33 --> Controller Class Initialized
INFO - 2019-07-01 19:20:33 --> Helper loaded: language_helper
INFO - 2019-07-01 19:20:33 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 19:20:33 --> Model Class Initialized
INFO - 2019-07-01 19:20:33 --> Model Class Initialized
INFO - 2019-07-01 19:20:33 --> Model Class Initialized
INFO - 2019-07-01 19:20:33 --> Model Class Initialized
INFO - 2019-07-01 19:20:33 --> Helper loaded: form_helper
INFO - 2019-07-01 19:20:33 --> Form Validation Class Initialized
DEBUG - 2019-07-01 19:20:33 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 19:20:33 --> Model Class Initialized
INFO - 2019-07-01 19:20:33 --> Model Class Initialized
INFO - 2019-07-01 19:20:33 --> Final output sent to browser
DEBUG - 2019-07-01 19:20:33 --> Total execution time: 0.4735
INFO - 2019-07-01 13:20:34 --> Config Class Initialized
INFO - 2019-07-01 13:20:34 --> Hooks Class Initialized
DEBUG - 2019-07-01 13:20:34 --> UTF-8 Support Enabled
INFO - 2019-07-01 13:20:35 --> Utf8 Class Initialized
INFO - 2019-07-01 13:20:35 --> URI Class Initialized
INFO - 2019-07-01 13:20:35 --> Router Class Initialized
INFO - 2019-07-01 13:20:35 --> Output Class Initialized
INFO - 2019-07-01 13:20:35 --> Security Class Initialized
DEBUG - 2019-07-01 13:20:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 13:20:35 --> Input Class Initialized
INFO - 2019-07-01 13:20:35 --> Language Class Initialized
INFO - 2019-07-01 13:20:35 --> Language Class Initialized
INFO - 2019-07-01 13:20:35 --> Config Class Initialized
INFO - 2019-07-01 13:20:35 --> Loader Class Initialized
DEBUG - 2019-07-01 13:20:35 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 13:20:35 --> Helper loaded: url_helper
INFO - 2019-07-01 13:20:35 --> Helper loaded: inflector_helper
INFO - 2019-07-01 13:20:35 --> Helper loaded: string_helper
INFO - 2019-07-01 13:20:35 --> Helper loaded: array_helper
INFO - 2019-07-01 13:20:35 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 13:20:35 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 13:20:35 --> Database Driver Class Initialized
INFO - 2019-07-01 13:20:35 --> Controller Class Initialized
INFO - 2019-07-01 19:20:35 --> Helper loaded: language_helper
INFO - 2019-07-01 19:20:35 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 19:20:35 --> Model Class Initialized
INFO - 2019-07-01 19:20:35 --> Model Class Initialized
INFO - 2019-07-01 19:20:35 --> Model Class Initialized
INFO - 2019-07-01 19:20:35 --> Model Class Initialized
INFO - 2019-07-01 19:20:35 --> Model Class Initialized
INFO - 2019-07-01 19:20:35 --> Final output sent to browser
DEBUG - 2019-07-01 19:20:35 --> Total execution time: 0.3456
INFO - 2019-07-01 13:20:45 --> Config Class Initialized
INFO - 2019-07-01 13:20:45 --> Hooks Class Initialized
DEBUG - 2019-07-01 13:20:45 --> UTF-8 Support Enabled
INFO - 2019-07-01 13:20:45 --> Utf8 Class Initialized
INFO - 2019-07-01 13:20:45 --> URI Class Initialized
INFO - 2019-07-01 13:20:45 --> Router Class Initialized
INFO - 2019-07-01 13:20:45 --> Output Class Initialized
INFO - 2019-07-01 13:20:45 --> Security Class Initialized
DEBUG - 2019-07-01 13:20:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 13:20:45 --> Input Class Initialized
INFO - 2019-07-01 13:20:45 --> Language Class Initialized
INFO - 2019-07-01 13:20:45 --> Language Class Initialized
INFO - 2019-07-01 13:20:46 --> Config Class Initialized
INFO - 2019-07-01 13:20:46 --> Loader Class Initialized
DEBUG - 2019-07-01 13:20:46 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 13:20:46 --> Helper loaded: url_helper
INFO - 2019-07-01 13:20:46 --> Helper loaded: inflector_helper
INFO - 2019-07-01 13:20:46 --> Helper loaded: string_helper
INFO - 2019-07-01 13:20:46 --> Helper loaded: array_helper
INFO - 2019-07-01 13:20:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 13:20:46 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 13:20:46 --> Database Driver Class Initialized
INFO - 2019-07-01 13:20:46 --> Controller Class Initialized
INFO - 2019-07-01 19:20:46 --> Helper loaded: language_helper
INFO - 2019-07-01 19:20:46 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 19:20:46 --> Model Class Initialized
INFO - 2019-07-01 19:20:46 --> Model Class Initialized
INFO - 2019-07-01 19:20:46 --> Model Class Initialized
INFO - 2019-07-01 19:20:46 --> Model Class Initialized
INFO - 2019-07-01 19:20:46 --> Final output sent to browser
DEBUG - 2019-07-01 19:20:46 --> Total execution time: 0.2272
INFO - 2019-07-01 13:21:38 --> Config Class Initialized
INFO - 2019-07-01 13:21:38 --> Hooks Class Initialized
DEBUG - 2019-07-01 13:21:38 --> UTF-8 Support Enabled
INFO - 2019-07-01 13:21:38 --> Utf8 Class Initialized
INFO - 2019-07-01 13:21:38 --> URI Class Initialized
INFO - 2019-07-01 13:21:38 --> Router Class Initialized
INFO - 2019-07-01 13:21:38 --> Output Class Initialized
INFO - 2019-07-01 13:21:38 --> Security Class Initialized
DEBUG - 2019-07-01 13:21:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 13:21:38 --> Input Class Initialized
INFO - 2019-07-01 13:21:38 --> Language Class Initialized
INFO - 2019-07-01 13:21:38 --> Language Class Initialized
INFO - 2019-07-01 13:21:38 --> Config Class Initialized
INFO - 2019-07-01 13:21:38 --> Loader Class Initialized
DEBUG - 2019-07-01 13:21:38 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 13:21:38 --> Helper loaded: url_helper
INFO - 2019-07-01 13:21:38 --> Helper loaded: inflector_helper
INFO - 2019-07-01 13:21:38 --> Helper loaded: string_helper
INFO - 2019-07-01 13:21:38 --> Helper loaded: array_helper
INFO - 2019-07-01 13:21:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 13:21:38 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 13:21:38 --> Database Driver Class Initialized
INFO - 2019-07-01 13:21:38 --> Controller Class Initialized
INFO - 2019-07-01 19:21:38 --> Helper loaded: language_helper
INFO - 2019-07-01 19:21:38 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 19:21:38 --> Model Class Initialized
INFO - 2019-07-01 19:21:38 --> Model Class Initialized
INFO - 2019-07-01 19:21:38 --> Model Class Initialized
INFO - 2019-07-01 19:21:38 --> Model Class Initialized
INFO - 2019-07-01 19:21:38 --> Final output sent to browser
DEBUG - 2019-07-01 19:21:38 --> Total execution time: 0.2830
INFO - 2019-07-01 13:29:15 --> Config Class Initialized
INFO - 2019-07-01 13:29:15 --> Hooks Class Initialized
DEBUG - 2019-07-01 13:29:15 --> UTF-8 Support Enabled
INFO - 2019-07-01 13:29:15 --> Utf8 Class Initialized
INFO - 2019-07-01 13:29:15 --> URI Class Initialized
INFO - 2019-07-01 13:29:15 --> Router Class Initialized
INFO - 2019-07-01 13:29:15 --> Output Class Initialized
INFO - 2019-07-01 13:29:15 --> Security Class Initialized
DEBUG - 2019-07-01 13:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 13:29:15 --> Input Class Initialized
INFO - 2019-07-01 13:29:15 --> Language Class Initialized
INFO - 2019-07-01 13:29:15 --> Language Class Initialized
INFO - 2019-07-01 13:29:15 --> Config Class Initialized
INFO - 2019-07-01 13:29:15 --> Loader Class Initialized
DEBUG - 2019-07-01 13:29:15 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 13:29:15 --> Helper loaded: url_helper
INFO - 2019-07-01 13:29:15 --> Helper loaded: inflector_helper
INFO - 2019-07-01 13:29:15 --> Helper loaded: string_helper
INFO - 2019-07-01 13:29:15 --> Helper loaded: array_helper
INFO - 2019-07-01 13:29:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 13:29:15 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 13:29:15 --> Database Driver Class Initialized
INFO - 2019-07-01 13:29:15 --> Controller Class Initialized
INFO - 2019-07-01 19:29:15 --> Helper loaded: language_helper
INFO - 2019-07-01 19:29:15 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 19:29:15 --> Model Class Initialized
INFO - 2019-07-01 19:29:15 --> Model Class Initialized
INFO - 2019-07-01 19:29:15 --> Model Class Initialized
INFO - 2019-07-01 19:29:15 --> Model Class Initialized
INFO - 2019-07-01 19:29:15 --> Helper loaded: form_helper
INFO - 2019-07-01 19:29:15 --> Form Validation Class Initialized
DEBUG - 2019-07-01 19:29:15 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 19:29:15 --> Model Class Initialized
INFO - 2019-07-01 19:29:15 --> Model Class Initialized
INFO - 2019-07-01 19:29:15 --> Final output sent to browser
DEBUG - 2019-07-01 19:29:15 --> Total execution time: 0.2435
INFO - 2019-07-01 13:40:09 --> Config Class Initialized
INFO - 2019-07-01 13:40:09 --> Hooks Class Initialized
DEBUG - 2019-07-01 13:40:09 --> UTF-8 Support Enabled
INFO - 2019-07-01 13:40:09 --> Utf8 Class Initialized
INFO - 2019-07-01 13:40:09 --> URI Class Initialized
INFO - 2019-07-01 13:40:09 --> Router Class Initialized
INFO - 2019-07-01 13:40:09 --> Output Class Initialized
INFO - 2019-07-01 13:40:09 --> Security Class Initialized
DEBUG - 2019-07-01 13:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 13:40:09 --> Input Class Initialized
INFO - 2019-07-01 13:40:10 --> Language Class Initialized
INFO - 2019-07-01 13:40:10 --> Language Class Initialized
INFO - 2019-07-01 13:40:10 --> Config Class Initialized
INFO - 2019-07-01 13:40:10 --> Loader Class Initialized
DEBUG - 2019-07-01 13:40:10 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 13:40:10 --> Helper loaded: url_helper
INFO - 2019-07-01 13:40:10 --> Helper loaded: inflector_helper
INFO - 2019-07-01 13:40:10 --> Helper loaded: string_helper
INFO - 2019-07-01 13:40:10 --> Helper loaded: array_helper
INFO - 2019-07-01 13:40:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 13:40:10 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 13:40:10 --> Database Driver Class Initialized
INFO - 2019-07-01 13:40:10 --> Controller Class Initialized
INFO - 2019-07-01 19:40:10 --> Helper loaded: language_helper
INFO - 2019-07-01 19:40:10 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 19:40:10 --> Model Class Initialized
INFO - 2019-07-01 19:40:10 --> Model Class Initialized
INFO - 2019-07-01 19:40:10 --> Model Class Initialized
INFO - 2019-07-01 19:40:10 --> Model Class Initialized
INFO - 2019-07-01 19:40:10 --> Helper loaded: form_helper
INFO - 2019-07-01 19:40:10 --> Form Validation Class Initialized
DEBUG - 2019-07-01 19:40:10 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 19:40:10 --> Model Class Initialized
INFO - 2019-07-01 19:40:10 --> Model Class Initialized
INFO - 2019-07-01 19:40:10 --> Final output sent to browser
DEBUG - 2019-07-01 19:40:10 --> Total execution time: 0.5359
INFO - 2019-07-01 13:40:11 --> Config Class Initialized
INFO - 2019-07-01 13:40:11 --> Hooks Class Initialized
DEBUG - 2019-07-01 13:40:11 --> UTF-8 Support Enabled
INFO - 2019-07-01 13:40:11 --> Utf8 Class Initialized
INFO - 2019-07-01 13:40:11 --> URI Class Initialized
INFO - 2019-07-01 13:40:11 --> Router Class Initialized
INFO - 2019-07-01 13:40:11 --> Output Class Initialized
INFO - 2019-07-01 13:40:11 --> Security Class Initialized
DEBUG - 2019-07-01 13:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 13:40:11 --> Input Class Initialized
INFO - 2019-07-01 13:40:11 --> Language Class Initialized
INFO - 2019-07-01 13:40:11 --> Language Class Initialized
INFO - 2019-07-01 13:40:11 --> Config Class Initialized
INFO - 2019-07-01 13:40:11 --> Loader Class Initialized
DEBUG - 2019-07-01 13:40:11 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 13:40:11 --> Helper loaded: url_helper
INFO - 2019-07-01 13:40:11 --> Helper loaded: inflector_helper
INFO - 2019-07-01 13:40:11 --> Helper loaded: string_helper
INFO - 2019-07-01 13:40:11 --> Helper loaded: array_helper
INFO - 2019-07-01 13:40:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 13:40:11 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 13:40:11 --> Database Driver Class Initialized
INFO - 2019-07-01 13:40:11 --> Controller Class Initialized
INFO - 2019-07-01 19:40:11 --> Helper loaded: language_helper
INFO - 2019-07-01 19:40:11 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 19:40:11 --> Model Class Initialized
INFO - 2019-07-01 19:40:11 --> Model Class Initialized
INFO - 2019-07-01 19:40:11 --> Model Class Initialized
INFO - 2019-07-01 19:40:11 --> Model Class Initialized
INFO - 2019-07-01 19:40:11 --> Helper loaded: form_helper
INFO - 2019-07-01 19:40:11 --> Form Validation Class Initialized
DEBUG - 2019-07-01 19:40:11 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 19:40:11 --> Model Class Initialized
INFO - 2019-07-01 19:40:11 --> Model Class Initialized
INFO - 2019-07-01 19:40:11 --> Final output sent to browser
DEBUG - 2019-07-01 19:40:11 --> Total execution time: 0.3037
INFO - 2019-07-01 13:40:13 --> Config Class Initialized
INFO - 2019-07-01 13:40:13 --> Hooks Class Initialized
DEBUG - 2019-07-01 13:40:13 --> UTF-8 Support Enabled
INFO - 2019-07-01 13:40:13 --> Utf8 Class Initialized
INFO - 2019-07-01 13:40:13 --> URI Class Initialized
INFO - 2019-07-01 13:40:13 --> Router Class Initialized
INFO - 2019-07-01 13:40:13 --> Output Class Initialized
INFO - 2019-07-01 13:40:13 --> Security Class Initialized
DEBUG - 2019-07-01 13:40:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 13:40:13 --> Input Class Initialized
INFO - 2019-07-01 13:40:13 --> Language Class Initialized
INFO - 2019-07-01 13:40:13 --> Language Class Initialized
INFO - 2019-07-01 13:40:14 --> Config Class Initialized
INFO - 2019-07-01 13:40:14 --> Loader Class Initialized
DEBUG - 2019-07-01 13:40:14 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 13:40:14 --> Helper loaded: url_helper
INFO - 2019-07-01 13:40:14 --> Helper loaded: inflector_helper
INFO - 2019-07-01 13:40:14 --> Helper loaded: string_helper
INFO - 2019-07-01 13:40:14 --> Helper loaded: array_helper
INFO - 2019-07-01 13:40:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 13:40:14 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 13:40:14 --> Database Driver Class Initialized
INFO - 2019-07-01 13:40:14 --> Controller Class Initialized
INFO - 2019-07-01 19:40:14 --> Helper loaded: language_helper
INFO - 2019-07-01 19:40:14 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 19:40:14 --> Model Class Initialized
INFO - 2019-07-01 19:40:14 --> Model Class Initialized
INFO - 2019-07-01 19:40:14 --> Model Class Initialized
INFO - 2019-07-01 19:40:14 --> Model Class Initialized
INFO - 2019-07-01 19:40:14 --> Model Class Initialized
INFO - 2019-07-01 19:40:14 --> Final output sent to browser
DEBUG - 2019-07-01 19:40:14 --> Total execution time: 0.2289
INFO - 2019-07-01 13:40:17 --> Config Class Initialized
INFO - 2019-07-01 13:40:17 --> Hooks Class Initialized
DEBUG - 2019-07-01 13:40:17 --> UTF-8 Support Enabled
INFO - 2019-07-01 13:40:17 --> Utf8 Class Initialized
INFO - 2019-07-01 13:40:17 --> URI Class Initialized
INFO - 2019-07-01 13:40:17 --> Router Class Initialized
INFO - 2019-07-01 13:40:17 --> Output Class Initialized
INFO - 2019-07-01 13:40:17 --> Security Class Initialized
DEBUG - 2019-07-01 13:40:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 13:40:17 --> Input Class Initialized
INFO - 2019-07-01 13:40:17 --> Language Class Initialized
INFO - 2019-07-01 13:40:17 --> Language Class Initialized
INFO - 2019-07-01 13:40:17 --> Config Class Initialized
INFO - 2019-07-01 13:40:17 --> Loader Class Initialized
DEBUG - 2019-07-01 13:40:17 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 13:40:17 --> Helper loaded: url_helper
INFO - 2019-07-01 13:40:17 --> Helper loaded: inflector_helper
INFO - 2019-07-01 13:40:17 --> Helper loaded: string_helper
INFO - 2019-07-01 13:40:17 --> Helper loaded: array_helper
INFO - 2019-07-01 13:40:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 13:40:17 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 13:40:17 --> Database Driver Class Initialized
INFO - 2019-07-01 13:40:17 --> Controller Class Initialized
INFO - 2019-07-01 19:40:18 --> Helper loaded: language_helper
INFO - 2019-07-01 19:40:18 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 19:40:18 --> Model Class Initialized
INFO - 2019-07-01 19:40:18 --> Model Class Initialized
INFO - 2019-07-01 19:40:18 --> Model Class Initialized
INFO - 2019-07-01 19:40:18 --> Model Class Initialized
INFO - 2019-07-01 19:40:18 --> Helper loaded: form_helper
INFO - 2019-07-01 19:40:18 --> Form Validation Class Initialized
DEBUG - 2019-07-01 19:40:18 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 19:40:18 --> Model Class Initialized
INFO - 2019-07-01 19:40:18 --> Model Class Initialized
INFO - 2019-07-01 19:40:18 --> Final output sent to browser
DEBUG - 2019-07-01 19:40:18 --> Total execution time: 0.4451
INFO - 2019-07-01 13:40:59 --> Config Class Initialized
INFO - 2019-07-01 13:40:59 --> Hooks Class Initialized
DEBUG - 2019-07-01 13:40:59 --> UTF-8 Support Enabled
INFO - 2019-07-01 13:40:59 --> Utf8 Class Initialized
INFO - 2019-07-01 13:40:59 --> URI Class Initialized
INFO - 2019-07-01 13:40:59 --> Router Class Initialized
INFO - 2019-07-01 13:40:59 --> Output Class Initialized
INFO - 2019-07-01 13:40:59 --> Security Class Initialized
DEBUG - 2019-07-01 13:40:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 13:40:59 --> Input Class Initialized
INFO - 2019-07-01 13:40:59 --> Language Class Initialized
INFO - 2019-07-01 13:40:59 --> Language Class Initialized
INFO - 2019-07-01 13:40:59 --> Config Class Initialized
INFO - 2019-07-01 13:40:59 --> Loader Class Initialized
DEBUG - 2019-07-01 13:40:59 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 13:40:59 --> Helper loaded: url_helper
INFO - 2019-07-01 13:40:59 --> Helper loaded: inflector_helper
INFO - 2019-07-01 13:40:59 --> Helper loaded: string_helper
INFO - 2019-07-01 13:40:59 --> Helper loaded: array_helper
INFO - 2019-07-01 13:40:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 13:40:59 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 13:40:59 --> Database Driver Class Initialized
INFO - 2019-07-01 13:40:59 --> Controller Class Initialized
INFO - 2019-07-01 19:40:59 --> Helper loaded: language_helper
INFO - 2019-07-01 19:40:59 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 19:40:59 --> Model Class Initialized
INFO - 2019-07-01 19:40:59 --> Model Class Initialized
INFO - 2019-07-01 19:40:59 --> Model Class Initialized
INFO - 2019-07-01 19:40:59 --> Model Class Initialized
INFO - 2019-07-01 19:40:59 --> Helper loaded: form_helper
INFO - 2019-07-01 19:40:59 --> Form Validation Class Initialized
DEBUG - 2019-07-01 19:40:59 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 19:40:59 --> Model Class Initialized
INFO - 2019-07-01 19:40:59 --> Model Class Initialized
INFO - 2019-07-01 19:40:59 --> Final output sent to browser
DEBUG - 2019-07-01 19:40:59 --> Total execution time: 0.4032
INFO - 2019-07-01 13:41:11 --> Config Class Initialized
INFO - 2019-07-01 13:41:11 --> Hooks Class Initialized
DEBUG - 2019-07-01 13:41:11 --> UTF-8 Support Enabled
INFO - 2019-07-01 13:41:11 --> Utf8 Class Initialized
INFO - 2019-07-01 13:41:11 --> URI Class Initialized
INFO - 2019-07-01 13:41:11 --> Router Class Initialized
INFO - 2019-07-01 13:41:11 --> Output Class Initialized
INFO - 2019-07-01 13:41:11 --> Security Class Initialized
DEBUG - 2019-07-01 13:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 13:41:11 --> Input Class Initialized
INFO - 2019-07-01 13:41:11 --> Language Class Initialized
INFO - 2019-07-01 13:41:11 --> Language Class Initialized
INFO - 2019-07-01 13:41:11 --> Config Class Initialized
INFO - 2019-07-01 13:41:11 --> Loader Class Initialized
DEBUG - 2019-07-01 13:41:11 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 13:41:11 --> Helper loaded: url_helper
INFO - 2019-07-01 13:41:11 --> Helper loaded: inflector_helper
INFO - 2019-07-01 13:41:11 --> Helper loaded: string_helper
INFO - 2019-07-01 13:41:11 --> Helper loaded: array_helper
INFO - 2019-07-01 13:41:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 13:41:11 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 13:41:11 --> Database Driver Class Initialized
INFO - 2019-07-01 13:41:11 --> Controller Class Initialized
INFO - 2019-07-01 19:41:11 --> Helper loaded: language_helper
INFO - 2019-07-01 19:41:11 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 19:41:11 --> Model Class Initialized
INFO - 2019-07-01 19:41:11 --> Model Class Initialized
INFO - 2019-07-01 19:41:11 --> Model Class Initialized
INFO - 2019-07-01 19:41:11 --> Model Class Initialized
INFO - 2019-07-01 19:41:11 --> Helper loaded: form_helper
INFO - 2019-07-01 19:41:11 --> Form Validation Class Initialized
DEBUG - 2019-07-01 19:41:11 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 19:41:11 --> Model Class Initialized
INFO - 2019-07-01 19:41:11 --> Model Class Initialized
INFO - 2019-07-01 19:41:11 --> Final output sent to browser
DEBUG - 2019-07-01 19:41:11 --> Total execution time: 0.2844
INFO - 2019-07-01 13:41:14 --> Config Class Initialized
INFO - 2019-07-01 13:41:14 --> Hooks Class Initialized
DEBUG - 2019-07-01 13:41:14 --> UTF-8 Support Enabled
INFO - 2019-07-01 13:41:14 --> Utf8 Class Initialized
INFO - 2019-07-01 13:41:14 --> URI Class Initialized
INFO - 2019-07-01 13:41:14 --> Router Class Initialized
INFO - 2019-07-01 13:41:14 --> Output Class Initialized
INFO - 2019-07-01 13:41:14 --> Security Class Initialized
DEBUG - 2019-07-01 13:41:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 13:41:14 --> Input Class Initialized
INFO - 2019-07-01 13:41:14 --> Language Class Initialized
INFO - 2019-07-01 13:41:14 --> Language Class Initialized
INFO - 2019-07-01 13:41:14 --> Config Class Initialized
INFO - 2019-07-01 13:41:14 --> Loader Class Initialized
DEBUG - 2019-07-01 13:41:14 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 13:41:14 --> Helper loaded: url_helper
INFO - 2019-07-01 13:41:14 --> Helper loaded: inflector_helper
INFO - 2019-07-01 13:41:14 --> Helper loaded: string_helper
INFO - 2019-07-01 13:41:14 --> Helper loaded: array_helper
INFO - 2019-07-01 13:41:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 13:41:14 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 13:41:14 --> Database Driver Class Initialized
INFO - 2019-07-01 13:41:14 --> Controller Class Initialized
INFO - 2019-07-01 19:41:14 --> Helper loaded: language_helper
INFO - 2019-07-01 19:41:14 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 19:41:14 --> Model Class Initialized
INFO - 2019-07-01 19:41:14 --> Model Class Initialized
INFO - 2019-07-01 19:41:14 --> Model Class Initialized
INFO - 2019-07-01 19:41:14 --> Model Class Initialized
INFO - 2019-07-01 19:41:14 --> Helper loaded: form_helper
INFO - 2019-07-01 19:41:14 --> Form Validation Class Initialized
DEBUG - 2019-07-01 19:41:14 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 19:41:14 --> Model Class Initialized
INFO - 2019-07-01 19:41:14 --> Model Class Initialized
INFO - 2019-07-01 19:41:14 --> Final output sent to browser
DEBUG - 2019-07-01 19:41:14 --> Total execution time: 0.2840
INFO - 2019-07-01 13:41:15 --> Config Class Initialized
INFO - 2019-07-01 13:41:15 --> Hooks Class Initialized
DEBUG - 2019-07-01 13:41:15 --> UTF-8 Support Enabled
INFO - 2019-07-01 13:41:15 --> Utf8 Class Initialized
INFO - 2019-07-01 13:41:15 --> URI Class Initialized
INFO - 2019-07-01 13:41:15 --> Router Class Initialized
INFO - 2019-07-01 13:41:15 --> Output Class Initialized
INFO - 2019-07-01 13:41:15 --> Security Class Initialized
DEBUG - 2019-07-01 13:41:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 13:41:15 --> Input Class Initialized
INFO - 2019-07-01 13:41:15 --> Language Class Initialized
INFO - 2019-07-01 13:41:15 --> Language Class Initialized
INFO - 2019-07-01 13:41:15 --> Config Class Initialized
INFO - 2019-07-01 13:41:15 --> Loader Class Initialized
DEBUG - 2019-07-01 13:41:15 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 13:41:15 --> Helper loaded: url_helper
INFO - 2019-07-01 13:41:15 --> Helper loaded: inflector_helper
INFO - 2019-07-01 13:41:15 --> Helper loaded: string_helper
INFO - 2019-07-01 13:41:15 --> Helper loaded: array_helper
INFO - 2019-07-01 13:41:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 13:41:15 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 13:41:15 --> Database Driver Class Initialized
INFO - 2019-07-01 13:41:15 --> Controller Class Initialized
INFO - 2019-07-01 19:41:15 --> Helper loaded: language_helper
INFO - 2019-07-01 19:41:15 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 19:41:15 --> Model Class Initialized
INFO - 2019-07-01 19:41:15 --> Model Class Initialized
INFO - 2019-07-01 19:41:15 --> Model Class Initialized
INFO - 2019-07-01 19:41:15 --> Model Class Initialized
INFO - 2019-07-01 19:41:15 --> Model Class Initialized
INFO - 2019-07-01 19:41:15 --> Final output sent to browser
DEBUG - 2019-07-01 19:41:15 --> Total execution time: 0.2289
INFO - 2019-07-01 13:41:20 --> Config Class Initialized
INFO - 2019-07-01 13:41:20 --> Hooks Class Initialized
DEBUG - 2019-07-01 13:41:20 --> UTF-8 Support Enabled
INFO - 2019-07-01 13:41:20 --> Utf8 Class Initialized
INFO - 2019-07-01 13:41:20 --> URI Class Initialized
INFO - 2019-07-01 13:41:20 --> Router Class Initialized
INFO - 2019-07-01 13:41:20 --> Output Class Initialized
INFO - 2019-07-01 13:41:20 --> Security Class Initialized
DEBUG - 2019-07-01 13:41:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 13:41:20 --> Input Class Initialized
INFO - 2019-07-01 13:41:20 --> Language Class Initialized
INFO - 2019-07-01 13:41:20 --> Language Class Initialized
INFO - 2019-07-01 13:41:20 --> Config Class Initialized
INFO - 2019-07-01 13:41:20 --> Loader Class Initialized
DEBUG - 2019-07-01 13:41:20 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 13:41:20 --> Helper loaded: url_helper
INFO - 2019-07-01 13:41:20 --> Helper loaded: inflector_helper
INFO - 2019-07-01 13:41:20 --> Helper loaded: string_helper
INFO - 2019-07-01 13:41:20 --> Helper loaded: array_helper
INFO - 2019-07-01 13:41:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 13:41:20 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 13:41:20 --> Database Driver Class Initialized
INFO - 2019-07-01 13:41:20 --> Controller Class Initialized
INFO - 2019-07-01 19:41:20 --> Helper loaded: language_helper
INFO - 2019-07-01 19:41:20 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 19:41:20 --> Model Class Initialized
INFO - 2019-07-01 19:41:20 --> Model Class Initialized
INFO - 2019-07-01 19:41:20 --> Model Class Initialized
INFO - 2019-07-01 19:41:20 --> Model Class Initialized
INFO - 2019-07-01 19:41:20 --> Final output sent to browser
DEBUG - 2019-07-01 19:41:21 --> Total execution time: 0.5724
INFO - 2019-07-01 13:51:54 --> Config Class Initialized
INFO - 2019-07-01 13:51:54 --> Hooks Class Initialized
DEBUG - 2019-07-01 13:51:54 --> UTF-8 Support Enabled
INFO - 2019-07-01 13:51:54 --> Utf8 Class Initialized
INFO - 2019-07-01 13:51:54 --> URI Class Initialized
INFO - 2019-07-01 13:51:54 --> Router Class Initialized
INFO - 2019-07-01 13:51:54 --> Output Class Initialized
INFO - 2019-07-01 13:51:54 --> Security Class Initialized
DEBUG - 2019-07-01 13:51:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 13:51:54 --> Input Class Initialized
INFO - 2019-07-01 13:51:54 --> Language Class Initialized
INFO - 2019-07-01 13:51:54 --> Language Class Initialized
INFO - 2019-07-01 13:51:54 --> Config Class Initialized
INFO - 2019-07-01 13:51:54 --> Loader Class Initialized
DEBUG - 2019-07-01 13:51:54 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 13:51:54 --> Helper loaded: url_helper
INFO - 2019-07-01 13:51:54 --> Helper loaded: inflector_helper
INFO - 2019-07-01 13:51:55 --> Helper loaded: string_helper
INFO - 2019-07-01 13:51:55 --> Helper loaded: array_helper
INFO - 2019-07-01 13:51:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 13:51:55 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 13:51:55 --> Database Driver Class Initialized
INFO - 2019-07-01 13:51:55 --> Controller Class Initialized
INFO - 2019-07-01 19:51:55 --> Helper loaded: language_helper
INFO - 2019-07-01 19:51:55 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 19:51:55 --> Model Class Initialized
INFO - 2019-07-01 19:51:55 --> Model Class Initialized
INFO - 2019-07-01 19:51:55 --> Model Class Initialized
INFO - 2019-07-01 19:51:55 --> Model Class Initialized
INFO - 2019-07-01 19:51:55 --> Final output sent to browser
DEBUG - 2019-07-01 19:51:55 --> Total execution time: 0.2957
INFO - 2019-07-01 13:51:55 --> Config Class Initialized
INFO - 2019-07-01 13:51:55 --> Hooks Class Initialized
INFO - 2019-07-01 13:51:55 --> Config Class Initialized
DEBUG - 2019-07-01 13:51:55 --> UTF-8 Support Enabled
INFO - 2019-07-01 13:51:55 --> Hooks Class Initialized
INFO - 2019-07-01 13:51:55 --> Utf8 Class Initialized
DEBUG - 2019-07-01 13:51:55 --> UTF-8 Support Enabled
INFO - 2019-07-01 13:51:55 --> URI Class Initialized
INFO - 2019-07-01 13:51:55 --> Utf8 Class Initialized
INFO - 2019-07-01 13:51:55 --> URI Class Initialized
INFO - 2019-07-01 13:51:55 --> Router Class Initialized
INFO - 2019-07-01 13:51:55 --> Router Class Initialized
INFO - 2019-07-01 13:51:55 --> Output Class Initialized
INFO - 2019-07-01 13:51:55 --> Output Class Initialized
INFO - 2019-07-01 13:51:55 --> Security Class Initialized
INFO - 2019-07-01 13:51:55 --> Security Class Initialized
DEBUG - 2019-07-01 13:51:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-01 13:51:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 13:51:55 --> Input Class Initialized
INFO - 2019-07-01 13:51:55 --> Input Class Initialized
INFO - 2019-07-01 13:51:55 --> Language Class Initialized
INFO - 2019-07-01 13:51:55 --> Language Class Initialized
INFO - 2019-07-01 13:51:55 --> Language Class Initialized
INFO - 2019-07-01 13:51:55 --> Language Class Initialized
INFO - 2019-07-01 13:51:55 --> Config Class Initialized
INFO - 2019-07-01 13:51:55 --> Loader Class Initialized
INFO - 2019-07-01 13:51:55 --> Config Class Initialized
INFO - 2019-07-01 13:51:55 --> Loader Class Initialized
DEBUG - 2019-07-01 13:51:55 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-01 13:51:55 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 13:51:55 --> Helper loaded: url_helper
INFO - 2019-07-01 13:51:55 --> Helper loaded: url_helper
INFO - 2019-07-01 13:51:55 --> Helper loaded: inflector_helper
INFO - 2019-07-01 13:51:55 --> Helper loaded: inflector_helper
INFO - 2019-07-01 13:51:55 --> Helper loaded: string_helper
INFO - 2019-07-01 13:51:55 --> Helper loaded: string_helper
INFO - 2019-07-01 13:51:55 --> Helper loaded: array_helper
INFO - 2019-07-01 13:51:55 --> Helper loaded: array_helper
INFO - 2019-07-01 13:51:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 13:51:55 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 13:51:55 --> Database Driver Class Initialized
INFO - 2019-07-01 13:51:55 --> Controller Class Initialized
INFO - 2019-07-01 19:51:55 --> Helper loaded: language_helper
INFO - 2019-07-01 19:51:55 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 19:51:55 --> Model Class Initialized
INFO - 2019-07-01 19:51:55 --> Model Class Initialized
INFO - 2019-07-01 19:51:55 --> Model Class Initialized
INFO - 2019-07-01 19:51:55 --> Model Class Initialized
INFO - 2019-07-01 19:51:55 --> Model Class Initialized
INFO - 2019-07-01 19:51:55 --> Final output sent to browser
DEBUG - 2019-07-01 19:51:55 --> Total execution time: 0.3856
INFO - 2019-07-01 13:51:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 13:51:55 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 13:51:55 --> Database Driver Class Initialized
INFO - 2019-07-01 13:51:55 --> Controller Class Initialized
INFO - 2019-07-01 19:51:55 --> Helper loaded: language_helper
INFO - 2019-07-01 19:51:55 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 19:51:55 --> Model Class Initialized
INFO - 2019-07-01 19:51:55 --> Model Class Initialized
INFO - 2019-07-01 19:51:55 --> Model Class Initialized
INFO - 2019-07-01 19:51:55 --> Model Class Initialized
INFO - 2019-07-01 19:51:55 --> Final output sent to browser
DEBUG - 2019-07-01 19:51:55 --> Total execution time: 0.5143
INFO - 2019-07-01 13:52:38 --> Config Class Initialized
INFO - 2019-07-01 13:52:38 --> Hooks Class Initialized
DEBUG - 2019-07-01 13:52:38 --> UTF-8 Support Enabled
INFO - 2019-07-01 13:52:38 --> Utf8 Class Initialized
INFO - 2019-07-01 13:52:38 --> URI Class Initialized
INFO - 2019-07-01 13:52:38 --> Router Class Initialized
INFO - 2019-07-01 13:52:38 --> Output Class Initialized
INFO - 2019-07-01 13:52:38 --> Security Class Initialized
DEBUG - 2019-07-01 13:52:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 13:52:38 --> Input Class Initialized
INFO - 2019-07-01 13:52:38 --> Language Class Initialized
INFO - 2019-07-01 13:52:38 --> Language Class Initialized
INFO - 2019-07-01 13:52:38 --> Config Class Initialized
INFO - 2019-07-01 13:52:38 --> Loader Class Initialized
DEBUG - 2019-07-01 13:52:38 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 13:52:38 --> Helper loaded: url_helper
INFO - 2019-07-01 13:52:38 --> Helper loaded: inflector_helper
INFO - 2019-07-01 13:52:38 --> Helper loaded: string_helper
INFO - 2019-07-01 13:52:38 --> Helper loaded: array_helper
INFO - 2019-07-01 13:52:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 13:52:38 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 13:52:38 --> Database Driver Class Initialized
INFO - 2019-07-01 13:52:38 --> Controller Class Initialized
INFO - 2019-07-01 19:52:38 --> Helper loaded: language_helper
INFO - 2019-07-01 19:52:38 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 19:52:38 --> Model Class Initialized
INFO - 2019-07-01 19:52:38 --> Model Class Initialized
INFO - 2019-07-01 19:52:38 --> Model Class Initialized
INFO - 2019-07-01 19:52:38 --> Model Class Initialized
INFO - 2019-07-01 19:52:38 --> Final output sent to browser
DEBUG - 2019-07-01 19:52:38 --> Total execution time: 0.3292
INFO - 2019-07-01 13:52:38 --> Config Class Initialized
INFO - 2019-07-01 13:52:38 --> Hooks Class Initialized
DEBUG - 2019-07-01 13:52:38 --> UTF-8 Support Enabled
INFO - 2019-07-01 13:52:38 --> Utf8 Class Initialized
INFO - 2019-07-01 13:52:38 --> URI Class Initialized
INFO - 2019-07-01 13:52:38 --> Router Class Initialized
INFO - 2019-07-01 13:52:38 --> Output Class Initialized
INFO - 2019-07-01 13:52:38 --> Security Class Initialized
DEBUG - 2019-07-01 13:52:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 13:52:38 --> Input Class Initialized
INFO - 2019-07-01 13:52:38 --> Language Class Initialized
INFO - 2019-07-01 13:52:38 --> Language Class Initialized
INFO - 2019-07-01 13:52:38 --> Config Class Initialized
INFO - 2019-07-01 13:52:38 --> Loader Class Initialized
DEBUG - 2019-07-01 13:52:38 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 13:52:38 --> Helper loaded: url_helper
INFO - 2019-07-01 13:52:38 --> Helper loaded: inflector_helper
INFO - 2019-07-01 13:52:38 --> Helper loaded: string_helper
INFO - 2019-07-01 13:52:38 --> Helper loaded: array_helper
INFO - 2019-07-01 13:52:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 13:52:38 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 13:52:38 --> Database Driver Class Initialized
INFO - 2019-07-01 13:52:39 --> Controller Class Initialized
INFO - 2019-07-01 19:52:39 --> Helper loaded: language_helper
INFO - 2019-07-01 19:52:39 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 19:52:39 --> Model Class Initialized
INFO - 2019-07-01 19:52:39 --> Model Class Initialized
INFO - 2019-07-01 19:52:39 --> Model Class Initialized
INFO - 2019-07-01 19:52:39 --> Model Class Initialized
INFO - 2019-07-01 19:52:39 --> Final output sent to browser
DEBUG - 2019-07-01 19:52:39 --> Total execution time: 0.2759
INFO - 2019-07-01 13:58:24 --> Config Class Initialized
INFO - 2019-07-01 13:58:24 --> Hooks Class Initialized
DEBUG - 2019-07-01 13:58:24 --> UTF-8 Support Enabled
INFO - 2019-07-01 13:58:24 --> Utf8 Class Initialized
INFO - 2019-07-01 13:58:24 --> URI Class Initialized
INFO - 2019-07-01 13:58:24 --> Router Class Initialized
INFO - 2019-07-01 13:58:24 --> Output Class Initialized
INFO - 2019-07-01 13:58:24 --> Security Class Initialized
DEBUG - 2019-07-01 13:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 13:58:24 --> Input Class Initialized
INFO - 2019-07-01 13:58:24 --> Language Class Initialized
INFO - 2019-07-01 13:58:24 --> Language Class Initialized
INFO - 2019-07-01 13:58:24 --> Config Class Initialized
INFO - 2019-07-01 13:58:24 --> Loader Class Initialized
DEBUG - 2019-07-01 13:58:24 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 13:58:24 --> Helper loaded: url_helper
INFO - 2019-07-01 13:58:24 --> Helper loaded: inflector_helper
INFO - 2019-07-01 13:58:24 --> Helper loaded: string_helper
INFO - 2019-07-01 13:58:24 --> Helper loaded: array_helper
INFO - 2019-07-01 13:58:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 13:58:24 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 13:58:24 --> Database Driver Class Initialized
INFO - 2019-07-01 13:58:24 --> Controller Class Initialized
INFO - 2019-07-01 19:58:24 --> Helper loaded: language_helper
INFO - 2019-07-01 19:58:24 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 19:58:24 --> Model Class Initialized
INFO - 2019-07-01 19:58:24 --> Model Class Initialized
INFO - 2019-07-01 19:58:24 --> Model Class Initialized
INFO - 2019-07-01 19:58:24 --> Model Class Initialized
INFO - 2019-07-01 19:58:24 --> Final output sent to browser
DEBUG - 2019-07-01 19:58:24 --> Total execution time: 0.2727
INFO - 2019-07-01 13:58:24 --> Config Class Initialized
INFO - 2019-07-01 13:58:24 --> Hooks Class Initialized
DEBUG - 2019-07-01 13:58:24 --> UTF-8 Support Enabled
INFO - 2019-07-01 13:58:24 --> Utf8 Class Initialized
INFO - 2019-07-01 13:58:24 --> URI Class Initialized
INFO - 2019-07-01 13:58:24 --> Router Class Initialized
INFO - 2019-07-01 13:58:24 --> Output Class Initialized
INFO - 2019-07-01 13:58:24 --> Security Class Initialized
DEBUG - 2019-07-01 13:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 13:58:24 --> Input Class Initialized
INFO - 2019-07-01 13:58:24 --> Language Class Initialized
INFO - 2019-07-01 13:58:24 --> Language Class Initialized
INFO - 2019-07-01 13:58:24 --> Config Class Initialized
INFO - 2019-07-01 13:58:24 --> Loader Class Initialized
DEBUG - 2019-07-01 13:58:24 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 13:58:24 --> Helper loaded: url_helper
INFO - 2019-07-01 13:58:24 --> Helper loaded: inflector_helper
INFO - 2019-07-01 13:58:24 --> Helper loaded: string_helper
INFO - 2019-07-01 13:58:24 --> Helper loaded: array_helper
INFO - 2019-07-01 13:58:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 13:58:24 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 13:58:24 --> Database Driver Class Initialized
INFO - 2019-07-01 13:58:24 --> Controller Class Initialized
INFO - 2019-07-01 19:58:24 --> Helper loaded: language_helper
INFO - 2019-07-01 19:58:24 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 19:58:24 --> Model Class Initialized
INFO - 2019-07-01 19:58:24 --> Model Class Initialized
INFO - 2019-07-01 19:58:24 --> Model Class Initialized
INFO - 2019-07-01 19:58:24 --> Model Class Initialized
INFO - 2019-07-01 19:58:24 --> Model Class Initialized
INFO - 2019-07-01 19:58:24 --> Final output sent to browser
DEBUG - 2019-07-01 19:58:24 --> Total execution time: 0.2424
INFO - 2019-07-01 13:58:27 --> Config Class Initialized
INFO - 2019-07-01 13:58:27 --> Hooks Class Initialized
DEBUG - 2019-07-01 13:58:27 --> UTF-8 Support Enabled
INFO - 2019-07-01 13:58:27 --> Utf8 Class Initialized
INFO - 2019-07-01 13:58:27 --> URI Class Initialized
INFO - 2019-07-01 13:58:27 --> Router Class Initialized
INFO - 2019-07-01 13:58:27 --> Output Class Initialized
INFO - 2019-07-01 13:58:27 --> Security Class Initialized
DEBUG - 2019-07-01 13:58:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 13:58:27 --> Input Class Initialized
INFO - 2019-07-01 13:58:27 --> Language Class Initialized
INFO - 2019-07-01 13:58:27 --> Language Class Initialized
INFO - 2019-07-01 13:58:27 --> Config Class Initialized
INFO - 2019-07-01 13:58:27 --> Loader Class Initialized
DEBUG - 2019-07-01 13:58:27 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 13:58:27 --> Helper loaded: url_helper
INFO - 2019-07-01 13:58:27 --> Helper loaded: inflector_helper
INFO - 2019-07-01 13:58:27 --> Helper loaded: string_helper
INFO - 2019-07-01 13:58:27 --> Helper loaded: array_helper
INFO - 2019-07-01 13:58:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 13:58:27 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 13:58:27 --> Database Driver Class Initialized
INFO - 2019-07-01 13:58:27 --> Controller Class Initialized
INFO - 2019-07-01 19:58:27 --> Helper loaded: language_helper
INFO - 2019-07-01 19:58:27 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 19:58:27 --> Model Class Initialized
INFO - 2019-07-01 19:58:27 --> Model Class Initialized
INFO - 2019-07-01 19:58:27 --> Model Class Initialized
INFO - 2019-07-01 19:58:27 --> Model Class Initialized
INFO - 2019-07-01 19:58:27 --> Helper loaded: form_helper
INFO - 2019-07-01 19:58:27 --> Form Validation Class Initialized
DEBUG - 2019-07-01 19:58:27 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 19:58:27 --> Model Class Initialized
INFO - 2019-07-01 19:58:27 --> Model Class Initialized
INFO - 2019-07-01 19:58:27 --> Final output sent to browser
DEBUG - 2019-07-01 19:58:27 --> Total execution time: 0.3378
INFO - 2019-07-01 13:58:29 --> Config Class Initialized
INFO - 2019-07-01 13:58:29 --> Hooks Class Initialized
DEBUG - 2019-07-01 13:58:29 --> UTF-8 Support Enabled
INFO - 2019-07-01 13:58:29 --> Utf8 Class Initialized
INFO - 2019-07-01 13:58:29 --> URI Class Initialized
INFO - 2019-07-01 13:58:29 --> Router Class Initialized
INFO - 2019-07-01 13:58:29 --> Output Class Initialized
INFO - 2019-07-01 13:58:29 --> Security Class Initialized
DEBUG - 2019-07-01 13:58:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 13:58:29 --> Input Class Initialized
INFO - 2019-07-01 13:58:29 --> Language Class Initialized
INFO - 2019-07-01 13:58:29 --> Language Class Initialized
INFO - 2019-07-01 13:58:29 --> Config Class Initialized
INFO - 2019-07-01 13:58:29 --> Loader Class Initialized
DEBUG - 2019-07-01 13:58:29 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 13:58:29 --> Helper loaded: url_helper
INFO - 2019-07-01 13:58:29 --> Helper loaded: inflector_helper
INFO - 2019-07-01 13:58:29 --> Helper loaded: string_helper
INFO - 2019-07-01 13:58:29 --> Helper loaded: array_helper
INFO - 2019-07-01 13:58:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 13:58:29 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 13:58:29 --> Database Driver Class Initialized
INFO - 2019-07-01 13:58:29 --> Controller Class Initialized
INFO - 2019-07-01 19:58:29 --> Helper loaded: language_helper
INFO - 2019-07-01 19:58:29 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 19:58:29 --> Model Class Initialized
INFO - 2019-07-01 19:58:29 --> Model Class Initialized
INFO - 2019-07-01 19:58:29 --> Model Class Initialized
INFO - 2019-07-01 19:58:29 --> Model Class Initialized
INFO - 2019-07-01 19:58:29 --> Model Class Initialized
INFO - 2019-07-01 19:58:29 --> Final output sent to browser
DEBUG - 2019-07-01 19:58:29 --> Total execution time: 0.2418
INFO - 2019-07-01 13:58:44 --> Config Class Initialized
INFO - 2019-07-01 13:58:44 --> Hooks Class Initialized
DEBUG - 2019-07-01 13:58:44 --> UTF-8 Support Enabled
INFO - 2019-07-01 13:58:44 --> Utf8 Class Initialized
INFO - 2019-07-01 13:58:44 --> URI Class Initialized
INFO - 2019-07-01 13:58:44 --> Router Class Initialized
INFO - 2019-07-01 13:58:44 --> Output Class Initialized
INFO - 2019-07-01 13:58:44 --> Security Class Initialized
DEBUG - 2019-07-01 13:58:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 13:58:44 --> Input Class Initialized
INFO - 2019-07-01 13:58:44 --> Language Class Initialized
INFO - 2019-07-01 13:58:44 --> Language Class Initialized
INFO - 2019-07-01 13:58:44 --> Config Class Initialized
INFO - 2019-07-01 13:58:44 --> Loader Class Initialized
DEBUG - 2019-07-01 13:58:44 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 13:58:44 --> Helper loaded: url_helper
INFO - 2019-07-01 13:58:44 --> Helper loaded: inflector_helper
INFO - 2019-07-01 13:58:44 --> Helper loaded: string_helper
INFO - 2019-07-01 13:58:44 --> Helper loaded: array_helper
INFO - 2019-07-01 13:58:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 13:58:44 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 13:58:44 --> Database Driver Class Initialized
INFO - 2019-07-01 13:58:44 --> Controller Class Initialized
INFO - 2019-07-01 19:58:44 --> Helper loaded: language_helper
INFO - 2019-07-01 19:58:44 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 19:58:44 --> Model Class Initialized
INFO - 2019-07-01 19:58:44 --> Model Class Initialized
INFO - 2019-07-01 19:58:44 --> Model Class Initialized
INFO - 2019-07-01 19:58:44 --> Model Class Initialized
INFO - 2019-07-01 19:58:44 --> Final output sent to browser
DEBUG - 2019-07-01 19:58:44 --> Total execution time: 0.2253
INFO - 2019-07-01 13:59:37 --> Config Class Initialized
INFO - 2019-07-01 13:59:37 --> Hooks Class Initialized
DEBUG - 2019-07-01 13:59:37 --> UTF-8 Support Enabled
INFO - 2019-07-01 13:59:37 --> Utf8 Class Initialized
INFO - 2019-07-01 13:59:37 --> URI Class Initialized
INFO - 2019-07-01 13:59:37 --> Router Class Initialized
INFO - 2019-07-01 13:59:37 --> Output Class Initialized
INFO - 2019-07-01 13:59:37 --> Security Class Initialized
DEBUG - 2019-07-01 13:59:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 13:59:37 --> Input Class Initialized
INFO - 2019-07-01 13:59:37 --> Language Class Initialized
INFO - 2019-07-01 13:59:37 --> Language Class Initialized
INFO - 2019-07-01 13:59:37 --> Config Class Initialized
INFO - 2019-07-01 13:59:37 --> Loader Class Initialized
DEBUG - 2019-07-01 13:59:37 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 13:59:37 --> Helper loaded: url_helper
INFO - 2019-07-01 13:59:37 --> Helper loaded: inflector_helper
INFO - 2019-07-01 13:59:37 --> Helper loaded: string_helper
INFO - 2019-07-01 13:59:37 --> Helper loaded: array_helper
INFO - 2019-07-01 13:59:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 13:59:37 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 13:59:37 --> Database Driver Class Initialized
INFO - 2019-07-01 13:59:37 --> Controller Class Initialized
INFO - 2019-07-01 19:59:37 --> Helper loaded: language_helper
INFO - 2019-07-01 19:59:37 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 19:59:37 --> Model Class Initialized
INFO - 2019-07-01 19:59:37 --> Model Class Initialized
INFO - 2019-07-01 19:59:37 --> Model Class Initialized
INFO - 2019-07-01 19:59:37 --> Model Class Initialized
INFO - 2019-07-01 19:59:37 --> Final output sent to browser
DEBUG - 2019-07-01 19:59:37 --> Total execution time: 0.2918
INFO - 2019-07-01 14:01:43 --> Config Class Initialized
INFO - 2019-07-01 14:01:43 --> Hooks Class Initialized
DEBUG - 2019-07-01 14:01:43 --> UTF-8 Support Enabled
INFO - 2019-07-01 14:01:43 --> Utf8 Class Initialized
INFO - 2019-07-01 14:01:43 --> URI Class Initialized
INFO - 2019-07-01 14:01:43 --> Router Class Initialized
INFO - 2019-07-01 14:01:43 --> Output Class Initialized
INFO - 2019-07-01 14:01:43 --> Security Class Initialized
DEBUG - 2019-07-01 14:01:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 14:01:43 --> Input Class Initialized
INFO - 2019-07-01 14:01:43 --> Language Class Initialized
INFO - 2019-07-01 14:01:43 --> Language Class Initialized
INFO - 2019-07-01 14:01:44 --> Config Class Initialized
INFO - 2019-07-01 14:01:44 --> Loader Class Initialized
DEBUG - 2019-07-01 14:01:44 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 14:01:44 --> Helper loaded: url_helper
INFO - 2019-07-01 14:01:44 --> Helper loaded: inflector_helper
INFO - 2019-07-01 14:01:44 --> Helper loaded: string_helper
INFO - 2019-07-01 14:01:44 --> Helper loaded: array_helper
INFO - 2019-07-01 14:01:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 14:01:44 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 14:01:44 --> Database Driver Class Initialized
INFO - 2019-07-01 14:01:44 --> Controller Class Initialized
INFO - 2019-07-01 20:01:44 --> Helper loaded: language_helper
INFO - 2019-07-01 20:01:44 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 20:01:44 --> Model Class Initialized
INFO - 2019-07-01 20:01:44 --> Model Class Initialized
INFO - 2019-07-01 20:01:44 --> Model Class Initialized
INFO - 2019-07-01 20:01:44 --> Model Class Initialized
INFO - 2019-07-01 20:01:44 --> Final output sent to browser
DEBUG - 2019-07-01 20:01:44 --> Total execution time: 0.2957
INFO - 2019-07-01 14:01:44 --> Config Class Initialized
INFO - 2019-07-01 14:01:44 --> Hooks Class Initialized
INFO - 2019-07-01 14:01:44 --> Config Class Initialized
DEBUG - 2019-07-01 14:01:44 --> UTF-8 Support Enabled
INFO - 2019-07-01 14:01:44 --> Hooks Class Initialized
INFO - 2019-07-01 14:01:44 --> Utf8 Class Initialized
DEBUG - 2019-07-01 14:01:44 --> UTF-8 Support Enabled
INFO - 2019-07-01 14:01:44 --> Utf8 Class Initialized
INFO - 2019-07-01 14:01:44 --> URI Class Initialized
INFO - 2019-07-01 14:01:44 --> URI Class Initialized
INFO - 2019-07-01 14:01:44 --> Router Class Initialized
INFO - 2019-07-01 14:01:44 --> Router Class Initialized
INFO - 2019-07-01 14:01:44 --> Output Class Initialized
INFO - 2019-07-01 14:01:44 --> Output Class Initialized
INFO - 2019-07-01 14:01:44 --> Security Class Initialized
INFO - 2019-07-01 14:01:44 --> Security Class Initialized
DEBUG - 2019-07-01 14:01:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-01 14:01:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 14:01:44 --> Input Class Initialized
INFO - 2019-07-01 14:01:44 --> Input Class Initialized
INFO - 2019-07-01 14:01:44 --> Language Class Initialized
INFO - 2019-07-01 14:01:44 --> Language Class Initialized
INFO - 2019-07-01 14:01:44 --> Language Class Initialized
INFO - 2019-07-01 14:01:44 --> Language Class Initialized
INFO - 2019-07-01 14:01:44 --> Config Class Initialized
INFO - 2019-07-01 14:01:44 --> Loader Class Initialized
INFO - 2019-07-01 14:01:44 --> Config Class Initialized
INFO - 2019-07-01 14:01:44 --> Loader Class Initialized
DEBUG - 2019-07-01 14:01:44 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-01 14:01:44 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 14:01:44 --> Helper loaded: url_helper
INFO - 2019-07-01 14:01:44 --> Helper loaded: url_helper
INFO - 2019-07-01 14:01:44 --> Helper loaded: inflector_helper
INFO - 2019-07-01 14:01:44 --> Helper loaded: inflector_helper
INFO - 2019-07-01 14:01:44 --> Helper loaded: string_helper
INFO - 2019-07-01 14:01:44 --> Helper loaded: string_helper
INFO - 2019-07-01 14:01:44 --> Helper loaded: array_helper
INFO - 2019-07-01 14:01:44 --> Helper loaded: array_helper
INFO - 2019-07-01 14:01:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 14:01:44 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 14:01:44 --> Database Driver Class Initialized
INFO - 2019-07-01 14:01:44 --> Controller Class Initialized
INFO - 2019-07-01 20:01:44 --> Helper loaded: language_helper
INFO - 2019-07-01 20:01:44 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 20:01:44 --> Model Class Initialized
INFO - 2019-07-01 20:01:44 --> Model Class Initialized
INFO - 2019-07-01 20:01:44 --> Model Class Initialized
INFO - 2019-07-01 20:01:44 --> Model Class Initialized
INFO - 2019-07-01 20:01:44 --> Model Class Initialized
INFO - 2019-07-01 20:01:44 --> Final output sent to browser
DEBUG - 2019-07-01 20:01:44 --> Total execution time: 0.3252
INFO - 2019-07-01 14:01:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 14:01:44 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 14:01:44 --> Database Driver Class Initialized
INFO - 2019-07-01 14:01:44 --> Controller Class Initialized
INFO - 2019-07-01 20:01:44 --> Helper loaded: language_helper
INFO - 2019-07-01 20:01:44 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 20:01:44 --> Model Class Initialized
INFO - 2019-07-01 20:01:44 --> Model Class Initialized
INFO - 2019-07-01 20:01:44 --> Model Class Initialized
INFO - 2019-07-01 20:01:44 --> Model Class Initialized
INFO - 2019-07-01 20:01:44 --> Final output sent to browser
DEBUG - 2019-07-01 20:01:44 --> Total execution time: 0.4248
INFO - 2019-07-01 14:02:06 --> Config Class Initialized
INFO - 2019-07-01 14:02:06 --> Hooks Class Initialized
DEBUG - 2019-07-01 14:02:06 --> UTF-8 Support Enabled
INFO - 2019-07-01 14:02:06 --> Utf8 Class Initialized
INFO - 2019-07-01 14:02:06 --> URI Class Initialized
INFO - 2019-07-01 14:02:06 --> Router Class Initialized
INFO - 2019-07-01 14:02:06 --> Output Class Initialized
INFO - 2019-07-01 14:02:06 --> Security Class Initialized
DEBUG - 2019-07-01 14:02:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 14:02:06 --> Input Class Initialized
INFO - 2019-07-01 14:02:06 --> Language Class Initialized
INFO - 2019-07-01 14:02:06 --> Language Class Initialized
INFO - 2019-07-01 14:02:06 --> Config Class Initialized
INFO - 2019-07-01 14:02:06 --> Loader Class Initialized
DEBUG - 2019-07-01 14:02:06 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 14:02:06 --> Helper loaded: url_helper
INFO - 2019-07-01 14:02:06 --> Helper loaded: inflector_helper
INFO - 2019-07-01 14:02:06 --> Helper loaded: string_helper
INFO - 2019-07-01 14:02:06 --> Helper loaded: array_helper
INFO - 2019-07-01 14:02:06 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 14:02:06 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 14:02:06 --> Database Driver Class Initialized
INFO - 2019-07-01 14:02:06 --> Controller Class Initialized
INFO - 2019-07-01 20:02:06 --> Helper loaded: language_helper
INFO - 2019-07-01 20:02:06 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 20:02:06 --> Model Class Initialized
INFO - 2019-07-01 20:02:06 --> Model Class Initialized
INFO - 2019-07-01 20:02:06 --> Model Class Initialized
INFO - 2019-07-01 20:02:06 --> Model Class Initialized
INFO - 2019-07-01 20:02:07 --> Final output sent to browser
DEBUG - 2019-07-01 20:02:07 --> Total execution time: 0.2877
INFO - 2019-07-01 14:02:07 --> Config Class Initialized
INFO - 2019-07-01 14:02:07 --> Hooks Class Initialized
DEBUG - 2019-07-01 14:02:07 --> UTF-8 Support Enabled
INFO - 2019-07-01 14:02:07 --> Utf8 Class Initialized
INFO - 2019-07-01 14:02:07 --> URI Class Initialized
INFO - 2019-07-01 14:02:07 --> Router Class Initialized
INFO - 2019-07-01 14:02:07 --> Output Class Initialized
INFO - 2019-07-01 14:02:07 --> Security Class Initialized
DEBUG - 2019-07-01 14:02:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 14:02:07 --> Input Class Initialized
INFO - 2019-07-01 14:02:07 --> Language Class Initialized
INFO - 2019-07-01 14:02:07 --> Language Class Initialized
INFO - 2019-07-01 14:02:07 --> Config Class Initialized
INFO - 2019-07-01 14:02:07 --> Loader Class Initialized
DEBUG - 2019-07-01 14:02:07 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 14:02:07 --> Helper loaded: url_helper
INFO - 2019-07-01 14:02:07 --> Helper loaded: inflector_helper
INFO - 2019-07-01 14:02:07 --> Helper loaded: string_helper
INFO - 2019-07-01 14:02:07 --> Helper loaded: array_helper
INFO - 2019-07-01 14:02:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 14:02:07 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 14:02:07 --> Database Driver Class Initialized
INFO - 2019-07-01 14:02:07 --> Controller Class Initialized
INFO - 2019-07-01 20:02:07 --> Helper loaded: language_helper
INFO - 2019-07-01 20:02:07 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 20:02:07 --> Model Class Initialized
INFO - 2019-07-01 20:02:07 --> Model Class Initialized
INFO - 2019-07-01 20:02:07 --> Model Class Initialized
INFO - 2019-07-01 20:02:07 --> Model Class Initialized
INFO - 2019-07-01 20:02:07 --> Final output sent to browser
DEBUG - 2019-07-01 20:02:07 --> Total execution time: 0.2489
INFO - 2019-07-01 14:03:59 --> Config Class Initialized
INFO - 2019-07-01 14:03:59 --> Hooks Class Initialized
DEBUG - 2019-07-01 14:03:59 --> UTF-8 Support Enabled
INFO - 2019-07-01 14:03:59 --> Utf8 Class Initialized
INFO - 2019-07-01 14:03:59 --> URI Class Initialized
INFO - 2019-07-01 14:03:59 --> Router Class Initialized
INFO - 2019-07-01 14:03:59 --> Output Class Initialized
INFO - 2019-07-01 14:03:59 --> Security Class Initialized
DEBUG - 2019-07-01 14:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 14:03:59 --> Input Class Initialized
INFO - 2019-07-01 14:03:59 --> Language Class Initialized
INFO - 2019-07-01 14:03:59 --> Language Class Initialized
INFO - 2019-07-01 14:03:59 --> Config Class Initialized
INFO - 2019-07-01 14:03:59 --> Loader Class Initialized
DEBUG - 2019-07-01 14:03:59 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 14:03:59 --> Helper loaded: url_helper
INFO - 2019-07-01 14:03:59 --> Helper loaded: inflector_helper
INFO - 2019-07-01 14:03:59 --> Helper loaded: string_helper
INFO - 2019-07-01 14:03:59 --> Helper loaded: array_helper
INFO - 2019-07-01 14:03:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 14:03:59 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 14:03:59 --> Database Driver Class Initialized
INFO - 2019-07-01 14:03:59 --> Controller Class Initialized
INFO - 2019-07-01 20:03:59 --> Helper loaded: language_helper
INFO - 2019-07-01 20:03:59 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 20:03:59 --> Model Class Initialized
INFO - 2019-07-01 20:03:59 --> Model Class Initialized
INFO - 2019-07-01 20:03:59 --> Model Class Initialized
INFO - 2019-07-01 20:03:59 --> Model Class Initialized
INFO - 2019-07-01 20:04:00 --> Final output sent to browser
DEBUG - 2019-07-01 20:04:00 --> Total execution time: 0.3430
INFO - 2019-07-01 14:04:00 --> Config Class Initialized
INFO - 2019-07-01 14:04:00 --> Hooks Class Initialized
DEBUG - 2019-07-01 14:04:00 --> UTF-8 Support Enabled
INFO - 2019-07-01 14:04:00 --> Utf8 Class Initialized
INFO - 2019-07-01 14:04:00 --> URI Class Initialized
INFO - 2019-07-01 14:04:00 --> Router Class Initialized
INFO - 2019-07-01 14:04:00 --> Output Class Initialized
INFO - 2019-07-01 14:04:00 --> Security Class Initialized
DEBUG - 2019-07-01 14:04:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 14:04:00 --> Input Class Initialized
INFO - 2019-07-01 14:04:00 --> Language Class Initialized
INFO - 2019-07-01 14:04:00 --> Language Class Initialized
INFO - 2019-07-01 14:04:00 --> Config Class Initialized
INFO - 2019-07-01 14:04:00 --> Loader Class Initialized
DEBUG - 2019-07-01 14:04:00 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 14:04:00 --> Helper loaded: url_helper
INFO - 2019-07-01 14:04:00 --> Helper loaded: inflector_helper
INFO - 2019-07-01 14:04:00 --> Helper loaded: string_helper
INFO - 2019-07-01 14:04:00 --> Helper loaded: array_helper
INFO - 2019-07-01 14:04:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 14:04:00 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 14:04:00 --> Database Driver Class Initialized
INFO - 2019-07-01 14:04:00 --> Controller Class Initialized
INFO - 2019-07-01 20:04:00 --> Helper loaded: language_helper
INFO - 2019-07-01 20:04:00 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 20:04:00 --> Model Class Initialized
INFO - 2019-07-01 20:04:00 --> Model Class Initialized
INFO - 2019-07-01 20:04:00 --> Model Class Initialized
INFO - 2019-07-01 20:04:00 --> Model Class Initialized
INFO - 2019-07-01 20:04:00 --> Model Class Initialized
INFO - 2019-07-01 20:04:00 --> Final output sent to browser
DEBUG - 2019-07-01 20:04:00 --> Total execution time: 0.3293
INFO - 2019-07-01 14:04:03 --> Config Class Initialized
INFO - 2019-07-01 14:04:03 --> Hooks Class Initialized
DEBUG - 2019-07-01 14:04:03 --> UTF-8 Support Enabled
INFO - 2019-07-01 14:04:03 --> Utf8 Class Initialized
INFO - 2019-07-01 14:04:03 --> URI Class Initialized
INFO - 2019-07-01 14:04:03 --> Router Class Initialized
INFO - 2019-07-01 14:04:03 --> Output Class Initialized
INFO - 2019-07-01 14:04:03 --> Security Class Initialized
DEBUG - 2019-07-01 14:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 14:04:03 --> Input Class Initialized
INFO - 2019-07-01 14:04:03 --> Language Class Initialized
INFO - 2019-07-01 14:04:03 --> Language Class Initialized
INFO - 2019-07-01 14:04:03 --> Config Class Initialized
INFO - 2019-07-01 14:04:03 --> Loader Class Initialized
DEBUG - 2019-07-01 14:04:03 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 14:04:03 --> Helper loaded: url_helper
INFO - 2019-07-01 14:04:03 --> Helper loaded: inflector_helper
INFO - 2019-07-01 14:04:03 --> Helper loaded: string_helper
INFO - 2019-07-01 14:04:03 --> Helper loaded: array_helper
INFO - 2019-07-01 14:04:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 14:04:03 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 14:04:03 --> Database Driver Class Initialized
INFO - 2019-07-01 14:04:04 --> Controller Class Initialized
INFO - 2019-07-01 20:04:04 --> Helper loaded: language_helper
INFO - 2019-07-01 20:04:04 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 20:04:04 --> Model Class Initialized
INFO - 2019-07-01 20:04:04 --> Model Class Initialized
INFO - 2019-07-01 20:04:04 --> Model Class Initialized
INFO - 2019-07-01 20:04:04 --> Model Class Initialized
INFO - 2019-07-01 20:04:04 --> Helper loaded: form_helper
INFO - 2019-07-01 20:04:04 --> Form Validation Class Initialized
DEBUG - 2019-07-01 20:04:04 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 20:04:04 --> Model Class Initialized
INFO - 2019-07-01 20:04:04 --> Model Class Initialized
INFO - 2019-07-01 20:04:04 --> Final output sent to browser
DEBUG - 2019-07-01 20:04:04 --> Total execution time: 0.3743
INFO - 2019-07-01 14:04:05 --> Config Class Initialized
INFO - 2019-07-01 14:04:05 --> Hooks Class Initialized
DEBUG - 2019-07-01 14:04:05 --> UTF-8 Support Enabled
INFO - 2019-07-01 14:04:05 --> Utf8 Class Initialized
INFO - 2019-07-01 14:04:05 --> URI Class Initialized
INFO - 2019-07-01 14:04:05 --> Router Class Initialized
INFO - 2019-07-01 14:04:05 --> Output Class Initialized
INFO - 2019-07-01 14:04:05 --> Security Class Initialized
DEBUG - 2019-07-01 14:04:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 14:04:05 --> Input Class Initialized
INFO - 2019-07-01 14:04:05 --> Language Class Initialized
INFO - 2019-07-01 14:04:05 --> Language Class Initialized
INFO - 2019-07-01 14:04:05 --> Config Class Initialized
INFO - 2019-07-01 14:04:05 --> Loader Class Initialized
DEBUG - 2019-07-01 14:04:05 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 14:04:05 --> Helper loaded: url_helper
INFO - 2019-07-01 14:04:05 --> Helper loaded: inflector_helper
INFO - 2019-07-01 14:04:05 --> Helper loaded: string_helper
INFO - 2019-07-01 14:04:05 --> Helper loaded: array_helper
INFO - 2019-07-01 14:04:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 14:04:05 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 14:04:05 --> Database Driver Class Initialized
INFO - 2019-07-01 14:04:05 --> Controller Class Initialized
INFO - 2019-07-01 20:04:05 --> Helper loaded: language_helper
INFO - 2019-07-01 20:04:05 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 20:04:05 --> Model Class Initialized
INFO - 2019-07-01 20:04:05 --> Model Class Initialized
INFO - 2019-07-01 20:04:05 --> Model Class Initialized
INFO - 2019-07-01 20:04:05 --> Model Class Initialized
INFO - 2019-07-01 20:04:05 --> Model Class Initialized
INFO - 2019-07-01 20:04:05 --> Final output sent to browser
DEBUG - 2019-07-01 20:04:06 --> Total execution time: 0.2866
INFO - 2019-07-01 14:04:14 --> Config Class Initialized
INFO - 2019-07-01 14:04:14 --> Hooks Class Initialized
DEBUG - 2019-07-01 14:04:14 --> UTF-8 Support Enabled
INFO - 2019-07-01 14:04:14 --> Utf8 Class Initialized
INFO - 2019-07-01 14:04:14 --> URI Class Initialized
INFO - 2019-07-01 14:04:14 --> Router Class Initialized
INFO - 2019-07-01 14:04:14 --> Output Class Initialized
INFO - 2019-07-01 14:04:14 --> Security Class Initialized
DEBUG - 2019-07-01 14:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 14:04:14 --> Input Class Initialized
INFO - 2019-07-01 14:04:14 --> Language Class Initialized
INFO - 2019-07-01 14:04:14 --> Language Class Initialized
INFO - 2019-07-01 14:04:14 --> Config Class Initialized
INFO - 2019-07-01 14:04:14 --> Loader Class Initialized
DEBUG - 2019-07-01 14:04:14 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 14:04:14 --> Helper loaded: url_helper
INFO - 2019-07-01 14:04:14 --> Helper loaded: inflector_helper
INFO - 2019-07-01 14:04:14 --> Helper loaded: string_helper
INFO - 2019-07-01 14:04:14 --> Helper loaded: array_helper
INFO - 2019-07-01 14:04:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 14:04:14 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 14:04:14 --> Database Driver Class Initialized
INFO - 2019-07-01 14:04:14 --> Controller Class Initialized
INFO - 2019-07-01 20:04:14 --> Helper loaded: language_helper
INFO - 2019-07-01 20:04:14 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 20:04:14 --> Model Class Initialized
INFO - 2019-07-01 20:04:14 --> Model Class Initialized
INFO - 2019-07-01 20:04:14 --> Model Class Initialized
INFO - 2019-07-01 20:04:14 --> Model Class Initialized
INFO - 2019-07-01 20:04:14 --> Final output sent to browser
DEBUG - 2019-07-01 20:04:14 --> Total execution time: 0.2531
INFO - 2019-07-01 14:05:10 --> Config Class Initialized
INFO - 2019-07-01 14:05:10 --> Hooks Class Initialized
DEBUG - 2019-07-01 14:05:10 --> UTF-8 Support Enabled
INFO - 2019-07-01 14:05:10 --> Utf8 Class Initialized
INFO - 2019-07-01 14:05:10 --> URI Class Initialized
INFO - 2019-07-01 14:05:10 --> Router Class Initialized
INFO - 2019-07-01 14:05:10 --> Output Class Initialized
INFO - 2019-07-01 14:05:10 --> Security Class Initialized
DEBUG - 2019-07-01 14:05:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 14:05:10 --> Input Class Initialized
INFO - 2019-07-01 14:05:10 --> Language Class Initialized
INFO - 2019-07-01 14:05:10 --> Language Class Initialized
INFO - 2019-07-01 14:05:10 --> Config Class Initialized
INFO - 2019-07-01 14:05:11 --> Loader Class Initialized
DEBUG - 2019-07-01 14:05:11 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 14:05:11 --> Helper loaded: url_helper
INFO - 2019-07-01 14:05:11 --> Helper loaded: inflector_helper
INFO - 2019-07-01 14:05:11 --> Helper loaded: string_helper
INFO - 2019-07-01 14:05:11 --> Helper loaded: array_helper
INFO - 2019-07-01 14:05:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 14:05:11 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 14:05:11 --> Database Driver Class Initialized
INFO - 2019-07-01 14:05:11 --> Controller Class Initialized
INFO - 2019-07-01 20:05:11 --> Helper loaded: language_helper
INFO - 2019-07-01 20:05:11 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 20:05:11 --> Model Class Initialized
INFO - 2019-07-01 20:05:11 --> Model Class Initialized
INFO - 2019-07-01 20:05:11 --> Model Class Initialized
INFO - 2019-07-01 20:05:11 --> Model Class Initialized
INFO - 2019-07-01 20:05:11 --> Final output sent to browser
DEBUG - 2019-07-01 20:05:11 --> Total execution time: 0.2435
INFO - 2019-07-01 14:06:09 --> Config Class Initialized
INFO - 2019-07-01 14:06:09 --> Hooks Class Initialized
DEBUG - 2019-07-01 14:06:09 --> UTF-8 Support Enabled
INFO - 2019-07-01 14:06:09 --> Utf8 Class Initialized
INFO - 2019-07-01 14:06:09 --> URI Class Initialized
INFO - 2019-07-01 14:06:09 --> Router Class Initialized
INFO - 2019-07-01 14:06:09 --> Output Class Initialized
INFO - 2019-07-01 14:06:09 --> Security Class Initialized
DEBUG - 2019-07-01 14:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 14:06:09 --> Input Class Initialized
INFO - 2019-07-01 14:06:10 --> Language Class Initialized
INFO - 2019-07-01 14:06:10 --> Language Class Initialized
INFO - 2019-07-01 14:06:10 --> Config Class Initialized
INFO - 2019-07-01 14:06:10 --> Loader Class Initialized
DEBUG - 2019-07-01 14:06:10 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 14:06:10 --> Helper loaded: url_helper
INFO - 2019-07-01 14:06:10 --> Helper loaded: inflector_helper
INFO - 2019-07-01 14:06:10 --> Helper loaded: string_helper
INFO - 2019-07-01 14:06:10 --> Helper loaded: array_helper
INFO - 2019-07-01 14:06:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 14:06:10 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 14:06:10 --> Database Driver Class Initialized
INFO - 2019-07-01 14:06:10 --> Controller Class Initialized
INFO - 2019-07-01 20:06:10 --> Helper loaded: language_helper
INFO - 2019-07-01 20:06:10 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 20:06:10 --> Model Class Initialized
INFO - 2019-07-01 20:06:10 --> Model Class Initialized
INFO - 2019-07-01 20:06:10 --> Model Class Initialized
INFO - 2019-07-01 20:06:10 --> Model Class Initialized
INFO - 2019-07-01 20:06:10 --> Helper loaded: form_helper
INFO - 2019-07-01 20:06:10 --> Form Validation Class Initialized
DEBUG - 2019-07-01 20:06:10 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 20:06:10 --> Model Class Initialized
INFO - 2019-07-01 20:06:10 --> Model Class Initialized
INFO - 2019-07-01 20:06:10 --> Final output sent to browser
DEBUG - 2019-07-01 20:06:10 --> Total execution time: 0.3663
INFO - 2019-07-01 14:06:30 --> Config Class Initialized
INFO - 2019-07-01 14:06:30 --> Hooks Class Initialized
DEBUG - 2019-07-01 14:06:30 --> UTF-8 Support Enabled
INFO - 2019-07-01 14:06:31 --> Utf8 Class Initialized
INFO - 2019-07-01 14:06:31 --> URI Class Initialized
INFO - 2019-07-01 14:06:31 --> Router Class Initialized
INFO - 2019-07-01 14:06:31 --> Output Class Initialized
INFO - 2019-07-01 14:06:31 --> Security Class Initialized
DEBUG - 2019-07-01 14:06:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 14:06:31 --> Input Class Initialized
INFO - 2019-07-01 14:06:31 --> Language Class Initialized
INFO - 2019-07-01 14:06:31 --> Language Class Initialized
INFO - 2019-07-01 14:06:31 --> Config Class Initialized
INFO - 2019-07-01 14:06:31 --> Loader Class Initialized
DEBUG - 2019-07-01 14:06:31 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 14:06:31 --> Helper loaded: url_helper
INFO - 2019-07-01 14:06:31 --> Helper loaded: inflector_helper
INFO - 2019-07-01 14:06:31 --> Helper loaded: string_helper
INFO - 2019-07-01 14:06:31 --> Helper loaded: array_helper
INFO - 2019-07-01 14:06:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 14:06:31 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 14:06:31 --> Database Driver Class Initialized
INFO - 2019-07-01 14:06:31 --> Controller Class Initialized
INFO - 2019-07-01 20:06:31 --> Helper loaded: language_helper
INFO - 2019-07-01 20:06:31 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 20:06:31 --> Model Class Initialized
INFO - 2019-07-01 20:06:31 --> Model Class Initialized
INFO - 2019-07-01 20:06:31 --> Model Class Initialized
INFO - 2019-07-01 20:06:31 --> Model Class Initialized
INFO - 2019-07-01 20:06:31 --> Helper loaded: form_helper
INFO - 2019-07-01 20:06:31 --> Form Validation Class Initialized
DEBUG - 2019-07-01 20:06:31 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 20:06:31 --> Model Class Initialized
INFO - 2019-07-01 20:06:31 --> Model Class Initialized
INFO - 2019-07-01 20:06:31 --> Final output sent to browser
DEBUG - 2019-07-01 20:06:31 --> Total execution time: 0.3558
INFO - 2019-07-01 14:10:59 --> Config Class Initialized
INFO - 2019-07-01 14:10:59 --> Hooks Class Initialized
DEBUG - 2019-07-01 14:10:59 --> UTF-8 Support Enabled
INFO - 2019-07-01 14:10:59 --> Utf8 Class Initialized
INFO - 2019-07-01 14:10:59 --> URI Class Initialized
INFO - 2019-07-01 14:10:59 --> Router Class Initialized
INFO - 2019-07-01 14:10:59 --> Output Class Initialized
INFO - 2019-07-01 14:10:59 --> Security Class Initialized
DEBUG - 2019-07-01 14:10:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 14:10:59 --> Input Class Initialized
INFO - 2019-07-01 14:10:59 --> Language Class Initialized
INFO - 2019-07-01 14:10:59 --> Language Class Initialized
INFO - 2019-07-01 14:10:59 --> Config Class Initialized
INFO - 2019-07-01 14:10:59 --> Loader Class Initialized
DEBUG - 2019-07-01 14:10:59 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 14:10:59 --> Helper loaded: url_helper
INFO - 2019-07-01 14:10:59 --> Helper loaded: inflector_helper
INFO - 2019-07-01 14:10:59 --> Helper loaded: string_helper
INFO - 2019-07-01 14:10:59 --> Helper loaded: array_helper
INFO - 2019-07-01 14:10:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 14:10:59 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 14:10:59 --> Database Driver Class Initialized
INFO - 2019-07-01 14:10:59 --> Controller Class Initialized
INFO - 2019-07-01 20:10:59 --> Helper loaded: language_helper
INFO - 2019-07-01 20:10:59 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 20:10:59 --> Model Class Initialized
INFO - 2019-07-01 20:10:59 --> Model Class Initialized
INFO - 2019-07-01 20:10:59 --> Model Class Initialized
INFO - 2019-07-01 20:10:59 --> Model Class Initialized
INFO - 2019-07-01 20:10:59 --> Helper loaded: form_helper
INFO - 2019-07-01 20:10:59 --> Form Validation Class Initialized
DEBUG - 2019-07-01 20:10:59 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 20:10:59 --> Model Class Initialized
INFO - 2019-07-01 20:10:59 --> Model Class Initialized
INFO - 2019-07-01 20:10:59 --> Final output sent to browser
DEBUG - 2019-07-01 20:10:59 --> Total execution time: 0.3015
INFO - 2019-07-01 14:11:03 --> Config Class Initialized
INFO - 2019-07-01 14:11:03 --> Hooks Class Initialized
DEBUG - 2019-07-01 14:11:03 --> UTF-8 Support Enabled
INFO - 2019-07-01 14:11:03 --> Utf8 Class Initialized
INFO - 2019-07-01 14:11:03 --> URI Class Initialized
INFO - 2019-07-01 14:11:03 --> Router Class Initialized
INFO - 2019-07-01 14:11:03 --> Output Class Initialized
INFO - 2019-07-01 14:11:03 --> Security Class Initialized
DEBUG - 2019-07-01 14:11:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 14:11:03 --> Input Class Initialized
INFO - 2019-07-01 14:11:03 --> Language Class Initialized
INFO - 2019-07-01 14:11:03 --> Language Class Initialized
INFO - 2019-07-01 14:11:03 --> Config Class Initialized
INFO - 2019-07-01 14:11:03 --> Loader Class Initialized
DEBUG - 2019-07-01 14:11:03 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 14:11:03 --> Helper loaded: url_helper
INFO - 2019-07-01 14:11:03 --> Helper loaded: inflector_helper
INFO - 2019-07-01 14:11:03 --> Helper loaded: string_helper
INFO - 2019-07-01 14:11:03 --> Helper loaded: array_helper
INFO - 2019-07-01 14:11:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 14:11:03 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 14:11:03 --> Database Driver Class Initialized
INFO - 2019-07-01 14:11:03 --> Controller Class Initialized
INFO - 2019-07-01 20:11:03 --> Helper loaded: language_helper
INFO - 2019-07-01 20:11:03 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 20:11:03 --> Model Class Initialized
INFO - 2019-07-01 20:11:03 --> Model Class Initialized
INFO - 2019-07-01 20:11:03 --> Model Class Initialized
INFO - 2019-07-01 20:11:03 --> Model Class Initialized
INFO - 2019-07-01 20:11:03 --> Helper loaded: form_helper
INFO - 2019-07-01 20:11:03 --> Form Validation Class Initialized
DEBUG - 2019-07-01 20:11:03 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 20:11:03 --> Model Class Initialized
INFO - 2019-07-01 20:11:03 --> Model Class Initialized
INFO - 2019-07-01 20:11:03 --> Final output sent to browser
DEBUG - 2019-07-01 20:11:03 --> Total execution time: 0.2911
INFO - 2019-07-01 14:13:49 --> Config Class Initialized
INFO - 2019-07-01 14:13:49 --> Hooks Class Initialized
DEBUG - 2019-07-01 14:13:49 --> UTF-8 Support Enabled
INFO - 2019-07-01 14:13:49 --> Utf8 Class Initialized
INFO - 2019-07-01 14:13:49 --> URI Class Initialized
INFO - 2019-07-01 14:13:49 --> Router Class Initialized
INFO - 2019-07-01 14:13:49 --> Output Class Initialized
INFO - 2019-07-01 14:13:49 --> Security Class Initialized
DEBUG - 2019-07-01 14:13:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 14:13:49 --> Input Class Initialized
INFO - 2019-07-01 14:13:49 --> Language Class Initialized
INFO - 2019-07-01 14:13:49 --> Language Class Initialized
INFO - 2019-07-01 14:13:49 --> Config Class Initialized
INFO - 2019-07-01 14:13:49 --> Loader Class Initialized
DEBUG - 2019-07-01 14:13:49 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 14:13:49 --> Helper loaded: url_helper
INFO - 2019-07-01 14:13:49 --> Helper loaded: inflector_helper
INFO - 2019-07-01 14:13:49 --> Helper loaded: string_helper
INFO - 2019-07-01 14:13:49 --> Helper loaded: array_helper
INFO - 2019-07-01 14:13:49 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 14:13:49 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 14:13:49 --> Database Driver Class Initialized
INFO - 2019-07-01 14:13:49 --> Controller Class Initialized
INFO - 2019-07-01 20:13:49 --> Helper loaded: language_helper
INFO - 2019-07-01 20:13:49 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 20:13:49 --> Model Class Initialized
INFO - 2019-07-01 20:13:49 --> Model Class Initialized
INFO - 2019-07-01 20:13:49 --> Model Class Initialized
INFO - 2019-07-01 20:13:49 --> Model Class Initialized
INFO - 2019-07-01 20:13:49 --> Helper loaded: form_helper
INFO - 2019-07-01 20:13:49 --> Form Validation Class Initialized
DEBUG - 2019-07-01 20:13:49 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 20:13:49 --> Model Class Initialized
INFO - 2019-07-01 20:13:49 --> Model Class Initialized
INFO - 2019-07-01 20:13:49 --> Final output sent to browser
DEBUG - 2019-07-01 20:13:49 --> Total execution time: 0.3539
INFO - 2019-07-01 14:13:50 --> Config Class Initialized
INFO - 2019-07-01 14:13:50 --> Hooks Class Initialized
DEBUG - 2019-07-01 14:13:51 --> UTF-8 Support Enabled
INFO - 2019-07-01 14:13:51 --> Utf8 Class Initialized
INFO - 2019-07-01 14:13:51 --> URI Class Initialized
INFO - 2019-07-01 14:13:51 --> Router Class Initialized
INFO - 2019-07-01 14:13:51 --> Output Class Initialized
INFO - 2019-07-01 14:13:51 --> Security Class Initialized
DEBUG - 2019-07-01 14:13:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 14:13:51 --> Input Class Initialized
INFO - 2019-07-01 14:13:51 --> Language Class Initialized
INFO - 2019-07-01 14:13:51 --> Language Class Initialized
INFO - 2019-07-01 14:13:51 --> Config Class Initialized
INFO - 2019-07-01 14:13:51 --> Loader Class Initialized
DEBUG - 2019-07-01 14:13:51 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 14:13:51 --> Helper loaded: url_helper
INFO - 2019-07-01 14:13:51 --> Helper loaded: inflector_helper
INFO - 2019-07-01 14:13:51 --> Helper loaded: string_helper
INFO - 2019-07-01 14:13:51 --> Helper loaded: array_helper
INFO - 2019-07-01 14:13:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 14:13:51 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 14:13:51 --> Database Driver Class Initialized
INFO - 2019-07-01 14:13:51 --> Controller Class Initialized
INFO - 2019-07-01 20:13:51 --> Helper loaded: language_helper
INFO - 2019-07-01 20:13:51 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 20:13:51 --> Model Class Initialized
INFO - 2019-07-01 20:13:51 --> Model Class Initialized
INFO - 2019-07-01 20:13:51 --> Model Class Initialized
INFO - 2019-07-01 20:13:51 --> Model Class Initialized
INFO - 2019-07-01 20:13:51 --> Helper loaded: form_helper
INFO - 2019-07-01 20:13:51 --> Form Validation Class Initialized
DEBUG - 2019-07-01 20:13:51 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 20:13:51 --> Model Class Initialized
INFO - 2019-07-01 20:13:51 --> Model Class Initialized
INFO - 2019-07-01 20:13:51 --> Final output sent to browser
DEBUG - 2019-07-01 20:13:51 --> Total execution time: 0.4273
INFO - 2019-07-01 14:13:52 --> Config Class Initialized
INFO - 2019-07-01 14:13:52 --> Hooks Class Initialized
DEBUG - 2019-07-01 14:13:52 --> UTF-8 Support Enabled
INFO - 2019-07-01 14:13:52 --> Utf8 Class Initialized
INFO - 2019-07-01 14:13:52 --> URI Class Initialized
INFO - 2019-07-01 14:13:52 --> Router Class Initialized
INFO - 2019-07-01 14:13:52 --> Output Class Initialized
INFO - 2019-07-01 14:13:52 --> Security Class Initialized
DEBUG - 2019-07-01 14:13:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 14:13:52 --> Input Class Initialized
INFO - 2019-07-01 14:13:52 --> Language Class Initialized
INFO - 2019-07-01 14:13:52 --> Language Class Initialized
INFO - 2019-07-01 14:13:52 --> Config Class Initialized
INFO - 2019-07-01 14:13:52 --> Loader Class Initialized
DEBUG - 2019-07-01 14:13:52 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 14:13:52 --> Helper loaded: url_helper
INFO - 2019-07-01 14:13:52 --> Helper loaded: inflector_helper
INFO - 2019-07-01 14:13:52 --> Helper loaded: string_helper
INFO - 2019-07-01 14:13:52 --> Helper loaded: array_helper
INFO - 2019-07-01 14:13:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 14:13:52 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 14:13:52 --> Database Driver Class Initialized
INFO - 2019-07-01 14:13:52 --> Controller Class Initialized
INFO - 2019-07-01 20:13:52 --> Helper loaded: language_helper
INFO - 2019-07-01 20:13:52 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 20:13:52 --> Model Class Initialized
INFO - 2019-07-01 20:13:52 --> Model Class Initialized
INFO - 2019-07-01 20:13:52 --> Model Class Initialized
INFO - 2019-07-01 20:13:52 --> Model Class Initialized
INFO - 2019-07-01 20:13:52 --> Model Class Initialized
INFO - 2019-07-01 20:13:52 --> Final output sent to browser
DEBUG - 2019-07-01 20:13:52 --> Total execution time: 0.2934
INFO - 2019-07-01 14:13:56 --> Config Class Initialized
INFO - 2019-07-01 14:13:56 --> Hooks Class Initialized
DEBUG - 2019-07-01 14:13:56 --> UTF-8 Support Enabled
INFO - 2019-07-01 14:13:56 --> Utf8 Class Initialized
INFO - 2019-07-01 14:13:56 --> URI Class Initialized
INFO - 2019-07-01 14:13:56 --> Router Class Initialized
INFO - 2019-07-01 14:13:56 --> Output Class Initialized
INFO - 2019-07-01 14:13:56 --> Security Class Initialized
DEBUG - 2019-07-01 14:13:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 14:13:57 --> Input Class Initialized
INFO - 2019-07-01 14:13:57 --> Language Class Initialized
INFO - 2019-07-01 14:13:57 --> Language Class Initialized
INFO - 2019-07-01 14:13:57 --> Config Class Initialized
INFO - 2019-07-01 14:13:57 --> Loader Class Initialized
DEBUG - 2019-07-01 14:13:57 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 14:13:57 --> Helper loaded: url_helper
INFO - 2019-07-01 14:13:57 --> Helper loaded: inflector_helper
INFO - 2019-07-01 14:13:57 --> Helper loaded: string_helper
INFO - 2019-07-01 14:13:57 --> Helper loaded: array_helper
INFO - 2019-07-01 14:13:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 14:13:57 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 14:13:57 --> Database Driver Class Initialized
INFO - 2019-07-01 14:13:57 --> Controller Class Initialized
INFO - 2019-07-01 20:13:57 --> Helper loaded: language_helper
INFO - 2019-07-01 20:13:57 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 20:13:57 --> Model Class Initialized
INFO - 2019-07-01 20:13:57 --> Model Class Initialized
INFO - 2019-07-01 20:13:57 --> Model Class Initialized
INFO - 2019-07-01 20:13:57 --> Model Class Initialized
INFO - 2019-07-01 20:13:57 --> Helper loaded: form_helper
INFO - 2019-07-01 20:13:57 --> Form Validation Class Initialized
DEBUG - 2019-07-01 20:13:57 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 20:13:57 --> Model Class Initialized
INFO - 2019-07-01 20:13:57 --> Model Class Initialized
INFO - 2019-07-01 14:14:11 --> Config Class Initialized
INFO - 2019-07-01 14:14:11 --> Hooks Class Initialized
DEBUG - 2019-07-01 14:14:11 --> UTF-8 Support Enabled
INFO - 2019-07-01 14:14:11 --> Utf8 Class Initialized
INFO - 2019-07-01 14:14:11 --> URI Class Initialized
INFO - 2019-07-01 14:14:11 --> Router Class Initialized
INFO - 2019-07-01 14:14:11 --> Output Class Initialized
INFO - 2019-07-01 14:14:11 --> Security Class Initialized
DEBUG - 2019-07-01 14:14:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 14:14:11 --> Input Class Initialized
INFO - 2019-07-01 14:14:11 --> Language Class Initialized
INFO - 2019-07-01 14:14:11 --> Language Class Initialized
INFO - 2019-07-01 14:14:11 --> Config Class Initialized
INFO - 2019-07-01 14:14:11 --> Loader Class Initialized
DEBUG - 2019-07-01 14:14:11 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 14:14:11 --> Helper loaded: url_helper
INFO - 2019-07-01 14:14:11 --> Helper loaded: inflector_helper
INFO - 2019-07-01 14:14:11 --> Helper loaded: string_helper
INFO - 2019-07-01 14:14:11 --> Helper loaded: array_helper
INFO - 2019-07-01 14:14:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 14:14:11 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 14:14:11 --> Database Driver Class Initialized
INFO - 2019-07-01 14:14:11 --> Controller Class Initialized
INFO - 2019-07-01 20:14:11 --> Helper loaded: language_helper
INFO - 2019-07-01 20:14:11 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 20:14:11 --> Model Class Initialized
INFO - 2019-07-01 20:14:11 --> Model Class Initialized
INFO - 2019-07-01 20:14:11 --> Model Class Initialized
INFO - 2019-07-01 20:14:11 --> Model Class Initialized
INFO - 2019-07-01 20:14:11 --> Helper loaded: form_helper
INFO - 2019-07-01 20:14:11 --> Form Validation Class Initialized
DEBUG - 2019-07-01 20:14:11 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 20:14:11 --> Model Class Initialized
INFO - 2019-07-01 20:14:11 --> Model Class Initialized
INFO - 2019-07-01 20:14:11 --> Final output sent to browser
DEBUG - 2019-07-01 20:14:11 --> Total execution time: 0.3498
INFO - 2019-07-01 14:14:13 --> Config Class Initialized
INFO - 2019-07-01 14:14:13 --> Hooks Class Initialized
DEBUG - 2019-07-01 14:14:13 --> UTF-8 Support Enabled
INFO - 2019-07-01 14:14:13 --> Utf8 Class Initialized
INFO - 2019-07-01 14:14:13 --> URI Class Initialized
INFO - 2019-07-01 14:14:13 --> Router Class Initialized
INFO - 2019-07-01 14:14:13 --> Output Class Initialized
INFO - 2019-07-01 14:14:13 --> Security Class Initialized
DEBUG - 2019-07-01 14:14:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 14:14:13 --> Input Class Initialized
INFO - 2019-07-01 14:14:13 --> Language Class Initialized
INFO - 2019-07-01 14:14:13 --> Language Class Initialized
INFO - 2019-07-01 14:14:13 --> Config Class Initialized
INFO - 2019-07-01 14:14:13 --> Loader Class Initialized
DEBUG - 2019-07-01 14:14:13 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 14:14:13 --> Helper loaded: url_helper
INFO - 2019-07-01 14:14:13 --> Helper loaded: inflector_helper
INFO - 2019-07-01 14:14:13 --> Helper loaded: string_helper
INFO - 2019-07-01 14:14:13 --> Helper loaded: array_helper
INFO - 2019-07-01 14:14:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 14:14:13 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 14:14:13 --> Database Driver Class Initialized
INFO - 2019-07-01 14:14:13 --> Controller Class Initialized
INFO - 2019-07-01 20:14:13 --> Helper loaded: language_helper
INFO - 2019-07-01 20:14:13 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 20:14:13 --> Model Class Initialized
INFO - 2019-07-01 20:14:13 --> Model Class Initialized
INFO - 2019-07-01 20:14:13 --> Model Class Initialized
INFO - 2019-07-01 20:14:13 --> Model Class Initialized
INFO - 2019-07-01 20:14:13 --> Model Class Initialized
INFO - 2019-07-01 20:14:13 --> Final output sent to browser
DEBUG - 2019-07-01 20:14:13 --> Total execution time: 0.2741
INFO - 2019-07-01 14:14:18 --> Config Class Initialized
INFO - 2019-07-01 14:14:18 --> Hooks Class Initialized
DEBUG - 2019-07-01 14:14:18 --> UTF-8 Support Enabled
INFO - 2019-07-01 14:14:18 --> Utf8 Class Initialized
INFO - 2019-07-01 14:14:18 --> URI Class Initialized
INFO - 2019-07-01 14:14:18 --> Router Class Initialized
INFO - 2019-07-01 14:14:18 --> Output Class Initialized
INFO - 2019-07-01 14:14:18 --> Security Class Initialized
DEBUG - 2019-07-01 14:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 14:14:18 --> Input Class Initialized
INFO - 2019-07-01 14:14:18 --> Language Class Initialized
INFO - 2019-07-01 14:14:18 --> Language Class Initialized
INFO - 2019-07-01 14:14:18 --> Config Class Initialized
INFO - 2019-07-01 14:14:18 --> Loader Class Initialized
DEBUG - 2019-07-01 14:14:18 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 14:14:18 --> Helper loaded: url_helper
INFO - 2019-07-01 14:14:18 --> Helper loaded: inflector_helper
INFO - 2019-07-01 14:14:18 --> Helper loaded: string_helper
INFO - 2019-07-01 14:14:18 --> Helper loaded: array_helper
INFO - 2019-07-01 14:14:18 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 14:14:18 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 14:14:18 --> Database Driver Class Initialized
INFO - 2019-07-01 14:14:18 --> Controller Class Initialized
INFO - 2019-07-01 20:14:18 --> Helper loaded: language_helper
INFO - 2019-07-01 20:14:18 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 20:14:18 --> Model Class Initialized
INFO - 2019-07-01 20:14:18 --> Model Class Initialized
INFO - 2019-07-01 20:14:18 --> Model Class Initialized
INFO - 2019-07-01 20:14:18 --> Model Class Initialized
INFO - 2019-07-01 20:14:18 --> Helper loaded: form_helper
INFO - 2019-07-01 20:14:18 --> Form Validation Class Initialized
DEBUG - 2019-07-01 20:14:18 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 20:14:18 --> Model Class Initialized
INFO - 2019-07-01 20:14:18 --> Model Class Initialized
ERROR - 2019-07-01 20:14:19 --> Query error: Unknown column 'order_details.status' in 'field list' - Invalid query: SELECT `orders`.*, `order_details`.`qty`, `order_details`.`price`, `order_details`.`sub_total`, `order_details`.`status`, `order_details`.`product_id`, `order_details`.`created_at` AS `order_date`, `products`.`name`, CONCAT(`customers`.`firstname`, " ", `customers`.`lastname`) AS customer_fullname, `customers`.`address`, `customers`.`contact_number`, `customers`.`email`
FROM `orders`
LEFT JOIN `order_details` ON `order_details`.`order_id` = `orders`.`id`
LEFT JOIN `products` ON `products`.`id` = `order_details`.`product_id`
INNER JOIN `customers` as `customers` ON `customers`.`id` = `orders`.`customer_id`
WHERE `resto_id` = '2'
AND `customer_id` = '1'
AND `order_status` = 'pending'
INFO - 2019-07-01 20:14:19 --> Language file loaded: language/english/db_lang.php
INFO - 2019-07-01 14:16:25 --> Config Class Initialized
INFO - 2019-07-01 14:16:25 --> Hooks Class Initialized
DEBUG - 2019-07-01 14:16:25 --> UTF-8 Support Enabled
INFO - 2019-07-01 14:16:25 --> Utf8 Class Initialized
INFO - 2019-07-01 14:16:25 --> URI Class Initialized
INFO - 2019-07-01 14:16:25 --> Router Class Initialized
INFO - 2019-07-01 14:16:25 --> Output Class Initialized
INFO - 2019-07-01 14:16:25 --> Security Class Initialized
DEBUG - 2019-07-01 14:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 14:16:25 --> Input Class Initialized
INFO - 2019-07-01 14:16:25 --> Language Class Initialized
INFO - 2019-07-01 14:16:25 --> Language Class Initialized
INFO - 2019-07-01 14:16:25 --> Config Class Initialized
INFO - 2019-07-01 14:16:25 --> Loader Class Initialized
DEBUG - 2019-07-01 14:16:25 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 14:16:25 --> Helper loaded: url_helper
INFO - 2019-07-01 14:16:25 --> Helper loaded: inflector_helper
INFO - 2019-07-01 14:16:25 --> Helper loaded: string_helper
INFO - 2019-07-01 14:16:25 --> Helper loaded: array_helper
INFO - 2019-07-01 14:16:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 14:16:25 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 14:16:25 --> Database Driver Class Initialized
INFO - 2019-07-01 14:16:25 --> Controller Class Initialized
INFO - 2019-07-01 20:16:25 --> Helper loaded: language_helper
INFO - 2019-07-01 20:16:25 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 20:16:25 --> Model Class Initialized
INFO - 2019-07-01 20:16:25 --> Model Class Initialized
INFO - 2019-07-01 20:16:25 --> Model Class Initialized
INFO - 2019-07-01 20:16:25 --> Model Class Initialized
INFO - 2019-07-01 20:16:25 --> Helper loaded: form_helper
INFO - 2019-07-01 20:16:25 --> Form Validation Class Initialized
DEBUG - 2019-07-01 20:16:25 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 20:16:25 --> Model Class Initialized
INFO - 2019-07-01 20:16:25 --> Model Class Initialized
INFO - 2019-07-01 20:16:25 --> Final output sent to browser
DEBUG - 2019-07-01 20:16:25 --> Total execution time: 0.3663
INFO - 2019-07-01 14:16:27 --> Config Class Initialized
INFO - 2019-07-01 14:16:27 --> Hooks Class Initialized
DEBUG - 2019-07-01 14:16:27 --> UTF-8 Support Enabled
INFO - 2019-07-01 14:16:27 --> Utf8 Class Initialized
INFO - 2019-07-01 14:16:27 --> URI Class Initialized
INFO - 2019-07-01 14:16:27 --> Router Class Initialized
INFO - 2019-07-01 14:16:27 --> Output Class Initialized
INFO - 2019-07-01 14:16:27 --> Security Class Initialized
DEBUG - 2019-07-01 14:16:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 14:16:27 --> Input Class Initialized
INFO - 2019-07-01 14:16:27 --> Language Class Initialized
INFO - 2019-07-01 14:16:27 --> Language Class Initialized
INFO - 2019-07-01 14:16:27 --> Config Class Initialized
INFO - 2019-07-01 14:16:27 --> Loader Class Initialized
DEBUG - 2019-07-01 14:16:27 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 14:16:27 --> Helper loaded: url_helper
INFO - 2019-07-01 14:16:27 --> Helper loaded: inflector_helper
INFO - 2019-07-01 14:16:27 --> Helper loaded: string_helper
INFO - 2019-07-01 14:16:27 --> Helper loaded: array_helper
INFO - 2019-07-01 14:16:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 14:16:27 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 14:16:27 --> Database Driver Class Initialized
INFO - 2019-07-01 14:16:27 --> Controller Class Initialized
INFO - 2019-07-01 20:16:27 --> Helper loaded: language_helper
INFO - 2019-07-01 20:16:27 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 20:16:27 --> Model Class Initialized
INFO - 2019-07-01 20:16:27 --> Model Class Initialized
INFO - 2019-07-01 20:16:27 --> Model Class Initialized
INFO - 2019-07-01 20:16:27 --> Model Class Initialized
INFO - 2019-07-01 20:16:27 --> Model Class Initialized
INFO - 2019-07-01 20:16:27 --> Final output sent to browser
DEBUG - 2019-07-01 20:16:27 --> Total execution time: 0.2683
INFO - 2019-07-01 14:16:32 --> Config Class Initialized
INFO - 2019-07-01 14:16:32 --> Hooks Class Initialized
DEBUG - 2019-07-01 14:16:32 --> UTF-8 Support Enabled
INFO - 2019-07-01 14:16:32 --> Utf8 Class Initialized
INFO - 2019-07-01 14:16:32 --> URI Class Initialized
INFO - 2019-07-01 14:16:32 --> Router Class Initialized
INFO - 2019-07-01 14:16:32 --> Output Class Initialized
INFO - 2019-07-01 14:16:32 --> Security Class Initialized
DEBUG - 2019-07-01 14:16:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 14:16:32 --> Input Class Initialized
INFO - 2019-07-01 14:16:32 --> Language Class Initialized
INFO - 2019-07-01 14:16:32 --> Language Class Initialized
INFO - 2019-07-01 14:16:32 --> Config Class Initialized
INFO - 2019-07-01 14:16:32 --> Loader Class Initialized
DEBUG - 2019-07-01 14:16:32 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 14:16:32 --> Helper loaded: url_helper
INFO - 2019-07-01 14:16:32 --> Helper loaded: inflector_helper
INFO - 2019-07-01 14:16:32 --> Helper loaded: string_helper
INFO - 2019-07-01 14:16:32 --> Helper loaded: array_helper
INFO - 2019-07-01 14:16:32 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 14:16:32 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 14:16:32 --> Database Driver Class Initialized
INFO - 2019-07-01 14:16:32 --> Controller Class Initialized
INFO - 2019-07-01 20:16:32 --> Helper loaded: language_helper
INFO - 2019-07-01 20:16:32 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 20:16:32 --> Model Class Initialized
INFO - 2019-07-01 20:16:32 --> Model Class Initialized
INFO - 2019-07-01 20:16:32 --> Model Class Initialized
INFO - 2019-07-01 20:16:32 --> Model Class Initialized
INFO - 2019-07-01 20:16:32 --> Helper loaded: form_helper
INFO - 2019-07-01 20:16:32 --> Form Validation Class Initialized
DEBUG - 2019-07-01 20:16:32 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 20:16:32 --> Model Class Initialized
INFO - 2019-07-01 20:16:32 --> Model Class Initialized
ERROR - 2019-07-01 20:16:32 --> Query error: Unknown column 'order_status' in 'where clause' - Invalid query: SELECT `orders`.*, `order_details`.`qty`, `order_details`.`price`, `order_details`.`sub_total`, `order_details`.`status`, `order_details`.`product_id`, `order_details`.`created_at` AS `order_date`, `products`.`name`, CONCAT(`customers`.`firstname`, " ", `customers`.`lastname`) AS customer_fullname, `customers`.`address`, `customers`.`contact_number`, `customers`.`email`
FROM `orders`
LEFT JOIN `order_details` ON `order_details`.`order_id` = `orders`.`id`
LEFT JOIN `products` ON `products`.`id` = `order_details`.`product_id`
INNER JOIN `customers` as `customers` ON `customers`.`id` = `orders`.`customer_id`
WHERE `resto_id` = '2'
AND `customer_id` = '1'
AND `order_status` = 'pending'
INFO - 2019-07-01 20:16:32 --> Language file loaded: language/english/db_lang.php
INFO - 2019-07-01 14:17:35 --> Config Class Initialized
INFO - 2019-07-01 14:17:35 --> Hooks Class Initialized
DEBUG - 2019-07-01 14:17:35 --> UTF-8 Support Enabled
INFO - 2019-07-01 14:17:35 --> Utf8 Class Initialized
INFO - 2019-07-01 14:17:35 --> URI Class Initialized
INFO - 2019-07-01 14:17:35 --> Router Class Initialized
INFO - 2019-07-01 14:17:35 --> Output Class Initialized
INFO - 2019-07-01 14:17:35 --> Security Class Initialized
DEBUG - 2019-07-01 14:17:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 14:17:36 --> Input Class Initialized
INFO - 2019-07-01 14:17:36 --> Language Class Initialized
INFO - 2019-07-01 14:17:36 --> Language Class Initialized
INFO - 2019-07-01 14:17:36 --> Config Class Initialized
INFO - 2019-07-01 14:17:36 --> Loader Class Initialized
DEBUG - 2019-07-01 14:17:36 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 14:17:36 --> Helper loaded: url_helper
INFO - 2019-07-01 14:17:36 --> Helper loaded: inflector_helper
INFO - 2019-07-01 14:17:36 --> Helper loaded: string_helper
INFO - 2019-07-01 14:17:36 --> Helper loaded: array_helper
INFO - 2019-07-01 14:17:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 14:17:36 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 14:17:36 --> Database Driver Class Initialized
INFO - 2019-07-01 14:17:36 --> Controller Class Initialized
INFO - 2019-07-01 20:17:36 --> Helper loaded: language_helper
INFO - 2019-07-01 20:17:36 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 20:17:36 --> Model Class Initialized
INFO - 2019-07-01 20:17:36 --> Model Class Initialized
INFO - 2019-07-01 20:17:36 --> Model Class Initialized
INFO - 2019-07-01 20:17:36 --> Model Class Initialized
INFO - 2019-07-01 20:17:36 --> Helper loaded: form_helper
INFO - 2019-07-01 20:17:36 --> Form Validation Class Initialized
DEBUG - 2019-07-01 20:17:36 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 20:17:36 --> Model Class Initialized
INFO - 2019-07-01 20:17:36 --> Model Class Initialized
ERROR - 2019-07-01 20:17:36 --> Query error: Unknown column 'order_details.status' in 'field list' - Invalid query: SELECT `orders`.*, `order_details`.`qty`, `order_details`.`price`, `order_details`.`sub_total`, `order_details`.`status`, `order_details`.`product_id`, `order_details`.`created_at` AS `order_date`, `products`.`name`, CONCAT(`customers`.`firstname`, " ", `customers`.`lastname`) AS customer_fullname, `customers`.`address`, `customers`.`contact_number`, `customers`.`email`
FROM `orders`
LEFT JOIN `order_details` ON `order_details`.`order_id` = `orders`.`id`
LEFT JOIN `products` ON `products`.`id` = `order_details`.`product_id`
INNER JOIN `customers` as `customers` ON `customers`.`id` = `orders`.`customer_id`
WHERE `resto_id` = '2'
AND `customer_id` = '1'
AND `order_status` = 'pending'
INFO - 2019-07-01 20:17:36 --> Language file loaded: language/english/db_lang.php
INFO - 2019-07-01 14:17:56 --> Config Class Initialized
INFO - 2019-07-01 14:17:56 --> Hooks Class Initialized
DEBUG - 2019-07-01 14:17:56 --> UTF-8 Support Enabled
INFO - 2019-07-01 14:17:56 --> Utf8 Class Initialized
INFO - 2019-07-01 14:17:56 --> URI Class Initialized
INFO - 2019-07-01 14:17:56 --> Router Class Initialized
INFO - 2019-07-01 14:17:56 --> Output Class Initialized
INFO - 2019-07-01 14:17:56 --> Security Class Initialized
DEBUG - 2019-07-01 14:17:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 14:17:56 --> Input Class Initialized
INFO - 2019-07-01 14:17:56 --> Language Class Initialized
INFO - 2019-07-01 14:17:56 --> Language Class Initialized
INFO - 2019-07-01 14:17:56 --> Config Class Initialized
INFO - 2019-07-01 14:17:56 --> Loader Class Initialized
DEBUG - 2019-07-01 14:17:56 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 14:17:56 --> Helper loaded: url_helper
INFO - 2019-07-01 14:17:56 --> Helper loaded: inflector_helper
INFO - 2019-07-01 14:17:56 --> Helper loaded: string_helper
INFO - 2019-07-01 14:17:56 --> Helper loaded: array_helper
INFO - 2019-07-01 14:17:56 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 14:17:56 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 14:17:56 --> Database Driver Class Initialized
INFO - 2019-07-01 14:17:56 --> Controller Class Initialized
INFO - 2019-07-01 20:17:56 --> Helper loaded: language_helper
INFO - 2019-07-01 20:17:56 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 20:17:56 --> Model Class Initialized
INFO - 2019-07-01 20:17:56 --> Model Class Initialized
INFO - 2019-07-01 20:17:56 --> Model Class Initialized
INFO - 2019-07-01 20:17:56 --> Model Class Initialized
INFO - 2019-07-01 20:17:56 --> Helper loaded: form_helper
INFO - 2019-07-01 20:17:56 --> Form Validation Class Initialized
DEBUG - 2019-07-01 20:17:56 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 20:17:56 --> Model Class Initialized
INFO - 2019-07-01 20:17:56 --> Model Class Initialized
INFO - 2019-07-01 20:17:56 --> Final output sent to browser
DEBUG - 2019-07-01 20:17:56 --> Total execution time: 0.3535
INFO - 2019-07-01 14:19:00 --> Config Class Initialized
INFO - 2019-07-01 14:19:00 --> Hooks Class Initialized
DEBUG - 2019-07-01 14:19:00 --> UTF-8 Support Enabled
INFO - 2019-07-01 14:19:00 --> Utf8 Class Initialized
INFO - 2019-07-01 14:19:00 --> URI Class Initialized
INFO - 2019-07-01 14:19:00 --> Router Class Initialized
INFO - 2019-07-01 14:19:00 --> Output Class Initialized
INFO - 2019-07-01 14:19:00 --> Security Class Initialized
DEBUG - 2019-07-01 14:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 14:19:00 --> Input Class Initialized
INFO - 2019-07-01 14:19:00 --> Language Class Initialized
INFO - 2019-07-01 14:19:00 --> Language Class Initialized
INFO - 2019-07-01 14:19:00 --> Config Class Initialized
INFO - 2019-07-01 14:19:00 --> Loader Class Initialized
DEBUG - 2019-07-01 14:19:00 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 14:19:00 --> Helper loaded: url_helper
INFO - 2019-07-01 14:19:00 --> Helper loaded: inflector_helper
INFO - 2019-07-01 14:19:00 --> Helper loaded: string_helper
INFO - 2019-07-01 14:19:00 --> Helper loaded: array_helper
INFO - 2019-07-01 14:19:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 14:19:00 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 14:19:00 --> Database Driver Class Initialized
INFO - 2019-07-01 14:19:00 --> Controller Class Initialized
INFO - 2019-07-01 20:19:00 --> Helper loaded: language_helper
INFO - 2019-07-01 20:19:00 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 20:19:00 --> Model Class Initialized
INFO - 2019-07-01 20:19:00 --> Model Class Initialized
INFO - 2019-07-01 20:19:00 --> Model Class Initialized
INFO - 2019-07-01 20:19:00 --> Model Class Initialized
INFO - 2019-07-01 20:19:01 --> Model Class Initialized
INFO - 2019-07-01 20:19:01 --> Final output sent to browser
DEBUG - 2019-07-01 20:19:01 --> Total execution time: 0.3047
INFO - 2019-07-01 14:19:07 --> Config Class Initialized
INFO - 2019-07-01 14:19:07 --> Hooks Class Initialized
DEBUG - 2019-07-01 14:19:07 --> UTF-8 Support Enabled
INFO - 2019-07-01 14:19:07 --> Utf8 Class Initialized
INFO - 2019-07-01 14:19:07 --> URI Class Initialized
INFO - 2019-07-01 14:19:07 --> Router Class Initialized
INFO - 2019-07-01 14:19:07 --> Output Class Initialized
INFO - 2019-07-01 14:19:07 --> Security Class Initialized
DEBUG - 2019-07-01 14:19:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 14:19:07 --> Input Class Initialized
INFO - 2019-07-01 14:19:07 --> Language Class Initialized
INFO - 2019-07-01 14:19:07 --> Language Class Initialized
INFO - 2019-07-01 14:19:07 --> Config Class Initialized
INFO - 2019-07-01 14:19:07 --> Loader Class Initialized
DEBUG - 2019-07-01 14:19:07 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 14:19:07 --> Helper loaded: url_helper
INFO - 2019-07-01 14:19:07 --> Helper loaded: inflector_helper
INFO - 2019-07-01 14:19:07 --> Helper loaded: string_helper
INFO - 2019-07-01 14:19:07 --> Helper loaded: array_helper
INFO - 2019-07-01 14:19:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 14:19:07 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 14:19:07 --> Database Driver Class Initialized
INFO - 2019-07-01 14:19:07 --> Controller Class Initialized
INFO - 2019-07-01 20:19:07 --> Helper loaded: language_helper
INFO - 2019-07-01 20:19:07 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 20:19:07 --> Model Class Initialized
INFO - 2019-07-01 20:19:07 --> Model Class Initialized
INFO - 2019-07-01 20:19:07 --> Model Class Initialized
INFO - 2019-07-01 20:19:07 --> Model Class Initialized
INFO - 2019-07-01 20:19:07 --> Helper loaded: form_helper
INFO - 2019-07-01 20:19:07 --> Form Validation Class Initialized
DEBUG - 2019-07-01 20:19:07 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 20:19:08 --> Model Class Initialized
INFO - 2019-07-01 20:19:08 --> Model Class Initialized
ERROR - 2019-07-01 20:19:08 --> Query error: Unknown column 'resto_id' in 'field list' - Invalid query: INSERT INTO `orders` (`customer_id`, `resto_id`, `order_number`, `created_at`, `updated_at`) VALUES ('1', '2', '11561983548', '2019-07-01 20:19:08', '2019-07-01 20:19:08')
INFO - 2019-07-01 20:19:08 --> Language file loaded: language/english/db_lang.php
INFO - 2019-07-01 14:19:41 --> Config Class Initialized
INFO - 2019-07-01 14:19:41 --> Hooks Class Initialized
DEBUG - 2019-07-01 14:19:41 --> UTF-8 Support Enabled
INFO - 2019-07-01 14:19:41 --> Utf8 Class Initialized
INFO - 2019-07-01 14:19:41 --> URI Class Initialized
INFO - 2019-07-01 14:19:41 --> Router Class Initialized
INFO - 2019-07-01 14:19:41 --> Output Class Initialized
INFO - 2019-07-01 14:19:41 --> Security Class Initialized
DEBUG - 2019-07-01 14:19:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 14:19:41 --> Input Class Initialized
INFO - 2019-07-01 14:19:41 --> Language Class Initialized
INFO - 2019-07-01 14:19:41 --> Language Class Initialized
INFO - 2019-07-01 14:19:41 --> Config Class Initialized
INFO - 2019-07-01 14:19:41 --> Loader Class Initialized
DEBUG - 2019-07-01 14:19:41 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 14:19:41 --> Helper loaded: url_helper
INFO - 2019-07-01 14:19:41 --> Helper loaded: inflector_helper
INFO - 2019-07-01 14:19:41 --> Helper loaded: string_helper
INFO - 2019-07-01 14:19:41 --> Helper loaded: array_helper
INFO - 2019-07-01 14:19:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 14:19:41 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 14:19:41 --> Database Driver Class Initialized
INFO - 2019-07-01 14:19:41 --> Controller Class Initialized
INFO - 2019-07-01 20:19:41 --> Helper loaded: language_helper
INFO - 2019-07-01 20:19:41 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 20:19:41 --> Model Class Initialized
INFO - 2019-07-01 20:19:41 --> Model Class Initialized
INFO - 2019-07-01 20:19:41 --> Model Class Initialized
INFO - 2019-07-01 20:19:41 --> Model Class Initialized
INFO - 2019-07-01 20:19:41 --> Helper loaded: form_helper
INFO - 2019-07-01 20:19:41 --> Form Validation Class Initialized
DEBUG - 2019-07-01 20:19:41 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 20:19:41 --> Model Class Initialized
INFO - 2019-07-01 20:19:41 --> Model Class Initialized
ERROR - 2019-07-01 20:19:41 --> Query error: Column 'resto_id' in where clause is ambiguous - Invalid query: SELECT `orders`.*, `order_details`.`qty`, `order_details`.`price`, `order_details`.`sub_total`, `order_details`.`order_status`, `order_details`.`product_id`, `order_details`.`created_at` AS `order_date`, `products`.`name`, CONCAT(`customers`.`firstname`, " ", `customers`.`lastname`) AS customer_fullname, `customers`.`address`, `customers`.`contact_number`, `customers`.`email`
FROM `orders`
LEFT JOIN `order_details` ON `order_details`.`order_id` = `orders`.`id`
LEFT JOIN `products` ON `products`.`id` = `order_details`.`product_id`
INNER JOIN `customers` as `customers` ON `customers`.`id` = `orders`.`customer_id`
WHERE `resto_id` = '2'
AND `customer_id` = '1'
AND `order_status` = 'pending'
INFO - 2019-07-01 20:19:41 --> Language file loaded: language/english/db_lang.php
INFO - 2019-07-01 14:23:57 --> Config Class Initialized
INFO - 2019-07-01 14:23:57 --> Hooks Class Initialized
DEBUG - 2019-07-01 14:23:57 --> UTF-8 Support Enabled
INFO - 2019-07-01 14:23:57 --> Utf8 Class Initialized
INFO - 2019-07-01 14:23:57 --> URI Class Initialized
INFO - 2019-07-01 14:23:57 --> Router Class Initialized
INFO - 2019-07-01 14:23:57 --> Output Class Initialized
INFO - 2019-07-01 14:23:57 --> Security Class Initialized
DEBUG - 2019-07-01 14:23:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 14:23:57 --> Input Class Initialized
INFO - 2019-07-01 14:23:57 --> Language Class Initialized
INFO - 2019-07-01 14:23:57 --> Language Class Initialized
INFO - 2019-07-01 14:23:57 --> Config Class Initialized
INFO - 2019-07-01 14:23:57 --> Loader Class Initialized
DEBUG - 2019-07-01 14:23:57 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 14:23:57 --> Helper loaded: url_helper
INFO - 2019-07-01 14:23:57 --> Helper loaded: inflector_helper
INFO - 2019-07-01 14:23:57 --> Helper loaded: string_helper
INFO - 2019-07-01 14:23:57 --> Helper loaded: array_helper
INFO - 2019-07-01 14:23:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 14:23:57 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 14:23:57 --> Database Driver Class Initialized
INFO - 2019-07-01 14:23:57 --> Controller Class Initialized
INFO - 2019-07-01 20:23:57 --> Helper loaded: language_helper
INFO - 2019-07-01 20:23:57 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 20:23:57 --> Model Class Initialized
INFO - 2019-07-01 20:23:57 --> Model Class Initialized
INFO - 2019-07-01 20:23:57 --> Model Class Initialized
INFO - 2019-07-01 20:23:57 --> Model Class Initialized
INFO - 2019-07-01 20:23:57 --> Helper loaded: form_helper
INFO - 2019-07-01 20:23:57 --> Form Validation Class Initialized
DEBUG - 2019-07-01 20:23:57 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 20:23:57 --> Model Class Initialized
INFO - 2019-07-01 20:23:57 --> Model Class Initialized
ERROR - 2019-07-01 20:23:57 --> Query error: Column 'resto_id' in where clause is ambiguous - Invalid query: SELECT `orders`.*, `order_details`.`qty`, `order_details`.`price`, `order_details`.`sub_total`, `order_details`.`order_status`, `order_details`.`product_id`, `order_details`.`created_at` AS `order_date`, `products`.`name`, CONCAT(`customers`.`firstname`, " ", `customers`.`lastname`) AS customer_fullname, `customers`.`address`, `customers`.`contact_number`, `customers`.`email`
FROM `orders`
LEFT JOIN `order_details` ON `order_details`.`order_id` = `orders`.`id`
LEFT JOIN `products` ON `products`.`id` = `order_details`.`product_id`
INNER JOIN `customers` as `customers` ON `customers`.`id` = `orders`.`customer_id`
WHERE `resto_id` = '2'
AND `customer_id` = '1'
AND `order_status` = 'pending'
INFO - 2019-07-01 20:23:57 --> Language file loaded: language/english/db_lang.php
INFO - 2019-07-01 14:26:26 --> Config Class Initialized
INFO - 2019-07-01 14:26:26 --> Hooks Class Initialized
DEBUG - 2019-07-01 14:26:26 --> UTF-8 Support Enabled
INFO - 2019-07-01 14:26:26 --> Utf8 Class Initialized
INFO - 2019-07-01 14:26:26 --> URI Class Initialized
INFO - 2019-07-01 14:26:26 --> Router Class Initialized
INFO - 2019-07-01 14:26:26 --> Output Class Initialized
INFO - 2019-07-01 14:26:26 --> Security Class Initialized
DEBUG - 2019-07-01 14:26:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 14:26:26 --> Input Class Initialized
INFO - 2019-07-01 14:26:26 --> Language Class Initialized
INFO - 2019-07-01 14:26:26 --> Language Class Initialized
INFO - 2019-07-01 14:26:26 --> Config Class Initialized
INFO - 2019-07-01 14:26:26 --> Loader Class Initialized
DEBUG - 2019-07-01 14:26:26 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 14:26:26 --> Helper loaded: url_helper
INFO - 2019-07-01 14:26:26 --> Helper loaded: inflector_helper
INFO - 2019-07-01 14:26:26 --> Helper loaded: string_helper
INFO - 2019-07-01 14:26:26 --> Helper loaded: array_helper
INFO - 2019-07-01 14:26:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 14:26:26 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 14:26:26 --> Database Driver Class Initialized
INFO - 2019-07-01 14:26:26 --> Controller Class Initialized
INFO - 2019-07-01 20:26:26 --> Helper loaded: language_helper
INFO - 2019-07-01 20:26:27 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 20:26:27 --> Model Class Initialized
INFO - 2019-07-01 20:26:27 --> Model Class Initialized
INFO - 2019-07-01 20:26:27 --> Model Class Initialized
INFO - 2019-07-01 20:26:27 --> Model Class Initialized
INFO - 2019-07-01 20:26:27 --> Helper loaded: form_helper
INFO - 2019-07-01 20:26:27 --> Form Validation Class Initialized
DEBUG - 2019-07-01 20:26:27 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 20:26:27 --> Model Class Initialized
INFO - 2019-07-01 20:26:27 --> Model Class Initialized
INFO - 2019-07-01 20:26:27 --> Final output sent to browser
DEBUG - 2019-07-01 20:26:27 --> Total execution time: 0.4316
INFO - 2019-07-01 14:26:28 --> Config Class Initialized
INFO - 2019-07-01 14:26:28 --> Hooks Class Initialized
DEBUG - 2019-07-01 14:26:28 --> UTF-8 Support Enabled
INFO - 2019-07-01 14:26:28 --> Utf8 Class Initialized
INFO - 2019-07-01 14:26:28 --> URI Class Initialized
INFO - 2019-07-01 14:26:28 --> Router Class Initialized
INFO - 2019-07-01 14:26:28 --> Output Class Initialized
INFO - 2019-07-01 14:26:28 --> Security Class Initialized
DEBUG - 2019-07-01 14:26:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 14:26:28 --> Input Class Initialized
INFO - 2019-07-01 14:26:28 --> Language Class Initialized
INFO - 2019-07-01 14:26:28 --> Language Class Initialized
INFO - 2019-07-01 14:26:28 --> Config Class Initialized
INFO - 2019-07-01 14:26:28 --> Loader Class Initialized
DEBUG - 2019-07-01 14:26:28 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 14:26:28 --> Helper loaded: url_helper
INFO - 2019-07-01 14:26:28 --> Helper loaded: inflector_helper
INFO - 2019-07-01 14:26:28 --> Helper loaded: string_helper
INFO - 2019-07-01 14:26:28 --> Helper loaded: array_helper
INFO - 2019-07-01 14:26:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 14:26:28 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 14:26:28 --> Database Driver Class Initialized
INFO - 2019-07-01 14:26:28 --> Controller Class Initialized
INFO - 2019-07-01 20:26:28 --> Helper loaded: language_helper
INFO - 2019-07-01 20:26:28 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 20:26:28 --> Model Class Initialized
INFO - 2019-07-01 20:26:28 --> Model Class Initialized
INFO - 2019-07-01 20:26:28 --> Model Class Initialized
INFO - 2019-07-01 20:26:28 --> Model Class Initialized
INFO - 2019-07-01 20:26:28 --> Model Class Initialized
INFO - 2019-07-01 20:26:28 --> Final output sent to browser
DEBUG - 2019-07-01 20:26:28 --> Total execution time: 0.2794
INFO - 2019-07-01 14:26:33 --> Config Class Initialized
INFO - 2019-07-01 14:26:33 --> Hooks Class Initialized
DEBUG - 2019-07-01 14:26:33 --> UTF-8 Support Enabled
INFO - 2019-07-01 14:26:33 --> Utf8 Class Initialized
INFO - 2019-07-01 14:26:33 --> URI Class Initialized
INFO - 2019-07-01 14:26:33 --> Router Class Initialized
INFO - 2019-07-01 14:26:33 --> Output Class Initialized
INFO - 2019-07-01 14:26:33 --> Security Class Initialized
DEBUG - 2019-07-01 14:26:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 14:26:33 --> Input Class Initialized
INFO - 2019-07-01 14:26:33 --> Language Class Initialized
INFO - 2019-07-01 14:26:33 --> Language Class Initialized
INFO - 2019-07-01 14:26:33 --> Config Class Initialized
INFO - 2019-07-01 14:26:33 --> Loader Class Initialized
DEBUG - 2019-07-01 14:26:33 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 14:26:33 --> Helper loaded: url_helper
INFO - 2019-07-01 14:26:33 --> Helper loaded: inflector_helper
INFO - 2019-07-01 14:26:33 --> Helper loaded: string_helper
INFO - 2019-07-01 14:26:33 --> Helper loaded: array_helper
INFO - 2019-07-01 14:26:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 14:26:33 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 14:26:33 --> Database Driver Class Initialized
INFO - 2019-07-01 14:26:33 --> Controller Class Initialized
INFO - 2019-07-01 20:26:33 --> Helper loaded: language_helper
INFO - 2019-07-01 20:26:33 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 20:26:33 --> Model Class Initialized
INFO - 2019-07-01 20:26:33 --> Model Class Initialized
INFO - 2019-07-01 20:26:33 --> Model Class Initialized
INFO - 2019-07-01 20:26:33 --> Model Class Initialized
INFO - 2019-07-01 20:26:33 --> Helper loaded: form_helper
INFO - 2019-07-01 20:26:33 --> Form Validation Class Initialized
DEBUG - 2019-07-01 20:26:33 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 20:26:33 --> Model Class Initialized
INFO - 2019-07-01 20:26:33 --> Model Class Initialized
ERROR - 2019-07-01 20:26:33 --> Query error: Column 'resto_id' in where clause is ambiguous - Invalid query: SELECT `orders`.*, `order_details`.`qty`, `order_details`.`price`, `order_details`.`sub_total`, `order_details`.`order_status`, `order_details`.`product_id`, `order_details`.`created_at` AS `order_date`, `products`.`name`, CONCAT(`customers`.`firstname`, " ", `customers`.`lastname`) AS customer_fullname, `customers`.`address`, `customers`.`contact_number`, `customers`.`email`
FROM `orders`
LEFT JOIN `order_details` ON `order_details`.`order_id` = `orders`.`id`
LEFT JOIN `products` ON `products`.`id` = `order_details`.`product_id`
INNER JOIN `customers` as `customers` ON `customers`.`id` = `orders`.`customer_id`
WHERE `resto_id` = '2'
AND `customer_id` = '1'
AND `order_status` = 'pending'
INFO - 2019-07-01 20:26:33 --> Language file loaded: language/english/db_lang.php
INFO - 2019-07-01 14:27:01 --> Config Class Initialized
INFO - 2019-07-01 14:27:01 --> Hooks Class Initialized
DEBUG - 2019-07-01 14:27:01 --> UTF-8 Support Enabled
INFO - 2019-07-01 14:27:01 --> Utf8 Class Initialized
INFO - 2019-07-01 14:27:01 --> URI Class Initialized
INFO - 2019-07-01 14:27:01 --> Router Class Initialized
INFO - 2019-07-01 14:27:01 --> Output Class Initialized
INFO - 2019-07-01 14:27:01 --> Security Class Initialized
DEBUG - 2019-07-01 14:27:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 14:27:01 --> Input Class Initialized
INFO - 2019-07-01 14:27:01 --> Language Class Initialized
INFO - 2019-07-01 14:27:01 --> Language Class Initialized
INFO - 2019-07-01 14:27:01 --> Config Class Initialized
INFO - 2019-07-01 14:27:01 --> Loader Class Initialized
DEBUG - 2019-07-01 14:27:01 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 14:27:01 --> Helper loaded: url_helper
INFO - 2019-07-01 14:27:01 --> Helper loaded: inflector_helper
INFO - 2019-07-01 14:27:01 --> Helper loaded: string_helper
INFO - 2019-07-01 14:27:01 --> Helper loaded: array_helper
INFO - 2019-07-01 14:27:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 14:27:01 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 14:27:01 --> Database Driver Class Initialized
INFO - 2019-07-01 14:27:01 --> Controller Class Initialized
INFO - 2019-07-01 20:27:01 --> Helper loaded: language_helper
INFO - 2019-07-01 20:27:01 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 20:27:01 --> Model Class Initialized
INFO - 2019-07-01 20:27:01 --> Model Class Initialized
INFO - 2019-07-01 20:27:01 --> Model Class Initialized
INFO - 2019-07-01 20:27:01 --> Model Class Initialized
INFO - 2019-07-01 20:27:01 --> Helper loaded: form_helper
INFO - 2019-07-01 20:27:01 --> Form Validation Class Initialized
DEBUG - 2019-07-01 20:27:01 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 20:27:01 --> Model Class Initialized
INFO - 2019-07-01 20:27:01 --> Model Class Initialized
ERROR - 2019-07-01 20:27:01 --> Query error: Column 'resto_id' in where clause is ambiguous - Invalid query: SELECT `orders`.*, `order_details`.`qty`, `order_details`.`price`, `order_details`.`sub_total`, `order_details`.`order_status`, `order_details`.`product_id`, `order_details`.`created_at` AS `order_date`, `products`.`name`, CONCAT(`customers`.`firstname`, " ", `customers`.`lastname`) AS customer_fullname, `customers`.`address`, `customers`.`contact_number`, `customers`.`email`
FROM `orders`
LEFT JOIN `order_details` ON `order_details`.`order_id` = `orders`.`id`
LEFT JOIN `products` ON `products`.`id` = `order_details`.`product_id`
INNER JOIN `customers` as `customers` ON `customers`.`id` = `orders`.`customer_id`
WHERE `resto_id` = '2'
AND `customer_id` = '1'
AND `order_status` = 'pending'
INFO - 2019-07-01 20:27:01 --> Language file loaded: language/english/db_lang.php
INFO - 2019-07-01 14:30:03 --> Config Class Initialized
INFO - 2019-07-01 14:30:03 --> Hooks Class Initialized
DEBUG - 2019-07-01 14:30:03 --> UTF-8 Support Enabled
INFO - 2019-07-01 14:30:03 --> Utf8 Class Initialized
INFO - 2019-07-01 14:30:03 --> URI Class Initialized
INFO - 2019-07-01 14:30:03 --> Router Class Initialized
INFO - 2019-07-01 14:30:03 --> Output Class Initialized
INFO - 2019-07-01 14:30:03 --> Security Class Initialized
DEBUG - 2019-07-01 14:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 14:30:03 --> Input Class Initialized
INFO - 2019-07-01 14:30:03 --> Language Class Initialized
INFO - 2019-07-01 14:30:03 --> Language Class Initialized
INFO - 2019-07-01 14:30:03 --> Config Class Initialized
INFO - 2019-07-01 14:30:03 --> Loader Class Initialized
DEBUG - 2019-07-01 14:30:03 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 14:30:03 --> Helper loaded: url_helper
INFO - 2019-07-01 14:30:03 --> Helper loaded: inflector_helper
INFO - 2019-07-01 14:30:03 --> Helper loaded: string_helper
INFO - 2019-07-01 14:30:03 --> Helper loaded: array_helper
INFO - 2019-07-01 14:30:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 14:30:03 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 14:30:03 --> Database Driver Class Initialized
INFO - 2019-07-01 14:30:03 --> Controller Class Initialized
INFO - 2019-07-01 20:30:03 --> Helper loaded: language_helper
INFO - 2019-07-01 20:30:03 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 20:30:03 --> Model Class Initialized
INFO - 2019-07-01 20:30:03 --> Model Class Initialized
INFO - 2019-07-01 20:30:03 --> Model Class Initialized
INFO - 2019-07-01 20:30:03 --> Model Class Initialized
INFO - 2019-07-01 20:30:03 --> Helper loaded: form_helper
INFO - 2019-07-01 20:30:03 --> Form Validation Class Initialized
DEBUG - 2019-07-01 20:30:03 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 20:30:03 --> Model Class Initialized
INFO - 2019-07-01 20:30:03 --> Model Class Initialized
INFO - 2019-07-01 20:30:03 --> Final output sent to browser
DEBUG - 2019-07-01 20:30:03 --> Total execution time: 0.3631
INFO - 2019-07-01 14:30:05 --> Config Class Initialized
INFO - 2019-07-01 14:30:05 --> Hooks Class Initialized
DEBUG - 2019-07-01 14:30:05 --> UTF-8 Support Enabled
INFO - 2019-07-01 14:30:05 --> Utf8 Class Initialized
INFO - 2019-07-01 14:30:05 --> URI Class Initialized
INFO - 2019-07-01 14:30:05 --> Router Class Initialized
INFO - 2019-07-01 14:30:05 --> Output Class Initialized
INFO - 2019-07-01 14:30:05 --> Security Class Initialized
DEBUG - 2019-07-01 14:30:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 14:30:05 --> Input Class Initialized
INFO - 2019-07-01 14:30:05 --> Language Class Initialized
INFO - 2019-07-01 14:30:05 --> Language Class Initialized
INFO - 2019-07-01 14:30:05 --> Config Class Initialized
INFO - 2019-07-01 14:30:05 --> Loader Class Initialized
DEBUG - 2019-07-01 14:30:05 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 14:30:05 --> Helper loaded: url_helper
INFO - 2019-07-01 14:30:05 --> Helper loaded: inflector_helper
INFO - 2019-07-01 14:30:05 --> Helper loaded: string_helper
INFO - 2019-07-01 14:30:05 --> Helper loaded: array_helper
INFO - 2019-07-01 14:30:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 14:30:05 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 14:30:05 --> Database Driver Class Initialized
INFO - 2019-07-01 14:30:05 --> Controller Class Initialized
INFO - 2019-07-01 20:30:05 --> Helper loaded: language_helper
INFO - 2019-07-01 20:30:05 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 20:30:05 --> Model Class Initialized
INFO - 2019-07-01 20:30:05 --> Model Class Initialized
INFO - 2019-07-01 20:30:05 --> Model Class Initialized
INFO - 2019-07-01 20:30:05 --> Model Class Initialized
INFO - 2019-07-01 20:30:05 --> Model Class Initialized
INFO - 2019-07-01 20:30:05 --> Final output sent to browser
DEBUG - 2019-07-01 20:30:05 --> Total execution time: 0.2923
INFO - 2019-07-01 14:30:10 --> Config Class Initialized
INFO - 2019-07-01 14:30:10 --> Hooks Class Initialized
DEBUG - 2019-07-01 14:30:10 --> UTF-8 Support Enabled
INFO - 2019-07-01 14:30:10 --> Utf8 Class Initialized
INFO - 2019-07-01 14:30:10 --> URI Class Initialized
INFO - 2019-07-01 14:30:10 --> Router Class Initialized
INFO - 2019-07-01 14:30:10 --> Output Class Initialized
INFO - 2019-07-01 14:30:10 --> Security Class Initialized
DEBUG - 2019-07-01 14:30:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 14:30:10 --> Input Class Initialized
INFO - 2019-07-01 14:30:10 --> Language Class Initialized
INFO - 2019-07-01 14:30:10 --> Language Class Initialized
INFO - 2019-07-01 14:30:10 --> Config Class Initialized
INFO - 2019-07-01 14:30:10 --> Loader Class Initialized
DEBUG - 2019-07-01 14:30:10 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 14:30:10 --> Helper loaded: url_helper
INFO - 2019-07-01 14:30:10 --> Helper loaded: inflector_helper
INFO - 2019-07-01 14:30:10 --> Helper loaded: string_helper
INFO - 2019-07-01 14:30:10 --> Helper loaded: array_helper
INFO - 2019-07-01 14:30:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 14:30:10 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 14:30:10 --> Database Driver Class Initialized
INFO - 2019-07-01 14:30:10 --> Controller Class Initialized
INFO - 2019-07-01 20:30:10 --> Helper loaded: language_helper
INFO - 2019-07-01 20:30:10 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 20:30:10 --> Model Class Initialized
INFO - 2019-07-01 20:30:10 --> Model Class Initialized
INFO - 2019-07-01 20:30:10 --> Model Class Initialized
INFO - 2019-07-01 20:30:10 --> Model Class Initialized
INFO - 2019-07-01 20:30:10 --> Helper loaded: form_helper
INFO - 2019-07-01 20:30:10 --> Form Validation Class Initialized
DEBUG - 2019-07-01 20:30:10 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 20:30:10 --> Model Class Initialized
INFO - 2019-07-01 20:30:10 --> Model Class Initialized
ERROR - 2019-07-01 20:30:10 --> Query error: Column 'resto_id' in where clause is ambiguous - Invalid query: SELECT `orders`.*, `order_details`.`qty`, `order_details`.`price`, `order_details`.`sub_total`, `order_details`.`order_status`, `order_details`.`product_id`, `order_details`.`created_at` AS `order_date`, `products`.`name`, CONCAT(`customers`.`firstname`, " ", `customers`.`lastname`) AS customer_fullname, `customers`.`address`, `customers`.`contact_number`, `customers`.`email`
FROM `orders`
LEFT JOIN `order_details` ON `order_details`.`order_id` = `orders`.`id`
LEFT JOIN `products` ON `products`.`id` = `order_details`.`product_id`
INNER JOIN `customers` as `customers` ON `customers`.`id` = `orders`.`customer_id`
WHERE `resto_id` = '2'
AND `customer_id` = '1'
AND `order_status` = 'pending'
INFO - 2019-07-01 20:30:10 --> Language file loaded: language/english/db_lang.php
INFO - 2019-07-01 14:32:25 --> Config Class Initialized
INFO - 2019-07-01 14:32:25 --> Hooks Class Initialized
DEBUG - 2019-07-01 14:32:25 --> UTF-8 Support Enabled
INFO - 2019-07-01 14:32:25 --> Utf8 Class Initialized
INFO - 2019-07-01 14:32:25 --> URI Class Initialized
INFO - 2019-07-01 14:32:25 --> Router Class Initialized
INFO - 2019-07-01 14:32:25 --> Output Class Initialized
INFO - 2019-07-01 14:32:25 --> Security Class Initialized
DEBUG - 2019-07-01 14:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 14:32:25 --> Input Class Initialized
INFO - 2019-07-01 14:32:25 --> Language Class Initialized
INFO - 2019-07-01 14:32:25 --> Language Class Initialized
INFO - 2019-07-01 14:32:25 --> Config Class Initialized
INFO - 2019-07-01 14:32:25 --> Loader Class Initialized
DEBUG - 2019-07-01 14:32:25 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 14:32:25 --> Helper loaded: url_helper
INFO - 2019-07-01 14:32:25 --> Helper loaded: inflector_helper
INFO - 2019-07-01 14:32:25 --> Helper loaded: string_helper
INFO - 2019-07-01 14:32:25 --> Helper loaded: array_helper
INFO - 2019-07-01 14:32:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 14:32:25 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 14:32:25 --> Database Driver Class Initialized
INFO - 2019-07-01 14:32:25 --> Controller Class Initialized
INFO - 2019-07-01 20:32:25 --> Helper loaded: language_helper
INFO - 2019-07-01 20:32:25 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 20:32:25 --> Model Class Initialized
INFO - 2019-07-01 20:32:25 --> Model Class Initialized
INFO - 2019-07-01 20:32:25 --> Model Class Initialized
INFO - 2019-07-01 20:32:25 --> Model Class Initialized
INFO - 2019-07-01 20:32:25 --> Helper loaded: form_helper
INFO - 2019-07-01 20:32:25 --> Form Validation Class Initialized
DEBUG - 2019-07-01 20:32:25 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 20:32:25 --> Model Class Initialized
INFO - 2019-07-01 20:32:25 --> Model Class Initialized
INFO - 2019-07-01 20:32:25 --> Final output sent to browser
DEBUG - 2019-07-01 20:32:25 --> Total execution time: 0.4591
INFO - 2019-07-01 14:33:07 --> Config Class Initialized
INFO - 2019-07-01 14:33:07 --> Hooks Class Initialized
DEBUG - 2019-07-01 14:33:07 --> UTF-8 Support Enabled
INFO - 2019-07-01 14:33:07 --> Utf8 Class Initialized
INFO - 2019-07-01 14:33:07 --> URI Class Initialized
INFO - 2019-07-01 14:33:07 --> Router Class Initialized
INFO - 2019-07-01 14:33:07 --> Output Class Initialized
INFO - 2019-07-01 14:33:07 --> Security Class Initialized
DEBUG - 2019-07-01 14:33:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 14:33:07 --> Input Class Initialized
INFO - 2019-07-01 14:33:07 --> Language Class Initialized
INFO - 2019-07-01 14:33:07 --> Language Class Initialized
INFO - 2019-07-01 14:33:07 --> Config Class Initialized
INFO - 2019-07-01 14:33:07 --> Loader Class Initialized
DEBUG - 2019-07-01 14:33:07 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 14:33:07 --> Helper loaded: url_helper
INFO - 2019-07-01 14:33:07 --> Helper loaded: inflector_helper
INFO - 2019-07-01 14:33:07 --> Helper loaded: string_helper
INFO - 2019-07-01 14:33:07 --> Helper loaded: array_helper
INFO - 2019-07-01 14:33:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 14:33:07 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 14:33:07 --> Database Driver Class Initialized
INFO - 2019-07-01 14:33:07 --> Controller Class Initialized
INFO - 2019-07-01 20:33:07 --> Helper loaded: language_helper
INFO - 2019-07-01 20:33:07 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 20:33:07 --> Model Class Initialized
INFO - 2019-07-01 20:33:07 --> Model Class Initialized
INFO - 2019-07-01 20:33:07 --> Model Class Initialized
INFO - 2019-07-01 20:33:07 --> Model Class Initialized
INFO - 2019-07-01 20:33:07 --> Helper loaded: form_helper
INFO - 2019-07-01 20:33:07 --> Form Validation Class Initialized
DEBUG - 2019-07-01 20:33:07 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 20:33:07 --> Model Class Initialized
INFO - 2019-07-01 20:33:07 --> Model Class Initialized
INFO - 2019-07-01 20:33:07 --> Final output sent to browser
DEBUG - 2019-07-01 20:33:07 --> Total execution time: 0.4728
INFO - 2019-07-01 14:33:08 --> Config Class Initialized
INFO - 2019-07-01 14:33:08 --> Hooks Class Initialized
DEBUG - 2019-07-01 14:33:08 --> UTF-8 Support Enabled
INFO - 2019-07-01 14:33:08 --> Utf8 Class Initialized
INFO - 2019-07-01 14:33:08 --> URI Class Initialized
INFO - 2019-07-01 14:33:08 --> Router Class Initialized
INFO - 2019-07-01 14:33:08 --> Output Class Initialized
INFO - 2019-07-01 14:33:08 --> Security Class Initialized
DEBUG - 2019-07-01 14:33:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 14:33:08 --> Input Class Initialized
INFO - 2019-07-01 14:33:08 --> Language Class Initialized
INFO - 2019-07-01 14:33:08 --> Language Class Initialized
INFO - 2019-07-01 14:33:08 --> Config Class Initialized
INFO - 2019-07-01 14:33:08 --> Loader Class Initialized
DEBUG - 2019-07-01 14:33:08 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 14:33:08 --> Helper loaded: url_helper
INFO - 2019-07-01 14:33:08 --> Helper loaded: inflector_helper
INFO - 2019-07-01 14:33:08 --> Helper loaded: string_helper
INFO - 2019-07-01 14:33:08 --> Helper loaded: array_helper
INFO - 2019-07-01 14:33:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 14:33:08 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 14:33:08 --> Database Driver Class Initialized
INFO - 2019-07-01 14:33:08 --> Controller Class Initialized
INFO - 2019-07-01 20:33:08 --> Helper loaded: language_helper
INFO - 2019-07-01 20:33:08 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 20:33:08 --> Model Class Initialized
INFO - 2019-07-01 20:33:08 --> Model Class Initialized
INFO - 2019-07-01 20:33:08 --> Model Class Initialized
INFO - 2019-07-01 20:33:08 --> Model Class Initialized
INFO - 2019-07-01 20:33:08 --> Model Class Initialized
INFO - 2019-07-01 20:33:08 --> Final output sent to browser
DEBUG - 2019-07-01 20:33:08 --> Total execution time: 0.3125
INFO - 2019-07-01 14:33:14 --> Config Class Initialized
INFO - 2019-07-01 14:33:14 --> Hooks Class Initialized
DEBUG - 2019-07-01 14:33:14 --> UTF-8 Support Enabled
INFO - 2019-07-01 14:33:14 --> Utf8 Class Initialized
INFO - 2019-07-01 14:33:14 --> URI Class Initialized
INFO - 2019-07-01 14:33:14 --> Router Class Initialized
INFO - 2019-07-01 14:33:14 --> Output Class Initialized
INFO - 2019-07-01 14:33:14 --> Security Class Initialized
DEBUG - 2019-07-01 14:33:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 14:33:14 --> Input Class Initialized
INFO - 2019-07-01 14:33:14 --> Language Class Initialized
INFO - 2019-07-01 14:33:14 --> Language Class Initialized
INFO - 2019-07-01 14:33:14 --> Config Class Initialized
INFO - 2019-07-01 14:33:14 --> Loader Class Initialized
DEBUG - 2019-07-01 14:33:14 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 14:33:14 --> Helper loaded: url_helper
INFO - 2019-07-01 14:33:14 --> Helper loaded: inflector_helper
INFO - 2019-07-01 14:33:14 --> Helper loaded: string_helper
INFO - 2019-07-01 14:33:14 --> Helper loaded: array_helper
INFO - 2019-07-01 14:33:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 14:33:14 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 14:33:14 --> Database Driver Class Initialized
INFO - 2019-07-01 14:33:14 --> Controller Class Initialized
INFO - 2019-07-01 20:33:14 --> Helper loaded: language_helper
INFO - 2019-07-01 20:33:14 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 20:33:14 --> Model Class Initialized
INFO - 2019-07-01 20:33:14 --> Model Class Initialized
INFO - 2019-07-01 20:33:14 --> Model Class Initialized
INFO - 2019-07-01 20:33:14 --> Model Class Initialized
INFO - 2019-07-01 20:33:14 --> Helper loaded: form_helper
INFO - 2019-07-01 20:33:14 --> Form Validation Class Initialized
DEBUG - 2019-07-01 20:33:14 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 20:33:14 --> Model Class Initialized
INFO - 2019-07-01 20:33:14 --> Model Class Initialized
ERROR - 2019-07-01 20:33:14 --> Query error: Column 'resto_id' in where clause is ambiguous - Invalid query: SELECT `orders`.*, `order_details`.`qty`, `order_details`.`price`, `order_details`.`sub_total`, `order_details`.`order_status`, `order_details`.`product_id`, `order_details`.`created_at` AS `order_date`, `products`.`name`, CONCAT(`customers`.`firstname`, " ", `customers`.`lastname`) AS customer_fullname, `customers`.`address`, `customers`.`contact_number`, `customers`.`email`
FROM `orders`
LEFT JOIN `order_details` ON `order_details`.`order_id` = `orders`.`id`
LEFT JOIN `products` ON `products`.`id` = `order_details`.`product_id`
INNER JOIN `customers` as `customers` ON `customers`.`id` = `orders`.`customer_id`
WHERE `resto_id` = '2'
AND `customer_id` = '1'
AND `order_status` = 'pending'
INFO - 2019-07-01 20:33:14 --> Language file loaded: language/english/db_lang.php
INFO - 2019-07-01 14:34:19 --> Config Class Initialized
INFO - 2019-07-01 14:34:19 --> Hooks Class Initialized
DEBUG - 2019-07-01 14:34:19 --> UTF-8 Support Enabled
INFO - 2019-07-01 14:34:19 --> Utf8 Class Initialized
INFO - 2019-07-01 14:34:19 --> URI Class Initialized
INFO - 2019-07-01 14:34:19 --> Router Class Initialized
INFO - 2019-07-01 14:34:19 --> Output Class Initialized
INFO - 2019-07-01 14:34:19 --> Security Class Initialized
DEBUG - 2019-07-01 14:34:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 14:34:19 --> Input Class Initialized
INFO - 2019-07-01 14:34:19 --> Language Class Initialized
INFO - 2019-07-01 14:34:19 --> Language Class Initialized
INFO - 2019-07-01 14:34:19 --> Config Class Initialized
INFO - 2019-07-01 14:34:19 --> Loader Class Initialized
DEBUG - 2019-07-01 14:34:19 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 14:34:19 --> Helper loaded: url_helper
INFO - 2019-07-01 14:34:19 --> Helper loaded: inflector_helper
INFO - 2019-07-01 14:34:19 --> Helper loaded: string_helper
INFO - 2019-07-01 14:34:19 --> Helper loaded: array_helper
INFO - 2019-07-01 14:34:19 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 14:34:19 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 14:34:19 --> Database Driver Class Initialized
INFO - 2019-07-01 14:34:19 --> Controller Class Initialized
INFO - 2019-07-01 20:34:19 --> Helper loaded: language_helper
INFO - 2019-07-01 20:34:19 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 20:34:19 --> Model Class Initialized
INFO - 2019-07-01 20:34:19 --> Model Class Initialized
INFO - 2019-07-01 20:34:19 --> Model Class Initialized
INFO - 2019-07-01 20:34:19 --> Model Class Initialized
INFO - 2019-07-01 20:34:19 --> Helper loaded: form_helper
INFO - 2019-07-01 20:34:20 --> Form Validation Class Initialized
DEBUG - 2019-07-01 20:34:20 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 20:34:20 --> Model Class Initialized
INFO - 2019-07-01 20:34:20 --> Model Class Initialized
INFO - 2019-07-01 20:34:20 --> Final output sent to browser
DEBUG - 2019-07-01 20:34:20 --> Total execution time: 0.4015
INFO - 2019-07-01 14:34:26 --> Config Class Initialized
INFO - 2019-07-01 14:34:26 --> Hooks Class Initialized
DEBUG - 2019-07-01 14:34:26 --> UTF-8 Support Enabled
INFO - 2019-07-01 14:34:26 --> Utf8 Class Initialized
INFO - 2019-07-01 14:34:26 --> URI Class Initialized
INFO - 2019-07-01 14:34:26 --> Router Class Initialized
INFO - 2019-07-01 14:34:26 --> Output Class Initialized
INFO - 2019-07-01 14:34:26 --> Security Class Initialized
DEBUG - 2019-07-01 14:34:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 14:34:26 --> Input Class Initialized
INFO - 2019-07-01 14:34:26 --> Language Class Initialized
INFO - 2019-07-01 14:34:26 --> Language Class Initialized
INFO - 2019-07-01 14:34:26 --> Config Class Initialized
INFO - 2019-07-01 14:34:26 --> Loader Class Initialized
DEBUG - 2019-07-01 14:34:26 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 14:34:26 --> Helper loaded: url_helper
INFO - 2019-07-01 14:34:26 --> Helper loaded: inflector_helper
INFO - 2019-07-01 14:34:26 --> Helper loaded: string_helper
INFO - 2019-07-01 14:34:26 --> Helper loaded: array_helper
INFO - 2019-07-01 14:34:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 14:34:26 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 14:34:26 --> Database Driver Class Initialized
INFO - 2019-07-01 14:34:26 --> Controller Class Initialized
INFO - 2019-07-01 20:34:26 --> Helper loaded: language_helper
INFO - 2019-07-01 20:34:26 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 20:34:26 --> Model Class Initialized
INFO - 2019-07-01 20:34:27 --> Model Class Initialized
INFO - 2019-07-01 20:34:27 --> Model Class Initialized
INFO - 2019-07-01 20:34:27 --> Model Class Initialized
INFO - 2019-07-01 20:34:27 --> Model Class Initialized
INFO - 2019-07-01 20:34:27 --> Final output sent to browser
DEBUG - 2019-07-01 20:34:27 --> Total execution time: 0.2935
INFO - 2019-07-01 14:34:32 --> Config Class Initialized
INFO - 2019-07-01 14:34:32 --> Hooks Class Initialized
DEBUG - 2019-07-01 14:34:32 --> UTF-8 Support Enabled
INFO - 2019-07-01 14:34:32 --> Utf8 Class Initialized
INFO - 2019-07-01 14:34:32 --> URI Class Initialized
INFO - 2019-07-01 14:34:32 --> Router Class Initialized
INFO - 2019-07-01 14:34:32 --> Output Class Initialized
INFO - 2019-07-01 14:34:32 --> Security Class Initialized
DEBUG - 2019-07-01 14:34:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 14:34:32 --> Input Class Initialized
INFO - 2019-07-01 14:34:32 --> Language Class Initialized
INFO - 2019-07-01 14:34:32 --> Language Class Initialized
INFO - 2019-07-01 14:34:32 --> Config Class Initialized
INFO - 2019-07-01 14:34:32 --> Loader Class Initialized
DEBUG - 2019-07-01 14:34:32 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 14:34:32 --> Helper loaded: url_helper
INFO - 2019-07-01 14:34:32 --> Helper loaded: inflector_helper
INFO - 2019-07-01 14:34:32 --> Helper loaded: string_helper
INFO - 2019-07-01 14:34:32 --> Helper loaded: array_helper
INFO - 2019-07-01 14:34:32 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 14:34:32 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 14:34:32 --> Database Driver Class Initialized
INFO - 2019-07-01 14:34:32 --> Controller Class Initialized
INFO - 2019-07-01 20:34:32 --> Helper loaded: language_helper
INFO - 2019-07-01 20:34:32 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 20:34:32 --> Model Class Initialized
INFO - 2019-07-01 20:34:32 --> Model Class Initialized
INFO - 2019-07-01 20:34:32 --> Model Class Initialized
INFO - 2019-07-01 20:34:32 --> Model Class Initialized
INFO - 2019-07-01 20:34:32 --> Helper loaded: form_helper
INFO - 2019-07-01 20:34:32 --> Form Validation Class Initialized
DEBUG - 2019-07-01 20:34:32 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 20:34:32 --> Model Class Initialized
INFO - 2019-07-01 20:34:32 --> Model Class Initialized
ERROR - 2019-07-01 20:34:32 --> Query error: Column 'resto_id' in where clause is ambiguous - Invalid query: SELECT `orders`.*, `order_details`.`qty`, `order_details`.`price`, `order_details`.`resto_id`, `order_details`.`sub_total`, `order_details`.`order_status`, `order_details`.`product_id`, `order_details`.`created_at` AS `order_date`, `products`.`name`, CONCAT(`customers`.`firstname`, " ", `customers`.`lastname`) AS customer_fullname, `customers`.`address`, `customers`.`contact_number`, `customers`.`email`
FROM `orders`
LEFT JOIN `order_details` ON `order_details`.`order_id` = `orders`.`id`
LEFT JOIN `products` ON `products`.`id` = `order_details`.`product_id`
INNER JOIN `customers` as `customers` ON `customers`.`id` = `orders`.`customer_id`
WHERE `resto_id` = '2'
AND `customer_id` = '1'
AND `order_status` = 'pending'
INFO - 2019-07-01 20:34:32 --> Language file loaded: language/english/db_lang.php
INFO - 2019-07-01 14:37:58 --> Config Class Initialized
INFO - 2019-07-01 14:37:58 --> Hooks Class Initialized
DEBUG - 2019-07-01 14:37:58 --> UTF-8 Support Enabled
INFO - 2019-07-01 14:37:58 --> Utf8 Class Initialized
INFO - 2019-07-01 14:37:58 --> URI Class Initialized
INFO - 2019-07-01 14:37:58 --> Router Class Initialized
INFO - 2019-07-01 14:37:58 --> Output Class Initialized
INFO - 2019-07-01 14:37:58 --> Security Class Initialized
DEBUG - 2019-07-01 14:37:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 14:37:58 --> Input Class Initialized
INFO - 2019-07-01 14:37:58 --> Language Class Initialized
INFO - 2019-07-01 14:37:58 --> Language Class Initialized
INFO - 2019-07-01 14:37:58 --> Config Class Initialized
INFO - 2019-07-01 14:37:58 --> Loader Class Initialized
DEBUG - 2019-07-01 14:37:58 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 14:37:58 --> Helper loaded: url_helper
INFO - 2019-07-01 14:37:58 --> Helper loaded: inflector_helper
INFO - 2019-07-01 14:37:58 --> Helper loaded: string_helper
INFO - 2019-07-01 14:37:58 --> Helper loaded: array_helper
INFO - 2019-07-01 14:37:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 14:37:58 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 14:37:58 --> Database Driver Class Initialized
INFO - 2019-07-01 14:37:58 --> Controller Class Initialized
INFO - 2019-07-01 20:37:58 --> Helper loaded: language_helper
INFO - 2019-07-01 20:37:58 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 20:37:58 --> Model Class Initialized
INFO - 2019-07-01 20:37:58 --> Model Class Initialized
INFO - 2019-07-01 20:37:58 --> Model Class Initialized
INFO - 2019-07-01 20:37:58 --> Model Class Initialized
INFO - 2019-07-01 20:37:58 --> Helper loaded: form_helper
INFO - 2019-07-01 20:37:58 --> Form Validation Class Initialized
DEBUG - 2019-07-01 20:37:58 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 20:37:58 --> Model Class Initialized
INFO - 2019-07-01 20:37:58 --> Model Class Initialized
INFO - 2019-07-01 20:37:58 --> Final output sent to browser
DEBUG - 2019-07-01 20:37:58 --> Total execution time: 0.4071
INFO - 2019-07-01 14:38:05 --> Config Class Initialized
INFO - 2019-07-01 14:38:05 --> Hooks Class Initialized
DEBUG - 2019-07-01 14:38:05 --> UTF-8 Support Enabled
INFO - 2019-07-01 14:38:05 --> Utf8 Class Initialized
INFO - 2019-07-01 14:38:06 --> URI Class Initialized
INFO - 2019-07-01 14:38:06 --> Router Class Initialized
INFO - 2019-07-01 14:38:06 --> Output Class Initialized
INFO - 2019-07-01 14:38:06 --> Security Class Initialized
DEBUG - 2019-07-01 14:38:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 14:38:06 --> Input Class Initialized
INFO - 2019-07-01 14:38:06 --> Language Class Initialized
INFO - 2019-07-01 14:38:06 --> Language Class Initialized
INFO - 2019-07-01 14:38:06 --> Config Class Initialized
INFO - 2019-07-01 14:38:06 --> Loader Class Initialized
DEBUG - 2019-07-01 14:38:06 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 14:38:06 --> Helper loaded: url_helper
INFO - 2019-07-01 14:38:06 --> Helper loaded: inflector_helper
INFO - 2019-07-01 14:38:06 --> Helper loaded: string_helper
INFO - 2019-07-01 14:38:06 --> Helper loaded: array_helper
INFO - 2019-07-01 14:38:06 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 14:38:06 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 14:38:06 --> Database Driver Class Initialized
INFO - 2019-07-01 14:38:06 --> Controller Class Initialized
INFO - 2019-07-01 20:38:06 --> Helper loaded: language_helper
INFO - 2019-07-01 20:38:06 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 20:38:06 --> Model Class Initialized
INFO - 2019-07-01 20:38:06 --> Model Class Initialized
INFO - 2019-07-01 20:38:06 --> Model Class Initialized
INFO - 2019-07-01 20:38:06 --> Model Class Initialized
INFO - 2019-07-01 20:38:06 --> Model Class Initialized
INFO - 2019-07-01 20:38:06 --> Final output sent to browser
DEBUG - 2019-07-01 20:38:06 --> Total execution time: 0.2862
INFO - 2019-07-01 14:38:16 --> Config Class Initialized
INFO - 2019-07-01 14:38:16 --> Hooks Class Initialized
DEBUG - 2019-07-01 14:38:16 --> UTF-8 Support Enabled
INFO - 2019-07-01 14:38:16 --> Utf8 Class Initialized
INFO - 2019-07-01 14:38:16 --> URI Class Initialized
INFO - 2019-07-01 14:38:16 --> Router Class Initialized
INFO - 2019-07-01 14:38:16 --> Output Class Initialized
INFO - 2019-07-01 14:38:16 --> Security Class Initialized
DEBUG - 2019-07-01 14:38:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 14:38:16 --> Input Class Initialized
INFO - 2019-07-01 14:38:16 --> Language Class Initialized
INFO - 2019-07-01 14:38:16 --> Language Class Initialized
INFO - 2019-07-01 14:38:16 --> Config Class Initialized
INFO - 2019-07-01 14:38:16 --> Loader Class Initialized
DEBUG - 2019-07-01 14:38:16 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 14:38:16 --> Helper loaded: url_helper
INFO - 2019-07-01 14:38:16 --> Helper loaded: inflector_helper
INFO - 2019-07-01 14:38:16 --> Helper loaded: string_helper
INFO - 2019-07-01 14:38:16 --> Helper loaded: array_helper
INFO - 2019-07-01 14:38:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 14:38:16 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 14:38:16 --> Database Driver Class Initialized
INFO - 2019-07-01 14:38:16 --> Controller Class Initialized
INFO - 2019-07-01 20:38:16 --> Helper loaded: language_helper
INFO - 2019-07-01 20:38:16 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 20:38:16 --> Model Class Initialized
INFO - 2019-07-01 20:38:16 --> Model Class Initialized
INFO - 2019-07-01 20:38:16 --> Model Class Initialized
INFO - 2019-07-01 20:38:17 --> Model Class Initialized
INFO - 2019-07-01 20:38:17 --> Helper loaded: form_helper
INFO - 2019-07-01 20:38:17 --> Form Validation Class Initialized
DEBUG - 2019-07-01 20:38:17 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 20:38:17 --> Model Class Initialized
INFO - 2019-07-01 20:38:17 --> Model Class Initialized
ERROR - 2019-07-01 20:38:17 --> Query error: Column 'resto_id' in where clause is ambiguous - Invalid query: SELECT `orders`.*, `order_details`.`qty`, `order_details`.`price`, `order_details`.`resto_id`, `order_details`.`sub_total`, `order_details`.`order_status`, `order_details`.`product_id`, `order_details`.`created_at` AS `order_date`, `products`.`name`, CONCAT(`customers`.`firstname`, " ", `customers`.`lastname`) AS customer_fullname, `customers`.`address`, `customers`.`contact_number`, `customers`.`email`
FROM `orders`
LEFT JOIN `order_details` ON `order_details`.`order_id` = `orders`.`id`
LEFT JOIN `products` ON `products`.`id` = `order_details`.`product_id`
INNER JOIN `customers` as `customers` ON `customers`.`id` = `orders`.`customer_id`
WHERE `resto_id` = '2'
AND `customer_id` = '1'
AND `order_status` = 'pending'
INFO - 2019-07-01 20:38:17 --> Language file loaded: language/english/db_lang.php
INFO - 2019-07-01 14:39:17 --> Config Class Initialized
INFO - 2019-07-01 14:39:17 --> Hooks Class Initialized
DEBUG - 2019-07-01 14:39:17 --> UTF-8 Support Enabled
INFO - 2019-07-01 14:39:17 --> Utf8 Class Initialized
INFO - 2019-07-01 14:39:17 --> URI Class Initialized
INFO - 2019-07-01 14:39:17 --> Router Class Initialized
INFO - 2019-07-01 14:39:17 --> Output Class Initialized
INFO - 2019-07-01 14:39:17 --> Security Class Initialized
DEBUG - 2019-07-01 14:39:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 14:39:17 --> Input Class Initialized
INFO - 2019-07-01 14:39:17 --> Language Class Initialized
INFO - 2019-07-01 14:39:17 --> Language Class Initialized
INFO - 2019-07-01 14:39:17 --> Config Class Initialized
INFO - 2019-07-01 14:39:17 --> Loader Class Initialized
DEBUG - 2019-07-01 14:39:17 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 14:39:17 --> Helper loaded: url_helper
INFO - 2019-07-01 14:39:17 --> Helper loaded: inflector_helper
INFO - 2019-07-01 14:39:17 --> Helper loaded: string_helper
INFO - 2019-07-01 14:39:17 --> Helper loaded: array_helper
INFO - 2019-07-01 14:39:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 14:39:17 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 14:39:17 --> Database Driver Class Initialized
INFO - 2019-07-01 14:39:17 --> Controller Class Initialized
INFO - 2019-07-01 20:39:17 --> Helper loaded: language_helper
INFO - 2019-07-01 20:39:17 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 20:39:17 --> Model Class Initialized
INFO - 2019-07-01 20:39:17 --> Model Class Initialized
INFO - 2019-07-01 20:39:18 --> Model Class Initialized
INFO - 2019-07-01 20:39:18 --> Model Class Initialized
INFO - 2019-07-01 20:39:18 --> Helper loaded: form_helper
INFO - 2019-07-01 20:39:18 --> Form Validation Class Initialized
DEBUG - 2019-07-01 20:39:18 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 20:39:18 --> Model Class Initialized
INFO - 2019-07-01 20:39:18 --> Model Class Initialized
ERROR - 2019-07-01 20:39:18 --> Query error: Column 'resto_id' in where clause is ambiguous - Invalid query: SELECT `orders`.*, `order_details`.`qty`, `order_details`.`price`, `order_details`.`resto_id`, `order_details`.`sub_total`, `order_details`.`order_status`, `order_details`.`product_id`, `order_details`.`created_at` AS `order_date`, `products`.`name`, CONCAT(`customers`.`firstname`, " ", `customers`.`lastname`) AS customer_fullname, `customers`.`address`, `customers`.`contact_number`, `customers`.`email`
FROM `orders`
LEFT JOIN `order_details` ON `order_details`.`order_id` = `orders`.`id`
LEFT JOIN `products` ON `products`.`id` = `order_details`.`product_id`
INNER JOIN `customers` as `customers` ON `customers`.`id` = `orders`.`customer_id`
WHERE `resto_id` = '2'
AND `customer_id` = '1'
AND `order_status` = 'pending'
INFO - 2019-07-01 20:39:18 --> Language file loaded: language/english/db_lang.php
INFO - 2019-07-01 14:39:35 --> Config Class Initialized
INFO - 2019-07-01 14:39:35 --> Hooks Class Initialized
DEBUG - 2019-07-01 14:39:35 --> UTF-8 Support Enabled
INFO - 2019-07-01 14:39:35 --> Utf8 Class Initialized
INFO - 2019-07-01 14:39:35 --> URI Class Initialized
INFO - 2019-07-01 14:39:35 --> Router Class Initialized
INFO - 2019-07-01 14:39:35 --> Output Class Initialized
INFO - 2019-07-01 14:39:35 --> Security Class Initialized
DEBUG - 2019-07-01 14:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 14:39:35 --> Input Class Initialized
INFO - 2019-07-01 14:39:35 --> Language Class Initialized
INFO - 2019-07-01 14:39:35 --> Language Class Initialized
INFO - 2019-07-01 14:39:35 --> Config Class Initialized
INFO - 2019-07-01 14:39:35 --> Loader Class Initialized
DEBUG - 2019-07-01 14:39:35 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 14:39:35 --> Helper loaded: url_helper
INFO - 2019-07-01 14:39:35 --> Helper loaded: inflector_helper
INFO - 2019-07-01 14:39:35 --> Helper loaded: string_helper
INFO - 2019-07-01 14:39:35 --> Helper loaded: array_helper
INFO - 2019-07-01 14:39:35 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 14:39:35 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 14:39:35 --> Database Driver Class Initialized
INFO - 2019-07-01 14:39:35 --> Controller Class Initialized
INFO - 2019-07-01 20:39:35 --> Helper loaded: language_helper
INFO - 2019-07-01 20:39:35 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 20:39:35 --> Model Class Initialized
INFO - 2019-07-01 20:39:35 --> Model Class Initialized
INFO - 2019-07-01 20:39:35 --> Model Class Initialized
INFO - 2019-07-01 20:39:35 --> Model Class Initialized
INFO - 2019-07-01 20:39:35 --> Helper loaded: form_helper
INFO - 2019-07-01 20:39:35 --> Form Validation Class Initialized
DEBUG - 2019-07-01 20:39:35 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 20:39:35 --> Model Class Initialized
INFO - 2019-07-01 20:39:35 --> Model Class Initialized
INFO - 2019-07-01 20:39:35 --> Final output sent to browser
DEBUG - 2019-07-01 20:39:35 --> Total execution time: 0.3815
INFO - 2019-07-01 14:39:36 --> Config Class Initialized
INFO - 2019-07-01 14:39:36 --> Hooks Class Initialized
DEBUG - 2019-07-01 14:39:36 --> UTF-8 Support Enabled
INFO - 2019-07-01 14:39:36 --> Utf8 Class Initialized
INFO - 2019-07-01 14:39:36 --> URI Class Initialized
INFO - 2019-07-01 14:39:36 --> Router Class Initialized
INFO - 2019-07-01 14:39:36 --> Output Class Initialized
INFO - 2019-07-01 14:39:36 --> Security Class Initialized
DEBUG - 2019-07-01 14:39:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 14:39:36 --> Input Class Initialized
INFO - 2019-07-01 14:39:36 --> Language Class Initialized
INFO - 2019-07-01 14:39:36 --> Language Class Initialized
INFO - 2019-07-01 14:39:36 --> Config Class Initialized
INFO - 2019-07-01 14:39:36 --> Loader Class Initialized
DEBUG - 2019-07-01 14:39:36 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 14:39:37 --> Helper loaded: url_helper
INFO - 2019-07-01 14:39:37 --> Helper loaded: inflector_helper
INFO - 2019-07-01 14:39:37 --> Helper loaded: string_helper
INFO - 2019-07-01 14:39:37 --> Helper loaded: array_helper
INFO - 2019-07-01 14:39:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 14:39:37 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 14:39:37 --> Database Driver Class Initialized
INFO - 2019-07-01 14:39:37 --> Controller Class Initialized
INFO - 2019-07-01 20:39:37 --> Helper loaded: language_helper
INFO - 2019-07-01 20:39:37 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 20:39:37 --> Model Class Initialized
INFO - 2019-07-01 20:39:37 --> Model Class Initialized
INFO - 2019-07-01 20:39:37 --> Model Class Initialized
INFO - 2019-07-01 20:39:37 --> Model Class Initialized
INFO - 2019-07-01 20:39:37 --> Model Class Initialized
INFO - 2019-07-01 20:39:37 --> Final output sent to browser
DEBUG - 2019-07-01 20:39:37 --> Total execution time: 0.3146
INFO - 2019-07-01 14:39:41 --> Config Class Initialized
INFO - 2019-07-01 14:39:41 --> Hooks Class Initialized
DEBUG - 2019-07-01 14:39:41 --> UTF-8 Support Enabled
INFO - 2019-07-01 14:39:41 --> Utf8 Class Initialized
INFO - 2019-07-01 14:39:41 --> URI Class Initialized
INFO - 2019-07-01 14:39:41 --> Router Class Initialized
INFO - 2019-07-01 14:39:41 --> Output Class Initialized
INFO - 2019-07-01 14:39:41 --> Security Class Initialized
DEBUG - 2019-07-01 14:39:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 14:39:41 --> Input Class Initialized
INFO - 2019-07-01 14:39:41 --> Language Class Initialized
INFO - 2019-07-01 14:39:41 --> Language Class Initialized
INFO - 2019-07-01 14:39:41 --> Config Class Initialized
INFO - 2019-07-01 14:39:41 --> Loader Class Initialized
DEBUG - 2019-07-01 14:39:41 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 14:39:41 --> Helper loaded: url_helper
INFO - 2019-07-01 14:39:41 --> Helper loaded: inflector_helper
INFO - 2019-07-01 14:39:41 --> Helper loaded: string_helper
INFO - 2019-07-01 14:39:41 --> Helper loaded: array_helper
INFO - 2019-07-01 14:39:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 14:39:41 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 14:39:41 --> Database Driver Class Initialized
INFO - 2019-07-01 14:39:41 --> Controller Class Initialized
INFO - 2019-07-01 20:39:41 --> Helper loaded: language_helper
INFO - 2019-07-01 20:39:41 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 20:39:41 --> Model Class Initialized
INFO - 2019-07-01 20:39:41 --> Model Class Initialized
INFO - 2019-07-01 20:39:41 --> Model Class Initialized
INFO - 2019-07-01 20:39:41 --> Model Class Initialized
INFO - 2019-07-01 20:39:41 --> Helper loaded: form_helper
INFO - 2019-07-01 20:39:41 --> Form Validation Class Initialized
DEBUG - 2019-07-01 20:39:41 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 20:39:41 --> Model Class Initialized
INFO - 2019-07-01 20:39:41 --> Model Class Initialized
ERROR - 2019-07-01 20:39:41 --> Query error: Column 'resto_id' in where clause is ambiguous - Invalid query: SELECT `orders`.*, `order_details`.`qty`, `order_details`.`price`, `order_details`.`resto_id`, `order_details`.`sub_total`, `order_details`.`order_status`, `order_details`.`product_id`, `order_details`.`created_at` AS `order_date`, `products`.`name`, CONCAT(`customers`.`firstname`, " ", `customers`.`lastname`) AS customer_fullname, `customers`.`address`, `customers`.`contact_number`, `customers`.`email`
FROM `orders`
LEFT JOIN `order_details` ON `order_details`.`order_id` = `orders`.`id`
LEFT JOIN `products` ON `products`.`id` = `order_details`.`product_id`
INNER JOIN `customers` as `customers` ON `customers`.`id` = `orders`.`customer_id`
WHERE `resto_id` = '2'
AND `customer_id` = '1'
AND `order_status` = 'pending'
INFO - 2019-07-01 20:39:41 --> Language file loaded: language/english/db_lang.php
INFO - 2019-07-01 14:40:41 --> Config Class Initialized
INFO - 2019-07-01 14:40:41 --> Hooks Class Initialized
DEBUG - 2019-07-01 14:40:41 --> UTF-8 Support Enabled
INFO - 2019-07-01 14:40:41 --> Utf8 Class Initialized
INFO - 2019-07-01 14:40:41 --> URI Class Initialized
INFO - 2019-07-01 14:40:41 --> Router Class Initialized
INFO - 2019-07-01 14:40:41 --> Output Class Initialized
INFO - 2019-07-01 14:40:41 --> Security Class Initialized
DEBUG - 2019-07-01 14:40:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 14:40:41 --> Input Class Initialized
INFO - 2019-07-01 14:40:41 --> Language Class Initialized
INFO - 2019-07-01 14:40:41 --> Language Class Initialized
INFO - 2019-07-01 14:40:41 --> Config Class Initialized
INFO - 2019-07-01 14:40:41 --> Loader Class Initialized
DEBUG - 2019-07-01 14:40:41 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 14:40:41 --> Helper loaded: url_helper
INFO - 2019-07-01 14:40:41 --> Helper loaded: inflector_helper
INFO - 2019-07-01 14:40:41 --> Helper loaded: string_helper
INFO - 2019-07-01 14:40:42 --> Helper loaded: array_helper
INFO - 2019-07-01 14:40:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 14:40:42 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 14:40:42 --> Database Driver Class Initialized
INFO - 2019-07-01 14:40:42 --> Controller Class Initialized
INFO - 2019-07-01 20:40:42 --> Helper loaded: language_helper
INFO - 2019-07-01 20:40:42 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 20:40:42 --> Model Class Initialized
INFO - 2019-07-01 20:40:42 --> Model Class Initialized
INFO - 2019-07-01 20:40:42 --> Model Class Initialized
INFO - 2019-07-01 20:40:42 --> Model Class Initialized
INFO - 2019-07-01 20:40:42 --> Helper loaded: form_helper
INFO - 2019-07-01 20:40:42 --> Form Validation Class Initialized
DEBUG - 2019-07-01 20:40:42 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 20:40:42 --> Model Class Initialized
INFO - 2019-07-01 20:40:42 --> Model Class Initialized
INFO - 2019-07-01 20:40:42 --> Final output sent to browser
DEBUG - 2019-07-01 20:40:42 --> Total execution time: 0.4245
INFO - 2019-07-01 14:40:43 --> Config Class Initialized
INFO - 2019-07-01 14:40:43 --> Hooks Class Initialized
DEBUG - 2019-07-01 14:40:43 --> UTF-8 Support Enabled
INFO - 2019-07-01 14:40:43 --> Utf8 Class Initialized
INFO - 2019-07-01 14:40:43 --> URI Class Initialized
INFO - 2019-07-01 14:40:43 --> Router Class Initialized
INFO - 2019-07-01 14:40:43 --> Output Class Initialized
INFO - 2019-07-01 14:40:43 --> Security Class Initialized
DEBUG - 2019-07-01 14:40:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 14:40:43 --> Input Class Initialized
INFO - 2019-07-01 14:40:43 --> Language Class Initialized
INFO - 2019-07-01 14:40:43 --> Language Class Initialized
INFO - 2019-07-01 14:40:43 --> Config Class Initialized
INFO - 2019-07-01 14:40:43 --> Loader Class Initialized
DEBUG - 2019-07-01 14:40:43 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 14:40:43 --> Helper loaded: url_helper
INFO - 2019-07-01 14:40:43 --> Helper loaded: inflector_helper
INFO - 2019-07-01 14:40:43 --> Helper loaded: string_helper
INFO - 2019-07-01 14:40:43 --> Helper loaded: array_helper
INFO - 2019-07-01 14:40:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 14:40:43 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 14:40:43 --> Database Driver Class Initialized
INFO - 2019-07-01 14:40:43 --> Controller Class Initialized
INFO - 2019-07-01 20:40:43 --> Helper loaded: language_helper
INFO - 2019-07-01 20:40:43 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 20:40:43 --> Model Class Initialized
INFO - 2019-07-01 20:40:43 --> Model Class Initialized
INFO - 2019-07-01 20:40:43 --> Model Class Initialized
INFO - 2019-07-01 20:40:43 --> Model Class Initialized
INFO - 2019-07-01 20:40:43 --> Model Class Initialized
INFO - 2019-07-01 20:40:43 --> Final output sent to browser
DEBUG - 2019-07-01 20:40:43 --> Total execution time: 0.3279
INFO - 2019-07-01 14:40:47 --> Config Class Initialized
INFO - 2019-07-01 14:40:47 --> Hooks Class Initialized
DEBUG - 2019-07-01 14:40:47 --> UTF-8 Support Enabled
INFO - 2019-07-01 14:40:47 --> Utf8 Class Initialized
INFO - 2019-07-01 14:40:48 --> URI Class Initialized
INFO - 2019-07-01 14:40:48 --> Router Class Initialized
INFO - 2019-07-01 14:40:48 --> Output Class Initialized
INFO - 2019-07-01 14:40:48 --> Security Class Initialized
DEBUG - 2019-07-01 14:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 14:40:48 --> Input Class Initialized
INFO - 2019-07-01 14:40:48 --> Language Class Initialized
INFO - 2019-07-01 14:40:48 --> Language Class Initialized
INFO - 2019-07-01 14:40:48 --> Config Class Initialized
INFO - 2019-07-01 14:40:48 --> Loader Class Initialized
DEBUG - 2019-07-01 14:40:48 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 14:40:48 --> Helper loaded: url_helper
INFO - 2019-07-01 14:40:48 --> Helper loaded: inflector_helper
INFO - 2019-07-01 14:40:48 --> Helper loaded: string_helper
INFO - 2019-07-01 14:40:48 --> Helper loaded: array_helper
INFO - 2019-07-01 14:40:48 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 14:40:48 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 14:40:48 --> Database Driver Class Initialized
INFO - 2019-07-01 14:40:48 --> Controller Class Initialized
INFO - 2019-07-01 20:40:48 --> Helper loaded: language_helper
INFO - 2019-07-01 20:40:48 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 20:40:48 --> Model Class Initialized
INFO - 2019-07-01 20:40:48 --> Model Class Initialized
INFO - 2019-07-01 20:40:48 --> Model Class Initialized
INFO - 2019-07-01 20:40:48 --> Model Class Initialized
INFO - 2019-07-01 20:40:48 --> Helper loaded: form_helper
INFO - 2019-07-01 20:40:48 --> Form Validation Class Initialized
DEBUG - 2019-07-01 20:40:48 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 20:40:48 --> Model Class Initialized
INFO - 2019-07-01 20:40:48 --> Model Class Initialized
ERROR - 2019-07-01 20:40:48 --> Query error: Column 'resto_id' in where clause is ambiguous - Invalid query: SELECT `orders`.*, `order_details`.`qty`, `order_details`.`price`, `order_details`.`resto_id`, `order_details`.`sub_total`, `order_details`.`order_status`, `order_details`.`product_id`, `order_details`.`created_at` AS `order_date`, `products`.`name`, CONCAT(`customers`.`firstname`, " ", `customers`.`lastname`) AS customer_fullname, `customers`.`address`, `customers`.`contact_number`, `customers`.`email`, `customers`.`email`
FROM `orders`
LEFT JOIN `order_details` ON `order_details`.`order_id` = `orders`.`id`
LEFT JOIN `products` ON `products`.`id` = `order_details`.`product_id`
INNER JOIN `customers` as `customers` ON `customers`.`id` = `orders`.`customer_id`
WHERE `resto_id` = '2'
AND `customer_id` = '1'
AND `order_status` = 'pending'
INFO - 2019-07-01 20:40:48 --> Language file loaded: language/english/db_lang.php
INFO - 2019-07-01 14:46:27 --> Config Class Initialized
INFO - 2019-07-01 14:46:27 --> Hooks Class Initialized
DEBUG - 2019-07-01 14:46:27 --> UTF-8 Support Enabled
INFO - 2019-07-01 14:46:27 --> Utf8 Class Initialized
INFO - 2019-07-01 14:46:27 --> URI Class Initialized
INFO - 2019-07-01 14:46:27 --> Router Class Initialized
INFO - 2019-07-01 14:46:27 --> Output Class Initialized
INFO - 2019-07-01 14:46:27 --> Security Class Initialized
DEBUG - 2019-07-01 14:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 14:46:27 --> Input Class Initialized
INFO - 2019-07-01 14:46:27 --> Language Class Initialized
INFO - 2019-07-01 14:46:27 --> Language Class Initialized
INFO - 2019-07-01 14:46:27 --> Config Class Initialized
INFO - 2019-07-01 14:46:27 --> Loader Class Initialized
DEBUG - 2019-07-01 14:46:27 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 14:46:27 --> Helper loaded: url_helper
INFO - 2019-07-01 14:46:27 --> Helper loaded: inflector_helper
INFO - 2019-07-01 14:46:27 --> Helper loaded: string_helper
INFO - 2019-07-01 14:46:27 --> Helper loaded: array_helper
INFO - 2019-07-01 14:46:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 14:46:27 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 14:46:27 --> Database Driver Class Initialized
INFO - 2019-07-01 14:46:27 --> Controller Class Initialized
INFO - 2019-07-01 20:46:27 --> Helper loaded: language_helper
INFO - 2019-07-01 20:46:27 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 20:46:27 --> Model Class Initialized
INFO - 2019-07-01 20:46:27 --> Model Class Initialized
INFO - 2019-07-01 20:46:27 --> Model Class Initialized
INFO - 2019-07-01 20:46:27 --> Model Class Initialized
INFO - 2019-07-01 20:46:27 --> Helper loaded: form_helper
INFO - 2019-07-01 20:46:27 --> Form Validation Class Initialized
DEBUG - 2019-07-01 20:46:27 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 20:46:27 --> Model Class Initialized
INFO - 2019-07-01 20:46:27 --> Model Class Initialized
INFO - 2019-07-01 20:46:27 --> Final output sent to browser
DEBUG - 2019-07-01 20:46:27 --> Total execution time: 0.3989
INFO - 2019-07-01 14:46:29 --> Config Class Initialized
INFO - 2019-07-01 14:46:29 --> Hooks Class Initialized
DEBUG - 2019-07-01 14:46:29 --> UTF-8 Support Enabled
INFO - 2019-07-01 14:46:29 --> Utf8 Class Initialized
INFO - 2019-07-01 14:46:29 --> URI Class Initialized
INFO - 2019-07-01 14:46:29 --> Router Class Initialized
INFO - 2019-07-01 14:46:29 --> Output Class Initialized
INFO - 2019-07-01 14:46:29 --> Security Class Initialized
DEBUG - 2019-07-01 14:46:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 14:46:29 --> Input Class Initialized
INFO - 2019-07-01 14:46:29 --> Language Class Initialized
INFO - 2019-07-01 14:46:29 --> Language Class Initialized
INFO - 2019-07-01 14:46:29 --> Config Class Initialized
INFO - 2019-07-01 14:46:29 --> Loader Class Initialized
DEBUG - 2019-07-01 14:46:29 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 14:46:29 --> Helper loaded: url_helper
INFO - 2019-07-01 14:46:29 --> Helper loaded: inflector_helper
INFO - 2019-07-01 14:46:29 --> Helper loaded: string_helper
INFO - 2019-07-01 14:46:29 --> Helper loaded: array_helper
INFO - 2019-07-01 14:46:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 14:46:29 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 14:46:29 --> Database Driver Class Initialized
INFO - 2019-07-01 14:46:29 --> Controller Class Initialized
INFO - 2019-07-01 20:46:29 --> Helper loaded: language_helper
INFO - 2019-07-01 20:46:29 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 20:46:29 --> Model Class Initialized
INFO - 2019-07-01 20:46:29 --> Model Class Initialized
INFO - 2019-07-01 20:46:29 --> Model Class Initialized
INFO - 2019-07-01 20:46:29 --> Model Class Initialized
INFO - 2019-07-01 20:46:29 --> Model Class Initialized
INFO - 2019-07-01 20:46:29 --> Final output sent to browser
DEBUG - 2019-07-01 20:46:29 --> Total execution time: 0.3071
INFO - 2019-07-01 14:46:33 --> Config Class Initialized
INFO - 2019-07-01 14:46:33 --> Hooks Class Initialized
DEBUG - 2019-07-01 14:46:33 --> UTF-8 Support Enabled
INFO - 2019-07-01 14:46:33 --> Utf8 Class Initialized
INFO - 2019-07-01 14:46:33 --> URI Class Initialized
INFO - 2019-07-01 14:46:33 --> Router Class Initialized
INFO - 2019-07-01 14:46:33 --> Output Class Initialized
INFO - 2019-07-01 14:46:33 --> Security Class Initialized
DEBUG - 2019-07-01 14:46:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 14:46:33 --> Input Class Initialized
INFO - 2019-07-01 14:46:33 --> Language Class Initialized
INFO - 2019-07-01 14:46:33 --> Language Class Initialized
INFO - 2019-07-01 14:46:33 --> Config Class Initialized
INFO - 2019-07-01 14:46:33 --> Loader Class Initialized
DEBUG - 2019-07-01 14:46:33 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 14:46:33 --> Helper loaded: url_helper
INFO - 2019-07-01 14:46:33 --> Helper loaded: inflector_helper
INFO - 2019-07-01 14:46:33 --> Helper loaded: string_helper
INFO - 2019-07-01 14:46:34 --> Helper loaded: array_helper
INFO - 2019-07-01 14:46:34 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 14:46:34 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 14:46:34 --> Database Driver Class Initialized
INFO - 2019-07-01 14:46:34 --> Controller Class Initialized
INFO - 2019-07-01 20:46:34 --> Helper loaded: language_helper
INFO - 2019-07-01 20:46:34 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 20:46:34 --> Model Class Initialized
INFO - 2019-07-01 20:46:34 --> Model Class Initialized
INFO - 2019-07-01 20:46:34 --> Model Class Initialized
INFO - 2019-07-01 20:46:34 --> Model Class Initialized
INFO - 2019-07-01 20:46:34 --> Helper loaded: form_helper
INFO - 2019-07-01 20:46:34 --> Form Validation Class Initialized
DEBUG - 2019-07-01 20:46:34 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 20:46:34 --> Model Class Initialized
INFO - 2019-07-01 20:46:34 --> Model Class Initialized
ERROR - 2019-07-01 20:46:34 --> Severity: Notice --> Undefined index: name C:\xampp\htdocs\crapi_admin\application\models\Order_model.php 77
ERROR - 2019-07-01 20:46:34 --> Query error: Unknown column 'description_request' in 'field list' - Invalid query: INSERT INTO `order_details` (`order_id`, `product_id`, `qty`, `price`, `sub_total`, `description_request`, `created_at`, `updated_at`) VALUES ('1', '4', '2', '40', 80, 'zxczxc', '2019-07-01 20:46:34', '2019-07-01 20:46:34')
INFO - 2019-07-01 20:46:34 --> Language file loaded: language/english/db_lang.php
INFO - 2019-07-01 14:48:34 --> Config Class Initialized
INFO - 2019-07-01 14:48:34 --> Hooks Class Initialized
DEBUG - 2019-07-01 14:48:34 --> UTF-8 Support Enabled
INFO - 2019-07-01 14:48:34 --> Utf8 Class Initialized
INFO - 2019-07-01 14:48:34 --> URI Class Initialized
INFO - 2019-07-01 14:48:34 --> Router Class Initialized
INFO - 2019-07-01 14:48:34 --> Output Class Initialized
INFO - 2019-07-01 14:48:34 --> Security Class Initialized
DEBUG - 2019-07-01 14:48:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 14:48:34 --> Input Class Initialized
INFO - 2019-07-01 14:48:34 --> Language Class Initialized
INFO - 2019-07-01 14:48:34 --> Language Class Initialized
INFO - 2019-07-01 14:48:34 --> Config Class Initialized
INFO - 2019-07-01 14:48:34 --> Loader Class Initialized
DEBUG - 2019-07-01 14:48:34 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 14:48:34 --> Helper loaded: url_helper
INFO - 2019-07-01 14:48:34 --> Helper loaded: inflector_helper
INFO - 2019-07-01 14:48:34 --> Helper loaded: string_helper
INFO - 2019-07-01 14:48:34 --> Helper loaded: array_helper
INFO - 2019-07-01 14:48:34 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 14:48:34 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 14:48:34 --> Database Driver Class Initialized
INFO - 2019-07-01 14:48:34 --> Controller Class Initialized
INFO - 2019-07-01 20:48:34 --> Helper loaded: language_helper
INFO - 2019-07-01 20:48:34 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 20:48:34 --> Model Class Initialized
INFO - 2019-07-01 20:48:34 --> Model Class Initialized
INFO - 2019-07-01 20:48:34 --> Model Class Initialized
INFO - 2019-07-01 20:48:34 --> Model Class Initialized
INFO - 2019-07-01 20:48:34 --> Helper loaded: form_helper
INFO - 2019-07-01 20:48:34 --> Form Validation Class Initialized
DEBUG - 2019-07-01 20:48:34 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 20:48:34 --> Model Class Initialized
INFO - 2019-07-01 20:48:34 --> Model Class Initialized
INFO - 2019-07-01 20:48:34 --> Final output sent to browser
DEBUG - 2019-07-01 20:48:34 --> Total execution time: 0.5302
INFO - 2019-07-01 14:48:36 --> Config Class Initialized
INFO - 2019-07-01 14:48:36 --> Hooks Class Initialized
DEBUG - 2019-07-01 14:48:36 --> UTF-8 Support Enabled
INFO - 2019-07-01 14:48:36 --> Utf8 Class Initialized
INFO - 2019-07-01 14:48:36 --> URI Class Initialized
INFO - 2019-07-01 14:48:36 --> Router Class Initialized
INFO - 2019-07-01 14:48:36 --> Output Class Initialized
INFO - 2019-07-01 14:48:36 --> Security Class Initialized
DEBUG - 2019-07-01 14:48:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 14:48:36 --> Input Class Initialized
INFO - 2019-07-01 14:48:36 --> Language Class Initialized
INFO - 2019-07-01 14:48:36 --> Language Class Initialized
INFO - 2019-07-01 14:48:36 --> Config Class Initialized
INFO - 2019-07-01 14:48:36 --> Loader Class Initialized
DEBUG - 2019-07-01 14:48:36 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 14:48:36 --> Helper loaded: url_helper
INFO - 2019-07-01 14:48:36 --> Helper loaded: inflector_helper
INFO - 2019-07-01 14:48:36 --> Helper loaded: string_helper
INFO - 2019-07-01 14:48:36 --> Helper loaded: array_helper
INFO - 2019-07-01 14:48:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 14:48:36 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 14:48:36 --> Database Driver Class Initialized
INFO - 2019-07-01 14:48:36 --> Controller Class Initialized
INFO - 2019-07-01 20:48:36 --> Helper loaded: language_helper
INFO - 2019-07-01 20:48:36 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 20:48:36 --> Model Class Initialized
INFO - 2019-07-01 20:48:36 --> Model Class Initialized
INFO - 2019-07-01 20:48:36 --> Model Class Initialized
INFO - 2019-07-01 20:48:36 --> Model Class Initialized
INFO - 2019-07-01 20:48:36 --> Model Class Initialized
INFO - 2019-07-01 20:48:36 --> Final output sent to browser
DEBUG - 2019-07-01 20:48:36 --> Total execution time: 0.4253
INFO - 2019-07-01 14:48:43 --> Config Class Initialized
INFO - 2019-07-01 14:48:43 --> Hooks Class Initialized
DEBUG - 2019-07-01 14:48:43 --> UTF-8 Support Enabled
INFO - 2019-07-01 14:48:43 --> Utf8 Class Initialized
INFO - 2019-07-01 14:48:43 --> URI Class Initialized
INFO - 2019-07-01 14:48:43 --> Router Class Initialized
INFO - 2019-07-01 14:48:43 --> Output Class Initialized
INFO - 2019-07-01 14:48:43 --> Security Class Initialized
DEBUG - 2019-07-01 14:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 14:48:43 --> Input Class Initialized
INFO - 2019-07-01 14:48:43 --> Language Class Initialized
INFO - 2019-07-01 14:48:43 --> Language Class Initialized
INFO - 2019-07-01 14:48:43 --> Config Class Initialized
INFO - 2019-07-01 14:48:43 --> Loader Class Initialized
DEBUG - 2019-07-01 14:48:43 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 14:48:43 --> Helper loaded: url_helper
INFO - 2019-07-01 14:48:43 --> Helper loaded: inflector_helper
INFO - 2019-07-01 14:48:43 --> Helper loaded: string_helper
INFO - 2019-07-01 14:48:43 --> Helper loaded: array_helper
INFO - 2019-07-01 14:48:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 14:48:43 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 14:48:43 --> Database Driver Class Initialized
INFO - 2019-07-01 14:48:43 --> Controller Class Initialized
INFO - 2019-07-01 20:48:43 --> Helper loaded: language_helper
INFO - 2019-07-01 20:48:43 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 20:48:43 --> Model Class Initialized
INFO - 2019-07-01 20:48:43 --> Model Class Initialized
INFO - 2019-07-01 20:48:43 --> Model Class Initialized
INFO - 2019-07-01 20:48:43 --> Model Class Initialized
INFO - 2019-07-01 20:48:43 --> Helper loaded: form_helper
INFO - 2019-07-01 20:48:43 --> Form Validation Class Initialized
DEBUG - 2019-07-01 20:48:43 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 20:48:43 --> Model Class Initialized
INFO - 2019-07-01 20:48:43 --> Model Class Initialized
INFO - 2019-07-01 20:48:43 --> Final output sent to browser
DEBUG - 2019-07-01 20:48:43 --> Total execution time: 0.3671
INFO - 2019-07-01 14:51:04 --> Config Class Initialized
INFO - 2019-07-01 14:51:04 --> Hooks Class Initialized
DEBUG - 2019-07-01 14:51:05 --> UTF-8 Support Enabled
INFO - 2019-07-01 14:51:05 --> Utf8 Class Initialized
INFO - 2019-07-01 14:51:05 --> URI Class Initialized
INFO - 2019-07-01 14:51:05 --> Router Class Initialized
INFO - 2019-07-01 14:51:05 --> Output Class Initialized
INFO - 2019-07-01 14:51:05 --> Security Class Initialized
DEBUG - 2019-07-01 14:51:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 14:51:05 --> Input Class Initialized
INFO - 2019-07-01 14:51:05 --> Language Class Initialized
INFO - 2019-07-01 14:51:05 --> Language Class Initialized
INFO - 2019-07-01 14:51:05 --> Config Class Initialized
INFO - 2019-07-01 14:51:05 --> Loader Class Initialized
DEBUG - 2019-07-01 14:51:05 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 14:51:05 --> Helper loaded: url_helper
INFO - 2019-07-01 14:51:05 --> Helper loaded: inflector_helper
INFO - 2019-07-01 14:51:05 --> Helper loaded: string_helper
INFO - 2019-07-01 14:51:05 --> Helper loaded: array_helper
INFO - 2019-07-01 14:51:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 14:51:05 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 14:51:05 --> Database Driver Class Initialized
INFO - 2019-07-01 14:51:05 --> Controller Class Initialized
INFO - 2019-07-01 20:51:05 --> Helper loaded: language_helper
INFO - 2019-07-01 20:51:05 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 20:51:05 --> Model Class Initialized
INFO - 2019-07-01 20:51:05 --> Model Class Initialized
INFO - 2019-07-01 20:51:05 --> Model Class Initialized
INFO - 2019-07-01 20:51:05 --> Model Class Initialized
INFO - 2019-07-01 20:51:05 --> Helper loaded: form_helper
INFO - 2019-07-01 20:51:05 --> Form Validation Class Initialized
DEBUG - 2019-07-01 20:51:05 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 20:51:05 --> Model Class Initialized
INFO - 2019-07-01 20:51:05 --> Model Class Initialized
INFO - 2019-07-01 20:51:05 --> Final output sent to browser
DEBUG - 2019-07-01 20:51:05 --> Total execution time: 0.4096
INFO - 2019-07-01 14:51:06 --> Config Class Initialized
INFO - 2019-07-01 14:51:06 --> Hooks Class Initialized
DEBUG - 2019-07-01 14:51:06 --> UTF-8 Support Enabled
INFO - 2019-07-01 14:51:06 --> Utf8 Class Initialized
INFO - 2019-07-01 14:51:06 --> URI Class Initialized
INFO - 2019-07-01 14:51:06 --> Router Class Initialized
INFO - 2019-07-01 14:51:06 --> Output Class Initialized
INFO - 2019-07-01 14:51:06 --> Security Class Initialized
DEBUG - 2019-07-01 14:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 14:51:06 --> Input Class Initialized
INFO - 2019-07-01 14:51:06 --> Language Class Initialized
INFO - 2019-07-01 14:51:06 --> Language Class Initialized
INFO - 2019-07-01 14:51:06 --> Config Class Initialized
INFO - 2019-07-01 14:51:06 --> Loader Class Initialized
DEBUG - 2019-07-01 14:51:06 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 14:51:06 --> Helper loaded: url_helper
INFO - 2019-07-01 14:51:06 --> Helper loaded: inflector_helper
INFO - 2019-07-01 14:51:06 --> Helper loaded: string_helper
INFO - 2019-07-01 14:51:06 --> Helper loaded: array_helper
INFO - 2019-07-01 14:51:06 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 14:51:06 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 14:51:06 --> Database Driver Class Initialized
INFO - 2019-07-01 14:51:06 --> Controller Class Initialized
INFO - 2019-07-01 20:51:06 --> Helper loaded: language_helper
INFO - 2019-07-01 20:51:06 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 20:51:06 --> Model Class Initialized
INFO - 2019-07-01 20:51:06 --> Model Class Initialized
INFO - 2019-07-01 20:51:06 --> Model Class Initialized
INFO - 2019-07-01 20:51:06 --> Model Class Initialized
INFO - 2019-07-01 20:51:06 --> Model Class Initialized
INFO - 2019-07-01 20:51:06 --> Final output sent to browser
DEBUG - 2019-07-01 20:51:06 --> Total execution time: 0.3184
INFO - 2019-07-01 14:51:12 --> Config Class Initialized
INFO - 2019-07-01 14:51:12 --> Hooks Class Initialized
DEBUG - 2019-07-01 14:51:12 --> UTF-8 Support Enabled
INFO - 2019-07-01 14:51:12 --> Utf8 Class Initialized
INFO - 2019-07-01 14:51:12 --> URI Class Initialized
INFO - 2019-07-01 14:51:12 --> Router Class Initialized
INFO - 2019-07-01 14:51:12 --> Output Class Initialized
INFO - 2019-07-01 14:51:12 --> Security Class Initialized
DEBUG - 2019-07-01 14:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 14:51:12 --> Input Class Initialized
INFO - 2019-07-01 14:51:12 --> Language Class Initialized
INFO - 2019-07-01 14:51:12 --> Language Class Initialized
INFO - 2019-07-01 14:51:12 --> Config Class Initialized
INFO - 2019-07-01 14:51:12 --> Loader Class Initialized
DEBUG - 2019-07-01 14:51:12 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 14:51:12 --> Helper loaded: url_helper
INFO - 2019-07-01 14:51:12 --> Helper loaded: inflector_helper
INFO - 2019-07-01 14:51:12 --> Helper loaded: string_helper
INFO - 2019-07-01 14:51:12 --> Helper loaded: array_helper
INFO - 2019-07-01 14:51:12 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 14:51:12 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 14:51:12 --> Database Driver Class Initialized
INFO - 2019-07-01 14:51:12 --> Controller Class Initialized
INFO - 2019-07-01 20:51:12 --> Helper loaded: language_helper
INFO - 2019-07-01 20:51:12 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 20:51:12 --> Model Class Initialized
INFO - 2019-07-01 20:51:12 --> Model Class Initialized
INFO - 2019-07-01 20:51:12 --> Model Class Initialized
INFO - 2019-07-01 20:51:12 --> Model Class Initialized
INFO - 2019-07-01 20:51:12 --> Helper loaded: form_helper
INFO - 2019-07-01 20:51:12 --> Form Validation Class Initialized
DEBUG - 2019-07-01 20:51:12 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 20:51:12 --> Model Class Initialized
INFO - 2019-07-01 20:51:12 --> Model Class Initialized
INFO - 2019-07-01 20:51:12 --> Final output sent to browser
DEBUG - 2019-07-01 20:51:12 --> Total execution time: 0.3791
INFO - 2019-07-01 14:52:04 --> Config Class Initialized
INFO - 2019-07-01 14:52:04 --> Hooks Class Initialized
DEBUG - 2019-07-01 14:52:04 --> UTF-8 Support Enabled
INFO - 2019-07-01 14:52:04 --> Utf8 Class Initialized
INFO - 2019-07-01 14:52:04 --> URI Class Initialized
INFO - 2019-07-01 14:52:04 --> Router Class Initialized
INFO - 2019-07-01 14:52:04 --> Output Class Initialized
INFO - 2019-07-01 14:52:04 --> Security Class Initialized
DEBUG - 2019-07-01 14:52:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 14:52:04 --> Input Class Initialized
INFO - 2019-07-01 14:52:04 --> Language Class Initialized
INFO - 2019-07-01 14:52:04 --> Language Class Initialized
INFO - 2019-07-01 14:52:04 --> Config Class Initialized
INFO - 2019-07-01 14:52:04 --> Loader Class Initialized
DEBUG - 2019-07-01 14:52:04 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 14:52:04 --> Helper loaded: url_helper
INFO - 2019-07-01 14:52:04 --> Helper loaded: inflector_helper
INFO - 2019-07-01 14:52:04 --> Helper loaded: string_helper
INFO - 2019-07-01 14:52:04 --> Helper loaded: array_helper
INFO - 2019-07-01 14:52:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 14:52:04 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 14:52:04 --> Database Driver Class Initialized
INFO - 2019-07-01 14:52:04 --> Controller Class Initialized
INFO - 2019-07-01 20:52:04 --> Helper loaded: language_helper
INFO - 2019-07-01 20:52:04 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 20:52:04 --> Model Class Initialized
INFO - 2019-07-01 20:52:04 --> Model Class Initialized
INFO - 2019-07-01 20:52:04 --> Model Class Initialized
INFO - 2019-07-01 20:52:04 --> Model Class Initialized
INFO - 2019-07-01 20:52:04 --> Helper loaded: form_helper
INFO - 2019-07-01 20:52:04 --> Form Validation Class Initialized
DEBUG - 2019-07-01 20:52:04 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 20:52:04 --> Model Class Initialized
INFO - 2019-07-01 20:52:04 --> Model Class Initialized
INFO - 2019-07-01 20:52:04 --> Final output sent to browser
DEBUG - 2019-07-01 20:52:04 --> Total execution time: 0.3915
INFO - 2019-07-01 14:52:06 --> Config Class Initialized
INFO - 2019-07-01 14:52:06 --> Hooks Class Initialized
DEBUG - 2019-07-01 14:52:06 --> UTF-8 Support Enabled
INFO - 2019-07-01 14:52:06 --> Utf8 Class Initialized
INFO - 2019-07-01 14:52:06 --> URI Class Initialized
INFO - 2019-07-01 14:52:06 --> Router Class Initialized
INFO - 2019-07-01 14:52:06 --> Output Class Initialized
INFO - 2019-07-01 14:52:06 --> Security Class Initialized
DEBUG - 2019-07-01 14:52:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 14:52:06 --> Input Class Initialized
INFO - 2019-07-01 14:52:06 --> Language Class Initialized
INFO - 2019-07-01 14:52:06 --> Language Class Initialized
INFO - 2019-07-01 14:52:06 --> Config Class Initialized
INFO - 2019-07-01 14:52:06 --> Loader Class Initialized
DEBUG - 2019-07-01 14:52:06 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 14:52:06 --> Helper loaded: url_helper
INFO - 2019-07-01 14:52:06 --> Helper loaded: inflector_helper
INFO - 2019-07-01 14:52:06 --> Helper loaded: string_helper
INFO - 2019-07-01 14:52:06 --> Helper loaded: array_helper
INFO - 2019-07-01 14:52:06 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 14:52:06 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 14:52:06 --> Database Driver Class Initialized
INFO - 2019-07-01 14:52:06 --> Controller Class Initialized
INFO - 2019-07-01 20:52:06 --> Helper loaded: language_helper
INFO - 2019-07-01 20:52:06 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 20:52:06 --> Model Class Initialized
INFO - 2019-07-01 20:52:06 --> Model Class Initialized
INFO - 2019-07-01 20:52:06 --> Model Class Initialized
INFO - 2019-07-01 20:52:06 --> Model Class Initialized
INFO - 2019-07-01 20:52:06 --> Helper loaded: form_helper
INFO - 2019-07-01 20:52:06 --> Form Validation Class Initialized
DEBUG - 2019-07-01 20:52:06 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 20:52:06 --> Model Class Initialized
INFO - 2019-07-01 20:52:06 --> Model Class Initialized
INFO - 2019-07-01 20:52:06 --> Final output sent to browser
DEBUG - 2019-07-01 20:52:06 --> Total execution time: 0.4276
INFO - 2019-07-01 14:52:11 --> Config Class Initialized
INFO - 2019-07-01 14:52:11 --> Hooks Class Initialized
DEBUG - 2019-07-01 14:52:11 --> UTF-8 Support Enabled
INFO - 2019-07-01 14:52:11 --> Utf8 Class Initialized
INFO - 2019-07-01 14:52:11 --> URI Class Initialized
INFO - 2019-07-01 14:52:11 --> Router Class Initialized
INFO - 2019-07-01 14:52:11 --> Output Class Initialized
INFO - 2019-07-01 14:52:11 --> Security Class Initialized
DEBUG - 2019-07-01 14:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 14:52:11 --> Input Class Initialized
INFO - 2019-07-01 14:52:11 --> Language Class Initialized
INFO - 2019-07-01 14:52:11 --> Language Class Initialized
INFO - 2019-07-01 14:52:11 --> Config Class Initialized
INFO - 2019-07-01 14:52:11 --> Loader Class Initialized
DEBUG - 2019-07-01 14:52:11 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 14:52:11 --> Helper loaded: url_helper
INFO - 2019-07-01 14:52:11 --> Helper loaded: inflector_helper
INFO - 2019-07-01 14:52:11 --> Helper loaded: string_helper
INFO - 2019-07-01 14:52:11 --> Helper loaded: array_helper
INFO - 2019-07-01 14:52:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 14:52:11 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 14:52:11 --> Database Driver Class Initialized
INFO - 2019-07-01 14:52:11 --> Controller Class Initialized
INFO - 2019-07-01 20:52:11 --> Helper loaded: language_helper
INFO - 2019-07-01 20:52:11 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 20:52:11 --> Model Class Initialized
INFO - 2019-07-01 20:52:11 --> Model Class Initialized
INFO - 2019-07-01 20:52:11 --> Model Class Initialized
INFO - 2019-07-01 20:52:11 --> Model Class Initialized
INFO - 2019-07-01 20:52:11 --> Model Class Initialized
INFO - 2019-07-01 20:52:11 --> Final output sent to browser
DEBUG - 2019-07-01 20:52:11 --> Total execution time: 0.3495
INFO - 2019-07-01 14:52:12 --> Config Class Initialized
INFO - 2019-07-01 14:52:12 --> Hooks Class Initialized
DEBUG - 2019-07-01 14:52:12 --> UTF-8 Support Enabled
INFO - 2019-07-01 14:52:12 --> Utf8 Class Initialized
INFO - 2019-07-01 14:52:12 --> URI Class Initialized
INFO - 2019-07-01 14:52:12 --> Router Class Initialized
INFO - 2019-07-01 14:52:12 --> Output Class Initialized
INFO - 2019-07-01 14:52:12 --> Security Class Initialized
DEBUG - 2019-07-01 14:52:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 14:52:12 --> Input Class Initialized
INFO - 2019-07-01 14:52:12 --> Language Class Initialized
INFO - 2019-07-01 14:52:12 --> Language Class Initialized
INFO - 2019-07-01 14:52:12 --> Config Class Initialized
INFO - 2019-07-01 14:52:12 --> Loader Class Initialized
DEBUG - 2019-07-01 14:52:12 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 14:52:12 --> Helper loaded: url_helper
INFO - 2019-07-01 14:52:12 --> Helper loaded: inflector_helper
INFO - 2019-07-01 14:52:12 --> Helper loaded: string_helper
INFO - 2019-07-01 14:52:12 --> Helper loaded: array_helper
INFO - 2019-07-01 14:52:12 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 14:52:12 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 14:52:12 --> Database Driver Class Initialized
INFO - 2019-07-01 14:52:12 --> Controller Class Initialized
INFO - 2019-07-01 20:52:12 --> Helper loaded: language_helper
INFO - 2019-07-01 20:52:12 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 20:52:12 --> Model Class Initialized
INFO - 2019-07-01 20:52:12 --> Model Class Initialized
INFO - 2019-07-01 20:52:12 --> Model Class Initialized
INFO - 2019-07-01 20:52:12 --> Model Class Initialized
INFO - 2019-07-01 20:52:12 --> Helper loaded: form_helper
INFO - 2019-07-01 20:52:12 --> Form Validation Class Initialized
DEBUG - 2019-07-01 20:52:12 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 20:52:12 --> Model Class Initialized
INFO - 2019-07-01 20:52:12 --> Model Class Initialized
INFO - 2019-07-01 20:52:13 --> Final output sent to browser
DEBUG - 2019-07-01 20:52:13 --> Total execution time: 0.3920
INFO - 2019-07-01 14:52:14 --> Config Class Initialized
INFO - 2019-07-01 14:52:14 --> Hooks Class Initialized
DEBUG - 2019-07-01 14:52:14 --> UTF-8 Support Enabled
INFO - 2019-07-01 14:52:14 --> Utf8 Class Initialized
INFO - 2019-07-01 14:52:14 --> URI Class Initialized
INFO - 2019-07-01 14:52:14 --> Router Class Initialized
INFO - 2019-07-01 14:52:14 --> Output Class Initialized
INFO - 2019-07-01 14:52:14 --> Security Class Initialized
DEBUG - 2019-07-01 14:52:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 14:52:14 --> Input Class Initialized
INFO - 2019-07-01 14:52:14 --> Language Class Initialized
INFO - 2019-07-01 14:52:14 --> Language Class Initialized
INFO - 2019-07-01 14:52:14 --> Config Class Initialized
INFO - 2019-07-01 14:52:14 --> Loader Class Initialized
DEBUG - 2019-07-01 14:52:14 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 14:52:14 --> Helper loaded: url_helper
INFO - 2019-07-01 14:52:14 --> Helper loaded: inflector_helper
INFO - 2019-07-01 14:52:14 --> Helper loaded: string_helper
INFO - 2019-07-01 14:52:14 --> Helper loaded: array_helper
INFO - 2019-07-01 14:52:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 14:52:14 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 14:52:14 --> Database Driver Class Initialized
INFO - 2019-07-01 14:52:14 --> Controller Class Initialized
INFO - 2019-07-01 20:52:14 --> Helper loaded: language_helper
INFO - 2019-07-01 20:52:14 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 20:52:14 --> Model Class Initialized
INFO - 2019-07-01 20:52:14 --> Model Class Initialized
INFO - 2019-07-01 20:52:14 --> Model Class Initialized
INFO - 2019-07-01 20:52:14 --> Model Class Initialized
INFO - 2019-07-01 20:52:14 --> Helper loaded: form_helper
INFO - 2019-07-01 20:52:14 --> Form Validation Class Initialized
DEBUG - 2019-07-01 20:52:14 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 20:52:14 --> Model Class Initialized
INFO - 2019-07-01 20:52:14 --> Model Class Initialized
INFO - 2019-07-01 20:52:14 --> Final output sent to browser
DEBUG - 2019-07-01 20:52:14 --> Total execution time: 0.4417
INFO - 2019-07-01 14:53:40 --> Config Class Initialized
INFO - 2019-07-01 14:53:40 --> Hooks Class Initialized
DEBUG - 2019-07-01 14:53:40 --> UTF-8 Support Enabled
INFO - 2019-07-01 14:53:40 --> Utf8 Class Initialized
INFO - 2019-07-01 14:53:40 --> URI Class Initialized
INFO - 2019-07-01 14:53:40 --> Router Class Initialized
INFO - 2019-07-01 14:53:40 --> Output Class Initialized
INFO - 2019-07-01 14:53:40 --> Security Class Initialized
DEBUG - 2019-07-01 14:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 14:53:40 --> Input Class Initialized
INFO - 2019-07-01 14:53:40 --> Language Class Initialized
INFO - 2019-07-01 14:53:40 --> Language Class Initialized
INFO - 2019-07-01 14:53:40 --> Config Class Initialized
INFO - 2019-07-01 14:53:40 --> Loader Class Initialized
DEBUG - 2019-07-01 14:53:40 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 14:53:40 --> Helper loaded: url_helper
INFO - 2019-07-01 14:53:40 --> Helper loaded: inflector_helper
INFO - 2019-07-01 14:53:40 --> Helper loaded: string_helper
INFO - 2019-07-01 14:53:40 --> Helper loaded: array_helper
INFO - 2019-07-01 14:53:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 14:53:40 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 14:53:40 --> Database Driver Class Initialized
INFO - 2019-07-01 14:53:40 --> Controller Class Initialized
INFO - 2019-07-01 20:53:40 --> Helper loaded: language_helper
INFO - 2019-07-01 20:53:40 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 20:53:40 --> Model Class Initialized
INFO - 2019-07-01 20:53:40 --> Model Class Initialized
INFO - 2019-07-01 20:53:40 --> Model Class Initialized
INFO - 2019-07-01 20:53:40 --> Model Class Initialized
INFO - 2019-07-01 20:53:40 --> Helper loaded: form_helper
INFO - 2019-07-01 20:53:40 --> Form Validation Class Initialized
DEBUG - 2019-07-01 20:53:40 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 20:53:40 --> Model Class Initialized
INFO - 2019-07-01 20:53:40 --> Model Class Initialized
INFO - 2019-07-01 20:53:40 --> Final output sent to browser
DEBUG - 2019-07-01 20:53:40 --> Total execution time: 0.4390
INFO - 2019-07-01 14:53:40 --> Config Class Initialized
INFO - 2019-07-01 14:53:40 --> Hooks Class Initialized
DEBUG - 2019-07-01 14:53:40 --> UTF-8 Support Enabled
INFO - 2019-07-01 14:53:40 --> Utf8 Class Initialized
INFO - 2019-07-01 14:53:40 --> URI Class Initialized
INFO - 2019-07-01 14:53:40 --> Router Class Initialized
INFO - 2019-07-01 14:53:40 --> Output Class Initialized
INFO - 2019-07-01 14:53:40 --> Security Class Initialized
DEBUG - 2019-07-01 14:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 14:53:40 --> Input Class Initialized
INFO - 2019-07-01 14:53:40 --> Language Class Initialized
INFO - 2019-07-01 14:53:41 --> Language Class Initialized
INFO - 2019-07-01 14:53:41 --> Config Class Initialized
INFO - 2019-07-01 14:53:41 --> Loader Class Initialized
DEBUG - 2019-07-01 14:53:41 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 14:53:41 --> Helper loaded: url_helper
INFO - 2019-07-01 14:53:41 --> Helper loaded: inflector_helper
INFO - 2019-07-01 14:53:41 --> Helper loaded: string_helper
INFO - 2019-07-01 14:53:41 --> Helper loaded: array_helper
INFO - 2019-07-01 14:53:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 14:53:41 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 14:53:41 --> Database Driver Class Initialized
INFO - 2019-07-01 14:53:41 --> Controller Class Initialized
INFO - 2019-07-01 20:53:41 --> Helper loaded: language_helper
INFO - 2019-07-01 20:53:41 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 20:53:41 --> Model Class Initialized
INFO - 2019-07-01 20:53:41 --> Model Class Initialized
INFO - 2019-07-01 20:53:41 --> Model Class Initialized
INFO - 2019-07-01 20:53:41 --> Model Class Initialized
INFO - 2019-07-01 20:53:41 --> Model Class Initialized
INFO - 2019-07-01 20:53:41 --> Final output sent to browser
DEBUG - 2019-07-01 20:53:41 --> Total execution time: 0.3147
INFO - 2019-07-01 14:53:50 --> Config Class Initialized
INFO - 2019-07-01 14:53:50 --> Hooks Class Initialized
DEBUG - 2019-07-01 14:53:50 --> UTF-8 Support Enabled
INFO - 2019-07-01 14:53:50 --> Utf8 Class Initialized
INFO - 2019-07-01 14:53:50 --> URI Class Initialized
INFO - 2019-07-01 14:53:50 --> Router Class Initialized
INFO - 2019-07-01 14:53:50 --> Output Class Initialized
INFO - 2019-07-01 14:53:50 --> Security Class Initialized
DEBUG - 2019-07-01 14:53:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 14:53:50 --> Input Class Initialized
INFO - 2019-07-01 14:53:50 --> Language Class Initialized
INFO - 2019-07-01 14:53:50 --> Language Class Initialized
INFO - 2019-07-01 14:53:50 --> Config Class Initialized
INFO - 2019-07-01 14:53:50 --> Loader Class Initialized
DEBUG - 2019-07-01 14:53:50 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 14:53:50 --> Helper loaded: url_helper
INFO - 2019-07-01 14:53:50 --> Helper loaded: inflector_helper
INFO - 2019-07-01 14:53:50 --> Helper loaded: string_helper
INFO - 2019-07-01 14:53:50 --> Helper loaded: array_helper
INFO - 2019-07-01 14:53:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 14:53:50 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 14:53:50 --> Database Driver Class Initialized
INFO - 2019-07-01 14:53:50 --> Controller Class Initialized
INFO - 2019-07-01 20:53:50 --> Helper loaded: language_helper
INFO - 2019-07-01 20:53:50 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 20:53:50 --> Model Class Initialized
INFO - 2019-07-01 20:53:51 --> Model Class Initialized
INFO - 2019-07-01 20:53:51 --> Model Class Initialized
INFO - 2019-07-01 20:53:51 --> Model Class Initialized
INFO - 2019-07-01 20:53:51 --> Helper loaded: form_helper
INFO - 2019-07-01 20:53:51 --> Form Validation Class Initialized
DEBUG - 2019-07-01 20:53:51 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 20:53:51 --> Model Class Initialized
INFO - 2019-07-01 20:53:51 --> Model Class Initialized
INFO - 2019-07-01 20:53:51 --> Final output sent to browser
DEBUG - 2019-07-01 20:53:51 --> Total execution time: 0.4489
INFO - 2019-07-01 14:53:51 --> Config Class Initialized
INFO - 2019-07-01 14:53:51 --> Hooks Class Initialized
DEBUG - 2019-07-01 14:53:51 --> UTF-8 Support Enabled
INFO - 2019-07-01 14:53:51 --> Utf8 Class Initialized
INFO - 2019-07-01 14:53:51 --> URI Class Initialized
INFO - 2019-07-01 14:53:51 --> Router Class Initialized
INFO - 2019-07-01 14:53:51 --> Output Class Initialized
INFO - 2019-07-01 14:53:51 --> Security Class Initialized
DEBUG - 2019-07-01 14:53:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 14:53:51 --> Input Class Initialized
INFO - 2019-07-01 14:53:51 --> Language Class Initialized
INFO - 2019-07-01 14:53:51 --> Language Class Initialized
INFO - 2019-07-01 14:53:51 --> Config Class Initialized
INFO - 2019-07-01 14:53:51 --> Loader Class Initialized
DEBUG - 2019-07-01 14:53:51 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 14:53:51 --> Helper loaded: url_helper
INFO - 2019-07-01 14:53:51 --> Helper loaded: inflector_helper
INFO - 2019-07-01 14:53:51 --> Helper loaded: string_helper
INFO - 2019-07-01 14:53:51 --> Helper loaded: array_helper
INFO - 2019-07-01 14:53:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 14:53:51 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 14:53:51 --> Database Driver Class Initialized
INFO - 2019-07-01 14:53:51 --> Controller Class Initialized
INFO - 2019-07-01 20:53:51 --> Helper loaded: language_helper
INFO - 2019-07-01 20:53:51 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 20:53:51 --> Model Class Initialized
INFO - 2019-07-01 20:53:51 --> Model Class Initialized
INFO - 2019-07-01 20:53:51 --> Model Class Initialized
INFO - 2019-07-01 20:53:51 --> Model Class Initialized
INFO - 2019-07-01 20:53:51 --> Helper loaded: form_helper
INFO - 2019-07-01 20:53:51 --> Form Validation Class Initialized
DEBUG - 2019-07-01 20:53:51 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 20:53:51 --> Model Class Initialized
INFO - 2019-07-01 20:53:51 --> Model Class Initialized
INFO - 2019-07-01 20:53:51 --> Final output sent to browser
DEBUG - 2019-07-01 20:53:51 --> Total execution time: 0.4620
INFO - 2019-07-01 14:53:58 --> Config Class Initialized
INFO - 2019-07-01 14:53:58 --> Hooks Class Initialized
DEBUG - 2019-07-01 14:53:58 --> UTF-8 Support Enabled
INFO - 2019-07-01 14:53:58 --> Utf8 Class Initialized
INFO - 2019-07-01 14:53:58 --> URI Class Initialized
INFO - 2019-07-01 14:53:58 --> Router Class Initialized
INFO - 2019-07-01 14:53:58 --> Output Class Initialized
INFO - 2019-07-01 14:53:58 --> Security Class Initialized
DEBUG - 2019-07-01 14:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 14:53:58 --> Input Class Initialized
INFO - 2019-07-01 14:53:58 --> Language Class Initialized
INFO - 2019-07-01 14:53:58 --> Language Class Initialized
INFO - 2019-07-01 14:53:58 --> Config Class Initialized
INFO - 2019-07-01 14:53:58 --> Loader Class Initialized
DEBUG - 2019-07-01 14:53:58 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 14:53:58 --> Helper loaded: url_helper
INFO - 2019-07-01 14:53:58 --> Helper loaded: inflector_helper
INFO - 2019-07-01 14:53:58 --> Helper loaded: string_helper
INFO - 2019-07-01 14:53:58 --> Helper loaded: array_helper
INFO - 2019-07-01 14:53:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 14:53:58 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 14:53:58 --> Database Driver Class Initialized
INFO - 2019-07-01 14:53:58 --> Controller Class Initialized
INFO - 2019-07-01 20:53:58 --> Helper loaded: language_helper
INFO - 2019-07-01 20:53:58 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 20:53:58 --> Model Class Initialized
INFO - 2019-07-01 20:53:58 --> Model Class Initialized
INFO - 2019-07-01 20:53:58 --> Model Class Initialized
INFO - 2019-07-01 20:53:58 --> Model Class Initialized
INFO - 2019-07-01 20:53:58 --> Helper loaded: form_helper
INFO - 2019-07-01 20:53:58 --> Form Validation Class Initialized
DEBUG - 2019-07-01 20:53:58 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 20:53:58 --> Model Class Initialized
INFO - 2019-07-01 20:53:58 --> Model Class Initialized
INFO - 2019-07-01 20:53:58 --> Final output sent to browser
DEBUG - 2019-07-01 20:53:58 --> Total execution time: 0.3749
INFO - 2019-07-01 14:54:56 --> Config Class Initialized
INFO - 2019-07-01 14:54:56 --> Hooks Class Initialized
DEBUG - 2019-07-01 14:54:56 --> UTF-8 Support Enabled
INFO - 2019-07-01 14:54:56 --> Utf8 Class Initialized
INFO - 2019-07-01 14:54:56 --> URI Class Initialized
INFO - 2019-07-01 14:54:56 --> Router Class Initialized
INFO - 2019-07-01 14:54:56 --> Output Class Initialized
INFO - 2019-07-01 14:54:56 --> Security Class Initialized
DEBUG - 2019-07-01 14:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 14:54:56 --> Input Class Initialized
INFO - 2019-07-01 14:54:56 --> Language Class Initialized
INFO - 2019-07-01 14:54:56 --> Language Class Initialized
INFO - 2019-07-01 14:54:56 --> Config Class Initialized
INFO - 2019-07-01 14:54:56 --> Loader Class Initialized
DEBUG - 2019-07-01 14:54:56 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 14:54:56 --> Helper loaded: url_helper
INFO - 2019-07-01 14:54:56 --> Helper loaded: inflector_helper
INFO - 2019-07-01 14:54:56 --> Helper loaded: string_helper
INFO - 2019-07-01 14:54:56 --> Helper loaded: array_helper
INFO - 2019-07-01 14:54:56 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 14:54:56 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 14:54:56 --> Database Driver Class Initialized
INFO - 2019-07-01 14:54:56 --> Controller Class Initialized
INFO - 2019-07-01 20:54:56 --> Helper loaded: language_helper
INFO - 2019-07-01 20:54:56 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 20:54:56 --> Model Class Initialized
INFO - 2019-07-01 20:54:56 --> Model Class Initialized
INFO - 2019-07-01 20:54:56 --> Model Class Initialized
INFO - 2019-07-01 20:54:56 --> Model Class Initialized
INFO - 2019-07-01 20:54:56 --> Helper loaded: form_helper
INFO - 2019-07-01 20:54:56 --> Form Validation Class Initialized
DEBUG - 2019-07-01 20:54:56 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 20:54:56 --> Model Class Initialized
INFO - 2019-07-01 20:54:56 --> Model Class Initialized
INFO - 2019-07-01 20:54:56 --> Final output sent to browser
DEBUG - 2019-07-01 20:54:56 --> Total execution time: 0.3549
INFO - 2019-07-01 14:55:00 --> Config Class Initialized
INFO - 2019-07-01 14:55:00 --> Hooks Class Initialized
DEBUG - 2019-07-01 14:55:00 --> UTF-8 Support Enabled
INFO - 2019-07-01 14:55:00 --> Utf8 Class Initialized
INFO - 2019-07-01 14:55:00 --> URI Class Initialized
INFO - 2019-07-01 14:55:00 --> Router Class Initialized
INFO - 2019-07-01 14:55:00 --> Output Class Initialized
INFO - 2019-07-01 14:55:00 --> Security Class Initialized
DEBUG - 2019-07-01 14:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 14:55:00 --> Input Class Initialized
INFO - 2019-07-01 14:55:00 --> Language Class Initialized
INFO - 2019-07-01 14:55:00 --> Language Class Initialized
INFO - 2019-07-01 14:55:00 --> Config Class Initialized
INFO - 2019-07-01 14:55:00 --> Loader Class Initialized
DEBUG - 2019-07-01 14:55:00 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 14:55:00 --> Helper loaded: url_helper
INFO - 2019-07-01 14:55:00 --> Helper loaded: inflector_helper
INFO - 2019-07-01 14:55:00 --> Helper loaded: string_helper
INFO - 2019-07-01 14:55:00 --> Helper loaded: array_helper
INFO - 2019-07-01 14:55:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 14:55:00 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 14:55:00 --> Database Driver Class Initialized
INFO - 2019-07-01 14:55:00 --> Controller Class Initialized
INFO - 2019-07-01 20:55:00 --> Helper loaded: language_helper
INFO - 2019-07-01 20:55:00 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 20:55:00 --> Model Class Initialized
INFO - 2019-07-01 20:55:00 --> Model Class Initialized
INFO - 2019-07-01 20:55:00 --> Model Class Initialized
INFO - 2019-07-01 20:55:00 --> Model Class Initialized
INFO - 2019-07-01 20:55:00 --> Helper loaded: form_helper
INFO - 2019-07-01 20:55:00 --> Form Validation Class Initialized
DEBUG - 2019-07-01 20:55:00 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 20:55:00 --> Model Class Initialized
INFO - 2019-07-01 20:55:00 --> Model Class Initialized
INFO - 2019-07-01 20:55:00 --> Final output sent to browser
DEBUG - 2019-07-01 20:55:00 --> Total execution time: 0.3419
INFO - 2019-07-01 14:57:52 --> Config Class Initialized
INFO - 2019-07-01 14:57:52 --> Hooks Class Initialized
DEBUG - 2019-07-01 14:57:52 --> UTF-8 Support Enabled
INFO - 2019-07-01 14:57:52 --> Utf8 Class Initialized
INFO - 2019-07-01 14:57:52 --> URI Class Initialized
INFO - 2019-07-01 14:57:52 --> Router Class Initialized
INFO - 2019-07-01 14:57:52 --> Output Class Initialized
INFO - 2019-07-01 14:57:52 --> Security Class Initialized
DEBUG - 2019-07-01 14:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 14:57:52 --> Input Class Initialized
INFO - 2019-07-01 14:57:52 --> Language Class Initialized
INFO - 2019-07-01 14:57:52 --> Language Class Initialized
INFO - 2019-07-01 14:57:52 --> Config Class Initialized
INFO - 2019-07-01 14:57:52 --> Loader Class Initialized
DEBUG - 2019-07-01 14:57:52 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 14:57:52 --> Helper loaded: url_helper
INFO - 2019-07-01 14:57:52 --> Helper loaded: inflector_helper
INFO - 2019-07-01 14:57:52 --> Helper loaded: string_helper
INFO - 2019-07-01 14:57:52 --> Helper loaded: array_helper
INFO - 2019-07-01 14:57:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 14:57:52 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 14:57:52 --> Database Driver Class Initialized
INFO - 2019-07-01 14:57:52 --> Controller Class Initialized
INFO - 2019-07-01 20:57:52 --> Helper loaded: language_helper
INFO - 2019-07-01 20:57:52 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 20:57:52 --> Model Class Initialized
INFO - 2019-07-01 20:57:52 --> Model Class Initialized
INFO - 2019-07-01 20:57:52 --> Model Class Initialized
INFO - 2019-07-01 20:57:52 --> Model Class Initialized
INFO - 2019-07-01 20:57:52 --> Helper loaded: form_helper
INFO - 2019-07-01 20:57:52 --> Form Validation Class Initialized
DEBUG - 2019-07-01 20:57:52 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 20:57:52 --> Model Class Initialized
INFO - 2019-07-01 20:57:52 --> Model Class Initialized
INFO - 2019-07-01 20:57:52 --> Final output sent to browser
DEBUG - 2019-07-01 20:57:52 --> Total execution time: 0.3789
INFO - 2019-07-01 14:59:14 --> Config Class Initialized
INFO - 2019-07-01 14:59:14 --> Hooks Class Initialized
DEBUG - 2019-07-01 14:59:14 --> UTF-8 Support Enabled
INFO - 2019-07-01 14:59:14 --> Utf8 Class Initialized
INFO - 2019-07-01 14:59:14 --> URI Class Initialized
INFO - 2019-07-01 14:59:14 --> Router Class Initialized
INFO - 2019-07-01 14:59:14 --> Output Class Initialized
INFO - 2019-07-01 14:59:14 --> Security Class Initialized
DEBUG - 2019-07-01 14:59:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 14:59:14 --> Input Class Initialized
INFO - 2019-07-01 14:59:14 --> Language Class Initialized
INFO - 2019-07-01 14:59:14 --> Language Class Initialized
INFO - 2019-07-01 14:59:14 --> Config Class Initialized
INFO - 2019-07-01 14:59:14 --> Loader Class Initialized
DEBUG - 2019-07-01 14:59:14 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 14:59:14 --> Helper loaded: url_helper
INFO - 2019-07-01 14:59:14 --> Helper loaded: inflector_helper
INFO - 2019-07-01 14:59:14 --> Helper loaded: string_helper
INFO - 2019-07-01 14:59:14 --> Helper loaded: array_helper
INFO - 2019-07-01 14:59:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 14:59:14 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 14:59:14 --> Database Driver Class Initialized
INFO - 2019-07-01 14:59:14 --> Controller Class Initialized
INFO - 2019-07-01 20:59:14 --> Helper loaded: language_helper
INFO - 2019-07-01 20:59:14 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 20:59:14 --> Model Class Initialized
INFO - 2019-07-01 20:59:14 --> Model Class Initialized
INFO - 2019-07-01 20:59:14 --> Model Class Initialized
INFO - 2019-07-01 20:59:14 --> Model Class Initialized
INFO - 2019-07-01 20:59:14 --> Helper loaded: form_helper
INFO - 2019-07-01 20:59:14 --> Form Validation Class Initialized
DEBUG - 2019-07-01 20:59:14 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 20:59:14 --> Model Class Initialized
INFO - 2019-07-01 20:59:14 --> Model Class Initialized
INFO - 2019-07-01 20:59:14 --> Final output sent to browser
DEBUG - 2019-07-01 20:59:14 --> Total execution time: 0.3413
INFO - 2019-07-01 15:02:24 --> Config Class Initialized
INFO - 2019-07-01 15:02:24 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:02:24 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:02:24 --> Utf8 Class Initialized
INFO - 2019-07-01 15:02:24 --> URI Class Initialized
INFO - 2019-07-01 15:02:24 --> Router Class Initialized
INFO - 2019-07-01 15:02:24 --> Output Class Initialized
INFO - 2019-07-01 15:02:24 --> Security Class Initialized
DEBUG - 2019-07-01 15:02:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:02:24 --> Input Class Initialized
INFO - 2019-07-01 15:02:24 --> Language Class Initialized
INFO - 2019-07-01 15:02:24 --> Language Class Initialized
INFO - 2019-07-01 15:02:24 --> Config Class Initialized
INFO - 2019-07-01 15:02:24 --> Loader Class Initialized
DEBUG - 2019-07-01 15:02:24 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:02:24 --> Helper loaded: url_helper
INFO - 2019-07-01 15:02:24 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:02:24 --> Helper loaded: string_helper
INFO - 2019-07-01 15:02:24 --> Helper loaded: array_helper
INFO - 2019-07-01 15:02:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:02:24 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:02:24 --> Database Driver Class Initialized
INFO - 2019-07-01 15:02:24 --> Controller Class Initialized
INFO - 2019-07-01 21:02:24 --> Helper loaded: language_helper
INFO - 2019-07-01 21:02:24 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:02:24 --> Model Class Initialized
INFO - 2019-07-01 21:02:24 --> Model Class Initialized
INFO - 2019-07-01 21:02:24 --> Model Class Initialized
INFO - 2019-07-01 21:02:24 --> Model Class Initialized
INFO - 2019-07-01 21:02:24 --> Helper loaded: form_helper
INFO - 2019-07-01 21:02:24 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:02:24 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:02:24 --> Model Class Initialized
INFO - 2019-07-01 21:02:24 --> Model Class Initialized
INFO - 2019-07-01 21:02:24 --> Final output sent to browser
DEBUG - 2019-07-01 21:02:24 --> Total execution time: 0.3709
INFO - 2019-07-01 15:02:56 --> Config Class Initialized
INFO - 2019-07-01 15:02:56 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:02:56 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:02:56 --> Utf8 Class Initialized
INFO - 2019-07-01 15:02:56 --> URI Class Initialized
INFO - 2019-07-01 15:02:56 --> Router Class Initialized
INFO - 2019-07-01 15:02:56 --> Output Class Initialized
INFO - 2019-07-01 15:02:56 --> Security Class Initialized
DEBUG - 2019-07-01 15:02:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:02:56 --> Input Class Initialized
INFO - 2019-07-01 15:02:56 --> Language Class Initialized
INFO - 2019-07-01 15:02:56 --> Language Class Initialized
INFO - 2019-07-01 15:02:56 --> Config Class Initialized
INFO - 2019-07-01 15:02:56 --> Loader Class Initialized
DEBUG - 2019-07-01 15:02:56 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:02:56 --> Helper loaded: url_helper
INFO - 2019-07-01 15:02:56 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:02:56 --> Helper loaded: string_helper
INFO - 2019-07-01 15:02:56 --> Helper loaded: array_helper
INFO - 2019-07-01 15:02:56 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:02:56 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:02:56 --> Database Driver Class Initialized
INFO - 2019-07-01 15:02:56 --> Controller Class Initialized
INFO - 2019-07-01 21:02:56 --> Helper loaded: language_helper
INFO - 2019-07-01 21:02:56 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:02:56 --> Model Class Initialized
INFO - 2019-07-01 21:02:56 --> Model Class Initialized
INFO - 2019-07-01 21:02:56 --> Model Class Initialized
INFO - 2019-07-01 21:02:56 --> Model Class Initialized
INFO - 2019-07-01 21:02:56 --> Helper loaded: form_helper
INFO - 2019-07-01 21:02:56 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:02:56 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:02:56 --> Model Class Initialized
INFO - 2019-07-01 21:02:56 --> Model Class Initialized
INFO - 2019-07-01 21:02:56 --> Final output sent to browser
DEBUG - 2019-07-01 21:02:56 --> Total execution time: 0.4296
INFO - 2019-07-01 15:03:20 --> Config Class Initialized
INFO - 2019-07-01 15:03:20 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:03:20 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:03:20 --> Utf8 Class Initialized
INFO - 2019-07-01 15:03:20 --> URI Class Initialized
INFO - 2019-07-01 15:03:20 --> Router Class Initialized
INFO - 2019-07-01 15:03:20 --> Output Class Initialized
INFO - 2019-07-01 15:03:20 --> Security Class Initialized
DEBUG - 2019-07-01 15:03:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:03:20 --> Input Class Initialized
INFO - 2019-07-01 15:03:20 --> Language Class Initialized
INFO - 2019-07-01 15:03:20 --> Language Class Initialized
INFO - 2019-07-01 15:03:20 --> Config Class Initialized
INFO - 2019-07-01 15:03:20 --> Loader Class Initialized
DEBUG - 2019-07-01 15:03:20 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:03:20 --> Helper loaded: url_helper
INFO - 2019-07-01 15:03:20 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:03:20 --> Helper loaded: string_helper
INFO - 2019-07-01 15:03:20 --> Helper loaded: array_helper
INFO - 2019-07-01 15:03:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:03:20 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:03:20 --> Database Driver Class Initialized
INFO - 2019-07-01 15:03:20 --> Controller Class Initialized
INFO - 2019-07-01 21:03:20 --> Helper loaded: language_helper
INFO - 2019-07-01 21:03:20 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:03:20 --> Model Class Initialized
INFO - 2019-07-01 21:03:20 --> Model Class Initialized
INFO - 2019-07-01 21:03:20 --> Model Class Initialized
INFO - 2019-07-01 21:03:20 --> Model Class Initialized
INFO - 2019-07-01 21:03:20 --> Helper loaded: form_helper
INFO - 2019-07-01 21:03:20 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:03:20 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:03:20 --> Model Class Initialized
INFO - 2019-07-01 21:03:20 --> Model Class Initialized
INFO - 2019-07-01 21:03:20 --> Final output sent to browser
DEBUG - 2019-07-01 21:03:20 --> Total execution time: 0.4469
INFO - 2019-07-01 15:03:33 --> Config Class Initialized
INFO - 2019-07-01 15:03:33 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:03:33 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:03:33 --> Utf8 Class Initialized
INFO - 2019-07-01 15:03:33 --> URI Class Initialized
INFO - 2019-07-01 15:03:33 --> Router Class Initialized
INFO - 2019-07-01 15:03:33 --> Output Class Initialized
INFO - 2019-07-01 15:03:33 --> Security Class Initialized
DEBUG - 2019-07-01 15:03:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:03:33 --> Input Class Initialized
INFO - 2019-07-01 15:03:33 --> Language Class Initialized
INFO - 2019-07-01 15:03:33 --> Language Class Initialized
INFO - 2019-07-01 15:03:33 --> Config Class Initialized
INFO - 2019-07-01 15:03:33 --> Loader Class Initialized
DEBUG - 2019-07-01 15:03:33 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:03:33 --> Helper loaded: url_helper
INFO - 2019-07-01 15:03:33 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:03:33 --> Helper loaded: string_helper
INFO - 2019-07-01 15:03:33 --> Helper loaded: array_helper
INFO - 2019-07-01 15:03:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:03:33 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:03:33 --> Database Driver Class Initialized
INFO - 2019-07-01 15:03:33 --> Controller Class Initialized
INFO - 2019-07-01 21:03:33 --> Helper loaded: language_helper
INFO - 2019-07-01 21:03:33 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:03:33 --> Model Class Initialized
INFO - 2019-07-01 21:03:33 --> Model Class Initialized
INFO - 2019-07-01 21:03:33 --> Model Class Initialized
INFO - 2019-07-01 21:03:33 --> Model Class Initialized
INFO - 2019-07-01 21:03:33 --> Helper loaded: form_helper
INFO - 2019-07-01 21:03:33 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:03:33 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:03:33 --> Model Class Initialized
INFO - 2019-07-01 21:03:33 --> Model Class Initialized
INFO - 2019-07-01 21:03:33 --> Final output sent to browser
DEBUG - 2019-07-01 21:03:33 --> Total execution time: 0.4358
INFO - 2019-07-01 15:07:01 --> Config Class Initialized
INFO - 2019-07-01 15:07:01 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:07:01 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:07:01 --> Utf8 Class Initialized
INFO - 2019-07-01 15:07:01 --> URI Class Initialized
INFO - 2019-07-01 15:07:01 --> Router Class Initialized
INFO - 2019-07-01 15:07:01 --> Output Class Initialized
INFO - 2019-07-01 15:07:01 --> Security Class Initialized
DEBUG - 2019-07-01 15:07:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:07:01 --> Input Class Initialized
INFO - 2019-07-01 15:07:01 --> Language Class Initialized
INFO - 2019-07-01 15:07:01 --> Language Class Initialized
INFO - 2019-07-01 15:07:01 --> Config Class Initialized
INFO - 2019-07-01 15:07:01 --> Loader Class Initialized
DEBUG - 2019-07-01 15:07:01 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:07:01 --> Helper loaded: url_helper
INFO - 2019-07-01 15:07:01 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:07:01 --> Helper loaded: string_helper
INFO - 2019-07-01 15:07:01 --> Helper loaded: array_helper
INFO - 2019-07-01 15:07:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:07:01 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:07:01 --> Database Driver Class Initialized
INFO - 2019-07-01 15:07:01 --> Controller Class Initialized
INFO - 2019-07-01 21:07:01 --> Helper loaded: language_helper
INFO - 2019-07-01 21:07:01 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:07:01 --> Model Class Initialized
INFO - 2019-07-01 21:07:01 --> Model Class Initialized
INFO - 2019-07-01 21:07:01 --> Model Class Initialized
INFO - 2019-07-01 21:07:01 --> Model Class Initialized
INFO - 2019-07-01 21:07:01 --> Helper loaded: form_helper
INFO - 2019-07-01 21:07:01 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:07:01 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:07:01 --> Model Class Initialized
INFO - 2019-07-01 21:07:01 --> Model Class Initialized
INFO - 2019-07-01 21:07:01 --> Final output sent to browser
DEBUG - 2019-07-01 21:07:01 --> Total execution time: 0.4769
INFO - 2019-07-01 15:07:11 --> Config Class Initialized
INFO - 2019-07-01 15:07:11 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:07:11 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:07:11 --> Utf8 Class Initialized
INFO - 2019-07-01 15:07:11 --> URI Class Initialized
INFO - 2019-07-01 15:07:11 --> Router Class Initialized
INFO - 2019-07-01 15:07:11 --> Output Class Initialized
INFO - 2019-07-01 15:07:11 --> Security Class Initialized
DEBUG - 2019-07-01 15:07:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:07:11 --> Input Class Initialized
INFO - 2019-07-01 15:07:11 --> Language Class Initialized
INFO - 2019-07-01 15:07:11 --> Language Class Initialized
INFO - 2019-07-01 15:07:11 --> Config Class Initialized
INFO - 2019-07-01 15:07:11 --> Loader Class Initialized
DEBUG - 2019-07-01 15:07:12 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:07:12 --> Helper loaded: url_helper
INFO - 2019-07-01 15:07:12 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:07:12 --> Helper loaded: string_helper
INFO - 2019-07-01 15:07:12 --> Helper loaded: array_helper
INFO - 2019-07-01 15:07:12 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:07:12 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:07:12 --> Database Driver Class Initialized
INFO - 2019-07-01 15:07:12 --> Controller Class Initialized
INFO - 2019-07-01 21:07:12 --> Helper loaded: language_helper
INFO - 2019-07-01 21:07:12 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:07:12 --> Model Class Initialized
INFO - 2019-07-01 21:07:12 --> Model Class Initialized
INFO - 2019-07-01 21:07:12 --> Model Class Initialized
INFO - 2019-07-01 21:07:12 --> Model Class Initialized
INFO - 2019-07-01 21:07:12 --> Helper loaded: form_helper
INFO - 2019-07-01 21:07:12 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:07:12 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:07:12 --> Model Class Initialized
INFO - 2019-07-01 21:07:12 --> Model Class Initialized
INFO - 2019-07-01 21:07:12 --> Final output sent to browser
DEBUG - 2019-07-01 21:07:12 --> Total execution time: 0.4545
INFO - 2019-07-01 15:07:13 --> Config Class Initialized
INFO - 2019-07-01 15:07:13 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:07:13 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:07:13 --> Utf8 Class Initialized
INFO - 2019-07-01 15:07:13 --> URI Class Initialized
INFO - 2019-07-01 15:07:13 --> Router Class Initialized
INFO - 2019-07-01 15:07:13 --> Output Class Initialized
INFO - 2019-07-01 15:07:13 --> Security Class Initialized
DEBUG - 2019-07-01 15:07:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:07:13 --> Input Class Initialized
INFO - 2019-07-01 15:07:13 --> Language Class Initialized
INFO - 2019-07-01 15:07:13 --> Language Class Initialized
INFO - 2019-07-01 15:07:13 --> Config Class Initialized
INFO - 2019-07-01 15:07:14 --> Loader Class Initialized
DEBUG - 2019-07-01 15:07:14 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:07:14 --> Helper loaded: url_helper
INFO - 2019-07-01 15:07:14 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:07:14 --> Helper loaded: string_helper
INFO - 2019-07-01 15:07:14 --> Helper loaded: array_helper
INFO - 2019-07-01 15:07:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:07:14 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:07:14 --> Database Driver Class Initialized
INFO - 2019-07-01 15:07:14 --> Controller Class Initialized
INFO - 2019-07-01 21:07:14 --> Helper loaded: language_helper
INFO - 2019-07-01 21:07:14 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:07:14 --> Model Class Initialized
INFO - 2019-07-01 21:07:14 --> Model Class Initialized
INFO - 2019-07-01 21:07:14 --> Model Class Initialized
INFO - 2019-07-01 21:07:14 --> Model Class Initialized
INFO - 2019-07-01 21:07:14 --> Model Class Initialized
INFO - 2019-07-01 21:07:14 --> Final output sent to browser
DEBUG - 2019-07-01 21:07:14 --> Total execution time: 0.3351
INFO - 2019-07-01 15:07:22 --> Config Class Initialized
INFO - 2019-07-01 15:07:22 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:07:22 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:07:22 --> Utf8 Class Initialized
INFO - 2019-07-01 15:07:22 --> URI Class Initialized
INFO - 2019-07-01 15:07:22 --> Router Class Initialized
INFO - 2019-07-01 15:07:22 --> Output Class Initialized
INFO - 2019-07-01 15:07:22 --> Security Class Initialized
DEBUG - 2019-07-01 15:07:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:07:22 --> Input Class Initialized
INFO - 2019-07-01 15:07:22 --> Language Class Initialized
INFO - 2019-07-01 15:07:22 --> Language Class Initialized
INFO - 2019-07-01 15:07:22 --> Config Class Initialized
INFO - 2019-07-01 15:07:22 --> Loader Class Initialized
DEBUG - 2019-07-01 15:07:23 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:07:23 --> Helper loaded: url_helper
INFO - 2019-07-01 15:07:23 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:07:23 --> Helper loaded: string_helper
INFO - 2019-07-01 15:07:23 --> Helper loaded: array_helper
INFO - 2019-07-01 15:07:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:07:23 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:07:23 --> Database Driver Class Initialized
INFO - 2019-07-01 15:07:23 --> Controller Class Initialized
INFO - 2019-07-01 21:07:23 --> Helper loaded: language_helper
INFO - 2019-07-01 21:07:23 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:07:23 --> Model Class Initialized
INFO - 2019-07-01 21:07:23 --> Model Class Initialized
INFO - 2019-07-01 21:07:23 --> Model Class Initialized
INFO - 2019-07-01 21:07:23 --> Model Class Initialized
INFO - 2019-07-01 21:07:23 --> Helper loaded: form_helper
INFO - 2019-07-01 21:07:23 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:07:23 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:07:23 --> Model Class Initialized
INFO - 2019-07-01 21:07:23 --> Model Class Initialized
ERROR - 2019-07-01 21:07:23 --> Severity: Notice --> Undefined index: resto_id C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 112
ERROR - 2019-07-01 21:07:23 --> Severity: Notice --> Undefined index: resto_id C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 115
ERROR - 2019-07-01 21:07:23 --> Query error: Unknown column 'order_number' in 'field list' - Invalid query: INSERT INTO `orders` (`customer_id`, `resto_id`, `order_number`, `created_at`, `updated_at`) VALUES ('1', NULL, '11561986443', '2019-07-01 21:07:23', '2019-07-01 21:07:23')
INFO - 2019-07-01 21:07:23 --> Language file loaded: language/english/db_lang.php
INFO - 2019-07-01 15:08:27 --> Config Class Initialized
INFO - 2019-07-01 15:08:27 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:08:27 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:08:27 --> Utf8 Class Initialized
INFO - 2019-07-01 15:08:27 --> URI Class Initialized
INFO - 2019-07-01 15:08:27 --> Router Class Initialized
INFO - 2019-07-01 15:08:27 --> Output Class Initialized
INFO - 2019-07-01 15:08:27 --> Security Class Initialized
DEBUG - 2019-07-01 15:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:08:27 --> Input Class Initialized
INFO - 2019-07-01 15:08:27 --> Language Class Initialized
INFO - 2019-07-01 15:08:27 --> Language Class Initialized
INFO - 2019-07-01 15:08:27 --> Config Class Initialized
INFO - 2019-07-01 15:08:27 --> Loader Class Initialized
DEBUG - 2019-07-01 15:08:27 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:08:27 --> Helper loaded: url_helper
INFO - 2019-07-01 15:08:27 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:08:27 --> Helper loaded: string_helper
INFO - 2019-07-01 15:08:27 --> Helper loaded: array_helper
INFO - 2019-07-01 15:08:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:08:27 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:08:27 --> Database Driver Class Initialized
INFO - 2019-07-01 15:08:27 --> Controller Class Initialized
INFO - 2019-07-01 21:08:27 --> Helper loaded: language_helper
INFO - 2019-07-01 21:08:27 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:08:27 --> Model Class Initialized
INFO - 2019-07-01 21:08:27 --> Model Class Initialized
INFO - 2019-07-01 21:08:27 --> Model Class Initialized
INFO - 2019-07-01 21:08:28 --> Model Class Initialized
INFO - 2019-07-01 21:08:28 --> Helper loaded: form_helper
INFO - 2019-07-01 21:08:28 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:08:28 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:08:28 --> Model Class Initialized
INFO - 2019-07-01 21:08:28 --> Model Class Initialized
INFO - 2019-07-01 21:08:28 --> Final output sent to browser
DEBUG - 2019-07-01 21:08:28 --> Total execution time: 1.0549
INFO - 2019-07-01 15:08:28 --> Config Class Initialized
INFO - 2019-07-01 15:08:28 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:08:28 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:08:28 --> Utf8 Class Initialized
INFO - 2019-07-01 15:08:28 --> URI Class Initialized
INFO - 2019-07-01 15:08:28 --> Router Class Initialized
INFO - 2019-07-01 15:08:28 --> Output Class Initialized
INFO - 2019-07-01 15:08:28 --> Security Class Initialized
DEBUG - 2019-07-01 15:08:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:08:28 --> Input Class Initialized
INFO - 2019-07-01 15:08:28 --> Language Class Initialized
INFO - 2019-07-01 15:08:28 --> Language Class Initialized
INFO - 2019-07-01 15:08:28 --> Config Class Initialized
INFO - 2019-07-01 15:08:28 --> Loader Class Initialized
DEBUG - 2019-07-01 15:08:28 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:08:28 --> Helper loaded: url_helper
INFO - 2019-07-01 15:08:28 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:08:28 --> Helper loaded: string_helper
INFO - 2019-07-01 15:08:28 --> Helper loaded: array_helper
INFO - 2019-07-01 15:08:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:08:28 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:08:28 --> Database Driver Class Initialized
INFO - 2019-07-01 15:08:28 --> Controller Class Initialized
INFO - 2019-07-01 21:08:28 --> Helper loaded: language_helper
INFO - 2019-07-01 21:08:29 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:08:29 --> Model Class Initialized
INFO - 2019-07-01 21:08:29 --> Model Class Initialized
INFO - 2019-07-01 21:08:29 --> Model Class Initialized
INFO - 2019-07-01 21:08:29 --> Model Class Initialized
INFO - 2019-07-01 21:08:29 --> Model Class Initialized
INFO - 2019-07-01 21:08:29 --> Final output sent to browser
DEBUG - 2019-07-01 21:08:29 --> Total execution time: 0.5606
INFO - 2019-07-01 15:08:36 --> Config Class Initialized
INFO - 2019-07-01 15:08:36 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:08:36 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:08:36 --> Utf8 Class Initialized
INFO - 2019-07-01 15:08:36 --> URI Class Initialized
INFO - 2019-07-01 15:08:36 --> Router Class Initialized
INFO - 2019-07-01 15:08:36 --> Output Class Initialized
INFO - 2019-07-01 15:08:36 --> Security Class Initialized
DEBUG - 2019-07-01 15:08:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:08:36 --> Input Class Initialized
INFO - 2019-07-01 15:08:36 --> Language Class Initialized
INFO - 2019-07-01 15:08:36 --> Language Class Initialized
INFO - 2019-07-01 15:08:36 --> Config Class Initialized
INFO - 2019-07-01 15:08:36 --> Loader Class Initialized
DEBUG - 2019-07-01 15:08:36 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:08:36 --> Helper loaded: url_helper
INFO - 2019-07-01 15:08:36 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:08:36 --> Helper loaded: string_helper
INFO - 2019-07-01 15:08:36 --> Helper loaded: array_helper
INFO - 2019-07-01 15:08:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:08:37 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:08:37 --> Database Driver Class Initialized
INFO - 2019-07-01 15:08:37 --> Controller Class Initialized
INFO - 2019-07-01 21:08:37 --> Helper loaded: language_helper
INFO - 2019-07-01 21:08:37 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:08:37 --> Model Class Initialized
INFO - 2019-07-01 21:08:37 --> Model Class Initialized
INFO - 2019-07-01 21:08:37 --> Model Class Initialized
INFO - 2019-07-01 21:08:37 --> Model Class Initialized
INFO - 2019-07-01 21:08:37 --> Helper loaded: form_helper
INFO - 2019-07-01 21:08:37 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:08:37 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:08:37 --> Model Class Initialized
INFO - 2019-07-01 21:08:37 --> Model Class Initialized
ERROR - 2019-07-01 21:08:37 --> Severity: Notice --> Undefined index: resto_id C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 112
ERROR - 2019-07-01 21:08:37 --> Severity: Notice --> Undefined index: resto_id C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 115
ERROR - 2019-07-01 21:08:37 --> Query error: Unknown column 'order_number' in 'field list' - Invalid query: INSERT INTO `orders` (`customer_id`, `resto_id`, `order_number`, `created_at`, `updated_at`) VALUES ('1', NULL, '11561986517', '2019-07-01 21:08:37', '2019-07-01 21:08:37')
INFO - 2019-07-01 21:08:37 --> Language file loaded: language/english/db_lang.php
INFO - 2019-07-01 15:10:00 --> Config Class Initialized
INFO - 2019-07-01 15:10:00 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:10:00 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:10:00 --> Utf8 Class Initialized
INFO - 2019-07-01 15:10:00 --> URI Class Initialized
INFO - 2019-07-01 15:10:00 --> Router Class Initialized
INFO - 2019-07-01 15:10:00 --> Output Class Initialized
INFO - 2019-07-01 15:10:00 --> Security Class Initialized
DEBUG - 2019-07-01 15:10:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:10:00 --> Input Class Initialized
INFO - 2019-07-01 15:10:00 --> Language Class Initialized
INFO - 2019-07-01 15:10:00 --> Language Class Initialized
INFO - 2019-07-01 15:10:00 --> Config Class Initialized
INFO - 2019-07-01 15:10:00 --> Loader Class Initialized
DEBUG - 2019-07-01 15:10:00 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:10:00 --> Helper loaded: url_helper
INFO - 2019-07-01 15:10:00 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:10:00 --> Helper loaded: string_helper
INFO - 2019-07-01 15:10:00 --> Helper loaded: array_helper
INFO - 2019-07-01 15:10:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:10:00 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:10:00 --> Database Driver Class Initialized
INFO - 2019-07-01 15:10:00 --> Controller Class Initialized
INFO - 2019-07-01 21:10:00 --> Helper loaded: language_helper
INFO - 2019-07-01 21:10:00 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:10:00 --> Model Class Initialized
INFO - 2019-07-01 21:10:00 --> Model Class Initialized
INFO - 2019-07-01 21:10:00 --> Model Class Initialized
INFO - 2019-07-01 21:10:00 --> Model Class Initialized
INFO - 2019-07-01 21:10:00 --> Helper loaded: form_helper
INFO - 2019-07-01 21:10:00 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:10:00 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:10:00 --> Model Class Initialized
INFO - 2019-07-01 21:10:00 --> Model Class Initialized
INFO - 2019-07-01 21:10:00 --> Final output sent to browser
DEBUG - 2019-07-01 21:10:00 --> Total execution time: 0.6972
INFO - 2019-07-01 15:10:03 --> Config Class Initialized
INFO - 2019-07-01 15:10:03 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:10:03 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:10:03 --> Utf8 Class Initialized
INFO - 2019-07-01 15:10:03 --> URI Class Initialized
INFO - 2019-07-01 15:10:03 --> Router Class Initialized
INFO - 2019-07-01 15:10:03 --> Output Class Initialized
INFO - 2019-07-01 15:10:03 --> Security Class Initialized
DEBUG - 2019-07-01 15:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:10:03 --> Input Class Initialized
INFO - 2019-07-01 15:10:03 --> Language Class Initialized
INFO - 2019-07-01 15:10:03 --> Language Class Initialized
INFO - 2019-07-01 15:10:03 --> Config Class Initialized
INFO - 2019-07-01 15:10:03 --> Loader Class Initialized
DEBUG - 2019-07-01 15:10:03 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:10:03 --> Helper loaded: url_helper
INFO - 2019-07-01 15:10:03 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:10:03 --> Helper loaded: string_helper
INFO - 2019-07-01 15:10:03 --> Helper loaded: array_helper
INFO - 2019-07-01 15:10:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:10:03 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:10:03 --> Database Driver Class Initialized
INFO - 2019-07-01 15:10:03 --> Controller Class Initialized
INFO - 2019-07-01 21:10:03 --> Helper loaded: language_helper
INFO - 2019-07-01 21:10:03 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:10:03 --> Model Class Initialized
INFO - 2019-07-01 21:10:03 --> Model Class Initialized
INFO - 2019-07-01 21:10:04 --> Model Class Initialized
INFO - 2019-07-01 21:10:04 --> Model Class Initialized
INFO - 2019-07-01 21:10:04 --> Helper loaded: form_helper
INFO - 2019-07-01 21:10:04 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:10:04 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:10:04 --> Model Class Initialized
INFO - 2019-07-01 21:10:04 --> Model Class Initialized
INFO - 2019-07-01 21:10:04 --> Final output sent to browser
DEBUG - 2019-07-01 21:10:04 --> Total execution time: 0.7558
INFO - 2019-07-01 15:10:05 --> Config Class Initialized
INFO - 2019-07-01 15:10:05 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:10:05 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:10:05 --> Utf8 Class Initialized
INFO - 2019-07-01 15:10:05 --> URI Class Initialized
INFO - 2019-07-01 15:10:05 --> Router Class Initialized
INFO - 2019-07-01 15:10:05 --> Output Class Initialized
INFO - 2019-07-01 15:10:05 --> Security Class Initialized
DEBUG - 2019-07-01 15:10:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:10:05 --> Input Class Initialized
INFO - 2019-07-01 15:10:05 --> Language Class Initialized
INFO - 2019-07-01 15:10:05 --> Language Class Initialized
INFO - 2019-07-01 15:10:05 --> Config Class Initialized
INFO - 2019-07-01 15:10:05 --> Loader Class Initialized
DEBUG - 2019-07-01 15:10:05 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:10:05 --> Helper loaded: url_helper
INFO - 2019-07-01 15:10:05 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:10:05 --> Helper loaded: string_helper
INFO - 2019-07-01 15:10:05 --> Helper loaded: array_helper
INFO - 2019-07-01 15:10:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:10:05 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:10:05 --> Database Driver Class Initialized
INFO - 2019-07-01 15:10:05 --> Controller Class Initialized
INFO - 2019-07-01 21:10:05 --> Helper loaded: language_helper
INFO - 2019-07-01 21:10:05 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:10:05 --> Model Class Initialized
INFO - 2019-07-01 21:10:05 --> Model Class Initialized
INFO - 2019-07-01 21:10:05 --> Model Class Initialized
INFO - 2019-07-01 21:10:05 --> Model Class Initialized
INFO - 2019-07-01 21:10:05 --> Helper loaded: form_helper
INFO - 2019-07-01 21:10:05 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:10:05 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:10:05 --> Model Class Initialized
INFO - 2019-07-01 21:10:05 --> Model Class Initialized
INFO - 2019-07-01 21:10:05 --> Final output sent to browser
DEBUG - 2019-07-01 21:10:05 --> Total execution time: 0.6246
INFO - 2019-07-01 15:10:06 --> Config Class Initialized
INFO - 2019-07-01 15:10:06 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:10:06 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:10:06 --> Utf8 Class Initialized
INFO - 2019-07-01 15:10:06 --> URI Class Initialized
INFO - 2019-07-01 15:10:06 --> Router Class Initialized
INFO - 2019-07-01 15:10:06 --> Output Class Initialized
INFO - 2019-07-01 15:10:06 --> Security Class Initialized
DEBUG - 2019-07-01 15:10:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:10:06 --> Input Class Initialized
INFO - 2019-07-01 15:10:06 --> Language Class Initialized
INFO - 2019-07-01 15:10:06 --> Language Class Initialized
INFO - 2019-07-01 15:10:06 --> Config Class Initialized
INFO - 2019-07-01 15:10:06 --> Loader Class Initialized
DEBUG - 2019-07-01 15:10:06 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:10:06 --> Helper loaded: url_helper
INFO - 2019-07-01 15:10:06 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:10:06 --> Helper loaded: string_helper
INFO - 2019-07-01 15:10:06 --> Helper loaded: array_helper
INFO - 2019-07-01 15:10:06 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:10:07 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:10:07 --> Database Driver Class Initialized
INFO - 2019-07-01 15:10:07 --> Controller Class Initialized
INFO - 2019-07-01 21:10:07 --> Helper loaded: language_helper
INFO - 2019-07-01 21:10:07 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:10:07 --> Model Class Initialized
INFO - 2019-07-01 21:10:07 --> Model Class Initialized
INFO - 2019-07-01 21:10:07 --> Model Class Initialized
INFO - 2019-07-01 21:10:07 --> Model Class Initialized
INFO - 2019-07-01 21:10:07 --> Model Class Initialized
INFO - 2019-07-01 21:10:07 --> Final output sent to browser
DEBUG - 2019-07-01 21:10:07 --> Total execution time: 0.5434
INFO - 2019-07-01 15:11:11 --> Config Class Initialized
INFO - 2019-07-01 15:11:11 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:11:11 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:11:11 --> Utf8 Class Initialized
INFO - 2019-07-01 15:11:11 --> URI Class Initialized
INFO - 2019-07-01 15:11:11 --> Router Class Initialized
INFO - 2019-07-01 15:11:11 --> Output Class Initialized
INFO - 2019-07-01 15:11:11 --> Security Class Initialized
DEBUG - 2019-07-01 15:11:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:11:11 --> Input Class Initialized
INFO - 2019-07-01 15:11:11 --> Language Class Initialized
INFO - 2019-07-01 15:11:11 --> Language Class Initialized
INFO - 2019-07-01 15:11:11 --> Config Class Initialized
INFO - 2019-07-01 15:11:11 --> Loader Class Initialized
DEBUG - 2019-07-01 15:11:11 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:11:11 --> Helper loaded: url_helper
INFO - 2019-07-01 15:11:11 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:11:11 --> Helper loaded: string_helper
INFO - 2019-07-01 15:11:11 --> Helper loaded: array_helper
INFO - 2019-07-01 15:11:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:11:11 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:11:11 --> Database Driver Class Initialized
INFO - 2019-07-01 15:11:11 --> Controller Class Initialized
INFO - 2019-07-01 21:11:11 --> Helper loaded: language_helper
INFO - 2019-07-01 21:11:11 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:11:11 --> Model Class Initialized
INFO - 2019-07-01 21:11:11 --> Model Class Initialized
INFO - 2019-07-01 21:11:11 --> Model Class Initialized
INFO - 2019-07-01 21:11:11 --> Model Class Initialized
INFO - 2019-07-01 21:11:11 --> Helper loaded: form_helper
INFO - 2019-07-01 21:11:11 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:11:11 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:11:11 --> Model Class Initialized
INFO - 2019-07-01 21:11:11 --> Model Class Initialized
INFO - 2019-07-01 21:11:11 --> Final output sent to browser
DEBUG - 2019-07-01 21:11:11 --> Total execution time: 0.4034
INFO - 2019-07-01 15:11:12 --> Config Class Initialized
INFO - 2019-07-01 15:11:12 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:11:12 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:11:12 --> Utf8 Class Initialized
INFO - 2019-07-01 15:11:12 --> URI Class Initialized
INFO - 2019-07-01 15:11:12 --> Router Class Initialized
INFO - 2019-07-01 15:11:12 --> Output Class Initialized
INFO - 2019-07-01 15:11:12 --> Security Class Initialized
DEBUG - 2019-07-01 15:11:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:11:12 --> Input Class Initialized
INFO - 2019-07-01 15:11:12 --> Language Class Initialized
INFO - 2019-07-01 15:11:12 --> Language Class Initialized
INFO - 2019-07-01 15:11:12 --> Config Class Initialized
INFO - 2019-07-01 15:11:12 --> Loader Class Initialized
DEBUG - 2019-07-01 15:11:12 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:11:12 --> Helper loaded: url_helper
INFO - 2019-07-01 15:11:12 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:11:12 --> Helper loaded: string_helper
INFO - 2019-07-01 15:11:12 --> Helper loaded: array_helper
INFO - 2019-07-01 15:11:12 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:11:12 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:11:12 --> Database Driver Class Initialized
INFO - 2019-07-01 15:11:12 --> Controller Class Initialized
INFO - 2019-07-01 21:11:12 --> Helper loaded: language_helper
INFO - 2019-07-01 21:11:12 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:11:12 --> Model Class Initialized
INFO - 2019-07-01 21:11:12 --> Model Class Initialized
INFO - 2019-07-01 21:11:12 --> Model Class Initialized
INFO - 2019-07-01 21:11:12 --> Model Class Initialized
INFO - 2019-07-01 21:11:12 --> Model Class Initialized
INFO - 2019-07-01 21:11:12 --> Final output sent to browser
DEBUG - 2019-07-01 21:11:12 --> Total execution time: 0.3401
INFO - 2019-07-01 15:11:13 --> Config Class Initialized
INFO - 2019-07-01 15:11:13 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:11:14 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:11:14 --> Utf8 Class Initialized
INFO - 2019-07-01 15:11:14 --> URI Class Initialized
INFO - 2019-07-01 15:11:14 --> Router Class Initialized
INFO - 2019-07-01 15:11:14 --> Output Class Initialized
INFO - 2019-07-01 15:11:14 --> Security Class Initialized
DEBUG - 2019-07-01 15:11:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:11:14 --> Input Class Initialized
INFO - 2019-07-01 15:11:14 --> Language Class Initialized
INFO - 2019-07-01 15:11:14 --> Language Class Initialized
INFO - 2019-07-01 15:11:14 --> Config Class Initialized
INFO - 2019-07-01 15:11:14 --> Loader Class Initialized
DEBUG - 2019-07-01 15:11:14 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:11:14 --> Helper loaded: url_helper
INFO - 2019-07-01 15:11:14 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:11:14 --> Helper loaded: string_helper
INFO - 2019-07-01 15:11:14 --> Helper loaded: array_helper
INFO - 2019-07-01 15:11:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:11:14 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:11:14 --> Database Driver Class Initialized
INFO - 2019-07-01 15:11:14 --> Controller Class Initialized
INFO - 2019-07-01 21:11:14 --> Helper loaded: language_helper
INFO - 2019-07-01 21:11:14 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:11:14 --> Model Class Initialized
INFO - 2019-07-01 21:11:14 --> Model Class Initialized
INFO - 2019-07-01 21:11:14 --> Model Class Initialized
INFO - 2019-07-01 21:11:14 --> Model Class Initialized
INFO - 2019-07-01 21:11:14 --> Helper loaded: form_helper
INFO - 2019-07-01 21:11:14 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:11:14 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:11:14 --> Model Class Initialized
INFO - 2019-07-01 21:11:14 --> Model Class Initialized
INFO - 2019-07-01 21:11:14 --> Final output sent to browser
DEBUG - 2019-07-01 21:11:14 --> Total execution time: 0.4473
INFO - 2019-07-01 15:11:15 --> Config Class Initialized
INFO - 2019-07-01 15:11:15 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:11:15 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:11:15 --> Utf8 Class Initialized
INFO - 2019-07-01 15:11:15 --> URI Class Initialized
INFO - 2019-07-01 15:11:15 --> Router Class Initialized
INFO - 2019-07-01 15:11:15 --> Output Class Initialized
INFO - 2019-07-01 15:11:15 --> Security Class Initialized
DEBUG - 2019-07-01 15:11:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:11:15 --> Input Class Initialized
INFO - 2019-07-01 15:11:15 --> Language Class Initialized
INFO - 2019-07-01 15:11:15 --> Language Class Initialized
INFO - 2019-07-01 15:11:15 --> Config Class Initialized
INFO - 2019-07-01 15:11:15 --> Loader Class Initialized
DEBUG - 2019-07-01 15:11:15 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:11:15 --> Helper loaded: url_helper
INFO - 2019-07-01 15:11:15 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:11:15 --> Helper loaded: string_helper
INFO - 2019-07-01 15:11:15 --> Helper loaded: array_helper
INFO - 2019-07-01 15:11:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:11:15 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:11:15 --> Database Driver Class Initialized
INFO - 2019-07-01 15:11:15 --> Controller Class Initialized
INFO - 2019-07-01 21:11:15 --> Helper loaded: language_helper
INFO - 2019-07-01 21:11:15 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:11:15 --> Model Class Initialized
INFO - 2019-07-01 21:11:15 --> Model Class Initialized
INFO - 2019-07-01 21:11:15 --> Model Class Initialized
INFO - 2019-07-01 21:11:15 --> Model Class Initialized
INFO - 2019-07-01 21:11:15 --> Model Class Initialized
INFO - 2019-07-01 21:11:15 --> Final output sent to browser
DEBUG - 2019-07-01 21:11:15 --> Total execution time: 0.3520
INFO - 2019-07-01 15:11:38 --> Config Class Initialized
INFO - 2019-07-01 15:11:38 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:11:38 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:11:38 --> Utf8 Class Initialized
INFO - 2019-07-01 15:11:38 --> URI Class Initialized
INFO - 2019-07-01 15:11:38 --> Router Class Initialized
INFO - 2019-07-01 15:11:38 --> Output Class Initialized
INFO - 2019-07-01 15:11:38 --> Security Class Initialized
DEBUG - 2019-07-01 15:11:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:11:38 --> Input Class Initialized
INFO - 2019-07-01 15:11:38 --> Language Class Initialized
INFO - 2019-07-01 15:11:38 --> Language Class Initialized
INFO - 2019-07-01 15:11:38 --> Config Class Initialized
INFO - 2019-07-01 15:11:38 --> Loader Class Initialized
DEBUG - 2019-07-01 15:11:38 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:11:38 --> Helper loaded: url_helper
INFO - 2019-07-01 15:11:38 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:11:38 --> Helper loaded: string_helper
INFO - 2019-07-01 15:11:38 --> Helper loaded: array_helper
INFO - 2019-07-01 15:11:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:11:38 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:11:38 --> Database Driver Class Initialized
INFO - 2019-07-01 15:11:38 --> Controller Class Initialized
INFO - 2019-07-01 21:11:38 --> Helper loaded: language_helper
INFO - 2019-07-01 21:11:38 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:11:38 --> Model Class Initialized
INFO - 2019-07-01 21:11:38 --> Model Class Initialized
INFO - 2019-07-01 21:11:38 --> Model Class Initialized
INFO - 2019-07-01 21:11:38 --> Model Class Initialized
INFO - 2019-07-01 21:11:38 --> Helper loaded: form_helper
INFO - 2019-07-01 21:11:38 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:11:38 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:11:38 --> Model Class Initialized
INFO - 2019-07-01 21:11:38 --> Model Class Initialized
INFO - 2019-07-01 21:11:38 --> Final output sent to browser
DEBUG - 2019-07-01 21:11:38 --> Total execution time: 0.5591
INFO - 2019-07-01 15:11:40 --> Config Class Initialized
INFO - 2019-07-01 15:11:40 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:11:40 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:11:40 --> Utf8 Class Initialized
INFO - 2019-07-01 15:11:40 --> URI Class Initialized
INFO - 2019-07-01 15:11:40 --> Router Class Initialized
INFO - 2019-07-01 15:11:40 --> Output Class Initialized
INFO - 2019-07-01 15:11:40 --> Security Class Initialized
DEBUG - 2019-07-01 15:11:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:11:40 --> Input Class Initialized
INFO - 2019-07-01 15:11:40 --> Language Class Initialized
INFO - 2019-07-01 15:11:40 --> Language Class Initialized
INFO - 2019-07-01 15:11:40 --> Config Class Initialized
INFO - 2019-07-01 15:11:40 --> Loader Class Initialized
DEBUG - 2019-07-01 15:11:40 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:11:40 --> Helper loaded: url_helper
INFO - 2019-07-01 15:11:40 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:11:40 --> Helper loaded: string_helper
INFO - 2019-07-01 15:11:40 --> Helper loaded: array_helper
INFO - 2019-07-01 15:11:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:11:40 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:11:40 --> Database Driver Class Initialized
INFO - 2019-07-01 15:11:40 --> Controller Class Initialized
INFO - 2019-07-01 21:11:40 --> Helper loaded: language_helper
INFO - 2019-07-01 21:11:40 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:11:40 --> Model Class Initialized
INFO - 2019-07-01 21:11:40 --> Model Class Initialized
INFO - 2019-07-01 21:11:40 --> Model Class Initialized
INFO - 2019-07-01 21:11:40 --> Model Class Initialized
INFO - 2019-07-01 21:11:40 --> Helper loaded: form_helper
INFO - 2019-07-01 21:11:41 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:11:41 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:11:41 --> Model Class Initialized
INFO - 2019-07-01 21:11:41 --> Model Class Initialized
INFO - 2019-07-01 21:11:41 --> Final output sent to browser
DEBUG - 2019-07-01 21:11:41 --> Total execution time: 0.3847
INFO - 2019-07-01 15:11:44 --> Config Class Initialized
INFO - 2019-07-01 15:11:44 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:11:44 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:11:44 --> Utf8 Class Initialized
INFO - 2019-07-01 15:11:44 --> URI Class Initialized
INFO - 2019-07-01 15:11:44 --> Router Class Initialized
INFO - 2019-07-01 15:11:44 --> Output Class Initialized
INFO - 2019-07-01 15:11:44 --> Security Class Initialized
DEBUG - 2019-07-01 15:11:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:11:44 --> Input Class Initialized
INFO - 2019-07-01 15:11:44 --> Language Class Initialized
INFO - 2019-07-01 15:11:44 --> Language Class Initialized
INFO - 2019-07-01 15:11:44 --> Config Class Initialized
INFO - 2019-07-01 15:11:44 --> Loader Class Initialized
DEBUG - 2019-07-01 15:11:44 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:11:44 --> Helper loaded: url_helper
INFO - 2019-07-01 15:11:44 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:11:44 --> Helper loaded: string_helper
INFO - 2019-07-01 15:11:44 --> Helper loaded: array_helper
INFO - 2019-07-01 15:11:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:11:44 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:11:44 --> Database Driver Class Initialized
INFO - 2019-07-01 15:11:44 --> Controller Class Initialized
INFO - 2019-07-01 21:11:44 --> Helper loaded: language_helper
INFO - 2019-07-01 21:11:44 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:11:44 --> Model Class Initialized
INFO - 2019-07-01 21:11:44 --> Model Class Initialized
INFO - 2019-07-01 21:11:44 --> Model Class Initialized
INFO - 2019-07-01 21:11:44 --> Model Class Initialized
INFO - 2019-07-01 21:11:44 --> Helper loaded: form_helper
INFO - 2019-07-01 21:11:44 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:11:44 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:11:44 --> Model Class Initialized
INFO - 2019-07-01 21:11:44 --> Model Class Initialized
INFO - 2019-07-01 21:11:44 --> Final output sent to browser
DEBUG - 2019-07-01 21:11:44 --> Total execution time: 0.4245
INFO - 2019-07-01 15:11:45 --> Config Class Initialized
INFO - 2019-07-01 15:11:45 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:11:45 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:11:45 --> Utf8 Class Initialized
INFO - 2019-07-01 15:11:45 --> URI Class Initialized
INFO - 2019-07-01 15:11:45 --> Router Class Initialized
INFO - 2019-07-01 15:11:45 --> Output Class Initialized
INFO - 2019-07-01 15:11:45 --> Security Class Initialized
DEBUG - 2019-07-01 15:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:11:45 --> Input Class Initialized
INFO - 2019-07-01 15:11:45 --> Language Class Initialized
INFO - 2019-07-01 15:11:45 --> Language Class Initialized
INFO - 2019-07-01 15:11:45 --> Config Class Initialized
INFO - 2019-07-01 15:11:45 --> Loader Class Initialized
DEBUG - 2019-07-01 15:11:45 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:11:45 --> Helper loaded: url_helper
INFO - 2019-07-01 15:11:45 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:11:45 --> Helper loaded: string_helper
INFO - 2019-07-01 15:11:45 --> Helper loaded: array_helper
INFO - 2019-07-01 15:11:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:11:45 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:11:45 --> Database Driver Class Initialized
INFO - 2019-07-01 15:11:45 --> Controller Class Initialized
INFO - 2019-07-01 21:11:45 --> Helper loaded: language_helper
INFO - 2019-07-01 21:11:45 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:11:45 --> Model Class Initialized
INFO - 2019-07-01 21:11:45 --> Model Class Initialized
INFO - 2019-07-01 21:11:46 --> Model Class Initialized
INFO - 2019-07-01 21:11:46 --> Model Class Initialized
INFO - 2019-07-01 21:11:46 --> Model Class Initialized
INFO - 2019-07-01 21:11:46 --> Final output sent to browser
DEBUG - 2019-07-01 21:11:46 --> Total execution time: 0.3261
INFO - 2019-07-01 15:12:02 --> Config Class Initialized
INFO - 2019-07-01 15:12:02 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:12:02 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:12:02 --> Utf8 Class Initialized
INFO - 2019-07-01 15:12:02 --> URI Class Initialized
INFO - 2019-07-01 15:12:02 --> Router Class Initialized
INFO - 2019-07-01 15:12:02 --> Output Class Initialized
INFO - 2019-07-01 15:12:02 --> Security Class Initialized
DEBUG - 2019-07-01 15:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:12:02 --> Input Class Initialized
INFO - 2019-07-01 15:12:02 --> Language Class Initialized
INFO - 2019-07-01 15:12:02 --> Language Class Initialized
INFO - 2019-07-01 15:12:02 --> Config Class Initialized
INFO - 2019-07-01 15:12:02 --> Loader Class Initialized
DEBUG - 2019-07-01 15:12:02 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:12:02 --> Helper loaded: url_helper
INFO - 2019-07-01 15:12:02 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:12:02 --> Helper loaded: string_helper
INFO - 2019-07-01 15:12:02 --> Helper loaded: array_helper
INFO - 2019-07-01 15:12:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:12:02 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:12:02 --> Config Class Initialized
INFO - 2019-07-01 15:12:02 --> Hooks Class Initialized
INFO - 2019-07-01 15:12:02 --> Database Driver Class Initialized
DEBUG - 2019-07-01 15:12:02 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:12:02 --> Utf8 Class Initialized
INFO - 2019-07-01 15:12:02 --> Controller Class Initialized
INFO - 2019-07-01 15:12:02 --> URI Class Initialized
INFO - 2019-07-01 21:12:02 --> Helper loaded: language_helper
INFO - 2019-07-01 15:12:02 --> Router Class Initialized
INFO - 2019-07-01 21:12:02 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 15:12:02 --> Output Class Initialized
INFO - 2019-07-01 15:12:02 --> Security Class Initialized
INFO - 2019-07-01 21:12:02 --> Model Class Initialized
INFO - 2019-07-01 21:12:02 --> Model Class Initialized
DEBUG - 2019-07-01 15:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 21:12:03 --> Model Class Initialized
INFO - 2019-07-01 15:12:03 --> Input Class Initialized
INFO - 2019-07-01 15:12:03 --> Language Class Initialized
INFO - 2019-07-01 21:12:03 --> Model Class Initialized
INFO - 2019-07-01 15:12:03 --> Language Class Initialized
INFO - 2019-07-01 21:12:03 --> Helper loaded: form_helper
INFO - 2019-07-01 15:12:03 --> Config Class Initialized
INFO - 2019-07-01 15:12:03 --> Loader Class Initialized
INFO - 2019-07-01 21:12:03 --> Form Validation Class Initialized
DEBUG - 2019-07-01 15:12:03 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-01 21:12:03 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 15:12:03 --> Helper loaded: url_helper
INFO - 2019-07-01 21:12:03 --> Model Class Initialized
INFO - 2019-07-01 15:12:03 --> Helper loaded: inflector_helper
INFO - 2019-07-01 21:12:03 --> Model Class Initialized
INFO - 2019-07-01 15:12:03 --> Helper loaded: string_helper
INFO - 2019-07-01 21:12:03 --> Final output sent to browser
INFO - 2019-07-01 15:12:03 --> Helper loaded: array_helper
DEBUG - 2019-07-01 21:12:03 --> Total execution time: 1.0648
INFO - 2019-07-01 15:12:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:12:03 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:12:03 --> Database Driver Class Initialized
INFO - 2019-07-01 15:12:03 --> Controller Class Initialized
INFO - 2019-07-01 21:12:03 --> Helper loaded: language_helper
INFO - 2019-07-01 21:12:03 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:12:03 --> Model Class Initialized
INFO - 2019-07-01 21:12:03 --> Model Class Initialized
INFO - 2019-07-01 21:12:03 --> Model Class Initialized
INFO - 2019-07-01 21:12:03 --> Model Class Initialized
INFO - 2019-07-01 21:12:03 --> Helper loaded: form_helper
INFO - 2019-07-01 21:12:03 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:12:03 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:12:03 --> Model Class Initialized
INFO - 2019-07-01 21:12:03 --> Model Class Initialized
INFO - 2019-07-01 21:12:03 --> Final output sent to browser
DEBUG - 2019-07-01 21:12:03 --> Total execution time: 0.8711
INFO - 2019-07-01 15:12:04 --> Config Class Initialized
INFO - 2019-07-01 15:12:04 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:12:04 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:12:04 --> Utf8 Class Initialized
INFO - 2019-07-01 15:12:04 --> URI Class Initialized
INFO - 2019-07-01 15:12:04 --> Router Class Initialized
INFO - 2019-07-01 15:12:04 --> Output Class Initialized
INFO - 2019-07-01 15:12:04 --> Security Class Initialized
DEBUG - 2019-07-01 15:12:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:12:04 --> Input Class Initialized
INFO - 2019-07-01 15:12:04 --> Language Class Initialized
INFO - 2019-07-01 15:12:04 --> Language Class Initialized
INFO - 2019-07-01 15:12:04 --> Config Class Initialized
INFO - 2019-07-01 15:12:04 --> Loader Class Initialized
DEBUG - 2019-07-01 15:12:04 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:12:04 --> Helper loaded: url_helper
INFO - 2019-07-01 15:12:04 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:12:04 --> Helper loaded: string_helper
INFO - 2019-07-01 15:12:04 --> Helper loaded: array_helper
INFO - 2019-07-01 15:12:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:12:04 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:12:04 --> Database Driver Class Initialized
INFO - 2019-07-01 15:12:04 --> Controller Class Initialized
INFO - 2019-07-01 21:12:04 --> Helper loaded: language_helper
INFO - 2019-07-01 21:12:04 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:12:04 --> Model Class Initialized
INFO - 2019-07-01 21:12:04 --> Model Class Initialized
INFO - 2019-07-01 21:12:04 --> Model Class Initialized
INFO - 2019-07-01 21:12:04 --> Model Class Initialized
INFO - 2019-07-01 21:12:04 --> Model Class Initialized
INFO - 2019-07-01 21:12:04 --> Final output sent to browser
DEBUG - 2019-07-01 21:12:04 --> Total execution time: 0.5846
INFO - 2019-07-01 15:12:09 --> Config Class Initialized
INFO - 2019-07-01 15:12:09 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:12:09 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:12:09 --> Utf8 Class Initialized
INFO - 2019-07-01 15:12:09 --> URI Class Initialized
INFO - 2019-07-01 15:12:10 --> Router Class Initialized
INFO - 2019-07-01 15:12:10 --> Output Class Initialized
INFO - 2019-07-01 15:12:10 --> Security Class Initialized
DEBUG - 2019-07-01 15:12:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:12:10 --> Input Class Initialized
INFO - 2019-07-01 15:12:10 --> Language Class Initialized
INFO - 2019-07-01 15:12:10 --> Language Class Initialized
INFO - 2019-07-01 15:12:10 --> Config Class Initialized
INFO - 2019-07-01 15:12:10 --> Loader Class Initialized
DEBUG - 2019-07-01 15:12:10 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:12:10 --> Helper loaded: url_helper
INFO - 2019-07-01 15:12:10 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:12:10 --> Helper loaded: string_helper
INFO - 2019-07-01 15:12:10 --> Helper loaded: array_helper
INFO - 2019-07-01 15:12:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:12:10 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:12:10 --> Database Driver Class Initialized
INFO - 2019-07-01 15:12:10 --> Controller Class Initialized
INFO - 2019-07-01 21:12:10 --> Helper loaded: language_helper
INFO - 2019-07-01 21:12:10 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:12:10 --> Model Class Initialized
INFO - 2019-07-01 21:12:10 --> Model Class Initialized
INFO - 2019-07-01 21:12:10 --> Model Class Initialized
INFO - 2019-07-01 21:12:10 --> Model Class Initialized
INFO - 2019-07-01 21:12:10 --> Helper loaded: form_helper
INFO - 2019-07-01 21:12:10 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:12:10 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:12:10 --> Model Class Initialized
INFO - 2019-07-01 21:12:10 --> Model Class Initialized
INFO - 2019-07-01 21:12:10 --> Final output sent to browser
DEBUG - 2019-07-01 21:12:10 --> Total execution time: 0.5386
INFO - 2019-07-01 15:12:46 --> Config Class Initialized
INFO - 2019-07-01 15:12:46 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:12:46 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:12:46 --> Utf8 Class Initialized
INFO - 2019-07-01 15:12:46 --> URI Class Initialized
INFO - 2019-07-01 15:12:46 --> Router Class Initialized
INFO - 2019-07-01 15:12:46 --> Output Class Initialized
INFO - 2019-07-01 15:12:46 --> Security Class Initialized
DEBUG - 2019-07-01 15:12:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:12:46 --> Input Class Initialized
INFO - 2019-07-01 15:12:46 --> Language Class Initialized
INFO - 2019-07-01 15:12:46 --> Language Class Initialized
INFO - 2019-07-01 15:12:46 --> Config Class Initialized
INFO - 2019-07-01 15:12:46 --> Loader Class Initialized
DEBUG - 2019-07-01 15:12:46 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:12:46 --> Helper loaded: url_helper
INFO - 2019-07-01 15:12:46 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:12:46 --> Helper loaded: string_helper
INFO - 2019-07-01 15:12:46 --> Helper loaded: array_helper
INFO - 2019-07-01 15:12:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:12:46 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:12:46 --> Database Driver Class Initialized
INFO - 2019-07-01 15:12:46 --> Controller Class Initialized
INFO - 2019-07-01 21:12:46 --> Helper loaded: language_helper
INFO - 2019-07-01 21:12:46 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:12:46 --> Model Class Initialized
INFO - 2019-07-01 21:12:47 --> Model Class Initialized
INFO - 2019-07-01 21:12:47 --> Model Class Initialized
INFO - 2019-07-01 21:12:47 --> Model Class Initialized
INFO - 2019-07-01 21:12:47 --> Helper loaded: form_helper
INFO - 2019-07-01 21:12:47 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:12:47 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:12:47 --> Model Class Initialized
INFO - 2019-07-01 21:12:47 --> Model Class Initialized
INFO - 2019-07-01 21:12:47 --> Final output sent to browser
DEBUG - 2019-07-01 21:12:47 --> Total execution time: 0.5018
INFO - 2019-07-01 15:12:49 --> Config Class Initialized
INFO - 2019-07-01 15:12:49 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:12:49 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:12:49 --> Utf8 Class Initialized
INFO - 2019-07-01 15:12:49 --> URI Class Initialized
INFO - 2019-07-01 15:12:49 --> Router Class Initialized
INFO - 2019-07-01 15:12:49 --> Output Class Initialized
INFO - 2019-07-01 15:12:49 --> Security Class Initialized
DEBUG - 2019-07-01 15:12:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:12:49 --> Input Class Initialized
INFO - 2019-07-01 15:12:49 --> Language Class Initialized
INFO - 2019-07-01 15:12:49 --> Language Class Initialized
INFO - 2019-07-01 15:12:49 --> Config Class Initialized
INFO - 2019-07-01 15:12:49 --> Loader Class Initialized
DEBUG - 2019-07-01 15:12:49 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:12:49 --> Helper loaded: url_helper
INFO - 2019-07-01 15:12:49 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:12:49 --> Helper loaded: string_helper
INFO - 2019-07-01 15:12:49 --> Helper loaded: array_helper
INFO - 2019-07-01 15:12:49 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:12:49 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:12:49 --> Database Driver Class Initialized
INFO - 2019-07-01 15:12:49 --> Controller Class Initialized
INFO - 2019-07-01 21:12:49 --> Helper loaded: language_helper
INFO - 2019-07-01 21:12:49 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:12:49 --> Model Class Initialized
INFO - 2019-07-01 21:12:49 --> Model Class Initialized
INFO - 2019-07-01 21:12:49 --> Model Class Initialized
INFO - 2019-07-01 21:12:49 --> Model Class Initialized
INFO - 2019-07-01 21:12:49 --> Helper loaded: form_helper
INFO - 2019-07-01 21:12:49 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:12:49 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:12:49 --> Model Class Initialized
INFO - 2019-07-01 21:12:50 --> Model Class Initialized
INFO - 2019-07-01 21:12:50 --> Final output sent to browser
DEBUG - 2019-07-01 21:12:50 --> Total execution time: 0.6804
INFO - 2019-07-01 15:13:34 --> Config Class Initialized
INFO - 2019-07-01 15:13:34 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:13:34 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:13:34 --> Utf8 Class Initialized
INFO - 2019-07-01 15:13:34 --> URI Class Initialized
INFO - 2019-07-01 15:13:34 --> Router Class Initialized
INFO - 2019-07-01 15:13:34 --> Output Class Initialized
INFO - 2019-07-01 15:13:34 --> Security Class Initialized
DEBUG - 2019-07-01 15:13:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:13:34 --> Input Class Initialized
INFO - 2019-07-01 15:13:34 --> Language Class Initialized
INFO - 2019-07-01 15:13:34 --> Language Class Initialized
INFO - 2019-07-01 15:13:34 --> Config Class Initialized
INFO - 2019-07-01 15:13:34 --> Loader Class Initialized
DEBUG - 2019-07-01 15:13:34 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:13:34 --> Helper loaded: url_helper
INFO - 2019-07-01 15:13:34 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:13:34 --> Helper loaded: string_helper
INFO - 2019-07-01 15:13:34 --> Helper loaded: array_helper
INFO - 2019-07-01 15:13:34 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:13:34 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:13:34 --> Database Driver Class Initialized
INFO - 2019-07-01 15:13:34 --> Controller Class Initialized
INFO - 2019-07-01 21:13:35 --> Helper loaded: language_helper
INFO - 2019-07-01 21:13:35 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:13:35 --> Model Class Initialized
INFO - 2019-07-01 21:13:35 --> Model Class Initialized
INFO - 2019-07-01 21:13:35 --> Model Class Initialized
INFO - 2019-07-01 21:13:35 --> Model Class Initialized
INFO - 2019-07-01 21:13:35 --> Helper loaded: form_helper
INFO - 2019-07-01 21:13:35 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:13:35 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:13:35 --> Model Class Initialized
INFO - 2019-07-01 21:13:35 --> Model Class Initialized
INFO - 2019-07-01 21:13:35 --> Final output sent to browser
DEBUG - 2019-07-01 21:13:35 --> Total execution time: 0.6566
INFO - 2019-07-01 15:13:37 --> Config Class Initialized
INFO - 2019-07-01 15:13:37 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:13:37 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:13:37 --> Utf8 Class Initialized
INFO - 2019-07-01 15:13:37 --> URI Class Initialized
INFO - 2019-07-01 15:13:37 --> Router Class Initialized
INFO - 2019-07-01 15:13:37 --> Output Class Initialized
INFO - 2019-07-01 15:13:37 --> Security Class Initialized
DEBUG - 2019-07-01 15:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:13:37 --> Input Class Initialized
INFO - 2019-07-01 15:13:37 --> Language Class Initialized
INFO - 2019-07-01 15:13:37 --> Language Class Initialized
INFO - 2019-07-01 15:13:37 --> Config Class Initialized
INFO - 2019-07-01 15:13:37 --> Loader Class Initialized
DEBUG - 2019-07-01 15:13:37 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:13:38 --> Helper loaded: url_helper
INFO - 2019-07-01 15:13:38 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:13:38 --> Helper loaded: string_helper
INFO - 2019-07-01 15:13:38 --> Helper loaded: array_helper
INFO - 2019-07-01 15:13:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:13:38 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:13:38 --> Database Driver Class Initialized
INFO - 2019-07-01 15:13:38 --> Controller Class Initialized
INFO - 2019-07-01 21:13:38 --> Helper loaded: language_helper
INFO - 2019-07-01 21:13:38 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:13:38 --> Model Class Initialized
INFO - 2019-07-01 21:13:38 --> Model Class Initialized
INFO - 2019-07-01 21:13:38 --> Model Class Initialized
INFO - 2019-07-01 21:13:38 --> Model Class Initialized
INFO - 2019-07-01 21:13:38 --> Helper loaded: form_helper
INFO - 2019-07-01 21:13:38 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:13:38 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:13:38 --> Model Class Initialized
INFO - 2019-07-01 21:13:38 --> Model Class Initialized
INFO - 2019-07-01 21:13:38 --> Final output sent to browser
DEBUG - 2019-07-01 21:13:38 --> Total execution time: 0.5773
INFO - 2019-07-01 15:14:28 --> Config Class Initialized
INFO - 2019-07-01 15:14:28 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:14:28 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:14:28 --> Utf8 Class Initialized
INFO - 2019-07-01 15:14:28 --> URI Class Initialized
INFO - 2019-07-01 15:14:28 --> Router Class Initialized
INFO - 2019-07-01 15:14:28 --> Output Class Initialized
INFO - 2019-07-01 15:14:29 --> Security Class Initialized
DEBUG - 2019-07-01 15:14:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:14:29 --> Input Class Initialized
INFO - 2019-07-01 15:14:29 --> Language Class Initialized
INFO - 2019-07-01 15:14:29 --> Language Class Initialized
INFO - 2019-07-01 15:14:29 --> Config Class Initialized
INFO - 2019-07-01 15:14:29 --> Loader Class Initialized
DEBUG - 2019-07-01 15:14:29 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:14:29 --> Helper loaded: url_helper
INFO - 2019-07-01 15:14:29 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:14:29 --> Helper loaded: string_helper
INFO - 2019-07-01 15:14:29 --> Helper loaded: array_helper
INFO - 2019-07-01 15:14:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:14:29 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:14:29 --> Database Driver Class Initialized
INFO - 2019-07-01 15:14:29 --> Controller Class Initialized
INFO - 2019-07-01 21:14:29 --> Helper loaded: language_helper
INFO - 2019-07-01 21:14:29 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:14:29 --> Model Class Initialized
INFO - 2019-07-01 21:14:29 --> Model Class Initialized
INFO - 2019-07-01 21:14:29 --> Model Class Initialized
INFO - 2019-07-01 21:14:29 --> Model Class Initialized
INFO - 2019-07-01 21:14:29 --> Helper loaded: form_helper
INFO - 2019-07-01 21:14:29 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:14:29 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:14:29 --> Model Class Initialized
INFO - 2019-07-01 21:14:29 --> Model Class Initialized
INFO - 2019-07-01 21:14:29 --> Final output sent to browser
DEBUG - 2019-07-01 21:14:29 --> Total execution time: 0.5967
INFO - 2019-07-01 15:14:31 --> Config Class Initialized
INFO - 2019-07-01 15:14:31 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:14:31 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:14:31 --> Utf8 Class Initialized
INFO - 2019-07-01 15:14:31 --> URI Class Initialized
INFO - 2019-07-01 15:14:32 --> Router Class Initialized
INFO - 2019-07-01 15:14:32 --> Output Class Initialized
INFO - 2019-07-01 15:14:32 --> Security Class Initialized
DEBUG - 2019-07-01 15:14:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:14:32 --> Input Class Initialized
INFO - 2019-07-01 15:14:32 --> Language Class Initialized
INFO - 2019-07-01 15:14:32 --> Language Class Initialized
INFO - 2019-07-01 15:14:32 --> Config Class Initialized
INFO - 2019-07-01 15:14:32 --> Loader Class Initialized
DEBUG - 2019-07-01 15:14:32 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:14:32 --> Helper loaded: url_helper
INFO - 2019-07-01 15:14:32 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:14:32 --> Helper loaded: string_helper
INFO - 2019-07-01 15:14:32 --> Helper loaded: array_helper
INFO - 2019-07-01 15:14:32 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:14:32 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:14:32 --> Database Driver Class Initialized
INFO - 2019-07-01 15:14:32 --> Controller Class Initialized
INFO - 2019-07-01 21:14:32 --> Helper loaded: language_helper
INFO - 2019-07-01 21:14:32 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:14:32 --> Model Class Initialized
INFO - 2019-07-01 21:14:32 --> Model Class Initialized
INFO - 2019-07-01 21:14:32 --> Model Class Initialized
INFO - 2019-07-01 21:14:32 --> Model Class Initialized
INFO - 2019-07-01 21:14:32 --> Helper loaded: form_helper
INFO - 2019-07-01 21:14:32 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:14:32 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:14:32 --> Model Class Initialized
INFO - 2019-07-01 21:14:32 --> Model Class Initialized
INFO - 2019-07-01 21:14:32 --> Final output sent to browser
DEBUG - 2019-07-01 21:14:32 --> Total execution time: 0.4055
INFO - 2019-07-01 15:14:38 --> Config Class Initialized
INFO - 2019-07-01 15:14:38 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:14:38 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:14:38 --> Utf8 Class Initialized
INFO - 2019-07-01 15:14:38 --> URI Class Initialized
INFO - 2019-07-01 15:14:38 --> Router Class Initialized
INFO - 2019-07-01 15:14:38 --> Output Class Initialized
INFO - 2019-07-01 15:14:38 --> Security Class Initialized
DEBUG - 2019-07-01 15:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:14:38 --> Input Class Initialized
INFO - 2019-07-01 15:14:38 --> Language Class Initialized
INFO - 2019-07-01 15:14:38 --> Language Class Initialized
INFO - 2019-07-01 15:14:38 --> Config Class Initialized
INFO - 2019-07-01 15:14:38 --> Loader Class Initialized
DEBUG - 2019-07-01 15:14:38 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:14:38 --> Helper loaded: url_helper
INFO - 2019-07-01 15:14:38 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:14:38 --> Helper loaded: string_helper
INFO - 2019-07-01 15:14:38 --> Helper loaded: array_helper
INFO - 2019-07-01 15:14:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:14:38 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:14:38 --> Database Driver Class Initialized
INFO - 2019-07-01 15:14:38 --> Controller Class Initialized
INFO - 2019-07-01 21:14:38 --> Helper loaded: language_helper
INFO - 2019-07-01 21:14:38 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:14:38 --> Model Class Initialized
INFO - 2019-07-01 21:14:38 --> Model Class Initialized
INFO - 2019-07-01 21:14:38 --> Model Class Initialized
INFO - 2019-07-01 21:14:38 --> Model Class Initialized
INFO - 2019-07-01 21:14:38 --> Helper loaded: form_helper
INFO - 2019-07-01 21:14:38 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:14:38 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:14:38 --> Model Class Initialized
INFO - 2019-07-01 21:14:38 --> Model Class Initialized
INFO - 2019-07-01 21:14:38 --> Final output sent to browser
DEBUG - 2019-07-01 21:14:38 --> Total execution time: 0.7616
INFO - 2019-07-01 15:14:40 --> Config Class Initialized
INFO - 2019-07-01 15:14:40 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:14:40 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:14:40 --> Utf8 Class Initialized
INFO - 2019-07-01 15:14:40 --> URI Class Initialized
INFO - 2019-07-01 15:14:40 --> Router Class Initialized
INFO - 2019-07-01 15:14:40 --> Output Class Initialized
INFO - 2019-07-01 15:14:40 --> Security Class Initialized
DEBUG - 2019-07-01 15:14:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:14:40 --> Input Class Initialized
INFO - 2019-07-01 15:14:40 --> Language Class Initialized
INFO - 2019-07-01 15:14:40 --> Language Class Initialized
INFO - 2019-07-01 15:14:40 --> Config Class Initialized
INFO - 2019-07-01 15:14:40 --> Loader Class Initialized
DEBUG - 2019-07-01 15:14:40 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:14:40 --> Helper loaded: url_helper
INFO - 2019-07-01 15:14:40 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:14:40 --> Helper loaded: string_helper
INFO - 2019-07-01 15:14:40 --> Helper loaded: array_helper
INFO - 2019-07-01 15:14:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:14:40 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:14:40 --> Database Driver Class Initialized
INFO - 2019-07-01 15:14:40 --> Controller Class Initialized
INFO - 2019-07-01 21:14:40 --> Helper loaded: language_helper
INFO - 2019-07-01 21:14:40 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:14:40 --> Model Class Initialized
INFO - 2019-07-01 21:14:40 --> Model Class Initialized
INFO - 2019-07-01 21:14:40 --> Model Class Initialized
INFO - 2019-07-01 21:14:40 --> Model Class Initialized
INFO - 2019-07-01 21:14:40 --> Model Class Initialized
INFO - 2019-07-01 21:14:40 --> Final output sent to browser
DEBUG - 2019-07-01 21:14:40 --> Total execution time: 0.3804
INFO - 2019-07-01 15:14:41 --> Config Class Initialized
INFO - 2019-07-01 15:14:41 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:14:41 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:14:41 --> Utf8 Class Initialized
INFO - 2019-07-01 15:14:41 --> URI Class Initialized
INFO - 2019-07-01 15:14:41 --> Router Class Initialized
INFO - 2019-07-01 15:14:41 --> Output Class Initialized
INFO - 2019-07-01 15:14:41 --> Security Class Initialized
DEBUG - 2019-07-01 15:14:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:14:41 --> Input Class Initialized
INFO - 2019-07-01 15:14:41 --> Language Class Initialized
INFO - 2019-07-01 15:14:41 --> Language Class Initialized
INFO - 2019-07-01 15:14:41 --> Config Class Initialized
INFO - 2019-07-01 15:14:41 --> Loader Class Initialized
DEBUG - 2019-07-01 15:14:41 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:14:41 --> Helper loaded: url_helper
INFO - 2019-07-01 15:14:41 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:14:41 --> Helper loaded: string_helper
INFO - 2019-07-01 15:14:41 --> Helper loaded: array_helper
INFO - 2019-07-01 15:14:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:14:41 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:14:41 --> Database Driver Class Initialized
INFO - 2019-07-01 15:14:41 --> Controller Class Initialized
INFO - 2019-07-01 21:14:41 --> Helper loaded: language_helper
INFO - 2019-07-01 21:14:41 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:14:41 --> Model Class Initialized
INFO - 2019-07-01 21:14:41 --> Model Class Initialized
INFO - 2019-07-01 21:14:41 --> Model Class Initialized
INFO - 2019-07-01 21:14:41 --> Model Class Initialized
INFO - 2019-07-01 21:14:41 --> Helper loaded: form_helper
INFO - 2019-07-01 21:14:41 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:14:41 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:14:41 --> Model Class Initialized
INFO - 2019-07-01 21:14:41 --> Model Class Initialized
INFO - 2019-07-01 21:14:41 --> Final output sent to browser
DEBUG - 2019-07-01 21:14:41 --> Total execution time: 0.4044
INFO - 2019-07-01 15:14:42 --> Config Class Initialized
INFO - 2019-07-01 15:14:42 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:14:42 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:14:42 --> Utf8 Class Initialized
INFO - 2019-07-01 15:14:42 --> URI Class Initialized
INFO - 2019-07-01 15:14:42 --> Router Class Initialized
INFO - 2019-07-01 15:14:42 --> Output Class Initialized
INFO - 2019-07-01 15:14:42 --> Security Class Initialized
DEBUG - 2019-07-01 15:14:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:14:42 --> Input Class Initialized
INFO - 2019-07-01 15:14:42 --> Language Class Initialized
INFO - 2019-07-01 15:14:42 --> Language Class Initialized
INFO - 2019-07-01 15:14:42 --> Config Class Initialized
INFO - 2019-07-01 15:14:42 --> Loader Class Initialized
DEBUG - 2019-07-01 15:14:42 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:14:42 --> Helper loaded: url_helper
INFO - 2019-07-01 15:14:42 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:14:42 --> Helper loaded: string_helper
INFO - 2019-07-01 15:14:42 --> Helper loaded: array_helper
INFO - 2019-07-01 15:14:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:14:42 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:14:42 --> Database Driver Class Initialized
INFO - 2019-07-01 15:14:42 --> Controller Class Initialized
INFO - 2019-07-01 21:14:42 --> Helper loaded: language_helper
INFO - 2019-07-01 21:14:42 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:14:42 --> Model Class Initialized
INFO - 2019-07-01 21:14:42 --> Model Class Initialized
INFO - 2019-07-01 21:14:42 --> Model Class Initialized
INFO - 2019-07-01 21:14:42 --> Model Class Initialized
INFO - 2019-07-01 21:14:42 --> Model Class Initialized
INFO - 2019-07-01 21:14:42 --> Final output sent to browser
DEBUG - 2019-07-01 21:14:42 --> Total execution time: 0.3435
INFO - 2019-07-01 15:14:49 --> Config Class Initialized
INFO - 2019-07-01 15:14:49 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:14:49 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:14:49 --> Utf8 Class Initialized
INFO - 2019-07-01 15:14:49 --> URI Class Initialized
INFO - 2019-07-01 15:14:49 --> Router Class Initialized
INFO - 2019-07-01 15:14:49 --> Output Class Initialized
INFO - 2019-07-01 15:14:49 --> Security Class Initialized
DEBUG - 2019-07-01 15:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:14:49 --> Input Class Initialized
INFO - 2019-07-01 15:14:49 --> Language Class Initialized
INFO - 2019-07-01 15:14:49 --> Language Class Initialized
INFO - 2019-07-01 15:14:49 --> Config Class Initialized
INFO - 2019-07-01 15:14:49 --> Loader Class Initialized
DEBUG - 2019-07-01 15:14:49 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:14:49 --> Helper loaded: url_helper
INFO - 2019-07-01 15:14:49 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:14:49 --> Helper loaded: string_helper
INFO - 2019-07-01 15:14:49 --> Helper loaded: array_helper
INFO - 2019-07-01 15:14:49 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:14:49 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:14:49 --> Database Driver Class Initialized
INFO - 2019-07-01 15:14:49 --> Controller Class Initialized
INFO - 2019-07-01 21:14:49 --> Helper loaded: language_helper
INFO - 2019-07-01 21:14:49 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:14:49 --> Model Class Initialized
INFO - 2019-07-01 21:14:49 --> Model Class Initialized
INFO - 2019-07-01 21:14:49 --> Model Class Initialized
INFO - 2019-07-01 21:14:49 --> Model Class Initialized
INFO - 2019-07-01 21:14:49 --> Helper loaded: form_helper
INFO - 2019-07-01 21:14:49 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:14:49 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:14:49 --> Model Class Initialized
INFO - 2019-07-01 21:14:49 --> Model Class Initialized
INFO - 2019-07-01 21:14:49 --> Final output sent to browser
DEBUG - 2019-07-01 21:14:49 --> Total execution time: 0.5552
INFO - 2019-07-01 15:14:49 --> Config Class Initialized
INFO - 2019-07-01 15:14:49 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:14:49 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:14:49 --> Utf8 Class Initialized
INFO - 2019-07-01 15:14:49 --> URI Class Initialized
INFO - 2019-07-01 15:14:49 --> Router Class Initialized
INFO - 2019-07-01 15:14:49 --> Output Class Initialized
INFO - 2019-07-01 15:14:49 --> Security Class Initialized
DEBUG - 2019-07-01 15:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:14:49 --> Input Class Initialized
INFO - 2019-07-01 15:14:49 --> Language Class Initialized
INFO - 2019-07-01 15:14:49 --> Language Class Initialized
INFO - 2019-07-01 15:14:49 --> Config Class Initialized
INFO - 2019-07-01 15:14:50 --> Loader Class Initialized
DEBUG - 2019-07-01 15:14:50 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:14:50 --> Helper loaded: url_helper
INFO - 2019-07-01 15:14:50 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:14:50 --> Helper loaded: string_helper
INFO - 2019-07-01 15:14:50 --> Helper loaded: array_helper
INFO - 2019-07-01 15:14:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:14:50 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:14:50 --> Database Driver Class Initialized
INFO - 2019-07-01 15:14:50 --> Controller Class Initialized
INFO - 2019-07-01 21:14:50 --> Helper loaded: language_helper
INFO - 2019-07-01 21:14:50 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:14:50 --> Model Class Initialized
INFO - 2019-07-01 21:14:50 --> Model Class Initialized
INFO - 2019-07-01 21:14:50 --> Model Class Initialized
INFO - 2019-07-01 21:14:50 --> Model Class Initialized
INFO - 2019-07-01 21:14:50 --> Helper loaded: form_helper
INFO - 2019-07-01 21:14:50 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:14:50 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:14:50 --> Model Class Initialized
INFO - 2019-07-01 21:14:50 --> Model Class Initialized
INFO - 2019-07-01 21:14:50 --> Final output sent to browser
DEBUG - 2019-07-01 21:14:50 --> Total execution time: 0.5217
INFO - 2019-07-01 15:15:07 --> Config Class Initialized
INFO - 2019-07-01 15:15:07 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:15:07 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:15:07 --> Utf8 Class Initialized
INFO - 2019-07-01 15:15:07 --> URI Class Initialized
INFO - 2019-07-01 15:15:07 --> Router Class Initialized
INFO - 2019-07-01 15:15:07 --> Output Class Initialized
INFO - 2019-07-01 15:15:07 --> Security Class Initialized
DEBUG - 2019-07-01 15:15:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:15:07 --> Input Class Initialized
INFO - 2019-07-01 15:15:07 --> Language Class Initialized
INFO - 2019-07-01 15:15:07 --> Language Class Initialized
INFO - 2019-07-01 15:15:07 --> Config Class Initialized
INFO - 2019-07-01 15:15:07 --> Loader Class Initialized
DEBUG - 2019-07-01 15:15:07 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:15:07 --> Helper loaded: url_helper
INFO - 2019-07-01 15:15:07 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:15:07 --> Helper loaded: string_helper
INFO - 2019-07-01 15:15:07 --> Helper loaded: array_helper
INFO - 2019-07-01 15:15:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:15:07 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:15:07 --> Database Driver Class Initialized
INFO - 2019-07-01 15:15:07 --> Controller Class Initialized
INFO - 2019-07-01 21:15:07 --> Helper loaded: language_helper
INFO - 2019-07-01 21:15:07 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:15:07 --> Model Class Initialized
INFO - 2019-07-01 21:15:08 --> Model Class Initialized
INFO - 2019-07-01 21:15:08 --> Model Class Initialized
INFO - 2019-07-01 21:15:08 --> Model Class Initialized
INFO - 2019-07-01 21:15:08 --> Helper loaded: form_helper
INFO - 2019-07-01 21:15:08 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:15:08 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:15:08 --> Model Class Initialized
INFO - 2019-07-01 21:15:08 --> Model Class Initialized
INFO - 2019-07-01 21:15:08 --> Final output sent to browser
DEBUG - 2019-07-01 21:15:08 --> Total execution time: 0.5405
INFO - 2019-07-01 15:15:08 --> Config Class Initialized
INFO - 2019-07-01 15:15:08 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:15:08 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:15:08 --> Utf8 Class Initialized
INFO - 2019-07-01 15:15:08 --> URI Class Initialized
INFO - 2019-07-01 15:15:08 --> Router Class Initialized
INFO - 2019-07-01 15:15:08 --> Output Class Initialized
INFO - 2019-07-01 15:15:08 --> Security Class Initialized
DEBUG - 2019-07-01 15:15:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:15:08 --> Input Class Initialized
INFO - 2019-07-01 15:15:08 --> Language Class Initialized
INFO - 2019-07-01 15:15:08 --> Language Class Initialized
INFO - 2019-07-01 15:15:08 --> Config Class Initialized
INFO - 2019-07-01 15:15:08 --> Loader Class Initialized
DEBUG - 2019-07-01 15:15:08 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:15:08 --> Helper loaded: url_helper
INFO - 2019-07-01 15:15:08 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:15:08 --> Helper loaded: string_helper
INFO - 2019-07-01 15:15:08 --> Helper loaded: array_helper
INFO - 2019-07-01 15:15:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:15:08 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:15:08 --> Database Driver Class Initialized
INFO - 2019-07-01 15:15:08 --> Controller Class Initialized
INFO - 2019-07-01 21:15:08 --> Helper loaded: language_helper
INFO - 2019-07-01 21:15:08 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:15:08 --> Model Class Initialized
INFO - 2019-07-01 21:15:08 --> Model Class Initialized
INFO - 2019-07-01 21:15:08 --> Model Class Initialized
INFO - 2019-07-01 21:15:08 --> Model Class Initialized
INFO - 2019-07-01 21:15:08 --> Helper loaded: form_helper
INFO - 2019-07-01 21:15:08 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:15:08 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:15:08 --> Model Class Initialized
INFO - 2019-07-01 21:15:08 --> Model Class Initialized
INFO - 2019-07-01 21:15:08 --> Final output sent to browser
DEBUG - 2019-07-01 21:15:08 --> Total execution time: 0.5619
INFO - 2019-07-01 15:15:21 --> Config Class Initialized
INFO - 2019-07-01 15:15:21 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:15:21 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:15:21 --> Utf8 Class Initialized
INFO - 2019-07-01 15:15:21 --> URI Class Initialized
INFO - 2019-07-01 15:15:21 --> Router Class Initialized
INFO - 2019-07-01 15:15:21 --> Output Class Initialized
INFO - 2019-07-01 15:15:21 --> Security Class Initialized
DEBUG - 2019-07-01 15:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:15:21 --> Input Class Initialized
INFO - 2019-07-01 15:15:21 --> Language Class Initialized
INFO - 2019-07-01 15:15:21 --> Language Class Initialized
INFO - 2019-07-01 15:15:21 --> Config Class Initialized
INFO - 2019-07-01 15:15:21 --> Loader Class Initialized
DEBUG - 2019-07-01 15:15:21 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:15:21 --> Helper loaded: url_helper
INFO - 2019-07-01 15:15:21 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:15:21 --> Helper loaded: string_helper
INFO - 2019-07-01 15:15:21 --> Helper loaded: array_helper
INFO - 2019-07-01 15:15:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:15:21 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:15:21 --> Database Driver Class Initialized
INFO - 2019-07-01 15:15:21 --> Controller Class Initialized
INFO - 2019-07-01 21:15:21 --> Helper loaded: language_helper
INFO - 2019-07-01 21:15:21 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:15:21 --> Model Class Initialized
INFO - 2019-07-01 21:15:21 --> Model Class Initialized
INFO - 2019-07-01 21:15:21 --> Model Class Initialized
INFO - 2019-07-01 21:15:22 --> Model Class Initialized
INFO - 2019-07-01 21:15:22 --> Helper loaded: form_helper
INFO - 2019-07-01 21:15:22 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:15:22 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:15:22 --> Model Class Initialized
INFO - 2019-07-01 21:15:22 --> Model Class Initialized
INFO - 2019-07-01 21:15:22 --> Final output sent to browser
DEBUG - 2019-07-01 21:15:22 --> Total execution time: 0.7362
INFO - 2019-07-01 15:16:12 --> Config Class Initialized
INFO - 2019-07-01 15:16:12 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:16:12 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:16:12 --> Utf8 Class Initialized
INFO - 2019-07-01 15:16:12 --> URI Class Initialized
INFO - 2019-07-01 15:16:12 --> Router Class Initialized
INFO - 2019-07-01 15:16:12 --> Output Class Initialized
INFO - 2019-07-01 15:16:12 --> Security Class Initialized
DEBUG - 2019-07-01 15:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:16:12 --> Input Class Initialized
INFO - 2019-07-01 15:16:12 --> Language Class Initialized
INFO - 2019-07-01 15:16:12 --> Language Class Initialized
INFO - 2019-07-01 15:16:12 --> Config Class Initialized
INFO - 2019-07-01 15:16:12 --> Loader Class Initialized
DEBUG - 2019-07-01 15:16:12 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:16:12 --> Helper loaded: url_helper
INFO - 2019-07-01 15:16:12 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:16:12 --> Helper loaded: string_helper
INFO - 2019-07-01 15:16:12 --> Helper loaded: array_helper
INFO - 2019-07-01 15:16:12 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:16:12 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:16:12 --> Database Driver Class Initialized
INFO - 2019-07-01 15:16:12 --> Controller Class Initialized
INFO - 2019-07-01 21:16:12 --> Helper loaded: language_helper
INFO - 2019-07-01 21:16:12 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:16:12 --> Model Class Initialized
INFO - 2019-07-01 21:16:12 --> Model Class Initialized
INFO - 2019-07-01 21:16:12 --> Model Class Initialized
INFO - 2019-07-01 21:16:12 --> Model Class Initialized
INFO - 2019-07-01 21:16:12 --> Helper loaded: form_helper
INFO - 2019-07-01 21:16:12 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:16:12 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:16:12 --> Model Class Initialized
INFO - 2019-07-01 21:16:12 --> Model Class Initialized
INFO - 2019-07-01 21:16:12 --> Final output sent to browser
DEBUG - 2019-07-01 21:16:12 --> Total execution time: 0.3985
INFO - 2019-07-01 15:18:06 --> Config Class Initialized
INFO - 2019-07-01 15:18:06 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:18:06 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:18:06 --> Utf8 Class Initialized
INFO - 2019-07-01 15:18:06 --> URI Class Initialized
INFO - 2019-07-01 15:18:06 --> Router Class Initialized
INFO - 2019-07-01 15:18:06 --> Output Class Initialized
INFO - 2019-07-01 15:18:06 --> Security Class Initialized
DEBUG - 2019-07-01 15:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:18:06 --> Input Class Initialized
INFO - 2019-07-01 15:18:06 --> Language Class Initialized
INFO - 2019-07-01 15:18:06 --> Language Class Initialized
INFO - 2019-07-01 15:18:06 --> Config Class Initialized
INFO - 2019-07-01 15:18:06 --> Loader Class Initialized
DEBUG - 2019-07-01 15:18:06 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:18:06 --> Helper loaded: url_helper
INFO - 2019-07-01 15:18:06 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:18:07 --> Helper loaded: string_helper
INFO - 2019-07-01 15:18:07 --> Helper loaded: array_helper
INFO - 2019-07-01 15:18:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:18:07 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:18:07 --> Database Driver Class Initialized
INFO - 2019-07-01 15:18:07 --> Controller Class Initialized
INFO - 2019-07-01 21:18:07 --> Helper loaded: language_helper
INFO - 2019-07-01 21:18:07 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:18:07 --> Model Class Initialized
INFO - 2019-07-01 21:18:07 --> Model Class Initialized
INFO - 2019-07-01 21:18:07 --> Model Class Initialized
INFO - 2019-07-01 21:18:07 --> Model Class Initialized
INFO - 2019-07-01 21:18:07 --> Helper loaded: form_helper
INFO - 2019-07-01 21:18:07 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:18:07 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:18:07 --> Model Class Initialized
INFO - 2019-07-01 21:18:07 --> Model Class Initialized
INFO - 2019-07-01 21:18:07 --> Final output sent to browser
DEBUG - 2019-07-01 21:18:07 --> Total execution time: 0.5262
INFO - 2019-07-01 15:18:10 --> Config Class Initialized
INFO - 2019-07-01 15:18:10 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:18:10 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:18:10 --> Utf8 Class Initialized
INFO - 2019-07-01 15:18:10 --> URI Class Initialized
INFO - 2019-07-01 15:18:10 --> Router Class Initialized
INFO - 2019-07-01 15:18:10 --> Output Class Initialized
INFO - 2019-07-01 15:18:10 --> Security Class Initialized
DEBUG - 2019-07-01 15:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:18:10 --> Input Class Initialized
INFO - 2019-07-01 15:18:10 --> Language Class Initialized
INFO - 2019-07-01 15:18:10 --> Language Class Initialized
INFO - 2019-07-01 15:18:10 --> Config Class Initialized
INFO - 2019-07-01 15:18:10 --> Loader Class Initialized
DEBUG - 2019-07-01 15:18:10 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:18:10 --> Helper loaded: url_helper
INFO - 2019-07-01 15:18:10 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:18:10 --> Helper loaded: string_helper
INFO - 2019-07-01 15:18:10 --> Helper loaded: array_helper
INFO - 2019-07-01 15:18:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:18:10 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:18:10 --> Database Driver Class Initialized
INFO - 2019-07-01 15:18:10 --> Controller Class Initialized
INFO - 2019-07-01 21:18:10 --> Helper loaded: language_helper
INFO - 2019-07-01 21:18:10 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:18:10 --> Model Class Initialized
INFO - 2019-07-01 21:18:10 --> Model Class Initialized
INFO - 2019-07-01 21:18:10 --> Model Class Initialized
INFO - 2019-07-01 21:18:10 --> Model Class Initialized
INFO - 2019-07-01 21:18:10 --> Helper loaded: form_helper
INFO - 2019-07-01 21:18:10 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:18:10 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:18:10 --> Model Class Initialized
INFO - 2019-07-01 21:18:10 --> Model Class Initialized
INFO - 2019-07-01 21:18:10 --> Final output sent to browser
DEBUG - 2019-07-01 21:18:10 --> Total execution time: 0.4625
INFO - 2019-07-01 15:18:10 --> Config Class Initialized
INFO - 2019-07-01 15:18:10 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:18:10 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:18:10 --> Utf8 Class Initialized
INFO - 2019-07-01 15:18:10 --> URI Class Initialized
INFO - 2019-07-01 15:18:10 --> Router Class Initialized
INFO - 2019-07-01 15:18:10 --> Output Class Initialized
INFO - 2019-07-01 15:18:10 --> Security Class Initialized
DEBUG - 2019-07-01 15:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:18:10 --> Input Class Initialized
INFO - 2019-07-01 15:18:10 --> Language Class Initialized
INFO - 2019-07-01 15:18:10 --> Language Class Initialized
INFO - 2019-07-01 15:18:10 --> Config Class Initialized
INFO - 2019-07-01 15:18:10 --> Loader Class Initialized
DEBUG - 2019-07-01 15:18:10 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:18:10 --> Helper loaded: url_helper
INFO - 2019-07-01 15:18:10 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:18:10 --> Helper loaded: string_helper
INFO - 2019-07-01 15:18:10 --> Helper loaded: array_helper
INFO - 2019-07-01 15:18:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:18:10 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:18:10 --> Database Driver Class Initialized
INFO - 2019-07-01 15:18:10 --> Controller Class Initialized
INFO - 2019-07-01 21:18:10 --> Helper loaded: language_helper
INFO - 2019-07-01 21:18:10 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:18:10 --> Model Class Initialized
INFO - 2019-07-01 21:18:10 --> Model Class Initialized
INFO - 2019-07-01 21:18:10 --> Model Class Initialized
INFO - 2019-07-01 21:18:10 --> Model Class Initialized
INFO - 2019-07-01 21:18:10 --> Model Class Initialized
INFO - 2019-07-01 21:18:10 --> Final output sent to browser
DEBUG - 2019-07-01 21:18:10 --> Total execution time: 0.3650
INFO - 2019-07-01 15:18:35 --> Config Class Initialized
INFO - 2019-07-01 15:18:35 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:18:35 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:18:35 --> Utf8 Class Initialized
INFO - 2019-07-01 15:18:35 --> URI Class Initialized
INFO - 2019-07-01 15:18:35 --> Router Class Initialized
INFO - 2019-07-01 15:18:35 --> Output Class Initialized
INFO - 2019-07-01 15:18:36 --> Security Class Initialized
DEBUG - 2019-07-01 15:18:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:18:36 --> Input Class Initialized
INFO - 2019-07-01 15:18:36 --> Language Class Initialized
INFO - 2019-07-01 15:18:36 --> Language Class Initialized
INFO - 2019-07-01 15:18:36 --> Config Class Initialized
INFO - 2019-07-01 15:18:36 --> Loader Class Initialized
DEBUG - 2019-07-01 15:18:36 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:18:36 --> Helper loaded: url_helper
INFO - 2019-07-01 15:18:36 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:18:36 --> Helper loaded: string_helper
INFO - 2019-07-01 15:18:36 --> Helper loaded: array_helper
INFO - 2019-07-01 15:18:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:18:36 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:18:36 --> Database Driver Class Initialized
INFO - 2019-07-01 15:18:36 --> Controller Class Initialized
INFO - 2019-07-01 21:18:36 --> Helper loaded: language_helper
INFO - 2019-07-01 21:18:36 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:18:36 --> Model Class Initialized
INFO - 2019-07-01 21:18:36 --> Model Class Initialized
INFO - 2019-07-01 21:18:36 --> Model Class Initialized
INFO - 2019-07-01 21:18:36 --> Model Class Initialized
INFO - 2019-07-01 21:18:36 --> Helper loaded: form_helper
INFO - 2019-07-01 21:18:36 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:18:36 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:18:36 --> Model Class Initialized
INFO - 2019-07-01 21:18:36 --> Model Class Initialized
INFO - 2019-07-01 21:18:36 --> Final output sent to browser
DEBUG - 2019-07-01 21:18:36 --> Total execution time: 0.5585
INFO - 2019-07-01 15:18:36 --> Config Class Initialized
INFO - 2019-07-01 15:18:36 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:18:36 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:18:36 --> Utf8 Class Initialized
INFO - 2019-07-01 15:18:36 --> URI Class Initialized
INFO - 2019-07-01 15:18:36 --> Router Class Initialized
INFO - 2019-07-01 15:18:36 --> Output Class Initialized
INFO - 2019-07-01 15:18:36 --> Security Class Initialized
DEBUG - 2019-07-01 15:18:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:18:36 --> Input Class Initialized
INFO - 2019-07-01 15:18:36 --> Language Class Initialized
INFO - 2019-07-01 15:18:36 --> Language Class Initialized
INFO - 2019-07-01 15:18:36 --> Config Class Initialized
INFO - 2019-07-01 15:18:36 --> Loader Class Initialized
DEBUG - 2019-07-01 15:18:36 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:18:36 --> Helper loaded: url_helper
INFO - 2019-07-01 15:18:36 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:18:36 --> Helper loaded: string_helper
INFO - 2019-07-01 15:18:36 --> Helper loaded: array_helper
INFO - 2019-07-01 15:18:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:18:36 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:18:36 --> Database Driver Class Initialized
INFO - 2019-07-01 15:18:36 --> Controller Class Initialized
INFO - 2019-07-01 21:18:37 --> Helper loaded: language_helper
INFO - 2019-07-01 21:18:37 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:18:37 --> Model Class Initialized
INFO - 2019-07-01 21:18:37 --> Model Class Initialized
INFO - 2019-07-01 21:18:37 --> Model Class Initialized
INFO - 2019-07-01 21:18:37 --> Model Class Initialized
INFO - 2019-07-01 21:18:37 --> Helper loaded: form_helper
INFO - 2019-07-01 21:18:37 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:18:37 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:18:37 --> Model Class Initialized
INFO - 2019-07-01 21:18:37 --> Model Class Initialized
INFO - 2019-07-01 21:18:37 --> Final output sent to browser
DEBUG - 2019-07-01 21:18:37 --> Total execution time: 0.6159
INFO - 2019-07-01 15:18:56 --> Config Class Initialized
INFO - 2019-07-01 15:18:56 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:18:56 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:18:56 --> Utf8 Class Initialized
INFO - 2019-07-01 15:18:56 --> URI Class Initialized
INFO - 2019-07-01 15:18:56 --> Router Class Initialized
INFO - 2019-07-01 15:18:56 --> Output Class Initialized
INFO - 2019-07-01 15:18:56 --> Security Class Initialized
DEBUG - 2019-07-01 15:18:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:18:56 --> Input Class Initialized
INFO - 2019-07-01 15:18:56 --> Language Class Initialized
INFO - 2019-07-01 15:18:56 --> Language Class Initialized
INFO - 2019-07-01 15:18:56 --> Config Class Initialized
INFO - 2019-07-01 15:18:56 --> Loader Class Initialized
DEBUG - 2019-07-01 15:18:56 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:18:56 --> Helper loaded: url_helper
INFO - 2019-07-01 15:18:56 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:18:56 --> Helper loaded: string_helper
INFO - 2019-07-01 15:18:56 --> Helper loaded: array_helper
INFO - 2019-07-01 15:18:56 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:18:56 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:18:56 --> Database Driver Class Initialized
INFO - 2019-07-01 15:18:56 --> Controller Class Initialized
INFO - 2019-07-01 21:18:56 --> Helper loaded: language_helper
INFO - 2019-07-01 21:18:56 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:18:56 --> Model Class Initialized
INFO - 2019-07-01 21:18:56 --> Model Class Initialized
INFO - 2019-07-01 21:18:56 --> Model Class Initialized
INFO - 2019-07-01 21:18:56 --> Model Class Initialized
INFO - 2019-07-01 21:18:56 --> Helper loaded: form_helper
INFO - 2019-07-01 21:18:56 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:18:56 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:18:56 --> Model Class Initialized
INFO - 2019-07-01 21:18:56 --> Model Class Initialized
INFO - 2019-07-01 21:18:56 --> Final output sent to browser
DEBUG - 2019-07-01 21:18:56 --> Total execution time: 0.7265
INFO - 2019-07-01 15:19:56 --> Config Class Initialized
INFO - 2019-07-01 15:19:56 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:19:56 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:19:56 --> Utf8 Class Initialized
INFO - 2019-07-01 15:19:56 --> URI Class Initialized
INFO - 2019-07-01 15:19:56 --> Router Class Initialized
INFO - 2019-07-01 15:19:56 --> Output Class Initialized
INFO - 2019-07-01 15:19:56 --> Security Class Initialized
DEBUG - 2019-07-01 15:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:19:56 --> Input Class Initialized
INFO - 2019-07-01 15:19:56 --> Language Class Initialized
INFO - 2019-07-01 15:19:56 --> Language Class Initialized
INFO - 2019-07-01 15:19:56 --> Config Class Initialized
INFO - 2019-07-01 15:19:56 --> Loader Class Initialized
DEBUG - 2019-07-01 15:19:56 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:19:56 --> Helper loaded: url_helper
INFO - 2019-07-01 15:19:56 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:19:56 --> Helper loaded: string_helper
INFO - 2019-07-01 15:19:57 --> Helper loaded: array_helper
INFO - 2019-07-01 15:19:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:19:57 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:19:57 --> Database Driver Class Initialized
INFO - 2019-07-01 15:19:57 --> Controller Class Initialized
INFO - 2019-07-01 21:19:57 --> Helper loaded: language_helper
INFO - 2019-07-01 21:19:57 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:19:57 --> Model Class Initialized
INFO - 2019-07-01 21:19:57 --> Model Class Initialized
INFO - 2019-07-01 21:19:57 --> Model Class Initialized
INFO - 2019-07-01 21:19:57 --> Model Class Initialized
INFO - 2019-07-01 21:19:57 --> Helper loaded: form_helper
INFO - 2019-07-01 21:19:57 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:19:57 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:19:57 --> Model Class Initialized
INFO - 2019-07-01 21:19:57 --> Model Class Initialized
INFO - 2019-07-01 21:19:57 --> Final output sent to browser
DEBUG - 2019-07-01 21:19:57 --> Total execution time: 1.1719
INFO - 2019-07-01 15:20:02 --> Config Class Initialized
INFO - 2019-07-01 15:20:02 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:20:02 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:20:02 --> Utf8 Class Initialized
INFO - 2019-07-01 15:20:02 --> URI Class Initialized
INFO - 2019-07-01 15:20:02 --> Router Class Initialized
INFO - 2019-07-01 15:20:02 --> Output Class Initialized
INFO - 2019-07-01 15:20:02 --> Security Class Initialized
DEBUG - 2019-07-01 15:20:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:20:02 --> Input Class Initialized
INFO - 2019-07-01 15:20:02 --> Language Class Initialized
INFO - 2019-07-01 15:20:02 --> Language Class Initialized
INFO - 2019-07-01 15:20:02 --> Config Class Initialized
INFO - 2019-07-01 15:20:02 --> Loader Class Initialized
DEBUG - 2019-07-01 15:20:03 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:20:03 --> Helper loaded: url_helper
INFO - 2019-07-01 15:20:03 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:20:03 --> Helper loaded: string_helper
INFO - 2019-07-01 15:20:03 --> Helper loaded: array_helper
INFO - 2019-07-01 15:20:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:20:03 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:20:03 --> Database Driver Class Initialized
INFO - 2019-07-01 15:20:03 --> Controller Class Initialized
INFO - 2019-07-01 21:20:03 --> Helper loaded: language_helper
INFO - 2019-07-01 21:20:03 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:20:03 --> Model Class Initialized
INFO - 2019-07-01 21:20:03 --> Model Class Initialized
INFO - 2019-07-01 21:20:03 --> Model Class Initialized
INFO - 2019-07-01 21:20:03 --> Model Class Initialized
INFO - 2019-07-01 21:20:03 --> Helper loaded: form_helper
INFO - 2019-07-01 21:20:03 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:20:03 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:20:03 --> Model Class Initialized
INFO - 2019-07-01 21:20:03 --> Model Class Initialized
INFO - 2019-07-01 21:20:03 --> Final output sent to browser
DEBUG - 2019-07-01 21:20:03 --> Total execution time: 0.6563
INFO - 2019-07-01 15:20:22 --> Config Class Initialized
INFO - 2019-07-01 15:20:22 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:20:22 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:20:22 --> Utf8 Class Initialized
INFO - 2019-07-01 15:20:22 --> URI Class Initialized
INFO - 2019-07-01 15:20:22 --> Router Class Initialized
INFO - 2019-07-01 15:20:22 --> Output Class Initialized
INFO - 2019-07-01 15:20:22 --> Security Class Initialized
DEBUG - 2019-07-01 15:20:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:20:22 --> Input Class Initialized
INFO - 2019-07-01 15:20:22 --> Language Class Initialized
INFO - 2019-07-01 15:20:22 --> Language Class Initialized
INFO - 2019-07-01 15:20:22 --> Config Class Initialized
INFO - 2019-07-01 15:20:22 --> Loader Class Initialized
DEBUG - 2019-07-01 15:20:22 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:20:23 --> Helper loaded: url_helper
INFO - 2019-07-01 15:20:23 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:20:23 --> Helper loaded: string_helper
INFO - 2019-07-01 15:20:23 --> Helper loaded: array_helper
INFO - 2019-07-01 15:20:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:20:23 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:20:23 --> Database Driver Class Initialized
INFO - 2019-07-01 15:20:23 --> Controller Class Initialized
INFO - 2019-07-01 21:20:23 --> Helper loaded: language_helper
INFO - 2019-07-01 21:20:23 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:20:23 --> Model Class Initialized
INFO - 2019-07-01 21:20:23 --> Model Class Initialized
INFO - 2019-07-01 21:20:23 --> Model Class Initialized
INFO - 2019-07-01 21:20:23 --> Model Class Initialized
INFO - 2019-07-01 21:20:23 --> Helper loaded: form_helper
INFO - 2019-07-01 21:20:23 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:20:23 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:20:23 --> Model Class Initialized
INFO - 2019-07-01 21:20:23 --> Model Class Initialized
INFO - 2019-07-01 21:20:23 --> Final output sent to browser
DEBUG - 2019-07-01 21:20:23 --> Total execution time: 1.4014
INFO - 2019-07-01 15:20:25 --> Config Class Initialized
INFO - 2019-07-01 15:20:25 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:20:25 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:20:25 --> Utf8 Class Initialized
INFO - 2019-07-01 15:20:25 --> URI Class Initialized
INFO - 2019-07-01 15:20:26 --> Router Class Initialized
INFO - 2019-07-01 15:20:26 --> Output Class Initialized
INFO - 2019-07-01 15:20:26 --> Security Class Initialized
DEBUG - 2019-07-01 15:20:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:20:26 --> Input Class Initialized
INFO - 2019-07-01 15:20:26 --> Language Class Initialized
INFO - 2019-07-01 15:20:26 --> Language Class Initialized
INFO - 2019-07-01 15:20:26 --> Config Class Initialized
INFO - 2019-07-01 15:20:26 --> Loader Class Initialized
DEBUG - 2019-07-01 15:20:26 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:20:26 --> Helper loaded: url_helper
INFO - 2019-07-01 15:20:26 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:20:26 --> Helper loaded: string_helper
INFO - 2019-07-01 15:20:26 --> Helper loaded: array_helper
INFO - 2019-07-01 15:20:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:20:26 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:20:26 --> Database Driver Class Initialized
INFO - 2019-07-01 15:20:26 --> Controller Class Initialized
INFO - 2019-07-01 21:20:26 --> Helper loaded: language_helper
INFO - 2019-07-01 21:20:26 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:20:26 --> Model Class Initialized
INFO - 2019-07-01 21:20:26 --> Model Class Initialized
INFO - 2019-07-01 21:20:26 --> Model Class Initialized
INFO - 2019-07-01 21:20:26 --> Model Class Initialized
INFO - 2019-07-01 21:20:26 --> Helper loaded: form_helper
INFO - 2019-07-01 21:20:26 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:20:26 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:20:26 --> Model Class Initialized
INFO - 2019-07-01 21:20:26 --> Model Class Initialized
INFO - 2019-07-01 21:20:26 --> Final output sent to browser
DEBUG - 2019-07-01 21:20:27 --> Total execution time: 1.1648
INFO - 2019-07-01 15:20:53 --> Config Class Initialized
INFO - 2019-07-01 15:20:53 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:20:53 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:20:53 --> Utf8 Class Initialized
INFO - 2019-07-01 15:20:53 --> URI Class Initialized
INFO - 2019-07-01 15:20:53 --> Router Class Initialized
INFO - 2019-07-01 15:20:53 --> Output Class Initialized
INFO - 2019-07-01 15:20:53 --> Security Class Initialized
DEBUG - 2019-07-01 15:20:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:20:53 --> Input Class Initialized
INFO - 2019-07-01 15:20:53 --> Language Class Initialized
INFO - 2019-07-01 15:20:53 --> Language Class Initialized
INFO - 2019-07-01 15:20:53 --> Config Class Initialized
INFO - 2019-07-01 15:20:53 --> Loader Class Initialized
DEBUG - 2019-07-01 15:20:53 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:20:53 --> Helper loaded: url_helper
INFO - 2019-07-01 15:20:53 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:20:53 --> Helper loaded: string_helper
INFO - 2019-07-01 15:20:53 --> Helper loaded: array_helper
INFO - 2019-07-01 15:20:53 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:20:53 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:20:53 --> Database Driver Class Initialized
INFO - 2019-07-01 15:20:54 --> Controller Class Initialized
INFO - 2019-07-01 21:20:54 --> Helper loaded: language_helper
INFO - 2019-07-01 21:20:54 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:20:54 --> Model Class Initialized
INFO - 2019-07-01 21:20:54 --> Model Class Initialized
INFO - 2019-07-01 21:20:54 --> Model Class Initialized
INFO - 2019-07-01 21:20:54 --> Model Class Initialized
INFO - 2019-07-01 21:20:54 --> Helper loaded: form_helper
INFO - 2019-07-01 21:20:54 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:20:54 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:20:54 --> Model Class Initialized
INFO - 2019-07-01 21:20:54 --> Model Class Initialized
INFO - 2019-07-01 21:20:54 --> Final output sent to browser
DEBUG - 2019-07-01 21:20:54 --> Total execution time: 1.3267
INFO - 2019-07-01 15:21:26 --> Config Class Initialized
INFO - 2019-07-01 15:21:26 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:21:26 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:21:26 --> Utf8 Class Initialized
INFO - 2019-07-01 15:21:26 --> URI Class Initialized
INFO - 2019-07-01 15:21:26 --> Router Class Initialized
INFO - 2019-07-01 15:21:26 --> Output Class Initialized
INFO - 2019-07-01 15:21:26 --> Security Class Initialized
DEBUG - 2019-07-01 15:21:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:21:26 --> Input Class Initialized
INFO - 2019-07-01 15:21:26 --> Language Class Initialized
INFO - 2019-07-01 15:21:26 --> Language Class Initialized
INFO - 2019-07-01 15:21:27 --> Config Class Initialized
INFO - 2019-07-01 15:21:27 --> Loader Class Initialized
DEBUG - 2019-07-01 15:21:27 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:21:27 --> Helper loaded: url_helper
INFO - 2019-07-01 15:21:27 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:21:27 --> Helper loaded: string_helper
INFO - 2019-07-01 15:21:27 --> Helper loaded: array_helper
INFO - 2019-07-01 15:21:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:21:27 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:21:27 --> Database Driver Class Initialized
INFO - 2019-07-01 15:21:27 --> Controller Class Initialized
INFO - 2019-07-01 21:21:27 --> Helper loaded: language_helper
INFO - 2019-07-01 21:21:27 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:21:27 --> Model Class Initialized
INFO - 2019-07-01 21:21:27 --> Model Class Initialized
INFO - 2019-07-01 21:21:27 --> Model Class Initialized
INFO - 2019-07-01 21:21:27 --> Model Class Initialized
INFO - 2019-07-01 21:21:27 --> Helper loaded: form_helper
INFO - 2019-07-01 21:21:27 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:21:27 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:21:27 --> Model Class Initialized
INFO - 2019-07-01 21:21:27 --> Model Class Initialized
INFO - 2019-07-01 21:21:27 --> Final output sent to browser
DEBUG - 2019-07-01 21:21:27 --> Total execution time: 1.1344
INFO - 2019-07-01 15:23:20 --> Config Class Initialized
INFO - 2019-07-01 15:23:20 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:23:20 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:23:20 --> Utf8 Class Initialized
INFO - 2019-07-01 15:23:20 --> URI Class Initialized
INFO - 2019-07-01 15:23:20 --> Router Class Initialized
INFO - 2019-07-01 15:23:20 --> Output Class Initialized
INFO - 2019-07-01 15:23:20 --> Security Class Initialized
DEBUG - 2019-07-01 15:23:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:23:20 --> Input Class Initialized
INFO - 2019-07-01 15:23:20 --> Language Class Initialized
INFO - 2019-07-01 15:23:20 --> Language Class Initialized
INFO - 2019-07-01 15:23:20 --> Config Class Initialized
INFO - 2019-07-01 15:23:20 --> Loader Class Initialized
DEBUG - 2019-07-01 15:23:20 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:23:20 --> Helper loaded: url_helper
INFO - 2019-07-01 15:23:20 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:23:20 --> Helper loaded: string_helper
INFO - 2019-07-01 15:23:20 --> Helper loaded: array_helper
INFO - 2019-07-01 15:23:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:23:21 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:23:21 --> Database Driver Class Initialized
INFO - 2019-07-01 15:23:21 --> Controller Class Initialized
INFO - 2019-07-01 21:23:21 --> Helper loaded: language_helper
INFO - 2019-07-01 21:23:21 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:23:21 --> Model Class Initialized
INFO - 2019-07-01 21:23:21 --> Model Class Initialized
INFO - 2019-07-01 21:23:21 --> Model Class Initialized
INFO - 2019-07-01 21:23:21 --> Model Class Initialized
INFO - 2019-07-01 21:23:21 --> Helper loaded: form_helper
INFO - 2019-07-01 21:23:21 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:23:21 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:23:21 --> Model Class Initialized
INFO - 2019-07-01 21:23:21 --> Model Class Initialized
ERROR - 2019-07-01 21:23:21 --> Severity: Notice --> Undefined index: product_id C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 118
ERROR - 2019-07-01 21:23:21 --> Severity: Notice --> Undefined index: product_id C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 142
ERROR - 2019-07-01 21:23:21 --> Severity: Notice --> Undefined index: qty C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 143
ERROR - 2019-07-01 21:23:21 --> Severity: Notice --> Undefined index: price C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 144
ERROR - 2019-07-01 21:23:21 --> Severity: Notice --> Undefined index: qty C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 145
ERROR - 2019-07-01 21:23:21 --> Severity: Notice --> Undefined index: price C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 145
ERROR - 2019-07-01 21:23:21 --> Severity: Notice --> Undefined index: description C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 146
ERROR - 2019-07-01 21:23:21 --> Query error: Column 'product_id' cannot be null - Invalid query: INSERT INTO `order_details` (`order_id`, `product_id`, `qty`, `price`, `sub_total`, `description_request`, `created_at`, `updated_at`) VALUES ('1', NULL, NULL, NULL, 0, NULL, '2019-07-01 21:23:21', '2019-07-01 21:23:21')
INFO - 2019-07-01 21:23:21 --> Language file loaded: language/english/db_lang.php
ERROR - 2019-07-01 21:23:21 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\crapi_admin\system\core\Exceptions.php:272) C:\xampp\htdocs\crapi_admin\system\core\Common.php 573
INFO - 2019-07-01 15:23:21 --> Config Class Initialized
INFO - 2019-07-01 15:23:21 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:23:21 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:23:21 --> Utf8 Class Initialized
INFO - 2019-07-01 15:23:21 --> URI Class Initialized
INFO - 2019-07-01 15:23:21 --> Router Class Initialized
INFO - 2019-07-01 15:23:21 --> Output Class Initialized
INFO - 2019-07-01 15:23:21 --> Security Class Initialized
DEBUG - 2019-07-01 15:23:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:23:21 --> Input Class Initialized
INFO - 2019-07-01 15:23:21 --> Language Class Initialized
INFO - 2019-07-01 15:23:21 --> Language Class Initialized
INFO - 2019-07-01 15:23:21 --> Config Class Initialized
INFO - 2019-07-01 15:23:21 --> Loader Class Initialized
DEBUG - 2019-07-01 15:23:21 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:23:22 --> Helper loaded: url_helper
INFO - 2019-07-01 15:23:22 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:23:22 --> Helper loaded: string_helper
INFO - 2019-07-01 15:23:22 --> Helper loaded: array_helper
INFO - 2019-07-01 15:23:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:23:22 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:23:22 --> Database Driver Class Initialized
INFO - 2019-07-01 15:23:22 --> Controller Class Initialized
INFO - 2019-07-01 21:23:22 --> Helper loaded: language_helper
INFO - 2019-07-01 21:23:22 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:23:22 --> Model Class Initialized
INFO - 2019-07-01 21:23:22 --> Model Class Initialized
INFO - 2019-07-01 21:23:22 --> Model Class Initialized
INFO - 2019-07-01 21:23:22 --> Model Class Initialized
INFO - 2019-07-01 21:23:22 --> Helper loaded: form_helper
INFO - 2019-07-01 21:23:22 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:23:22 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:23:22 --> Model Class Initialized
INFO - 2019-07-01 21:23:22 --> Model Class Initialized
ERROR - 2019-07-01 21:23:22 --> Severity: Notice --> Undefined index: product_id C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 118
ERROR - 2019-07-01 21:23:22 --> Severity: Notice --> Undefined index: product_id C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 142
ERROR - 2019-07-01 21:23:22 --> Severity: Notice --> Undefined index: qty C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 143
ERROR - 2019-07-01 21:23:22 --> Severity: Notice --> Undefined index: price C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 144
ERROR - 2019-07-01 21:23:22 --> Severity: Notice --> Undefined index: qty C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 145
ERROR - 2019-07-01 21:23:22 --> Severity: Notice --> Undefined index: price C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 145
ERROR - 2019-07-01 21:23:22 --> Severity: Notice --> Undefined index: description C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 146
ERROR - 2019-07-01 21:23:22 --> Query error: Column 'product_id' cannot be null - Invalid query: INSERT INTO `order_details` (`order_id`, `product_id`, `qty`, `price`, `sub_total`, `description_request`, `created_at`, `updated_at`) VALUES ('1', NULL, NULL, NULL, 0, NULL, '2019-07-01 21:23:22', '2019-07-01 21:23:22')
INFO - 2019-07-01 21:23:22 --> Language file loaded: language/english/db_lang.php
ERROR - 2019-07-01 21:23:22 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\crapi_admin\system\core\Exceptions.php:272) C:\xampp\htdocs\crapi_admin\system\core\Common.php 573
INFO - 2019-07-01 15:23:22 --> Config Class Initialized
INFO - 2019-07-01 15:23:22 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:23:22 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:23:22 --> Utf8 Class Initialized
INFO - 2019-07-01 15:23:22 --> URI Class Initialized
INFO - 2019-07-01 15:23:22 --> Router Class Initialized
INFO - 2019-07-01 15:23:22 --> Output Class Initialized
INFO - 2019-07-01 15:23:22 --> Security Class Initialized
DEBUG - 2019-07-01 15:23:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:23:22 --> Input Class Initialized
INFO - 2019-07-01 15:23:22 --> Language Class Initialized
INFO - 2019-07-01 15:23:22 --> Language Class Initialized
INFO - 2019-07-01 15:23:22 --> Config Class Initialized
INFO - 2019-07-01 15:23:22 --> Loader Class Initialized
DEBUG - 2019-07-01 15:23:22 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:23:22 --> Helper loaded: url_helper
INFO - 2019-07-01 15:23:22 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:23:22 --> Helper loaded: string_helper
INFO - 2019-07-01 15:23:23 --> Helper loaded: array_helper
INFO - 2019-07-01 15:23:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:23:23 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:23:23 --> Database Driver Class Initialized
INFO - 2019-07-01 15:23:23 --> Controller Class Initialized
INFO - 2019-07-01 21:23:23 --> Helper loaded: language_helper
INFO - 2019-07-01 21:23:23 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:23:23 --> Model Class Initialized
INFO - 2019-07-01 21:23:23 --> Model Class Initialized
INFO - 2019-07-01 21:23:23 --> Model Class Initialized
INFO - 2019-07-01 21:23:23 --> Model Class Initialized
INFO - 2019-07-01 21:23:23 --> Helper loaded: form_helper
INFO - 2019-07-01 21:23:23 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:23:23 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:23:23 --> Model Class Initialized
INFO - 2019-07-01 21:23:23 --> Model Class Initialized
ERROR - 2019-07-01 21:23:23 --> Severity: Notice --> Undefined index: product_id C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 118
ERROR - 2019-07-01 21:23:23 --> Severity: Notice --> Undefined index: product_id C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 142
ERROR - 2019-07-01 21:23:23 --> Severity: Notice --> Undefined index: qty C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 143
ERROR - 2019-07-01 21:23:23 --> Severity: Notice --> Undefined index: price C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 144
ERROR - 2019-07-01 21:23:23 --> Severity: Notice --> Undefined index: qty C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 145
ERROR - 2019-07-01 21:23:23 --> Severity: Notice --> Undefined index: price C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 145
ERROR - 2019-07-01 21:23:23 --> Severity: Notice --> Undefined index: description C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 146
ERROR - 2019-07-01 21:23:23 --> Query error: Column 'product_id' cannot be null - Invalid query: INSERT INTO `order_details` (`order_id`, `product_id`, `qty`, `price`, `sub_total`, `description_request`, `created_at`, `updated_at`) VALUES ('1', NULL, NULL, NULL, 0, NULL, '2019-07-01 21:23:23', '2019-07-01 21:23:23')
INFO - 2019-07-01 21:23:23 --> Language file loaded: language/english/db_lang.php
ERROR - 2019-07-01 21:23:23 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\crapi_admin\system\core\Exceptions.php:272) C:\xampp\htdocs\crapi_admin\system\core\Common.php 573
INFO - 2019-07-01 15:23:23 --> Config Class Initialized
INFO - 2019-07-01 15:23:23 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:23:23 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:23:23 --> Utf8 Class Initialized
INFO - 2019-07-01 15:23:23 --> URI Class Initialized
INFO - 2019-07-01 15:23:23 --> Router Class Initialized
INFO - 2019-07-01 15:23:23 --> Output Class Initialized
INFO - 2019-07-01 15:23:23 --> Security Class Initialized
DEBUG - 2019-07-01 15:23:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:23:23 --> Input Class Initialized
INFO - 2019-07-01 15:23:23 --> Language Class Initialized
INFO - 2019-07-01 15:23:23 --> Language Class Initialized
INFO - 2019-07-01 15:23:23 --> Config Class Initialized
INFO - 2019-07-01 15:23:23 --> Loader Class Initialized
DEBUG - 2019-07-01 15:23:23 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:23:23 --> Helper loaded: url_helper
INFO - 2019-07-01 15:23:23 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:23:23 --> Helper loaded: string_helper
INFO - 2019-07-01 15:23:23 --> Helper loaded: array_helper
INFO - 2019-07-01 15:23:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:23:23 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:23:24 --> Database Driver Class Initialized
INFO - 2019-07-01 15:23:24 --> Controller Class Initialized
INFO - 2019-07-01 21:23:24 --> Helper loaded: language_helper
INFO - 2019-07-01 21:23:24 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:23:24 --> Model Class Initialized
INFO - 2019-07-01 21:23:24 --> Model Class Initialized
INFO - 2019-07-01 21:23:24 --> Model Class Initialized
INFO - 2019-07-01 21:23:24 --> Model Class Initialized
INFO - 2019-07-01 21:23:24 --> Helper loaded: form_helper
INFO - 2019-07-01 21:23:24 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:23:24 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:23:24 --> Model Class Initialized
INFO - 2019-07-01 21:23:24 --> Model Class Initialized
ERROR - 2019-07-01 21:23:24 --> Severity: Notice --> Undefined index: product_id C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 118
ERROR - 2019-07-01 21:23:24 --> Severity: Notice --> Undefined index: product_id C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 142
ERROR - 2019-07-01 21:23:24 --> Severity: Notice --> Undefined index: qty C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 143
ERROR - 2019-07-01 21:23:24 --> Severity: Notice --> Undefined index: price C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 144
ERROR - 2019-07-01 21:23:24 --> Severity: Notice --> Undefined index: qty C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 145
ERROR - 2019-07-01 21:23:24 --> Severity: Notice --> Undefined index: price C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 145
ERROR - 2019-07-01 21:23:24 --> Severity: Notice --> Undefined index: description C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 146
ERROR - 2019-07-01 21:23:24 --> Query error: Column 'product_id' cannot be null - Invalid query: INSERT INTO `order_details` (`order_id`, `product_id`, `qty`, `price`, `sub_total`, `description_request`, `created_at`, `updated_at`) VALUES ('1', NULL, NULL, NULL, 0, NULL, '2019-07-01 21:23:24', '2019-07-01 21:23:24')
INFO - 2019-07-01 21:23:24 --> Language file loaded: language/english/db_lang.php
ERROR - 2019-07-01 21:23:24 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\crapi_admin\system\core\Exceptions.php:272) C:\xampp\htdocs\crapi_admin\system\core\Common.php 573
INFO - 2019-07-01 15:23:24 --> Config Class Initialized
INFO - 2019-07-01 15:23:24 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:23:24 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:23:24 --> Utf8 Class Initialized
INFO - 2019-07-01 15:23:24 --> URI Class Initialized
INFO - 2019-07-01 15:23:24 --> Router Class Initialized
INFO - 2019-07-01 15:23:24 --> Output Class Initialized
INFO - 2019-07-01 15:23:24 --> Security Class Initialized
DEBUG - 2019-07-01 15:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:23:24 --> Input Class Initialized
INFO - 2019-07-01 15:23:24 --> Language Class Initialized
INFO - 2019-07-01 15:23:24 --> Language Class Initialized
INFO - 2019-07-01 15:23:24 --> Config Class Initialized
INFO - 2019-07-01 15:23:24 --> Loader Class Initialized
DEBUG - 2019-07-01 15:23:24 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:23:24 --> Helper loaded: url_helper
INFO - 2019-07-01 15:23:24 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:23:24 --> Helper loaded: string_helper
INFO - 2019-07-01 15:23:24 --> Helper loaded: array_helper
INFO - 2019-07-01 15:23:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:23:24 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:23:24 --> Database Driver Class Initialized
INFO - 2019-07-01 15:23:24 --> Controller Class Initialized
INFO - 2019-07-01 21:23:25 --> Helper loaded: language_helper
INFO - 2019-07-01 21:23:25 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:23:25 --> Model Class Initialized
INFO - 2019-07-01 21:23:25 --> Model Class Initialized
INFO - 2019-07-01 21:23:25 --> Model Class Initialized
INFO - 2019-07-01 21:23:25 --> Model Class Initialized
INFO - 2019-07-01 21:23:25 --> Helper loaded: form_helper
INFO - 2019-07-01 21:23:25 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:23:25 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:23:25 --> Model Class Initialized
INFO - 2019-07-01 21:23:25 --> Model Class Initialized
ERROR - 2019-07-01 21:23:25 --> Severity: Notice --> Undefined index: product_id C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 118
ERROR - 2019-07-01 21:23:25 --> Severity: Notice --> Undefined index: product_id C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 142
ERROR - 2019-07-01 21:23:25 --> Severity: Notice --> Undefined index: qty C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 143
ERROR - 2019-07-01 21:23:25 --> Severity: Notice --> Undefined index: price C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 144
ERROR - 2019-07-01 21:23:25 --> Severity: Notice --> Undefined index: qty C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 145
ERROR - 2019-07-01 21:23:25 --> Severity: Notice --> Undefined index: price C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 145
ERROR - 2019-07-01 21:23:25 --> Severity: Notice --> Undefined index: description C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 146
ERROR - 2019-07-01 21:23:25 --> Query error: Column 'product_id' cannot be null - Invalid query: INSERT INTO `order_details` (`order_id`, `product_id`, `qty`, `price`, `sub_total`, `description_request`, `created_at`, `updated_at`) VALUES ('1', NULL, NULL, NULL, 0, NULL, '2019-07-01 21:23:25', '2019-07-01 21:23:25')
INFO - 2019-07-01 21:23:25 --> Language file loaded: language/english/db_lang.php
ERROR - 2019-07-01 21:23:25 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\crapi_admin\system\core\Exceptions.php:272) C:\xampp\htdocs\crapi_admin\system\core\Common.php 573
INFO - 2019-07-01 15:23:25 --> Config Class Initialized
INFO - 2019-07-01 15:23:25 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:23:25 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:23:25 --> Utf8 Class Initialized
INFO - 2019-07-01 15:23:25 --> URI Class Initialized
INFO - 2019-07-01 15:23:25 --> Router Class Initialized
INFO - 2019-07-01 15:23:25 --> Output Class Initialized
INFO - 2019-07-01 15:23:25 --> Security Class Initialized
DEBUG - 2019-07-01 15:23:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:23:25 --> Input Class Initialized
INFO - 2019-07-01 15:23:25 --> Language Class Initialized
INFO - 2019-07-01 15:23:25 --> Language Class Initialized
INFO - 2019-07-01 15:23:25 --> Config Class Initialized
INFO - 2019-07-01 15:23:25 --> Loader Class Initialized
DEBUG - 2019-07-01 15:23:25 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:23:25 --> Helper loaded: url_helper
INFO - 2019-07-01 15:23:25 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:23:25 --> Helper loaded: string_helper
INFO - 2019-07-01 15:23:25 --> Helper loaded: array_helper
INFO - 2019-07-01 15:23:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:23:25 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:23:26 --> Database Driver Class Initialized
INFO - 2019-07-01 15:23:26 --> Controller Class Initialized
INFO - 2019-07-01 21:23:26 --> Helper loaded: language_helper
INFO - 2019-07-01 21:23:26 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:23:26 --> Model Class Initialized
INFO - 2019-07-01 21:23:26 --> Model Class Initialized
INFO - 2019-07-01 21:23:26 --> Model Class Initialized
INFO - 2019-07-01 21:23:26 --> Model Class Initialized
INFO - 2019-07-01 21:23:26 --> Helper loaded: form_helper
INFO - 2019-07-01 21:23:26 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:23:26 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:23:26 --> Model Class Initialized
INFO - 2019-07-01 21:23:26 --> Model Class Initialized
ERROR - 2019-07-01 21:23:26 --> Severity: Notice --> Undefined index: product_id C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 118
ERROR - 2019-07-01 21:23:26 --> Severity: Notice --> Undefined index: product_id C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 142
ERROR - 2019-07-01 21:23:26 --> Severity: Notice --> Undefined index: qty C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 143
ERROR - 2019-07-01 21:23:26 --> Severity: Notice --> Undefined index: price C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 144
ERROR - 2019-07-01 21:23:26 --> Severity: Notice --> Undefined index: qty C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 145
ERROR - 2019-07-01 21:23:26 --> Severity: Notice --> Undefined index: price C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 145
ERROR - 2019-07-01 21:23:26 --> Severity: Notice --> Undefined index: description C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 146
ERROR - 2019-07-01 21:23:26 --> Query error: Column 'product_id' cannot be null - Invalid query: INSERT INTO `order_details` (`order_id`, `product_id`, `qty`, `price`, `sub_total`, `description_request`, `created_at`, `updated_at`) VALUES ('1', NULL, NULL, NULL, 0, NULL, '2019-07-01 21:23:26', '2019-07-01 21:23:26')
INFO - 2019-07-01 21:23:26 --> Language file loaded: language/english/db_lang.php
ERROR - 2019-07-01 21:23:26 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\crapi_admin\system\core\Exceptions.php:272) C:\xampp\htdocs\crapi_admin\system\core\Common.php 573
INFO - 2019-07-01 15:23:26 --> Config Class Initialized
INFO - 2019-07-01 15:23:26 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:23:26 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:23:26 --> Utf8 Class Initialized
INFO - 2019-07-01 15:23:26 --> URI Class Initialized
INFO - 2019-07-01 15:23:26 --> Router Class Initialized
INFO - 2019-07-01 15:23:26 --> Output Class Initialized
INFO - 2019-07-01 15:23:26 --> Security Class Initialized
DEBUG - 2019-07-01 15:23:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:23:26 --> Input Class Initialized
INFO - 2019-07-01 15:23:26 --> Language Class Initialized
INFO - 2019-07-01 15:23:26 --> Language Class Initialized
INFO - 2019-07-01 15:23:26 --> Config Class Initialized
INFO - 2019-07-01 15:23:26 --> Loader Class Initialized
DEBUG - 2019-07-01 15:23:26 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:23:26 --> Helper loaded: url_helper
INFO - 2019-07-01 15:23:26 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:23:26 --> Helper loaded: string_helper
INFO - 2019-07-01 15:23:26 --> Helper loaded: array_helper
INFO - 2019-07-01 15:23:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:23:26 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:23:26 --> Database Driver Class Initialized
INFO - 2019-07-01 15:23:26 --> Controller Class Initialized
INFO - 2019-07-01 21:23:26 --> Helper loaded: language_helper
INFO - 2019-07-01 21:23:27 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:23:27 --> Model Class Initialized
INFO - 2019-07-01 21:23:27 --> Model Class Initialized
INFO - 2019-07-01 21:23:27 --> Model Class Initialized
INFO - 2019-07-01 21:23:27 --> Model Class Initialized
INFO - 2019-07-01 21:23:27 --> Helper loaded: form_helper
INFO - 2019-07-01 21:23:27 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:23:27 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:23:27 --> Model Class Initialized
INFO - 2019-07-01 21:23:27 --> Model Class Initialized
ERROR - 2019-07-01 21:23:27 --> Severity: Notice --> Undefined index: product_id C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 118
ERROR - 2019-07-01 21:23:27 --> Severity: Notice --> Undefined index: product_id C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 142
ERROR - 2019-07-01 21:23:27 --> Severity: Notice --> Undefined index: qty C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 143
ERROR - 2019-07-01 21:23:27 --> Severity: Notice --> Undefined index: price C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 144
ERROR - 2019-07-01 21:23:27 --> Severity: Notice --> Undefined index: qty C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 145
ERROR - 2019-07-01 21:23:27 --> Severity: Notice --> Undefined index: price C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 145
ERROR - 2019-07-01 21:23:27 --> Severity: Notice --> Undefined index: description C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 146
ERROR - 2019-07-01 21:23:27 --> Query error: Column 'product_id' cannot be null - Invalid query: INSERT INTO `order_details` (`order_id`, `product_id`, `qty`, `price`, `sub_total`, `description_request`, `created_at`, `updated_at`) VALUES ('1', NULL, NULL, NULL, 0, NULL, '2019-07-01 21:23:27', '2019-07-01 21:23:27')
INFO - 2019-07-01 21:23:27 --> Language file loaded: language/english/db_lang.php
ERROR - 2019-07-01 21:23:27 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\crapi_admin\system\core\Exceptions.php:272) C:\xampp\htdocs\crapi_admin\system\core\Common.php 573
INFO - 2019-07-01 15:23:27 --> Config Class Initialized
INFO - 2019-07-01 15:23:27 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:23:27 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:23:27 --> Utf8 Class Initialized
INFO - 2019-07-01 15:23:27 --> URI Class Initialized
INFO - 2019-07-01 15:23:27 --> Router Class Initialized
INFO - 2019-07-01 15:23:27 --> Output Class Initialized
INFO - 2019-07-01 15:23:27 --> Security Class Initialized
DEBUG - 2019-07-01 15:23:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:23:27 --> Input Class Initialized
INFO - 2019-07-01 15:23:27 --> Language Class Initialized
INFO - 2019-07-01 15:23:27 --> Language Class Initialized
INFO - 2019-07-01 15:23:27 --> Config Class Initialized
INFO - 2019-07-01 15:23:27 --> Loader Class Initialized
DEBUG - 2019-07-01 15:23:27 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:23:27 --> Helper loaded: url_helper
INFO - 2019-07-01 15:23:27 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:23:27 --> Helper loaded: string_helper
INFO - 2019-07-01 15:23:27 --> Helper loaded: array_helper
INFO - 2019-07-01 15:23:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:23:27 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:23:28 --> Database Driver Class Initialized
INFO - 2019-07-01 15:23:28 --> Controller Class Initialized
INFO - 2019-07-01 21:23:28 --> Helper loaded: language_helper
INFO - 2019-07-01 21:23:28 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:23:28 --> Model Class Initialized
INFO - 2019-07-01 21:23:28 --> Model Class Initialized
INFO - 2019-07-01 21:23:28 --> Model Class Initialized
INFO - 2019-07-01 21:23:28 --> Model Class Initialized
INFO - 2019-07-01 21:23:28 --> Helper loaded: form_helper
INFO - 2019-07-01 21:23:28 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:23:28 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:23:28 --> Model Class Initialized
INFO - 2019-07-01 21:23:28 --> Model Class Initialized
ERROR - 2019-07-01 21:23:28 --> Severity: Notice --> Undefined index: product_id C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 118
ERROR - 2019-07-01 21:23:28 --> Severity: Notice --> Undefined index: product_id C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 142
ERROR - 2019-07-01 21:23:28 --> Severity: Notice --> Undefined index: qty C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 143
ERROR - 2019-07-01 21:23:28 --> Severity: Notice --> Undefined index: price C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 144
ERROR - 2019-07-01 21:23:28 --> Severity: Notice --> Undefined index: qty C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 145
ERROR - 2019-07-01 21:23:28 --> Severity: Notice --> Undefined index: price C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 145
ERROR - 2019-07-01 21:23:28 --> Severity: Notice --> Undefined index: description C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 146
ERROR - 2019-07-01 21:23:28 --> Query error: Column 'product_id' cannot be null - Invalid query: INSERT INTO `order_details` (`order_id`, `product_id`, `qty`, `price`, `sub_total`, `description_request`, `created_at`, `updated_at`) VALUES ('1', NULL, NULL, NULL, 0, NULL, '2019-07-01 21:23:28', '2019-07-01 21:23:28')
INFO - 2019-07-01 21:23:28 --> Language file loaded: language/english/db_lang.php
ERROR - 2019-07-01 21:23:28 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\crapi_admin\system\core\Exceptions.php:272) C:\xampp\htdocs\crapi_admin\system\core\Common.php 573
INFO - 2019-07-01 15:23:28 --> Config Class Initialized
INFO - 2019-07-01 15:23:28 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:23:28 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:23:28 --> Utf8 Class Initialized
INFO - 2019-07-01 15:23:28 --> URI Class Initialized
INFO - 2019-07-01 15:23:28 --> Router Class Initialized
INFO - 2019-07-01 15:23:28 --> Output Class Initialized
INFO - 2019-07-01 15:23:28 --> Security Class Initialized
DEBUG - 2019-07-01 15:23:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:23:28 --> Input Class Initialized
INFO - 2019-07-01 15:23:28 --> Language Class Initialized
INFO - 2019-07-01 15:23:28 --> Language Class Initialized
INFO - 2019-07-01 15:23:28 --> Config Class Initialized
INFO - 2019-07-01 15:23:28 --> Loader Class Initialized
DEBUG - 2019-07-01 15:23:28 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:23:28 --> Helper loaded: url_helper
INFO - 2019-07-01 15:23:28 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:23:28 --> Helper loaded: string_helper
INFO - 2019-07-01 15:23:29 --> Helper loaded: array_helper
INFO - 2019-07-01 15:23:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:23:29 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:23:29 --> Database Driver Class Initialized
INFO - 2019-07-01 15:23:29 --> Controller Class Initialized
INFO - 2019-07-01 21:23:29 --> Helper loaded: language_helper
INFO - 2019-07-01 21:23:29 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:23:29 --> Model Class Initialized
INFO - 2019-07-01 21:23:29 --> Model Class Initialized
INFO - 2019-07-01 21:23:29 --> Model Class Initialized
INFO - 2019-07-01 21:23:29 --> Model Class Initialized
INFO - 2019-07-01 21:23:29 --> Helper loaded: form_helper
INFO - 2019-07-01 21:23:29 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:23:29 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:23:29 --> Model Class Initialized
INFO - 2019-07-01 21:23:29 --> Model Class Initialized
ERROR - 2019-07-01 21:23:29 --> Severity: Notice --> Undefined index: product_id C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 118
ERROR - 2019-07-01 21:23:29 --> Severity: Notice --> Undefined index: product_id C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 142
ERROR - 2019-07-01 21:23:29 --> Severity: Notice --> Undefined index: qty C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 143
ERROR - 2019-07-01 21:23:29 --> Severity: Notice --> Undefined index: price C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 144
ERROR - 2019-07-01 21:23:29 --> Severity: Notice --> Undefined index: qty C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 145
ERROR - 2019-07-01 21:23:29 --> Severity: Notice --> Undefined index: price C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 145
ERROR - 2019-07-01 21:23:29 --> Severity: Notice --> Undefined index: description C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 146
ERROR - 2019-07-01 21:23:29 --> Query error: Column 'product_id' cannot be null - Invalid query: INSERT INTO `order_details` (`order_id`, `product_id`, `qty`, `price`, `sub_total`, `description_request`, `created_at`, `updated_at`) VALUES ('1', NULL, NULL, NULL, 0, NULL, '2019-07-01 21:23:29', '2019-07-01 21:23:29')
INFO - 2019-07-01 21:23:29 --> Language file loaded: language/english/db_lang.php
ERROR - 2019-07-01 21:23:29 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\crapi_admin\system\core\Exceptions.php:272) C:\xampp\htdocs\crapi_admin\system\core\Common.php 573
INFO - 2019-07-01 15:23:29 --> Config Class Initialized
INFO - 2019-07-01 15:23:29 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:23:29 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:23:29 --> Utf8 Class Initialized
INFO - 2019-07-01 15:23:29 --> URI Class Initialized
INFO - 2019-07-01 15:23:29 --> Router Class Initialized
INFO - 2019-07-01 15:23:29 --> Output Class Initialized
INFO - 2019-07-01 15:23:29 --> Security Class Initialized
DEBUG - 2019-07-01 15:23:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:23:29 --> Input Class Initialized
INFO - 2019-07-01 15:23:29 --> Language Class Initialized
INFO - 2019-07-01 15:23:29 --> Language Class Initialized
INFO - 2019-07-01 15:23:29 --> Config Class Initialized
INFO - 2019-07-01 15:23:29 --> Loader Class Initialized
DEBUG - 2019-07-01 15:23:29 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:23:29 --> Helper loaded: url_helper
INFO - 2019-07-01 15:23:30 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:23:30 --> Helper loaded: string_helper
INFO - 2019-07-01 15:23:30 --> Helper loaded: array_helper
INFO - 2019-07-01 15:23:30 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:23:30 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:23:30 --> Database Driver Class Initialized
INFO - 2019-07-01 15:23:30 --> Controller Class Initialized
INFO - 2019-07-01 21:23:30 --> Helper loaded: language_helper
INFO - 2019-07-01 21:23:30 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:23:30 --> Model Class Initialized
INFO - 2019-07-01 21:23:30 --> Model Class Initialized
INFO - 2019-07-01 21:23:30 --> Model Class Initialized
INFO - 2019-07-01 21:23:30 --> Model Class Initialized
INFO - 2019-07-01 21:23:30 --> Helper loaded: form_helper
INFO - 2019-07-01 21:23:30 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:23:30 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:23:30 --> Model Class Initialized
INFO - 2019-07-01 21:23:30 --> Model Class Initialized
ERROR - 2019-07-01 21:23:30 --> Severity: Notice --> Undefined index: product_id C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 118
ERROR - 2019-07-01 21:23:30 --> Severity: Notice --> Undefined index: product_id C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 142
ERROR - 2019-07-01 21:23:30 --> Severity: Notice --> Undefined index: qty C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 143
ERROR - 2019-07-01 21:23:30 --> Severity: Notice --> Undefined index: price C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 144
ERROR - 2019-07-01 21:23:30 --> Severity: Notice --> Undefined index: qty C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 145
ERROR - 2019-07-01 21:23:30 --> Severity: Notice --> Undefined index: price C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 145
ERROR - 2019-07-01 21:23:30 --> Severity: Notice --> Undefined index: description C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 146
ERROR - 2019-07-01 21:23:30 --> Query error: Column 'product_id' cannot be null - Invalid query: INSERT INTO `order_details` (`order_id`, `product_id`, `qty`, `price`, `sub_total`, `description_request`, `created_at`, `updated_at`) VALUES ('1', NULL, NULL, NULL, 0, NULL, '2019-07-01 21:23:30', '2019-07-01 21:23:30')
INFO - 2019-07-01 21:23:30 --> Language file loaded: language/english/db_lang.php
ERROR - 2019-07-01 21:23:30 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\crapi_admin\system\core\Exceptions.php:272) C:\xampp\htdocs\crapi_admin\system\core\Common.php 573
INFO - 2019-07-01 15:23:30 --> Config Class Initialized
INFO - 2019-07-01 15:23:30 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:23:30 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:23:30 --> Utf8 Class Initialized
INFO - 2019-07-01 15:23:30 --> URI Class Initialized
INFO - 2019-07-01 15:23:30 --> Router Class Initialized
INFO - 2019-07-01 15:23:30 --> Output Class Initialized
INFO - 2019-07-01 15:23:30 --> Security Class Initialized
DEBUG - 2019-07-01 15:23:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:23:30 --> Input Class Initialized
INFO - 2019-07-01 15:23:30 --> Language Class Initialized
INFO - 2019-07-01 15:23:30 --> Language Class Initialized
INFO - 2019-07-01 15:23:30 --> Config Class Initialized
INFO - 2019-07-01 15:23:30 --> Loader Class Initialized
DEBUG - 2019-07-01 15:23:31 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:23:31 --> Helper loaded: url_helper
INFO - 2019-07-01 15:23:31 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:23:31 --> Helper loaded: string_helper
INFO - 2019-07-01 15:23:31 --> Helper loaded: array_helper
INFO - 2019-07-01 15:23:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:23:31 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:23:31 --> Database Driver Class Initialized
INFO - 2019-07-01 15:23:31 --> Controller Class Initialized
INFO - 2019-07-01 21:23:31 --> Helper loaded: language_helper
INFO - 2019-07-01 21:23:31 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:23:31 --> Model Class Initialized
INFO - 2019-07-01 21:23:31 --> Model Class Initialized
INFO - 2019-07-01 21:23:31 --> Model Class Initialized
INFO - 2019-07-01 21:23:31 --> Model Class Initialized
INFO - 2019-07-01 21:23:31 --> Helper loaded: form_helper
INFO - 2019-07-01 21:23:31 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:23:31 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:23:31 --> Model Class Initialized
INFO - 2019-07-01 21:23:31 --> Model Class Initialized
ERROR - 2019-07-01 21:23:31 --> Severity: Notice --> Undefined index: product_id C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 118
ERROR - 2019-07-01 21:23:31 --> Severity: Notice --> Undefined index: product_id C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 142
ERROR - 2019-07-01 21:23:31 --> Severity: Notice --> Undefined index: qty C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 143
ERROR - 2019-07-01 21:23:31 --> Severity: Notice --> Undefined index: price C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 144
ERROR - 2019-07-01 21:23:31 --> Severity: Notice --> Undefined index: qty C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 145
ERROR - 2019-07-01 21:23:31 --> Severity: Notice --> Undefined index: price C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 145
ERROR - 2019-07-01 21:23:31 --> Severity: Notice --> Undefined index: description C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 146
ERROR - 2019-07-01 21:23:31 --> Query error: Column 'product_id' cannot be null - Invalid query: INSERT INTO `order_details` (`order_id`, `product_id`, `qty`, `price`, `sub_total`, `description_request`, `created_at`, `updated_at`) VALUES ('1', NULL, NULL, NULL, 0, NULL, '2019-07-01 21:23:31', '2019-07-01 21:23:31')
INFO - 2019-07-01 21:23:31 --> Language file loaded: language/english/db_lang.php
ERROR - 2019-07-01 21:23:31 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\crapi_admin\system\core\Exceptions.php:272) C:\xampp\htdocs\crapi_admin\system\core\Common.php 573
INFO - 2019-07-01 15:23:31 --> Config Class Initialized
INFO - 2019-07-01 15:23:31 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:23:31 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:23:31 --> Utf8 Class Initialized
INFO - 2019-07-01 15:23:31 --> URI Class Initialized
INFO - 2019-07-01 15:23:31 --> Router Class Initialized
INFO - 2019-07-01 15:23:31 --> Output Class Initialized
INFO - 2019-07-01 15:23:31 --> Security Class Initialized
DEBUG - 2019-07-01 15:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:23:31 --> Input Class Initialized
INFO - 2019-07-01 15:23:31 --> Language Class Initialized
INFO - 2019-07-01 15:23:31 --> Language Class Initialized
INFO - 2019-07-01 15:23:31 --> Config Class Initialized
INFO - 2019-07-01 15:23:31 --> Loader Class Initialized
DEBUG - 2019-07-01 15:23:31 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:23:32 --> Helper loaded: url_helper
INFO - 2019-07-01 15:23:32 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:23:32 --> Helper loaded: string_helper
INFO - 2019-07-01 15:23:32 --> Helper loaded: array_helper
INFO - 2019-07-01 15:23:32 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:23:32 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:23:32 --> Database Driver Class Initialized
INFO - 2019-07-01 15:23:32 --> Controller Class Initialized
INFO - 2019-07-01 21:23:32 --> Helper loaded: language_helper
INFO - 2019-07-01 21:23:32 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:23:32 --> Model Class Initialized
INFO - 2019-07-01 21:23:32 --> Model Class Initialized
INFO - 2019-07-01 21:23:32 --> Model Class Initialized
INFO - 2019-07-01 21:23:32 --> Model Class Initialized
INFO - 2019-07-01 21:23:32 --> Helper loaded: form_helper
INFO - 2019-07-01 21:23:32 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:23:32 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:23:32 --> Model Class Initialized
INFO - 2019-07-01 21:23:32 --> Model Class Initialized
ERROR - 2019-07-01 21:23:32 --> Severity: Notice --> Undefined index: product_id C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 118
ERROR - 2019-07-01 21:23:32 --> Severity: Notice --> Undefined index: product_id C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 142
ERROR - 2019-07-01 21:23:32 --> Severity: Notice --> Undefined index: qty C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 143
ERROR - 2019-07-01 21:23:32 --> Severity: Notice --> Undefined index: price C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 144
ERROR - 2019-07-01 21:23:32 --> Severity: Notice --> Undefined index: qty C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 145
ERROR - 2019-07-01 21:23:32 --> Severity: Notice --> Undefined index: price C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 145
ERROR - 2019-07-01 21:23:32 --> Severity: Notice --> Undefined index: description C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 146
ERROR - 2019-07-01 21:23:32 --> Query error: Column 'product_id' cannot be null - Invalid query: INSERT INTO `order_details` (`order_id`, `product_id`, `qty`, `price`, `sub_total`, `description_request`, `created_at`, `updated_at`) VALUES ('1', NULL, NULL, NULL, 0, NULL, '2019-07-01 21:23:32', '2019-07-01 21:23:32')
INFO - 2019-07-01 21:23:32 --> Language file loaded: language/english/db_lang.php
ERROR - 2019-07-01 21:23:32 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\crapi_admin\system\core\Exceptions.php:272) C:\xampp\htdocs\crapi_admin\system\core\Common.php 573
INFO - 2019-07-01 15:23:32 --> Config Class Initialized
INFO - 2019-07-01 15:23:32 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:23:32 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:23:32 --> Utf8 Class Initialized
INFO - 2019-07-01 15:23:32 --> URI Class Initialized
INFO - 2019-07-01 15:23:32 --> Router Class Initialized
INFO - 2019-07-01 15:23:32 --> Output Class Initialized
INFO - 2019-07-01 15:23:32 --> Security Class Initialized
DEBUG - 2019-07-01 15:23:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:23:32 --> Input Class Initialized
INFO - 2019-07-01 15:23:32 --> Language Class Initialized
INFO - 2019-07-01 15:23:32 --> Language Class Initialized
INFO - 2019-07-01 15:23:32 --> Config Class Initialized
INFO - 2019-07-01 15:23:32 --> Loader Class Initialized
DEBUG - 2019-07-01 15:23:32 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:23:32 --> Helper loaded: url_helper
INFO - 2019-07-01 15:23:32 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:23:32 --> Helper loaded: string_helper
INFO - 2019-07-01 15:23:32 --> Helper loaded: array_helper
INFO - 2019-07-01 15:23:32 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:23:33 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:23:33 --> Database Driver Class Initialized
INFO - 2019-07-01 15:23:33 --> Controller Class Initialized
INFO - 2019-07-01 21:23:33 --> Helper loaded: language_helper
INFO - 2019-07-01 21:23:33 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:23:33 --> Model Class Initialized
INFO - 2019-07-01 21:23:33 --> Model Class Initialized
INFO - 2019-07-01 21:23:33 --> Model Class Initialized
INFO - 2019-07-01 21:23:33 --> Model Class Initialized
INFO - 2019-07-01 21:23:33 --> Helper loaded: form_helper
INFO - 2019-07-01 21:23:33 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:23:33 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:23:33 --> Model Class Initialized
INFO - 2019-07-01 21:23:33 --> Model Class Initialized
ERROR - 2019-07-01 21:23:33 --> Severity: Notice --> Undefined index: product_id C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 118
ERROR - 2019-07-01 21:23:33 --> Severity: Notice --> Undefined index: product_id C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 142
ERROR - 2019-07-01 21:23:33 --> Severity: Notice --> Undefined index: qty C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 143
ERROR - 2019-07-01 21:23:33 --> Severity: Notice --> Undefined index: price C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 144
ERROR - 2019-07-01 21:23:33 --> Severity: Notice --> Undefined index: qty C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 145
ERROR - 2019-07-01 21:23:33 --> Severity: Notice --> Undefined index: price C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 145
ERROR - 2019-07-01 21:23:33 --> Severity: Notice --> Undefined index: description C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 146
ERROR - 2019-07-01 21:23:33 --> Query error: Column 'product_id' cannot be null - Invalid query: INSERT INTO `order_details` (`order_id`, `product_id`, `qty`, `price`, `sub_total`, `description_request`, `created_at`, `updated_at`) VALUES ('1', NULL, NULL, NULL, 0, NULL, '2019-07-01 21:23:33', '2019-07-01 21:23:33')
INFO - 2019-07-01 21:23:33 --> Language file loaded: language/english/db_lang.php
ERROR - 2019-07-01 21:23:33 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\crapi_admin\system\core\Exceptions.php:272) C:\xampp\htdocs\crapi_admin\system\core\Common.php 573
INFO - 2019-07-01 15:23:33 --> Config Class Initialized
INFO - 2019-07-01 15:23:33 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:23:33 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:23:33 --> Utf8 Class Initialized
INFO - 2019-07-01 15:23:33 --> URI Class Initialized
INFO - 2019-07-01 15:23:33 --> Router Class Initialized
INFO - 2019-07-01 15:23:33 --> Output Class Initialized
INFO - 2019-07-01 15:23:33 --> Security Class Initialized
DEBUG - 2019-07-01 15:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:23:33 --> Input Class Initialized
INFO - 2019-07-01 15:23:33 --> Language Class Initialized
INFO - 2019-07-01 15:23:33 --> Language Class Initialized
INFO - 2019-07-01 15:23:33 --> Config Class Initialized
INFO - 2019-07-01 15:23:33 --> Loader Class Initialized
DEBUG - 2019-07-01 15:23:33 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:23:33 --> Helper loaded: url_helper
INFO - 2019-07-01 15:23:33 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:23:33 --> Helper loaded: string_helper
INFO - 2019-07-01 15:23:34 --> Helper loaded: array_helper
INFO - 2019-07-01 15:23:34 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:23:34 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:23:34 --> Database Driver Class Initialized
INFO - 2019-07-01 15:23:34 --> Controller Class Initialized
INFO - 2019-07-01 21:23:34 --> Helper loaded: language_helper
INFO - 2019-07-01 21:23:34 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:23:34 --> Model Class Initialized
INFO - 2019-07-01 21:23:34 --> Model Class Initialized
INFO - 2019-07-01 21:23:34 --> Model Class Initialized
INFO - 2019-07-01 21:23:34 --> Model Class Initialized
INFO - 2019-07-01 21:23:34 --> Helper loaded: form_helper
INFO - 2019-07-01 21:23:34 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:23:34 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:23:34 --> Model Class Initialized
INFO - 2019-07-01 21:23:34 --> Model Class Initialized
ERROR - 2019-07-01 21:23:34 --> Severity: Notice --> Undefined index: product_id C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 118
ERROR - 2019-07-01 21:23:34 --> Severity: Notice --> Undefined index: product_id C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 142
ERROR - 2019-07-01 21:23:34 --> Severity: Notice --> Undefined index: qty C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 143
ERROR - 2019-07-01 21:23:34 --> Severity: Notice --> Undefined index: price C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 144
ERROR - 2019-07-01 21:23:34 --> Severity: Notice --> Undefined index: qty C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 145
ERROR - 2019-07-01 21:23:34 --> Severity: Notice --> Undefined index: price C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 145
ERROR - 2019-07-01 21:23:34 --> Severity: Notice --> Undefined index: description C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 146
ERROR - 2019-07-01 21:23:34 --> Query error: Column 'product_id' cannot be null - Invalid query: INSERT INTO `order_details` (`order_id`, `product_id`, `qty`, `price`, `sub_total`, `description_request`, `created_at`, `updated_at`) VALUES ('1', NULL, NULL, NULL, 0, NULL, '2019-07-01 21:23:34', '2019-07-01 21:23:34')
INFO - 2019-07-01 21:23:34 --> Language file loaded: language/english/db_lang.php
ERROR - 2019-07-01 21:23:34 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\crapi_admin\system\core\Exceptions.php:272) C:\xampp\htdocs\crapi_admin\system\core\Common.php 573
INFO - 2019-07-01 15:23:34 --> Config Class Initialized
INFO - 2019-07-01 15:23:34 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:23:34 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:23:34 --> Utf8 Class Initialized
INFO - 2019-07-01 15:23:34 --> URI Class Initialized
INFO - 2019-07-01 15:23:34 --> Router Class Initialized
INFO - 2019-07-01 15:23:34 --> Output Class Initialized
INFO - 2019-07-01 15:23:34 --> Security Class Initialized
DEBUG - 2019-07-01 15:23:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:23:34 --> Input Class Initialized
INFO - 2019-07-01 15:23:34 --> Language Class Initialized
INFO - 2019-07-01 15:23:34 --> Language Class Initialized
INFO - 2019-07-01 15:23:34 --> Config Class Initialized
INFO - 2019-07-01 15:23:34 --> Loader Class Initialized
DEBUG - 2019-07-01 15:23:34 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:23:35 --> Helper loaded: url_helper
INFO - 2019-07-01 15:23:35 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:23:35 --> Helper loaded: string_helper
INFO - 2019-07-01 15:23:35 --> Helper loaded: array_helper
INFO - 2019-07-01 15:23:35 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:23:35 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:23:35 --> Database Driver Class Initialized
INFO - 2019-07-01 15:23:35 --> Controller Class Initialized
INFO - 2019-07-01 21:23:35 --> Helper loaded: language_helper
INFO - 2019-07-01 21:23:35 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:23:35 --> Model Class Initialized
INFO - 2019-07-01 21:23:35 --> Model Class Initialized
INFO - 2019-07-01 21:23:35 --> Model Class Initialized
INFO - 2019-07-01 21:23:35 --> Model Class Initialized
INFO - 2019-07-01 21:23:35 --> Helper loaded: form_helper
INFO - 2019-07-01 21:23:35 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:23:35 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:23:35 --> Model Class Initialized
INFO - 2019-07-01 21:23:35 --> Model Class Initialized
ERROR - 2019-07-01 21:23:35 --> Severity: Notice --> Undefined index: product_id C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 118
ERROR - 2019-07-01 21:23:35 --> Severity: Notice --> Undefined index: product_id C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 142
ERROR - 2019-07-01 21:23:35 --> Severity: Notice --> Undefined index: qty C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 143
ERROR - 2019-07-01 21:23:35 --> Severity: Notice --> Undefined index: price C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 144
ERROR - 2019-07-01 21:23:35 --> Severity: Notice --> Undefined index: qty C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 145
ERROR - 2019-07-01 21:23:35 --> Severity: Notice --> Undefined index: price C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 145
ERROR - 2019-07-01 21:23:35 --> Severity: Notice --> Undefined index: description C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 146
ERROR - 2019-07-01 21:23:35 --> Query error: Column 'product_id' cannot be null - Invalid query: INSERT INTO `order_details` (`order_id`, `product_id`, `qty`, `price`, `sub_total`, `description_request`, `created_at`, `updated_at`) VALUES ('1', NULL, NULL, NULL, 0, NULL, '2019-07-01 21:23:35', '2019-07-01 21:23:35')
INFO - 2019-07-01 21:23:35 --> Language file loaded: language/english/db_lang.php
ERROR - 2019-07-01 21:23:35 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\crapi_admin\system\core\Exceptions.php:272) C:\xampp\htdocs\crapi_admin\system\core\Common.php 573
INFO - 2019-07-01 15:23:35 --> Config Class Initialized
INFO - 2019-07-01 15:23:35 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:23:35 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:23:35 --> Utf8 Class Initialized
INFO - 2019-07-01 15:23:35 --> URI Class Initialized
INFO - 2019-07-01 15:23:35 --> Router Class Initialized
INFO - 2019-07-01 15:23:35 --> Output Class Initialized
INFO - 2019-07-01 15:23:35 --> Security Class Initialized
DEBUG - 2019-07-01 15:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:23:35 --> Input Class Initialized
INFO - 2019-07-01 15:23:35 --> Language Class Initialized
INFO - 2019-07-01 15:23:36 --> Language Class Initialized
INFO - 2019-07-01 15:23:36 --> Config Class Initialized
INFO - 2019-07-01 15:23:36 --> Loader Class Initialized
DEBUG - 2019-07-01 15:23:36 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:23:36 --> Helper loaded: url_helper
INFO - 2019-07-01 15:23:36 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:23:36 --> Helper loaded: string_helper
INFO - 2019-07-01 15:23:36 --> Helper loaded: array_helper
INFO - 2019-07-01 15:23:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:23:36 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:23:36 --> Database Driver Class Initialized
INFO - 2019-07-01 15:23:36 --> Controller Class Initialized
INFO - 2019-07-01 21:23:36 --> Helper loaded: language_helper
INFO - 2019-07-01 21:23:36 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:23:36 --> Model Class Initialized
INFO - 2019-07-01 21:23:36 --> Model Class Initialized
INFO - 2019-07-01 21:23:36 --> Model Class Initialized
INFO - 2019-07-01 21:23:36 --> Model Class Initialized
INFO - 2019-07-01 21:23:36 --> Helper loaded: form_helper
INFO - 2019-07-01 21:23:36 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:23:36 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:23:36 --> Model Class Initialized
INFO - 2019-07-01 21:23:36 --> Model Class Initialized
ERROR - 2019-07-01 21:23:36 --> Severity: Notice --> Undefined index: product_id C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 118
ERROR - 2019-07-01 21:23:36 --> Severity: Notice --> Undefined index: product_id C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 142
ERROR - 2019-07-01 21:23:36 --> Severity: Notice --> Undefined index: qty C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 143
ERROR - 2019-07-01 21:23:36 --> Severity: Notice --> Undefined index: price C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 144
ERROR - 2019-07-01 21:23:36 --> Severity: Notice --> Undefined index: qty C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 145
ERROR - 2019-07-01 21:23:36 --> Severity: Notice --> Undefined index: price C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 145
ERROR - 2019-07-01 21:23:36 --> Severity: Notice --> Undefined index: description C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 146
ERROR - 2019-07-01 21:23:36 --> Query error: Column 'product_id' cannot be null - Invalid query: INSERT INTO `order_details` (`order_id`, `product_id`, `qty`, `price`, `sub_total`, `description_request`, `created_at`, `updated_at`) VALUES ('1', NULL, NULL, NULL, 0, NULL, '2019-07-01 21:23:36', '2019-07-01 21:23:36')
INFO - 2019-07-01 21:23:36 --> Language file loaded: language/english/db_lang.php
ERROR - 2019-07-01 21:23:36 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\crapi_admin\system\core\Exceptions.php:272) C:\xampp\htdocs\crapi_admin\system\core\Common.php 573
INFO - 2019-07-01 15:23:37 --> Config Class Initialized
INFO - 2019-07-01 15:23:37 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:23:37 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:23:37 --> Utf8 Class Initialized
INFO - 2019-07-01 15:23:37 --> URI Class Initialized
INFO - 2019-07-01 15:23:37 --> Router Class Initialized
INFO - 2019-07-01 15:23:37 --> Output Class Initialized
INFO - 2019-07-01 15:23:37 --> Security Class Initialized
DEBUG - 2019-07-01 15:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:23:37 --> Input Class Initialized
INFO - 2019-07-01 15:23:37 --> Language Class Initialized
INFO - 2019-07-01 15:23:37 --> Language Class Initialized
INFO - 2019-07-01 15:23:37 --> Config Class Initialized
INFO - 2019-07-01 15:23:37 --> Loader Class Initialized
DEBUG - 2019-07-01 15:23:37 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:23:37 --> Helper loaded: url_helper
INFO - 2019-07-01 15:23:37 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:23:37 --> Helper loaded: string_helper
INFO - 2019-07-01 15:23:37 --> Helper loaded: array_helper
INFO - 2019-07-01 15:23:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:23:37 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:23:37 --> Database Driver Class Initialized
INFO - 2019-07-01 15:23:37 --> Controller Class Initialized
INFO - 2019-07-01 21:23:37 --> Helper loaded: language_helper
INFO - 2019-07-01 21:23:37 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:23:37 --> Model Class Initialized
INFO - 2019-07-01 21:23:37 --> Model Class Initialized
INFO - 2019-07-01 21:23:37 --> Model Class Initialized
INFO - 2019-07-01 21:23:37 --> Model Class Initialized
INFO - 2019-07-01 21:23:37 --> Helper loaded: form_helper
INFO - 2019-07-01 21:23:37 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:23:37 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:23:37 --> Model Class Initialized
INFO - 2019-07-01 21:23:37 --> Model Class Initialized
ERROR - 2019-07-01 21:23:37 --> Severity: Notice --> Undefined index: product_id C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 118
ERROR - 2019-07-01 21:23:37 --> Severity: Notice --> Undefined index: product_id C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 142
ERROR - 2019-07-01 21:23:37 --> Severity: Notice --> Undefined index: qty C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 143
ERROR - 2019-07-01 21:23:37 --> Severity: Notice --> Undefined index: price C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 144
ERROR - 2019-07-01 21:23:37 --> Severity: Notice --> Undefined index: qty C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 145
ERROR - 2019-07-01 21:23:37 --> Severity: Notice --> Undefined index: price C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 145
ERROR - 2019-07-01 21:23:37 --> Severity: Notice --> Undefined index: description C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 146
ERROR - 2019-07-01 21:23:37 --> Query error: Column 'product_id' cannot be null - Invalid query: INSERT INTO `order_details` (`order_id`, `product_id`, `qty`, `price`, `sub_total`, `description_request`, `created_at`, `updated_at`) VALUES ('1', NULL, NULL, NULL, 0, NULL, '2019-07-01 21:23:37', '2019-07-01 21:23:37')
INFO - 2019-07-01 21:23:37 --> Language file loaded: language/english/db_lang.php
ERROR - 2019-07-01 21:23:37 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\crapi_admin\system\core\Exceptions.php:272) C:\xampp\htdocs\crapi_admin\system\core\Common.php 573
INFO - 2019-07-01 15:23:38 --> Config Class Initialized
INFO - 2019-07-01 15:23:38 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:23:38 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:23:38 --> Utf8 Class Initialized
INFO - 2019-07-01 15:23:38 --> URI Class Initialized
INFO - 2019-07-01 15:23:38 --> Router Class Initialized
INFO - 2019-07-01 15:23:38 --> Output Class Initialized
INFO - 2019-07-01 15:23:38 --> Security Class Initialized
DEBUG - 2019-07-01 15:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:23:38 --> Input Class Initialized
INFO - 2019-07-01 15:23:38 --> Language Class Initialized
INFO - 2019-07-01 15:23:38 --> Language Class Initialized
INFO - 2019-07-01 15:23:38 --> Config Class Initialized
INFO - 2019-07-01 15:23:38 --> Loader Class Initialized
DEBUG - 2019-07-01 15:23:38 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:23:38 --> Helper loaded: url_helper
INFO - 2019-07-01 15:23:38 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:23:38 --> Helper loaded: string_helper
INFO - 2019-07-01 15:23:38 --> Helper loaded: array_helper
INFO - 2019-07-01 15:23:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:23:38 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:23:38 --> Database Driver Class Initialized
INFO - 2019-07-01 15:23:38 --> Controller Class Initialized
INFO - 2019-07-01 21:23:38 --> Helper loaded: language_helper
INFO - 2019-07-01 21:23:38 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:23:38 --> Model Class Initialized
INFO - 2019-07-01 21:23:38 --> Model Class Initialized
INFO - 2019-07-01 21:23:38 --> Model Class Initialized
INFO - 2019-07-01 21:23:38 --> Model Class Initialized
INFO - 2019-07-01 21:23:38 --> Helper loaded: form_helper
INFO - 2019-07-01 21:23:38 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:23:38 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:23:38 --> Model Class Initialized
INFO - 2019-07-01 21:23:38 --> Model Class Initialized
ERROR - 2019-07-01 21:23:38 --> Severity: Notice --> Undefined index: product_id C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 118
ERROR - 2019-07-01 21:23:38 --> Severity: Notice --> Undefined index: product_id C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 142
ERROR - 2019-07-01 21:23:38 --> Severity: Notice --> Undefined index: qty C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 143
ERROR - 2019-07-01 21:23:38 --> Severity: Notice --> Undefined index: price C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 144
ERROR - 2019-07-01 21:23:38 --> Severity: Notice --> Undefined index: qty C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 145
ERROR - 2019-07-01 21:23:38 --> Severity: Notice --> Undefined index: price C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 145
ERROR - 2019-07-01 21:23:38 --> Severity: Notice --> Undefined index: description C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 146
ERROR - 2019-07-01 21:23:38 --> Query error: Column 'product_id' cannot be null - Invalid query: INSERT INTO `order_details` (`order_id`, `product_id`, `qty`, `price`, `sub_total`, `description_request`, `created_at`, `updated_at`) VALUES ('1', NULL, NULL, NULL, 0, NULL, '2019-07-01 21:23:38', '2019-07-01 21:23:38')
INFO - 2019-07-01 21:23:38 --> Language file loaded: language/english/db_lang.php
ERROR - 2019-07-01 21:23:38 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\crapi_admin\system\core\Exceptions.php:272) C:\xampp\htdocs\crapi_admin\system\core\Common.php 573
INFO - 2019-07-01 15:23:39 --> Config Class Initialized
INFO - 2019-07-01 15:23:39 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:23:39 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:23:39 --> Utf8 Class Initialized
INFO - 2019-07-01 15:23:39 --> URI Class Initialized
INFO - 2019-07-01 15:23:39 --> Router Class Initialized
INFO - 2019-07-01 15:23:39 --> Output Class Initialized
INFO - 2019-07-01 15:23:39 --> Security Class Initialized
DEBUG - 2019-07-01 15:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:23:39 --> Input Class Initialized
INFO - 2019-07-01 15:23:39 --> Language Class Initialized
INFO - 2019-07-01 15:23:39 --> Language Class Initialized
INFO - 2019-07-01 15:23:39 --> Config Class Initialized
INFO - 2019-07-01 15:23:39 --> Loader Class Initialized
DEBUG - 2019-07-01 15:23:39 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:23:39 --> Helper loaded: url_helper
INFO - 2019-07-01 15:23:39 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:23:39 --> Helper loaded: string_helper
INFO - 2019-07-01 15:23:39 --> Helper loaded: array_helper
INFO - 2019-07-01 15:23:39 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:23:39 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:23:39 --> Database Driver Class Initialized
INFO - 2019-07-01 15:23:39 --> Controller Class Initialized
INFO - 2019-07-01 21:23:39 --> Helper loaded: language_helper
INFO - 2019-07-01 21:23:39 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:23:39 --> Model Class Initialized
INFO - 2019-07-01 21:23:39 --> Model Class Initialized
INFO - 2019-07-01 21:23:39 --> Model Class Initialized
INFO - 2019-07-01 21:23:39 --> Model Class Initialized
INFO - 2019-07-01 21:23:39 --> Helper loaded: form_helper
INFO - 2019-07-01 21:23:39 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:23:39 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:23:39 --> Model Class Initialized
INFO - 2019-07-01 21:23:39 --> Model Class Initialized
ERROR - 2019-07-01 21:23:39 --> Severity: Notice --> Undefined index: product_id C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 118
ERROR - 2019-07-01 21:23:39 --> Severity: Notice --> Undefined index: product_id C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 142
ERROR - 2019-07-01 21:23:39 --> Severity: Notice --> Undefined index: qty C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 143
ERROR - 2019-07-01 21:23:39 --> Severity: Notice --> Undefined index: price C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 144
ERROR - 2019-07-01 21:23:39 --> Severity: Notice --> Undefined index: qty C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 145
ERROR - 2019-07-01 21:23:39 --> Severity: Notice --> Undefined index: price C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 145
ERROR - 2019-07-01 21:23:39 --> Severity: Notice --> Undefined index: description C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 146
ERROR - 2019-07-01 21:23:39 --> Query error: Column 'product_id' cannot be null - Invalid query: INSERT INTO `order_details` (`order_id`, `product_id`, `qty`, `price`, `sub_total`, `description_request`, `created_at`, `updated_at`) VALUES ('1', NULL, NULL, NULL, 0, NULL, '2019-07-01 21:23:39', '2019-07-01 21:23:39')
INFO - 2019-07-01 21:23:39 --> Language file loaded: language/english/db_lang.php
ERROR - 2019-07-01 21:23:39 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\crapi_admin\system\core\Exceptions.php:272) C:\xampp\htdocs\crapi_admin\system\core\Common.php 573
INFO - 2019-07-01 15:23:39 --> Config Class Initialized
INFO - 2019-07-01 15:23:39 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:23:39 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:23:39 --> Utf8 Class Initialized
INFO - 2019-07-01 15:23:39 --> URI Class Initialized
INFO - 2019-07-01 15:23:40 --> Router Class Initialized
INFO - 2019-07-01 15:23:40 --> Output Class Initialized
INFO - 2019-07-01 15:23:40 --> Security Class Initialized
DEBUG - 2019-07-01 15:23:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:23:40 --> Input Class Initialized
INFO - 2019-07-01 15:23:40 --> Language Class Initialized
INFO - 2019-07-01 15:23:40 --> Language Class Initialized
INFO - 2019-07-01 15:23:40 --> Config Class Initialized
INFO - 2019-07-01 15:23:40 --> Loader Class Initialized
DEBUG - 2019-07-01 15:23:40 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:23:40 --> Helper loaded: url_helper
INFO - 2019-07-01 15:23:40 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:23:40 --> Helper loaded: string_helper
INFO - 2019-07-01 15:23:40 --> Helper loaded: array_helper
INFO - 2019-07-01 15:23:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:23:40 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:23:40 --> Database Driver Class Initialized
INFO - 2019-07-01 15:23:40 --> Controller Class Initialized
INFO - 2019-07-01 21:23:40 --> Helper loaded: language_helper
INFO - 2019-07-01 21:23:40 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:23:40 --> Model Class Initialized
INFO - 2019-07-01 21:23:40 --> Model Class Initialized
INFO - 2019-07-01 21:23:40 --> Model Class Initialized
INFO - 2019-07-01 21:23:40 --> Model Class Initialized
INFO - 2019-07-01 21:23:40 --> Helper loaded: form_helper
INFO - 2019-07-01 21:23:40 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:23:40 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:23:40 --> Model Class Initialized
INFO - 2019-07-01 21:23:40 --> Model Class Initialized
ERROR - 2019-07-01 21:23:40 --> Severity: Notice --> Undefined index: product_id C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 118
ERROR - 2019-07-01 21:23:40 --> Severity: Notice --> Undefined index: product_id C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 142
ERROR - 2019-07-01 21:23:40 --> Severity: Notice --> Undefined index: qty C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 143
ERROR - 2019-07-01 21:23:40 --> Severity: Notice --> Undefined index: price C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 144
ERROR - 2019-07-01 21:23:40 --> Severity: Notice --> Undefined index: qty C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 145
ERROR - 2019-07-01 21:23:40 --> Severity: Notice --> Undefined index: price C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 145
ERROR - 2019-07-01 21:23:40 --> Severity: Notice --> Undefined index: description C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 146
ERROR - 2019-07-01 21:23:40 --> Query error: Column 'product_id' cannot be null - Invalid query: INSERT INTO `order_details` (`order_id`, `product_id`, `qty`, `price`, `sub_total`, `description_request`, `created_at`, `updated_at`) VALUES ('1', NULL, NULL, NULL, 0, NULL, '2019-07-01 21:23:40', '2019-07-01 21:23:40')
INFO - 2019-07-01 21:23:40 --> Language file loaded: language/english/db_lang.php
ERROR - 2019-07-01 21:23:40 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\crapi_admin\system\core\Exceptions.php:272) C:\xampp\htdocs\crapi_admin\system\core\Common.php 573
INFO - 2019-07-01 15:23:40 --> Config Class Initialized
INFO - 2019-07-01 15:23:40 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:23:40 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:23:40 --> Utf8 Class Initialized
INFO - 2019-07-01 15:23:40 --> URI Class Initialized
INFO - 2019-07-01 15:23:40 --> Router Class Initialized
INFO - 2019-07-01 15:23:40 --> Output Class Initialized
INFO - 2019-07-01 15:23:40 --> Security Class Initialized
DEBUG - 2019-07-01 15:23:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:23:40 --> Input Class Initialized
INFO - 2019-07-01 15:23:40 --> Language Class Initialized
INFO - 2019-07-01 15:23:40 --> Language Class Initialized
INFO - 2019-07-01 15:23:40 --> Config Class Initialized
INFO - 2019-07-01 15:23:41 --> Loader Class Initialized
DEBUG - 2019-07-01 15:23:41 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:23:41 --> Helper loaded: url_helper
INFO - 2019-07-01 15:23:41 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:23:41 --> Helper loaded: string_helper
INFO - 2019-07-01 15:23:41 --> Helper loaded: array_helper
INFO - 2019-07-01 15:23:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:23:41 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:23:41 --> Database Driver Class Initialized
INFO - 2019-07-01 15:23:41 --> Controller Class Initialized
INFO - 2019-07-01 21:23:41 --> Helper loaded: language_helper
INFO - 2019-07-01 21:23:41 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:23:41 --> Model Class Initialized
INFO - 2019-07-01 21:23:41 --> Model Class Initialized
INFO - 2019-07-01 21:23:41 --> Model Class Initialized
INFO - 2019-07-01 21:23:41 --> Model Class Initialized
INFO - 2019-07-01 21:23:41 --> Helper loaded: form_helper
INFO - 2019-07-01 21:23:41 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:23:41 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:23:41 --> Model Class Initialized
INFO - 2019-07-01 21:23:41 --> Model Class Initialized
ERROR - 2019-07-01 21:23:41 --> Severity: Notice --> Undefined index: product_id C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 118
ERROR - 2019-07-01 21:23:41 --> Severity: Notice --> Undefined index: product_id C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 142
ERROR - 2019-07-01 21:23:41 --> Severity: Notice --> Undefined index: qty C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 143
ERROR - 2019-07-01 21:23:41 --> Severity: Notice --> Undefined index: price C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 144
ERROR - 2019-07-01 21:23:41 --> Severity: Notice --> Undefined index: qty C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 145
ERROR - 2019-07-01 21:23:41 --> Severity: Notice --> Undefined index: price C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 145
ERROR - 2019-07-01 21:23:41 --> Severity: Notice --> Undefined index: description C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 146
ERROR - 2019-07-01 21:23:41 --> Query error: Column 'product_id' cannot be null - Invalid query: INSERT INTO `order_details` (`order_id`, `product_id`, `qty`, `price`, `sub_total`, `description_request`, `created_at`, `updated_at`) VALUES ('1', NULL, NULL, NULL, 0, NULL, '2019-07-01 21:23:41', '2019-07-01 21:23:41')
INFO - 2019-07-01 21:23:41 --> Language file loaded: language/english/db_lang.php
ERROR - 2019-07-01 21:23:41 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\crapi_admin\system\core\Exceptions.php:272) C:\xampp\htdocs\crapi_admin\system\core\Common.php 573
INFO - 2019-07-01 15:23:41 --> Config Class Initialized
INFO - 2019-07-01 15:23:41 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:23:41 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:23:41 --> Utf8 Class Initialized
INFO - 2019-07-01 15:23:41 --> URI Class Initialized
INFO - 2019-07-01 15:23:41 --> Router Class Initialized
INFO - 2019-07-01 15:23:41 --> Output Class Initialized
INFO - 2019-07-01 15:23:41 --> Security Class Initialized
DEBUG - 2019-07-01 15:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:23:41 --> Input Class Initialized
INFO - 2019-07-01 15:23:41 --> Language Class Initialized
INFO - 2019-07-01 15:23:41 --> Language Class Initialized
INFO - 2019-07-01 15:23:41 --> Config Class Initialized
INFO - 2019-07-01 15:23:41 --> Loader Class Initialized
DEBUG - 2019-07-01 15:23:41 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:23:41 --> Helper loaded: url_helper
INFO - 2019-07-01 15:23:41 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:23:41 --> Helper loaded: string_helper
INFO - 2019-07-01 15:23:41 --> Helper loaded: array_helper
INFO - 2019-07-01 15:23:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:23:41 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:23:42 --> Database Driver Class Initialized
INFO - 2019-07-01 15:23:42 --> Controller Class Initialized
INFO - 2019-07-01 21:23:42 --> Helper loaded: language_helper
INFO - 2019-07-01 21:23:42 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:23:42 --> Model Class Initialized
INFO - 2019-07-01 21:23:42 --> Model Class Initialized
INFO - 2019-07-01 21:23:42 --> Model Class Initialized
INFO - 2019-07-01 21:23:42 --> Model Class Initialized
INFO - 2019-07-01 21:23:42 --> Helper loaded: form_helper
INFO - 2019-07-01 21:23:42 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:23:42 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:23:42 --> Model Class Initialized
INFO - 2019-07-01 21:23:42 --> Model Class Initialized
ERROR - 2019-07-01 21:23:42 --> Severity: Notice --> Undefined index: product_id C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 118
ERROR - 2019-07-01 21:23:42 --> Severity: Notice --> Undefined index: product_id C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 142
ERROR - 2019-07-01 21:23:42 --> Severity: Notice --> Undefined index: qty C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 143
ERROR - 2019-07-01 21:23:42 --> Severity: Notice --> Undefined index: price C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 144
ERROR - 2019-07-01 21:23:42 --> Severity: Notice --> Undefined index: qty C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 145
ERROR - 2019-07-01 21:23:42 --> Severity: Notice --> Undefined index: price C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 145
ERROR - 2019-07-01 21:23:42 --> Severity: Notice --> Undefined index: description C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 146
ERROR - 2019-07-01 21:23:42 --> Query error: Column 'product_id' cannot be null - Invalid query: INSERT INTO `order_details` (`order_id`, `product_id`, `qty`, `price`, `sub_total`, `description_request`, `created_at`, `updated_at`) VALUES ('1', NULL, NULL, NULL, 0, NULL, '2019-07-01 21:23:42', '2019-07-01 21:23:42')
INFO - 2019-07-01 21:23:42 --> Language file loaded: language/english/db_lang.php
ERROR - 2019-07-01 21:23:42 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\crapi_admin\system\core\Exceptions.php:272) C:\xampp\htdocs\crapi_admin\system\core\Common.php 573
INFO - 2019-07-01 15:23:42 --> Config Class Initialized
INFO - 2019-07-01 15:23:42 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:23:42 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:23:42 --> Utf8 Class Initialized
INFO - 2019-07-01 15:23:42 --> URI Class Initialized
INFO - 2019-07-01 15:23:42 --> Router Class Initialized
INFO - 2019-07-01 15:23:42 --> Output Class Initialized
INFO - 2019-07-01 15:23:42 --> Security Class Initialized
DEBUG - 2019-07-01 15:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:23:42 --> Input Class Initialized
INFO - 2019-07-01 15:23:42 --> Language Class Initialized
INFO - 2019-07-01 15:23:42 --> Language Class Initialized
INFO - 2019-07-01 15:23:42 --> Config Class Initialized
INFO - 2019-07-01 15:23:42 --> Loader Class Initialized
DEBUG - 2019-07-01 15:23:42 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:23:42 --> Helper loaded: url_helper
INFO - 2019-07-01 15:23:42 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:23:42 --> Helper loaded: string_helper
INFO - 2019-07-01 15:23:42 --> Helper loaded: array_helper
INFO - 2019-07-01 15:23:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:23:42 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:23:42 --> Database Driver Class Initialized
INFO - 2019-07-01 15:23:42 --> Controller Class Initialized
INFO - 2019-07-01 21:23:42 --> Helper loaded: language_helper
INFO - 2019-07-01 21:23:42 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:23:42 --> Model Class Initialized
INFO - 2019-07-01 21:23:42 --> Model Class Initialized
INFO - 2019-07-01 21:23:42 --> Model Class Initialized
INFO - 2019-07-01 21:23:42 --> Model Class Initialized
INFO - 2019-07-01 21:23:43 --> Helper loaded: form_helper
INFO - 2019-07-01 21:23:43 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:23:43 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:23:43 --> Model Class Initialized
INFO - 2019-07-01 21:23:43 --> Model Class Initialized
ERROR - 2019-07-01 21:23:43 --> Severity: Notice --> Undefined index: product_id C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 118
ERROR - 2019-07-01 21:23:43 --> Severity: Notice --> Undefined index: product_id C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 142
ERROR - 2019-07-01 21:23:43 --> Severity: Notice --> Undefined index: qty C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 143
ERROR - 2019-07-01 21:23:43 --> Severity: Notice --> Undefined index: price C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 144
ERROR - 2019-07-01 21:23:43 --> Severity: Notice --> Undefined index: qty C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 145
ERROR - 2019-07-01 21:23:43 --> Severity: Notice --> Undefined index: price C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 145
ERROR - 2019-07-01 21:23:43 --> Severity: Notice --> Undefined index: description C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 146
ERROR - 2019-07-01 21:23:43 --> Query error: Column 'product_id' cannot be null - Invalid query: INSERT INTO `order_details` (`order_id`, `product_id`, `qty`, `price`, `sub_total`, `description_request`, `created_at`, `updated_at`) VALUES ('1', NULL, NULL, NULL, 0, NULL, '2019-07-01 21:23:43', '2019-07-01 21:23:43')
INFO - 2019-07-01 21:23:43 --> Language file loaded: language/english/db_lang.php
ERROR - 2019-07-01 21:23:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\crapi_admin\system\core\Exceptions.php:272) C:\xampp\htdocs\crapi_admin\system\core\Common.php 573
INFO - 2019-07-01 15:23:43 --> Config Class Initialized
INFO - 2019-07-01 15:23:43 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:23:43 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:23:43 --> Utf8 Class Initialized
INFO - 2019-07-01 15:23:43 --> URI Class Initialized
INFO - 2019-07-01 15:23:43 --> Router Class Initialized
INFO - 2019-07-01 15:23:43 --> Output Class Initialized
INFO - 2019-07-01 15:23:43 --> Security Class Initialized
DEBUG - 2019-07-01 15:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:23:43 --> Input Class Initialized
INFO - 2019-07-01 15:23:43 --> Language Class Initialized
INFO - 2019-07-01 15:23:43 --> Language Class Initialized
INFO - 2019-07-01 15:23:43 --> Config Class Initialized
INFO - 2019-07-01 15:23:43 --> Loader Class Initialized
DEBUG - 2019-07-01 15:23:43 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:23:43 --> Helper loaded: url_helper
INFO - 2019-07-01 15:23:43 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:23:43 --> Helper loaded: string_helper
INFO - 2019-07-01 15:23:43 --> Helper loaded: array_helper
INFO - 2019-07-01 15:23:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:23:43 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:23:43 --> Database Driver Class Initialized
INFO - 2019-07-01 15:23:43 --> Controller Class Initialized
INFO - 2019-07-01 21:23:43 --> Helper loaded: language_helper
INFO - 2019-07-01 21:23:43 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:23:43 --> Model Class Initialized
INFO - 2019-07-01 21:23:43 --> Model Class Initialized
INFO - 2019-07-01 21:23:43 --> Model Class Initialized
INFO - 2019-07-01 21:23:43 --> Model Class Initialized
INFO - 2019-07-01 21:23:43 --> Helper loaded: form_helper
INFO - 2019-07-01 21:23:43 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:23:43 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:23:43 --> Model Class Initialized
INFO - 2019-07-01 21:23:43 --> Model Class Initialized
ERROR - 2019-07-01 21:23:43 --> Severity: Notice --> Undefined index: product_id C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 118
ERROR - 2019-07-01 21:23:43 --> Severity: Notice --> Undefined index: product_id C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 142
ERROR - 2019-07-01 21:23:43 --> Severity: Notice --> Undefined index: qty C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 143
ERROR - 2019-07-01 21:23:43 --> Severity: Notice --> Undefined index: price C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 144
ERROR - 2019-07-01 21:23:43 --> Severity: Notice --> Undefined index: qty C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 145
ERROR - 2019-07-01 21:23:43 --> Severity: Notice --> Undefined index: price C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 145
ERROR - 2019-07-01 21:23:43 --> Severity: Notice --> Undefined index: description C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 146
ERROR - 2019-07-01 21:23:43 --> Query error: Column 'product_id' cannot be null - Invalid query: INSERT INTO `order_details` (`order_id`, `product_id`, `qty`, `price`, `sub_total`, `description_request`, `created_at`, `updated_at`) VALUES ('1', NULL, NULL, NULL, 0, NULL, '2019-07-01 21:23:43', '2019-07-01 21:23:43')
INFO - 2019-07-01 21:23:43 --> Language file loaded: language/english/db_lang.php
ERROR - 2019-07-01 21:23:43 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\crapi_admin\system\core\Exceptions.php:272) C:\xampp\htdocs\crapi_admin\system\core\Common.php 573
INFO - 2019-07-01 15:23:43 --> Config Class Initialized
INFO - 2019-07-01 15:23:44 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:23:44 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:23:44 --> Utf8 Class Initialized
INFO - 2019-07-01 15:23:44 --> URI Class Initialized
INFO - 2019-07-01 15:23:44 --> Router Class Initialized
INFO - 2019-07-01 15:23:44 --> Output Class Initialized
INFO - 2019-07-01 15:23:44 --> Security Class Initialized
DEBUG - 2019-07-01 15:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:23:44 --> Input Class Initialized
INFO - 2019-07-01 15:23:44 --> Language Class Initialized
INFO - 2019-07-01 15:23:44 --> Language Class Initialized
INFO - 2019-07-01 15:23:44 --> Config Class Initialized
INFO - 2019-07-01 15:23:44 --> Loader Class Initialized
DEBUG - 2019-07-01 15:23:44 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:23:44 --> Helper loaded: url_helper
INFO - 2019-07-01 15:23:44 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:23:44 --> Helper loaded: string_helper
INFO - 2019-07-01 15:23:44 --> Helper loaded: array_helper
INFO - 2019-07-01 15:23:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:23:44 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:23:44 --> Database Driver Class Initialized
INFO - 2019-07-01 15:23:44 --> Controller Class Initialized
INFO - 2019-07-01 21:23:44 --> Helper loaded: language_helper
INFO - 2019-07-01 21:23:44 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:23:44 --> Model Class Initialized
INFO - 2019-07-01 21:23:44 --> Model Class Initialized
INFO - 2019-07-01 21:23:44 --> Model Class Initialized
INFO - 2019-07-01 21:23:44 --> Model Class Initialized
INFO - 2019-07-01 21:23:44 --> Helper loaded: form_helper
INFO - 2019-07-01 21:23:44 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:23:44 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:23:44 --> Model Class Initialized
INFO - 2019-07-01 21:23:44 --> Model Class Initialized
ERROR - 2019-07-01 21:23:44 --> Severity: Notice --> Undefined index: product_id C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 118
ERROR - 2019-07-01 21:23:44 --> Severity: Notice --> Undefined index: product_id C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 142
ERROR - 2019-07-01 21:23:44 --> Severity: Notice --> Undefined index: qty C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 143
ERROR - 2019-07-01 21:23:44 --> Severity: Notice --> Undefined index: price C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 144
ERROR - 2019-07-01 21:23:44 --> Severity: Notice --> Undefined index: qty C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 145
ERROR - 2019-07-01 21:23:44 --> Severity: Notice --> Undefined index: price C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 145
ERROR - 2019-07-01 21:23:44 --> Severity: Notice --> Undefined index: description C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 146
ERROR - 2019-07-01 21:23:44 --> Query error: Column 'product_id' cannot be null - Invalid query: INSERT INTO `order_details` (`order_id`, `product_id`, `qty`, `price`, `sub_total`, `description_request`, `created_at`, `updated_at`) VALUES ('1', NULL, NULL, NULL, 0, NULL, '2019-07-01 21:23:44', '2019-07-01 21:23:44')
INFO - 2019-07-01 21:23:44 --> Language file loaded: language/english/db_lang.php
ERROR - 2019-07-01 21:23:44 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\crapi_admin\system\core\Exceptions.php:272) C:\xampp\htdocs\crapi_admin\system\core\Common.php 573
INFO - 2019-07-01 15:23:44 --> Config Class Initialized
INFO - 2019-07-01 15:23:44 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:23:44 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:23:44 --> Utf8 Class Initialized
INFO - 2019-07-01 15:23:44 --> URI Class Initialized
INFO - 2019-07-01 15:23:44 --> Router Class Initialized
INFO - 2019-07-01 15:23:44 --> Output Class Initialized
INFO - 2019-07-01 15:23:44 --> Security Class Initialized
DEBUG - 2019-07-01 15:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:23:44 --> Input Class Initialized
INFO - 2019-07-01 15:23:44 --> Language Class Initialized
INFO - 2019-07-01 15:23:44 --> Language Class Initialized
INFO - 2019-07-01 15:23:44 --> Config Class Initialized
INFO - 2019-07-01 15:23:44 --> Loader Class Initialized
DEBUG - 2019-07-01 15:23:44 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:23:44 --> Helper loaded: url_helper
INFO - 2019-07-01 15:23:44 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:23:44 --> Helper loaded: string_helper
INFO - 2019-07-01 15:23:44 --> Helper loaded: array_helper
INFO - 2019-07-01 15:23:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:23:45 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:23:45 --> Database Driver Class Initialized
INFO - 2019-07-01 15:23:45 --> Controller Class Initialized
INFO - 2019-07-01 21:23:45 --> Helper loaded: language_helper
INFO - 2019-07-01 21:23:45 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:23:45 --> Model Class Initialized
INFO - 2019-07-01 21:23:45 --> Model Class Initialized
INFO - 2019-07-01 21:23:45 --> Model Class Initialized
INFO - 2019-07-01 21:23:45 --> Model Class Initialized
INFO - 2019-07-01 21:23:45 --> Helper loaded: form_helper
INFO - 2019-07-01 21:23:45 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:23:45 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:23:45 --> Model Class Initialized
INFO - 2019-07-01 21:23:45 --> Model Class Initialized
ERROR - 2019-07-01 21:23:45 --> Severity: Notice --> Undefined index: product_id C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 118
ERROR - 2019-07-01 21:23:45 --> Severity: Notice --> Undefined index: product_id C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 142
ERROR - 2019-07-01 21:23:45 --> Severity: Notice --> Undefined index: qty C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 143
ERROR - 2019-07-01 21:23:45 --> Severity: Notice --> Undefined index: price C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 144
ERROR - 2019-07-01 21:23:45 --> Severity: Notice --> Undefined index: qty C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 145
ERROR - 2019-07-01 21:23:45 --> Severity: Notice --> Undefined index: price C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 145
ERROR - 2019-07-01 21:23:45 --> Severity: Notice --> Undefined index: description C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 146
ERROR - 2019-07-01 21:23:45 --> Query error: Column 'product_id' cannot be null - Invalid query: INSERT INTO `order_details` (`order_id`, `product_id`, `qty`, `price`, `sub_total`, `description_request`, `created_at`, `updated_at`) VALUES ('1', NULL, NULL, NULL, 0, NULL, '2019-07-01 21:23:45', '2019-07-01 21:23:45')
INFO - 2019-07-01 21:23:45 --> Language file loaded: language/english/db_lang.php
ERROR - 2019-07-01 21:23:45 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\crapi_admin\system\core\Exceptions.php:272) C:\xampp\htdocs\crapi_admin\system\core\Common.php 573
INFO - 2019-07-01 15:23:45 --> Config Class Initialized
INFO - 2019-07-01 15:23:45 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:23:45 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:23:45 --> Utf8 Class Initialized
INFO - 2019-07-01 15:23:45 --> URI Class Initialized
INFO - 2019-07-01 15:23:45 --> Router Class Initialized
INFO - 2019-07-01 15:23:45 --> Output Class Initialized
INFO - 2019-07-01 15:23:45 --> Security Class Initialized
DEBUG - 2019-07-01 15:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:23:45 --> Input Class Initialized
INFO - 2019-07-01 15:23:45 --> Language Class Initialized
INFO - 2019-07-01 15:23:45 --> Language Class Initialized
INFO - 2019-07-01 15:23:45 --> Config Class Initialized
INFO - 2019-07-01 15:23:45 --> Loader Class Initialized
DEBUG - 2019-07-01 15:23:45 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:23:45 --> Helper loaded: url_helper
INFO - 2019-07-01 15:23:45 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:23:45 --> Helper loaded: string_helper
INFO - 2019-07-01 15:23:45 --> Helper loaded: array_helper
INFO - 2019-07-01 15:23:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:23:45 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:23:45 --> Database Driver Class Initialized
INFO - 2019-07-01 15:23:45 --> Controller Class Initialized
INFO - 2019-07-01 21:23:45 --> Helper loaded: language_helper
INFO - 2019-07-01 21:23:45 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:23:45 --> Model Class Initialized
INFO - 2019-07-01 21:23:45 --> Model Class Initialized
INFO - 2019-07-01 21:23:45 --> Model Class Initialized
INFO - 2019-07-01 21:23:45 --> Model Class Initialized
INFO - 2019-07-01 21:23:45 --> Helper loaded: form_helper
INFO - 2019-07-01 21:23:45 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:23:45 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:23:45 --> Model Class Initialized
INFO - 2019-07-01 21:23:45 --> Model Class Initialized
ERROR - 2019-07-01 21:23:45 --> Severity: Notice --> Undefined index: product_id C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 118
ERROR - 2019-07-01 21:23:45 --> Severity: Notice --> Undefined index: product_id C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 142
ERROR - 2019-07-01 21:23:45 --> Severity: Notice --> Undefined index: qty C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 143
ERROR - 2019-07-01 21:23:46 --> Severity: Notice --> Undefined index: price C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 144
ERROR - 2019-07-01 21:23:46 --> Severity: Notice --> Undefined index: qty C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 145
ERROR - 2019-07-01 21:23:46 --> Severity: Notice --> Undefined index: price C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 145
ERROR - 2019-07-01 21:23:46 --> Severity: Notice --> Undefined index: description C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 146
ERROR - 2019-07-01 21:23:46 --> Query error: Column 'product_id' cannot be null - Invalid query: INSERT INTO `order_details` (`order_id`, `product_id`, `qty`, `price`, `sub_total`, `description_request`, `created_at`, `updated_at`) VALUES ('1', NULL, NULL, NULL, 0, NULL, '2019-07-01 21:23:46', '2019-07-01 21:23:46')
INFO - 2019-07-01 21:23:46 --> Language file loaded: language/english/db_lang.php
ERROR - 2019-07-01 21:23:46 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\crapi_admin\system\core\Exceptions.php:272) C:\xampp\htdocs\crapi_admin\system\core\Common.php 573
INFO - 2019-07-01 15:23:46 --> Config Class Initialized
INFO - 2019-07-01 15:23:46 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:23:46 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:23:46 --> Utf8 Class Initialized
INFO - 2019-07-01 15:23:46 --> URI Class Initialized
INFO - 2019-07-01 15:23:46 --> Router Class Initialized
INFO - 2019-07-01 15:23:46 --> Output Class Initialized
INFO - 2019-07-01 15:23:46 --> Security Class Initialized
DEBUG - 2019-07-01 15:23:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:23:46 --> Input Class Initialized
INFO - 2019-07-01 15:23:46 --> Language Class Initialized
INFO - 2019-07-01 15:23:46 --> Language Class Initialized
INFO - 2019-07-01 15:23:46 --> Config Class Initialized
INFO - 2019-07-01 15:23:46 --> Loader Class Initialized
DEBUG - 2019-07-01 15:23:46 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:23:46 --> Helper loaded: url_helper
INFO - 2019-07-01 15:23:46 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:23:46 --> Helper loaded: string_helper
INFO - 2019-07-01 15:23:46 --> Helper loaded: array_helper
INFO - 2019-07-01 15:23:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:23:46 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:23:46 --> Database Driver Class Initialized
INFO - 2019-07-01 15:23:46 --> Controller Class Initialized
INFO - 2019-07-01 21:23:46 --> Helper loaded: language_helper
INFO - 2019-07-01 21:23:46 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:23:46 --> Model Class Initialized
INFO - 2019-07-01 21:23:46 --> Model Class Initialized
INFO - 2019-07-01 21:23:46 --> Model Class Initialized
INFO - 2019-07-01 21:23:46 --> Model Class Initialized
INFO - 2019-07-01 21:23:46 --> Helper loaded: form_helper
INFO - 2019-07-01 21:23:46 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:23:46 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:23:46 --> Model Class Initialized
INFO - 2019-07-01 21:23:46 --> Model Class Initialized
ERROR - 2019-07-01 21:23:46 --> Severity: Notice --> Undefined index: product_id C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 118
ERROR - 2019-07-01 21:23:46 --> Severity: Notice --> Undefined index: product_id C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 142
ERROR - 2019-07-01 21:23:46 --> Severity: Notice --> Undefined index: qty C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 143
ERROR - 2019-07-01 21:23:46 --> Severity: Notice --> Undefined index: price C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 144
ERROR - 2019-07-01 21:23:46 --> Severity: Notice --> Undefined index: qty C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 145
ERROR - 2019-07-01 21:23:46 --> Severity: Notice --> Undefined index: price C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 145
ERROR - 2019-07-01 21:23:46 --> Severity: Notice --> Undefined index: description C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 146
ERROR - 2019-07-01 21:23:46 --> Query error: Column 'product_id' cannot be null - Invalid query: INSERT INTO `order_details` (`order_id`, `product_id`, `qty`, `price`, `sub_total`, `description_request`, `created_at`, `updated_at`) VALUES ('1', NULL, NULL, NULL, 0, NULL, '2019-07-01 21:23:46', '2019-07-01 21:23:46')
INFO - 2019-07-01 21:23:46 --> Language file loaded: language/english/db_lang.php
ERROR - 2019-07-01 21:23:46 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\crapi_admin\system\core\Exceptions.php:272) C:\xampp\htdocs\crapi_admin\system\core\Common.php 573
INFO - 2019-07-01 15:23:46 --> Config Class Initialized
INFO - 2019-07-01 15:23:46 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:23:46 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:23:46 --> Utf8 Class Initialized
INFO - 2019-07-01 15:23:46 --> URI Class Initialized
INFO - 2019-07-01 15:23:46 --> Router Class Initialized
INFO - 2019-07-01 15:23:46 --> Output Class Initialized
INFO - 2019-07-01 15:23:46 --> Security Class Initialized
DEBUG - 2019-07-01 15:23:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:23:46 --> Input Class Initialized
INFO - 2019-07-01 15:23:46 --> Language Class Initialized
INFO - 2019-07-01 15:23:47 --> Language Class Initialized
INFO - 2019-07-01 15:23:47 --> Config Class Initialized
INFO - 2019-07-01 15:23:47 --> Loader Class Initialized
DEBUG - 2019-07-01 15:23:47 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:23:47 --> Helper loaded: url_helper
INFO - 2019-07-01 15:23:47 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:23:47 --> Helper loaded: string_helper
INFO - 2019-07-01 15:23:47 --> Helper loaded: array_helper
INFO - 2019-07-01 15:23:47 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:23:47 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:23:47 --> Database Driver Class Initialized
INFO - 2019-07-01 15:23:47 --> Controller Class Initialized
INFO - 2019-07-01 21:23:47 --> Helper loaded: language_helper
INFO - 2019-07-01 21:23:47 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:23:47 --> Model Class Initialized
INFO - 2019-07-01 21:23:47 --> Model Class Initialized
INFO - 2019-07-01 21:23:47 --> Model Class Initialized
INFO - 2019-07-01 21:23:47 --> Model Class Initialized
INFO - 2019-07-01 21:23:47 --> Helper loaded: form_helper
INFO - 2019-07-01 21:23:47 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:23:47 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:23:47 --> Model Class Initialized
INFO - 2019-07-01 21:23:47 --> Model Class Initialized
ERROR - 2019-07-01 21:23:47 --> Severity: Notice --> Undefined index: product_id C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 118
ERROR - 2019-07-01 21:23:47 --> Severity: Notice --> Undefined index: product_id C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 142
ERROR - 2019-07-01 21:23:47 --> Severity: Notice --> Undefined index: qty C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 143
ERROR - 2019-07-01 21:23:47 --> Severity: Notice --> Undefined index: price C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 144
ERROR - 2019-07-01 21:23:47 --> Severity: Notice --> Undefined index: qty C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 145
ERROR - 2019-07-01 21:23:47 --> Severity: Notice --> Undefined index: price C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 145
ERROR - 2019-07-01 21:23:47 --> Severity: Notice --> Undefined index: description C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 146
ERROR - 2019-07-01 21:23:47 --> Query error: Column 'product_id' cannot be null - Invalid query: INSERT INTO `order_details` (`order_id`, `product_id`, `qty`, `price`, `sub_total`, `description_request`, `created_at`, `updated_at`) VALUES ('1', NULL, NULL, NULL, 0, NULL, '2019-07-01 21:23:47', '2019-07-01 21:23:47')
INFO - 2019-07-01 21:23:47 --> Language file loaded: language/english/db_lang.php
ERROR - 2019-07-01 21:23:47 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\crapi_admin\system\core\Exceptions.php:272) C:\xampp\htdocs\crapi_admin\system\core\Common.php 573
INFO - 2019-07-01 15:23:47 --> Config Class Initialized
INFO - 2019-07-01 15:23:47 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:23:47 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:23:47 --> Utf8 Class Initialized
INFO - 2019-07-01 15:23:47 --> URI Class Initialized
INFO - 2019-07-01 15:23:47 --> Router Class Initialized
INFO - 2019-07-01 15:23:47 --> Output Class Initialized
INFO - 2019-07-01 15:23:47 --> Security Class Initialized
DEBUG - 2019-07-01 15:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:23:47 --> Input Class Initialized
INFO - 2019-07-01 15:23:48 --> Language Class Initialized
INFO - 2019-07-01 15:23:48 --> Language Class Initialized
INFO - 2019-07-01 15:23:48 --> Config Class Initialized
INFO - 2019-07-01 15:23:48 --> Loader Class Initialized
DEBUG - 2019-07-01 15:23:48 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:23:48 --> Helper loaded: url_helper
INFO - 2019-07-01 15:23:48 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:23:48 --> Helper loaded: string_helper
INFO - 2019-07-01 15:23:48 --> Helper loaded: array_helper
INFO - 2019-07-01 15:23:48 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:23:48 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:23:48 --> Database Driver Class Initialized
INFO - 2019-07-01 15:23:48 --> Controller Class Initialized
INFO - 2019-07-01 21:23:48 --> Helper loaded: language_helper
INFO - 2019-07-01 21:23:48 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:23:48 --> Model Class Initialized
INFO - 2019-07-01 21:23:48 --> Model Class Initialized
INFO - 2019-07-01 21:23:48 --> Model Class Initialized
INFO - 2019-07-01 21:23:48 --> Model Class Initialized
INFO - 2019-07-01 21:23:48 --> Helper loaded: form_helper
INFO - 2019-07-01 21:23:48 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:23:48 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:23:48 --> Model Class Initialized
INFO - 2019-07-01 21:23:48 --> Model Class Initialized
INFO - 2019-07-01 21:23:48 --> Final output sent to browser
DEBUG - 2019-07-01 21:23:48 --> Total execution time: 0.8649
INFO - 2019-07-01 15:23:48 --> Config Class Initialized
INFO - 2019-07-01 15:23:48 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:23:48 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:23:48 --> Utf8 Class Initialized
INFO - 2019-07-01 15:23:48 --> URI Class Initialized
INFO - 2019-07-01 15:23:48 --> Router Class Initialized
INFO - 2019-07-01 15:23:48 --> Output Class Initialized
INFO - 2019-07-01 15:23:48 --> Security Class Initialized
DEBUG - 2019-07-01 15:23:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:23:48 --> Input Class Initialized
INFO - 2019-07-01 15:23:48 --> Language Class Initialized
INFO - 2019-07-01 15:23:48 --> Language Class Initialized
INFO - 2019-07-01 15:23:48 --> Config Class Initialized
INFO - 2019-07-01 15:23:48 --> Loader Class Initialized
DEBUG - 2019-07-01 15:23:48 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:23:48 --> Helper loaded: url_helper
INFO - 2019-07-01 15:23:48 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:23:48 --> Helper loaded: string_helper
INFO - 2019-07-01 15:23:48 --> Helper loaded: array_helper
INFO - 2019-07-01 15:23:49 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:23:49 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:23:49 --> Database Driver Class Initialized
INFO - 2019-07-01 15:23:49 --> Controller Class Initialized
INFO - 2019-07-01 21:23:49 --> Helper loaded: language_helper
INFO - 2019-07-01 21:23:49 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:23:49 --> Model Class Initialized
INFO - 2019-07-01 21:23:49 --> Model Class Initialized
INFO - 2019-07-01 21:23:49 --> Model Class Initialized
INFO - 2019-07-01 21:23:49 --> Model Class Initialized
INFO - 2019-07-01 21:23:49 --> Helper loaded: form_helper
INFO - 2019-07-01 21:23:49 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:23:49 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:23:49 --> Model Class Initialized
INFO - 2019-07-01 21:23:49 --> Model Class Initialized
INFO - 2019-07-01 21:23:49 --> Final output sent to browser
DEBUG - 2019-07-01 21:23:49 --> Total execution time: 0.5891
INFO - 2019-07-01 15:23:49 --> Config Class Initialized
INFO - 2019-07-01 15:23:49 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:23:49 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:23:49 --> Utf8 Class Initialized
INFO - 2019-07-01 15:23:49 --> URI Class Initialized
INFO - 2019-07-01 15:23:49 --> Router Class Initialized
INFO - 2019-07-01 15:23:49 --> Output Class Initialized
INFO - 2019-07-01 15:23:49 --> Security Class Initialized
DEBUG - 2019-07-01 15:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:23:49 --> Input Class Initialized
INFO - 2019-07-01 15:23:49 --> Language Class Initialized
INFO - 2019-07-01 15:23:49 --> Language Class Initialized
INFO - 2019-07-01 15:23:49 --> Config Class Initialized
INFO - 2019-07-01 15:23:49 --> Loader Class Initialized
DEBUG - 2019-07-01 15:23:49 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:23:49 --> Helper loaded: url_helper
INFO - 2019-07-01 15:23:49 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:23:49 --> Helper loaded: string_helper
INFO - 2019-07-01 15:23:49 --> Helper loaded: array_helper
INFO - 2019-07-01 15:23:49 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:23:49 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:23:49 --> Database Driver Class Initialized
INFO - 2019-07-01 15:23:49 --> Controller Class Initialized
INFO - 2019-07-01 21:23:49 --> Helper loaded: language_helper
INFO - 2019-07-01 21:23:49 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:23:49 --> Model Class Initialized
INFO - 2019-07-01 21:23:49 --> Model Class Initialized
INFO - 2019-07-01 21:23:49 --> Model Class Initialized
INFO - 2019-07-01 21:23:49 --> Model Class Initialized
INFO - 2019-07-01 21:23:49 --> Helper loaded: form_helper
INFO - 2019-07-01 21:23:49 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:23:49 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:23:49 --> Model Class Initialized
INFO - 2019-07-01 21:23:49 --> Model Class Initialized
INFO - 2019-07-01 21:23:49 --> Final output sent to browser
DEBUG - 2019-07-01 21:23:50 --> Total execution time: 0.6580
INFO - 2019-07-01 15:23:50 --> Config Class Initialized
INFO - 2019-07-01 15:23:50 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:23:50 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:23:50 --> Utf8 Class Initialized
INFO - 2019-07-01 15:23:50 --> URI Class Initialized
INFO - 2019-07-01 15:23:50 --> Router Class Initialized
INFO - 2019-07-01 15:23:50 --> Output Class Initialized
INFO - 2019-07-01 15:23:50 --> Security Class Initialized
DEBUG - 2019-07-01 15:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:23:50 --> Input Class Initialized
INFO - 2019-07-01 15:23:50 --> Language Class Initialized
INFO - 2019-07-01 15:23:50 --> Language Class Initialized
INFO - 2019-07-01 15:23:50 --> Config Class Initialized
INFO - 2019-07-01 15:23:50 --> Loader Class Initialized
DEBUG - 2019-07-01 15:23:50 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:23:50 --> Helper loaded: url_helper
INFO - 2019-07-01 15:23:50 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:23:50 --> Helper loaded: string_helper
INFO - 2019-07-01 15:23:50 --> Helper loaded: array_helper
INFO - 2019-07-01 15:23:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:23:50 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:23:50 --> Database Driver Class Initialized
INFO - 2019-07-01 15:23:50 --> Controller Class Initialized
INFO - 2019-07-01 21:23:50 --> Helper loaded: language_helper
INFO - 2019-07-01 21:23:50 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:23:50 --> Model Class Initialized
INFO - 2019-07-01 21:23:50 --> Model Class Initialized
INFO - 2019-07-01 21:23:50 --> Model Class Initialized
INFO - 2019-07-01 21:23:50 --> Model Class Initialized
INFO - 2019-07-01 21:23:50 --> Helper loaded: form_helper
INFO - 2019-07-01 21:23:50 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:23:50 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:23:50 --> Model Class Initialized
INFO - 2019-07-01 21:23:50 --> Model Class Initialized
INFO - 2019-07-01 21:23:50 --> Final output sent to browser
DEBUG - 2019-07-01 21:23:50 --> Total execution time: 0.7437
INFO - 2019-07-01 15:23:50 --> Config Class Initialized
INFO - 2019-07-01 15:23:50 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:23:50 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:23:50 --> Utf8 Class Initialized
INFO - 2019-07-01 15:23:51 --> URI Class Initialized
INFO - 2019-07-01 15:23:51 --> Router Class Initialized
INFO - 2019-07-01 15:23:51 --> Output Class Initialized
INFO - 2019-07-01 15:23:51 --> Security Class Initialized
DEBUG - 2019-07-01 15:23:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:23:51 --> Input Class Initialized
INFO - 2019-07-01 15:23:51 --> Language Class Initialized
INFO - 2019-07-01 15:23:51 --> Language Class Initialized
INFO - 2019-07-01 15:23:51 --> Config Class Initialized
INFO - 2019-07-01 15:23:51 --> Loader Class Initialized
DEBUG - 2019-07-01 15:23:51 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:23:51 --> Helper loaded: url_helper
INFO - 2019-07-01 15:23:51 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:23:51 --> Helper loaded: string_helper
INFO - 2019-07-01 15:23:51 --> Helper loaded: array_helper
INFO - 2019-07-01 15:23:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:23:51 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:23:51 --> Database Driver Class Initialized
INFO - 2019-07-01 15:23:51 --> Controller Class Initialized
INFO - 2019-07-01 21:23:51 --> Helper loaded: language_helper
INFO - 2019-07-01 21:23:51 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:23:51 --> Model Class Initialized
INFO - 2019-07-01 21:23:51 --> Model Class Initialized
INFO - 2019-07-01 21:23:51 --> Model Class Initialized
INFO - 2019-07-01 21:23:51 --> Model Class Initialized
INFO - 2019-07-01 21:23:51 --> Helper loaded: form_helper
INFO - 2019-07-01 21:23:51 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:23:51 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:23:51 --> Model Class Initialized
INFO - 2019-07-01 21:23:51 --> Model Class Initialized
INFO - 2019-07-01 21:23:51 --> Final output sent to browser
DEBUG - 2019-07-01 21:23:51 --> Total execution time: 0.7645
INFO - 2019-07-01 15:23:51 --> Config Class Initialized
INFO - 2019-07-01 15:23:51 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:23:51 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:23:51 --> Utf8 Class Initialized
INFO - 2019-07-01 15:23:51 --> URI Class Initialized
INFO - 2019-07-01 15:23:51 --> Router Class Initialized
INFO - 2019-07-01 15:23:51 --> Output Class Initialized
INFO - 2019-07-01 15:23:51 --> Security Class Initialized
DEBUG - 2019-07-01 15:23:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:23:51 --> Input Class Initialized
INFO - 2019-07-01 15:23:51 --> Language Class Initialized
INFO - 2019-07-01 15:23:51 --> Language Class Initialized
INFO - 2019-07-01 15:23:51 --> Config Class Initialized
INFO - 2019-07-01 15:23:51 --> Loader Class Initialized
DEBUG - 2019-07-01 15:23:51 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:23:51 --> Helper loaded: url_helper
INFO - 2019-07-01 15:23:52 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:23:52 --> Helper loaded: string_helper
INFO - 2019-07-01 15:23:52 --> Helper loaded: array_helper
INFO - 2019-07-01 15:23:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:23:52 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:23:52 --> Database Driver Class Initialized
INFO - 2019-07-01 15:23:52 --> Controller Class Initialized
INFO - 2019-07-01 21:23:52 --> Helper loaded: language_helper
INFO - 2019-07-01 21:23:52 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:23:52 --> Model Class Initialized
INFO - 2019-07-01 21:23:52 --> Model Class Initialized
INFO - 2019-07-01 21:23:52 --> Model Class Initialized
INFO - 2019-07-01 21:23:52 --> Model Class Initialized
INFO - 2019-07-01 21:23:52 --> Helper loaded: form_helper
INFO - 2019-07-01 21:23:52 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:23:52 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:23:52 --> Model Class Initialized
INFO - 2019-07-01 21:23:52 --> Model Class Initialized
INFO - 2019-07-01 21:23:52 --> Final output sent to browser
DEBUG - 2019-07-01 21:23:52 --> Total execution time: 0.6747
INFO - 2019-07-01 15:23:52 --> Config Class Initialized
INFO - 2019-07-01 15:23:52 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:23:52 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:23:52 --> Utf8 Class Initialized
INFO - 2019-07-01 15:23:52 --> URI Class Initialized
INFO - 2019-07-01 15:23:52 --> Router Class Initialized
INFO - 2019-07-01 15:23:52 --> Output Class Initialized
INFO - 2019-07-01 15:23:52 --> Security Class Initialized
DEBUG - 2019-07-01 15:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:23:52 --> Input Class Initialized
INFO - 2019-07-01 15:23:52 --> Language Class Initialized
INFO - 2019-07-01 15:23:52 --> Language Class Initialized
INFO - 2019-07-01 15:23:52 --> Config Class Initialized
INFO - 2019-07-01 15:23:52 --> Loader Class Initialized
DEBUG - 2019-07-01 15:23:52 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:23:52 --> Helper loaded: url_helper
INFO - 2019-07-01 15:23:52 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:23:52 --> Helper loaded: string_helper
INFO - 2019-07-01 15:23:52 --> Helper loaded: array_helper
INFO - 2019-07-01 15:23:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:23:52 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:23:52 --> Database Driver Class Initialized
INFO - 2019-07-01 15:23:52 --> Controller Class Initialized
INFO - 2019-07-01 21:23:52 --> Helper loaded: language_helper
INFO - 2019-07-01 21:23:52 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:23:53 --> Model Class Initialized
INFO - 2019-07-01 21:23:53 --> Model Class Initialized
INFO - 2019-07-01 21:23:53 --> Model Class Initialized
INFO - 2019-07-01 21:23:53 --> Model Class Initialized
INFO - 2019-07-01 21:23:53 --> Helper loaded: form_helper
INFO - 2019-07-01 21:23:53 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:23:53 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:23:53 --> Model Class Initialized
INFO - 2019-07-01 21:23:53 --> Model Class Initialized
INFO - 2019-07-01 21:23:53 --> Final output sent to browser
DEBUG - 2019-07-01 21:23:53 --> Total execution time: 0.7221
INFO - 2019-07-01 15:23:53 --> Config Class Initialized
INFO - 2019-07-01 15:23:53 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:23:53 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:23:53 --> Utf8 Class Initialized
INFO - 2019-07-01 15:23:53 --> URI Class Initialized
INFO - 2019-07-01 15:23:53 --> Router Class Initialized
INFO - 2019-07-01 15:23:53 --> Output Class Initialized
INFO - 2019-07-01 15:23:53 --> Security Class Initialized
DEBUG - 2019-07-01 15:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:23:53 --> Input Class Initialized
INFO - 2019-07-01 15:23:53 --> Language Class Initialized
INFO - 2019-07-01 15:23:53 --> Language Class Initialized
INFO - 2019-07-01 15:23:53 --> Config Class Initialized
INFO - 2019-07-01 15:23:53 --> Loader Class Initialized
DEBUG - 2019-07-01 15:23:53 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:23:53 --> Helper loaded: url_helper
INFO - 2019-07-01 15:23:53 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:23:53 --> Helper loaded: string_helper
INFO - 2019-07-01 15:23:53 --> Helper loaded: array_helper
INFO - 2019-07-01 15:23:53 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:23:53 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:23:53 --> Database Driver Class Initialized
INFO - 2019-07-01 15:23:53 --> Controller Class Initialized
INFO - 2019-07-01 21:23:53 --> Helper loaded: language_helper
INFO - 2019-07-01 21:23:53 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:23:53 --> Model Class Initialized
INFO - 2019-07-01 21:23:53 --> Model Class Initialized
INFO - 2019-07-01 21:23:53 --> Model Class Initialized
INFO - 2019-07-01 21:23:54 --> Model Class Initialized
INFO - 2019-07-01 21:23:54 --> Helper loaded: form_helper
INFO - 2019-07-01 21:23:54 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:23:54 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:23:54 --> Model Class Initialized
INFO - 2019-07-01 21:23:54 --> Model Class Initialized
INFO - 2019-07-01 21:23:54 --> Final output sent to browser
DEBUG - 2019-07-01 21:23:54 --> Total execution time: 0.9114
INFO - 2019-07-01 15:23:54 --> Config Class Initialized
INFO - 2019-07-01 15:23:54 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:23:54 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:23:54 --> Utf8 Class Initialized
INFO - 2019-07-01 15:23:54 --> URI Class Initialized
INFO - 2019-07-01 15:23:54 --> Router Class Initialized
INFO - 2019-07-01 15:23:54 --> Output Class Initialized
INFO - 2019-07-01 15:23:54 --> Security Class Initialized
DEBUG - 2019-07-01 15:23:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:23:54 --> Input Class Initialized
INFO - 2019-07-01 15:23:54 --> Language Class Initialized
INFO - 2019-07-01 15:23:54 --> Language Class Initialized
INFO - 2019-07-01 15:23:54 --> Config Class Initialized
INFO - 2019-07-01 15:23:54 --> Loader Class Initialized
DEBUG - 2019-07-01 15:23:54 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:23:54 --> Helper loaded: url_helper
INFO - 2019-07-01 15:23:54 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:23:54 --> Helper loaded: string_helper
INFO - 2019-07-01 15:23:54 --> Helper loaded: array_helper
INFO - 2019-07-01 15:23:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:23:54 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:23:54 --> Database Driver Class Initialized
INFO - 2019-07-01 15:23:54 --> Controller Class Initialized
INFO - 2019-07-01 21:23:54 --> Helper loaded: language_helper
INFO - 2019-07-01 21:23:54 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:23:54 --> Model Class Initialized
INFO - 2019-07-01 21:23:54 --> Model Class Initialized
INFO - 2019-07-01 21:23:55 --> Model Class Initialized
INFO - 2019-07-01 21:23:55 --> Model Class Initialized
INFO - 2019-07-01 21:23:55 --> Helper loaded: form_helper
INFO - 2019-07-01 21:23:55 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:23:55 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:23:55 --> Model Class Initialized
INFO - 2019-07-01 21:23:55 --> Model Class Initialized
INFO - 2019-07-01 21:23:55 --> Final output sent to browser
DEBUG - 2019-07-01 21:23:55 --> Total execution time: 0.9370
INFO - 2019-07-01 15:23:55 --> Config Class Initialized
INFO - 2019-07-01 15:23:55 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:23:55 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:23:55 --> Utf8 Class Initialized
INFO - 2019-07-01 15:23:55 --> URI Class Initialized
INFO - 2019-07-01 15:23:55 --> Router Class Initialized
INFO - 2019-07-01 15:23:55 --> Output Class Initialized
INFO - 2019-07-01 15:23:55 --> Security Class Initialized
DEBUG - 2019-07-01 15:23:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:23:55 --> Input Class Initialized
INFO - 2019-07-01 15:23:55 --> Language Class Initialized
INFO - 2019-07-01 15:23:55 --> Language Class Initialized
INFO - 2019-07-01 15:23:55 --> Config Class Initialized
INFO - 2019-07-01 15:23:55 --> Loader Class Initialized
DEBUG - 2019-07-01 15:23:55 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:23:55 --> Helper loaded: url_helper
INFO - 2019-07-01 15:23:56 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:23:56 --> Helper loaded: string_helper
INFO - 2019-07-01 15:23:56 --> Helper loaded: array_helper
INFO - 2019-07-01 15:23:56 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:23:56 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:23:56 --> Database Driver Class Initialized
INFO - 2019-07-01 15:23:56 --> Controller Class Initialized
INFO - 2019-07-01 21:23:56 --> Helper loaded: language_helper
INFO - 2019-07-01 21:23:56 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:23:56 --> Model Class Initialized
INFO - 2019-07-01 21:23:56 --> Model Class Initialized
INFO - 2019-07-01 21:23:56 --> Model Class Initialized
INFO - 2019-07-01 21:23:56 --> Model Class Initialized
INFO - 2019-07-01 21:23:56 --> Helper loaded: form_helper
INFO - 2019-07-01 21:23:56 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:23:56 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:23:56 --> Model Class Initialized
INFO - 2019-07-01 21:23:56 --> Model Class Initialized
INFO - 2019-07-01 21:23:56 --> Final output sent to browser
DEBUG - 2019-07-01 21:23:56 --> Total execution time: 1.3337
INFO - 2019-07-01 15:23:56 --> Config Class Initialized
INFO - 2019-07-01 15:23:56 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:23:56 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:23:56 --> Utf8 Class Initialized
INFO - 2019-07-01 15:23:56 --> URI Class Initialized
INFO - 2019-07-01 15:23:56 --> Router Class Initialized
INFO - 2019-07-01 15:23:56 --> Output Class Initialized
INFO - 2019-07-01 15:23:57 --> Security Class Initialized
DEBUG - 2019-07-01 15:23:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:23:57 --> Input Class Initialized
INFO - 2019-07-01 15:23:57 --> Language Class Initialized
INFO - 2019-07-01 15:23:57 --> Language Class Initialized
INFO - 2019-07-01 15:23:57 --> Config Class Initialized
INFO - 2019-07-01 15:23:57 --> Loader Class Initialized
DEBUG - 2019-07-01 15:23:57 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:23:57 --> Helper loaded: url_helper
INFO - 2019-07-01 15:23:57 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:23:57 --> Helper loaded: string_helper
INFO - 2019-07-01 15:23:57 --> Helper loaded: array_helper
INFO - 2019-07-01 15:23:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:23:57 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:23:57 --> Database Driver Class Initialized
INFO - 2019-07-01 15:23:57 --> Controller Class Initialized
INFO - 2019-07-01 21:23:57 --> Helper loaded: language_helper
INFO - 2019-07-01 21:23:57 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:23:57 --> Model Class Initialized
INFO - 2019-07-01 21:23:57 --> Model Class Initialized
INFO - 2019-07-01 21:23:57 --> Model Class Initialized
INFO - 2019-07-01 21:23:57 --> Model Class Initialized
INFO - 2019-07-01 21:23:57 --> Helper loaded: form_helper
INFO - 2019-07-01 21:23:57 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:23:57 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:23:57 --> Model Class Initialized
INFO - 2019-07-01 21:23:57 --> Model Class Initialized
INFO - 2019-07-01 21:23:57 --> Final output sent to browser
DEBUG - 2019-07-01 21:23:57 --> Total execution time: 1.0325
INFO - 2019-07-01 15:23:57 --> Config Class Initialized
INFO - 2019-07-01 15:23:57 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:23:57 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:23:57 --> Utf8 Class Initialized
INFO - 2019-07-01 15:23:57 --> URI Class Initialized
INFO - 2019-07-01 15:23:58 --> Router Class Initialized
INFO - 2019-07-01 15:23:58 --> Output Class Initialized
INFO - 2019-07-01 15:23:58 --> Security Class Initialized
DEBUG - 2019-07-01 15:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:23:58 --> Input Class Initialized
INFO - 2019-07-01 15:23:58 --> Language Class Initialized
INFO - 2019-07-01 15:23:58 --> Language Class Initialized
INFO - 2019-07-01 15:23:58 --> Config Class Initialized
INFO - 2019-07-01 15:23:58 --> Loader Class Initialized
DEBUG - 2019-07-01 15:23:58 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:23:58 --> Helper loaded: url_helper
INFO - 2019-07-01 15:23:58 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:23:58 --> Helper loaded: string_helper
INFO - 2019-07-01 15:23:58 --> Helper loaded: array_helper
INFO - 2019-07-01 15:23:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:23:58 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:23:58 --> Database Driver Class Initialized
INFO - 2019-07-01 15:23:58 --> Controller Class Initialized
INFO - 2019-07-01 21:23:58 --> Helper loaded: language_helper
INFO - 2019-07-01 21:23:58 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:23:58 --> Model Class Initialized
INFO - 2019-07-01 21:23:58 --> Model Class Initialized
INFO - 2019-07-01 21:23:58 --> Model Class Initialized
INFO - 2019-07-01 21:23:58 --> Model Class Initialized
INFO - 2019-07-01 21:23:58 --> Helper loaded: form_helper
INFO - 2019-07-01 21:23:58 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:23:58 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:23:58 --> Model Class Initialized
INFO - 2019-07-01 21:23:58 --> Model Class Initialized
INFO - 2019-07-01 21:23:58 --> Final output sent to browser
DEBUG - 2019-07-01 21:23:58 --> Total execution time: 0.8934
INFO - 2019-07-01 15:23:58 --> Config Class Initialized
INFO - 2019-07-01 15:23:58 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:23:58 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:23:58 --> Utf8 Class Initialized
INFO - 2019-07-01 15:23:58 --> URI Class Initialized
INFO - 2019-07-01 15:23:58 --> Router Class Initialized
INFO - 2019-07-01 15:23:58 --> Output Class Initialized
INFO - 2019-07-01 15:23:58 --> Security Class Initialized
DEBUG - 2019-07-01 15:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:23:59 --> Input Class Initialized
INFO - 2019-07-01 15:23:59 --> Language Class Initialized
INFO - 2019-07-01 15:23:59 --> Language Class Initialized
INFO - 2019-07-01 15:23:59 --> Config Class Initialized
INFO - 2019-07-01 15:23:59 --> Loader Class Initialized
DEBUG - 2019-07-01 15:23:59 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:23:59 --> Helper loaded: url_helper
INFO - 2019-07-01 15:23:59 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:23:59 --> Helper loaded: string_helper
INFO - 2019-07-01 15:23:59 --> Helper loaded: array_helper
INFO - 2019-07-01 15:23:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:23:59 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:23:59 --> Database Driver Class Initialized
INFO - 2019-07-01 15:23:59 --> Controller Class Initialized
INFO - 2019-07-01 21:23:59 --> Helper loaded: language_helper
INFO - 2019-07-01 21:23:59 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:23:59 --> Model Class Initialized
INFO - 2019-07-01 21:23:59 --> Model Class Initialized
INFO - 2019-07-01 21:23:59 --> Model Class Initialized
INFO - 2019-07-01 21:23:59 --> Model Class Initialized
INFO - 2019-07-01 21:23:59 --> Helper loaded: form_helper
INFO - 2019-07-01 21:23:59 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:23:59 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:23:59 --> Model Class Initialized
INFO - 2019-07-01 21:23:59 --> Model Class Initialized
INFO - 2019-07-01 21:23:59 --> Final output sent to browser
DEBUG - 2019-07-01 21:23:59 --> Total execution time: 0.6705
INFO - 2019-07-01 15:23:59 --> Config Class Initialized
INFO - 2019-07-01 15:23:59 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:23:59 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:23:59 --> Utf8 Class Initialized
INFO - 2019-07-01 15:23:59 --> URI Class Initialized
INFO - 2019-07-01 15:23:59 --> Router Class Initialized
INFO - 2019-07-01 15:23:59 --> Output Class Initialized
INFO - 2019-07-01 15:23:59 --> Security Class Initialized
DEBUG - 2019-07-01 15:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:23:59 --> Input Class Initialized
INFO - 2019-07-01 15:23:59 --> Language Class Initialized
INFO - 2019-07-01 15:23:59 --> Language Class Initialized
INFO - 2019-07-01 15:23:59 --> Config Class Initialized
INFO - 2019-07-01 15:23:59 --> Loader Class Initialized
DEBUG - 2019-07-01 15:23:59 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:24:00 --> Helper loaded: url_helper
INFO - 2019-07-01 15:24:00 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:24:00 --> Helper loaded: string_helper
INFO - 2019-07-01 15:24:00 --> Helper loaded: array_helper
INFO - 2019-07-01 15:24:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:24:00 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:24:00 --> Database Driver Class Initialized
INFO - 2019-07-01 15:24:00 --> Controller Class Initialized
INFO - 2019-07-01 21:24:00 --> Helper loaded: language_helper
INFO - 2019-07-01 21:24:00 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:24:00 --> Model Class Initialized
INFO - 2019-07-01 21:24:00 --> Model Class Initialized
INFO - 2019-07-01 21:24:00 --> Model Class Initialized
INFO - 2019-07-01 21:24:00 --> Model Class Initialized
INFO - 2019-07-01 21:24:00 --> Helper loaded: form_helper
INFO - 2019-07-01 21:24:00 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:24:00 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:24:00 --> Model Class Initialized
INFO - 2019-07-01 21:24:00 --> Model Class Initialized
INFO - 2019-07-01 21:24:00 --> Final output sent to browser
DEBUG - 2019-07-01 21:24:00 --> Total execution time: 0.8764
INFO - 2019-07-01 15:24:00 --> Config Class Initialized
INFO - 2019-07-01 15:24:00 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:24:00 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:24:00 --> Utf8 Class Initialized
INFO - 2019-07-01 15:24:00 --> URI Class Initialized
INFO - 2019-07-01 15:24:00 --> Router Class Initialized
INFO - 2019-07-01 15:24:00 --> Output Class Initialized
INFO - 2019-07-01 15:24:00 --> Security Class Initialized
DEBUG - 2019-07-01 15:24:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:24:00 --> Input Class Initialized
INFO - 2019-07-01 15:24:00 --> Language Class Initialized
INFO - 2019-07-01 15:24:00 --> Language Class Initialized
INFO - 2019-07-01 15:24:00 --> Config Class Initialized
INFO - 2019-07-01 15:24:00 --> Loader Class Initialized
DEBUG - 2019-07-01 15:24:00 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:24:00 --> Helper loaded: url_helper
INFO - 2019-07-01 15:24:00 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:24:00 --> Helper loaded: string_helper
INFO - 2019-07-01 15:24:00 --> Helper loaded: array_helper
INFO - 2019-07-01 15:24:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:24:00 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:24:01 --> Database Driver Class Initialized
INFO - 2019-07-01 15:24:01 --> Controller Class Initialized
INFO - 2019-07-01 21:24:01 --> Helper loaded: language_helper
INFO - 2019-07-01 21:24:01 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:24:01 --> Model Class Initialized
INFO - 2019-07-01 21:24:01 --> Model Class Initialized
INFO - 2019-07-01 21:24:01 --> Model Class Initialized
INFO - 2019-07-01 21:24:01 --> Model Class Initialized
INFO - 2019-07-01 21:24:01 --> Helper loaded: form_helper
INFO - 2019-07-01 21:24:01 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:24:01 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:24:01 --> Model Class Initialized
INFO - 2019-07-01 21:24:01 --> Model Class Initialized
INFO - 2019-07-01 21:24:01 --> Final output sent to browser
DEBUG - 2019-07-01 21:24:01 --> Total execution time: 0.7180
INFO - 2019-07-01 15:24:01 --> Config Class Initialized
INFO - 2019-07-01 15:24:01 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:24:01 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:24:01 --> Utf8 Class Initialized
INFO - 2019-07-01 15:24:01 --> URI Class Initialized
INFO - 2019-07-01 15:24:01 --> Router Class Initialized
INFO - 2019-07-01 15:24:01 --> Output Class Initialized
INFO - 2019-07-01 15:24:01 --> Security Class Initialized
DEBUG - 2019-07-01 15:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:24:01 --> Input Class Initialized
INFO - 2019-07-01 15:24:01 --> Language Class Initialized
INFO - 2019-07-01 15:24:01 --> Language Class Initialized
INFO - 2019-07-01 15:24:01 --> Config Class Initialized
INFO - 2019-07-01 15:24:01 --> Loader Class Initialized
DEBUG - 2019-07-01 15:24:01 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:24:01 --> Helper loaded: url_helper
INFO - 2019-07-01 15:24:01 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:24:01 --> Helper loaded: string_helper
INFO - 2019-07-01 15:24:01 --> Helper loaded: array_helper
INFO - 2019-07-01 15:24:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:24:01 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:24:01 --> Database Driver Class Initialized
INFO - 2019-07-01 15:24:02 --> Controller Class Initialized
INFO - 2019-07-01 21:24:02 --> Helper loaded: language_helper
INFO - 2019-07-01 21:24:02 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:24:02 --> Model Class Initialized
INFO - 2019-07-01 21:24:02 --> Model Class Initialized
INFO - 2019-07-01 21:24:02 --> Model Class Initialized
INFO - 2019-07-01 21:24:02 --> Model Class Initialized
INFO - 2019-07-01 21:24:02 --> Helper loaded: form_helper
INFO - 2019-07-01 21:24:02 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:24:02 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:24:02 --> Model Class Initialized
INFO - 2019-07-01 21:24:02 --> Model Class Initialized
INFO - 2019-07-01 21:24:02 --> Final output sent to browser
DEBUG - 2019-07-01 21:24:02 --> Total execution time: 0.8555
INFO - 2019-07-01 15:24:02 --> Config Class Initialized
INFO - 2019-07-01 15:24:02 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:24:02 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:24:02 --> Utf8 Class Initialized
INFO - 2019-07-01 15:24:02 --> URI Class Initialized
INFO - 2019-07-01 15:24:02 --> Router Class Initialized
INFO - 2019-07-01 15:24:02 --> Output Class Initialized
INFO - 2019-07-01 15:24:02 --> Security Class Initialized
DEBUG - 2019-07-01 15:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:24:02 --> Input Class Initialized
INFO - 2019-07-01 15:24:02 --> Language Class Initialized
INFO - 2019-07-01 15:24:02 --> Language Class Initialized
INFO - 2019-07-01 15:24:02 --> Config Class Initialized
INFO - 2019-07-01 15:24:02 --> Loader Class Initialized
DEBUG - 2019-07-01 15:24:02 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:24:02 --> Helper loaded: url_helper
INFO - 2019-07-01 15:24:02 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:24:02 --> Helper loaded: string_helper
INFO - 2019-07-01 15:24:02 --> Helper loaded: array_helper
INFO - 2019-07-01 15:24:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:24:02 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:24:02 --> Database Driver Class Initialized
INFO - 2019-07-01 15:24:03 --> Controller Class Initialized
INFO - 2019-07-01 21:24:03 --> Helper loaded: language_helper
INFO - 2019-07-01 21:24:03 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:24:03 --> Model Class Initialized
INFO - 2019-07-01 21:24:03 --> Model Class Initialized
INFO - 2019-07-01 21:24:03 --> Model Class Initialized
INFO - 2019-07-01 21:24:03 --> Model Class Initialized
INFO - 2019-07-01 21:24:03 --> Helper loaded: form_helper
INFO - 2019-07-01 21:24:03 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:24:03 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:24:03 --> Model Class Initialized
INFO - 2019-07-01 21:24:03 --> Model Class Initialized
INFO - 2019-07-01 21:24:03 --> Final output sent to browser
DEBUG - 2019-07-01 21:24:03 --> Total execution time: 0.9843
INFO - 2019-07-01 15:24:03 --> Config Class Initialized
INFO - 2019-07-01 15:24:03 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:24:03 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:24:03 --> Utf8 Class Initialized
INFO - 2019-07-01 15:24:03 --> URI Class Initialized
INFO - 2019-07-01 15:24:03 --> Router Class Initialized
INFO - 2019-07-01 15:24:03 --> Output Class Initialized
INFO - 2019-07-01 15:24:03 --> Security Class Initialized
DEBUG - 2019-07-01 15:24:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:24:03 --> Input Class Initialized
INFO - 2019-07-01 15:24:03 --> Language Class Initialized
INFO - 2019-07-01 15:24:03 --> Language Class Initialized
INFO - 2019-07-01 15:24:03 --> Config Class Initialized
INFO - 2019-07-01 15:24:03 --> Loader Class Initialized
DEBUG - 2019-07-01 15:24:03 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:24:03 --> Helper loaded: url_helper
INFO - 2019-07-01 15:24:03 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:24:03 --> Helper loaded: string_helper
INFO - 2019-07-01 15:24:03 --> Helper loaded: array_helper
INFO - 2019-07-01 15:24:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:24:03 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:24:03 --> Database Driver Class Initialized
INFO - 2019-07-01 15:24:04 --> Controller Class Initialized
INFO - 2019-07-01 21:24:04 --> Helper loaded: language_helper
INFO - 2019-07-01 21:24:04 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:24:04 --> Model Class Initialized
INFO - 2019-07-01 21:24:04 --> Model Class Initialized
INFO - 2019-07-01 21:24:04 --> Model Class Initialized
INFO - 2019-07-01 21:24:04 --> Model Class Initialized
INFO - 2019-07-01 21:24:04 --> Helper loaded: form_helper
INFO - 2019-07-01 21:24:04 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:24:04 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:24:04 --> Model Class Initialized
INFO - 2019-07-01 21:24:04 --> Model Class Initialized
INFO - 2019-07-01 21:24:04 --> Final output sent to browser
DEBUG - 2019-07-01 21:24:04 --> Total execution time: 0.8214
INFO - 2019-07-01 15:24:04 --> Config Class Initialized
INFO - 2019-07-01 15:24:04 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:24:04 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:24:04 --> Utf8 Class Initialized
INFO - 2019-07-01 15:24:04 --> URI Class Initialized
INFO - 2019-07-01 15:24:04 --> Router Class Initialized
INFO - 2019-07-01 15:24:04 --> Output Class Initialized
INFO - 2019-07-01 15:24:04 --> Security Class Initialized
DEBUG - 2019-07-01 15:24:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:24:04 --> Input Class Initialized
INFO - 2019-07-01 15:24:04 --> Language Class Initialized
INFO - 2019-07-01 15:24:04 --> Language Class Initialized
INFO - 2019-07-01 15:24:04 --> Config Class Initialized
INFO - 2019-07-01 15:24:04 --> Loader Class Initialized
DEBUG - 2019-07-01 15:24:04 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:24:04 --> Helper loaded: url_helper
INFO - 2019-07-01 15:24:04 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:24:04 --> Helper loaded: string_helper
INFO - 2019-07-01 15:24:04 --> Helper loaded: array_helper
INFO - 2019-07-01 15:24:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:24:04 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:24:04 --> Database Driver Class Initialized
INFO - 2019-07-01 15:24:04 --> Controller Class Initialized
INFO - 2019-07-01 21:24:04 --> Helper loaded: language_helper
INFO - 2019-07-01 21:24:04 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:24:04 --> Model Class Initialized
INFO - 2019-07-01 21:24:04 --> Model Class Initialized
INFO - 2019-07-01 21:24:04 --> Model Class Initialized
INFO - 2019-07-01 21:24:04 --> Model Class Initialized
INFO - 2019-07-01 21:24:04 --> Helper loaded: form_helper
INFO - 2019-07-01 21:24:04 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:24:04 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:24:04 --> Model Class Initialized
INFO - 2019-07-01 21:24:04 --> Model Class Initialized
INFO - 2019-07-01 21:24:04 --> Final output sent to browser
DEBUG - 2019-07-01 21:24:04 --> Total execution time: 0.6523
INFO - 2019-07-01 15:24:05 --> Config Class Initialized
INFO - 2019-07-01 15:24:05 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:24:05 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:24:05 --> Utf8 Class Initialized
INFO - 2019-07-01 15:24:05 --> URI Class Initialized
INFO - 2019-07-01 15:24:05 --> Router Class Initialized
INFO - 2019-07-01 15:24:05 --> Output Class Initialized
INFO - 2019-07-01 15:24:05 --> Security Class Initialized
DEBUG - 2019-07-01 15:24:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:24:05 --> Input Class Initialized
INFO - 2019-07-01 15:24:05 --> Language Class Initialized
INFO - 2019-07-01 15:24:05 --> Language Class Initialized
INFO - 2019-07-01 15:24:05 --> Config Class Initialized
INFO - 2019-07-01 15:24:05 --> Loader Class Initialized
DEBUG - 2019-07-01 15:24:05 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:24:05 --> Helper loaded: url_helper
INFO - 2019-07-01 15:24:05 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:24:05 --> Helper loaded: string_helper
INFO - 2019-07-01 15:24:05 --> Helper loaded: array_helper
INFO - 2019-07-01 15:24:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:24:05 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:24:05 --> Database Driver Class Initialized
INFO - 2019-07-01 15:24:05 --> Controller Class Initialized
INFO - 2019-07-01 21:24:05 --> Helper loaded: language_helper
INFO - 2019-07-01 21:24:05 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:24:05 --> Model Class Initialized
INFO - 2019-07-01 21:24:05 --> Model Class Initialized
INFO - 2019-07-01 21:24:05 --> Model Class Initialized
INFO - 2019-07-01 21:24:05 --> Model Class Initialized
INFO - 2019-07-01 21:24:05 --> Helper loaded: form_helper
INFO - 2019-07-01 21:24:05 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:24:05 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:24:05 --> Model Class Initialized
INFO - 2019-07-01 21:24:05 --> Model Class Initialized
INFO - 2019-07-01 21:24:05 --> Final output sent to browser
DEBUG - 2019-07-01 21:24:05 --> Total execution time: 0.7946
INFO - 2019-07-01 15:24:05 --> Config Class Initialized
INFO - 2019-07-01 15:24:05 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:24:05 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:24:05 --> Utf8 Class Initialized
INFO - 2019-07-01 15:24:05 --> URI Class Initialized
INFO - 2019-07-01 15:24:06 --> Router Class Initialized
INFO - 2019-07-01 15:24:06 --> Output Class Initialized
INFO - 2019-07-01 15:24:06 --> Security Class Initialized
DEBUG - 2019-07-01 15:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:24:06 --> Input Class Initialized
INFO - 2019-07-01 15:24:06 --> Language Class Initialized
INFO - 2019-07-01 15:24:06 --> Language Class Initialized
INFO - 2019-07-01 15:24:06 --> Config Class Initialized
INFO - 2019-07-01 15:24:06 --> Loader Class Initialized
DEBUG - 2019-07-01 15:24:06 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:24:06 --> Helper loaded: url_helper
INFO - 2019-07-01 15:24:06 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:24:06 --> Helper loaded: string_helper
INFO - 2019-07-01 15:24:06 --> Helper loaded: array_helper
INFO - 2019-07-01 15:24:06 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:24:06 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:24:06 --> Database Driver Class Initialized
INFO - 2019-07-01 15:24:06 --> Controller Class Initialized
INFO - 2019-07-01 21:24:06 --> Helper loaded: language_helper
INFO - 2019-07-01 21:24:06 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:24:06 --> Model Class Initialized
INFO - 2019-07-01 21:24:06 --> Model Class Initialized
INFO - 2019-07-01 21:24:06 --> Model Class Initialized
INFO - 2019-07-01 21:24:06 --> Model Class Initialized
INFO - 2019-07-01 21:24:06 --> Helper loaded: form_helper
INFO - 2019-07-01 21:24:06 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:24:06 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:24:06 --> Model Class Initialized
INFO - 2019-07-01 21:24:06 --> Model Class Initialized
INFO - 2019-07-01 21:24:06 --> Final output sent to browser
DEBUG - 2019-07-01 21:24:06 --> Total execution time: 0.7138
INFO - 2019-07-01 15:24:06 --> Config Class Initialized
INFO - 2019-07-01 15:24:06 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:24:06 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:24:06 --> Utf8 Class Initialized
INFO - 2019-07-01 15:24:06 --> URI Class Initialized
INFO - 2019-07-01 15:24:06 --> Router Class Initialized
INFO - 2019-07-01 15:24:06 --> Output Class Initialized
INFO - 2019-07-01 15:24:06 --> Security Class Initialized
DEBUG - 2019-07-01 15:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:24:06 --> Input Class Initialized
INFO - 2019-07-01 15:24:06 --> Language Class Initialized
INFO - 2019-07-01 15:24:06 --> Language Class Initialized
INFO - 2019-07-01 15:24:06 --> Config Class Initialized
INFO - 2019-07-01 15:24:06 --> Loader Class Initialized
DEBUG - 2019-07-01 15:24:06 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:24:06 --> Helper loaded: url_helper
INFO - 2019-07-01 15:24:06 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:24:07 --> Helper loaded: string_helper
INFO - 2019-07-01 15:24:07 --> Helper loaded: array_helper
INFO - 2019-07-01 15:24:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:24:07 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:24:07 --> Database Driver Class Initialized
INFO - 2019-07-01 15:24:07 --> Controller Class Initialized
INFO - 2019-07-01 21:24:07 --> Helper loaded: language_helper
INFO - 2019-07-01 21:24:07 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:24:07 --> Model Class Initialized
INFO - 2019-07-01 21:24:07 --> Model Class Initialized
INFO - 2019-07-01 21:24:07 --> Model Class Initialized
INFO - 2019-07-01 21:24:07 --> Model Class Initialized
INFO - 2019-07-01 21:24:07 --> Helper loaded: form_helper
INFO - 2019-07-01 21:24:07 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:24:07 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:24:07 --> Model Class Initialized
INFO - 2019-07-01 21:24:07 --> Model Class Initialized
INFO - 2019-07-01 21:24:07 --> Final output sent to browser
DEBUG - 2019-07-01 21:24:07 --> Total execution time: 0.6504
INFO - 2019-07-01 15:24:07 --> Config Class Initialized
INFO - 2019-07-01 15:24:07 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:24:07 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:24:07 --> Utf8 Class Initialized
INFO - 2019-07-01 15:24:07 --> URI Class Initialized
INFO - 2019-07-01 15:24:07 --> Router Class Initialized
INFO - 2019-07-01 15:24:07 --> Output Class Initialized
INFO - 2019-07-01 15:24:07 --> Security Class Initialized
DEBUG - 2019-07-01 15:24:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:24:07 --> Input Class Initialized
INFO - 2019-07-01 15:24:07 --> Language Class Initialized
INFO - 2019-07-01 15:24:07 --> Language Class Initialized
INFO - 2019-07-01 15:24:07 --> Config Class Initialized
INFO - 2019-07-01 15:24:07 --> Loader Class Initialized
DEBUG - 2019-07-01 15:24:07 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:24:07 --> Helper loaded: url_helper
INFO - 2019-07-01 15:24:07 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:24:07 --> Helper loaded: string_helper
INFO - 2019-07-01 15:24:07 --> Helper loaded: array_helper
INFO - 2019-07-01 15:24:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:24:07 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:24:07 --> Database Driver Class Initialized
INFO - 2019-07-01 15:24:07 --> Controller Class Initialized
INFO - 2019-07-01 21:24:07 --> Helper loaded: language_helper
INFO - 2019-07-01 21:24:07 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:24:07 --> Model Class Initialized
INFO - 2019-07-01 21:24:07 --> Model Class Initialized
INFO - 2019-07-01 21:24:07 --> Model Class Initialized
INFO - 2019-07-01 21:24:07 --> Model Class Initialized
INFO - 2019-07-01 21:24:07 --> Helper loaded: form_helper
INFO - 2019-07-01 21:24:08 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:24:08 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:24:08 --> Model Class Initialized
INFO - 2019-07-01 21:24:08 --> Model Class Initialized
INFO - 2019-07-01 21:24:08 --> Final output sent to browser
DEBUG - 2019-07-01 21:24:08 --> Total execution time: 0.6755
INFO - 2019-07-01 15:24:08 --> Config Class Initialized
INFO - 2019-07-01 15:24:08 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:24:08 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:24:08 --> Utf8 Class Initialized
INFO - 2019-07-01 15:24:08 --> URI Class Initialized
INFO - 2019-07-01 15:24:08 --> Router Class Initialized
INFO - 2019-07-01 15:24:08 --> Output Class Initialized
INFO - 2019-07-01 15:24:08 --> Security Class Initialized
DEBUG - 2019-07-01 15:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:24:08 --> Input Class Initialized
INFO - 2019-07-01 15:24:08 --> Language Class Initialized
INFO - 2019-07-01 15:24:08 --> Language Class Initialized
INFO - 2019-07-01 15:24:08 --> Config Class Initialized
INFO - 2019-07-01 15:24:08 --> Loader Class Initialized
DEBUG - 2019-07-01 15:24:08 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:24:08 --> Helper loaded: url_helper
INFO - 2019-07-01 15:24:08 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:24:08 --> Helper loaded: string_helper
INFO - 2019-07-01 15:24:08 --> Helper loaded: array_helper
INFO - 2019-07-01 15:24:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:24:08 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:24:08 --> Database Driver Class Initialized
INFO - 2019-07-01 15:24:08 --> Controller Class Initialized
INFO - 2019-07-01 21:24:08 --> Helper loaded: language_helper
INFO - 2019-07-01 21:24:08 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:24:08 --> Model Class Initialized
INFO - 2019-07-01 21:24:08 --> Model Class Initialized
INFO - 2019-07-01 21:24:08 --> Model Class Initialized
INFO - 2019-07-01 21:24:08 --> Model Class Initialized
INFO - 2019-07-01 21:24:08 --> Helper loaded: form_helper
INFO - 2019-07-01 21:24:08 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:24:09 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:24:09 --> Model Class Initialized
INFO - 2019-07-01 21:24:09 --> Model Class Initialized
INFO - 2019-07-01 21:24:09 --> Final output sent to browser
DEBUG - 2019-07-01 21:24:09 --> Total execution time: 0.8854
INFO - 2019-07-01 15:24:09 --> Config Class Initialized
INFO - 2019-07-01 15:24:09 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:24:09 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:24:09 --> Utf8 Class Initialized
INFO - 2019-07-01 15:24:09 --> URI Class Initialized
INFO - 2019-07-01 15:24:09 --> Router Class Initialized
INFO - 2019-07-01 15:24:09 --> Output Class Initialized
INFO - 2019-07-01 15:24:09 --> Security Class Initialized
DEBUG - 2019-07-01 15:24:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:24:09 --> Input Class Initialized
INFO - 2019-07-01 15:24:09 --> Language Class Initialized
INFO - 2019-07-01 15:24:09 --> Language Class Initialized
INFO - 2019-07-01 15:24:09 --> Config Class Initialized
INFO - 2019-07-01 15:24:09 --> Loader Class Initialized
DEBUG - 2019-07-01 15:24:09 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:24:09 --> Helper loaded: url_helper
INFO - 2019-07-01 15:24:09 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:24:09 --> Helper loaded: string_helper
INFO - 2019-07-01 15:24:09 --> Helper loaded: array_helper
INFO - 2019-07-01 15:24:09 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:24:09 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:24:09 --> Database Driver Class Initialized
INFO - 2019-07-01 15:24:09 --> Controller Class Initialized
INFO - 2019-07-01 21:24:09 --> Helper loaded: language_helper
INFO - 2019-07-01 21:24:09 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:24:09 --> Model Class Initialized
INFO - 2019-07-01 21:24:10 --> Model Class Initialized
INFO - 2019-07-01 21:24:10 --> Model Class Initialized
INFO - 2019-07-01 21:24:10 --> Model Class Initialized
INFO - 2019-07-01 21:24:10 --> Helper loaded: form_helper
INFO - 2019-07-01 21:24:10 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:24:10 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:24:10 --> Model Class Initialized
INFO - 2019-07-01 21:24:10 --> Model Class Initialized
INFO - 2019-07-01 21:24:10 --> Final output sent to browser
DEBUG - 2019-07-01 21:24:10 --> Total execution time: 1.0201
INFO - 2019-07-01 15:24:10 --> Config Class Initialized
INFO - 2019-07-01 15:24:10 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:24:10 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:24:10 --> Utf8 Class Initialized
INFO - 2019-07-01 15:24:10 --> URI Class Initialized
INFO - 2019-07-01 15:24:10 --> Router Class Initialized
INFO - 2019-07-01 15:24:10 --> Output Class Initialized
INFO - 2019-07-01 15:24:10 --> Security Class Initialized
DEBUG - 2019-07-01 15:24:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:24:10 --> Input Class Initialized
INFO - 2019-07-01 15:24:10 --> Language Class Initialized
INFO - 2019-07-01 15:24:10 --> Language Class Initialized
INFO - 2019-07-01 15:24:10 --> Config Class Initialized
INFO - 2019-07-01 15:24:10 --> Loader Class Initialized
DEBUG - 2019-07-01 15:24:10 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:24:10 --> Helper loaded: url_helper
INFO - 2019-07-01 15:24:10 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:24:10 --> Helper loaded: string_helper
INFO - 2019-07-01 15:24:10 --> Helper loaded: array_helper
INFO - 2019-07-01 15:24:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:24:10 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:24:10 --> Database Driver Class Initialized
INFO - 2019-07-01 15:24:10 --> Controller Class Initialized
INFO - 2019-07-01 21:24:10 --> Helper loaded: language_helper
INFO - 2019-07-01 21:24:10 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:24:10 --> Model Class Initialized
INFO - 2019-07-01 21:24:10 --> Model Class Initialized
INFO - 2019-07-01 21:24:10 --> Model Class Initialized
INFO - 2019-07-01 21:24:10 --> Model Class Initialized
INFO - 2019-07-01 21:24:10 --> Helper loaded: form_helper
INFO - 2019-07-01 21:24:10 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:24:11 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:24:11 --> Model Class Initialized
INFO - 2019-07-01 21:24:11 --> Model Class Initialized
INFO - 2019-07-01 21:24:11 --> Final output sent to browser
DEBUG - 2019-07-01 21:24:11 --> Total execution time: 0.7657
INFO - 2019-07-01 15:24:11 --> Config Class Initialized
INFO - 2019-07-01 15:24:11 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:24:11 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:24:11 --> Utf8 Class Initialized
INFO - 2019-07-01 15:24:11 --> URI Class Initialized
INFO - 2019-07-01 15:24:11 --> Router Class Initialized
INFO - 2019-07-01 15:24:11 --> Output Class Initialized
INFO - 2019-07-01 15:24:11 --> Security Class Initialized
DEBUG - 2019-07-01 15:24:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:24:11 --> Input Class Initialized
INFO - 2019-07-01 15:24:11 --> Language Class Initialized
INFO - 2019-07-01 15:24:11 --> Language Class Initialized
INFO - 2019-07-01 15:24:11 --> Config Class Initialized
INFO - 2019-07-01 15:24:11 --> Loader Class Initialized
DEBUG - 2019-07-01 15:24:11 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:24:11 --> Helper loaded: url_helper
INFO - 2019-07-01 15:24:11 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:24:11 --> Helper loaded: string_helper
INFO - 2019-07-01 15:24:11 --> Helper loaded: array_helper
INFO - 2019-07-01 15:24:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:24:11 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:24:11 --> Database Driver Class Initialized
INFO - 2019-07-01 15:24:11 --> Controller Class Initialized
INFO - 2019-07-01 21:24:11 --> Helper loaded: language_helper
INFO - 2019-07-01 21:24:11 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:24:11 --> Model Class Initialized
INFO - 2019-07-01 21:24:11 --> Model Class Initialized
INFO - 2019-07-01 21:24:11 --> Model Class Initialized
INFO - 2019-07-01 21:24:11 --> Model Class Initialized
INFO - 2019-07-01 21:24:11 --> Helper loaded: form_helper
INFO - 2019-07-01 21:24:11 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:24:11 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:24:11 --> Model Class Initialized
INFO - 2019-07-01 21:24:11 --> Model Class Initialized
INFO - 2019-07-01 21:24:11 --> Final output sent to browser
DEBUG - 2019-07-01 21:24:11 --> Total execution time: 0.7283
INFO - 2019-07-01 15:24:11 --> Config Class Initialized
INFO - 2019-07-01 15:24:11 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:24:12 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:24:12 --> Utf8 Class Initialized
INFO - 2019-07-01 15:24:12 --> URI Class Initialized
INFO - 2019-07-01 15:24:12 --> Router Class Initialized
INFO - 2019-07-01 15:24:12 --> Output Class Initialized
INFO - 2019-07-01 15:24:12 --> Security Class Initialized
DEBUG - 2019-07-01 15:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:24:12 --> Input Class Initialized
INFO - 2019-07-01 15:24:12 --> Language Class Initialized
INFO - 2019-07-01 15:24:12 --> Language Class Initialized
INFO - 2019-07-01 15:24:12 --> Config Class Initialized
INFO - 2019-07-01 15:24:12 --> Loader Class Initialized
DEBUG - 2019-07-01 15:24:12 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:24:12 --> Helper loaded: url_helper
INFO - 2019-07-01 15:24:12 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:24:12 --> Helper loaded: string_helper
INFO - 2019-07-01 15:24:12 --> Helper loaded: array_helper
INFO - 2019-07-01 15:24:12 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:24:12 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:24:12 --> Database Driver Class Initialized
INFO - 2019-07-01 15:24:12 --> Controller Class Initialized
INFO - 2019-07-01 21:24:12 --> Helper loaded: language_helper
INFO - 2019-07-01 21:24:12 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:24:12 --> Model Class Initialized
INFO - 2019-07-01 21:24:12 --> Model Class Initialized
INFO - 2019-07-01 21:24:12 --> Model Class Initialized
INFO - 2019-07-01 21:24:12 --> Model Class Initialized
INFO - 2019-07-01 21:24:12 --> Helper loaded: form_helper
INFO - 2019-07-01 21:24:12 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:24:12 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:24:12 --> Model Class Initialized
INFO - 2019-07-01 21:24:12 --> Model Class Initialized
INFO - 2019-07-01 21:24:12 --> Final output sent to browser
DEBUG - 2019-07-01 21:24:12 --> Total execution time: 0.7363
INFO - 2019-07-01 15:24:12 --> Config Class Initialized
INFO - 2019-07-01 15:24:12 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:24:12 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:24:12 --> Utf8 Class Initialized
INFO - 2019-07-01 15:24:12 --> URI Class Initialized
INFO - 2019-07-01 15:24:12 --> Router Class Initialized
INFO - 2019-07-01 15:24:12 --> Output Class Initialized
INFO - 2019-07-01 15:24:12 --> Security Class Initialized
DEBUG - 2019-07-01 15:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:24:12 --> Input Class Initialized
INFO - 2019-07-01 15:24:12 --> Language Class Initialized
INFO - 2019-07-01 15:24:12 --> Language Class Initialized
INFO - 2019-07-01 15:24:12 --> Config Class Initialized
INFO - 2019-07-01 15:24:13 --> Loader Class Initialized
DEBUG - 2019-07-01 15:24:13 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:24:13 --> Helper loaded: url_helper
INFO - 2019-07-01 15:24:13 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:24:13 --> Helper loaded: string_helper
INFO - 2019-07-01 15:24:13 --> Helper loaded: array_helper
INFO - 2019-07-01 15:24:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:24:13 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:24:13 --> Database Driver Class Initialized
INFO - 2019-07-01 15:24:13 --> Controller Class Initialized
INFO - 2019-07-01 21:24:13 --> Helper loaded: language_helper
INFO - 2019-07-01 21:24:13 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:24:13 --> Model Class Initialized
INFO - 2019-07-01 21:24:13 --> Model Class Initialized
INFO - 2019-07-01 21:24:13 --> Model Class Initialized
INFO - 2019-07-01 21:24:13 --> Model Class Initialized
INFO - 2019-07-01 21:24:13 --> Helper loaded: form_helper
INFO - 2019-07-01 21:24:13 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:24:13 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:24:13 --> Model Class Initialized
INFO - 2019-07-01 21:24:13 --> Model Class Initialized
INFO - 2019-07-01 21:24:13 --> Final output sent to browser
DEBUG - 2019-07-01 21:24:13 --> Total execution time: 0.6779
INFO - 2019-07-01 15:24:13 --> Config Class Initialized
INFO - 2019-07-01 15:24:13 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:24:13 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:24:13 --> Utf8 Class Initialized
INFO - 2019-07-01 15:24:13 --> URI Class Initialized
INFO - 2019-07-01 15:24:13 --> Router Class Initialized
INFO - 2019-07-01 15:24:13 --> Output Class Initialized
INFO - 2019-07-01 15:24:13 --> Security Class Initialized
DEBUG - 2019-07-01 15:24:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:24:13 --> Input Class Initialized
INFO - 2019-07-01 15:24:13 --> Language Class Initialized
INFO - 2019-07-01 15:24:13 --> Language Class Initialized
INFO - 2019-07-01 15:24:13 --> Config Class Initialized
INFO - 2019-07-01 15:24:13 --> Loader Class Initialized
DEBUG - 2019-07-01 15:24:13 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:24:13 --> Helper loaded: url_helper
INFO - 2019-07-01 15:24:13 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:24:13 --> Helper loaded: string_helper
INFO - 2019-07-01 15:24:14 --> Helper loaded: array_helper
INFO - 2019-07-01 15:24:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:24:14 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:24:14 --> Database Driver Class Initialized
INFO - 2019-07-01 15:24:14 --> Controller Class Initialized
INFO - 2019-07-01 21:24:14 --> Helper loaded: language_helper
INFO - 2019-07-01 21:24:14 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:24:14 --> Model Class Initialized
INFO - 2019-07-01 21:24:14 --> Model Class Initialized
INFO - 2019-07-01 21:24:14 --> Model Class Initialized
INFO - 2019-07-01 21:24:14 --> Model Class Initialized
INFO - 2019-07-01 21:24:14 --> Helper loaded: form_helper
INFO - 2019-07-01 21:24:14 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:24:14 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:24:14 --> Model Class Initialized
INFO - 2019-07-01 21:24:14 --> Model Class Initialized
INFO - 2019-07-01 21:24:14 --> Final output sent to browser
DEBUG - 2019-07-01 21:24:14 --> Total execution time: 0.8125
INFO - 2019-07-01 15:24:14 --> Config Class Initialized
INFO - 2019-07-01 15:24:14 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:24:14 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:24:14 --> Utf8 Class Initialized
INFO - 2019-07-01 15:24:14 --> URI Class Initialized
INFO - 2019-07-01 15:24:14 --> Router Class Initialized
INFO - 2019-07-01 15:24:14 --> Output Class Initialized
INFO - 2019-07-01 15:24:14 --> Security Class Initialized
DEBUG - 2019-07-01 15:24:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:24:14 --> Input Class Initialized
INFO - 2019-07-01 15:24:14 --> Language Class Initialized
INFO - 2019-07-01 15:24:14 --> Language Class Initialized
INFO - 2019-07-01 15:24:14 --> Config Class Initialized
INFO - 2019-07-01 15:24:14 --> Loader Class Initialized
DEBUG - 2019-07-01 15:24:14 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:24:14 --> Helper loaded: url_helper
INFO - 2019-07-01 15:24:14 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:24:14 --> Helper loaded: string_helper
INFO - 2019-07-01 15:24:14 --> Helper loaded: array_helper
INFO - 2019-07-01 15:24:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:24:14 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:24:14 --> Database Driver Class Initialized
INFO - 2019-07-01 15:24:14 --> Controller Class Initialized
INFO - 2019-07-01 21:24:14 --> Helper loaded: language_helper
INFO - 2019-07-01 21:24:14 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:24:15 --> Model Class Initialized
INFO - 2019-07-01 21:24:15 --> Model Class Initialized
INFO - 2019-07-01 21:24:15 --> Model Class Initialized
INFO - 2019-07-01 21:24:15 --> Model Class Initialized
INFO - 2019-07-01 21:24:15 --> Helper loaded: form_helper
INFO - 2019-07-01 21:24:15 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:24:15 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:24:15 --> Model Class Initialized
INFO - 2019-07-01 21:24:15 --> Model Class Initialized
INFO - 2019-07-01 21:24:15 --> Final output sent to browser
DEBUG - 2019-07-01 21:24:15 --> Total execution time: 0.7167
INFO - 2019-07-01 15:24:15 --> Config Class Initialized
INFO - 2019-07-01 15:24:15 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:24:15 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:24:15 --> Utf8 Class Initialized
INFO - 2019-07-01 15:24:15 --> URI Class Initialized
INFO - 2019-07-01 15:24:15 --> Router Class Initialized
INFO - 2019-07-01 15:24:15 --> Output Class Initialized
INFO - 2019-07-01 15:24:15 --> Security Class Initialized
DEBUG - 2019-07-01 15:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:24:15 --> Input Class Initialized
INFO - 2019-07-01 15:24:15 --> Language Class Initialized
INFO - 2019-07-01 15:24:15 --> Language Class Initialized
INFO - 2019-07-01 15:24:15 --> Config Class Initialized
INFO - 2019-07-01 15:24:15 --> Loader Class Initialized
DEBUG - 2019-07-01 15:24:15 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:24:15 --> Helper loaded: url_helper
INFO - 2019-07-01 15:24:15 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:24:15 --> Helper loaded: string_helper
INFO - 2019-07-01 15:24:15 --> Helper loaded: array_helper
INFO - 2019-07-01 15:24:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:24:15 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:24:15 --> Database Driver Class Initialized
INFO - 2019-07-01 15:24:15 --> Controller Class Initialized
INFO - 2019-07-01 21:24:15 --> Helper loaded: language_helper
INFO - 2019-07-01 21:24:15 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:24:15 --> Model Class Initialized
INFO - 2019-07-01 21:24:15 --> Model Class Initialized
INFO - 2019-07-01 21:24:15 --> Model Class Initialized
INFO - 2019-07-01 21:24:15 --> Model Class Initialized
INFO - 2019-07-01 21:24:15 --> Helper loaded: form_helper
INFO - 2019-07-01 21:24:15 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:24:15 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:24:15 --> Model Class Initialized
INFO - 2019-07-01 21:24:15 --> Model Class Initialized
INFO - 2019-07-01 21:24:15 --> Final output sent to browser
DEBUG - 2019-07-01 21:24:15 --> Total execution time: 0.6846
INFO - 2019-07-01 15:24:15 --> Config Class Initialized
INFO - 2019-07-01 15:24:16 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:24:16 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:24:16 --> Utf8 Class Initialized
INFO - 2019-07-01 15:24:16 --> URI Class Initialized
INFO - 2019-07-01 15:24:16 --> Router Class Initialized
INFO - 2019-07-01 15:24:16 --> Output Class Initialized
INFO - 2019-07-01 15:24:16 --> Security Class Initialized
DEBUG - 2019-07-01 15:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:24:16 --> Input Class Initialized
INFO - 2019-07-01 15:24:16 --> Language Class Initialized
INFO - 2019-07-01 15:24:16 --> Language Class Initialized
INFO - 2019-07-01 15:24:16 --> Config Class Initialized
INFO - 2019-07-01 15:24:16 --> Loader Class Initialized
DEBUG - 2019-07-01 15:24:16 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:24:16 --> Helper loaded: url_helper
INFO - 2019-07-01 15:24:16 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:24:16 --> Helper loaded: string_helper
INFO - 2019-07-01 15:24:16 --> Helper loaded: array_helper
INFO - 2019-07-01 15:24:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:24:16 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:24:16 --> Database Driver Class Initialized
INFO - 2019-07-01 15:24:16 --> Controller Class Initialized
INFO - 2019-07-01 21:24:16 --> Helper loaded: language_helper
INFO - 2019-07-01 21:24:16 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:24:16 --> Model Class Initialized
INFO - 2019-07-01 21:24:16 --> Model Class Initialized
INFO - 2019-07-01 21:24:16 --> Model Class Initialized
INFO - 2019-07-01 21:24:16 --> Model Class Initialized
INFO - 2019-07-01 21:24:16 --> Helper loaded: form_helper
INFO - 2019-07-01 21:24:16 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:24:16 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:24:16 --> Model Class Initialized
INFO - 2019-07-01 21:24:16 --> Model Class Initialized
INFO - 2019-07-01 21:24:16 --> Final output sent to browser
DEBUG - 2019-07-01 21:24:16 --> Total execution time: 0.5698
INFO - 2019-07-01 15:24:16 --> Config Class Initialized
INFO - 2019-07-01 15:24:16 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:24:16 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:24:16 --> Utf8 Class Initialized
INFO - 2019-07-01 15:24:16 --> URI Class Initialized
INFO - 2019-07-01 15:24:16 --> Router Class Initialized
INFO - 2019-07-01 15:24:16 --> Output Class Initialized
INFO - 2019-07-01 15:24:16 --> Security Class Initialized
DEBUG - 2019-07-01 15:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:24:16 --> Input Class Initialized
INFO - 2019-07-01 15:24:16 --> Language Class Initialized
INFO - 2019-07-01 15:24:16 --> Language Class Initialized
INFO - 2019-07-01 15:24:16 --> Config Class Initialized
INFO - 2019-07-01 15:24:16 --> Loader Class Initialized
DEBUG - 2019-07-01 15:24:16 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:24:16 --> Helper loaded: url_helper
INFO - 2019-07-01 15:24:16 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:24:16 --> Helper loaded: string_helper
INFO - 2019-07-01 15:24:16 --> Helper loaded: array_helper
INFO - 2019-07-01 15:24:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:24:17 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:24:17 --> Database Driver Class Initialized
INFO - 2019-07-01 15:24:17 --> Controller Class Initialized
INFO - 2019-07-01 21:24:17 --> Helper loaded: language_helper
INFO - 2019-07-01 21:24:17 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:24:17 --> Model Class Initialized
INFO - 2019-07-01 21:24:17 --> Model Class Initialized
INFO - 2019-07-01 21:24:17 --> Model Class Initialized
INFO - 2019-07-01 21:24:17 --> Model Class Initialized
INFO - 2019-07-01 21:24:17 --> Helper loaded: form_helper
INFO - 2019-07-01 21:24:17 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:24:17 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:24:17 --> Model Class Initialized
INFO - 2019-07-01 21:24:17 --> Model Class Initialized
INFO - 2019-07-01 21:24:17 --> Final output sent to browser
DEBUG - 2019-07-01 21:24:17 --> Total execution time: 0.7136
INFO - 2019-07-01 15:24:17 --> Config Class Initialized
INFO - 2019-07-01 15:24:17 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:24:17 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:24:17 --> Utf8 Class Initialized
INFO - 2019-07-01 15:24:17 --> URI Class Initialized
INFO - 2019-07-01 15:24:17 --> Router Class Initialized
INFO - 2019-07-01 15:24:17 --> Output Class Initialized
INFO - 2019-07-01 15:24:17 --> Security Class Initialized
DEBUG - 2019-07-01 15:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:24:17 --> Input Class Initialized
INFO - 2019-07-01 15:24:17 --> Language Class Initialized
INFO - 2019-07-01 15:24:17 --> Language Class Initialized
INFO - 2019-07-01 15:24:17 --> Config Class Initialized
INFO - 2019-07-01 15:24:17 --> Loader Class Initialized
DEBUG - 2019-07-01 15:24:17 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:24:17 --> Helper loaded: url_helper
INFO - 2019-07-01 15:24:17 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:24:17 --> Helper loaded: string_helper
INFO - 2019-07-01 15:24:17 --> Helper loaded: array_helper
INFO - 2019-07-01 15:24:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:24:17 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:24:18 --> Database Driver Class Initialized
INFO - 2019-07-01 15:24:18 --> Controller Class Initialized
INFO - 2019-07-01 21:24:18 --> Helper loaded: language_helper
INFO - 2019-07-01 21:24:18 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:24:18 --> Model Class Initialized
INFO - 2019-07-01 21:24:18 --> Model Class Initialized
INFO - 2019-07-01 21:24:18 --> Model Class Initialized
INFO - 2019-07-01 21:24:18 --> Model Class Initialized
INFO - 2019-07-01 21:24:18 --> Helper loaded: form_helper
INFO - 2019-07-01 21:24:18 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:24:18 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:24:18 --> Model Class Initialized
INFO - 2019-07-01 21:24:18 --> Model Class Initialized
INFO - 2019-07-01 21:24:18 --> Final output sent to browser
DEBUG - 2019-07-01 21:24:18 --> Total execution time: 0.8931
INFO - 2019-07-01 15:24:18 --> Config Class Initialized
INFO - 2019-07-01 15:24:18 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:24:18 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:24:18 --> Utf8 Class Initialized
INFO - 2019-07-01 15:24:18 --> URI Class Initialized
INFO - 2019-07-01 15:24:18 --> Router Class Initialized
INFO - 2019-07-01 15:24:18 --> Output Class Initialized
INFO - 2019-07-01 15:24:18 --> Security Class Initialized
DEBUG - 2019-07-01 15:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:24:18 --> Input Class Initialized
INFO - 2019-07-01 15:24:18 --> Language Class Initialized
INFO - 2019-07-01 15:24:18 --> Language Class Initialized
INFO - 2019-07-01 15:24:18 --> Config Class Initialized
INFO - 2019-07-01 15:24:18 --> Loader Class Initialized
DEBUG - 2019-07-01 15:24:18 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:24:18 --> Helper loaded: url_helper
INFO - 2019-07-01 15:24:18 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:24:18 --> Helper loaded: string_helper
INFO - 2019-07-01 15:24:18 --> Helper loaded: array_helper
INFO - 2019-07-01 15:24:18 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:24:18 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:24:18 --> Database Driver Class Initialized
INFO - 2019-07-01 15:24:18 --> Controller Class Initialized
INFO - 2019-07-01 21:24:18 --> Helper loaded: language_helper
INFO - 2019-07-01 21:24:18 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:24:18 --> Model Class Initialized
INFO - 2019-07-01 21:24:18 --> Model Class Initialized
INFO - 2019-07-01 21:24:19 --> Model Class Initialized
INFO - 2019-07-01 21:24:19 --> Model Class Initialized
INFO - 2019-07-01 21:24:19 --> Helper loaded: form_helper
INFO - 2019-07-01 21:24:19 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:24:19 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:24:19 --> Model Class Initialized
INFO - 2019-07-01 21:24:19 --> Model Class Initialized
INFO - 2019-07-01 21:24:19 --> Final output sent to browser
DEBUG - 2019-07-01 21:24:19 --> Total execution time: 0.7213
INFO - 2019-07-01 15:24:19 --> Config Class Initialized
INFO - 2019-07-01 15:24:19 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:24:19 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:24:19 --> Utf8 Class Initialized
INFO - 2019-07-01 15:24:19 --> URI Class Initialized
INFO - 2019-07-01 15:24:19 --> Router Class Initialized
INFO - 2019-07-01 15:24:19 --> Output Class Initialized
INFO - 2019-07-01 15:24:19 --> Security Class Initialized
DEBUG - 2019-07-01 15:24:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:24:19 --> Input Class Initialized
INFO - 2019-07-01 15:24:19 --> Language Class Initialized
INFO - 2019-07-01 15:24:19 --> Language Class Initialized
INFO - 2019-07-01 15:24:19 --> Config Class Initialized
INFO - 2019-07-01 15:24:19 --> Loader Class Initialized
DEBUG - 2019-07-01 15:24:19 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:24:19 --> Helper loaded: url_helper
INFO - 2019-07-01 15:24:19 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:24:19 --> Helper loaded: string_helper
INFO - 2019-07-01 15:24:19 --> Helper loaded: array_helper
INFO - 2019-07-01 15:24:19 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:24:19 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:24:19 --> Database Driver Class Initialized
INFO - 2019-07-01 15:24:19 --> Controller Class Initialized
INFO - 2019-07-01 21:24:19 --> Helper loaded: language_helper
INFO - 2019-07-01 21:24:19 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:24:19 --> Model Class Initialized
INFO - 2019-07-01 21:24:19 --> Model Class Initialized
INFO - 2019-07-01 21:24:19 --> Model Class Initialized
INFO - 2019-07-01 21:24:19 --> Model Class Initialized
INFO - 2019-07-01 21:24:19 --> Helper loaded: form_helper
INFO - 2019-07-01 21:24:19 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:24:19 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:24:19 --> Model Class Initialized
INFO - 2019-07-01 21:24:19 --> Model Class Initialized
INFO - 2019-07-01 21:24:19 --> Final output sent to browser
DEBUG - 2019-07-01 21:24:19 --> Total execution time: 0.6742
INFO - 2019-07-01 15:24:19 --> Config Class Initialized
INFO - 2019-07-01 15:24:19 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:24:20 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:24:20 --> Utf8 Class Initialized
INFO - 2019-07-01 15:24:20 --> URI Class Initialized
INFO - 2019-07-01 15:24:20 --> Router Class Initialized
INFO - 2019-07-01 15:24:20 --> Output Class Initialized
INFO - 2019-07-01 15:24:20 --> Security Class Initialized
DEBUG - 2019-07-01 15:24:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:24:20 --> Input Class Initialized
INFO - 2019-07-01 15:24:20 --> Language Class Initialized
INFO - 2019-07-01 15:24:20 --> Language Class Initialized
INFO - 2019-07-01 15:24:20 --> Config Class Initialized
INFO - 2019-07-01 15:24:20 --> Loader Class Initialized
DEBUG - 2019-07-01 15:24:20 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:24:20 --> Helper loaded: url_helper
INFO - 2019-07-01 15:24:20 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:24:20 --> Helper loaded: string_helper
INFO - 2019-07-01 15:24:20 --> Helper loaded: array_helper
INFO - 2019-07-01 15:24:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:24:20 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:24:20 --> Database Driver Class Initialized
INFO - 2019-07-01 15:24:20 --> Controller Class Initialized
INFO - 2019-07-01 21:24:20 --> Helper loaded: language_helper
INFO - 2019-07-01 21:24:20 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:24:20 --> Model Class Initialized
INFO - 2019-07-01 21:24:20 --> Model Class Initialized
INFO - 2019-07-01 21:24:20 --> Model Class Initialized
INFO - 2019-07-01 21:24:20 --> Model Class Initialized
INFO - 2019-07-01 21:24:20 --> Helper loaded: form_helper
INFO - 2019-07-01 21:24:20 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:24:20 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:24:20 --> Model Class Initialized
INFO - 2019-07-01 21:24:20 --> Model Class Initialized
INFO - 2019-07-01 21:24:20 --> Final output sent to browser
DEBUG - 2019-07-01 21:24:20 --> Total execution time: 0.7433
INFO - 2019-07-01 15:24:20 --> Config Class Initialized
INFO - 2019-07-01 15:24:20 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:24:20 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:24:20 --> Utf8 Class Initialized
INFO - 2019-07-01 15:24:20 --> URI Class Initialized
INFO - 2019-07-01 15:24:20 --> Router Class Initialized
INFO - 2019-07-01 15:24:20 --> Output Class Initialized
INFO - 2019-07-01 15:24:20 --> Security Class Initialized
DEBUG - 2019-07-01 15:24:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:24:21 --> Input Class Initialized
INFO - 2019-07-01 15:24:21 --> Language Class Initialized
INFO - 2019-07-01 15:24:21 --> Language Class Initialized
INFO - 2019-07-01 15:24:21 --> Config Class Initialized
INFO - 2019-07-01 15:24:21 --> Loader Class Initialized
DEBUG - 2019-07-01 15:24:21 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:24:21 --> Helper loaded: url_helper
INFO - 2019-07-01 15:24:21 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:24:21 --> Helper loaded: string_helper
INFO - 2019-07-01 15:24:21 --> Helper loaded: array_helper
INFO - 2019-07-01 15:24:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:24:21 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:24:21 --> Database Driver Class Initialized
INFO - 2019-07-01 15:24:21 --> Controller Class Initialized
INFO - 2019-07-01 21:24:21 --> Helper loaded: language_helper
INFO - 2019-07-01 21:24:21 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:24:21 --> Model Class Initialized
INFO - 2019-07-01 21:24:21 --> Model Class Initialized
INFO - 2019-07-01 21:24:21 --> Model Class Initialized
INFO - 2019-07-01 21:24:21 --> Model Class Initialized
INFO - 2019-07-01 21:24:21 --> Helper loaded: form_helper
INFO - 2019-07-01 21:24:21 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:24:21 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:24:21 --> Model Class Initialized
INFO - 2019-07-01 21:24:21 --> Model Class Initialized
INFO - 2019-07-01 21:24:21 --> Final output sent to browser
DEBUG - 2019-07-01 21:24:21 --> Total execution time: 0.8513
INFO - 2019-07-01 15:24:21 --> Config Class Initialized
INFO - 2019-07-01 15:24:21 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:24:21 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:24:21 --> Utf8 Class Initialized
INFO - 2019-07-01 15:24:21 --> URI Class Initialized
INFO - 2019-07-01 15:24:21 --> Router Class Initialized
INFO - 2019-07-01 15:24:21 --> Output Class Initialized
INFO - 2019-07-01 15:24:21 --> Security Class Initialized
DEBUG - 2019-07-01 15:24:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:24:21 --> Input Class Initialized
INFO - 2019-07-01 15:24:22 --> Language Class Initialized
INFO - 2019-07-01 15:24:22 --> Language Class Initialized
INFO - 2019-07-01 15:24:22 --> Config Class Initialized
INFO - 2019-07-01 15:24:22 --> Loader Class Initialized
DEBUG - 2019-07-01 15:24:22 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:24:22 --> Helper loaded: url_helper
INFO - 2019-07-01 15:24:22 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:24:22 --> Helper loaded: string_helper
INFO - 2019-07-01 15:24:22 --> Helper loaded: array_helper
INFO - 2019-07-01 15:24:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:24:22 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:24:22 --> Database Driver Class Initialized
INFO - 2019-07-01 15:24:22 --> Controller Class Initialized
INFO - 2019-07-01 21:24:22 --> Helper loaded: language_helper
INFO - 2019-07-01 21:24:22 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:24:22 --> Model Class Initialized
INFO - 2019-07-01 21:24:22 --> Model Class Initialized
INFO - 2019-07-01 21:24:22 --> Model Class Initialized
INFO - 2019-07-01 21:24:22 --> Model Class Initialized
INFO - 2019-07-01 21:24:22 --> Helper loaded: form_helper
INFO - 2019-07-01 21:24:22 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:24:22 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:24:22 --> Model Class Initialized
INFO - 2019-07-01 21:24:22 --> Model Class Initialized
INFO - 2019-07-01 21:24:22 --> Final output sent to browser
DEBUG - 2019-07-01 21:24:22 --> Total execution time: 0.8327
INFO - 2019-07-01 15:24:22 --> Config Class Initialized
INFO - 2019-07-01 15:24:22 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:24:22 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:24:22 --> Utf8 Class Initialized
INFO - 2019-07-01 15:24:22 --> URI Class Initialized
INFO - 2019-07-01 15:24:22 --> Router Class Initialized
INFO - 2019-07-01 15:24:22 --> Output Class Initialized
INFO - 2019-07-01 15:24:22 --> Security Class Initialized
DEBUG - 2019-07-01 15:24:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:24:22 --> Input Class Initialized
INFO - 2019-07-01 15:24:22 --> Language Class Initialized
INFO - 2019-07-01 15:24:22 --> Language Class Initialized
INFO - 2019-07-01 15:24:23 --> Config Class Initialized
INFO - 2019-07-01 15:24:23 --> Loader Class Initialized
DEBUG - 2019-07-01 15:24:23 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:24:23 --> Helper loaded: url_helper
INFO - 2019-07-01 15:24:23 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:24:23 --> Helper loaded: string_helper
INFO - 2019-07-01 15:24:23 --> Helper loaded: array_helper
INFO - 2019-07-01 15:24:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:24:23 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:24:23 --> Database Driver Class Initialized
INFO - 2019-07-01 15:24:23 --> Controller Class Initialized
INFO - 2019-07-01 21:24:23 --> Helper loaded: language_helper
INFO - 2019-07-01 21:24:23 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:24:23 --> Model Class Initialized
INFO - 2019-07-01 21:24:23 --> Model Class Initialized
INFO - 2019-07-01 21:24:23 --> Model Class Initialized
INFO - 2019-07-01 21:24:23 --> Model Class Initialized
INFO - 2019-07-01 21:24:23 --> Helper loaded: form_helper
INFO - 2019-07-01 21:24:23 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:24:23 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:24:23 --> Model Class Initialized
INFO - 2019-07-01 21:24:23 --> Model Class Initialized
INFO - 2019-07-01 21:24:23 --> Final output sent to browser
DEBUG - 2019-07-01 21:24:23 --> Total execution time: 0.8350
INFO - 2019-07-01 15:24:23 --> Config Class Initialized
INFO - 2019-07-01 15:24:23 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:24:23 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:24:23 --> Utf8 Class Initialized
INFO - 2019-07-01 15:24:23 --> URI Class Initialized
INFO - 2019-07-01 15:24:23 --> Router Class Initialized
INFO - 2019-07-01 15:24:23 --> Output Class Initialized
INFO - 2019-07-01 15:24:23 --> Security Class Initialized
DEBUG - 2019-07-01 15:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:24:23 --> Input Class Initialized
INFO - 2019-07-01 15:24:23 --> Language Class Initialized
INFO - 2019-07-01 15:24:23 --> Language Class Initialized
INFO - 2019-07-01 15:24:23 --> Config Class Initialized
INFO - 2019-07-01 15:24:23 --> Loader Class Initialized
DEBUG - 2019-07-01 15:24:23 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:24:24 --> Helper loaded: url_helper
INFO - 2019-07-01 15:24:24 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:24:24 --> Helper loaded: string_helper
INFO - 2019-07-01 15:24:24 --> Helper loaded: array_helper
INFO - 2019-07-01 15:24:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:24:24 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:24:24 --> Database Driver Class Initialized
INFO - 2019-07-01 15:24:24 --> Controller Class Initialized
INFO - 2019-07-01 21:24:24 --> Helper loaded: language_helper
INFO - 2019-07-01 21:24:24 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:24:24 --> Model Class Initialized
INFO - 2019-07-01 21:24:24 --> Model Class Initialized
INFO - 2019-07-01 21:24:24 --> Model Class Initialized
INFO - 2019-07-01 21:24:24 --> Model Class Initialized
INFO - 2019-07-01 21:24:24 --> Helper loaded: form_helper
INFO - 2019-07-01 21:24:24 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:24:24 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:24:24 --> Model Class Initialized
INFO - 2019-07-01 21:24:24 --> Model Class Initialized
INFO - 2019-07-01 21:24:24 --> Final output sent to browser
DEBUG - 2019-07-01 21:24:24 --> Total execution time: 1.0224
INFO - 2019-07-01 15:24:24 --> Config Class Initialized
INFO - 2019-07-01 15:24:24 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:24:24 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:24:24 --> Utf8 Class Initialized
INFO - 2019-07-01 15:24:24 --> URI Class Initialized
INFO - 2019-07-01 15:24:24 --> Router Class Initialized
INFO - 2019-07-01 15:24:24 --> Output Class Initialized
INFO - 2019-07-01 15:24:24 --> Security Class Initialized
DEBUG - 2019-07-01 15:24:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:24:25 --> Input Class Initialized
INFO - 2019-07-01 15:24:25 --> Language Class Initialized
INFO - 2019-07-01 15:24:25 --> Language Class Initialized
INFO - 2019-07-01 15:24:25 --> Config Class Initialized
INFO - 2019-07-01 15:24:25 --> Loader Class Initialized
DEBUG - 2019-07-01 15:24:25 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:24:25 --> Helper loaded: url_helper
INFO - 2019-07-01 15:24:25 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:24:25 --> Helper loaded: string_helper
INFO - 2019-07-01 15:24:25 --> Helper loaded: array_helper
INFO - 2019-07-01 15:24:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:24:25 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:24:25 --> Database Driver Class Initialized
INFO - 2019-07-01 15:24:25 --> Controller Class Initialized
INFO - 2019-07-01 21:24:25 --> Helper loaded: language_helper
INFO - 2019-07-01 21:24:25 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:24:25 --> Model Class Initialized
INFO - 2019-07-01 21:24:25 --> Model Class Initialized
INFO - 2019-07-01 21:24:25 --> Model Class Initialized
INFO - 2019-07-01 21:24:25 --> Model Class Initialized
INFO - 2019-07-01 21:24:25 --> Helper loaded: form_helper
INFO - 2019-07-01 21:24:25 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:24:25 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:24:25 --> Model Class Initialized
INFO - 2019-07-01 21:24:25 --> Model Class Initialized
INFO - 2019-07-01 21:24:25 --> Final output sent to browser
DEBUG - 2019-07-01 21:24:25 --> Total execution time: 0.9840
INFO - 2019-07-01 15:24:25 --> Config Class Initialized
INFO - 2019-07-01 15:24:25 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:24:25 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:24:25 --> Utf8 Class Initialized
INFO - 2019-07-01 15:24:25 --> URI Class Initialized
INFO - 2019-07-01 15:24:25 --> Router Class Initialized
INFO - 2019-07-01 15:24:25 --> Output Class Initialized
INFO - 2019-07-01 15:24:26 --> Security Class Initialized
DEBUG - 2019-07-01 15:24:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:24:26 --> Input Class Initialized
INFO - 2019-07-01 15:24:26 --> Language Class Initialized
INFO - 2019-07-01 15:24:26 --> Language Class Initialized
INFO - 2019-07-01 15:24:26 --> Config Class Initialized
INFO - 2019-07-01 15:24:26 --> Loader Class Initialized
DEBUG - 2019-07-01 15:24:26 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:24:26 --> Helper loaded: url_helper
INFO - 2019-07-01 15:24:26 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:24:26 --> Helper loaded: string_helper
INFO - 2019-07-01 15:24:26 --> Helper loaded: array_helper
INFO - 2019-07-01 15:24:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:24:26 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:24:26 --> Database Driver Class Initialized
INFO - 2019-07-01 15:24:26 --> Controller Class Initialized
INFO - 2019-07-01 21:24:26 --> Helper loaded: language_helper
INFO - 2019-07-01 21:24:26 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:24:26 --> Model Class Initialized
INFO - 2019-07-01 21:24:26 --> Model Class Initialized
INFO - 2019-07-01 21:24:26 --> Model Class Initialized
INFO - 2019-07-01 21:24:26 --> Model Class Initialized
INFO - 2019-07-01 21:24:26 --> Helper loaded: form_helper
INFO - 2019-07-01 21:24:26 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:24:26 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:24:26 --> Model Class Initialized
INFO - 2019-07-01 21:24:26 --> Model Class Initialized
INFO - 2019-07-01 21:24:26 --> Final output sent to browser
DEBUG - 2019-07-01 21:24:27 --> Total execution time: 1.1868
INFO - 2019-07-01 15:24:27 --> Config Class Initialized
INFO - 2019-07-01 15:24:27 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:24:27 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:24:27 --> Utf8 Class Initialized
INFO - 2019-07-01 15:24:27 --> URI Class Initialized
INFO - 2019-07-01 15:24:27 --> Router Class Initialized
INFO - 2019-07-01 15:24:27 --> Output Class Initialized
INFO - 2019-07-01 15:24:27 --> Security Class Initialized
DEBUG - 2019-07-01 15:24:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:24:27 --> Input Class Initialized
INFO - 2019-07-01 15:24:27 --> Language Class Initialized
INFO - 2019-07-01 15:24:27 --> Language Class Initialized
INFO - 2019-07-01 15:24:27 --> Config Class Initialized
INFO - 2019-07-01 15:24:27 --> Loader Class Initialized
DEBUG - 2019-07-01 15:24:27 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:24:27 --> Helper loaded: url_helper
INFO - 2019-07-01 15:24:27 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:24:27 --> Helper loaded: string_helper
INFO - 2019-07-01 15:24:27 --> Helper loaded: array_helper
INFO - 2019-07-01 15:24:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:24:27 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:24:27 --> Database Driver Class Initialized
INFO - 2019-07-01 15:24:27 --> Controller Class Initialized
INFO - 2019-07-01 21:24:27 --> Helper loaded: language_helper
INFO - 2019-07-01 21:24:27 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:24:27 --> Model Class Initialized
INFO - 2019-07-01 21:24:27 --> Model Class Initialized
INFO - 2019-07-01 21:24:28 --> Model Class Initialized
INFO - 2019-07-01 21:24:28 --> Model Class Initialized
INFO - 2019-07-01 21:24:28 --> Helper loaded: form_helper
INFO - 2019-07-01 21:24:28 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:24:28 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:24:28 --> Model Class Initialized
INFO - 2019-07-01 21:24:28 --> Model Class Initialized
INFO - 2019-07-01 21:24:28 --> Final output sent to browser
DEBUG - 2019-07-01 21:24:28 --> Total execution time: 1.1729
INFO - 2019-07-01 15:24:28 --> Config Class Initialized
INFO - 2019-07-01 15:24:28 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:24:28 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:24:28 --> Utf8 Class Initialized
INFO - 2019-07-01 15:24:28 --> URI Class Initialized
INFO - 2019-07-01 15:24:28 --> Router Class Initialized
INFO - 2019-07-01 15:24:28 --> Output Class Initialized
INFO - 2019-07-01 15:24:28 --> Security Class Initialized
DEBUG - 2019-07-01 15:24:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:24:28 --> Input Class Initialized
INFO - 2019-07-01 15:24:28 --> Language Class Initialized
INFO - 2019-07-01 15:24:28 --> Language Class Initialized
INFO - 2019-07-01 15:24:28 --> Config Class Initialized
INFO - 2019-07-01 15:24:28 --> Loader Class Initialized
DEBUG - 2019-07-01 15:24:28 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:24:28 --> Helper loaded: url_helper
INFO - 2019-07-01 15:24:28 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:24:28 --> Helper loaded: string_helper
INFO - 2019-07-01 15:24:28 --> Helper loaded: array_helper
INFO - 2019-07-01 15:24:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:24:28 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:24:28 --> Database Driver Class Initialized
INFO - 2019-07-01 15:24:29 --> Controller Class Initialized
INFO - 2019-07-01 21:24:29 --> Helper loaded: language_helper
INFO - 2019-07-01 21:24:29 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:24:29 --> Model Class Initialized
INFO - 2019-07-01 21:24:29 --> Model Class Initialized
INFO - 2019-07-01 21:24:29 --> Model Class Initialized
INFO - 2019-07-01 21:24:29 --> Model Class Initialized
INFO - 2019-07-01 21:24:29 --> Helper loaded: form_helper
INFO - 2019-07-01 21:24:29 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:24:29 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:24:29 --> Model Class Initialized
INFO - 2019-07-01 21:24:29 --> Model Class Initialized
INFO - 2019-07-01 21:24:29 --> Final output sent to browser
DEBUG - 2019-07-01 21:24:29 --> Total execution time: 0.8700
INFO - 2019-07-01 15:24:29 --> Config Class Initialized
INFO - 2019-07-01 15:24:29 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:24:29 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:24:29 --> Utf8 Class Initialized
INFO - 2019-07-01 15:24:29 --> URI Class Initialized
INFO - 2019-07-01 15:24:29 --> Router Class Initialized
INFO - 2019-07-01 15:24:29 --> Output Class Initialized
INFO - 2019-07-01 15:24:29 --> Security Class Initialized
DEBUG - 2019-07-01 15:24:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:24:29 --> Input Class Initialized
INFO - 2019-07-01 15:24:29 --> Language Class Initialized
INFO - 2019-07-01 15:24:29 --> Language Class Initialized
INFO - 2019-07-01 15:24:29 --> Config Class Initialized
INFO - 2019-07-01 15:24:29 --> Loader Class Initialized
DEBUG - 2019-07-01 15:24:29 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:24:29 --> Helper loaded: url_helper
INFO - 2019-07-01 15:24:29 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:24:29 --> Helper loaded: string_helper
INFO - 2019-07-01 15:24:29 --> Helper loaded: array_helper
INFO - 2019-07-01 15:24:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:24:29 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:24:29 --> Database Driver Class Initialized
INFO - 2019-07-01 15:24:29 --> Controller Class Initialized
INFO - 2019-07-01 21:24:29 --> Helper loaded: language_helper
INFO - 2019-07-01 21:24:29 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:24:29 --> Model Class Initialized
INFO - 2019-07-01 21:24:29 --> Model Class Initialized
INFO - 2019-07-01 21:24:30 --> Model Class Initialized
INFO - 2019-07-01 21:24:30 --> Model Class Initialized
INFO - 2019-07-01 21:24:30 --> Helper loaded: form_helper
INFO - 2019-07-01 21:24:30 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:24:30 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:24:30 --> Model Class Initialized
INFO - 2019-07-01 21:24:30 --> Model Class Initialized
INFO - 2019-07-01 21:24:30 --> Final output sent to browser
DEBUG - 2019-07-01 21:24:30 --> Total execution time: 0.8065
INFO - 2019-07-01 15:24:30 --> Config Class Initialized
INFO - 2019-07-01 15:24:30 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:24:30 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:24:30 --> Utf8 Class Initialized
INFO - 2019-07-01 15:24:30 --> URI Class Initialized
INFO - 2019-07-01 15:24:30 --> Router Class Initialized
INFO - 2019-07-01 15:24:30 --> Output Class Initialized
INFO - 2019-07-01 15:24:30 --> Security Class Initialized
DEBUG - 2019-07-01 15:24:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:24:30 --> Input Class Initialized
INFO - 2019-07-01 15:24:30 --> Language Class Initialized
INFO - 2019-07-01 15:24:30 --> Language Class Initialized
INFO - 2019-07-01 15:24:30 --> Config Class Initialized
INFO - 2019-07-01 15:24:30 --> Loader Class Initialized
DEBUG - 2019-07-01 15:24:30 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:24:30 --> Helper loaded: url_helper
INFO - 2019-07-01 15:24:30 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:24:30 --> Helper loaded: string_helper
INFO - 2019-07-01 15:24:30 --> Helper loaded: array_helper
INFO - 2019-07-01 15:24:30 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:24:30 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:24:30 --> Database Driver Class Initialized
INFO - 2019-07-01 15:24:30 --> Controller Class Initialized
INFO - 2019-07-01 21:24:30 --> Helper loaded: language_helper
INFO - 2019-07-01 21:24:30 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:24:30 --> Model Class Initialized
INFO - 2019-07-01 21:24:31 --> Model Class Initialized
INFO - 2019-07-01 21:24:31 --> Model Class Initialized
INFO - 2019-07-01 21:24:31 --> Model Class Initialized
INFO - 2019-07-01 21:24:31 --> Helper loaded: form_helper
INFO - 2019-07-01 21:24:31 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:24:31 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:24:31 --> Model Class Initialized
INFO - 2019-07-01 21:24:31 --> Model Class Initialized
INFO - 2019-07-01 21:24:31 --> Final output sent to browser
DEBUG - 2019-07-01 21:24:31 --> Total execution time: 0.9680
INFO - 2019-07-01 15:24:31 --> Config Class Initialized
INFO - 2019-07-01 15:24:31 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:24:31 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:24:31 --> Utf8 Class Initialized
INFO - 2019-07-01 15:24:31 --> URI Class Initialized
INFO - 2019-07-01 15:24:31 --> Router Class Initialized
INFO - 2019-07-01 15:24:31 --> Output Class Initialized
INFO - 2019-07-01 15:24:31 --> Security Class Initialized
DEBUG - 2019-07-01 15:24:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:24:31 --> Input Class Initialized
INFO - 2019-07-01 15:24:31 --> Language Class Initialized
INFO - 2019-07-01 15:24:31 --> Language Class Initialized
INFO - 2019-07-01 15:24:31 --> Config Class Initialized
INFO - 2019-07-01 15:24:31 --> Loader Class Initialized
DEBUG - 2019-07-01 15:24:31 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:24:31 --> Helper loaded: url_helper
INFO - 2019-07-01 15:24:31 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:24:31 --> Helper loaded: string_helper
INFO - 2019-07-01 15:24:31 --> Helper loaded: array_helper
INFO - 2019-07-01 15:24:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:24:31 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:24:31 --> Database Driver Class Initialized
INFO - 2019-07-01 15:24:31 --> Controller Class Initialized
INFO - 2019-07-01 21:24:31 --> Helper loaded: language_helper
INFO - 2019-07-01 21:24:31 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:24:31 --> Model Class Initialized
INFO - 2019-07-01 21:24:32 --> Model Class Initialized
INFO - 2019-07-01 21:24:32 --> Model Class Initialized
INFO - 2019-07-01 21:24:32 --> Model Class Initialized
INFO - 2019-07-01 21:24:32 --> Helper loaded: form_helper
INFO - 2019-07-01 21:24:32 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:24:32 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:24:32 --> Model Class Initialized
INFO - 2019-07-01 21:24:32 --> Model Class Initialized
INFO - 2019-07-01 21:24:32 --> Final output sent to browser
DEBUG - 2019-07-01 21:24:32 --> Total execution time: 0.8590
INFO - 2019-07-01 15:24:32 --> Config Class Initialized
INFO - 2019-07-01 15:24:32 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:24:32 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:24:32 --> Utf8 Class Initialized
INFO - 2019-07-01 15:24:32 --> URI Class Initialized
INFO - 2019-07-01 15:24:32 --> Router Class Initialized
INFO - 2019-07-01 15:24:32 --> Output Class Initialized
INFO - 2019-07-01 15:24:32 --> Security Class Initialized
DEBUG - 2019-07-01 15:24:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:24:32 --> Input Class Initialized
INFO - 2019-07-01 15:24:32 --> Language Class Initialized
INFO - 2019-07-01 15:24:32 --> Language Class Initialized
INFO - 2019-07-01 15:24:32 --> Config Class Initialized
INFO - 2019-07-01 15:24:32 --> Loader Class Initialized
DEBUG - 2019-07-01 15:24:32 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:24:32 --> Helper loaded: url_helper
INFO - 2019-07-01 15:24:32 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:24:32 --> Helper loaded: string_helper
INFO - 2019-07-01 15:24:32 --> Helper loaded: array_helper
INFO - 2019-07-01 15:24:32 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:24:32 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:24:32 --> Database Driver Class Initialized
INFO - 2019-07-01 15:24:33 --> Controller Class Initialized
INFO - 2019-07-01 21:24:33 --> Helper loaded: language_helper
INFO - 2019-07-01 21:24:33 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:24:33 --> Model Class Initialized
INFO - 2019-07-01 21:24:33 --> Model Class Initialized
INFO - 2019-07-01 21:24:33 --> Model Class Initialized
INFO - 2019-07-01 21:24:33 --> Model Class Initialized
INFO - 2019-07-01 21:24:33 --> Helper loaded: form_helper
INFO - 2019-07-01 21:24:33 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:24:33 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:24:33 --> Model Class Initialized
INFO - 2019-07-01 21:24:33 --> Model Class Initialized
INFO - 2019-07-01 21:24:33 --> Final output sent to browser
DEBUG - 2019-07-01 21:24:33 --> Total execution time: 1.2055
INFO - 2019-07-01 15:24:33 --> Config Class Initialized
INFO - 2019-07-01 15:24:33 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:24:33 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:24:33 --> Utf8 Class Initialized
INFO - 2019-07-01 15:24:33 --> URI Class Initialized
INFO - 2019-07-01 15:24:33 --> Router Class Initialized
INFO - 2019-07-01 15:24:33 --> Output Class Initialized
INFO - 2019-07-01 15:24:33 --> Security Class Initialized
DEBUG - 2019-07-01 15:24:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:24:33 --> Input Class Initialized
INFO - 2019-07-01 15:24:33 --> Language Class Initialized
INFO - 2019-07-01 15:24:34 --> Language Class Initialized
INFO - 2019-07-01 15:24:34 --> Config Class Initialized
INFO - 2019-07-01 15:24:34 --> Loader Class Initialized
DEBUG - 2019-07-01 15:24:34 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:24:34 --> Helper loaded: url_helper
INFO - 2019-07-01 15:24:34 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:24:34 --> Helper loaded: string_helper
INFO - 2019-07-01 15:24:34 --> Helper loaded: array_helper
INFO - 2019-07-01 15:24:34 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:24:34 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:24:34 --> Database Driver Class Initialized
INFO - 2019-07-01 15:24:34 --> Controller Class Initialized
INFO - 2019-07-01 21:24:34 --> Helper loaded: language_helper
INFO - 2019-07-01 21:24:34 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:24:34 --> Model Class Initialized
INFO - 2019-07-01 21:24:34 --> Model Class Initialized
INFO - 2019-07-01 21:24:34 --> Model Class Initialized
INFO - 2019-07-01 21:24:34 --> Model Class Initialized
INFO - 2019-07-01 21:24:34 --> Helper loaded: form_helper
INFO - 2019-07-01 21:24:34 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:24:34 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:24:34 --> Model Class Initialized
INFO - 2019-07-01 21:24:34 --> Model Class Initialized
INFO - 2019-07-01 21:24:34 --> Final output sent to browser
DEBUG - 2019-07-01 21:24:34 --> Total execution time: 0.9036
INFO - 2019-07-01 15:24:34 --> Config Class Initialized
INFO - 2019-07-01 15:24:34 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:24:34 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:24:34 --> Utf8 Class Initialized
INFO - 2019-07-01 15:24:34 --> URI Class Initialized
INFO - 2019-07-01 15:24:34 --> Router Class Initialized
INFO - 2019-07-01 15:24:34 --> Output Class Initialized
INFO - 2019-07-01 15:24:34 --> Security Class Initialized
DEBUG - 2019-07-01 15:24:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:24:34 --> Input Class Initialized
INFO - 2019-07-01 15:24:34 --> Language Class Initialized
INFO - 2019-07-01 15:24:34 --> Language Class Initialized
INFO - 2019-07-01 15:24:34 --> Config Class Initialized
INFO - 2019-07-01 15:24:34 --> Loader Class Initialized
DEBUG - 2019-07-01 15:24:34 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:24:34 --> Helper loaded: url_helper
INFO - 2019-07-01 15:24:35 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:24:35 --> Helper loaded: string_helper
INFO - 2019-07-01 15:24:35 --> Helper loaded: array_helper
INFO - 2019-07-01 15:24:35 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:24:35 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:24:35 --> Database Driver Class Initialized
INFO - 2019-07-01 15:24:35 --> Controller Class Initialized
INFO - 2019-07-01 21:24:35 --> Helper loaded: language_helper
INFO - 2019-07-01 21:24:35 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:24:35 --> Model Class Initialized
INFO - 2019-07-01 21:24:35 --> Model Class Initialized
INFO - 2019-07-01 21:24:35 --> Model Class Initialized
INFO - 2019-07-01 21:24:35 --> Model Class Initialized
INFO - 2019-07-01 21:24:35 --> Helper loaded: form_helper
INFO - 2019-07-01 21:24:35 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:24:35 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:24:35 --> Model Class Initialized
INFO - 2019-07-01 21:24:35 --> Model Class Initialized
INFO - 2019-07-01 21:24:35 --> Final output sent to browser
DEBUG - 2019-07-01 21:24:35 --> Total execution time: 0.7926
INFO - 2019-07-01 15:24:35 --> Config Class Initialized
INFO - 2019-07-01 15:24:35 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:24:35 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:24:35 --> Utf8 Class Initialized
INFO - 2019-07-01 15:24:35 --> URI Class Initialized
INFO - 2019-07-01 15:24:35 --> Router Class Initialized
INFO - 2019-07-01 15:24:35 --> Output Class Initialized
INFO - 2019-07-01 15:24:35 --> Security Class Initialized
DEBUG - 2019-07-01 15:24:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:24:35 --> Input Class Initialized
INFO - 2019-07-01 15:24:35 --> Language Class Initialized
INFO - 2019-07-01 15:24:35 --> Language Class Initialized
INFO - 2019-07-01 15:24:35 --> Config Class Initialized
INFO - 2019-07-01 15:24:35 --> Loader Class Initialized
DEBUG - 2019-07-01 15:24:35 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:24:36 --> Helper loaded: url_helper
INFO - 2019-07-01 15:24:36 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:24:36 --> Helper loaded: string_helper
INFO - 2019-07-01 15:24:36 --> Helper loaded: array_helper
INFO - 2019-07-01 15:24:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:24:36 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:24:36 --> Database Driver Class Initialized
INFO - 2019-07-01 15:24:36 --> Controller Class Initialized
INFO - 2019-07-01 21:24:36 --> Helper loaded: language_helper
INFO - 2019-07-01 21:24:36 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:24:36 --> Model Class Initialized
INFO - 2019-07-01 21:24:36 --> Model Class Initialized
INFO - 2019-07-01 21:24:36 --> Model Class Initialized
INFO - 2019-07-01 21:24:36 --> Model Class Initialized
INFO - 2019-07-01 21:24:36 --> Helper loaded: form_helper
INFO - 2019-07-01 21:24:36 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:24:36 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:24:36 --> Model Class Initialized
INFO - 2019-07-01 21:24:36 --> Model Class Initialized
INFO - 2019-07-01 21:24:36 --> Final output sent to browser
DEBUG - 2019-07-01 21:24:36 --> Total execution time: 0.8912
INFO - 2019-07-01 15:24:36 --> Config Class Initialized
INFO - 2019-07-01 15:24:36 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:24:36 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:24:36 --> Utf8 Class Initialized
INFO - 2019-07-01 15:24:36 --> URI Class Initialized
INFO - 2019-07-01 15:24:36 --> Router Class Initialized
INFO - 2019-07-01 15:24:36 --> Output Class Initialized
INFO - 2019-07-01 15:24:36 --> Security Class Initialized
DEBUG - 2019-07-01 15:24:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:24:36 --> Input Class Initialized
INFO - 2019-07-01 15:24:36 --> Language Class Initialized
INFO - 2019-07-01 15:24:36 --> Language Class Initialized
INFO - 2019-07-01 15:24:36 --> Config Class Initialized
INFO - 2019-07-01 15:24:36 --> Loader Class Initialized
DEBUG - 2019-07-01 15:24:36 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:24:36 --> Helper loaded: url_helper
INFO - 2019-07-01 15:24:36 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:24:36 --> Helper loaded: string_helper
INFO - 2019-07-01 15:24:36 --> Helper loaded: array_helper
INFO - 2019-07-01 15:24:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:24:37 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:24:37 --> Database Driver Class Initialized
INFO - 2019-07-01 15:24:37 --> Controller Class Initialized
INFO - 2019-07-01 21:24:37 --> Helper loaded: language_helper
INFO - 2019-07-01 21:24:37 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:24:37 --> Model Class Initialized
INFO - 2019-07-01 21:24:37 --> Model Class Initialized
INFO - 2019-07-01 21:24:37 --> Model Class Initialized
INFO - 2019-07-01 21:24:37 --> Model Class Initialized
INFO - 2019-07-01 21:24:37 --> Helper loaded: form_helper
INFO - 2019-07-01 21:24:37 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:24:37 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:24:37 --> Model Class Initialized
INFO - 2019-07-01 21:24:37 --> Model Class Initialized
INFO - 2019-07-01 21:24:37 --> Final output sent to browser
DEBUG - 2019-07-01 21:24:37 --> Total execution time: 0.7912
INFO - 2019-07-01 15:24:37 --> Config Class Initialized
INFO - 2019-07-01 15:24:37 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:24:37 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:24:37 --> Utf8 Class Initialized
INFO - 2019-07-01 15:24:37 --> URI Class Initialized
INFO - 2019-07-01 15:24:37 --> Router Class Initialized
INFO - 2019-07-01 15:24:37 --> Output Class Initialized
INFO - 2019-07-01 15:24:37 --> Security Class Initialized
DEBUG - 2019-07-01 15:24:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:24:37 --> Input Class Initialized
INFO - 2019-07-01 15:24:37 --> Language Class Initialized
INFO - 2019-07-01 15:24:37 --> Language Class Initialized
INFO - 2019-07-01 15:24:37 --> Config Class Initialized
INFO - 2019-07-01 15:24:37 --> Loader Class Initialized
DEBUG - 2019-07-01 15:24:37 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:24:37 --> Helper loaded: url_helper
INFO - 2019-07-01 15:24:37 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:24:37 --> Helper loaded: string_helper
INFO - 2019-07-01 15:24:37 --> Helper loaded: array_helper
INFO - 2019-07-01 15:24:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:24:37 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:24:37 --> Database Driver Class Initialized
INFO - 2019-07-01 15:24:37 --> Controller Class Initialized
INFO - 2019-07-01 21:24:37 --> Helper loaded: language_helper
INFO - 2019-07-01 21:24:38 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:24:38 --> Model Class Initialized
INFO - 2019-07-01 21:24:38 --> Model Class Initialized
INFO - 2019-07-01 21:24:38 --> Model Class Initialized
INFO - 2019-07-01 21:24:38 --> Model Class Initialized
INFO - 2019-07-01 21:24:38 --> Helper loaded: form_helper
INFO - 2019-07-01 21:24:38 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:24:38 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:24:38 --> Model Class Initialized
INFO - 2019-07-01 21:24:38 --> Model Class Initialized
INFO - 2019-07-01 21:24:38 --> Final output sent to browser
DEBUG - 2019-07-01 21:24:38 --> Total execution time: 0.8366
INFO - 2019-07-01 15:24:38 --> Config Class Initialized
INFO - 2019-07-01 15:24:38 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:24:38 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:24:38 --> Utf8 Class Initialized
INFO - 2019-07-01 15:24:38 --> URI Class Initialized
INFO - 2019-07-01 15:24:38 --> Router Class Initialized
INFO - 2019-07-01 15:24:38 --> Output Class Initialized
INFO - 2019-07-01 15:24:38 --> Security Class Initialized
DEBUG - 2019-07-01 15:24:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:24:38 --> Input Class Initialized
INFO - 2019-07-01 15:24:38 --> Language Class Initialized
INFO - 2019-07-01 15:24:38 --> Language Class Initialized
INFO - 2019-07-01 15:24:38 --> Config Class Initialized
INFO - 2019-07-01 15:24:38 --> Loader Class Initialized
DEBUG - 2019-07-01 15:24:38 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:24:38 --> Helper loaded: url_helper
INFO - 2019-07-01 15:24:38 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:24:38 --> Helper loaded: string_helper
INFO - 2019-07-01 15:24:38 --> Helper loaded: array_helper
INFO - 2019-07-01 15:24:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:24:38 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:24:38 --> Database Driver Class Initialized
INFO - 2019-07-01 15:24:38 --> Controller Class Initialized
INFO - 2019-07-01 21:24:38 --> Helper loaded: language_helper
INFO - 2019-07-01 21:24:38 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:24:38 --> Model Class Initialized
INFO - 2019-07-01 21:24:39 --> Model Class Initialized
INFO - 2019-07-01 21:24:39 --> Model Class Initialized
INFO - 2019-07-01 21:24:39 --> Model Class Initialized
INFO - 2019-07-01 21:24:39 --> Helper loaded: form_helper
INFO - 2019-07-01 21:24:39 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:24:39 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:24:39 --> Model Class Initialized
INFO - 2019-07-01 21:24:39 --> Model Class Initialized
INFO - 2019-07-01 21:24:39 --> Final output sent to browser
DEBUG - 2019-07-01 21:24:39 --> Total execution time: 0.8367
INFO - 2019-07-01 15:24:39 --> Config Class Initialized
INFO - 2019-07-01 15:24:39 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:24:39 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:24:39 --> Utf8 Class Initialized
INFO - 2019-07-01 15:24:39 --> URI Class Initialized
INFO - 2019-07-01 15:24:39 --> Router Class Initialized
INFO - 2019-07-01 15:24:39 --> Output Class Initialized
INFO - 2019-07-01 15:24:39 --> Security Class Initialized
DEBUG - 2019-07-01 15:24:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:24:39 --> Input Class Initialized
INFO - 2019-07-01 15:24:39 --> Language Class Initialized
INFO - 2019-07-01 15:24:39 --> Language Class Initialized
INFO - 2019-07-01 15:24:39 --> Config Class Initialized
INFO - 2019-07-01 15:24:39 --> Loader Class Initialized
DEBUG - 2019-07-01 15:24:39 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:24:39 --> Helper loaded: url_helper
INFO - 2019-07-01 15:24:39 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:24:39 --> Helper loaded: string_helper
INFO - 2019-07-01 15:24:39 --> Helper loaded: array_helper
INFO - 2019-07-01 15:24:39 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:24:39 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:24:39 --> Database Driver Class Initialized
INFO - 2019-07-01 15:24:39 --> Controller Class Initialized
INFO - 2019-07-01 21:24:39 --> Helper loaded: language_helper
INFO - 2019-07-01 21:24:39 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:24:39 --> Model Class Initialized
INFO - 2019-07-01 21:24:39 --> Model Class Initialized
INFO - 2019-07-01 21:24:39 --> Model Class Initialized
INFO - 2019-07-01 21:24:40 --> Model Class Initialized
INFO - 2019-07-01 21:24:40 --> Helper loaded: form_helper
INFO - 2019-07-01 21:24:40 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:24:40 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:24:40 --> Model Class Initialized
INFO - 2019-07-01 21:24:40 --> Model Class Initialized
INFO - 2019-07-01 21:24:40 --> Final output sent to browser
DEBUG - 2019-07-01 21:24:40 --> Total execution time: 0.9320
INFO - 2019-07-01 15:24:40 --> Config Class Initialized
INFO - 2019-07-01 15:24:40 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:24:40 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:24:40 --> Utf8 Class Initialized
INFO - 2019-07-01 15:24:40 --> URI Class Initialized
INFO - 2019-07-01 15:24:40 --> Router Class Initialized
INFO - 2019-07-01 15:24:40 --> Output Class Initialized
INFO - 2019-07-01 15:24:40 --> Security Class Initialized
DEBUG - 2019-07-01 15:24:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:24:40 --> Input Class Initialized
INFO - 2019-07-01 15:24:40 --> Language Class Initialized
INFO - 2019-07-01 15:24:40 --> Language Class Initialized
INFO - 2019-07-01 15:24:40 --> Config Class Initialized
INFO - 2019-07-01 15:24:40 --> Loader Class Initialized
DEBUG - 2019-07-01 15:24:40 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:24:40 --> Helper loaded: url_helper
INFO - 2019-07-01 15:24:40 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:24:40 --> Helper loaded: string_helper
INFO - 2019-07-01 15:24:40 --> Helper loaded: array_helper
INFO - 2019-07-01 15:24:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:24:40 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:24:40 --> Database Driver Class Initialized
INFO - 2019-07-01 15:24:40 --> Controller Class Initialized
INFO - 2019-07-01 21:24:40 --> Helper loaded: language_helper
INFO - 2019-07-01 21:24:40 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:24:41 --> Model Class Initialized
INFO - 2019-07-01 21:24:41 --> Model Class Initialized
INFO - 2019-07-01 21:24:41 --> Model Class Initialized
INFO - 2019-07-01 21:24:41 --> Model Class Initialized
INFO - 2019-07-01 21:24:41 --> Helper loaded: form_helper
INFO - 2019-07-01 21:24:41 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:24:41 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:24:41 --> Model Class Initialized
INFO - 2019-07-01 21:24:41 --> Model Class Initialized
INFO - 2019-07-01 21:24:41 --> Final output sent to browser
DEBUG - 2019-07-01 21:24:41 --> Total execution time: 0.8949
INFO - 2019-07-01 15:24:41 --> Config Class Initialized
INFO - 2019-07-01 15:24:41 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:24:41 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:24:41 --> Utf8 Class Initialized
INFO - 2019-07-01 15:24:41 --> URI Class Initialized
INFO - 2019-07-01 15:24:41 --> Router Class Initialized
INFO - 2019-07-01 15:24:41 --> Output Class Initialized
INFO - 2019-07-01 15:24:41 --> Security Class Initialized
DEBUG - 2019-07-01 15:24:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:24:41 --> Input Class Initialized
INFO - 2019-07-01 15:24:41 --> Language Class Initialized
INFO - 2019-07-01 15:24:41 --> Language Class Initialized
INFO - 2019-07-01 15:24:41 --> Config Class Initialized
INFO - 2019-07-01 15:24:41 --> Loader Class Initialized
DEBUG - 2019-07-01 15:24:41 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:24:41 --> Helper loaded: url_helper
INFO - 2019-07-01 15:24:41 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:24:41 --> Helper loaded: string_helper
INFO - 2019-07-01 15:24:41 --> Helper loaded: array_helper
INFO - 2019-07-01 15:24:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:24:41 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:24:41 --> Database Driver Class Initialized
INFO - 2019-07-01 15:24:41 --> Controller Class Initialized
INFO - 2019-07-01 21:24:41 --> Helper loaded: language_helper
INFO - 2019-07-01 21:24:41 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:24:41 --> Model Class Initialized
INFO - 2019-07-01 21:24:42 --> Model Class Initialized
INFO - 2019-07-01 21:24:42 --> Model Class Initialized
INFO - 2019-07-01 21:24:42 --> Model Class Initialized
INFO - 2019-07-01 21:24:42 --> Helper loaded: form_helper
INFO - 2019-07-01 21:24:42 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:24:42 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:24:42 --> Model Class Initialized
INFO - 2019-07-01 21:24:42 --> Model Class Initialized
INFO - 2019-07-01 21:24:42 --> Final output sent to browser
DEBUG - 2019-07-01 21:24:42 --> Total execution time: 0.8863
INFO - 2019-07-01 15:25:24 --> Config Class Initialized
INFO - 2019-07-01 15:25:24 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:25:25 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:25:25 --> Utf8 Class Initialized
INFO - 2019-07-01 15:25:25 --> URI Class Initialized
INFO - 2019-07-01 15:25:25 --> Router Class Initialized
INFO - 2019-07-01 15:25:25 --> Output Class Initialized
INFO - 2019-07-01 15:25:25 --> Security Class Initialized
DEBUG - 2019-07-01 15:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:25:25 --> Input Class Initialized
INFO - 2019-07-01 15:25:25 --> Language Class Initialized
INFO - 2019-07-01 15:25:25 --> Language Class Initialized
INFO - 2019-07-01 15:25:25 --> Config Class Initialized
INFO - 2019-07-01 15:25:25 --> Loader Class Initialized
DEBUG - 2019-07-01 15:25:25 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:25:25 --> Helper loaded: url_helper
INFO - 2019-07-01 15:25:25 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:25:25 --> Helper loaded: string_helper
INFO - 2019-07-01 15:25:25 --> Helper loaded: array_helper
INFO - 2019-07-01 15:25:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:25:25 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:25:26 --> Database Driver Class Initialized
INFO - 2019-07-01 15:25:26 --> Controller Class Initialized
INFO - 2019-07-01 21:25:26 --> Helper loaded: language_helper
INFO - 2019-07-01 21:25:26 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:25:26 --> Model Class Initialized
INFO - 2019-07-01 21:25:26 --> Model Class Initialized
INFO - 2019-07-01 21:25:26 --> Model Class Initialized
INFO - 2019-07-01 21:25:26 --> Model Class Initialized
INFO - 2019-07-01 21:25:26 --> Helper loaded: form_helper
INFO - 2019-07-01 21:25:26 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:25:26 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:25:26 --> Model Class Initialized
INFO - 2019-07-01 21:25:26 --> Model Class Initialized
INFO - 2019-07-01 21:25:26 --> Final output sent to browser
DEBUG - 2019-07-01 21:25:26 --> Total execution time: 1.7678
INFO - 2019-07-01 15:25:35 --> Config Class Initialized
INFO - 2019-07-01 15:25:35 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:25:35 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:25:35 --> Utf8 Class Initialized
INFO - 2019-07-01 15:25:35 --> URI Class Initialized
INFO - 2019-07-01 15:25:35 --> Router Class Initialized
INFO - 2019-07-01 15:25:35 --> Output Class Initialized
INFO - 2019-07-01 15:25:35 --> Security Class Initialized
DEBUG - 2019-07-01 15:25:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:25:35 --> Input Class Initialized
INFO - 2019-07-01 15:25:35 --> Language Class Initialized
INFO - 2019-07-01 15:25:35 --> Language Class Initialized
INFO - 2019-07-01 15:25:35 --> Config Class Initialized
INFO - 2019-07-01 15:25:35 --> Loader Class Initialized
DEBUG - 2019-07-01 15:25:35 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:25:35 --> Helper loaded: url_helper
INFO - 2019-07-01 15:25:36 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:25:36 --> Helper loaded: string_helper
INFO - 2019-07-01 15:25:36 --> Helper loaded: array_helper
INFO - 2019-07-01 15:25:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:25:36 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:25:36 --> Database Driver Class Initialized
INFO - 2019-07-01 15:25:36 --> Controller Class Initialized
INFO - 2019-07-01 21:25:36 --> Helper loaded: language_helper
INFO - 2019-07-01 21:25:36 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:25:36 --> Model Class Initialized
INFO - 2019-07-01 21:25:36 --> Model Class Initialized
INFO - 2019-07-01 21:25:36 --> Model Class Initialized
INFO - 2019-07-01 21:25:36 --> Model Class Initialized
INFO - 2019-07-01 21:25:36 --> Helper loaded: form_helper
INFO - 2019-07-01 21:25:36 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:25:36 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:25:36 --> Model Class Initialized
INFO - 2019-07-01 21:25:36 --> Model Class Initialized
INFO - 2019-07-01 21:25:36 --> Final output sent to browser
DEBUG - 2019-07-01 21:25:36 --> Total execution time: 0.6124
INFO - 2019-07-01 15:26:59 --> Config Class Initialized
INFO - 2019-07-01 15:26:59 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:26:59 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:26:59 --> Utf8 Class Initialized
INFO - 2019-07-01 15:26:59 --> URI Class Initialized
INFO - 2019-07-01 15:26:59 --> Router Class Initialized
INFO - 2019-07-01 15:27:00 --> Output Class Initialized
INFO - 2019-07-01 15:27:00 --> Security Class Initialized
DEBUG - 2019-07-01 15:27:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:27:00 --> Input Class Initialized
INFO - 2019-07-01 15:27:00 --> Language Class Initialized
INFO - 2019-07-01 15:27:00 --> Language Class Initialized
INFO - 2019-07-01 15:27:00 --> Config Class Initialized
INFO - 2019-07-01 15:27:00 --> Loader Class Initialized
DEBUG - 2019-07-01 15:27:00 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:27:00 --> Helper loaded: url_helper
INFO - 2019-07-01 15:27:00 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:27:00 --> Helper loaded: string_helper
INFO - 2019-07-01 15:27:00 --> Helper loaded: array_helper
INFO - 2019-07-01 15:27:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:27:00 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:27:00 --> Database Driver Class Initialized
INFO - 2019-07-01 15:27:00 --> Controller Class Initialized
INFO - 2019-07-01 21:27:00 --> Helper loaded: language_helper
INFO - 2019-07-01 21:27:00 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:27:00 --> Model Class Initialized
INFO - 2019-07-01 21:27:00 --> Model Class Initialized
INFO - 2019-07-01 21:27:00 --> Model Class Initialized
INFO - 2019-07-01 21:27:00 --> Model Class Initialized
INFO - 2019-07-01 21:27:00 --> Helper loaded: form_helper
INFO - 2019-07-01 21:27:00 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:27:00 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:27:00 --> Model Class Initialized
INFO - 2019-07-01 21:27:00 --> Model Class Initialized
INFO - 2019-07-01 21:27:00 --> Final output sent to browser
DEBUG - 2019-07-01 21:27:00 --> Total execution time: 0.6750
INFO - 2019-07-01 15:27:50 --> Config Class Initialized
INFO - 2019-07-01 15:27:51 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:27:51 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:27:51 --> Utf8 Class Initialized
INFO - 2019-07-01 15:27:51 --> URI Class Initialized
INFO - 2019-07-01 15:27:51 --> Router Class Initialized
INFO - 2019-07-01 15:27:51 --> Output Class Initialized
INFO - 2019-07-01 15:27:51 --> Security Class Initialized
DEBUG - 2019-07-01 15:27:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:27:51 --> Input Class Initialized
INFO - 2019-07-01 15:27:51 --> Language Class Initialized
INFO - 2019-07-01 15:27:51 --> Language Class Initialized
INFO - 2019-07-01 15:27:51 --> Config Class Initialized
INFO - 2019-07-01 15:27:51 --> Loader Class Initialized
DEBUG - 2019-07-01 15:27:51 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:27:51 --> Helper loaded: url_helper
INFO - 2019-07-01 15:27:51 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:27:51 --> Helper loaded: string_helper
INFO - 2019-07-01 15:27:51 --> Helper loaded: array_helper
INFO - 2019-07-01 15:27:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:27:51 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:27:51 --> Database Driver Class Initialized
INFO - 2019-07-01 15:27:51 --> Controller Class Initialized
INFO - 2019-07-01 21:27:51 --> Helper loaded: language_helper
INFO - 2019-07-01 21:27:51 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:27:51 --> Model Class Initialized
INFO - 2019-07-01 21:27:51 --> Model Class Initialized
INFO - 2019-07-01 21:27:51 --> Model Class Initialized
INFO - 2019-07-01 21:27:51 --> Model Class Initialized
INFO - 2019-07-01 21:27:51 --> Helper loaded: form_helper
INFO - 2019-07-01 21:27:51 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:27:51 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:27:51 --> Model Class Initialized
INFO - 2019-07-01 21:27:52 --> Model Class Initialized
INFO - 2019-07-01 21:27:52 --> Final output sent to browser
DEBUG - 2019-07-01 21:27:52 --> Total execution time: 1.0877
INFO - 2019-07-01 15:28:33 --> Config Class Initialized
INFO - 2019-07-01 15:28:33 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:28:33 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:28:33 --> Utf8 Class Initialized
INFO - 2019-07-01 15:28:33 --> URI Class Initialized
INFO - 2019-07-01 15:28:33 --> Router Class Initialized
INFO - 2019-07-01 15:28:33 --> Output Class Initialized
INFO - 2019-07-01 15:28:33 --> Security Class Initialized
DEBUG - 2019-07-01 15:28:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:28:33 --> Input Class Initialized
INFO - 2019-07-01 15:28:33 --> Language Class Initialized
INFO - 2019-07-01 15:28:33 --> Language Class Initialized
INFO - 2019-07-01 15:28:33 --> Config Class Initialized
INFO - 2019-07-01 15:28:33 --> Loader Class Initialized
DEBUG - 2019-07-01 15:28:33 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:28:33 --> Helper loaded: url_helper
INFO - 2019-07-01 15:28:33 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:28:33 --> Helper loaded: string_helper
INFO - 2019-07-01 15:28:33 --> Helper loaded: array_helper
INFO - 2019-07-01 15:28:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:28:33 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:28:33 --> Database Driver Class Initialized
INFO - 2019-07-01 15:28:33 --> Controller Class Initialized
INFO - 2019-07-01 21:28:33 --> Helper loaded: language_helper
INFO - 2019-07-01 21:28:33 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:28:33 --> Model Class Initialized
INFO - 2019-07-01 21:28:33 --> Model Class Initialized
INFO - 2019-07-01 21:28:33 --> Model Class Initialized
INFO - 2019-07-01 21:28:33 --> Model Class Initialized
INFO - 2019-07-01 21:28:33 --> Helper loaded: form_helper
INFO - 2019-07-01 21:28:33 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:28:33 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:28:33 --> Model Class Initialized
INFO - 2019-07-01 21:28:33 --> Model Class Initialized
INFO - 2019-07-01 21:28:33 --> Final output sent to browser
DEBUG - 2019-07-01 21:28:33 --> Total execution time: 0.7701
INFO - 2019-07-01 15:29:03 --> Config Class Initialized
INFO - 2019-07-01 15:29:03 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:29:03 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:29:03 --> Utf8 Class Initialized
INFO - 2019-07-01 15:29:03 --> URI Class Initialized
INFO - 2019-07-01 15:29:03 --> Router Class Initialized
INFO - 2019-07-01 15:29:03 --> Output Class Initialized
INFO - 2019-07-01 15:29:03 --> Security Class Initialized
DEBUG - 2019-07-01 15:29:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:29:03 --> Input Class Initialized
INFO - 2019-07-01 15:29:03 --> Language Class Initialized
INFO - 2019-07-01 15:29:03 --> Language Class Initialized
INFO - 2019-07-01 15:29:03 --> Config Class Initialized
INFO - 2019-07-01 15:29:03 --> Loader Class Initialized
DEBUG - 2019-07-01 15:29:03 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:29:03 --> Helper loaded: url_helper
INFO - 2019-07-01 15:29:03 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:29:03 --> Helper loaded: string_helper
INFO - 2019-07-01 15:29:03 --> Helper loaded: array_helper
INFO - 2019-07-01 15:29:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:29:04 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:29:04 --> Database Driver Class Initialized
INFO - 2019-07-01 15:29:04 --> Controller Class Initialized
INFO - 2019-07-01 21:29:04 --> Helper loaded: language_helper
INFO - 2019-07-01 21:29:04 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:29:04 --> Model Class Initialized
INFO - 2019-07-01 21:29:04 --> Model Class Initialized
INFO - 2019-07-01 21:29:04 --> Model Class Initialized
INFO - 2019-07-01 21:29:04 --> Model Class Initialized
INFO - 2019-07-01 21:29:04 --> Helper loaded: form_helper
INFO - 2019-07-01 21:29:04 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:29:04 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:29:04 --> Model Class Initialized
INFO - 2019-07-01 21:29:04 --> Model Class Initialized
INFO - 2019-07-01 21:29:04 --> Final output sent to browser
DEBUG - 2019-07-01 21:29:04 --> Total execution time: 0.7728
INFO - 2019-07-01 15:29:09 --> Config Class Initialized
INFO - 2019-07-01 15:29:09 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:29:09 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:29:09 --> Utf8 Class Initialized
INFO - 2019-07-01 15:29:09 --> URI Class Initialized
INFO - 2019-07-01 15:29:09 --> Router Class Initialized
INFO - 2019-07-01 15:29:09 --> Output Class Initialized
INFO - 2019-07-01 15:29:09 --> Security Class Initialized
DEBUG - 2019-07-01 15:29:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:29:09 --> Input Class Initialized
INFO - 2019-07-01 15:29:09 --> Language Class Initialized
INFO - 2019-07-01 15:29:09 --> Language Class Initialized
INFO - 2019-07-01 15:29:09 --> Config Class Initialized
INFO - 2019-07-01 15:29:09 --> Loader Class Initialized
DEBUG - 2019-07-01 15:29:09 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:29:09 --> Helper loaded: url_helper
INFO - 2019-07-01 15:29:09 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:29:10 --> Helper loaded: string_helper
INFO - 2019-07-01 15:29:10 --> Helper loaded: array_helper
INFO - 2019-07-01 15:29:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:29:10 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:29:10 --> Database Driver Class Initialized
INFO - 2019-07-01 15:29:10 --> Controller Class Initialized
INFO - 2019-07-01 21:29:10 --> Helper loaded: language_helper
INFO - 2019-07-01 21:29:10 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:29:10 --> Model Class Initialized
INFO - 2019-07-01 21:29:10 --> Model Class Initialized
INFO - 2019-07-01 21:29:10 --> Model Class Initialized
INFO - 2019-07-01 21:29:10 --> Model Class Initialized
INFO - 2019-07-01 21:29:10 --> Helper loaded: form_helper
INFO - 2019-07-01 21:29:10 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:29:10 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:29:10 --> Model Class Initialized
INFO - 2019-07-01 21:29:10 --> Model Class Initialized
INFO - 2019-07-01 21:29:10 --> Final output sent to browser
DEBUG - 2019-07-01 21:29:10 --> Total execution time: 0.7333
INFO - 2019-07-01 15:31:21 --> Config Class Initialized
INFO - 2019-07-01 15:31:21 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:31:21 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:31:21 --> Utf8 Class Initialized
INFO - 2019-07-01 15:31:22 --> URI Class Initialized
INFO - 2019-07-01 15:31:22 --> Router Class Initialized
INFO - 2019-07-01 15:31:22 --> Output Class Initialized
INFO - 2019-07-01 15:31:22 --> Security Class Initialized
DEBUG - 2019-07-01 15:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:31:22 --> Input Class Initialized
INFO - 2019-07-01 15:31:22 --> Language Class Initialized
INFO - 2019-07-01 15:31:22 --> Language Class Initialized
INFO - 2019-07-01 15:31:22 --> Config Class Initialized
INFO - 2019-07-01 15:31:22 --> Loader Class Initialized
DEBUG - 2019-07-01 15:31:22 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:31:22 --> Helper loaded: url_helper
INFO - 2019-07-01 15:31:22 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:31:22 --> Helper loaded: string_helper
INFO - 2019-07-01 15:31:22 --> Helper loaded: array_helper
INFO - 2019-07-01 15:31:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:31:22 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:31:22 --> Database Driver Class Initialized
INFO - 2019-07-01 15:31:22 --> Controller Class Initialized
INFO - 2019-07-01 21:31:22 --> Helper loaded: language_helper
INFO - 2019-07-01 21:31:22 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:31:22 --> Model Class Initialized
INFO - 2019-07-01 21:31:22 --> Model Class Initialized
INFO - 2019-07-01 21:31:22 --> Model Class Initialized
INFO - 2019-07-01 21:31:22 --> Model Class Initialized
INFO - 2019-07-01 21:31:22 --> Helper loaded: form_helper
INFO - 2019-07-01 21:31:22 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:31:22 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:31:22 --> Model Class Initialized
INFO - 2019-07-01 21:31:22 --> Model Class Initialized
INFO - 2019-07-01 21:31:23 --> Final output sent to browser
DEBUG - 2019-07-01 21:31:23 --> Total execution time: 1.2086
INFO - 2019-07-01 15:31:45 --> Config Class Initialized
INFO - 2019-07-01 15:31:45 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:31:45 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:31:45 --> Utf8 Class Initialized
INFO - 2019-07-01 15:31:45 --> URI Class Initialized
INFO - 2019-07-01 15:31:45 --> Router Class Initialized
INFO - 2019-07-01 15:31:45 --> Output Class Initialized
INFO - 2019-07-01 15:31:45 --> Security Class Initialized
DEBUG - 2019-07-01 15:31:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:31:45 --> Input Class Initialized
INFO - 2019-07-01 15:31:46 --> Language Class Initialized
INFO - 2019-07-01 15:31:46 --> Language Class Initialized
INFO - 2019-07-01 15:31:46 --> Config Class Initialized
INFO - 2019-07-01 15:31:46 --> Loader Class Initialized
DEBUG - 2019-07-01 15:31:46 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:31:46 --> Helper loaded: url_helper
INFO - 2019-07-01 15:31:46 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:31:46 --> Helper loaded: string_helper
INFO - 2019-07-01 15:31:46 --> Helper loaded: array_helper
INFO - 2019-07-01 15:31:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:31:46 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:31:46 --> Database Driver Class Initialized
INFO - 2019-07-01 15:31:46 --> Controller Class Initialized
INFO - 2019-07-01 21:31:46 --> Helper loaded: language_helper
INFO - 2019-07-01 21:31:46 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:31:46 --> Model Class Initialized
INFO - 2019-07-01 21:31:46 --> Model Class Initialized
INFO - 2019-07-01 21:31:46 --> Model Class Initialized
INFO - 2019-07-01 21:31:46 --> Model Class Initialized
INFO - 2019-07-01 21:31:46 --> Helper loaded: form_helper
INFO - 2019-07-01 21:31:46 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:31:46 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:31:46 --> Model Class Initialized
INFO - 2019-07-01 21:31:46 --> Model Class Initialized
INFO - 2019-07-01 21:31:46 --> Final output sent to browser
DEBUG - 2019-07-01 21:31:46 --> Total execution time: 0.5144
INFO - 2019-07-01 15:31:48 --> Config Class Initialized
INFO - 2019-07-01 15:31:48 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:31:48 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:31:48 --> Utf8 Class Initialized
INFO - 2019-07-01 15:31:48 --> URI Class Initialized
INFO - 2019-07-01 15:31:48 --> Router Class Initialized
INFO - 2019-07-01 15:31:48 --> Output Class Initialized
INFO - 2019-07-01 15:31:48 --> Security Class Initialized
DEBUG - 2019-07-01 15:31:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:31:48 --> Input Class Initialized
INFO - 2019-07-01 15:31:48 --> Language Class Initialized
INFO - 2019-07-01 15:31:48 --> Language Class Initialized
INFO - 2019-07-01 15:31:48 --> Config Class Initialized
INFO - 2019-07-01 15:31:48 --> Loader Class Initialized
DEBUG - 2019-07-01 15:31:48 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:31:48 --> Helper loaded: url_helper
INFO - 2019-07-01 15:31:48 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:31:48 --> Helper loaded: string_helper
INFO - 2019-07-01 15:31:48 --> Helper loaded: array_helper
INFO - 2019-07-01 15:31:48 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:31:48 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:31:48 --> Database Driver Class Initialized
INFO - 2019-07-01 15:31:48 --> Controller Class Initialized
INFO - 2019-07-01 21:31:48 --> Helper loaded: language_helper
INFO - 2019-07-01 21:31:48 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:31:48 --> Model Class Initialized
INFO - 2019-07-01 21:31:48 --> Model Class Initialized
INFO - 2019-07-01 21:31:48 --> Model Class Initialized
INFO - 2019-07-01 21:31:48 --> Model Class Initialized
INFO - 2019-07-01 21:31:48 --> Helper loaded: form_helper
INFO - 2019-07-01 21:31:48 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:31:48 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:31:49 --> Model Class Initialized
INFO - 2019-07-01 21:31:49 --> Model Class Initialized
INFO - 2019-07-01 21:31:49 --> Final output sent to browser
DEBUG - 2019-07-01 21:31:49 --> Total execution time: 0.6986
INFO - 2019-07-01 15:32:05 --> Config Class Initialized
INFO - 2019-07-01 15:32:05 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:32:05 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:32:05 --> Utf8 Class Initialized
INFO - 2019-07-01 15:32:05 --> URI Class Initialized
INFO - 2019-07-01 15:32:05 --> Router Class Initialized
INFO - 2019-07-01 15:32:05 --> Output Class Initialized
INFO - 2019-07-01 15:32:05 --> Security Class Initialized
DEBUG - 2019-07-01 15:32:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:32:05 --> Input Class Initialized
INFO - 2019-07-01 15:32:05 --> Language Class Initialized
INFO - 2019-07-01 15:32:05 --> Language Class Initialized
INFO - 2019-07-01 15:32:05 --> Config Class Initialized
INFO - 2019-07-01 15:32:05 --> Loader Class Initialized
DEBUG - 2019-07-01 15:32:05 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:32:05 --> Helper loaded: url_helper
INFO - 2019-07-01 15:32:06 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:32:06 --> Helper loaded: string_helper
INFO - 2019-07-01 15:32:06 --> Helper loaded: array_helper
INFO - 2019-07-01 15:32:06 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:32:06 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:32:06 --> Database Driver Class Initialized
INFO - 2019-07-01 15:32:06 --> Controller Class Initialized
INFO - 2019-07-01 21:32:06 --> Helper loaded: language_helper
INFO - 2019-07-01 21:32:06 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:32:06 --> Model Class Initialized
INFO - 2019-07-01 21:32:06 --> Model Class Initialized
INFO - 2019-07-01 21:32:06 --> Model Class Initialized
INFO - 2019-07-01 21:32:06 --> Model Class Initialized
INFO - 2019-07-01 21:32:06 --> Helper loaded: form_helper
INFO - 2019-07-01 21:32:06 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:32:06 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:32:06 --> Model Class Initialized
INFO - 2019-07-01 21:32:06 --> Model Class Initialized
ERROR - 2019-07-01 21:32:06 --> Severity: Notice --> Undefined index: resto_id C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 112
ERROR - 2019-07-01 21:32:06 --> Severity: Notice --> Undefined index: resto_id C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 115
ERROR - 2019-07-01 21:32:06 --> Query error: Unknown column 'order_number' in 'field list' - Invalid query: INSERT INTO `orders` (`customer_id`, `resto_id`, `order_number`, `created_at`, `updated_at`) VALUES ('1', NULL, '11561987926', '2019-07-01 21:32:06', '2019-07-01 21:32:06')
INFO - 2019-07-01 21:32:06 --> Language file loaded: language/english/db_lang.php
INFO - 2019-07-01 15:32:33 --> Config Class Initialized
INFO - 2019-07-01 15:32:33 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:32:33 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:32:33 --> Utf8 Class Initialized
INFO - 2019-07-01 15:32:33 --> URI Class Initialized
INFO - 2019-07-01 15:32:33 --> Router Class Initialized
INFO - 2019-07-01 15:32:33 --> Output Class Initialized
INFO - 2019-07-01 15:32:33 --> Security Class Initialized
DEBUG - 2019-07-01 15:32:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:32:33 --> Input Class Initialized
INFO - 2019-07-01 15:32:33 --> Language Class Initialized
INFO - 2019-07-01 15:32:33 --> Language Class Initialized
INFO - 2019-07-01 15:32:33 --> Config Class Initialized
INFO - 2019-07-01 15:32:34 --> Loader Class Initialized
DEBUG - 2019-07-01 15:32:34 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:32:34 --> Helper loaded: url_helper
INFO - 2019-07-01 15:32:34 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:32:34 --> Helper loaded: string_helper
INFO - 2019-07-01 15:32:34 --> Helper loaded: array_helper
INFO - 2019-07-01 15:32:34 --> Config Class Initialized
INFO - 2019-07-01 15:32:34 --> Session: Class initialized using 'files' driver.
INFO - 2019-07-01 15:32:34 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:32:34 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:32:34 --> Utf8 Class Initialized
DEBUG - 2019-07-01 15:32:34 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:32:34 --> URI Class Initialized
INFO - 2019-07-01 15:32:34 --> Database Driver Class Initialized
INFO - 2019-07-01 15:32:34 --> Router Class Initialized
INFO - 2019-07-01 15:32:34 --> Controller Class Initialized
INFO - 2019-07-01 15:32:34 --> Output Class Initialized
INFO - 2019-07-01 21:32:34 --> Helper loaded: language_helper
INFO - 2019-07-01 15:32:34 --> Security Class Initialized
INFO - 2019-07-01 21:32:34 --> Language file loaded: language/english/general_lang.php
DEBUG - 2019-07-01 15:32:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 21:32:34 --> Model Class Initialized
INFO - 2019-07-01 15:32:34 --> Input Class Initialized
INFO - 2019-07-01 21:32:34 --> Model Class Initialized
INFO - 2019-07-01 15:32:34 --> Language Class Initialized
INFO - 2019-07-01 21:32:34 --> Model Class Initialized
INFO - 2019-07-01 15:32:34 --> Language Class Initialized
INFO - 2019-07-01 15:32:34 --> Config Class Initialized
INFO - 2019-07-01 21:32:34 --> Model Class Initialized
INFO - 2019-07-01 15:32:34 --> Loader Class Initialized
INFO - 2019-07-01 21:32:34 --> Helper loaded: form_helper
DEBUG - 2019-07-01 15:32:34 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 21:32:34 --> Form Validation Class Initialized
INFO - 2019-07-01 15:32:34 --> Helper loaded: url_helper
DEBUG - 2019-07-01 21:32:34 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 15:32:34 --> Helper loaded: inflector_helper
INFO - 2019-07-01 21:32:34 --> Model Class Initialized
INFO - 2019-07-01 21:32:34 --> Model Class Initialized
INFO - 2019-07-01 15:32:34 --> Helper loaded: string_helper
INFO - 2019-07-01 15:32:35 --> Helper loaded: array_helper
INFO - 2019-07-01 21:32:35 --> Final output sent to browser
DEBUG - 2019-07-01 21:32:35 --> Total execution time: 1.5205
INFO - 2019-07-01 15:32:35 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:32:35 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:32:35 --> Database Driver Class Initialized
INFO - 2019-07-01 15:32:35 --> Controller Class Initialized
INFO - 2019-07-01 21:32:35 --> Helper loaded: language_helper
INFO - 2019-07-01 21:32:35 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:32:35 --> Model Class Initialized
INFO - 2019-07-01 21:32:35 --> Model Class Initialized
INFO - 2019-07-01 21:32:35 --> Model Class Initialized
INFO - 2019-07-01 21:32:35 --> Model Class Initialized
INFO - 2019-07-01 21:32:35 --> Helper loaded: form_helper
INFO - 2019-07-01 21:32:35 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:32:35 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:32:35 --> Model Class Initialized
INFO - 2019-07-01 21:32:35 --> Model Class Initialized
INFO - 2019-07-01 21:32:35 --> Final output sent to browser
DEBUG - 2019-07-01 21:32:35 --> Total execution time: 1.3164
INFO - 2019-07-01 15:32:41 --> Config Class Initialized
INFO - 2019-07-01 15:32:41 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:32:41 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:32:41 --> Utf8 Class Initialized
INFO - 2019-07-01 15:32:41 --> URI Class Initialized
INFO - 2019-07-01 15:32:41 --> Router Class Initialized
INFO - 2019-07-01 15:32:41 --> Output Class Initialized
INFO - 2019-07-01 15:32:41 --> Security Class Initialized
DEBUG - 2019-07-01 15:32:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:32:41 --> Input Class Initialized
INFO - 2019-07-01 15:32:41 --> Language Class Initialized
INFO - 2019-07-01 15:32:41 --> Language Class Initialized
INFO - 2019-07-01 15:32:41 --> Config Class Initialized
INFO - 2019-07-01 15:32:41 --> Loader Class Initialized
DEBUG - 2019-07-01 15:32:41 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:32:41 --> Helper loaded: url_helper
INFO - 2019-07-01 15:32:41 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:32:41 --> Helper loaded: string_helper
INFO - 2019-07-01 15:32:41 --> Helper loaded: array_helper
INFO - 2019-07-01 15:32:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:32:41 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:32:41 --> Database Driver Class Initialized
INFO - 2019-07-01 15:32:41 --> Controller Class Initialized
INFO - 2019-07-01 21:32:41 --> Helper loaded: language_helper
INFO - 2019-07-01 21:32:41 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:32:41 --> Model Class Initialized
INFO - 2019-07-01 21:32:41 --> Model Class Initialized
INFO - 2019-07-01 21:32:41 --> Model Class Initialized
INFO - 2019-07-01 21:32:41 --> Model Class Initialized
INFO - 2019-07-01 21:32:41 --> Helper loaded: form_helper
INFO - 2019-07-01 21:32:41 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:32:41 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:32:41 --> Model Class Initialized
INFO - 2019-07-01 21:32:41 --> Model Class Initialized
INFO - 2019-07-01 21:32:41 --> Final output sent to browser
DEBUG - 2019-07-01 21:32:41 --> Total execution time: 0.6609
INFO - 2019-07-01 15:32:41 --> Config Class Initialized
INFO - 2019-07-01 15:32:41 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:32:41 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:32:41 --> Utf8 Class Initialized
INFO - 2019-07-01 15:32:41 --> URI Class Initialized
INFO - 2019-07-01 15:32:41 --> Router Class Initialized
INFO - 2019-07-01 15:32:41 --> Output Class Initialized
INFO - 2019-07-01 15:32:41 --> Security Class Initialized
DEBUG - 2019-07-01 15:32:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:32:41 --> Input Class Initialized
INFO - 2019-07-01 15:32:41 --> Language Class Initialized
INFO - 2019-07-01 15:32:42 --> Language Class Initialized
INFO - 2019-07-01 15:32:42 --> Config Class Initialized
INFO - 2019-07-01 15:32:42 --> Loader Class Initialized
DEBUG - 2019-07-01 15:32:42 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:32:42 --> Helper loaded: url_helper
INFO - 2019-07-01 15:32:42 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:32:42 --> Helper loaded: string_helper
INFO - 2019-07-01 15:32:42 --> Helper loaded: array_helper
INFO - 2019-07-01 15:32:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:32:42 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:32:42 --> Database Driver Class Initialized
INFO - 2019-07-01 15:32:42 --> Controller Class Initialized
INFO - 2019-07-01 21:32:42 --> Helper loaded: language_helper
INFO - 2019-07-01 21:32:42 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:32:42 --> Model Class Initialized
INFO - 2019-07-01 21:32:42 --> Model Class Initialized
INFO - 2019-07-01 21:32:42 --> Model Class Initialized
INFO - 2019-07-01 21:32:42 --> Model Class Initialized
INFO - 2019-07-01 21:32:42 --> Helper loaded: form_helper
INFO - 2019-07-01 21:32:42 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:32:42 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:32:42 --> Model Class Initialized
INFO - 2019-07-01 21:32:42 --> Model Class Initialized
INFO - 2019-07-01 21:32:42 --> Final output sent to browser
DEBUG - 2019-07-01 21:32:42 --> Total execution time: 0.6406
INFO - 2019-07-01 15:32:45 --> Config Class Initialized
INFO - 2019-07-01 15:32:45 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:32:45 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:32:45 --> Utf8 Class Initialized
INFO - 2019-07-01 15:32:45 --> URI Class Initialized
INFO - 2019-07-01 15:32:45 --> Router Class Initialized
INFO - 2019-07-01 15:32:46 --> Output Class Initialized
INFO - 2019-07-01 15:32:46 --> Security Class Initialized
DEBUG - 2019-07-01 15:32:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:32:46 --> Input Class Initialized
INFO - 2019-07-01 15:32:46 --> Language Class Initialized
INFO - 2019-07-01 15:32:46 --> Language Class Initialized
INFO - 2019-07-01 15:32:46 --> Config Class Initialized
INFO - 2019-07-01 15:32:46 --> Loader Class Initialized
DEBUG - 2019-07-01 15:32:46 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:32:46 --> Helper loaded: url_helper
INFO - 2019-07-01 15:32:46 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:32:46 --> Helper loaded: string_helper
INFO - 2019-07-01 15:32:46 --> Helper loaded: array_helper
INFO - 2019-07-01 15:32:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:32:46 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:32:46 --> Database Driver Class Initialized
INFO - 2019-07-01 15:32:46 --> Controller Class Initialized
INFO - 2019-07-01 21:32:46 --> Helper loaded: language_helper
INFO - 2019-07-01 21:32:46 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:32:46 --> Model Class Initialized
INFO - 2019-07-01 21:32:46 --> Model Class Initialized
INFO - 2019-07-01 21:32:46 --> Model Class Initialized
INFO - 2019-07-01 21:32:46 --> Model Class Initialized
INFO - 2019-07-01 21:32:46 --> Helper loaded: form_helper
INFO - 2019-07-01 21:32:46 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:32:46 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:32:46 --> Model Class Initialized
INFO - 2019-07-01 21:32:46 --> Model Class Initialized
INFO - 2019-07-01 21:32:46 --> Final output sent to browser
DEBUG - 2019-07-01 21:32:46 --> Total execution time: 0.5442
INFO - 2019-07-01 15:32:50 --> Config Class Initialized
INFO - 2019-07-01 15:32:50 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:32:50 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:32:50 --> Utf8 Class Initialized
INFO - 2019-07-01 15:32:50 --> URI Class Initialized
INFO - 2019-07-01 15:32:50 --> Router Class Initialized
INFO - 2019-07-01 15:32:50 --> Output Class Initialized
INFO - 2019-07-01 15:32:50 --> Security Class Initialized
DEBUG - 2019-07-01 15:32:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:32:50 --> Input Class Initialized
INFO - 2019-07-01 15:32:50 --> Language Class Initialized
INFO - 2019-07-01 15:32:50 --> Language Class Initialized
INFO - 2019-07-01 15:32:50 --> Config Class Initialized
INFO - 2019-07-01 15:32:50 --> Loader Class Initialized
DEBUG - 2019-07-01 15:32:50 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:32:50 --> Helper loaded: url_helper
INFO - 2019-07-01 15:32:50 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:32:50 --> Helper loaded: string_helper
INFO - 2019-07-01 15:32:50 --> Helper loaded: array_helper
INFO - 2019-07-01 15:32:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:32:50 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:32:51 --> Database Driver Class Initialized
INFO - 2019-07-01 15:32:51 --> Controller Class Initialized
INFO - 2019-07-01 21:32:51 --> Helper loaded: language_helper
INFO - 2019-07-01 21:32:51 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:32:51 --> Model Class Initialized
INFO - 2019-07-01 21:32:51 --> Model Class Initialized
INFO - 2019-07-01 21:32:51 --> Model Class Initialized
INFO - 2019-07-01 21:32:51 --> Model Class Initialized
INFO - 2019-07-01 21:32:51 --> Helper loaded: form_helper
INFO - 2019-07-01 21:32:51 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:32:51 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:32:51 --> Model Class Initialized
INFO - 2019-07-01 21:32:51 --> Model Class Initialized
INFO - 2019-07-01 21:32:51 --> Final output sent to browser
DEBUG - 2019-07-01 21:32:51 --> Total execution time: 0.9226
INFO - 2019-07-01 15:33:09 --> Config Class Initialized
INFO - 2019-07-01 15:33:09 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:33:09 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:33:09 --> Utf8 Class Initialized
INFO - 2019-07-01 15:33:09 --> URI Class Initialized
INFO - 2019-07-01 15:33:09 --> Router Class Initialized
INFO - 2019-07-01 15:33:09 --> Output Class Initialized
INFO - 2019-07-01 15:33:09 --> Security Class Initialized
DEBUG - 2019-07-01 15:33:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:33:09 --> Input Class Initialized
INFO - 2019-07-01 15:33:09 --> Language Class Initialized
INFO - 2019-07-01 15:33:09 --> Language Class Initialized
INFO - 2019-07-01 15:33:09 --> Config Class Initialized
INFO - 2019-07-01 15:33:09 --> Loader Class Initialized
DEBUG - 2019-07-01 15:33:09 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:33:09 --> Helper loaded: url_helper
INFO - 2019-07-01 15:33:09 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:33:09 --> Helper loaded: string_helper
INFO - 2019-07-01 15:33:09 --> Helper loaded: array_helper
INFO - 2019-07-01 15:33:09 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:33:09 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:33:09 --> Database Driver Class Initialized
INFO - 2019-07-01 15:33:09 --> Controller Class Initialized
INFO - 2019-07-01 21:33:09 --> Helper loaded: language_helper
INFO - 2019-07-01 21:33:09 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:33:09 --> Model Class Initialized
INFO - 2019-07-01 21:33:09 --> Model Class Initialized
INFO - 2019-07-01 21:33:09 --> Model Class Initialized
INFO - 2019-07-01 21:33:09 --> Model Class Initialized
INFO - 2019-07-01 21:33:09 --> Helper loaded: form_helper
INFO - 2019-07-01 21:33:09 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:33:09 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:33:09 --> Model Class Initialized
INFO - 2019-07-01 21:33:10 --> Model Class Initialized
INFO - 2019-07-01 21:33:10 --> Final output sent to browser
DEBUG - 2019-07-01 21:33:10 --> Total execution time: 0.7208
INFO - 2019-07-01 15:33:38 --> Config Class Initialized
INFO - 2019-07-01 15:33:38 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:33:38 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:33:38 --> Utf8 Class Initialized
INFO - 2019-07-01 15:33:38 --> URI Class Initialized
INFO - 2019-07-01 15:33:38 --> Router Class Initialized
INFO - 2019-07-01 15:33:38 --> Output Class Initialized
INFO - 2019-07-01 15:33:38 --> Security Class Initialized
DEBUG - 2019-07-01 15:33:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:33:38 --> Input Class Initialized
INFO - 2019-07-01 15:33:38 --> Language Class Initialized
INFO - 2019-07-01 15:33:38 --> Language Class Initialized
INFO - 2019-07-01 15:33:38 --> Config Class Initialized
INFO - 2019-07-01 15:33:38 --> Loader Class Initialized
DEBUG - 2019-07-01 15:33:38 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:33:38 --> Helper loaded: url_helper
INFO - 2019-07-01 15:33:38 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:33:38 --> Helper loaded: string_helper
INFO - 2019-07-01 15:33:38 --> Helper loaded: array_helper
INFO - 2019-07-01 15:33:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:33:38 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:33:38 --> Database Driver Class Initialized
INFO - 2019-07-01 15:33:38 --> Controller Class Initialized
INFO - 2019-07-01 21:33:38 --> Helper loaded: language_helper
INFO - 2019-07-01 21:33:38 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:33:38 --> Model Class Initialized
INFO - 2019-07-01 21:33:38 --> Model Class Initialized
INFO - 2019-07-01 21:33:38 --> Model Class Initialized
INFO - 2019-07-01 21:33:38 --> Model Class Initialized
INFO - 2019-07-01 21:33:38 --> Model Class Initialized
INFO - 2019-07-01 21:33:38 --> Final output sent to browser
DEBUG - 2019-07-01 21:33:38 --> Total execution time: 0.6249
INFO - 2019-07-01 15:33:44 --> Config Class Initialized
INFO - 2019-07-01 15:33:44 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:33:44 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:33:44 --> Utf8 Class Initialized
INFO - 2019-07-01 15:33:44 --> URI Class Initialized
INFO - 2019-07-01 15:33:44 --> Router Class Initialized
INFO - 2019-07-01 15:33:44 --> Output Class Initialized
INFO - 2019-07-01 15:33:44 --> Security Class Initialized
DEBUG - 2019-07-01 15:33:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:33:44 --> Input Class Initialized
INFO - 2019-07-01 15:33:44 --> Language Class Initialized
INFO - 2019-07-01 15:33:44 --> Language Class Initialized
INFO - 2019-07-01 15:33:44 --> Config Class Initialized
INFO - 2019-07-01 15:33:44 --> Loader Class Initialized
DEBUG - 2019-07-01 15:33:45 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:33:45 --> Helper loaded: url_helper
INFO - 2019-07-01 15:33:45 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:33:45 --> Helper loaded: string_helper
INFO - 2019-07-01 15:33:45 --> Helper loaded: array_helper
INFO - 2019-07-01 15:33:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:33:45 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:33:45 --> Database Driver Class Initialized
INFO - 2019-07-01 15:33:45 --> Controller Class Initialized
INFO - 2019-07-01 21:33:45 --> Helper loaded: language_helper
INFO - 2019-07-01 21:33:45 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:33:45 --> Model Class Initialized
INFO - 2019-07-01 21:33:45 --> Model Class Initialized
INFO - 2019-07-01 21:33:45 --> Model Class Initialized
INFO - 2019-07-01 21:33:45 --> Model Class Initialized
INFO - 2019-07-01 21:33:45 --> Helper loaded: form_helper
INFO - 2019-07-01 21:33:45 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:33:45 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:33:45 --> Model Class Initialized
INFO - 2019-07-01 21:33:45 --> Model Class Initialized
ERROR - 2019-07-01 21:33:45 --> Query error: Unknown column 'order_number' in 'field list' - Invalid query: INSERT INTO `orders` (`customer_id`, `resto_id`, `order_number`, `created_at`, `updated_at`) VALUES ('1', '2', '11561988025', '2019-07-01 21:33:45', '2019-07-01 21:33:45')
INFO - 2019-07-01 21:33:45 --> Language file loaded: language/english/db_lang.php
INFO - 2019-07-01 15:33:45 --> Config Class Initialized
INFO - 2019-07-01 15:33:45 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:33:45 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:33:45 --> Utf8 Class Initialized
INFO - 2019-07-01 15:33:45 --> URI Class Initialized
INFO - 2019-07-01 15:33:45 --> Router Class Initialized
INFO - 2019-07-01 15:33:45 --> Output Class Initialized
INFO - 2019-07-01 15:33:45 --> Security Class Initialized
DEBUG - 2019-07-01 15:33:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:33:45 --> Input Class Initialized
INFO - 2019-07-01 15:33:45 --> Language Class Initialized
INFO - 2019-07-01 15:33:45 --> Language Class Initialized
INFO - 2019-07-01 15:33:45 --> Config Class Initialized
INFO - 2019-07-01 15:33:45 --> Loader Class Initialized
DEBUG - 2019-07-01 15:33:45 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:33:45 --> Helper loaded: url_helper
INFO - 2019-07-01 15:33:45 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:33:45 --> Helper loaded: string_helper
INFO - 2019-07-01 15:33:45 --> Helper loaded: array_helper
INFO - 2019-07-01 15:33:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:33:45 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:33:45 --> Database Driver Class Initialized
INFO - 2019-07-01 15:33:45 --> Controller Class Initialized
INFO - 2019-07-01 21:33:45 --> Helper loaded: language_helper
INFO - 2019-07-01 21:33:45 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:33:45 --> Model Class Initialized
INFO - 2019-07-01 21:33:45 --> Model Class Initialized
INFO - 2019-07-01 21:33:45 --> Model Class Initialized
INFO - 2019-07-01 21:33:45 --> Model Class Initialized
INFO - 2019-07-01 21:33:45 --> Helper loaded: form_helper
INFO - 2019-07-01 21:33:45 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:33:45 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:33:45 --> Model Class Initialized
INFO - 2019-07-01 21:33:45 --> Model Class Initialized
INFO - 2019-07-01 21:33:45 --> Final output sent to browser
DEBUG - 2019-07-01 21:33:45 --> Total execution time: 0.4956
INFO - 2019-07-01 15:35:58 --> Config Class Initialized
INFO - 2019-07-01 15:35:58 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:35:58 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:35:58 --> Utf8 Class Initialized
INFO - 2019-07-01 15:35:58 --> URI Class Initialized
INFO - 2019-07-01 15:35:59 --> Router Class Initialized
INFO - 2019-07-01 15:35:59 --> Output Class Initialized
INFO - 2019-07-01 15:35:59 --> Security Class Initialized
DEBUG - 2019-07-01 15:35:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:35:59 --> Input Class Initialized
INFO - 2019-07-01 15:35:59 --> Language Class Initialized
INFO - 2019-07-01 15:35:59 --> Language Class Initialized
INFO - 2019-07-01 15:35:59 --> Config Class Initialized
INFO - 2019-07-01 15:35:59 --> Loader Class Initialized
DEBUG - 2019-07-01 15:35:59 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:35:59 --> Helper loaded: url_helper
INFO - 2019-07-01 15:35:59 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:35:59 --> Helper loaded: string_helper
INFO - 2019-07-01 15:35:59 --> Helper loaded: array_helper
INFO - 2019-07-01 15:35:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:35:59 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:35:59 --> Database Driver Class Initialized
INFO - 2019-07-01 15:35:59 --> Controller Class Initialized
INFO - 2019-07-01 21:35:59 --> Helper loaded: language_helper
INFO - 2019-07-01 21:35:59 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:35:59 --> Model Class Initialized
INFO - 2019-07-01 21:35:59 --> Model Class Initialized
INFO - 2019-07-01 21:35:59 --> Model Class Initialized
INFO - 2019-07-01 21:35:59 --> Model Class Initialized
INFO - 2019-07-01 21:35:59 --> Helper loaded: form_helper
INFO - 2019-07-01 21:35:59 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:35:59 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:35:59 --> Model Class Initialized
INFO - 2019-07-01 21:35:59 --> Model Class Initialized
INFO - 2019-07-01 21:35:59 --> Final output sent to browser
DEBUG - 2019-07-01 21:35:59 --> Total execution time: 1.0784
INFO - 2019-07-01 15:36:00 --> Config Class Initialized
INFO - 2019-07-01 15:36:00 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:36:00 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:36:00 --> Utf8 Class Initialized
INFO - 2019-07-01 15:36:00 --> URI Class Initialized
INFO - 2019-07-01 15:36:00 --> Router Class Initialized
INFO - 2019-07-01 15:36:01 --> Output Class Initialized
INFO - 2019-07-01 15:36:01 --> Security Class Initialized
DEBUG - 2019-07-01 15:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:36:01 --> Input Class Initialized
INFO - 2019-07-01 15:36:01 --> Language Class Initialized
INFO - 2019-07-01 15:36:01 --> Language Class Initialized
INFO - 2019-07-01 15:36:01 --> Config Class Initialized
INFO - 2019-07-01 15:36:01 --> Loader Class Initialized
DEBUG - 2019-07-01 15:36:01 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:36:01 --> Helper loaded: url_helper
INFO - 2019-07-01 15:36:01 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:36:01 --> Helper loaded: string_helper
INFO - 2019-07-01 15:36:01 --> Helper loaded: array_helper
INFO - 2019-07-01 15:36:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:36:01 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:36:01 --> Database Driver Class Initialized
INFO - 2019-07-01 15:36:01 --> Controller Class Initialized
INFO - 2019-07-01 21:36:01 --> Helper loaded: language_helper
INFO - 2019-07-01 21:36:01 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:36:01 --> Model Class Initialized
INFO - 2019-07-01 21:36:01 --> Model Class Initialized
INFO - 2019-07-01 21:36:01 --> Model Class Initialized
INFO - 2019-07-01 21:36:01 --> Model Class Initialized
INFO - 2019-07-01 21:36:01 --> Model Class Initialized
INFO - 2019-07-01 21:36:01 --> Final output sent to browser
DEBUG - 2019-07-01 21:36:01 --> Total execution time: 0.8585
INFO - 2019-07-01 15:36:07 --> Config Class Initialized
INFO - 2019-07-01 15:36:07 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:36:07 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:36:07 --> Utf8 Class Initialized
INFO - 2019-07-01 15:36:07 --> URI Class Initialized
INFO - 2019-07-01 15:36:07 --> Router Class Initialized
INFO - 2019-07-01 15:36:07 --> Output Class Initialized
INFO - 2019-07-01 15:36:07 --> Security Class Initialized
DEBUG - 2019-07-01 15:36:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:36:07 --> Input Class Initialized
INFO - 2019-07-01 15:36:07 --> Language Class Initialized
INFO - 2019-07-01 15:36:07 --> Language Class Initialized
INFO - 2019-07-01 15:36:07 --> Config Class Initialized
INFO - 2019-07-01 15:36:07 --> Loader Class Initialized
DEBUG - 2019-07-01 15:36:07 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:36:07 --> Helper loaded: url_helper
INFO - 2019-07-01 15:36:07 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:36:07 --> Helper loaded: string_helper
INFO - 2019-07-01 15:36:07 --> Helper loaded: array_helper
INFO - 2019-07-01 15:36:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:36:07 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:36:07 --> Database Driver Class Initialized
INFO - 2019-07-01 15:36:07 --> Controller Class Initialized
INFO - 2019-07-01 21:36:07 --> Helper loaded: language_helper
INFO - 2019-07-01 21:36:07 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:36:07 --> Model Class Initialized
INFO - 2019-07-01 21:36:07 --> Model Class Initialized
INFO - 2019-07-01 21:36:07 --> Model Class Initialized
INFO - 2019-07-01 21:36:07 --> Model Class Initialized
INFO - 2019-07-01 21:36:07 --> Helper loaded: form_helper
INFO - 2019-07-01 21:36:08 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:36:08 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:36:08 --> Model Class Initialized
INFO - 2019-07-01 21:36:08 --> Model Class Initialized
INFO - 2019-07-01 21:36:08 --> Final output sent to browser
DEBUG - 2019-07-01 21:36:08 --> Total execution time: 0.9376
INFO - 2019-07-01 15:36:08 --> Config Class Initialized
INFO - 2019-07-01 15:36:08 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:36:08 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:36:08 --> Utf8 Class Initialized
INFO - 2019-07-01 15:36:08 --> URI Class Initialized
INFO - 2019-07-01 15:36:08 --> Router Class Initialized
INFO - 2019-07-01 15:36:08 --> Output Class Initialized
INFO - 2019-07-01 15:36:08 --> Security Class Initialized
DEBUG - 2019-07-01 15:36:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:36:08 --> Input Class Initialized
INFO - 2019-07-01 15:36:08 --> Language Class Initialized
INFO - 2019-07-01 15:36:08 --> Language Class Initialized
INFO - 2019-07-01 15:36:08 --> Config Class Initialized
INFO - 2019-07-01 15:36:08 --> Loader Class Initialized
DEBUG - 2019-07-01 15:36:08 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:36:08 --> Helper loaded: url_helper
INFO - 2019-07-01 15:36:08 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:36:08 --> Helper loaded: string_helper
INFO - 2019-07-01 15:36:08 --> Helper loaded: array_helper
INFO - 2019-07-01 15:36:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:36:08 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:36:08 --> Database Driver Class Initialized
INFO - 2019-07-01 15:36:08 --> Controller Class Initialized
INFO - 2019-07-01 21:36:08 --> Helper loaded: language_helper
INFO - 2019-07-01 21:36:08 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:36:08 --> Model Class Initialized
INFO - 2019-07-01 21:36:08 --> Model Class Initialized
INFO - 2019-07-01 21:36:08 --> Model Class Initialized
INFO - 2019-07-01 21:36:08 --> Model Class Initialized
INFO - 2019-07-01 21:36:08 --> Helper loaded: form_helper
INFO - 2019-07-01 21:36:08 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:36:08 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:36:09 --> Model Class Initialized
INFO - 2019-07-01 21:36:09 --> Model Class Initialized
INFO - 2019-07-01 21:36:09 --> Final output sent to browser
DEBUG - 2019-07-01 21:36:09 --> Total execution time: 0.8590
INFO - 2019-07-01 15:36:14 --> Config Class Initialized
INFO - 2019-07-01 15:36:14 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:36:14 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:36:14 --> Utf8 Class Initialized
INFO - 2019-07-01 15:36:14 --> URI Class Initialized
INFO - 2019-07-01 15:36:15 --> Router Class Initialized
INFO - 2019-07-01 15:36:15 --> Output Class Initialized
INFO - 2019-07-01 15:36:15 --> Security Class Initialized
DEBUG - 2019-07-01 15:36:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:36:15 --> Input Class Initialized
INFO - 2019-07-01 15:36:15 --> Language Class Initialized
INFO - 2019-07-01 15:36:15 --> Language Class Initialized
INFO - 2019-07-01 15:36:15 --> Config Class Initialized
INFO - 2019-07-01 15:36:15 --> Loader Class Initialized
DEBUG - 2019-07-01 15:36:15 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:36:15 --> Helper loaded: url_helper
INFO - 2019-07-01 15:36:15 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:36:15 --> Helper loaded: string_helper
INFO - 2019-07-01 15:36:15 --> Helper loaded: array_helper
INFO - 2019-07-01 15:36:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:36:15 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:36:15 --> Database Driver Class Initialized
INFO - 2019-07-01 15:36:15 --> Controller Class Initialized
INFO - 2019-07-01 21:36:15 --> Helper loaded: language_helper
INFO - 2019-07-01 21:36:15 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:36:15 --> Model Class Initialized
INFO - 2019-07-01 21:36:15 --> Model Class Initialized
INFO - 2019-07-01 21:36:15 --> Model Class Initialized
INFO - 2019-07-01 21:36:15 --> Model Class Initialized
INFO - 2019-07-01 21:36:15 --> Helper loaded: form_helper
INFO - 2019-07-01 21:36:15 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:36:15 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:36:15 --> Model Class Initialized
INFO - 2019-07-01 21:36:15 --> Model Class Initialized
INFO - 2019-07-01 21:36:15 --> Final output sent to browser
DEBUG - 2019-07-01 21:36:15 --> Total execution time: 0.6749
INFO - 2019-07-01 15:36:50 --> Config Class Initialized
INFO - 2019-07-01 15:36:50 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:36:50 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:36:50 --> Utf8 Class Initialized
INFO - 2019-07-01 15:36:50 --> URI Class Initialized
INFO - 2019-07-01 15:36:50 --> Router Class Initialized
INFO - 2019-07-01 15:36:50 --> Output Class Initialized
INFO - 2019-07-01 15:36:50 --> Security Class Initialized
DEBUG - 2019-07-01 15:36:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:36:50 --> Input Class Initialized
INFO - 2019-07-01 15:36:50 --> Language Class Initialized
INFO - 2019-07-01 15:36:50 --> Language Class Initialized
INFO - 2019-07-01 15:36:50 --> Config Class Initialized
INFO - 2019-07-01 15:36:50 --> Loader Class Initialized
DEBUG - 2019-07-01 15:36:50 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:36:50 --> Helper loaded: url_helper
INFO - 2019-07-01 15:36:50 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:36:50 --> Helper loaded: string_helper
INFO - 2019-07-01 15:36:50 --> Helper loaded: array_helper
INFO - 2019-07-01 15:36:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:36:50 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:36:50 --> Database Driver Class Initialized
INFO - 2019-07-01 15:36:50 --> Controller Class Initialized
INFO - 2019-07-01 21:36:51 --> Helper loaded: language_helper
INFO - 2019-07-01 21:36:51 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:36:51 --> Model Class Initialized
INFO - 2019-07-01 21:36:51 --> Model Class Initialized
INFO - 2019-07-01 21:36:51 --> Model Class Initialized
INFO - 2019-07-01 21:36:51 --> Model Class Initialized
INFO - 2019-07-01 21:36:51 --> Helper loaded: form_helper
INFO - 2019-07-01 21:36:51 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:36:51 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:36:51 --> Model Class Initialized
INFO - 2019-07-01 21:36:51 --> Model Class Initialized
INFO - 2019-07-01 21:36:51 --> Final output sent to browser
DEBUG - 2019-07-01 21:36:51 --> Total execution time: 1.1790
INFO - 2019-07-01 15:37:08 --> Config Class Initialized
INFO - 2019-07-01 15:37:08 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:37:08 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:37:08 --> Utf8 Class Initialized
INFO - 2019-07-01 15:37:08 --> URI Class Initialized
INFO - 2019-07-01 15:37:08 --> Router Class Initialized
INFO - 2019-07-01 15:37:08 --> Output Class Initialized
INFO - 2019-07-01 15:37:08 --> Security Class Initialized
DEBUG - 2019-07-01 15:37:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:37:08 --> Input Class Initialized
INFO - 2019-07-01 15:37:08 --> Language Class Initialized
INFO - 2019-07-01 15:37:08 --> Language Class Initialized
INFO - 2019-07-01 15:37:08 --> Config Class Initialized
INFO - 2019-07-01 15:37:08 --> Loader Class Initialized
DEBUG - 2019-07-01 15:37:08 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:37:08 --> Helper loaded: url_helper
INFO - 2019-07-01 15:37:08 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:37:08 --> Helper loaded: string_helper
INFO - 2019-07-01 15:37:08 --> Helper loaded: array_helper
INFO - 2019-07-01 15:37:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:37:08 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:37:08 --> Database Driver Class Initialized
INFO - 2019-07-01 15:37:09 --> Controller Class Initialized
INFO - 2019-07-01 21:37:09 --> Helper loaded: language_helper
INFO - 2019-07-01 21:37:09 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:37:09 --> Model Class Initialized
INFO - 2019-07-01 21:37:09 --> Model Class Initialized
INFO - 2019-07-01 21:37:09 --> Model Class Initialized
INFO - 2019-07-01 21:37:09 --> Model Class Initialized
INFO - 2019-07-01 21:37:09 --> Helper loaded: form_helper
INFO - 2019-07-01 21:37:09 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:37:09 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:37:09 --> Model Class Initialized
INFO - 2019-07-01 21:37:09 --> Model Class Initialized
INFO - 2019-07-01 21:37:09 --> Final output sent to browser
DEBUG - 2019-07-01 21:37:09 --> Total execution time: 0.9058
INFO - 2019-07-01 15:38:46 --> Config Class Initialized
INFO - 2019-07-01 15:38:46 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:38:46 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:38:46 --> Utf8 Class Initialized
INFO - 2019-07-01 15:38:46 --> URI Class Initialized
INFO - 2019-07-01 15:38:46 --> Router Class Initialized
INFO - 2019-07-01 15:38:46 --> Output Class Initialized
INFO - 2019-07-01 15:38:46 --> Security Class Initialized
DEBUG - 2019-07-01 15:38:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:38:46 --> Input Class Initialized
INFO - 2019-07-01 15:38:46 --> Language Class Initialized
INFO - 2019-07-01 15:38:46 --> Language Class Initialized
INFO - 2019-07-01 15:38:46 --> Config Class Initialized
INFO - 2019-07-01 15:38:46 --> Loader Class Initialized
DEBUG - 2019-07-01 15:38:46 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:38:46 --> Helper loaded: url_helper
INFO - 2019-07-01 15:38:46 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:38:46 --> Helper loaded: string_helper
INFO - 2019-07-01 15:38:46 --> Helper loaded: array_helper
INFO - 2019-07-01 15:38:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:38:46 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:38:46 --> Database Driver Class Initialized
INFO - 2019-07-01 15:38:46 --> Controller Class Initialized
INFO - 2019-07-01 21:38:46 --> Helper loaded: language_helper
INFO - 2019-07-01 21:38:46 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:38:46 --> Model Class Initialized
INFO - 2019-07-01 21:38:46 --> Model Class Initialized
INFO - 2019-07-01 21:38:46 --> Model Class Initialized
INFO - 2019-07-01 21:38:46 --> Model Class Initialized
INFO - 2019-07-01 21:38:46 --> Helper loaded: form_helper
INFO - 2019-07-01 21:38:46 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:38:46 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:38:46 --> Model Class Initialized
INFO - 2019-07-01 21:38:47 --> Model Class Initialized
INFO - 2019-07-01 21:38:47 --> Final output sent to browser
DEBUG - 2019-07-01 21:38:47 --> Total execution time: 0.6412
INFO - 2019-07-01 15:43:58 --> Config Class Initialized
INFO - 2019-07-01 15:43:58 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:43:58 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:43:58 --> Utf8 Class Initialized
INFO - 2019-07-01 15:43:58 --> URI Class Initialized
INFO - 2019-07-01 15:43:58 --> Router Class Initialized
INFO - 2019-07-01 15:43:58 --> Output Class Initialized
INFO - 2019-07-01 15:43:58 --> Security Class Initialized
DEBUG - 2019-07-01 15:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:43:58 --> Input Class Initialized
INFO - 2019-07-01 15:43:59 --> Language Class Initialized
INFO - 2019-07-01 15:43:59 --> Language Class Initialized
INFO - 2019-07-01 15:43:59 --> Config Class Initialized
INFO - 2019-07-01 15:43:59 --> Loader Class Initialized
DEBUG - 2019-07-01 15:43:59 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:43:59 --> Helper loaded: url_helper
INFO - 2019-07-01 15:43:59 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:43:59 --> Helper loaded: string_helper
INFO - 2019-07-01 15:43:59 --> Helper loaded: array_helper
INFO - 2019-07-01 15:43:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:43:59 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:43:59 --> Database Driver Class Initialized
INFO - 2019-07-01 15:43:59 --> Controller Class Initialized
INFO - 2019-07-01 21:43:59 --> Helper loaded: language_helper
INFO - 2019-07-01 21:43:59 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:43:59 --> Model Class Initialized
INFO - 2019-07-01 21:43:59 --> Model Class Initialized
INFO - 2019-07-01 21:43:59 --> Model Class Initialized
INFO - 2019-07-01 21:43:59 --> Model Class Initialized
INFO - 2019-07-01 21:43:59 --> Helper loaded: form_helper
INFO - 2019-07-01 21:44:00 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:44:00 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:44:00 --> Model Class Initialized
INFO - 2019-07-01 21:44:00 --> Model Class Initialized
INFO - 2019-07-01 21:44:00 --> Final output sent to browser
DEBUG - 2019-07-01 21:44:00 --> Total execution time: 1.7432
INFO - 2019-07-01 15:44:03 --> Config Class Initialized
INFO - 2019-07-01 15:44:04 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:44:04 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:44:04 --> Utf8 Class Initialized
INFO - 2019-07-01 15:44:04 --> URI Class Initialized
INFO - 2019-07-01 15:44:04 --> Router Class Initialized
INFO - 2019-07-01 15:44:04 --> Output Class Initialized
INFO - 2019-07-01 15:44:04 --> Security Class Initialized
DEBUG - 2019-07-01 15:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:44:04 --> Input Class Initialized
INFO - 2019-07-01 15:44:04 --> Language Class Initialized
INFO - 2019-07-01 15:44:04 --> Language Class Initialized
INFO - 2019-07-01 15:44:04 --> Config Class Initialized
INFO - 2019-07-01 15:44:04 --> Loader Class Initialized
DEBUG - 2019-07-01 15:44:04 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:44:04 --> Helper loaded: url_helper
INFO - 2019-07-01 15:44:04 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:44:04 --> Helper loaded: string_helper
INFO - 2019-07-01 15:44:04 --> Helper loaded: array_helper
INFO - 2019-07-01 15:44:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:44:04 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:44:04 --> Database Driver Class Initialized
INFO - 2019-07-01 15:44:04 --> Controller Class Initialized
INFO - 2019-07-01 21:44:04 --> Helper loaded: language_helper
INFO - 2019-07-01 21:44:04 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:44:04 --> Model Class Initialized
INFO - 2019-07-01 21:44:04 --> Model Class Initialized
INFO - 2019-07-01 21:44:04 --> Model Class Initialized
INFO - 2019-07-01 21:44:04 --> Model Class Initialized
INFO - 2019-07-01 21:44:04 --> Helper loaded: form_helper
INFO - 2019-07-01 21:44:04 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:44:04 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:44:04 --> Model Class Initialized
INFO - 2019-07-01 21:44:05 --> Model Class Initialized
INFO - 2019-07-01 21:44:05 --> Final output sent to browser
DEBUG - 2019-07-01 21:44:05 --> Total execution time: 1.1077
INFO - 2019-07-01 15:44:05 --> Config Class Initialized
INFO - 2019-07-01 15:44:05 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:44:05 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:44:05 --> Utf8 Class Initialized
INFO - 2019-07-01 15:44:05 --> URI Class Initialized
INFO - 2019-07-01 15:44:05 --> Router Class Initialized
INFO - 2019-07-01 15:44:05 --> Output Class Initialized
INFO - 2019-07-01 15:44:05 --> Security Class Initialized
DEBUG - 2019-07-01 15:44:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:44:05 --> Input Class Initialized
INFO - 2019-07-01 15:44:05 --> Language Class Initialized
INFO - 2019-07-01 15:44:05 --> Language Class Initialized
INFO - 2019-07-01 15:44:05 --> Config Class Initialized
INFO - 2019-07-01 15:44:05 --> Loader Class Initialized
DEBUG - 2019-07-01 15:44:05 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:44:05 --> Helper loaded: url_helper
INFO - 2019-07-01 15:44:05 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:44:05 --> Helper loaded: string_helper
INFO - 2019-07-01 15:44:05 --> Helper loaded: array_helper
INFO - 2019-07-01 15:44:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:44:05 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:44:05 --> Database Driver Class Initialized
INFO - 2019-07-01 15:44:05 --> Controller Class Initialized
INFO - 2019-07-01 21:44:05 --> Helper loaded: language_helper
INFO - 2019-07-01 21:44:05 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:44:05 --> Model Class Initialized
INFO - 2019-07-01 21:44:05 --> Model Class Initialized
INFO - 2019-07-01 21:44:05 --> Model Class Initialized
INFO - 2019-07-01 21:44:05 --> Model Class Initialized
INFO - 2019-07-01 21:44:06 --> Helper loaded: form_helper
INFO - 2019-07-01 21:44:06 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:44:06 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:44:06 --> Model Class Initialized
INFO - 2019-07-01 21:44:06 --> Model Class Initialized
INFO - 2019-07-01 21:44:06 --> Final output sent to browser
DEBUG - 2019-07-01 21:44:06 --> Total execution time: 0.9532
INFO - 2019-07-01 15:44:18 --> Config Class Initialized
INFO - 2019-07-01 15:44:18 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:44:18 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:44:18 --> Utf8 Class Initialized
INFO - 2019-07-01 15:44:18 --> URI Class Initialized
INFO - 2019-07-01 15:44:18 --> Router Class Initialized
INFO - 2019-07-01 15:44:18 --> Output Class Initialized
INFO - 2019-07-01 15:44:18 --> Security Class Initialized
DEBUG - 2019-07-01 15:44:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:44:19 --> Input Class Initialized
INFO - 2019-07-01 15:44:19 --> Language Class Initialized
INFO - 2019-07-01 15:44:19 --> Language Class Initialized
INFO - 2019-07-01 15:44:19 --> Config Class Initialized
INFO - 2019-07-01 15:44:19 --> Loader Class Initialized
DEBUG - 2019-07-01 15:44:19 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:44:19 --> Helper loaded: url_helper
INFO - 2019-07-01 15:44:19 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:44:19 --> Helper loaded: string_helper
INFO - 2019-07-01 15:44:19 --> Helper loaded: array_helper
INFO - 2019-07-01 15:44:19 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:44:19 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:44:19 --> Database Driver Class Initialized
INFO - 2019-07-01 15:44:19 --> Controller Class Initialized
INFO - 2019-07-01 21:44:19 --> Helper loaded: language_helper
INFO - 2019-07-01 21:44:19 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:44:19 --> Model Class Initialized
INFO - 2019-07-01 21:44:19 --> Model Class Initialized
INFO - 2019-07-01 21:44:19 --> Model Class Initialized
INFO - 2019-07-01 21:44:19 --> Model Class Initialized
INFO - 2019-07-01 21:44:19 --> Model Class Initialized
INFO - 2019-07-01 21:44:19 --> Final output sent to browser
DEBUG - 2019-07-01 21:44:19 --> Total execution time: 0.9807
INFO - 2019-07-01 15:44:24 --> Config Class Initialized
INFO - 2019-07-01 15:44:24 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:44:24 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:44:24 --> Utf8 Class Initialized
INFO - 2019-07-01 15:44:24 --> URI Class Initialized
INFO - 2019-07-01 15:44:24 --> Router Class Initialized
INFO - 2019-07-01 15:44:24 --> Output Class Initialized
INFO - 2019-07-01 15:44:24 --> Security Class Initialized
DEBUG - 2019-07-01 15:44:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:44:24 --> Input Class Initialized
INFO - 2019-07-01 15:44:25 --> Language Class Initialized
INFO - 2019-07-01 15:44:25 --> Language Class Initialized
INFO - 2019-07-01 15:44:25 --> Config Class Initialized
INFO - 2019-07-01 15:44:25 --> Loader Class Initialized
DEBUG - 2019-07-01 15:44:25 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:44:25 --> Helper loaded: url_helper
INFO - 2019-07-01 15:44:25 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:44:25 --> Helper loaded: string_helper
INFO - 2019-07-01 15:44:25 --> Helper loaded: array_helper
INFO - 2019-07-01 15:44:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:44:25 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:44:25 --> Database Driver Class Initialized
INFO - 2019-07-01 15:44:25 --> Controller Class Initialized
INFO - 2019-07-01 21:44:25 --> Helper loaded: language_helper
INFO - 2019-07-01 21:44:25 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:44:25 --> Model Class Initialized
INFO - 2019-07-01 21:44:25 --> Model Class Initialized
INFO - 2019-07-01 21:44:25 --> Model Class Initialized
INFO - 2019-07-01 21:44:25 --> Model Class Initialized
INFO - 2019-07-01 21:44:25 --> Helper loaded: form_helper
INFO - 2019-07-01 21:44:25 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:44:25 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:44:25 --> Model Class Initialized
INFO - 2019-07-01 21:44:25 --> Model Class Initialized
INFO - 2019-07-01 21:44:25 --> Final output sent to browser
DEBUG - 2019-07-01 21:44:25 --> Total execution time: 1.2119
INFO - 2019-07-01 15:44:25 --> Config Class Initialized
INFO - 2019-07-01 15:44:26 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:44:26 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:44:26 --> Utf8 Class Initialized
INFO - 2019-07-01 15:44:26 --> URI Class Initialized
INFO - 2019-07-01 15:44:26 --> Router Class Initialized
INFO - 2019-07-01 15:44:26 --> Output Class Initialized
INFO - 2019-07-01 15:44:26 --> Security Class Initialized
DEBUG - 2019-07-01 15:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:44:26 --> Input Class Initialized
INFO - 2019-07-01 15:44:26 --> Language Class Initialized
INFO - 2019-07-01 15:44:26 --> Language Class Initialized
INFO - 2019-07-01 15:44:26 --> Config Class Initialized
INFO - 2019-07-01 15:44:26 --> Loader Class Initialized
DEBUG - 2019-07-01 15:44:26 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:44:26 --> Helper loaded: url_helper
INFO - 2019-07-01 15:44:26 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:44:26 --> Helper loaded: string_helper
INFO - 2019-07-01 15:44:26 --> Helper loaded: array_helper
INFO - 2019-07-01 15:44:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:44:26 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:44:26 --> Database Driver Class Initialized
INFO - 2019-07-01 15:44:26 --> Controller Class Initialized
INFO - 2019-07-01 21:44:26 --> Helper loaded: language_helper
INFO - 2019-07-01 21:44:26 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:44:26 --> Model Class Initialized
INFO - 2019-07-01 21:44:26 --> Model Class Initialized
INFO - 2019-07-01 21:44:26 --> Model Class Initialized
INFO - 2019-07-01 21:44:26 --> Model Class Initialized
INFO - 2019-07-01 21:44:26 --> Helper loaded: form_helper
INFO - 2019-07-01 21:44:26 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:44:26 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:44:26 --> Model Class Initialized
INFO - 2019-07-01 21:44:26 --> Model Class Initialized
INFO - 2019-07-01 21:44:26 --> Final output sent to browser
DEBUG - 2019-07-01 21:44:26 --> Total execution time: 0.9584
INFO - 2019-07-01 15:44:48 --> Config Class Initialized
INFO - 2019-07-01 15:44:48 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:44:48 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:44:48 --> Utf8 Class Initialized
INFO - 2019-07-01 15:44:48 --> URI Class Initialized
INFO - 2019-07-01 15:44:48 --> Router Class Initialized
INFO - 2019-07-01 15:44:48 --> Output Class Initialized
INFO - 2019-07-01 15:44:48 --> Security Class Initialized
DEBUG - 2019-07-01 15:44:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:44:48 --> Input Class Initialized
INFO - 2019-07-01 15:44:48 --> Language Class Initialized
INFO - 2019-07-01 15:44:48 --> Language Class Initialized
INFO - 2019-07-01 15:44:48 --> Config Class Initialized
INFO - 2019-07-01 15:44:48 --> Loader Class Initialized
DEBUG - 2019-07-01 15:44:48 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:44:48 --> Helper loaded: url_helper
INFO - 2019-07-01 15:44:48 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:44:48 --> Helper loaded: string_helper
INFO - 2019-07-01 15:44:48 --> Helper loaded: array_helper
INFO - 2019-07-01 15:44:48 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:44:49 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:44:49 --> Database Driver Class Initialized
INFO - 2019-07-01 15:44:49 --> Controller Class Initialized
INFO - 2019-07-01 21:44:49 --> Helper loaded: language_helper
INFO - 2019-07-01 21:44:49 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:44:49 --> Model Class Initialized
INFO - 2019-07-01 21:44:49 --> Model Class Initialized
INFO - 2019-07-01 21:44:49 --> Model Class Initialized
INFO - 2019-07-01 21:44:49 --> Model Class Initialized
INFO - 2019-07-01 21:44:49 --> Model Class Initialized
INFO - 2019-07-01 21:44:49 --> Final output sent to browser
DEBUG - 2019-07-01 21:44:49 --> Total execution time: 0.6174
INFO - 2019-07-01 15:44:59 --> Config Class Initialized
INFO - 2019-07-01 15:44:59 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:44:59 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:44:59 --> Utf8 Class Initialized
INFO - 2019-07-01 15:44:59 --> URI Class Initialized
INFO - 2019-07-01 15:44:59 --> Router Class Initialized
INFO - 2019-07-01 15:44:59 --> Output Class Initialized
INFO - 2019-07-01 15:44:59 --> Security Class Initialized
DEBUG - 2019-07-01 15:44:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:45:00 --> Input Class Initialized
INFO - 2019-07-01 15:45:00 --> Language Class Initialized
INFO - 2019-07-01 15:45:00 --> Language Class Initialized
INFO - 2019-07-01 15:45:00 --> Config Class Initialized
INFO - 2019-07-01 15:45:00 --> Loader Class Initialized
DEBUG - 2019-07-01 15:45:00 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:45:00 --> Helper loaded: url_helper
INFO - 2019-07-01 15:45:00 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:45:00 --> Helper loaded: string_helper
INFO - 2019-07-01 15:45:00 --> Helper loaded: array_helper
INFO - 2019-07-01 15:45:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:45:00 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:45:00 --> Database Driver Class Initialized
INFO - 2019-07-01 15:45:00 --> Controller Class Initialized
INFO - 2019-07-01 21:45:00 --> Helper loaded: language_helper
INFO - 2019-07-01 21:45:00 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:45:00 --> Model Class Initialized
INFO - 2019-07-01 21:45:00 --> Model Class Initialized
INFO - 2019-07-01 21:45:00 --> Model Class Initialized
INFO - 2019-07-01 21:45:00 --> Model Class Initialized
INFO - 2019-07-01 21:45:00 --> Helper loaded: form_helper
INFO - 2019-07-01 21:45:00 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:45:00 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:45:00 --> Model Class Initialized
INFO - 2019-07-01 21:45:00 --> Model Class Initialized
INFO - 2019-07-01 21:45:00 --> Final output sent to browser
DEBUG - 2019-07-01 21:45:00 --> Total execution time: 1.0893
INFO - 2019-07-01 15:45:00 --> Config Class Initialized
INFO - 2019-07-01 15:45:00 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:45:01 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:45:01 --> Utf8 Class Initialized
INFO - 2019-07-01 15:45:01 --> URI Class Initialized
INFO - 2019-07-01 15:45:01 --> Router Class Initialized
INFO - 2019-07-01 15:45:01 --> Output Class Initialized
INFO - 2019-07-01 15:45:01 --> Security Class Initialized
DEBUG - 2019-07-01 15:45:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:45:01 --> Input Class Initialized
INFO - 2019-07-01 15:45:01 --> Language Class Initialized
INFO - 2019-07-01 15:45:01 --> Language Class Initialized
INFO - 2019-07-01 15:45:01 --> Config Class Initialized
INFO - 2019-07-01 15:45:01 --> Loader Class Initialized
DEBUG - 2019-07-01 15:45:01 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:45:01 --> Helper loaded: url_helper
INFO - 2019-07-01 15:45:01 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:45:01 --> Helper loaded: string_helper
INFO - 2019-07-01 15:45:01 --> Helper loaded: array_helper
INFO - 2019-07-01 15:45:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:45:01 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:45:01 --> Database Driver Class Initialized
INFO - 2019-07-01 15:45:01 --> Controller Class Initialized
INFO - 2019-07-01 21:45:01 --> Helper loaded: language_helper
INFO - 2019-07-01 21:45:01 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:45:01 --> Model Class Initialized
INFO - 2019-07-01 21:45:01 --> Model Class Initialized
INFO - 2019-07-01 21:45:01 --> Model Class Initialized
INFO - 2019-07-01 21:45:01 --> Model Class Initialized
INFO - 2019-07-01 21:45:01 --> Helper loaded: form_helper
INFO - 2019-07-01 21:45:01 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:45:01 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:45:01 --> Model Class Initialized
INFO - 2019-07-01 21:45:01 --> Model Class Initialized
INFO - 2019-07-01 21:45:01 --> Final output sent to browser
DEBUG - 2019-07-01 21:45:02 --> Total execution time: 1.0423
INFO - 2019-07-01 15:45:12 --> Config Class Initialized
INFO - 2019-07-01 15:45:12 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:45:12 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:45:13 --> Utf8 Class Initialized
INFO - 2019-07-01 15:45:13 --> URI Class Initialized
INFO - 2019-07-01 15:45:13 --> Router Class Initialized
INFO - 2019-07-01 15:45:13 --> Output Class Initialized
INFO - 2019-07-01 15:45:13 --> Security Class Initialized
DEBUG - 2019-07-01 15:45:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:45:13 --> Input Class Initialized
INFO - 2019-07-01 15:45:13 --> Language Class Initialized
INFO - 2019-07-01 15:45:13 --> Language Class Initialized
INFO - 2019-07-01 15:45:13 --> Config Class Initialized
INFO - 2019-07-01 15:45:13 --> Loader Class Initialized
DEBUG - 2019-07-01 15:45:13 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:45:13 --> Helper loaded: url_helper
INFO - 2019-07-01 15:45:13 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:45:13 --> Helper loaded: string_helper
INFO - 2019-07-01 15:45:13 --> Helper loaded: array_helper
INFO - 2019-07-01 15:45:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:45:13 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:45:13 --> Database Driver Class Initialized
INFO - 2019-07-01 15:45:13 --> Controller Class Initialized
INFO - 2019-07-01 21:45:13 --> Helper loaded: language_helper
INFO - 2019-07-01 21:45:13 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:45:13 --> Model Class Initialized
INFO - 2019-07-01 21:45:13 --> Model Class Initialized
INFO - 2019-07-01 21:45:13 --> Model Class Initialized
INFO - 2019-07-01 21:45:13 --> Model Class Initialized
INFO - 2019-07-01 21:45:13 --> Helper loaded: form_helper
INFO - 2019-07-01 21:45:13 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:45:13 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:45:13 --> Model Class Initialized
INFO - 2019-07-01 21:45:13 --> Model Class Initialized
INFO - 2019-07-01 21:45:13 --> Final output sent to browser
DEBUG - 2019-07-01 21:45:13 --> Total execution time: 0.7696
INFO - 2019-07-01 15:45:14 --> Config Class Initialized
INFO - 2019-07-01 15:45:14 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:45:14 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:45:14 --> Utf8 Class Initialized
INFO - 2019-07-01 15:45:14 --> URI Class Initialized
INFO - 2019-07-01 15:45:14 --> Router Class Initialized
INFO - 2019-07-01 15:45:14 --> Output Class Initialized
INFO - 2019-07-01 15:45:14 --> Security Class Initialized
DEBUG - 2019-07-01 15:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:45:14 --> Input Class Initialized
INFO - 2019-07-01 15:45:14 --> Language Class Initialized
INFO - 2019-07-01 15:45:14 --> Language Class Initialized
INFO - 2019-07-01 15:45:14 --> Config Class Initialized
INFO - 2019-07-01 15:45:14 --> Loader Class Initialized
DEBUG - 2019-07-01 15:45:14 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:45:14 --> Helper loaded: url_helper
INFO - 2019-07-01 15:45:14 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:45:14 --> Helper loaded: string_helper
INFO - 2019-07-01 15:45:14 --> Helper loaded: array_helper
INFO - 2019-07-01 15:45:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:45:14 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:45:14 --> Database Driver Class Initialized
INFO - 2019-07-01 15:45:14 --> Controller Class Initialized
INFO - 2019-07-01 21:45:14 --> Helper loaded: language_helper
INFO - 2019-07-01 21:45:14 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:45:14 --> Model Class Initialized
INFO - 2019-07-01 21:45:14 --> Model Class Initialized
INFO - 2019-07-01 21:45:14 --> Model Class Initialized
INFO - 2019-07-01 21:45:14 --> Model Class Initialized
INFO - 2019-07-01 21:45:14 --> Model Class Initialized
INFO - 2019-07-01 21:45:14 --> Final output sent to browser
DEBUG - 2019-07-01 21:45:14 --> Total execution time: 0.5266
INFO - 2019-07-01 15:45:21 --> Config Class Initialized
INFO - 2019-07-01 15:45:21 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:45:21 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:45:21 --> Utf8 Class Initialized
INFO - 2019-07-01 15:45:21 --> URI Class Initialized
INFO - 2019-07-01 15:45:21 --> Router Class Initialized
INFO - 2019-07-01 15:45:21 --> Output Class Initialized
INFO - 2019-07-01 15:45:21 --> Security Class Initialized
DEBUG - 2019-07-01 15:45:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:45:21 --> Input Class Initialized
INFO - 2019-07-01 15:45:21 --> Language Class Initialized
INFO - 2019-07-01 15:45:21 --> Language Class Initialized
INFO - 2019-07-01 15:45:21 --> Config Class Initialized
INFO - 2019-07-01 15:45:21 --> Loader Class Initialized
DEBUG - 2019-07-01 15:45:21 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:45:21 --> Helper loaded: url_helper
INFO - 2019-07-01 15:45:21 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:45:21 --> Helper loaded: string_helper
INFO - 2019-07-01 15:45:21 --> Helper loaded: array_helper
INFO - 2019-07-01 15:45:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:45:21 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:45:21 --> Database Driver Class Initialized
INFO - 2019-07-01 15:45:21 --> Controller Class Initialized
INFO - 2019-07-01 21:45:21 --> Helper loaded: language_helper
INFO - 2019-07-01 21:45:21 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:45:21 --> Model Class Initialized
INFO - 2019-07-01 21:45:22 --> Model Class Initialized
INFO - 2019-07-01 21:45:22 --> Model Class Initialized
INFO - 2019-07-01 21:45:22 --> Model Class Initialized
INFO - 2019-07-01 21:45:22 --> Helper loaded: form_helper
INFO - 2019-07-01 21:45:22 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:45:22 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:45:22 --> Model Class Initialized
INFO - 2019-07-01 21:45:22 --> Model Class Initialized
INFO - 2019-07-01 21:45:22 --> Final output sent to browser
DEBUG - 2019-07-01 21:45:22 --> Total execution time: 1.2256
INFO - 2019-07-01 15:45:22 --> Config Class Initialized
INFO - 2019-07-01 15:45:22 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:45:22 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:45:22 --> Utf8 Class Initialized
INFO - 2019-07-01 15:45:22 --> URI Class Initialized
INFO - 2019-07-01 15:45:22 --> Router Class Initialized
INFO - 2019-07-01 15:45:22 --> Output Class Initialized
INFO - 2019-07-01 15:45:22 --> Security Class Initialized
DEBUG - 2019-07-01 15:45:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:45:22 --> Input Class Initialized
INFO - 2019-07-01 15:45:22 --> Language Class Initialized
INFO - 2019-07-01 15:45:22 --> Language Class Initialized
INFO - 2019-07-01 15:45:22 --> Config Class Initialized
INFO - 2019-07-01 15:45:22 --> Loader Class Initialized
DEBUG - 2019-07-01 15:45:22 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:45:23 --> Helper loaded: url_helper
INFO - 2019-07-01 15:45:23 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:45:23 --> Helper loaded: string_helper
INFO - 2019-07-01 15:45:23 --> Helper loaded: array_helper
INFO - 2019-07-01 15:45:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:45:23 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:45:23 --> Database Driver Class Initialized
INFO - 2019-07-01 15:45:23 --> Controller Class Initialized
INFO - 2019-07-01 21:45:23 --> Helper loaded: language_helper
INFO - 2019-07-01 21:45:23 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:45:23 --> Model Class Initialized
INFO - 2019-07-01 21:45:23 --> Model Class Initialized
INFO - 2019-07-01 21:45:23 --> Model Class Initialized
INFO - 2019-07-01 21:45:23 --> Model Class Initialized
INFO - 2019-07-01 21:45:23 --> Helper loaded: form_helper
INFO - 2019-07-01 21:45:23 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:45:23 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:45:23 --> Model Class Initialized
INFO - 2019-07-01 21:45:23 --> Model Class Initialized
INFO - 2019-07-01 21:45:23 --> Final output sent to browser
DEBUG - 2019-07-01 21:45:23 --> Total execution time: 1.2182
INFO - 2019-07-01 15:46:19 --> Config Class Initialized
INFO - 2019-07-01 15:46:19 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:46:19 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:46:19 --> Utf8 Class Initialized
INFO - 2019-07-01 15:46:19 --> URI Class Initialized
INFO - 2019-07-01 15:46:19 --> Router Class Initialized
INFO - 2019-07-01 15:46:19 --> Output Class Initialized
INFO - 2019-07-01 15:46:19 --> Security Class Initialized
DEBUG - 2019-07-01 15:46:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:46:19 --> Input Class Initialized
INFO - 2019-07-01 15:46:19 --> Language Class Initialized
INFO - 2019-07-01 15:46:19 --> Language Class Initialized
INFO - 2019-07-01 15:46:19 --> Config Class Initialized
INFO - 2019-07-01 15:46:19 --> Loader Class Initialized
DEBUG - 2019-07-01 15:46:20 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:46:20 --> Helper loaded: url_helper
INFO - 2019-07-01 15:46:20 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:46:20 --> Helper loaded: string_helper
INFO - 2019-07-01 15:46:20 --> Helper loaded: array_helper
INFO - 2019-07-01 15:46:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:46:20 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:46:20 --> Database Driver Class Initialized
INFO - 2019-07-01 15:46:20 --> Controller Class Initialized
INFO - 2019-07-01 21:46:20 --> Helper loaded: language_helper
INFO - 2019-07-01 21:46:20 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:46:20 --> Model Class Initialized
INFO - 2019-07-01 21:46:20 --> Model Class Initialized
INFO - 2019-07-01 21:46:20 --> Model Class Initialized
INFO - 2019-07-01 21:46:20 --> Model Class Initialized
INFO - 2019-07-01 21:46:20 --> Helper loaded: form_helper
INFO - 2019-07-01 21:46:20 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:46:20 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:46:20 --> Model Class Initialized
INFO - 2019-07-01 21:46:20 --> Model Class Initialized
ERROR - 2019-07-01 21:46:20 --> Query error: Unknown column 'order_details.status' in 'field list' - Invalid query: SELECT `orders`.*, `order_details`.`qty`, `order_details`.`price`, `order_details`.`sub_total`, `order_details`.`status`, `order_details`.`product_id`, `order_details`.`created_at` AS `order_date`, `products`.`name`, CONCAT(`customers`.`firstname`, " ", `customers`.`lastname`) AS customer_fullname, `customers`.`address`, `customers`.`contact_number`, `customers`.`email`
FROM `orders`
LEFT JOIN `order_details` ON `order_details`.`order_id` = `orders`.`id`
LEFT JOIN `products` ON `products`.`id` = `order_details`.`product_id`
INNER JOIN `customers` as `customers` ON `customers`.`id` = `orders`.`customer_id`
WHERE `customer_id` = '1'
AND `resto_id` = '2'
AND `order_status` = 'pending'
INFO - 2019-07-01 21:46:20 --> Language file loaded: language/english/db_lang.php
INFO - 2019-07-01 15:46:38 --> Config Class Initialized
INFO - 2019-07-01 15:46:38 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:46:38 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:46:38 --> Utf8 Class Initialized
INFO - 2019-07-01 15:46:38 --> URI Class Initialized
INFO - 2019-07-01 15:46:38 --> Router Class Initialized
INFO - 2019-07-01 15:46:38 --> Output Class Initialized
INFO - 2019-07-01 15:46:38 --> Security Class Initialized
DEBUG - 2019-07-01 15:46:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:46:38 --> Input Class Initialized
INFO - 2019-07-01 15:46:38 --> Language Class Initialized
INFO - 2019-07-01 15:46:38 --> Language Class Initialized
INFO - 2019-07-01 15:46:38 --> Config Class Initialized
INFO - 2019-07-01 15:46:38 --> Loader Class Initialized
DEBUG - 2019-07-01 15:46:38 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:46:38 --> Helper loaded: url_helper
INFO - 2019-07-01 15:46:38 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:46:38 --> Helper loaded: string_helper
INFO - 2019-07-01 15:46:38 --> Helper loaded: array_helper
INFO - 2019-07-01 15:46:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:46:38 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:46:38 --> Database Driver Class Initialized
INFO - 2019-07-01 15:46:38 --> Controller Class Initialized
INFO - 2019-07-01 21:46:38 --> Helper loaded: language_helper
INFO - 2019-07-01 21:46:38 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:46:38 --> Model Class Initialized
INFO - 2019-07-01 21:46:38 --> Model Class Initialized
INFO - 2019-07-01 21:46:38 --> Model Class Initialized
INFO - 2019-07-01 21:46:38 --> Model Class Initialized
INFO - 2019-07-01 21:46:38 --> Helper loaded: form_helper
INFO - 2019-07-01 21:46:38 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:46:38 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:46:38 --> Model Class Initialized
INFO - 2019-07-01 21:46:38 --> Model Class Initialized
ERROR - 2019-07-01 21:46:39 --> Query error: Column 'resto_id' in where clause is ambiguous - Invalid query: SELECT `orders`.*, `order_details`.`qty`, `order_details`.`price`, `order_details`.`sub_total`, `order_details`.`order_status`, `order_details`.`product_id`, `order_details`.`created_at` AS `order_date`, `products`.`name`, CONCAT(`customers`.`firstname`, " ", `customers`.`lastname`) AS customer_fullname, `customers`.`address`, `customers`.`contact_number`, `customers`.`email`
FROM `orders`
LEFT JOIN `order_details` ON `order_details`.`order_id` = `orders`.`id`
LEFT JOIN `products` ON `products`.`id` = `order_details`.`product_id`
INNER JOIN `customers` as `customers` ON `customers`.`id` = `orders`.`customer_id`
WHERE `customer_id` = '1'
AND `resto_id` = '2'
AND `order_status` = 'pending'
INFO - 2019-07-01 21:46:39 --> Language file loaded: language/english/db_lang.php
INFO - 2019-07-01 15:46:42 --> Config Class Initialized
INFO - 2019-07-01 15:46:42 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:46:42 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:46:42 --> Utf8 Class Initialized
INFO - 2019-07-01 15:46:42 --> URI Class Initialized
INFO - 2019-07-01 15:46:42 --> Router Class Initialized
INFO - 2019-07-01 15:46:42 --> Output Class Initialized
INFO - 2019-07-01 15:46:42 --> Security Class Initialized
DEBUG - 2019-07-01 15:46:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:46:42 --> Input Class Initialized
INFO - 2019-07-01 15:46:42 --> Language Class Initialized
INFO - 2019-07-01 15:46:42 --> Language Class Initialized
INFO - 2019-07-01 15:46:42 --> Config Class Initialized
INFO - 2019-07-01 15:46:42 --> Loader Class Initialized
DEBUG - 2019-07-01 15:46:42 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:46:42 --> Helper loaded: url_helper
INFO - 2019-07-01 15:46:42 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:46:43 --> Helper loaded: string_helper
INFO - 2019-07-01 15:46:43 --> Helper loaded: array_helper
INFO - 2019-07-01 15:46:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:46:43 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:46:43 --> Database Driver Class Initialized
INFO - 2019-07-01 15:46:43 --> Controller Class Initialized
INFO - 2019-07-01 21:46:43 --> Helper loaded: language_helper
INFO - 2019-07-01 21:46:43 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:46:43 --> Model Class Initialized
INFO - 2019-07-01 21:46:43 --> Model Class Initialized
INFO - 2019-07-01 21:46:43 --> Model Class Initialized
INFO - 2019-07-01 21:46:43 --> Model Class Initialized
INFO - 2019-07-01 21:46:43 --> Helper loaded: form_helper
INFO - 2019-07-01 21:46:43 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:46:43 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:46:43 --> Model Class Initialized
INFO - 2019-07-01 21:46:43 --> Model Class Initialized
ERROR - 2019-07-01 21:46:43 --> Query error: Column 'resto_id' in where clause is ambiguous - Invalid query: SELECT `orders`.*, `order_details`.`qty`, `order_details`.`price`, `order_details`.`sub_total`, `order_details`.`order_status`, `order_details`.`product_id`, `order_details`.`created_at` AS `order_date`, `products`.`name`, CONCAT(`customers`.`firstname`, " ", `customers`.`lastname`) AS customer_fullname, `customers`.`address`, `customers`.`contact_number`, `customers`.`email`
FROM `orders`
LEFT JOIN `order_details` ON `order_details`.`order_id` = `orders`.`id`
LEFT JOIN `products` ON `products`.`id` = `order_details`.`product_id`
INNER JOIN `customers` as `customers` ON `customers`.`id` = `orders`.`customer_id`
WHERE `customer_id` = '1'
AND `resto_id` = '2'
AND `order_status` = 'pending'
INFO - 2019-07-01 21:46:43 --> Language file loaded: language/english/db_lang.php
INFO - 2019-07-01 15:47:44 --> Config Class Initialized
INFO - 2019-07-01 15:47:44 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:47:44 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:47:44 --> Utf8 Class Initialized
INFO - 2019-07-01 15:47:44 --> URI Class Initialized
INFO - 2019-07-01 15:47:44 --> Router Class Initialized
INFO - 2019-07-01 15:47:44 --> Output Class Initialized
INFO - 2019-07-01 15:47:44 --> Security Class Initialized
DEBUG - 2019-07-01 15:47:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:47:44 --> Input Class Initialized
INFO - 2019-07-01 15:47:44 --> Language Class Initialized
INFO - 2019-07-01 15:47:44 --> Language Class Initialized
INFO - 2019-07-01 15:47:44 --> Config Class Initialized
INFO - 2019-07-01 15:47:44 --> Loader Class Initialized
DEBUG - 2019-07-01 15:47:44 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:47:44 --> Helper loaded: url_helper
INFO - 2019-07-01 15:47:44 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:47:44 --> Helper loaded: string_helper
INFO - 2019-07-01 15:47:44 --> Helper loaded: array_helper
INFO - 2019-07-01 15:47:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:47:44 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:47:44 --> Database Driver Class Initialized
INFO - 2019-07-01 15:47:44 --> Controller Class Initialized
INFO - 2019-07-01 21:47:44 --> Helper loaded: language_helper
INFO - 2019-07-01 21:47:44 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:47:44 --> Model Class Initialized
INFO - 2019-07-01 21:47:44 --> Model Class Initialized
INFO - 2019-07-01 21:47:44 --> Model Class Initialized
INFO - 2019-07-01 21:47:44 --> Model Class Initialized
INFO - 2019-07-01 21:47:44 --> Helper loaded: form_helper
INFO - 2019-07-01 21:47:44 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:47:44 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:47:44 --> Model Class Initialized
INFO - 2019-07-01 21:47:44 --> Model Class Initialized
ERROR - 2019-07-01 21:47:44 --> Query error: Column 'resto_id' in where clause is ambiguous - Invalid query: SELECT `orders`.*, `order_details`.`qty`, `order_details`.`price`, `order_details`.`resto_id`, `order_details`.`sub_total`, `order_details`.`order_status`, `order_details`.`product_id`, `order_details`.`created_at` AS `order_date`, `products`.`name`, CONCAT(`customers`.`firstname`, " ", `customers`.`lastname`) AS customer_fullname, `customers`.`address`, `customers`.`contact_number`, `customers`.`email`
FROM `orders`
LEFT JOIN `order_details` ON `order_details`.`order_id` = `orders`.`id`
LEFT JOIN `products` ON `products`.`resto_id` = `order_details`.`resto_id`
INNER JOIN `customers` as `customers` ON `customers`.`id` = `orders`.`customer_id`
WHERE `customer_id` = '1'
AND `resto_id` = '2'
AND `order_status` = 'pending'
INFO - 2019-07-01 21:47:44 --> Language file loaded: language/english/db_lang.php
INFO - 2019-07-01 15:48:23 --> Config Class Initialized
INFO - 2019-07-01 15:48:23 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:48:23 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:48:23 --> Utf8 Class Initialized
INFO - 2019-07-01 15:48:24 --> URI Class Initialized
INFO - 2019-07-01 15:48:24 --> Router Class Initialized
INFO - 2019-07-01 15:48:24 --> Output Class Initialized
INFO - 2019-07-01 15:48:24 --> Security Class Initialized
DEBUG - 2019-07-01 15:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:48:24 --> Input Class Initialized
INFO - 2019-07-01 15:48:24 --> Language Class Initialized
INFO - 2019-07-01 15:48:24 --> Language Class Initialized
INFO - 2019-07-01 15:48:24 --> Config Class Initialized
INFO - 2019-07-01 15:48:24 --> Loader Class Initialized
DEBUG - 2019-07-01 15:48:24 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:48:24 --> Helper loaded: url_helper
INFO - 2019-07-01 15:48:24 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:48:24 --> Helper loaded: string_helper
INFO - 2019-07-01 15:48:24 --> Helper loaded: array_helper
INFO - 2019-07-01 15:48:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:48:24 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:48:24 --> Database Driver Class Initialized
INFO - 2019-07-01 15:48:24 --> Controller Class Initialized
INFO - 2019-07-01 21:48:24 --> Helper loaded: language_helper
INFO - 2019-07-01 21:48:24 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:48:24 --> Model Class Initialized
INFO - 2019-07-01 21:48:24 --> Model Class Initialized
INFO - 2019-07-01 21:48:24 --> Model Class Initialized
INFO - 2019-07-01 21:48:24 --> Model Class Initialized
INFO - 2019-07-01 21:48:25 --> Helper loaded: form_helper
INFO - 2019-07-01 21:48:25 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:48:25 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:48:25 --> Model Class Initialized
INFO - 2019-07-01 21:48:25 --> Model Class Initialized
ERROR - 2019-07-01 21:48:25 --> Query error: Column 'resto_id' in where clause is ambiguous - Invalid query: SELECT `orders`.*, `order_details`.`qty`, `order_details`.`price`, `order_details`.`resto_id`, `order_details`.`sub_total`, `order_details`.`order_status`, `order_details`.`product_id`, `order_details`.`created_at` AS `order_date`, `products`.`name`, CONCAT(`customers`.`firstname`, " ", `customers`.`lastname`) AS customer_fullname, `customers`.`address`, `customers`.`contact_number`, `customers`.`email`
FROM `orders`
LEFT JOIN `order_details` ON `order_details`.`order_id` = `orders`.`id`
LEFT JOIN `products` ON `products`.`resto_id` = `order_details`.`resto_id`
INNER JOIN `customers` as `customers` ON `customers`.`id` = `orders`.`customer_id`
WHERE `customer_id` = '1'
AND `resto_id` = '2'
AND `order_status` = 'pending'
INFO - 2019-07-01 21:48:25 --> Language file loaded: language/english/db_lang.php
INFO - 2019-07-01 15:48:28 --> Config Class Initialized
INFO - 2019-07-01 15:48:28 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:48:28 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:48:28 --> Utf8 Class Initialized
INFO - 2019-07-01 15:48:28 --> URI Class Initialized
INFO - 2019-07-01 15:48:28 --> Router Class Initialized
INFO - 2019-07-01 15:48:28 --> Output Class Initialized
INFO - 2019-07-01 15:48:28 --> Security Class Initialized
DEBUG - 2019-07-01 15:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:48:28 --> Input Class Initialized
INFO - 2019-07-01 15:48:28 --> Language Class Initialized
INFO - 2019-07-01 15:48:28 --> Language Class Initialized
INFO - 2019-07-01 15:48:28 --> Config Class Initialized
INFO - 2019-07-01 15:48:28 --> Loader Class Initialized
DEBUG - 2019-07-01 15:48:29 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:48:29 --> Helper loaded: url_helper
INFO - 2019-07-01 15:48:29 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:48:29 --> Helper loaded: string_helper
INFO - 2019-07-01 15:48:29 --> Helper loaded: array_helper
INFO - 2019-07-01 15:48:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:48:29 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:48:29 --> Database Driver Class Initialized
INFO - 2019-07-01 15:48:29 --> Controller Class Initialized
INFO - 2019-07-01 21:48:29 --> Helper loaded: language_helper
INFO - 2019-07-01 21:48:29 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:48:29 --> Model Class Initialized
INFO - 2019-07-01 21:48:29 --> Model Class Initialized
INFO - 2019-07-01 21:48:29 --> Model Class Initialized
INFO - 2019-07-01 21:48:29 --> Model Class Initialized
INFO - 2019-07-01 21:48:29 --> Helper loaded: form_helper
INFO - 2019-07-01 21:48:29 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:48:29 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:48:29 --> Model Class Initialized
INFO - 2019-07-01 21:48:29 --> Model Class Initialized
ERROR - 2019-07-01 21:48:29 --> Query error: Column 'resto_id' in where clause is ambiguous - Invalid query: SELECT `orders`.*, `order_details`.`qty`, `order_details`.`price`, `order_details`.`resto_id`, `order_details`.`sub_total`, `order_details`.`order_status`, `order_details`.`product_id`, `order_details`.`created_at` AS `order_date`, `products`.`name`, CONCAT(`customers`.`firstname`, " ", `customers`.`lastname`) AS customer_fullname, `customers`.`address`, `customers`.`contact_number`, `customers`.`email`
FROM `orders`
LEFT JOIN `order_details` ON `order_details`.`order_id` = `orders`.`id`
LEFT JOIN `products` ON `products`.`resto_id` = `order_details`.`resto_id`
INNER JOIN `customers` as `customers` ON `customers`.`id` = `orders`.`customer_id`
WHERE `customer_id` = '1'
AND `resto_id` = '2'
AND `order_status` = 'pending'
INFO - 2019-07-01 21:48:29 --> Language file loaded: language/english/db_lang.php
INFO - 2019-07-01 15:48:30 --> Config Class Initialized
INFO - 2019-07-01 15:48:30 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:48:30 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:48:30 --> Utf8 Class Initialized
INFO - 2019-07-01 15:48:30 --> URI Class Initialized
INFO - 2019-07-01 15:48:30 --> Router Class Initialized
INFO - 2019-07-01 15:48:31 --> Output Class Initialized
INFO - 2019-07-01 15:48:31 --> Security Class Initialized
DEBUG - 2019-07-01 15:48:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:48:31 --> Input Class Initialized
INFO - 2019-07-01 15:48:31 --> Language Class Initialized
INFO - 2019-07-01 15:48:31 --> Language Class Initialized
INFO - 2019-07-01 15:48:31 --> Config Class Initialized
INFO - 2019-07-01 15:48:31 --> Loader Class Initialized
DEBUG - 2019-07-01 15:48:31 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:48:31 --> Helper loaded: url_helper
INFO - 2019-07-01 15:48:31 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:48:31 --> Helper loaded: string_helper
INFO - 2019-07-01 15:48:31 --> Helper loaded: array_helper
INFO - 2019-07-01 15:48:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:48:31 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:48:31 --> Database Driver Class Initialized
INFO - 2019-07-01 15:48:31 --> Controller Class Initialized
INFO - 2019-07-01 21:48:31 --> Helper loaded: language_helper
INFO - 2019-07-01 21:48:31 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:48:31 --> Model Class Initialized
INFO - 2019-07-01 21:48:31 --> Model Class Initialized
INFO - 2019-07-01 21:48:31 --> Model Class Initialized
INFO - 2019-07-01 21:48:31 --> Model Class Initialized
INFO - 2019-07-01 21:48:31 --> Model Class Initialized
INFO - 2019-07-01 21:48:31 --> Final output sent to browser
DEBUG - 2019-07-01 21:48:31 --> Total execution time: 1.0153
INFO - 2019-07-01 15:48:37 --> Config Class Initialized
INFO - 2019-07-01 15:48:37 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:48:37 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:48:37 --> Utf8 Class Initialized
INFO - 2019-07-01 15:48:37 --> URI Class Initialized
INFO - 2019-07-01 15:48:37 --> Router Class Initialized
INFO - 2019-07-01 15:48:37 --> Output Class Initialized
INFO - 2019-07-01 15:48:37 --> Security Class Initialized
DEBUG - 2019-07-01 15:48:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:48:37 --> Input Class Initialized
INFO - 2019-07-01 15:48:37 --> Language Class Initialized
INFO - 2019-07-01 15:48:37 --> Language Class Initialized
INFO - 2019-07-01 15:48:37 --> Config Class Initialized
INFO - 2019-07-01 15:48:37 --> Loader Class Initialized
DEBUG - 2019-07-01 15:48:37 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:48:37 --> Helper loaded: url_helper
INFO - 2019-07-01 15:48:37 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:48:37 --> Helper loaded: string_helper
INFO - 2019-07-01 15:48:37 --> Helper loaded: array_helper
INFO - 2019-07-01 15:48:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:48:37 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:48:37 --> Database Driver Class Initialized
INFO - 2019-07-01 15:48:37 --> Controller Class Initialized
INFO - 2019-07-01 21:48:37 --> Helper loaded: language_helper
INFO - 2019-07-01 21:48:38 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:48:38 --> Model Class Initialized
INFO - 2019-07-01 21:48:38 --> Model Class Initialized
INFO - 2019-07-01 21:48:38 --> Model Class Initialized
INFO - 2019-07-01 21:48:38 --> Model Class Initialized
INFO - 2019-07-01 21:48:38 --> Helper loaded: form_helper
INFO - 2019-07-01 21:48:38 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:48:38 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:48:38 --> Model Class Initialized
INFO - 2019-07-01 21:48:38 --> Model Class Initialized
ERROR - 2019-07-01 21:48:38 --> Query error: Column 'resto_id' in where clause is ambiguous - Invalid query: SELECT `orders`.*, `order_details`.`qty`, `order_details`.`price`, `order_details`.`resto_id`, `order_details`.`sub_total`, `order_details`.`order_status`, `order_details`.`product_id`, `order_details`.`created_at` AS `order_date`, `products`.`name`, CONCAT(`customers`.`firstname`, " ", `customers`.`lastname`) AS customer_fullname, `customers`.`address`, `customers`.`contact_number`, `customers`.`email`
FROM `orders`
LEFT JOIN `order_details` ON `order_details`.`order_id` = `orders`.`id`
LEFT JOIN `products` ON `products`.`resto_id` = `order_details`.`resto_id`
INNER JOIN `customers` as `customers` ON `customers`.`id` = `orders`.`customer_id`
WHERE `resto_id` = '2'
AND `customer_id` = '1'
AND `order_status` = 'pending'
INFO - 2019-07-01 21:48:38 --> Language file loaded: language/english/db_lang.php
INFO - 2019-07-01 15:48:38 --> Config Class Initialized
INFO - 2019-07-01 15:48:38 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:48:38 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:48:38 --> Utf8 Class Initialized
INFO - 2019-07-01 15:48:38 --> URI Class Initialized
INFO - 2019-07-01 15:48:38 --> Router Class Initialized
INFO - 2019-07-01 15:48:38 --> Output Class Initialized
INFO - 2019-07-01 15:48:38 --> Security Class Initialized
DEBUG - 2019-07-01 15:48:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:48:38 --> Input Class Initialized
INFO - 2019-07-01 15:48:38 --> Language Class Initialized
INFO - 2019-07-01 15:48:38 --> Language Class Initialized
INFO - 2019-07-01 15:48:38 --> Config Class Initialized
INFO - 2019-07-01 15:48:38 --> Loader Class Initialized
DEBUG - 2019-07-01 15:48:38 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:48:38 --> Helper loaded: url_helper
INFO - 2019-07-01 15:48:38 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:48:38 --> Helper loaded: string_helper
INFO - 2019-07-01 15:48:38 --> Helper loaded: array_helper
INFO - 2019-07-01 15:48:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:48:38 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:48:38 --> Database Driver Class Initialized
INFO - 2019-07-01 15:48:38 --> Controller Class Initialized
INFO - 2019-07-01 21:48:38 --> Helper loaded: language_helper
INFO - 2019-07-01 21:48:38 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:48:38 --> Model Class Initialized
INFO - 2019-07-01 21:48:38 --> Model Class Initialized
INFO - 2019-07-01 21:48:38 --> Model Class Initialized
INFO - 2019-07-01 21:48:39 --> Model Class Initialized
INFO - 2019-07-01 21:48:39 --> Helper loaded: form_helper
INFO - 2019-07-01 21:48:39 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:48:39 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:48:39 --> Model Class Initialized
INFO - 2019-07-01 21:48:39 --> Model Class Initialized
ERROR - 2019-07-01 21:48:39 --> Query error: Column 'resto_id' in where clause is ambiguous - Invalid query: SELECT `orders`.*, `order_details`.`qty`, `order_details`.`price`, `order_details`.`resto_id`, `order_details`.`sub_total`, `order_details`.`order_status`, `order_details`.`product_id`, `order_details`.`created_at` AS `order_date`, `products`.`name`, CONCAT(`customers`.`firstname`, " ", `customers`.`lastname`) AS customer_fullname, `customers`.`address`, `customers`.`contact_number`, `customers`.`email`
FROM `orders`
LEFT JOIN `order_details` ON `order_details`.`order_id` = `orders`.`id`
LEFT JOIN `products` ON `products`.`resto_id` = `order_details`.`resto_id`
INNER JOIN `customers` as `customers` ON `customers`.`id` = `orders`.`customer_id`
WHERE `customer_id` = '1'
AND `resto_id` = '2'
AND `order_status` = 'pending'
INFO - 2019-07-01 21:48:39 --> Language file loaded: language/english/db_lang.php
INFO - 2019-07-01 15:50:11 --> Config Class Initialized
INFO - 2019-07-01 15:50:11 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:50:11 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:50:11 --> Utf8 Class Initialized
INFO - 2019-07-01 15:50:11 --> URI Class Initialized
INFO - 2019-07-01 15:50:11 --> Router Class Initialized
INFO - 2019-07-01 15:50:11 --> Output Class Initialized
INFO - 2019-07-01 15:50:11 --> Security Class Initialized
DEBUG - 2019-07-01 15:50:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:50:11 --> Input Class Initialized
INFO - 2019-07-01 15:50:11 --> Language Class Initialized
INFO - 2019-07-01 15:50:11 --> Language Class Initialized
INFO - 2019-07-01 15:50:11 --> Config Class Initialized
INFO - 2019-07-01 15:50:11 --> Loader Class Initialized
DEBUG - 2019-07-01 15:50:11 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:50:11 --> Helper loaded: url_helper
INFO - 2019-07-01 15:50:11 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:50:11 --> Helper loaded: string_helper
INFO - 2019-07-01 15:50:11 --> Helper loaded: array_helper
INFO - 2019-07-01 15:50:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:50:11 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:50:11 --> Database Driver Class Initialized
INFO - 2019-07-01 15:50:11 --> Controller Class Initialized
INFO - 2019-07-01 21:50:11 --> Helper loaded: language_helper
INFO - 2019-07-01 21:50:11 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:50:11 --> Model Class Initialized
INFO - 2019-07-01 21:50:11 --> Model Class Initialized
INFO - 2019-07-01 21:50:11 --> Model Class Initialized
INFO - 2019-07-01 21:50:12 --> Model Class Initialized
INFO - 2019-07-01 21:50:12 --> Helper loaded: form_helper
INFO - 2019-07-01 21:50:12 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:50:12 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:50:12 --> Model Class Initialized
INFO - 2019-07-01 21:50:12 --> Model Class Initialized
INFO - 2019-07-01 21:50:12 --> Final output sent to browser
DEBUG - 2019-07-01 21:50:12 --> Total execution time: 1.0807
INFO - 2019-07-01 15:50:16 --> Config Class Initialized
INFO - 2019-07-01 15:50:16 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:50:16 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:50:16 --> Utf8 Class Initialized
INFO - 2019-07-01 15:50:16 --> URI Class Initialized
INFO - 2019-07-01 15:50:16 --> Router Class Initialized
INFO - 2019-07-01 15:50:16 --> Output Class Initialized
INFO - 2019-07-01 15:50:16 --> Security Class Initialized
DEBUG - 2019-07-01 15:50:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:50:16 --> Input Class Initialized
INFO - 2019-07-01 15:50:16 --> Language Class Initialized
INFO - 2019-07-01 15:50:16 --> Language Class Initialized
INFO - 2019-07-01 15:50:16 --> Config Class Initialized
INFO - 2019-07-01 15:50:16 --> Loader Class Initialized
DEBUG - 2019-07-01 15:50:16 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:50:16 --> Helper loaded: url_helper
INFO - 2019-07-01 15:50:16 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:50:16 --> Helper loaded: string_helper
INFO - 2019-07-01 15:50:16 --> Helper loaded: array_helper
INFO - 2019-07-01 15:50:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:50:16 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:50:16 --> Database Driver Class Initialized
INFO - 2019-07-01 15:50:16 --> Controller Class Initialized
INFO - 2019-07-01 21:50:16 --> Helper loaded: language_helper
INFO - 2019-07-01 21:50:16 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:50:16 --> Model Class Initialized
INFO - 2019-07-01 21:50:16 --> Model Class Initialized
INFO - 2019-07-01 21:50:17 --> Model Class Initialized
INFO - 2019-07-01 21:50:17 --> Model Class Initialized
INFO - 2019-07-01 21:50:17 --> Helper loaded: form_helper
INFO - 2019-07-01 21:50:17 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:50:17 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:50:17 --> Model Class Initialized
INFO - 2019-07-01 21:50:17 --> Model Class Initialized
INFO - 2019-07-01 21:50:17 --> Final output sent to browser
DEBUG - 2019-07-01 21:50:17 --> Total execution time: 0.6532
INFO - 2019-07-01 15:50:17 --> Config Class Initialized
INFO - 2019-07-01 15:50:17 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:50:17 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:50:17 --> Utf8 Class Initialized
INFO - 2019-07-01 15:50:17 --> URI Class Initialized
INFO - 2019-07-01 15:50:17 --> Router Class Initialized
INFO - 2019-07-01 15:50:17 --> Output Class Initialized
INFO - 2019-07-01 15:50:17 --> Security Class Initialized
DEBUG - 2019-07-01 15:50:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:50:17 --> Input Class Initialized
INFO - 2019-07-01 15:50:17 --> Language Class Initialized
INFO - 2019-07-01 15:50:17 --> Language Class Initialized
INFO - 2019-07-01 15:50:17 --> Config Class Initialized
INFO - 2019-07-01 15:50:17 --> Loader Class Initialized
DEBUG - 2019-07-01 15:50:17 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:50:17 --> Helper loaded: url_helper
INFO - 2019-07-01 15:50:17 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:50:17 --> Helper loaded: string_helper
INFO - 2019-07-01 15:50:17 --> Helper loaded: array_helper
INFO - 2019-07-01 15:50:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:50:17 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:50:17 --> Database Driver Class Initialized
INFO - 2019-07-01 15:50:17 --> Controller Class Initialized
INFO - 2019-07-01 21:50:17 --> Helper loaded: language_helper
INFO - 2019-07-01 21:50:17 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:50:17 --> Model Class Initialized
INFO - 2019-07-01 21:50:17 --> Model Class Initialized
INFO - 2019-07-01 21:50:17 --> Model Class Initialized
INFO - 2019-07-01 21:50:17 --> Model Class Initialized
INFO - 2019-07-01 21:50:17 --> Helper loaded: form_helper
INFO - 2019-07-01 21:50:17 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:50:17 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:50:17 --> Model Class Initialized
INFO - 2019-07-01 21:50:17 --> Model Class Initialized
INFO - 2019-07-01 21:50:17 --> Final output sent to browser
DEBUG - 2019-07-01 21:50:17 --> Total execution time: 0.7081
INFO - 2019-07-01 15:50:19 --> Config Class Initialized
INFO - 2019-07-01 15:50:19 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:50:19 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:50:19 --> Utf8 Class Initialized
INFO - 2019-07-01 15:50:19 --> URI Class Initialized
INFO - 2019-07-01 15:50:19 --> Router Class Initialized
INFO - 2019-07-01 15:50:19 --> Output Class Initialized
INFO - 2019-07-01 15:50:19 --> Security Class Initialized
DEBUG - 2019-07-01 15:50:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:50:20 --> Input Class Initialized
INFO - 2019-07-01 15:50:20 --> Language Class Initialized
INFO - 2019-07-01 15:50:20 --> Language Class Initialized
INFO - 2019-07-01 15:50:20 --> Config Class Initialized
INFO - 2019-07-01 15:50:20 --> Loader Class Initialized
DEBUG - 2019-07-01 15:50:20 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:50:20 --> Helper loaded: url_helper
INFO - 2019-07-01 15:50:20 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:50:20 --> Helper loaded: string_helper
INFO - 2019-07-01 15:50:20 --> Helper loaded: array_helper
INFO - 2019-07-01 15:50:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:50:20 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:50:20 --> Database Driver Class Initialized
INFO - 2019-07-01 15:50:20 --> Controller Class Initialized
INFO - 2019-07-01 21:50:20 --> Helper loaded: language_helper
INFO - 2019-07-01 21:50:20 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:50:20 --> Model Class Initialized
INFO - 2019-07-01 21:50:20 --> Model Class Initialized
INFO - 2019-07-01 21:50:20 --> Model Class Initialized
INFO - 2019-07-01 21:50:20 --> Model Class Initialized
INFO - 2019-07-01 21:50:20 --> Helper loaded: form_helper
INFO - 2019-07-01 21:50:20 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:50:20 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:50:20 --> Model Class Initialized
INFO - 2019-07-01 21:50:20 --> Model Class Initialized
INFO - 2019-07-01 21:50:20 --> Final output sent to browser
DEBUG - 2019-07-01 21:50:20 --> Total execution time: 0.9018
INFO - 2019-07-01 15:50:21 --> Config Class Initialized
INFO - 2019-07-01 15:50:21 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:50:21 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:50:21 --> Utf8 Class Initialized
INFO - 2019-07-01 15:50:21 --> URI Class Initialized
INFO - 2019-07-01 15:50:21 --> Router Class Initialized
INFO - 2019-07-01 15:50:21 --> Output Class Initialized
INFO - 2019-07-01 15:50:21 --> Security Class Initialized
DEBUG - 2019-07-01 15:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:50:21 --> Input Class Initialized
INFO - 2019-07-01 15:50:21 --> Language Class Initialized
INFO - 2019-07-01 15:50:21 --> Language Class Initialized
INFO - 2019-07-01 15:50:21 --> Config Class Initialized
INFO - 2019-07-01 15:50:21 --> Loader Class Initialized
DEBUG - 2019-07-01 15:50:21 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:50:21 --> Helper loaded: url_helper
INFO - 2019-07-01 15:50:21 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:50:22 --> Helper loaded: string_helper
INFO - 2019-07-01 15:50:22 --> Helper loaded: array_helper
INFO - 2019-07-01 15:50:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:50:22 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:50:22 --> Database Driver Class Initialized
INFO - 2019-07-01 15:50:22 --> Controller Class Initialized
INFO - 2019-07-01 21:50:22 --> Helper loaded: language_helper
INFO - 2019-07-01 21:50:22 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:50:22 --> Model Class Initialized
INFO - 2019-07-01 21:50:22 --> Model Class Initialized
INFO - 2019-07-01 21:50:22 --> Model Class Initialized
INFO - 2019-07-01 21:50:22 --> Model Class Initialized
INFO - 2019-07-01 21:50:22 --> Model Class Initialized
INFO - 2019-07-01 21:50:22 --> Final output sent to browser
DEBUG - 2019-07-01 21:50:22 --> Total execution time: 0.8907
INFO - 2019-07-01 15:50:27 --> Config Class Initialized
INFO - 2019-07-01 15:50:27 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:50:27 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:50:27 --> Utf8 Class Initialized
INFO - 2019-07-01 15:50:27 --> URI Class Initialized
INFO - 2019-07-01 15:50:27 --> Router Class Initialized
INFO - 2019-07-01 15:50:27 --> Output Class Initialized
INFO - 2019-07-01 15:50:27 --> Security Class Initialized
DEBUG - 2019-07-01 15:50:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:50:28 --> Input Class Initialized
INFO - 2019-07-01 15:50:28 --> Language Class Initialized
INFO - 2019-07-01 15:50:28 --> Language Class Initialized
INFO - 2019-07-01 15:50:28 --> Config Class Initialized
INFO - 2019-07-01 15:50:28 --> Loader Class Initialized
DEBUG - 2019-07-01 15:50:28 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:50:28 --> Helper loaded: url_helper
INFO - 2019-07-01 15:50:28 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:50:28 --> Helper loaded: string_helper
INFO - 2019-07-01 15:50:28 --> Helper loaded: array_helper
INFO - 2019-07-01 15:50:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:50:28 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:50:28 --> Database Driver Class Initialized
INFO - 2019-07-01 15:50:28 --> Controller Class Initialized
INFO - 2019-07-01 21:50:28 --> Helper loaded: language_helper
INFO - 2019-07-01 21:50:28 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:50:28 --> Model Class Initialized
INFO - 2019-07-01 21:50:28 --> Model Class Initialized
INFO - 2019-07-01 21:50:28 --> Model Class Initialized
INFO - 2019-07-01 21:50:28 --> Model Class Initialized
INFO - 2019-07-01 21:50:28 --> Helper loaded: form_helper
INFO - 2019-07-01 21:50:28 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:50:28 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:50:28 --> Model Class Initialized
INFO - 2019-07-01 21:50:28 --> Model Class Initialized
INFO - 2019-07-01 21:50:28 --> Final output sent to browser
DEBUG - 2019-07-01 21:50:28 --> Total execution time: 1.2898
INFO - 2019-07-01 15:50:29 --> Config Class Initialized
INFO - 2019-07-01 15:50:29 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:50:29 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:50:29 --> Utf8 Class Initialized
INFO - 2019-07-01 15:50:29 --> URI Class Initialized
INFO - 2019-07-01 15:50:29 --> Router Class Initialized
INFO - 2019-07-01 15:50:29 --> Output Class Initialized
INFO - 2019-07-01 15:50:29 --> Security Class Initialized
DEBUG - 2019-07-01 15:50:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:50:29 --> Input Class Initialized
INFO - 2019-07-01 15:50:29 --> Language Class Initialized
INFO - 2019-07-01 15:50:29 --> Language Class Initialized
INFO - 2019-07-01 15:50:29 --> Config Class Initialized
INFO - 2019-07-01 15:50:29 --> Loader Class Initialized
DEBUG - 2019-07-01 15:50:29 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:50:29 --> Helper loaded: url_helper
INFO - 2019-07-01 15:50:29 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:50:29 --> Helper loaded: string_helper
INFO - 2019-07-01 15:50:29 --> Helper loaded: array_helper
INFO - 2019-07-01 15:50:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:50:29 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:50:29 --> Database Driver Class Initialized
INFO - 2019-07-01 15:50:29 --> Controller Class Initialized
INFO - 2019-07-01 21:50:29 --> Helper loaded: language_helper
INFO - 2019-07-01 21:50:29 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:50:29 --> Model Class Initialized
INFO - 2019-07-01 21:50:30 --> Model Class Initialized
INFO - 2019-07-01 21:50:30 --> Model Class Initialized
INFO - 2019-07-01 21:50:30 --> Model Class Initialized
INFO - 2019-07-01 21:50:30 --> Helper loaded: form_helper
INFO - 2019-07-01 21:50:30 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:50:30 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:50:30 --> Model Class Initialized
INFO - 2019-07-01 21:50:30 --> Model Class Initialized
INFO - 2019-07-01 21:50:30 --> Final output sent to browser
DEBUG - 2019-07-01 21:50:30 --> Total execution time: 1.1740
INFO - 2019-07-01 15:50:34 --> Config Class Initialized
INFO - 2019-07-01 15:50:34 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:50:34 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:50:34 --> Utf8 Class Initialized
INFO - 2019-07-01 15:50:34 --> URI Class Initialized
INFO - 2019-07-01 15:50:34 --> Router Class Initialized
INFO - 2019-07-01 15:50:34 --> Output Class Initialized
INFO - 2019-07-01 15:50:34 --> Security Class Initialized
DEBUG - 2019-07-01 15:50:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:50:34 --> Input Class Initialized
INFO - 2019-07-01 15:50:34 --> Language Class Initialized
INFO - 2019-07-01 15:50:34 --> Language Class Initialized
INFO - 2019-07-01 15:50:34 --> Config Class Initialized
INFO - 2019-07-01 15:50:34 --> Loader Class Initialized
DEBUG - 2019-07-01 15:50:34 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:50:34 --> Helper loaded: url_helper
INFO - 2019-07-01 15:50:34 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:50:34 --> Helper loaded: string_helper
INFO - 2019-07-01 15:50:34 --> Helper loaded: array_helper
INFO - 2019-07-01 15:50:34 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:50:34 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:50:34 --> Database Driver Class Initialized
INFO - 2019-07-01 15:50:34 --> Controller Class Initialized
INFO - 2019-07-01 21:50:34 --> Helper loaded: language_helper
INFO - 2019-07-01 21:50:34 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:50:34 --> Model Class Initialized
INFO - 2019-07-01 21:50:34 --> Model Class Initialized
INFO - 2019-07-01 21:50:34 --> Model Class Initialized
INFO - 2019-07-01 21:50:34 --> Model Class Initialized
INFO - 2019-07-01 21:50:34 --> Helper loaded: form_helper
INFO - 2019-07-01 21:50:34 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:50:34 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:50:35 --> Model Class Initialized
INFO - 2019-07-01 21:50:35 --> Model Class Initialized
INFO - 2019-07-01 21:50:35 --> Final output sent to browser
DEBUG - 2019-07-01 21:50:35 --> Total execution time: 0.8748
INFO - 2019-07-01 15:50:36 --> Config Class Initialized
INFO - 2019-07-01 15:50:36 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:50:36 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:50:36 --> Utf8 Class Initialized
INFO - 2019-07-01 15:50:36 --> URI Class Initialized
INFO - 2019-07-01 15:50:36 --> Router Class Initialized
INFO - 2019-07-01 15:50:36 --> Output Class Initialized
INFO - 2019-07-01 15:50:36 --> Security Class Initialized
DEBUG - 2019-07-01 15:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:50:36 --> Input Class Initialized
INFO - 2019-07-01 15:50:36 --> Language Class Initialized
INFO - 2019-07-01 15:50:36 --> Language Class Initialized
INFO - 2019-07-01 15:50:36 --> Config Class Initialized
INFO - 2019-07-01 15:50:36 --> Loader Class Initialized
DEBUG - 2019-07-01 15:50:36 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:50:36 --> Helper loaded: url_helper
INFO - 2019-07-01 15:50:36 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:50:36 --> Helper loaded: string_helper
INFO - 2019-07-01 15:50:36 --> Helper loaded: array_helper
INFO - 2019-07-01 15:50:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:50:37 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:50:37 --> Database Driver Class Initialized
INFO - 2019-07-01 15:50:37 --> Controller Class Initialized
INFO - 2019-07-01 21:50:37 --> Helper loaded: language_helper
INFO - 2019-07-01 21:50:37 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:50:37 --> Model Class Initialized
INFO - 2019-07-01 21:50:37 --> Model Class Initialized
INFO - 2019-07-01 21:50:37 --> Model Class Initialized
INFO - 2019-07-01 21:50:37 --> Model Class Initialized
INFO - 2019-07-01 21:50:37 --> Model Class Initialized
INFO - 2019-07-01 21:50:37 --> Final output sent to browser
DEBUG - 2019-07-01 21:50:37 --> Total execution time: 0.7560
INFO - 2019-07-01 15:50:44 --> Config Class Initialized
INFO - 2019-07-01 15:50:44 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:50:44 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:50:44 --> Utf8 Class Initialized
INFO - 2019-07-01 15:50:44 --> URI Class Initialized
INFO - 2019-07-01 15:50:44 --> Router Class Initialized
INFO - 2019-07-01 15:50:44 --> Output Class Initialized
INFO - 2019-07-01 15:50:44 --> Security Class Initialized
DEBUG - 2019-07-01 15:50:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:50:44 --> Input Class Initialized
INFO - 2019-07-01 15:50:44 --> Language Class Initialized
INFO - 2019-07-01 15:50:44 --> Language Class Initialized
INFO - 2019-07-01 15:50:44 --> Config Class Initialized
INFO - 2019-07-01 15:50:44 --> Loader Class Initialized
DEBUG - 2019-07-01 15:50:44 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:50:44 --> Helper loaded: url_helper
INFO - 2019-07-01 15:50:44 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:50:44 --> Helper loaded: string_helper
INFO - 2019-07-01 15:50:44 --> Helper loaded: array_helper
INFO - 2019-07-01 15:50:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:50:44 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:50:44 --> Database Driver Class Initialized
INFO - 2019-07-01 15:50:44 --> Controller Class Initialized
INFO - 2019-07-01 21:50:44 --> Helper loaded: language_helper
INFO - 2019-07-01 21:50:44 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:50:44 --> Model Class Initialized
INFO - 2019-07-01 21:50:44 --> Model Class Initialized
INFO - 2019-07-01 21:50:44 --> Model Class Initialized
INFO - 2019-07-01 21:50:44 --> Model Class Initialized
INFO - 2019-07-01 21:50:44 --> Helper loaded: form_helper
INFO - 2019-07-01 21:50:44 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:50:44 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:50:44 --> Model Class Initialized
INFO - 2019-07-01 21:50:44 --> Model Class Initialized
INFO - 2019-07-01 21:50:44 --> Final output sent to browser
DEBUG - 2019-07-01 21:50:44 --> Total execution time: 0.8530
INFO - 2019-07-01 15:50:45 --> Config Class Initialized
INFO - 2019-07-01 15:50:45 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:50:45 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:50:45 --> Utf8 Class Initialized
INFO - 2019-07-01 15:50:45 --> URI Class Initialized
INFO - 2019-07-01 15:50:45 --> Router Class Initialized
INFO - 2019-07-01 15:50:45 --> Output Class Initialized
INFO - 2019-07-01 15:50:45 --> Security Class Initialized
DEBUG - 2019-07-01 15:50:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:50:45 --> Input Class Initialized
INFO - 2019-07-01 15:50:45 --> Language Class Initialized
INFO - 2019-07-01 15:50:45 --> Language Class Initialized
INFO - 2019-07-01 15:50:45 --> Config Class Initialized
INFO - 2019-07-01 15:50:45 --> Loader Class Initialized
DEBUG - 2019-07-01 15:50:45 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:50:45 --> Helper loaded: url_helper
INFO - 2019-07-01 15:50:45 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:50:45 --> Helper loaded: string_helper
INFO - 2019-07-01 15:50:45 --> Helper loaded: array_helper
INFO - 2019-07-01 15:50:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:50:45 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:50:45 --> Database Driver Class Initialized
INFO - 2019-07-01 15:50:45 --> Controller Class Initialized
INFO - 2019-07-01 21:50:45 --> Helper loaded: language_helper
INFO - 2019-07-01 21:50:45 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:50:45 --> Model Class Initialized
INFO - 2019-07-01 21:50:45 --> Model Class Initialized
INFO - 2019-07-01 21:50:45 --> Model Class Initialized
INFO - 2019-07-01 21:50:45 --> Model Class Initialized
INFO - 2019-07-01 21:50:45 --> Helper loaded: form_helper
INFO - 2019-07-01 21:50:45 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:50:45 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:50:45 --> Model Class Initialized
INFO - 2019-07-01 21:50:45 --> Model Class Initialized
INFO - 2019-07-01 21:50:45 --> Final output sent to browser
DEBUG - 2019-07-01 21:50:45 --> Total execution time: 0.7771
INFO - 2019-07-01 15:50:49 --> Config Class Initialized
INFO - 2019-07-01 15:50:49 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:50:49 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:50:49 --> Utf8 Class Initialized
INFO - 2019-07-01 15:50:49 --> URI Class Initialized
INFO - 2019-07-01 15:50:49 --> Router Class Initialized
INFO - 2019-07-01 15:50:49 --> Output Class Initialized
INFO - 2019-07-01 15:50:49 --> Security Class Initialized
DEBUG - 2019-07-01 15:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:50:49 --> Input Class Initialized
INFO - 2019-07-01 15:50:49 --> Language Class Initialized
INFO - 2019-07-01 15:50:49 --> Language Class Initialized
INFO - 2019-07-01 15:50:49 --> Config Class Initialized
INFO - 2019-07-01 15:50:49 --> Loader Class Initialized
DEBUG - 2019-07-01 15:50:49 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:50:49 --> Helper loaded: url_helper
INFO - 2019-07-01 15:50:49 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:50:49 --> Helper loaded: string_helper
INFO - 2019-07-01 15:50:49 --> Helper loaded: array_helper
INFO - 2019-07-01 15:50:49 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:50:49 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:50:49 --> Database Driver Class Initialized
INFO - 2019-07-01 15:50:49 --> Controller Class Initialized
INFO - 2019-07-01 21:50:49 --> Helper loaded: language_helper
INFO - 2019-07-01 21:50:50 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:50:50 --> Model Class Initialized
INFO - 2019-07-01 21:50:50 --> Model Class Initialized
INFO - 2019-07-01 21:50:50 --> Model Class Initialized
INFO - 2019-07-01 21:50:50 --> Model Class Initialized
INFO - 2019-07-01 21:50:50 --> Helper loaded: form_helper
INFO - 2019-07-01 21:50:50 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:50:50 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:50:50 --> Model Class Initialized
INFO - 2019-07-01 21:50:50 --> Model Class Initialized
INFO - 2019-07-01 21:50:50 --> Final output sent to browser
DEBUG - 2019-07-01 21:50:50 --> Total execution time: 0.9597
INFO - 2019-07-01 15:50:52 --> Config Class Initialized
INFO - 2019-07-01 15:50:52 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:50:52 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:50:52 --> Utf8 Class Initialized
INFO - 2019-07-01 15:50:52 --> URI Class Initialized
INFO - 2019-07-01 15:50:52 --> Router Class Initialized
INFO - 2019-07-01 15:50:53 --> Output Class Initialized
INFO - 2019-07-01 15:50:53 --> Security Class Initialized
DEBUG - 2019-07-01 15:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:50:53 --> Input Class Initialized
INFO - 2019-07-01 15:50:53 --> Language Class Initialized
INFO - 2019-07-01 15:50:53 --> Language Class Initialized
INFO - 2019-07-01 15:50:53 --> Config Class Initialized
INFO - 2019-07-01 15:50:53 --> Loader Class Initialized
DEBUG - 2019-07-01 15:50:53 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:50:53 --> Helper loaded: url_helper
INFO - 2019-07-01 15:50:53 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:50:53 --> Helper loaded: string_helper
INFO - 2019-07-01 15:50:53 --> Helper loaded: array_helper
INFO - 2019-07-01 15:50:53 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:50:53 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:50:53 --> Database Driver Class Initialized
INFO - 2019-07-01 15:50:53 --> Controller Class Initialized
INFO - 2019-07-01 21:50:53 --> Helper loaded: language_helper
INFO - 2019-07-01 21:50:53 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:50:53 --> Model Class Initialized
INFO - 2019-07-01 21:50:53 --> Model Class Initialized
INFO - 2019-07-01 21:50:53 --> Model Class Initialized
INFO - 2019-07-01 21:50:53 --> Model Class Initialized
INFO - 2019-07-01 21:50:53 --> Helper loaded: form_helper
INFO - 2019-07-01 21:50:53 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:50:53 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:50:53 --> Model Class Initialized
INFO - 2019-07-01 21:50:53 --> Model Class Initialized
INFO - 2019-07-01 21:50:53 --> Final output sent to browser
DEBUG - 2019-07-01 21:50:53 --> Total execution time: 1.0441
INFO - 2019-07-01 15:50:53 --> Config Class Initialized
INFO - 2019-07-01 15:50:53 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:50:54 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:50:54 --> Utf8 Class Initialized
INFO - 2019-07-01 15:50:54 --> URI Class Initialized
INFO - 2019-07-01 15:50:54 --> Router Class Initialized
INFO - 2019-07-01 15:50:54 --> Output Class Initialized
INFO - 2019-07-01 15:50:54 --> Security Class Initialized
DEBUG - 2019-07-01 15:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:50:54 --> Input Class Initialized
INFO - 2019-07-01 15:50:54 --> Language Class Initialized
INFO - 2019-07-01 15:50:54 --> Language Class Initialized
INFO - 2019-07-01 15:50:54 --> Config Class Initialized
INFO - 2019-07-01 15:50:54 --> Loader Class Initialized
DEBUG - 2019-07-01 15:50:54 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:50:54 --> Helper loaded: url_helper
INFO - 2019-07-01 15:50:54 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:50:54 --> Helper loaded: string_helper
INFO - 2019-07-01 15:50:54 --> Helper loaded: array_helper
INFO - 2019-07-01 15:50:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:50:54 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:50:54 --> Database Driver Class Initialized
INFO - 2019-07-01 15:50:54 --> Controller Class Initialized
INFO - 2019-07-01 21:50:54 --> Helper loaded: language_helper
INFO - 2019-07-01 21:50:54 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:50:54 --> Model Class Initialized
INFO - 2019-07-01 21:50:54 --> Model Class Initialized
INFO - 2019-07-01 21:50:54 --> Model Class Initialized
INFO - 2019-07-01 21:50:54 --> Model Class Initialized
INFO - 2019-07-01 21:50:54 --> Helper loaded: form_helper
INFO - 2019-07-01 21:50:54 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:50:54 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:50:54 --> Model Class Initialized
INFO - 2019-07-01 21:50:55 --> Model Class Initialized
INFO - 2019-07-01 21:50:55 --> Final output sent to browser
DEBUG - 2019-07-01 21:50:55 --> Total execution time: 1.0759
INFO - 2019-07-01 15:50:57 --> Config Class Initialized
INFO - 2019-07-01 15:50:57 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:50:57 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:50:57 --> Utf8 Class Initialized
INFO - 2019-07-01 15:50:57 --> URI Class Initialized
INFO - 2019-07-01 15:50:57 --> Router Class Initialized
INFO - 2019-07-01 15:50:57 --> Output Class Initialized
INFO - 2019-07-01 15:50:57 --> Security Class Initialized
DEBUG - 2019-07-01 15:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:50:57 --> Input Class Initialized
INFO - 2019-07-01 15:50:57 --> Language Class Initialized
INFO - 2019-07-01 15:50:57 --> Language Class Initialized
INFO - 2019-07-01 15:50:57 --> Config Class Initialized
INFO - 2019-07-01 15:50:57 --> Loader Class Initialized
DEBUG - 2019-07-01 15:50:58 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:50:58 --> Helper loaded: url_helper
INFO - 2019-07-01 15:50:58 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:50:58 --> Helper loaded: string_helper
INFO - 2019-07-01 15:50:58 --> Helper loaded: array_helper
INFO - 2019-07-01 15:50:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:50:58 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:50:58 --> Database Driver Class Initialized
INFO - 2019-07-01 15:50:58 --> Controller Class Initialized
INFO - 2019-07-01 21:50:58 --> Helper loaded: language_helper
INFO - 2019-07-01 21:50:58 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:50:58 --> Model Class Initialized
INFO - 2019-07-01 21:50:58 --> Model Class Initialized
INFO - 2019-07-01 21:50:58 --> Model Class Initialized
INFO - 2019-07-01 21:50:58 --> Model Class Initialized
INFO - 2019-07-01 21:50:58 --> Helper loaded: form_helper
INFO - 2019-07-01 21:50:58 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:50:58 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:50:58 --> Model Class Initialized
INFO - 2019-07-01 21:50:58 --> Model Class Initialized
INFO - 2019-07-01 21:50:58 --> Final output sent to browser
DEBUG - 2019-07-01 21:50:58 --> Total execution time: 1.3225
INFO - 2019-07-01 15:51:20 --> Config Class Initialized
INFO - 2019-07-01 15:51:20 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:51:20 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:51:20 --> Utf8 Class Initialized
INFO - 2019-07-01 15:51:20 --> URI Class Initialized
INFO - 2019-07-01 15:51:21 --> Router Class Initialized
INFO - 2019-07-01 15:51:21 --> Output Class Initialized
INFO - 2019-07-01 15:51:21 --> Security Class Initialized
DEBUG - 2019-07-01 15:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:51:21 --> Input Class Initialized
INFO - 2019-07-01 15:51:21 --> Language Class Initialized
INFO - 2019-07-01 15:51:21 --> Language Class Initialized
INFO - 2019-07-01 15:51:21 --> Config Class Initialized
INFO - 2019-07-01 15:51:21 --> Loader Class Initialized
DEBUG - 2019-07-01 15:51:21 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:51:21 --> Helper loaded: url_helper
INFO - 2019-07-01 15:51:21 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:51:21 --> Helper loaded: string_helper
INFO - 2019-07-01 15:51:21 --> Helper loaded: array_helper
INFO - 2019-07-01 15:51:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:51:21 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:51:21 --> Database Driver Class Initialized
INFO - 2019-07-01 15:51:21 --> Controller Class Initialized
INFO - 2019-07-01 21:51:21 --> Helper loaded: language_helper
INFO - 2019-07-01 21:51:21 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:51:21 --> Model Class Initialized
INFO - 2019-07-01 21:51:21 --> Model Class Initialized
INFO - 2019-07-01 21:51:21 --> Model Class Initialized
INFO - 2019-07-01 21:51:21 --> Model Class Initialized
INFO - 2019-07-01 21:51:21 --> Helper loaded: form_helper
INFO - 2019-07-01 21:51:21 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:51:21 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:51:21 --> Model Class Initialized
INFO - 2019-07-01 21:51:22 --> Model Class Initialized
INFO - 2019-07-01 21:51:22 --> Final output sent to browser
DEBUG - 2019-07-01 21:51:22 --> Total execution time: 1.2836
INFO - 2019-07-01 15:51:22 --> Config Class Initialized
INFO - 2019-07-01 15:51:22 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:51:22 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:51:22 --> Utf8 Class Initialized
INFO - 2019-07-01 15:51:22 --> URI Class Initialized
INFO - 2019-07-01 15:51:22 --> Router Class Initialized
INFO - 2019-07-01 15:51:22 --> Output Class Initialized
INFO - 2019-07-01 15:51:22 --> Security Class Initialized
DEBUG - 2019-07-01 15:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:51:22 --> Input Class Initialized
INFO - 2019-07-01 15:51:22 --> Language Class Initialized
INFO - 2019-07-01 15:51:22 --> Language Class Initialized
INFO - 2019-07-01 15:51:22 --> Config Class Initialized
INFO - 2019-07-01 15:51:23 --> Loader Class Initialized
DEBUG - 2019-07-01 15:51:23 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:51:23 --> Helper loaded: url_helper
INFO - 2019-07-01 15:51:23 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:51:23 --> Helper loaded: string_helper
INFO - 2019-07-01 15:51:23 --> Helper loaded: array_helper
INFO - 2019-07-01 15:51:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:51:23 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:51:23 --> Database Driver Class Initialized
INFO - 2019-07-01 15:51:23 --> Controller Class Initialized
INFO - 2019-07-01 21:51:23 --> Helper loaded: language_helper
INFO - 2019-07-01 21:51:23 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:51:23 --> Model Class Initialized
INFO - 2019-07-01 21:51:23 --> Model Class Initialized
INFO - 2019-07-01 21:51:23 --> Model Class Initialized
INFO - 2019-07-01 21:51:23 --> Model Class Initialized
INFO - 2019-07-01 21:51:23 --> Model Class Initialized
INFO - 2019-07-01 21:51:23 --> Final output sent to browser
DEBUG - 2019-07-01 21:51:23 --> Total execution time: 0.8290
INFO - 2019-07-01 15:51:28 --> Config Class Initialized
INFO - 2019-07-01 15:51:28 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:51:28 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:51:28 --> Utf8 Class Initialized
INFO - 2019-07-01 15:51:28 --> URI Class Initialized
INFO - 2019-07-01 15:51:28 --> Router Class Initialized
INFO - 2019-07-01 15:51:28 --> Output Class Initialized
INFO - 2019-07-01 15:51:28 --> Security Class Initialized
DEBUG - 2019-07-01 15:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:51:28 --> Input Class Initialized
INFO - 2019-07-01 15:51:29 --> Language Class Initialized
INFO - 2019-07-01 15:51:29 --> Language Class Initialized
INFO - 2019-07-01 15:51:29 --> Config Class Initialized
INFO - 2019-07-01 15:51:29 --> Loader Class Initialized
DEBUG - 2019-07-01 15:51:29 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:51:29 --> Helper loaded: url_helper
INFO - 2019-07-01 15:51:29 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:51:29 --> Helper loaded: string_helper
INFO - 2019-07-01 15:51:29 --> Helper loaded: array_helper
INFO - 2019-07-01 15:51:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:51:29 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:51:29 --> Database Driver Class Initialized
INFO - 2019-07-01 15:51:29 --> Controller Class Initialized
INFO - 2019-07-01 21:51:29 --> Helper loaded: language_helper
INFO - 2019-07-01 21:51:29 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:51:29 --> Model Class Initialized
INFO - 2019-07-01 21:51:29 --> Model Class Initialized
INFO - 2019-07-01 21:51:29 --> Model Class Initialized
INFO - 2019-07-01 21:51:29 --> Model Class Initialized
INFO - 2019-07-01 21:51:29 --> Helper loaded: form_helper
INFO - 2019-07-01 21:51:29 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:51:29 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:51:29 --> Model Class Initialized
INFO - 2019-07-01 21:51:29 --> Model Class Initialized
INFO - 2019-07-01 21:51:29 --> Final output sent to browser
DEBUG - 2019-07-01 21:51:29 --> Total execution time: 1.1950
INFO - 2019-07-01 15:51:29 --> Config Class Initialized
INFO - 2019-07-01 15:51:29 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:51:30 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:51:30 --> Utf8 Class Initialized
INFO - 2019-07-01 15:51:30 --> URI Class Initialized
INFO - 2019-07-01 15:51:30 --> Router Class Initialized
INFO - 2019-07-01 15:51:30 --> Output Class Initialized
INFO - 2019-07-01 15:51:30 --> Security Class Initialized
DEBUG - 2019-07-01 15:51:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:51:30 --> Input Class Initialized
INFO - 2019-07-01 15:51:30 --> Language Class Initialized
INFO - 2019-07-01 15:51:30 --> Language Class Initialized
INFO - 2019-07-01 15:51:30 --> Config Class Initialized
INFO - 2019-07-01 15:51:30 --> Loader Class Initialized
DEBUG - 2019-07-01 15:51:30 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:51:30 --> Helper loaded: url_helper
INFO - 2019-07-01 15:51:30 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:51:30 --> Helper loaded: string_helper
INFO - 2019-07-01 15:51:30 --> Helper loaded: array_helper
INFO - 2019-07-01 15:51:30 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:51:30 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:51:30 --> Database Driver Class Initialized
INFO - 2019-07-01 15:51:30 --> Controller Class Initialized
INFO - 2019-07-01 21:51:30 --> Helper loaded: language_helper
INFO - 2019-07-01 21:51:30 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:51:30 --> Model Class Initialized
INFO - 2019-07-01 21:51:30 --> Model Class Initialized
INFO - 2019-07-01 21:51:30 --> Model Class Initialized
INFO - 2019-07-01 21:51:30 --> Model Class Initialized
INFO - 2019-07-01 21:51:30 --> Helper loaded: form_helper
INFO - 2019-07-01 21:51:30 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:51:30 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:51:30 --> Model Class Initialized
INFO - 2019-07-01 21:51:30 --> Model Class Initialized
INFO - 2019-07-01 21:51:30 --> Final output sent to browser
DEBUG - 2019-07-01 21:51:30 --> Total execution time: 0.8474
INFO - 2019-07-01 15:51:46 --> Config Class Initialized
INFO - 2019-07-01 15:51:46 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:51:46 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:51:46 --> Utf8 Class Initialized
INFO - 2019-07-01 15:51:46 --> URI Class Initialized
INFO - 2019-07-01 15:51:46 --> Router Class Initialized
INFO - 2019-07-01 15:51:46 --> Output Class Initialized
INFO - 2019-07-01 15:51:46 --> Security Class Initialized
DEBUG - 2019-07-01 15:51:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:51:46 --> Input Class Initialized
INFO - 2019-07-01 15:51:46 --> Language Class Initialized
INFO - 2019-07-01 15:51:46 --> Language Class Initialized
INFO - 2019-07-01 15:51:46 --> Config Class Initialized
INFO - 2019-07-01 15:51:46 --> Loader Class Initialized
DEBUG - 2019-07-01 15:51:46 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:51:46 --> Helper loaded: url_helper
INFO - 2019-07-01 15:51:46 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:51:46 --> Helper loaded: string_helper
INFO - 2019-07-01 15:51:46 --> Helper loaded: array_helper
INFO - 2019-07-01 15:51:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:51:46 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:51:46 --> Database Driver Class Initialized
INFO - 2019-07-01 15:51:46 --> Controller Class Initialized
INFO - 2019-07-01 21:51:46 --> Helper loaded: language_helper
INFO - 2019-07-01 21:51:46 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:51:46 --> Model Class Initialized
INFO - 2019-07-01 21:51:46 --> Model Class Initialized
INFO - 2019-07-01 21:51:46 --> Model Class Initialized
INFO - 2019-07-01 21:51:46 --> Model Class Initialized
INFO - 2019-07-01 21:51:46 --> Model Class Initialized
INFO - 2019-07-01 21:51:46 --> Final output sent to browser
DEBUG - 2019-07-01 21:51:46 --> Total execution time: 0.5709
INFO - 2019-07-01 15:51:49 --> Config Class Initialized
INFO - 2019-07-01 15:51:49 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:51:49 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:51:49 --> Utf8 Class Initialized
INFO - 2019-07-01 15:51:49 --> URI Class Initialized
INFO - 2019-07-01 15:51:50 --> Router Class Initialized
INFO - 2019-07-01 15:51:50 --> Output Class Initialized
INFO - 2019-07-01 15:51:50 --> Security Class Initialized
DEBUG - 2019-07-01 15:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:51:50 --> Input Class Initialized
INFO - 2019-07-01 15:51:50 --> Language Class Initialized
INFO - 2019-07-01 15:51:50 --> Language Class Initialized
INFO - 2019-07-01 15:51:50 --> Config Class Initialized
INFO - 2019-07-01 15:51:50 --> Loader Class Initialized
DEBUG - 2019-07-01 15:51:50 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:51:50 --> Helper loaded: url_helper
INFO - 2019-07-01 15:51:50 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:51:50 --> Helper loaded: string_helper
INFO - 2019-07-01 15:51:50 --> Helper loaded: array_helper
INFO - 2019-07-01 15:51:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:51:50 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:51:50 --> Database Driver Class Initialized
INFO - 2019-07-01 15:51:50 --> Controller Class Initialized
INFO - 2019-07-01 21:51:50 --> Helper loaded: language_helper
INFO - 2019-07-01 21:51:50 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:51:50 --> Model Class Initialized
INFO - 2019-07-01 21:51:50 --> Model Class Initialized
INFO - 2019-07-01 21:51:50 --> Model Class Initialized
INFO - 2019-07-01 21:51:50 --> Model Class Initialized
INFO - 2019-07-01 21:51:50 --> Helper loaded: form_helper
INFO - 2019-07-01 21:51:50 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:51:50 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:51:50 --> Model Class Initialized
INFO - 2019-07-01 21:51:50 --> Model Class Initialized
INFO - 2019-07-01 21:51:50 --> Final output sent to browser
DEBUG - 2019-07-01 21:51:50 --> Total execution time: 1.0471
INFO - 2019-07-01 15:51:51 --> Config Class Initialized
INFO - 2019-07-01 15:51:51 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:51:51 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:51:51 --> Utf8 Class Initialized
INFO - 2019-07-01 15:51:51 --> URI Class Initialized
INFO - 2019-07-01 15:51:51 --> Router Class Initialized
INFO - 2019-07-01 15:51:51 --> Output Class Initialized
INFO - 2019-07-01 15:51:51 --> Security Class Initialized
DEBUG - 2019-07-01 15:51:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:51:51 --> Input Class Initialized
INFO - 2019-07-01 15:51:51 --> Language Class Initialized
INFO - 2019-07-01 15:51:51 --> Language Class Initialized
INFO - 2019-07-01 15:51:51 --> Config Class Initialized
INFO - 2019-07-01 15:51:51 --> Loader Class Initialized
DEBUG - 2019-07-01 15:51:51 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:51:51 --> Helper loaded: url_helper
INFO - 2019-07-01 15:51:51 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:51:51 --> Helper loaded: string_helper
INFO - 2019-07-01 15:51:51 --> Helper loaded: array_helper
INFO - 2019-07-01 15:51:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:51:51 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:51:51 --> Database Driver Class Initialized
INFO - 2019-07-01 15:51:51 --> Controller Class Initialized
INFO - 2019-07-01 21:51:51 --> Helper loaded: language_helper
INFO - 2019-07-01 21:51:51 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:51:51 --> Model Class Initialized
INFO - 2019-07-01 21:51:51 --> Model Class Initialized
INFO - 2019-07-01 21:51:51 --> Model Class Initialized
INFO - 2019-07-01 21:51:51 --> Model Class Initialized
INFO - 2019-07-01 21:51:51 --> Helper loaded: form_helper
INFO - 2019-07-01 21:51:51 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:51:51 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:51:52 --> Model Class Initialized
INFO - 2019-07-01 21:51:52 --> Model Class Initialized
INFO - 2019-07-01 21:51:52 --> Final output sent to browser
DEBUG - 2019-07-01 21:51:52 --> Total execution time: 1.0416
INFO - 2019-07-01 15:51:55 --> Config Class Initialized
INFO - 2019-07-01 15:51:55 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:51:55 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:51:55 --> Utf8 Class Initialized
INFO - 2019-07-01 15:51:55 --> URI Class Initialized
INFO - 2019-07-01 15:51:55 --> Router Class Initialized
INFO - 2019-07-01 15:51:56 --> Output Class Initialized
INFO - 2019-07-01 15:51:56 --> Security Class Initialized
DEBUG - 2019-07-01 15:51:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:51:56 --> Input Class Initialized
INFO - 2019-07-01 15:51:56 --> Language Class Initialized
INFO - 2019-07-01 15:51:56 --> Language Class Initialized
INFO - 2019-07-01 15:51:56 --> Config Class Initialized
INFO - 2019-07-01 15:51:56 --> Loader Class Initialized
DEBUG - 2019-07-01 15:51:56 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:51:56 --> Helper loaded: url_helper
INFO - 2019-07-01 15:51:56 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:51:56 --> Helper loaded: string_helper
INFO - 2019-07-01 15:51:56 --> Helper loaded: array_helper
INFO - 2019-07-01 15:51:56 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:51:56 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:51:56 --> Database Driver Class Initialized
INFO - 2019-07-01 15:51:56 --> Controller Class Initialized
INFO - 2019-07-01 21:51:56 --> Helper loaded: language_helper
INFO - 2019-07-01 21:51:56 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:51:56 --> Model Class Initialized
INFO - 2019-07-01 21:51:56 --> Model Class Initialized
INFO - 2019-07-01 21:51:56 --> Model Class Initialized
INFO - 2019-07-01 21:51:56 --> Model Class Initialized
INFO - 2019-07-01 21:51:56 --> Helper loaded: form_helper
INFO - 2019-07-01 21:51:56 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:51:56 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:51:56 --> Model Class Initialized
INFO - 2019-07-01 21:51:56 --> Model Class Initialized
INFO - 2019-07-01 21:51:56 --> Final output sent to browser
DEBUG - 2019-07-01 21:51:57 --> Total execution time: 1.2979
INFO - 2019-07-01 15:58:54 --> Config Class Initialized
INFO - 2019-07-01 15:58:54 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:58:54 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:58:54 --> Utf8 Class Initialized
INFO - 2019-07-01 15:58:54 --> URI Class Initialized
INFO - 2019-07-01 15:58:54 --> Router Class Initialized
INFO - 2019-07-01 15:58:54 --> Output Class Initialized
INFO - 2019-07-01 15:58:54 --> Security Class Initialized
DEBUG - 2019-07-01 15:58:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:58:54 --> Input Class Initialized
INFO - 2019-07-01 15:58:54 --> Language Class Initialized
INFO - 2019-07-01 15:58:54 --> Language Class Initialized
INFO - 2019-07-01 15:58:54 --> Config Class Initialized
INFO - 2019-07-01 15:58:54 --> Loader Class Initialized
DEBUG - 2019-07-01 15:58:54 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:58:54 --> Helper loaded: url_helper
INFO - 2019-07-01 15:58:54 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:58:54 --> Helper loaded: string_helper
INFO - 2019-07-01 15:58:54 --> Helper loaded: array_helper
INFO - 2019-07-01 15:58:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:58:55 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:58:55 --> Database Driver Class Initialized
INFO - 2019-07-01 15:58:55 --> Controller Class Initialized
INFO - 2019-07-01 21:58:55 --> Helper loaded: language_helper
INFO - 2019-07-01 21:58:55 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:58:55 --> Model Class Initialized
INFO - 2019-07-01 21:58:55 --> Model Class Initialized
INFO - 2019-07-01 21:58:55 --> Model Class Initialized
INFO - 2019-07-01 21:58:55 --> Model Class Initialized
INFO - 2019-07-01 21:58:55 --> Helper loaded: form_helper
INFO - 2019-07-01 21:58:55 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:58:55 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:58:55 --> Model Class Initialized
INFO - 2019-07-01 21:58:55 --> Model Class Initialized
INFO - 2019-07-01 21:58:55 --> Final output sent to browser
DEBUG - 2019-07-01 21:58:55 --> Total execution time: 1.6341
INFO - 2019-07-01 15:59:00 --> Config Class Initialized
INFO - 2019-07-01 15:59:00 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:59:00 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:59:00 --> Utf8 Class Initialized
INFO - 2019-07-01 15:59:00 --> URI Class Initialized
INFO - 2019-07-01 15:59:00 --> Router Class Initialized
INFO - 2019-07-01 15:59:00 --> Output Class Initialized
INFO - 2019-07-01 15:59:00 --> Security Class Initialized
DEBUG - 2019-07-01 15:59:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:59:00 --> Input Class Initialized
INFO - 2019-07-01 15:59:00 --> Language Class Initialized
INFO - 2019-07-01 15:59:00 --> Language Class Initialized
INFO - 2019-07-01 15:59:00 --> Config Class Initialized
INFO - 2019-07-01 15:59:00 --> Loader Class Initialized
DEBUG - 2019-07-01 15:59:00 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:59:00 --> Helper loaded: url_helper
INFO - 2019-07-01 15:59:00 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:59:00 --> Helper loaded: string_helper
INFO - 2019-07-01 15:59:00 --> Helper loaded: array_helper
INFO - 2019-07-01 15:59:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:59:00 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:59:00 --> Database Driver Class Initialized
INFO - 2019-07-01 15:59:00 --> Controller Class Initialized
INFO - 2019-07-01 21:59:00 --> Helper loaded: language_helper
INFO - 2019-07-01 21:59:01 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:59:01 --> Model Class Initialized
INFO - 2019-07-01 21:59:01 --> Model Class Initialized
INFO - 2019-07-01 21:59:01 --> Model Class Initialized
INFO - 2019-07-01 21:59:01 --> Model Class Initialized
INFO - 2019-07-01 21:59:01 --> Helper loaded: form_helper
INFO - 2019-07-01 21:59:01 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:59:01 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:59:01 --> Model Class Initialized
INFO - 2019-07-01 21:59:01 --> Model Class Initialized
INFO - 2019-07-01 21:59:01 --> Final output sent to browser
DEBUG - 2019-07-01 21:59:01 --> Total execution time: 1.1563
INFO - 2019-07-01 15:59:16 --> Config Class Initialized
INFO - 2019-07-01 15:59:16 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:59:16 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:59:16 --> Utf8 Class Initialized
INFO - 2019-07-01 15:59:16 --> URI Class Initialized
INFO - 2019-07-01 15:59:16 --> Router Class Initialized
INFO - 2019-07-01 15:59:16 --> Output Class Initialized
INFO - 2019-07-01 15:59:16 --> Security Class Initialized
DEBUG - 2019-07-01 15:59:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:59:16 --> Input Class Initialized
INFO - 2019-07-01 15:59:16 --> Language Class Initialized
INFO - 2019-07-01 15:59:16 --> Language Class Initialized
INFO - 2019-07-01 15:59:16 --> Config Class Initialized
INFO - 2019-07-01 15:59:16 --> Loader Class Initialized
DEBUG - 2019-07-01 15:59:16 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:59:16 --> Helper loaded: url_helper
INFO - 2019-07-01 15:59:16 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:59:16 --> Helper loaded: string_helper
INFO - 2019-07-01 15:59:16 --> Helper loaded: array_helper
INFO - 2019-07-01 15:59:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:59:16 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:59:16 --> Database Driver Class Initialized
INFO - 2019-07-01 15:59:16 --> Controller Class Initialized
INFO - 2019-07-01 21:59:17 --> Helper loaded: language_helper
INFO - 2019-07-01 21:59:17 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:59:17 --> Model Class Initialized
INFO - 2019-07-01 21:59:17 --> Model Class Initialized
INFO - 2019-07-01 21:59:17 --> Model Class Initialized
INFO - 2019-07-01 21:59:17 --> Model Class Initialized
INFO - 2019-07-01 21:59:17 --> Helper loaded: form_helper
INFO - 2019-07-01 21:59:17 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:59:17 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:59:17 --> Model Class Initialized
INFO - 2019-07-01 21:59:17 --> Model Class Initialized
INFO - 2019-07-01 21:59:17 --> Final output sent to browser
DEBUG - 2019-07-01 21:59:17 --> Total execution time: 0.9652
INFO - 2019-07-01 15:59:17 --> Config Class Initialized
INFO - 2019-07-01 15:59:17 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:59:17 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:59:17 --> Utf8 Class Initialized
INFO - 2019-07-01 15:59:17 --> URI Class Initialized
INFO - 2019-07-01 15:59:17 --> Router Class Initialized
INFO - 2019-07-01 15:59:17 --> Output Class Initialized
INFO - 2019-07-01 15:59:17 --> Security Class Initialized
DEBUG - 2019-07-01 15:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:59:17 --> Input Class Initialized
INFO - 2019-07-01 15:59:17 --> Language Class Initialized
INFO - 2019-07-01 15:59:17 --> Language Class Initialized
INFO - 2019-07-01 15:59:17 --> Config Class Initialized
INFO - 2019-07-01 15:59:17 --> Loader Class Initialized
DEBUG - 2019-07-01 15:59:17 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:59:18 --> Helper loaded: url_helper
INFO - 2019-07-01 15:59:18 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:59:18 --> Helper loaded: string_helper
INFO - 2019-07-01 15:59:18 --> Helper loaded: array_helper
INFO - 2019-07-01 15:59:18 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:59:18 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:59:18 --> Database Driver Class Initialized
INFO - 2019-07-01 15:59:18 --> Controller Class Initialized
INFO - 2019-07-01 21:59:18 --> Helper loaded: language_helper
INFO - 2019-07-01 21:59:18 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:59:18 --> Model Class Initialized
INFO - 2019-07-01 21:59:18 --> Model Class Initialized
INFO - 2019-07-01 21:59:18 --> Model Class Initialized
INFO - 2019-07-01 21:59:18 --> Model Class Initialized
INFO - 2019-07-01 21:59:18 --> Helper loaded: form_helper
INFO - 2019-07-01 21:59:18 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:59:18 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:59:18 --> Model Class Initialized
INFO - 2019-07-01 21:59:18 --> Model Class Initialized
INFO - 2019-07-01 21:59:18 --> Final output sent to browser
DEBUG - 2019-07-01 21:59:18 --> Total execution time: 0.9582
INFO - 2019-07-01 15:59:23 --> Config Class Initialized
INFO - 2019-07-01 15:59:23 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:59:23 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:59:23 --> Utf8 Class Initialized
INFO - 2019-07-01 15:59:23 --> URI Class Initialized
INFO - 2019-07-01 15:59:23 --> Router Class Initialized
INFO - 2019-07-01 15:59:23 --> Output Class Initialized
INFO - 2019-07-01 15:59:23 --> Security Class Initialized
DEBUG - 2019-07-01 15:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:59:23 --> Input Class Initialized
INFO - 2019-07-01 15:59:23 --> Language Class Initialized
INFO - 2019-07-01 15:59:24 --> Language Class Initialized
INFO - 2019-07-01 15:59:24 --> Config Class Initialized
INFO - 2019-07-01 15:59:24 --> Loader Class Initialized
DEBUG - 2019-07-01 15:59:24 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:59:24 --> Helper loaded: url_helper
INFO - 2019-07-01 15:59:24 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:59:24 --> Helper loaded: string_helper
INFO - 2019-07-01 15:59:24 --> Helper loaded: array_helper
INFO - 2019-07-01 15:59:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:59:24 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:59:24 --> Database Driver Class Initialized
INFO - 2019-07-01 15:59:24 --> Controller Class Initialized
INFO - 2019-07-01 21:59:24 --> Helper loaded: language_helper
INFO - 2019-07-01 21:59:24 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:59:24 --> Model Class Initialized
INFO - 2019-07-01 21:59:24 --> Model Class Initialized
INFO - 2019-07-01 21:59:24 --> Model Class Initialized
INFO - 2019-07-01 21:59:24 --> Model Class Initialized
INFO - 2019-07-01 21:59:24 --> Helper loaded: form_helper
INFO - 2019-07-01 21:59:24 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:59:24 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:59:24 --> Model Class Initialized
INFO - 2019-07-01 21:59:24 --> Model Class Initialized
INFO - 2019-07-01 21:59:24 --> Final output sent to browser
DEBUG - 2019-07-01 21:59:24 --> Total execution time: 1.1037
INFO - 2019-07-01 15:59:56 --> Config Class Initialized
INFO - 2019-07-01 15:59:56 --> Hooks Class Initialized
DEBUG - 2019-07-01 15:59:56 --> UTF-8 Support Enabled
INFO - 2019-07-01 15:59:56 --> Utf8 Class Initialized
INFO - 2019-07-01 15:59:56 --> URI Class Initialized
INFO - 2019-07-01 15:59:56 --> Router Class Initialized
INFO - 2019-07-01 15:59:57 --> Output Class Initialized
INFO - 2019-07-01 15:59:57 --> Security Class Initialized
DEBUG - 2019-07-01 15:59:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 15:59:57 --> Input Class Initialized
INFO - 2019-07-01 15:59:57 --> Language Class Initialized
INFO - 2019-07-01 15:59:57 --> Language Class Initialized
INFO - 2019-07-01 15:59:57 --> Config Class Initialized
INFO - 2019-07-01 15:59:57 --> Loader Class Initialized
DEBUG - 2019-07-01 15:59:57 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 15:59:57 --> Helper loaded: url_helper
INFO - 2019-07-01 15:59:57 --> Helper loaded: inflector_helper
INFO - 2019-07-01 15:59:57 --> Helper loaded: string_helper
INFO - 2019-07-01 15:59:57 --> Helper loaded: array_helper
INFO - 2019-07-01 15:59:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 15:59:57 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 15:59:57 --> Database Driver Class Initialized
INFO - 2019-07-01 15:59:57 --> Controller Class Initialized
INFO - 2019-07-01 21:59:57 --> Helper loaded: language_helper
INFO - 2019-07-01 21:59:57 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 21:59:57 --> Model Class Initialized
INFO - 2019-07-01 21:59:57 --> Model Class Initialized
INFO - 2019-07-01 21:59:57 --> Model Class Initialized
INFO - 2019-07-01 21:59:57 --> Model Class Initialized
INFO - 2019-07-01 21:59:57 --> Helper loaded: form_helper
INFO - 2019-07-01 21:59:57 --> Form Validation Class Initialized
DEBUG - 2019-07-01 21:59:58 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 21:59:58 --> Model Class Initialized
INFO - 2019-07-01 21:59:58 --> Model Class Initialized
INFO - 2019-07-01 21:59:58 --> Final output sent to browser
DEBUG - 2019-07-01 21:59:58 --> Total execution time: 1.4631
INFO - 2019-07-01 16:00:14 --> Config Class Initialized
INFO - 2019-07-01 16:00:14 --> Hooks Class Initialized
DEBUG - 2019-07-01 16:00:14 --> UTF-8 Support Enabled
INFO - 2019-07-01 16:00:14 --> Utf8 Class Initialized
INFO - 2019-07-01 16:00:14 --> URI Class Initialized
INFO - 2019-07-01 16:00:14 --> Router Class Initialized
INFO - 2019-07-01 16:00:14 --> Output Class Initialized
INFO - 2019-07-01 16:00:14 --> Security Class Initialized
DEBUG - 2019-07-01 16:00:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 16:00:14 --> Input Class Initialized
INFO - 2019-07-01 16:00:14 --> Language Class Initialized
INFO - 2019-07-01 16:00:14 --> Language Class Initialized
INFO - 2019-07-01 16:00:14 --> Config Class Initialized
INFO - 2019-07-01 16:00:14 --> Loader Class Initialized
DEBUG - 2019-07-01 16:00:14 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 16:00:14 --> Helper loaded: url_helper
INFO - 2019-07-01 16:00:14 --> Helper loaded: inflector_helper
INFO - 2019-07-01 16:00:14 --> Helper loaded: string_helper
INFO - 2019-07-01 16:00:14 --> Helper loaded: array_helper
INFO - 2019-07-01 16:00:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 16:00:14 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 16:00:14 --> Database Driver Class Initialized
INFO - 2019-07-01 16:00:14 --> Controller Class Initialized
INFO - 2019-07-01 22:00:14 --> Helper loaded: language_helper
INFO - 2019-07-01 22:00:14 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 22:00:14 --> Model Class Initialized
INFO - 2019-07-01 22:00:14 --> Model Class Initialized
INFO - 2019-07-01 22:00:14 --> Model Class Initialized
INFO - 2019-07-01 22:00:15 --> Model Class Initialized
INFO - 2019-07-01 22:00:15 --> Helper loaded: form_helper
INFO - 2019-07-01 22:00:15 --> Form Validation Class Initialized
DEBUG - 2019-07-01 22:00:15 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 22:00:15 --> Model Class Initialized
INFO - 2019-07-01 22:00:15 --> Model Class Initialized
INFO - 2019-07-01 22:00:15 --> Final output sent to browser
DEBUG - 2019-07-01 22:00:15 --> Total execution time: 1.0972
INFO - 2019-07-01 16:00:21 --> Config Class Initialized
INFO - 2019-07-01 16:00:21 --> Hooks Class Initialized
DEBUG - 2019-07-01 16:00:21 --> UTF-8 Support Enabled
INFO - 2019-07-01 16:00:21 --> Utf8 Class Initialized
INFO - 2019-07-01 16:00:21 --> URI Class Initialized
INFO - 2019-07-01 16:00:21 --> Router Class Initialized
INFO - 2019-07-01 16:00:21 --> Output Class Initialized
INFO - 2019-07-01 16:00:21 --> Security Class Initialized
DEBUG - 2019-07-01 16:00:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 16:00:21 --> Input Class Initialized
INFO - 2019-07-01 16:00:21 --> Language Class Initialized
INFO - 2019-07-01 16:00:21 --> Language Class Initialized
INFO - 2019-07-01 16:00:21 --> Config Class Initialized
INFO - 2019-07-01 16:00:21 --> Loader Class Initialized
DEBUG - 2019-07-01 16:00:21 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 16:00:21 --> Helper loaded: url_helper
INFO - 2019-07-01 16:00:21 --> Helper loaded: inflector_helper
INFO - 2019-07-01 16:00:21 --> Helper loaded: string_helper
INFO - 2019-07-01 16:00:21 --> Helper loaded: array_helper
INFO - 2019-07-01 16:00:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 16:00:22 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 16:00:22 --> Database Driver Class Initialized
INFO - 2019-07-01 16:00:22 --> Controller Class Initialized
INFO - 2019-07-01 22:00:22 --> Helper loaded: language_helper
INFO - 2019-07-01 22:00:22 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 22:00:22 --> Model Class Initialized
INFO - 2019-07-01 22:00:22 --> Model Class Initialized
INFO - 2019-07-01 22:00:22 --> Model Class Initialized
INFO - 2019-07-01 22:00:22 --> Model Class Initialized
INFO - 2019-07-01 22:00:22 --> Helper loaded: form_helper
INFO - 2019-07-01 22:00:22 --> Form Validation Class Initialized
DEBUG - 2019-07-01 22:00:22 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 22:00:22 --> Model Class Initialized
INFO - 2019-07-01 22:00:22 --> Model Class Initialized
INFO - 2019-07-01 22:00:22 --> Final output sent to browser
DEBUG - 2019-07-01 22:00:22 --> Total execution time: 1.4944
INFO - 2019-07-01 16:00:22 --> Config Class Initialized
INFO - 2019-07-01 16:00:22 --> Hooks Class Initialized
DEBUG - 2019-07-01 16:00:22 --> UTF-8 Support Enabled
INFO - 2019-07-01 16:00:22 --> Utf8 Class Initialized
INFO - 2019-07-01 16:00:22 --> URI Class Initialized
INFO - 2019-07-01 16:00:22 --> Router Class Initialized
INFO - 2019-07-01 16:00:22 --> Output Class Initialized
INFO - 2019-07-01 16:00:23 --> Security Class Initialized
DEBUG - 2019-07-01 16:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 16:00:23 --> Input Class Initialized
INFO - 2019-07-01 16:00:23 --> Language Class Initialized
INFO - 2019-07-01 16:00:23 --> Language Class Initialized
INFO - 2019-07-01 16:00:23 --> Config Class Initialized
INFO - 2019-07-01 16:00:23 --> Loader Class Initialized
DEBUG - 2019-07-01 16:00:23 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 16:00:23 --> Helper loaded: url_helper
INFO - 2019-07-01 16:00:23 --> Helper loaded: inflector_helper
INFO - 2019-07-01 16:00:23 --> Helper loaded: string_helper
INFO - 2019-07-01 16:00:23 --> Helper loaded: array_helper
INFO - 2019-07-01 16:00:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 16:00:23 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 16:00:23 --> Database Driver Class Initialized
INFO - 2019-07-01 16:00:23 --> Controller Class Initialized
INFO - 2019-07-01 22:00:23 --> Helper loaded: language_helper
INFO - 2019-07-01 22:00:23 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 22:00:23 --> Model Class Initialized
INFO - 2019-07-01 22:00:23 --> Model Class Initialized
INFO - 2019-07-01 22:00:23 --> Model Class Initialized
INFO - 2019-07-01 22:00:23 --> Model Class Initialized
INFO - 2019-07-01 22:00:23 --> Helper loaded: form_helper
INFO - 2019-07-01 22:00:23 --> Form Validation Class Initialized
DEBUG - 2019-07-01 22:00:23 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 22:00:23 --> Model Class Initialized
INFO - 2019-07-01 22:00:23 --> Model Class Initialized
INFO - 2019-07-01 22:00:23 --> Final output sent to browser
DEBUG - 2019-07-01 22:00:23 --> Total execution time: 0.9809
INFO - 2019-07-01 16:00:27 --> Config Class Initialized
INFO - 2019-07-01 16:00:27 --> Hooks Class Initialized
DEBUG - 2019-07-01 16:00:27 --> UTF-8 Support Enabled
INFO - 2019-07-01 16:00:27 --> Utf8 Class Initialized
INFO - 2019-07-01 16:00:27 --> URI Class Initialized
INFO - 2019-07-01 16:00:27 --> Router Class Initialized
INFO - 2019-07-01 16:00:27 --> Output Class Initialized
INFO - 2019-07-01 16:00:27 --> Security Class Initialized
DEBUG - 2019-07-01 16:00:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 16:00:27 --> Input Class Initialized
INFO - 2019-07-01 16:00:27 --> Language Class Initialized
INFO - 2019-07-01 16:00:27 --> Language Class Initialized
INFO - 2019-07-01 16:00:27 --> Config Class Initialized
INFO - 2019-07-01 16:00:27 --> Loader Class Initialized
DEBUG - 2019-07-01 16:00:27 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 16:00:27 --> Helper loaded: url_helper
INFO - 2019-07-01 16:00:27 --> Helper loaded: inflector_helper
INFO - 2019-07-01 16:00:27 --> Helper loaded: string_helper
INFO - 2019-07-01 16:00:27 --> Helper loaded: array_helper
INFO - 2019-07-01 16:00:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 16:00:27 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 16:00:27 --> Database Driver Class Initialized
INFO - 2019-07-01 16:00:27 --> Controller Class Initialized
INFO - 2019-07-01 22:00:28 --> Helper loaded: language_helper
INFO - 2019-07-01 22:00:28 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 22:00:28 --> Model Class Initialized
INFO - 2019-07-01 22:00:28 --> Model Class Initialized
INFO - 2019-07-01 22:00:28 --> Model Class Initialized
INFO - 2019-07-01 22:00:28 --> Model Class Initialized
INFO - 2019-07-01 22:00:28 --> Helper loaded: form_helper
INFO - 2019-07-01 22:00:28 --> Form Validation Class Initialized
DEBUG - 2019-07-01 22:00:28 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 22:00:28 --> Model Class Initialized
INFO - 2019-07-01 22:00:28 --> Model Class Initialized
INFO - 2019-07-01 22:00:28 --> Final output sent to browser
DEBUG - 2019-07-01 22:00:28 --> Total execution time: 1.1562
INFO - 2019-07-01 16:02:30 --> Config Class Initialized
INFO - 2019-07-01 16:02:30 --> Hooks Class Initialized
DEBUG - 2019-07-01 16:02:30 --> UTF-8 Support Enabled
INFO - 2019-07-01 16:02:30 --> Utf8 Class Initialized
INFO - 2019-07-01 16:02:30 --> URI Class Initialized
INFO - 2019-07-01 16:02:30 --> Router Class Initialized
INFO - 2019-07-01 16:02:30 --> Output Class Initialized
INFO - 2019-07-01 16:02:30 --> Security Class Initialized
DEBUG - 2019-07-01 16:02:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 16:02:31 --> Input Class Initialized
INFO - 2019-07-01 16:02:31 --> Language Class Initialized
INFO - 2019-07-01 16:02:31 --> Language Class Initialized
INFO - 2019-07-01 16:02:31 --> Config Class Initialized
INFO - 2019-07-01 16:02:31 --> Loader Class Initialized
DEBUG - 2019-07-01 16:02:31 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 16:02:31 --> Helper loaded: url_helper
INFO - 2019-07-01 16:02:31 --> Helper loaded: inflector_helper
INFO - 2019-07-01 16:02:31 --> Helper loaded: string_helper
INFO - 2019-07-01 16:02:31 --> Helper loaded: array_helper
INFO - 2019-07-01 16:02:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 16:02:31 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 16:02:31 --> Database Driver Class Initialized
INFO - 2019-07-01 16:02:31 --> Controller Class Initialized
INFO - 2019-07-01 22:02:31 --> Helper loaded: language_helper
INFO - 2019-07-01 22:02:31 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 22:02:32 --> Model Class Initialized
INFO - 2019-07-01 22:02:32 --> Model Class Initialized
INFO - 2019-07-01 22:02:32 --> Model Class Initialized
INFO - 2019-07-01 22:02:32 --> Model Class Initialized
INFO - 2019-07-01 22:02:32 --> Helper loaded: form_helper
INFO - 2019-07-01 22:02:32 --> Form Validation Class Initialized
DEBUG - 2019-07-01 22:02:32 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 22:02:32 --> Model Class Initialized
INFO - 2019-07-01 22:02:32 --> Model Class Initialized
INFO - 2019-07-01 22:02:32 --> Final output sent to browser
DEBUG - 2019-07-01 22:02:32 --> Total execution time: 1.7909
INFO - 2019-07-01 16:02:35 --> Config Class Initialized
INFO - 2019-07-01 16:02:35 --> Hooks Class Initialized
DEBUG - 2019-07-01 16:02:35 --> UTF-8 Support Enabled
INFO - 2019-07-01 16:02:35 --> Utf8 Class Initialized
INFO - 2019-07-01 16:02:35 --> URI Class Initialized
INFO - 2019-07-01 16:02:35 --> Router Class Initialized
INFO - 2019-07-01 16:02:35 --> Output Class Initialized
INFO - 2019-07-01 16:02:35 --> Security Class Initialized
DEBUG - 2019-07-01 16:02:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 16:02:35 --> Input Class Initialized
INFO - 2019-07-01 16:02:35 --> Language Class Initialized
INFO - 2019-07-01 16:02:35 --> Language Class Initialized
INFO - 2019-07-01 16:02:35 --> Config Class Initialized
INFO - 2019-07-01 16:02:35 --> Loader Class Initialized
DEBUG - 2019-07-01 16:02:35 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 16:02:35 --> Helper loaded: url_helper
INFO - 2019-07-01 16:02:36 --> Helper loaded: inflector_helper
INFO - 2019-07-01 16:02:36 --> Helper loaded: string_helper
INFO - 2019-07-01 16:02:36 --> Helper loaded: array_helper
INFO - 2019-07-01 16:02:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 16:02:36 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 16:02:36 --> Database Driver Class Initialized
INFO - 2019-07-01 16:02:36 --> Controller Class Initialized
INFO - 2019-07-01 22:02:36 --> Helper loaded: language_helper
INFO - 2019-07-01 22:02:36 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 22:02:36 --> Model Class Initialized
INFO - 2019-07-01 22:02:36 --> Model Class Initialized
INFO - 2019-07-01 22:02:36 --> Model Class Initialized
INFO - 2019-07-01 22:02:36 --> Model Class Initialized
INFO - 2019-07-01 22:02:36 --> Helper loaded: form_helper
INFO - 2019-07-01 22:02:36 --> Form Validation Class Initialized
DEBUG - 2019-07-01 22:02:36 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 22:02:36 --> Model Class Initialized
INFO - 2019-07-01 22:02:36 --> Model Class Initialized
INFO - 2019-07-01 22:02:36 --> Final output sent to browser
DEBUG - 2019-07-01 22:02:36 --> Total execution time: 1.5301
INFO - 2019-07-01 16:02:36 --> Config Class Initialized
INFO - 2019-07-01 16:02:37 --> Hooks Class Initialized
DEBUG - 2019-07-01 16:02:37 --> UTF-8 Support Enabled
INFO - 2019-07-01 16:02:37 --> Utf8 Class Initialized
INFO - 2019-07-01 16:02:37 --> URI Class Initialized
INFO - 2019-07-01 16:02:37 --> Router Class Initialized
INFO - 2019-07-01 16:02:37 --> Output Class Initialized
INFO - 2019-07-01 16:02:37 --> Security Class Initialized
DEBUG - 2019-07-01 16:02:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 16:02:37 --> Input Class Initialized
INFO - 2019-07-01 16:02:37 --> Language Class Initialized
INFO - 2019-07-01 16:02:37 --> Language Class Initialized
INFO - 2019-07-01 16:02:37 --> Config Class Initialized
INFO - 2019-07-01 16:02:37 --> Loader Class Initialized
DEBUG - 2019-07-01 16:02:37 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 16:02:37 --> Helper loaded: url_helper
INFO - 2019-07-01 16:02:37 --> Helper loaded: inflector_helper
INFO - 2019-07-01 16:02:37 --> Helper loaded: string_helper
INFO - 2019-07-01 16:02:37 --> Helper loaded: array_helper
INFO - 2019-07-01 16:02:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 16:02:37 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 16:02:37 --> Database Driver Class Initialized
INFO - 2019-07-01 16:02:37 --> Controller Class Initialized
INFO - 2019-07-01 22:02:37 --> Helper loaded: language_helper
INFO - 2019-07-01 22:02:37 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 22:02:37 --> Model Class Initialized
INFO - 2019-07-01 22:02:37 --> Model Class Initialized
INFO - 2019-07-01 22:02:37 --> Model Class Initialized
INFO - 2019-07-01 22:02:37 --> Model Class Initialized
INFO - 2019-07-01 22:02:37 --> Helper loaded: form_helper
INFO - 2019-07-01 22:02:38 --> Form Validation Class Initialized
DEBUG - 2019-07-01 22:02:38 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-01 22:02:38 --> Model Class Initialized
INFO - 2019-07-01 22:02:38 --> Model Class Initialized
INFO - 2019-07-01 22:02:38 --> Final output sent to browser
DEBUG - 2019-07-01 22:02:38 --> Total execution time: 1.1938
INFO - 2019-07-01 16:02:42 --> Config Class Initialized
INFO - 2019-07-01 16:02:42 --> Hooks Class Initialized
DEBUG - 2019-07-01 16:02:42 --> UTF-8 Support Enabled
INFO - 2019-07-01 16:02:42 --> Utf8 Class Initialized
INFO - 2019-07-01 16:02:42 --> URI Class Initialized
INFO - 2019-07-01 16:02:42 --> Router Class Initialized
INFO - 2019-07-01 16:02:42 --> Output Class Initialized
INFO - 2019-07-01 16:02:42 --> Security Class Initialized
DEBUG - 2019-07-01 16:02:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-01 16:02:42 --> Input Class Initialized
INFO - 2019-07-01 16:02:42 --> Language Class Initialized
INFO - 2019-07-01 16:02:42 --> Language Class Initialized
INFO - 2019-07-01 16:02:42 --> Config Class Initialized
INFO - 2019-07-01 16:02:42 --> Loader Class Initialized
DEBUG - 2019-07-01 16:02:42 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-01 16:02:42 --> Helper loaded: url_helper
INFO - 2019-07-01 16:02:42 --> Helper loaded: inflector_helper
INFO - 2019-07-01 16:02:42 --> Helper loaded: string_helper
INFO - 2019-07-01 16:02:42 --> Helper loaded: array_helper
INFO - 2019-07-01 16:02:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-01 16:02:42 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-01 16:02:42 --> Database Driver Class Initialized
INFO - 2019-07-01 16:02:42 --> Controller Class Initialized
INFO - 2019-07-01 22:02:43 --> Helper loaded: language_helper
INFO - 2019-07-01 22:02:43 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-01 22:02:43 --> Model Class Initialized
INFO - 2019-07-01 22:02:43 --> Model Class Initialized
INFO - 2019-07-01 22:02:43 --> Model Class Initialized
INFO - 2019-07-01 22:02:43 --> Model Class Initialized
INFO - 2019-07-01 22:02:43 --> Model Class Initialized
INFO - 2019-07-01 22:02:43 --> Final output sent to browser
DEBUG - 2019-07-01 22:02:43 --> Total execution time: 0.6927
