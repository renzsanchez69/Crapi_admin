INFO - 2019-07-05 00:56:24 --> Helper loaded: language_helper
<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-07-05 00:56:24 --> Helper loaded: language_helper
INFO - 2019-07-05 00:56:24 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-05 00:56:24 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-05 00:56:24 --> Model Class Initialized
INFO - 2019-07-05 00:56:24 --> Model Class Initialized
INFO - 2019-07-05 00:56:24 --> Model Class Initialized
INFO - 2019-07-05 00:56:24 --> Model Class Initialized
INFO - 2019-07-05 00:56:24 --> Model Class Initialized
INFO - 2019-07-05 00:56:24 --> Model Class Initialized
INFO - 2019-07-05 00:56:24 --> Model Class Initialized
INFO - 2019-07-05 00:56:24 --> Model Class Initialized
INFO - 2019-07-05 00:56:24 --> Model Class Initialized
INFO - 2019-07-05 00:56:24 --> Helper loaded: form_helper
INFO - 2019-07-05 00:56:24 --> Form Validation Class Initialized
DEBUG - 2019-07-05 00:56:24 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-05 00:56:24 --> Final output sent to browser
DEBUG - 2019-07-05 00:56:24 --> Total execution time: 1.0750
INFO - 2019-07-05 00:56:24 --> Model Class Initialized
INFO - 2019-07-05 00:56:24 --> Model Class Initialized
INFO - 2019-07-05 00:56:24 --> Final output sent to browser
DEBUG - 2019-07-05 00:56:24 --> Total execution time: 1.1217
INFO - 2019-07-05 16:52:27 --> Config Class Initialized
INFO - 2019-07-05 16:52:27 --> Hooks Class Initialized
DEBUG - 2019-07-05 16:52:27 --> UTF-8 Support Enabled
INFO - 2019-07-05 16:52:27 --> Utf8 Class Initialized
INFO - 2019-07-05 16:52:27 --> URI Class Initialized
INFO - 2019-07-05 16:52:27 --> Router Class Initialized
INFO - 2019-07-05 16:52:27 --> Output Class Initialized
INFO - 2019-07-05 16:52:27 --> Security Class Initialized
DEBUG - 2019-07-05 16:52:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-05 16:52:27 --> Input Class Initialized
INFO - 2019-07-05 16:52:27 --> Language Class Initialized
INFO - 2019-07-05 16:52:27 --> Language Class Initialized
INFO - 2019-07-05 16:52:27 --> Config Class Initialized
INFO - 2019-07-05 16:52:27 --> Loader Class Initialized
DEBUG - 2019-07-05 16:52:27 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-05 16:52:27 --> Helper loaded: url_helper
INFO - 2019-07-05 16:52:27 --> Helper loaded: inflector_helper
INFO - 2019-07-05 16:52:27 --> Helper loaded: string_helper
INFO - 2019-07-05 16:52:27 --> Helper loaded: array_helper
INFO - 2019-07-05 16:52:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-05 16:52:27 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-05 16:52:27 --> Database Driver Class Initialized
INFO - 2019-07-05 16:52:27 --> Controller Class Initialized
INFO - 2019-07-05 22:52:27 --> Helper loaded: language_helper
INFO - 2019-07-05 22:52:27 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-05 22:52:27 --> Model Class Initialized
INFO - 2019-07-05 22:52:27 --> Model Class Initialized
INFO - 2019-07-05 22:52:27 --> Model Class Initialized
INFO - 2019-07-05 22:52:27 --> Model Class Initialized
INFO - 2019-07-05 22:52:28 --> Final output sent to browser
DEBUG - 2019-07-05 22:52:28 --> Total execution time: 1.0532
INFO - 2019-07-05 16:52:28 --> Config Class Initialized
INFO - 2019-07-05 16:52:28 --> Hooks Class Initialized
DEBUG - 2019-07-05 16:52:28 --> UTF-8 Support Enabled
INFO - 2019-07-05 16:52:28 --> Utf8 Class Initialized
INFO - 2019-07-05 16:52:28 --> URI Class Initialized
INFO - 2019-07-05 16:52:28 --> Router Class Initialized
INFO - 2019-07-05 16:52:28 --> Output Class Initialized
INFO - 2019-07-05 16:52:28 --> Security Class Initialized
DEBUG - 2019-07-05 16:52:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-05 16:52:28 --> Input Class Initialized
INFO - 2019-07-05 16:52:28 --> Language Class Initialized
INFO - 2019-07-05 16:52:28 --> Language Class Initialized
INFO - 2019-07-05 16:52:28 --> Config Class Initialized
INFO - 2019-07-05 16:52:28 --> Loader Class Initialized
DEBUG - 2019-07-05 16:52:28 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-05 16:52:28 --> Helper loaded: url_helper
INFO - 2019-07-05 16:52:28 --> Helper loaded: inflector_helper
INFO - 2019-07-05 16:52:28 --> Helper loaded: string_helper
INFO - 2019-07-05 16:52:28 --> Helper loaded: array_helper
INFO - 2019-07-05 16:52:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-05 16:52:28 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-05 16:52:28 --> Database Driver Class Initialized
INFO - 2019-07-05 16:52:28 --> Controller Class Initialized
INFO - 2019-07-05 22:52:28 --> Helper loaded: language_helper
INFO - 2019-07-05 22:52:28 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-05 22:52:28 --> Model Class Initialized
INFO - 2019-07-05 22:52:28 --> Model Class Initialized
INFO - 2019-07-05 22:52:28 --> Model Class Initialized
INFO - 2019-07-05 22:52:28 --> Model Class Initialized
INFO - 2019-07-05 22:52:28 --> Model Class Initialized
INFO - 2019-07-05 22:52:28 --> Final output sent to browser
DEBUG - 2019-07-05 22:52:28 --> Total execution time: 0.3536
INFO - 2019-07-05 16:52:29 --> Config Class Initialized
INFO - 2019-07-05 16:52:29 --> Hooks Class Initialized
DEBUG - 2019-07-05 16:52:29 --> UTF-8 Support Enabled
INFO - 2019-07-05 16:52:29 --> Utf8 Class Initialized
INFO - 2019-07-05 16:52:30 --> Config Class Initialized
INFO - 2019-07-05 16:52:30 --> URI Class Initialized
INFO - 2019-07-05 16:52:30 --> Hooks Class Initialized
DEBUG - 2019-07-05 16:52:30 --> UTF-8 Support Enabled
INFO - 2019-07-05 16:52:30 --> Router Class Initialized
INFO - 2019-07-05 16:52:30 --> Utf8 Class Initialized
INFO - 2019-07-05 16:52:30 --> URI Class Initialized
INFO - 2019-07-05 16:52:30 --> Output Class Initialized
INFO - 2019-07-05 16:52:30 --> Router Class Initialized
INFO - 2019-07-05 16:52:30 --> Security Class Initialized
INFO - 2019-07-05 16:52:30 --> Output Class Initialized
DEBUG - 2019-07-05 16:52:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-05 16:52:30 --> Security Class Initialized
INFO - 2019-07-05 16:52:30 --> Input Class Initialized
INFO - 2019-07-05 16:52:30 --> Language Class Initialized
DEBUG - 2019-07-05 16:52:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-05 16:52:30 --> Language Class Initialized
INFO - 2019-07-05 16:52:30 --> Input Class Initialized
INFO - 2019-07-05 16:52:30 --> Config Class Initialized
INFO - 2019-07-05 16:52:30 --> Loader Class Initialized
INFO - 2019-07-05 16:52:30 --> Language Class Initialized
DEBUG - 2019-07-05 16:52:30 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-05 16:52:30 --> Language Class Initialized
INFO - 2019-07-05 16:52:30 --> Config Class Initialized
INFO - 2019-07-05 16:52:30 --> Helper loaded: url_helper
INFO - 2019-07-05 16:52:30 --> Loader Class Initialized
INFO - 2019-07-05 16:52:30 --> Helper loaded: inflector_helper
DEBUG - 2019-07-05 16:52:30 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-05 16:52:30 --> Helper loaded: string_helper
INFO - 2019-07-05 16:52:30 --> Helper loaded: url_helper
INFO - 2019-07-05 16:52:30 --> Helper loaded: array_helper
INFO - 2019-07-05 16:52:30 --> Helper loaded: inflector_helper
INFO - 2019-07-05 16:52:30 --> Session: Class initialized using 'files' driver.
INFO - 2019-07-05 16:52:30 --> Helper loaded: string_helper
DEBUG - 2019-07-05 16:52:30 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-05 16:52:30 --> Helper loaded: array_helper
INFO - 2019-07-05 16:52:30 --> Database Driver Class Initialized
INFO - 2019-07-05 16:52:30 --> Controller Class Initialized
INFO - 2019-07-05 22:52:30 --> Helper loaded: language_helper
INFO - 2019-07-05 22:52:30 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-05 22:52:30 --> Model Class Initialized
INFO - 2019-07-05 22:52:30 --> Model Class Initialized
INFO - 2019-07-05 22:52:30 --> Model Class Initialized
INFO - 2019-07-05 22:52:30 --> Model Class Initialized
INFO - 2019-07-05 22:52:30 --> Model Class Initialized
INFO - 2019-07-05 22:52:30 --> Final output sent to browser
DEBUG - 2019-07-05 22:52:30 --> Total execution time: 0.3656
INFO - 2019-07-05 16:52:30 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-05 16:52:30 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-05 16:52:30 --> Database Driver Class Initialized
INFO - 2019-07-05 16:52:30 --> Controller Class Initialized
INFO - 2019-07-05 22:52:30 --> Helper loaded: language_helper
INFO - 2019-07-05 22:52:30 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-05 22:52:30 --> Model Class Initialized
INFO - 2019-07-05 22:52:30 --> Model Class Initialized
INFO - 2019-07-05 22:52:30 --> Model Class Initialized
INFO - 2019-07-05 22:52:30 --> Model Class Initialized
INFO - 2019-07-05 22:52:30 --> Helper loaded: form_helper
INFO - 2019-07-05 22:52:30 --> Form Validation Class Initialized
DEBUG - 2019-07-05 22:52:30 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-05 22:52:30 --> Model Class Initialized
INFO - 2019-07-05 22:52:30 --> Model Class Initialized
INFO - 2019-07-05 22:52:30 --> Final output sent to browser
DEBUG - 2019-07-05 22:52:30 --> Total execution time: 0.5939
INFO - 2019-07-05 17:22:55 --> Config Class Initialized
INFO - 2019-07-05 17:22:55 --> Config Class Initialized
INFO - 2019-07-05 17:22:55 --> Hooks Class Initialized
INFO - 2019-07-05 17:22:55 --> Hooks Class Initialized
DEBUG - 2019-07-05 17:22:55 --> UTF-8 Support Enabled
DEBUG - 2019-07-05 17:22:55 --> UTF-8 Support Enabled
INFO - 2019-07-05 17:22:55 --> Utf8 Class Initialized
INFO - 2019-07-05 17:22:55 --> Utf8 Class Initialized
INFO - 2019-07-05 17:22:55 --> URI Class Initialized
INFO - 2019-07-05 17:22:55 --> URI Class Initialized
INFO - 2019-07-05 17:22:55 --> Router Class Initialized
INFO - 2019-07-05 17:22:55 --> Router Class Initialized
INFO - 2019-07-05 17:22:55 --> Output Class Initialized
INFO - 2019-07-05 17:22:55 --> Output Class Initialized
INFO - 2019-07-05 17:22:55 --> Security Class Initialized
INFO - 2019-07-05 17:22:55 --> Security Class Initialized
DEBUG - 2019-07-05 17:22:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-05 17:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-05 17:22:55 --> Input Class Initialized
INFO - 2019-07-05 17:22:55 --> Input Class Initialized
INFO - 2019-07-05 17:22:55 --> Language Class Initialized
INFO - 2019-07-05 17:22:55 --> Language Class Initialized
INFO - 2019-07-05 17:22:55 --> Language Class Initialized
INFO - 2019-07-05 17:22:55 --> Language Class Initialized
INFO - 2019-07-05 17:22:55 --> Config Class Initialized
INFO - 2019-07-05 17:22:55 --> Config Class Initialized
INFO - 2019-07-05 17:22:55 --> Loader Class Initialized
INFO - 2019-07-05 17:22:55 --> Loader Class Initialized
DEBUG - 2019-07-05 17:22:55 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-05 17:22:55 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-05 17:22:55 --> Helper loaded: url_helper
INFO - 2019-07-05 17:22:55 --> Helper loaded: url_helper
INFO - 2019-07-05 17:22:55 --> Helper loaded: inflector_helper
INFO - 2019-07-05 17:22:55 --> Helper loaded: inflector_helper
INFO - 2019-07-05 17:22:55 --> Helper loaded: string_helper
INFO - 2019-07-05 17:22:55 --> Helper loaded: string_helper
INFO - 2019-07-05 17:22:55 --> Helper loaded: array_helper
INFO - 2019-07-05 17:22:55 --> Helper loaded: array_helper
INFO - 2019-07-05 17:22:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-05 17:22:55 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-05 17:22:55 --> Database Driver Class Initialized
INFO - 2019-07-05 17:22:55 --> Controller Class Initialized
INFO - 2019-07-05 23:22:55 --> Helper loaded: language_helper
INFO - 2019-07-05 23:22:55 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-05 23:22:55 --> Model Class Initialized
INFO - 2019-07-05 23:22:56 --> Model Class Initialized
INFO - 2019-07-05 23:22:56 --> Model Class Initialized
INFO - 2019-07-05 23:22:56 --> Model Class Initialized
INFO - 2019-07-05 23:22:56 --> Model Class Initialized
INFO - 2019-07-05 23:22:56 --> Final output sent to browser
DEBUG - 2019-07-05 23:22:56 --> Total execution time: 0.7878
INFO - 2019-07-05 17:22:56 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-05 17:22:56 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-05 17:22:56 --> Database Driver Class Initialized
INFO - 2019-07-05 17:22:56 --> Controller Class Initialized
INFO - 2019-07-05 23:22:56 --> Helper loaded: language_helper
INFO - 2019-07-05 23:22:56 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-05 23:22:56 --> Model Class Initialized
INFO - 2019-07-05 23:22:56 --> Model Class Initialized
INFO - 2019-07-05 23:22:56 --> Model Class Initialized
INFO - 2019-07-05 23:22:56 --> Model Class Initialized
INFO - 2019-07-05 23:22:56 --> Helper loaded: form_helper
INFO - 2019-07-05 23:22:56 --> Form Validation Class Initialized
DEBUG - 2019-07-05 23:22:56 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-05 23:22:56 --> Model Class Initialized
INFO - 2019-07-05 23:22:56 --> Model Class Initialized
INFO - 2019-07-05 23:22:56 --> Final output sent to browser
DEBUG - 2019-07-05 23:22:56 --> Total execution time: 1.0694
INFO - 2019-07-05 17:33:08 --> Config Class Initialized
INFO - 2019-07-05 17:33:08 --> Hooks Class Initialized
INFO - 2019-07-05 17:33:08 --> Config Class Initialized
DEBUG - 2019-07-05 17:33:08 --> UTF-8 Support Enabled
INFO - 2019-07-05 17:33:08 --> Hooks Class Initialized
INFO - 2019-07-05 17:33:08 --> Utf8 Class Initialized
DEBUG - 2019-07-05 17:33:08 --> UTF-8 Support Enabled
INFO - 2019-07-05 17:33:08 --> URI Class Initialized
INFO - 2019-07-05 17:33:08 --> Utf8 Class Initialized
INFO - 2019-07-05 17:33:08 --> URI Class Initialized
INFO - 2019-07-05 17:33:08 --> Router Class Initialized
INFO - 2019-07-05 17:33:08 --> Router Class Initialized
INFO - 2019-07-05 17:33:08 --> Output Class Initialized
INFO - 2019-07-05 17:33:08 --> Output Class Initialized
INFO - 2019-07-05 17:33:08 --> Security Class Initialized
INFO - 2019-07-05 17:33:08 --> Security Class Initialized
DEBUG - 2019-07-05 17:33:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-05 17:33:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-05 17:33:08 --> Input Class Initialized
INFO - 2019-07-05 17:33:08 --> Input Class Initialized
INFO - 2019-07-05 17:33:08 --> Language Class Initialized
INFO - 2019-07-05 17:33:08 --> Language Class Initialized
INFO - 2019-07-05 17:33:08 --> Language Class Initialized
INFO - 2019-07-05 17:33:08 --> Language Class Initialized
INFO - 2019-07-05 17:33:08 --> Config Class Initialized
INFO - 2019-07-05 17:33:08 --> Loader Class Initialized
INFO - 2019-07-05 17:33:08 --> Config Class Initialized
INFO - 2019-07-05 17:33:08 --> Loader Class Initialized
DEBUG - 2019-07-05 17:33:08 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-05 17:33:08 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-05 17:33:08 --> Helper loaded: url_helper
INFO - 2019-07-05 17:33:08 --> Helper loaded: url_helper
INFO - 2019-07-05 17:33:08 --> Helper loaded: inflector_helper
INFO - 2019-07-05 17:33:08 --> Helper loaded: inflector_helper
INFO - 2019-07-05 17:33:08 --> Helper loaded: string_helper
INFO - 2019-07-05 17:33:08 --> Helper loaded: string_helper
INFO - 2019-07-05 17:33:08 --> Helper loaded: array_helper
INFO - 2019-07-05 17:33:08 --> Helper loaded: array_helper
INFO - 2019-07-05 17:33:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-05 17:33:08 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-05 17:33:09 --> Database Driver Class Initialized
INFO - 2019-07-05 17:33:09 --> Controller Class Initialized
INFO - 2019-07-05 23:33:09 --> Helper loaded: language_helper
INFO - 2019-07-05 23:33:09 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-05 23:33:09 --> Model Class Initialized
INFO - 2019-07-05 23:33:09 --> Model Class Initialized
INFO - 2019-07-05 23:33:09 --> Model Class Initialized
INFO - 2019-07-05 23:33:09 --> Model Class Initialized
INFO - 2019-07-05 23:33:09 --> Helper loaded: form_helper
INFO - 2019-07-05 23:33:09 --> Form Validation Class Initialized
DEBUG - 2019-07-05 23:33:09 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-05 23:33:09 --> Model Class Initialized
INFO - 2019-07-05 23:33:09 --> Model Class Initialized
INFO - 2019-07-05 23:33:09 --> Final output sent to browser
DEBUG - 2019-07-05 23:33:09 --> Total execution time: 0.4131
INFO - 2019-07-05 17:33:09 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-05 17:33:09 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-05 17:33:09 --> Database Driver Class Initialized
INFO - 2019-07-05 17:33:09 --> Controller Class Initialized
INFO - 2019-07-05 23:33:09 --> Helper loaded: language_helper
INFO - 2019-07-05 23:33:09 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-05 23:33:09 --> Model Class Initialized
INFO - 2019-07-05 23:33:09 --> Model Class Initialized
INFO - 2019-07-05 23:33:09 --> Model Class Initialized
INFO - 2019-07-05 23:33:09 --> Model Class Initialized
INFO - 2019-07-05 23:33:09 --> Model Class Initialized
INFO - 2019-07-05 23:33:09 --> Final output sent to browser
DEBUG - 2019-07-05 23:33:09 --> Total execution time: 0.5345
INFO - 2019-07-05 17:33:10 --> Config Class Initialized
INFO - 2019-07-05 17:33:10 --> Config Class Initialized
INFO - 2019-07-05 17:33:10 --> Hooks Class Initialized
INFO - 2019-07-05 17:33:10 --> Hooks Class Initialized
DEBUG - 2019-07-05 17:33:10 --> UTF-8 Support Enabled
DEBUG - 2019-07-05 17:33:10 --> UTF-8 Support Enabled
INFO - 2019-07-05 17:33:10 --> Utf8 Class Initialized
INFO - 2019-07-05 17:33:10 --> Utf8 Class Initialized
INFO - 2019-07-05 17:33:10 --> URI Class Initialized
INFO - 2019-07-05 17:33:10 --> URI Class Initialized
INFO - 2019-07-05 17:33:10 --> Router Class Initialized
INFO - 2019-07-05 17:33:10 --> Router Class Initialized
INFO - 2019-07-05 17:33:10 --> Output Class Initialized
INFO - 2019-07-05 17:33:10 --> Output Class Initialized
INFO - 2019-07-05 17:33:10 --> Security Class Initialized
INFO - 2019-07-05 17:33:10 --> Security Class Initialized
DEBUG - 2019-07-05 17:33:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-05 17:33:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-05 17:33:10 --> Input Class Initialized
INFO - 2019-07-05 17:33:10 --> Input Class Initialized
INFO - 2019-07-05 17:33:10 --> Language Class Initialized
INFO - 2019-07-05 17:33:10 --> Language Class Initialized
INFO - 2019-07-05 17:33:10 --> Language Class Initialized
INFO - 2019-07-05 17:33:10 --> Language Class Initialized
INFO - 2019-07-05 17:33:10 --> Config Class Initialized
INFO - 2019-07-05 17:33:10 --> Config Class Initialized
INFO - 2019-07-05 17:33:10 --> Loader Class Initialized
INFO - 2019-07-05 17:33:10 --> Loader Class Initialized
DEBUG - 2019-07-05 17:33:10 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-05 17:33:10 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-05 17:33:10 --> Helper loaded: url_helper
INFO - 2019-07-05 17:33:10 --> Helper loaded: url_helper
INFO - 2019-07-05 17:33:10 --> Helper loaded: inflector_helper
INFO - 2019-07-05 17:33:10 --> Helper loaded: inflector_helper
INFO - 2019-07-05 17:33:10 --> Helper loaded: string_helper
INFO - 2019-07-05 17:33:10 --> Helper loaded: string_helper
INFO - 2019-07-05 17:33:10 --> Helper loaded: array_helper
INFO - 2019-07-05 17:33:10 --> Helper loaded: array_helper
INFO - 2019-07-05 17:33:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-05 17:33:10 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-05 17:33:10 --> Database Driver Class Initialized
INFO - 2019-07-05 17:33:10 --> Controller Class Initialized
INFO - 2019-07-05 23:33:10 --> Helper loaded: language_helper
INFO - 2019-07-05 23:33:10 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-05 23:33:10 --> Model Class Initialized
INFO - 2019-07-05 23:33:10 --> Model Class Initialized
INFO - 2019-07-05 23:33:10 --> Model Class Initialized
INFO - 2019-07-05 23:33:10 --> Model Class Initialized
INFO - 2019-07-05 23:33:10 --> Model Class Initialized
INFO - 2019-07-05 23:33:10 --> Final output sent to browser
DEBUG - 2019-07-05 23:33:10 --> Total execution time: 0.4022
INFO - 2019-07-05 17:33:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-05 17:33:10 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-05 17:33:10 --> Database Driver Class Initialized
INFO - 2019-07-05 17:33:10 --> Controller Class Initialized
INFO - 2019-07-05 23:33:10 --> Helper loaded: language_helper
INFO - 2019-07-05 23:33:10 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-05 23:33:10 --> Model Class Initialized
INFO - 2019-07-05 23:33:10 --> Model Class Initialized
INFO - 2019-07-05 23:33:10 --> Model Class Initialized
INFO - 2019-07-05 23:33:10 --> Model Class Initialized
INFO - 2019-07-05 23:33:10 --> Helper loaded: form_helper
INFO - 2019-07-05 23:33:10 --> Form Validation Class Initialized
DEBUG - 2019-07-05 23:33:10 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-05 23:33:10 --> Model Class Initialized
INFO - 2019-07-05 23:33:10 --> Model Class Initialized
INFO - 2019-07-05 23:33:10 --> Final output sent to browser
DEBUG - 2019-07-05 23:33:10 --> Total execution time: 0.5515
INFO - 2019-07-05 17:33:58 --> Config Class Initialized
INFO - 2019-07-05 17:33:58 --> Hooks Class Initialized
INFO - 2019-07-05 17:33:58 --> Config Class Initialized
DEBUG - 2019-07-05 17:33:58 --> UTF-8 Support Enabled
INFO - 2019-07-05 17:33:58 --> Hooks Class Initialized
INFO - 2019-07-05 17:33:58 --> Utf8 Class Initialized
DEBUG - 2019-07-05 17:33:58 --> UTF-8 Support Enabled
INFO - 2019-07-05 17:33:58 --> URI Class Initialized
INFO - 2019-07-05 17:33:58 --> Utf8 Class Initialized
INFO - 2019-07-05 17:33:58 --> URI Class Initialized
INFO - 2019-07-05 17:33:58 --> Router Class Initialized
INFO - 2019-07-05 17:33:58 --> Router Class Initialized
INFO - 2019-07-05 17:33:58 --> Output Class Initialized
INFO - 2019-07-05 17:33:58 --> Output Class Initialized
INFO - 2019-07-05 17:33:58 --> Security Class Initialized
INFO - 2019-07-05 17:33:58 --> Security Class Initialized
DEBUG - 2019-07-05 17:33:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-05 17:33:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-05 17:33:58 --> Input Class Initialized
INFO - 2019-07-05 17:33:58 --> Input Class Initialized
INFO - 2019-07-05 17:33:58 --> Language Class Initialized
INFO - 2019-07-05 17:33:58 --> Language Class Initialized
INFO - 2019-07-05 17:33:58 --> Language Class Initialized
INFO - 2019-07-05 17:33:58 --> Config Class Initialized
INFO - 2019-07-05 17:33:58 --> Language Class Initialized
INFO - 2019-07-05 17:33:58 --> Config Class Initialized
INFO - 2019-07-05 17:33:58 --> Loader Class Initialized
INFO - 2019-07-05 17:33:58 --> Loader Class Initialized
DEBUG - 2019-07-05 17:33:58 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-05 17:33:58 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-05 17:33:58 --> Helper loaded: url_helper
INFO - 2019-07-05 17:33:58 --> Helper loaded: url_helper
INFO - 2019-07-05 17:33:58 --> Helper loaded: inflector_helper
INFO - 2019-07-05 17:33:58 --> Helper loaded: inflector_helper
INFO - 2019-07-05 17:33:58 --> Helper loaded: string_helper
INFO - 2019-07-05 17:33:58 --> Helper loaded: string_helper
INFO - 2019-07-05 17:33:58 --> Helper loaded: array_helper
INFO - 2019-07-05 17:33:58 --> Helper loaded: array_helper
INFO - 2019-07-05 17:33:58 --> Session: Class initialized using 'files' driver.
INFO - 2019-07-05 17:33:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-05 17:33:58 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
DEBUG - 2019-07-05 17:33:58 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-05 17:33:58 --> Database Driver Class Initialized
INFO - 2019-07-05 17:33:58 --> Database Driver Class Initialized
INFO - 2019-07-05 17:33:58 --> Controller Class Initialized
INFO - 2019-07-05 17:33:58 --> Controller Class Initialized
INFO - 2019-07-05 23:33:58 --> Helper loaded: language_helper
INFO - 2019-07-05 23:33:58 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-05 23:33:58 --> Helper loaded: language_helper
INFO - 2019-07-05 23:33:58 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-05 23:33:58 --> Model Class Initialized
INFO - 2019-07-05 23:33:58 --> Model Class Initialized
INFO - 2019-07-05 23:33:58 --> Model Class Initialized
INFO - 2019-07-05 23:33:58 --> Model Class Initialized
INFO - 2019-07-05 23:33:58 --> Model Class Initialized
INFO - 2019-07-05 23:33:58 --> Model Class Initialized
INFO - 2019-07-05 23:33:58 --> Model Class Initialized
INFO - 2019-07-05 23:33:58 --> Model Class Initialized
INFO - 2019-07-05 23:33:58 --> Model Class Initialized
INFO - 2019-07-05 23:33:58 --> Helper loaded: form_helper
INFO - 2019-07-05 23:33:58 --> Form Validation Class Initialized
INFO - 2019-07-05 23:33:58 --> Final output sent to browser
DEBUG - 2019-07-05 23:33:58 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
DEBUG - 2019-07-05 23:33:58 --> Total execution time: 0.4644
INFO - 2019-07-05 23:33:58 --> Model Class Initialized
INFO - 2019-07-05 23:33:58 --> Model Class Initialized
INFO - 2019-07-05 23:33:58 --> Final output sent to browser
DEBUG - 2019-07-05 23:33:58 --> Total execution time: 0.4537
INFO - 2019-07-05 17:34:20 --> Config Class Initialized
INFO - 2019-07-05 17:34:20 --> Hooks Class Initialized
DEBUG - 2019-07-05 17:34:20 --> UTF-8 Support Enabled
INFO - 2019-07-05 17:34:20 --> Utf8 Class Initialized
INFO - 2019-07-05 17:34:20 --> URI Class Initialized
INFO - 2019-07-05 17:34:20 --> Router Class Initialized
INFO - 2019-07-05 17:34:20 --> Output Class Initialized
INFO - 2019-07-05 17:34:20 --> Security Class Initialized
DEBUG - 2019-07-05 17:34:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-05 17:34:20 --> Input Class Initialized
INFO - 2019-07-05 17:34:20 --> Language Class Initialized
INFO - 2019-07-05 17:34:20 --> Language Class Initialized
INFO - 2019-07-05 17:34:20 --> Config Class Initialized
INFO - 2019-07-05 17:34:20 --> Loader Class Initialized
DEBUG - 2019-07-05 17:34:20 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-05 17:34:20 --> Helper loaded: url_helper
INFO - 2019-07-05 17:34:20 --> Helper loaded: inflector_helper
INFO - 2019-07-05 17:34:20 --> Helper loaded: string_helper
INFO - 2019-07-05 17:34:20 --> Helper loaded: array_helper
INFO - 2019-07-05 17:34:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-05 17:34:20 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-05 17:34:20 --> Database Driver Class Initialized
INFO - 2019-07-05 17:34:20 --> Controller Class Initialized
INFO - 2019-07-05 23:34:21 --> Helper loaded: language_helper
INFO - 2019-07-05 23:34:21 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-05 23:34:21 --> Model Class Initialized
INFO - 2019-07-05 23:34:21 --> Model Class Initialized
INFO - 2019-07-05 23:34:21 --> Model Class Initialized
INFO - 2019-07-05 23:34:21 --> Model Class Initialized
INFO - 2019-07-05 23:34:21 --> Model Class Initialized
INFO - 2019-07-05 23:34:21 --> Final output sent to browser
DEBUG - 2019-07-05 23:34:21 --> Total execution time: 0.2927
INFO - 2019-07-05 17:34:35 --> Config Class Initialized
INFO - 2019-07-05 17:34:35 --> Config Class Initialized
INFO - 2019-07-05 17:34:35 --> Hooks Class Initialized
INFO - 2019-07-05 17:34:35 --> Hooks Class Initialized
DEBUG - 2019-07-05 17:34:35 --> UTF-8 Support Enabled
DEBUG - 2019-07-05 17:34:35 --> UTF-8 Support Enabled
INFO - 2019-07-05 17:34:35 --> Utf8 Class Initialized
INFO - 2019-07-05 17:34:35 --> Utf8 Class Initialized
INFO - 2019-07-05 17:34:35 --> URI Class Initialized
INFO - 2019-07-05 17:34:35 --> URI Class Initialized
INFO - 2019-07-05 17:34:35 --> Router Class Initialized
INFO - 2019-07-05 17:34:35 --> Router Class Initialized
INFO - 2019-07-05 17:34:35 --> Output Class Initialized
INFO - 2019-07-05 17:34:35 --> Output Class Initialized
INFO - 2019-07-05 17:34:35 --> Security Class Initialized
INFO - 2019-07-05 17:34:35 --> Security Class Initialized
DEBUG - 2019-07-05 17:34:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-05 17:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-05 17:34:35 --> Input Class Initialized
INFO - 2019-07-05 17:34:35 --> Input Class Initialized
INFO - 2019-07-05 17:34:35 --> Language Class Initialized
INFO - 2019-07-05 17:34:35 --> Language Class Initialized
INFO - 2019-07-05 17:34:35 --> Language Class Initialized
INFO - 2019-07-05 17:34:35 --> Language Class Initialized
INFO - 2019-07-05 17:34:35 --> Config Class Initialized
INFO - 2019-07-05 17:34:35 --> Loader Class Initialized
INFO - 2019-07-05 17:34:35 --> Config Class Initialized
INFO - 2019-07-05 17:34:35 --> Loader Class Initialized
DEBUG - 2019-07-05 17:34:35 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-05 17:34:35 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-05 17:34:35 --> Helper loaded: url_helper
INFO - 2019-07-05 17:34:35 --> Helper loaded: url_helper
INFO - 2019-07-05 17:34:35 --> Helper loaded: inflector_helper
INFO - 2019-07-05 17:34:35 --> Helper loaded: inflector_helper
INFO - 2019-07-05 17:34:35 --> Helper loaded: string_helper
INFO - 2019-07-05 17:34:35 --> Helper loaded: string_helper
INFO - 2019-07-05 17:34:35 --> Helper loaded: array_helper
INFO - 2019-07-05 17:34:35 --> Helper loaded: array_helper
INFO - 2019-07-05 17:34:35 --> Session: Class initialized using 'files' driver.
INFO - 2019-07-05 17:34:35 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-05 17:34:35 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
DEBUG - 2019-07-05 17:34:35 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-05 17:34:35 --> Database Driver Class Initialized
INFO - 2019-07-05 17:34:35 --> Database Driver Class Initialized
INFO - 2019-07-05 17:34:35 --> Controller Class Initialized
INFO - 2019-07-05 17:34:35 --> Controller Class Initialized
INFO - 2019-07-05 23:34:35 --> Helper loaded: language_helper
INFO - 2019-07-05 23:34:35 --> Helper loaded: language_helper
INFO - 2019-07-05 23:34:35 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-05 23:34:35 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-05 23:34:35 --> Model Class Initialized
INFO - 2019-07-05 23:34:35 --> Model Class Initialized
INFO - 2019-07-05 23:34:35 --> Model Class Initialized
INFO - 2019-07-05 23:34:35 --> Model Class Initialized
INFO - 2019-07-05 23:34:35 --> Model Class Initialized
INFO - 2019-07-05 23:34:35 --> Model Class Initialized
INFO - 2019-07-05 23:34:35 --> Model Class Initialized
INFO - 2019-07-05 23:34:35 --> Model Class Initialized
INFO - 2019-07-05 23:34:35 --> Model Class Initialized
INFO - 2019-07-05 23:34:35 --> Helper loaded: form_helper
INFO - 2019-07-05 23:34:35 --> Form Validation Class Initialized
INFO - 2019-07-05 23:34:35 --> Final output sent to browser
DEBUG - 2019-07-05 23:34:35 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
DEBUG - 2019-07-05 23:34:35 --> Total execution time: 0.4542
INFO - 2019-07-05 23:34:35 --> Model Class Initialized
INFO - 2019-07-05 23:34:35 --> Model Class Initialized
INFO - 2019-07-05 23:34:35 --> Final output sent to browser
DEBUG - 2019-07-05 23:34:35 --> Total execution time: 0.4781
INFO - 2019-07-05 17:35:23 --> Config Class Initialized
INFO - 2019-07-05 17:35:23 --> Config Class Initialized
INFO - 2019-07-05 17:35:23 --> Hooks Class Initialized
INFO - 2019-07-05 17:35:23 --> Hooks Class Initialized
DEBUG - 2019-07-05 17:35:23 --> UTF-8 Support Enabled
DEBUG - 2019-07-05 17:35:23 --> UTF-8 Support Enabled
INFO - 2019-07-05 17:35:23 --> Utf8 Class Initialized
INFO - 2019-07-05 17:35:23 --> Utf8 Class Initialized
INFO - 2019-07-05 17:35:23 --> URI Class Initialized
INFO - 2019-07-05 17:35:23 --> URI Class Initialized
INFO - 2019-07-05 17:35:23 --> Router Class Initialized
INFO - 2019-07-05 17:35:23 --> Router Class Initialized
INFO - 2019-07-05 17:35:23 --> Output Class Initialized
INFO - 2019-07-05 17:35:23 --> Output Class Initialized
INFO - 2019-07-05 17:35:23 --> Security Class Initialized
INFO - 2019-07-05 17:35:23 --> Security Class Initialized
DEBUG - 2019-07-05 17:35:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-05 17:35:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-05 17:35:23 --> Input Class Initialized
INFO - 2019-07-05 17:35:23 --> Input Class Initialized
INFO - 2019-07-05 17:35:23 --> Language Class Initialized
INFO - 2019-07-05 17:35:23 --> Language Class Initialized
INFO - 2019-07-05 17:35:23 --> Language Class Initialized
INFO - 2019-07-05 17:35:23 --> Language Class Initialized
INFO - 2019-07-05 17:35:23 --> Config Class Initialized
INFO - 2019-07-05 17:35:23 --> Config Class Initialized
INFO - 2019-07-05 17:35:23 --> Loader Class Initialized
INFO - 2019-07-05 17:35:23 --> Loader Class Initialized
DEBUG - 2019-07-05 17:35:23 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-05 17:35:23 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-05 17:35:23 --> Helper loaded: url_helper
INFO - 2019-07-05 17:35:23 --> Helper loaded: url_helper
INFO - 2019-07-05 17:35:23 --> Helper loaded: inflector_helper
INFO - 2019-07-05 17:35:23 --> Helper loaded: inflector_helper
INFO - 2019-07-05 17:35:23 --> Helper loaded: string_helper
INFO - 2019-07-05 17:35:23 --> Helper loaded: string_helper
INFO - 2019-07-05 17:35:23 --> Helper loaded: array_helper
INFO - 2019-07-05 17:35:23 --> Helper loaded: array_helper
INFO - 2019-07-05 17:35:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-05 17:35:23 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-05 17:35:23 --> Database Driver Class Initialized
INFO - 2019-07-05 17:35:23 --> Controller Class Initialized
INFO - 2019-07-05 23:35:23 --> Helper loaded: language_helper
INFO - 2019-07-05 23:35:23 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-05 23:35:23 --> Model Class Initialized
INFO - 2019-07-05 23:35:23 --> Model Class Initialized
INFO - 2019-07-05 23:35:23 --> Model Class Initialized
INFO - 2019-07-05 23:35:23 --> Model Class Initialized
INFO - 2019-07-05 23:35:23 --> Model Class Initialized
INFO - 2019-07-05 23:35:23 --> Final output sent to browser
DEBUG - 2019-07-05 23:35:23 --> Total execution time: 0.3792
INFO - 2019-07-05 17:35:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-05 17:35:23 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-05 17:35:23 --> Database Driver Class Initialized
INFO - 2019-07-05 17:35:23 --> Controller Class Initialized
INFO - 2019-07-05 23:35:23 --> Helper loaded: language_helper
INFO - 2019-07-05 23:35:24 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-05 23:35:24 --> Model Class Initialized
INFO - 2019-07-05 23:35:24 --> Model Class Initialized
INFO - 2019-07-05 23:35:24 --> Model Class Initialized
INFO - 2019-07-05 23:35:24 --> Model Class Initialized
INFO - 2019-07-05 23:35:24 --> Helper loaded: form_helper
INFO - 2019-07-05 23:35:24 --> Form Validation Class Initialized
DEBUG - 2019-07-05 23:35:24 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-05 23:35:24 --> Model Class Initialized
INFO - 2019-07-05 23:35:24 --> Model Class Initialized
INFO - 2019-07-05 23:35:24 --> Final output sent to browser
DEBUG - 2019-07-05 23:35:24 --> Total execution time: 0.5162
INFO - 2019-07-05 17:35:26 --> Config Class Initialized
INFO - 2019-07-05 17:35:26 --> Config Class Initialized
INFO - 2019-07-05 17:35:26 --> Hooks Class Initialized
INFO - 2019-07-05 17:35:26 --> Hooks Class Initialized
DEBUG - 2019-07-05 17:35:26 --> UTF-8 Support Enabled
INFO - 2019-07-05 17:35:26 --> Utf8 Class Initialized
DEBUG - 2019-07-05 17:35:26 --> UTF-8 Support Enabled
INFO - 2019-07-05 17:35:26 --> Utf8 Class Initialized
INFO - 2019-07-05 17:35:26 --> URI Class Initialized
INFO - 2019-07-05 17:35:26 --> URI Class Initialized
INFO - 2019-07-05 17:35:26 --> Router Class Initialized
INFO - 2019-07-05 17:35:26 --> Router Class Initialized
INFO - 2019-07-05 17:35:26 --> Output Class Initialized
INFO - 2019-07-05 17:35:26 --> Output Class Initialized
INFO - 2019-07-05 17:35:26 --> Security Class Initialized
INFO - 2019-07-05 17:35:26 --> Security Class Initialized
DEBUG - 2019-07-05 17:35:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-05 17:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-05 17:35:26 --> Input Class Initialized
INFO - 2019-07-05 17:35:26 --> Input Class Initialized
INFO - 2019-07-05 17:35:26 --> Language Class Initialized
INFO - 2019-07-05 17:35:26 --> Language Class Initialized
INFO - 2019-07-05 17:35:26 --> Language Class Initialized
INFO - 2019-07-05 17:35:26 --> Language Class Initialized
INFO - 2019-07-05 17:35:26 --> Config Class Initialized
INFO - 2019-07-05 17:35:26 --> Config Class Initialized
INFO - 2019-07-05 17:35:26 --> Loader Class Initialized
INFO - 2019-07-05 17:35:26 --> Loader Class Initialized
DEBUG - 2019-07-05 17:35:26 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-05 17:35:27 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-05 17:35:27 --> Helper loaded: url_helper
INFO - 2019-07-05 17:35:27 --> Helper loaded: url_helper
INFO - 2019-07-05 17:35:27 --> Helper loaded: inflector_helper
INFO - 2019-07-05 17:35:27 --> Helper loaded: inflector_helper
INFO - 2019-07-05 17:35:27 --> Helper loaded: string_helper
INFO - 2019-07-05 17:35:27 --> Helper loaded: string_helper
INFO - 2019-07-05 17:35:27 --> Helper loaded: array_helper
INFO - 2019-07-05 17:35:27 --> Helper loaded: array_helper
INFO - 2019-07-05 17:35:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-05 17:35:27 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-05 17:35:27 --> Database Driver Class Initialized
INFO - 2019-07-05 17:35:27 --> Controller Class Initialized
INFO - 2019-07-05 23:35:27 --> Helper loaded: language_helper
INFO - 2019-07-05 23:35:27 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-05 23:35:27 --> Model Class Initialized
INFO - 2019-07-05 23:35:27 --> Model Class Initialized
INFO - 2019-07-05 23:35:27 --> Model Class Initialized
INFO - 2019-07-05 23:35:27 --> Model Class Initialized
INFO - 2019-07-05 23:35:27 --> Model Class Initialized
INFO - 2019-07-05 23:35:27 --> Final output sent to browser
DEBUG - 2019-07-05 23:35:27 --> Total execution time: 0.4157
INFO - 2019-07-05 17:35:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-05 17:35:27 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-05 17:35:27 --> Database Driver Class Initialized
INFO - 2019-07-05 17:35:27 --> Controller Class Initialized
INFO - 2019-07-05 23:35:27 --> Helper loaded: language_helper
INFO - 2019-07-05 23:35:27 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-05 23:35:27 --> Model Class Initialized
INFO - 2019-07-05 23:35:27 --> Model Class Initialized
INFO - 2019-07-05 23:35:27 --> Model Class Initialized
INFO - 2019-07-05 23:35:27 --> Model Class Initialized
INFO - 2019-07-05 23:35:27 --> Helper loaded: form_helper
INFO - 2019-07-05 23:35:27 --> Form Validation Class Initialized
DEBUG - 2019-07-05 23:35:27 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-05 23:35:27 --> Model Class Initialized
INFO - 2019-07-05 23:35:27 --> Model Class Initialized
INFO - 2019-07-05 23:35:27 --> Final output sent to browser
DEBUG - 2019-07-05 23:35:27 --> Total execution time: 0.5733
INFO - 2019-07-05 17:35:50 --> Config Class Initialized
INFO - 2019-07-05 17:35:50 --> Config Class Initialized
INFO - 2019-07-05 17:35:50 --> Hooks Class Initialized
INFO - 2019-07-05 17:35:50 --> Hooks Class Initialized
DEBUG - 2019-07-05 17:35:50 --> UTF-8 Support Enabled
DEBUG - 2019-07-05 17:35:50 --> UTF-8 Support Enabled
INFO - 2019-07-05 17:35:50 --> Utf8 Class Initialized
INFO - 2019-07-05 17:35:51 --> Utf8 Class Initialized
INFO - 2019-07-05 17:35:51 --> URI Class Initialized
INFO - 2019-07-05 17:35:51 --> URI Class Initialized
INFO - 2019-07-05 17:35:51 --> Router Class Initialized
INFO - 2019-07-05 17:35:51 --> Router Class Initialized
INFO - 2019-07-05 17:35:51 --> Output Class Initialized
INFO - 2019-07-05 17:35:51 --> Output Class Initialized
INFO - 2019-07-05 17:35:51 --> Security Class Initialized
INFO - 2019-07-05 17:35:51 --> Security Class Initialized
DEBUG - 2019-07-05 17:35:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-05 17:35:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-05 17:35:51 --> Input Class Initialized
INFO - 2019-07-05 17:35:51 --> Input Class Initialized
INFO - 2019-07-05 17:35:51 --> Language Class Initialized
INFO - 2019-07-05 17:35:51 --> Language Class Initialized
INFO - 2019-07-05 17:35:51 --> Language Class Initialized
INFO - 2019-07-05 17:35:51 --> Language Class Initialized
INFO - 2019-07-05 17:35:51 --> Config Class Initialized
INFO - 2019-07-05 17:35:51 --> Config Class Initialized
INFO - 2019-07-05 17:35:51 --> Loader Class Initialized
INFO - 2019-07-05 17:35:51 --> Loader Class Initialized
DEBUG - 2019-07-05 17:35:51 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-05 17:35:51 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-05 17:35:51 --> Helper loaded: url_helper
INFO - 2019-07-05 17:35:51 --> Helper loaded: url_helper
INFO - 2019-07-05 17:35:51 --> Helper loaded: inflector_helper
INFO - 2019-07-05 17:35:51 --> Helper loaded: inflector_helper
INFO - 2019-07-05 17:35:51 --> Helper loaded: string_helper
INFO - 2019-07-05 17:35:51 --> Helper loaded: string_helper
INFO - 2019-07-05 17:35:51 --> Helper loaded: array_helper
INFO - 2019-07-05 17:35:51 --> Helper loaded: array_helper
INFO - 2019-07-05 17:35:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-05 17:35:51 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-05 17:35:51 --> Database Driver Class Initialized
INFO - 2019-07-05 17:35:51 --> Controller Class Initialized
INFO - 2019-07-05 23:35:51 --> Helper loaded: language_helper
INFO - 2019-07-05 23:35:51 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-05 23:35:51 --> Model Class Initialized
INFO - 2019-07-05 23:35:51 --> Model Class Initialized
INFO - 2019-07-05 23:35:51 --> Model Class Initialized
INFO - 2019-07-05 23:35:51 --> Model Class Initialized
INFO - 2019-07-05 23:35:51 --> Model Class Initialized
INFO - 2019-07-05 23:35:51 --> Final output sent to browser
DEBUG - 2019-07-05 23:35:51 --> Total execution time: 0.3918
INFO - 2019-07-05 17:35:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-05 17:35:51 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-05 17:35:51 --> Database Driver Class Initialized
INFO - 2019-07-05 17:35:51 --> Controller Class Initialized
INFO - 2019-07-05 23:35:51 --> Helper loaded: language_helper
INFO - 2019-07-05 23:35:51 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-05 23:35:51 --> Model Class Initialized
INFO - 2019-07-05 23:35:51 --> Model Class Initialized
INFO - 2019-07-05 23:35:51 --> Model Class Initialized
INFO - 2019-07-05 23:35:51 --> Model Class Initialized
INFO - 2019-07-05 23:35:51 --> Helper loaded: form_helper
INFO - 2019-07-05 23:35:51 --> Form Validation Class Initialized
DEBUG - 2019-07-05 23:35:51 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-05 23:35:51 --> Model Class Initialized
INFO - 2019-07-05 23:35:51 --> Model Class Initialized
INFO - 2019-07-05 23:35:51 --> Final output sent to browser
DEBUG - 2019-07-05 23:35:51 --> Total execution time: 0.5699
INFO - 2019-07-05 17:35:53 --> Config Class Initialized
INFO - 2019-07-05 17:35:53 --> Config Class Initialized
INFO - 2019-07-05 17:35:53 --> Hooks Class Initialized
INFO - 2019-07-05 17:35:53 --> Hooks Class Initialized
DEBUG - 2019-07-05 17:35:53 --> UTF-8 Support Enabled
INFO - 2019-07-05 17:35:53 --> Utf8 Class Initialized
DEBUG - 2019-07-05 17:35:53 --> UTF-8 Support Enabled
INFO - 2019-07-05 17:35:53 --> Utf8 Class Initialized
INFO - 2019-07-05 17:35:53 --> URI Class Initialized
INFO - 2019-07-05 17:35:53 --> URI Class Initialized
INFO - 2019-07-05 17:35:53 --> Router Class Initialized
INFO - 2019-07-05 17:35:53 --> Router Class Initialized
INFO - 2019-07-05 17:35:53 --> Output Class Initialized
INFO - 2019-07-05 17:35:53 --> Output Class Initialized
INFO - 2019-07-05 17:35:53 --> Security Class Initialized
INFO - 2019-07-05 17:35:53 --> Security Class Initialized
DEBUG - 2019-07-05 17:35:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-05 17:35:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-05 17:35:53 --> Input Class Initialized
INFO - 2019-07-05 17:35:53 --> Input Class Initialized
INFO - 2019-07-05 17:35:53 --> Language Class Initialized
INFO - 2019-07-05 17:35:53 --> Language Class Initialized
INFO - 2019-07-05 17:35:53 --> Language Class Initialized
INFO - 2019-07-05 17:35:53 --> Language Class Initialized
INFO - 2019-07-05 17:35:53 --> Config Class Initialized
INFO - 2019-07-05 17:35:53 --> Config Class Initialized
INFO - 2019-07-05 17:35:53 --> Loader Class Initialized
INFO - 2019-07-05 17:35:53 --> Loader Class Initialized
DEBUG - 2019-07-05 17:35:53 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-05 17:35:53 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-05 17:35:53 --> Helper loaded: url_helper
INFO - 2019-07-05 17:35:53 --> Helper loaded: url_helper
INFO - 2019-07-05 17:35:53 --> Helper loaded: inflector_helper
INFO - 2019-07-05 17:35:53 --> Helper loaded: inflector_helper
INFO - 2019-07-05 17:35:53 --> Helper loaded: string_helper
INFO - 2019-07-05 17:35:53 --> Helper loaded: string_helper
INFO - 2019-07-05 17:35:53 --> Helper loaded: array_helper
INFO - 2019-07-05 17:35:53 --> Helper loaded: array_helper
INFO - 2019-07-05 17:35:53 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-05 17:35:53 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-05 17:35:53 --> Database Driver Class Initialized
INFO - 2019-07-05 17:35:53 --> Controller Class Initialized
INFO - 2019-07-05 23:35:53 --> Helper loaded: language_helper
INFO - 2019-07-05 23:35:53 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-05 23:35:53 --> Model Class Initialized
INFO - 2019-07-05 23:35:53 --> Model Class Initialized
INFO - 2019-07-05 23:35:53 --> Model Class Initialized
INFO - 2019-07-05 23:35:53 --> Model Class Initialized
INFO - 2019-07-05 23:35:53 --> Model Class Initialized
INFO - 2019-07-05 23:35:53 --> Final output sent to browser
DEBUG - 2019-07-05 23:35:53 --> Total execution time: 0.4276
INFO - 2019-07-05 17:35:53 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-05 17:35:53 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-05 17:35:53 --> Database Driver Class Initialized
INFO - 2019-07-05 17:35:53 --> Controller Class Initialized
INFO - 2019-07-05 23:35:53 --> Helper loaded: language_helper
INFO - 2019-07-05 23:35:53 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-05 23:35:53 --> Model Class Initialized
INFO - 2019-07-05 23:35:53 --> Model Class Initialized
INFO - 2019-07-05 23:35:53 --> Model Class Initialized
INFO - 2019-07-05 23:35:53 --> Model Class Initialized
INFO - 2019-07-05 23:35:53 --> Helper loaded: form_helper
INFO - 2019-07-05 23:35:53 --> Form Validation Class Initialized
DEBUG - 2019-07-05 23:35:53 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-05 23:35:53 --> Model Class Initialized
INFO - 2019-07-05 23:35:53 --> Model Class Initialized
INFO - 2019-07-05 23:35:53 --> Final output sent to browser
DEBUG - 2019-07-05 23:35:53 --> Total execution time: 0.5647
INFO - 2019-07-05 17:36:04 --> Config Class Initialized
INFO - 2019-07-05 17:36:04 --> Hooks Class Initialized
INFO - 2019-07-05 17:36:04 --> Config Class Initialized
DEBUG - 2019-07-05 17:36:04 --> UTF-8 Support Enabled
INFO - 2019-07-05 17:36:04 --> Utf8 Class Initialized
INFO - 2019-07-05 17:36:04 --> URI Class Initialized
INFO - 2019-07-05 17:36:04 --> Router Class Initialized
INFO - 2019-07-05 17:36:04 --> Hooks Class Initialized
INFO - 2019-07-05 17:36:04 --> Output Class Initialized
DEBUG - 2019-07-05 17:36:04 --> UTF-8 Support Enabled
INFO - 2019-07-05 17:36:04 --> Utf8 Class Initialized
INFO - 2019-07-05 17:36:04 --> URI Class Initialized
INFO - 2019-07-05 17:36:04 --> Security Class Initialized
INFO - 2019-07-05 17:36:04 --> Router Class Initialized
DEBUG - 2019-07-05 17:36:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-05 17:36:04 --> Output Class Initialized
INFO - 2019-07-05 17:36:04 --> Input Class Initialized
INFO - 2019-07-05 17:36:04 --> Language Class Initialized
INFO - 2019-07-05 17:36:04 --> Security Class Initialized
INFO - 2019-07-05 17:36:04 --> Language Class Initialized
DEBUG - 2019-07-05 17:36:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-05 17:36:04 --> Config Class Initialized
INFO - 2019-07-05 17:36:04 --> Input Class Initialized
INFO - 2019-07-05 17:36:04 --> Loader Class Initialized
INFO - 2019-07-05 17:36:04 --> Language Class Initialized
DEBUG - 2019-07-05 17:36:05 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-05 17:36:05 --> Language Class Initialized
INFO - 2019-07-05 17:36:05 --> Helper loaded: url_helper
INFO - 2019-07-05 17:36:05 --> Config Class Initialized
INFO - 2019-07-05 17:36:05 --> Loader Class Initialized
INFO - 2019-07-05 17:36:05 --> Helper loaded: inflector_helper
DEBUG - 2019-07-05 17:36:05 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-05 17:36:05 --> Helper loaded: string_helper
INFO - 2019-07-05 17:36:05 --> Helper loaded: url_helper
INFO - 2019-07-05 17:36:05 --> Helper loaded: array_helper
INFO - 2019-07-05 17:36:05 --> Helper loaded: inflector_helper
INFO - 2019-07-05 17:36:05 --> Session: Class initialized using 'files' driver.
INFO - 2019-07-05 17:36:05 --> Helper loaded: string_helper
DEBUG - 2019-07-05 17:36:05 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-05 17:36:05 --> Helper loaded: array_helper
INFO - 2019-07-05 17:36:05 --> Database Driver Class Initialized
INFO - 2019-07-05 17:36:05 --> Controller Class Initialized
INFO - 2019-07-05 23:36:05 --> Helper loaded: language_helper
INFO - 2019-07-05 23:36:05 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-05 23:36:05 --> Model Class Initialized
INFO - 2019-07-05 23:36:05 --> Model Class Initialized
INFO - 2019-07-05 23:36:05 --> Model Class Initialized
INFO - 2019-07-05 23:36:05 --> Model Class Initialized
INFO - 2019-07-05 23:36:05 --> Helper loaded: form_helper
INFO - 2019-07-05 23:36:05 --> Form Validation Class Initialized
DEBUG - 2019-07-05 23:36:05 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-05 23:36:05 --> Model Class Initialized
INFO - 2019-07-05 23:36:05 --> Model Class Initialized
INFO - 2019-07-05 23:36:05 --> Final output sent to browser
DEBUG - 2019-07-05 23:36:05 --> Total execution time: 0.4946
INFO - 2019-07-05 17:36:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-05 17:36:05 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-05 17:36:05 --> Database Driver Class Initialized
INFO - 2019-07-05 17:36:05 --> Controller Class Initialized
INFO - 2019-07-05 23:36:05 --> Helper loaded: language_helper
INFO - 2019-07-05 23:36:05 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-05 23:36:05 --> Model Class Initialized
INFO - 2019-07-05 23:36:05 --> Model Class Initialized
INFO - 2019-07-05 23:36:05 --> Model Class Initialized
INFO - 2019-07-05 23:36:05 --> Model Class Initialized
INFO - 2019-07-05 23:36:05 --> Model Class Initialized
INFO - 2019-07-05 23:36:05 --> Final output sent to browser
DEBUG - 2019-07-05 23:36:05 --> Total execution time: 0.6216
INFO - 2019-07-05 17:36:08 --> Config Class Initialized
INFO - 2019-07-05 17:36:08 --> Hooks Class Initialized
INFO - 2019-07-05 17:36:08 --> Config Class Initialized
DEBUG - 2019-07-05 17:36:08 --> UTF-8 Support Enabled
INFO - 2019-07-05 17:36:08 --> Hooks Class Initialized
INFO - 2019-07-05 17:36:08 --> Utf8 Class Initialized
DEBUG - 2019-07-05 17:36:08 --> UTF-8 Support Enabled
INFO - 2019-07-05 17:36:08 --> URI Class Initialized
INFO - 2019-07-05 17:36:08 --> Utf8 Class Initialized
INFO - 2019-07-05 17:36:08 --> Router Class Initialized
INFO - 2019-07-05 17:36:09 --> URI Class Initialized
INFO - 2019-07-05 17:36:09 --> Output Class Initialized
INFO - 2019-07-05 17:36:09 --> Router Class Initialized
INFO - 2019-07-05 17:36:09 --> Security Class Initialized
INFO - 2019-07-05 17:36:09 --> Output Class Initialized
DEBUG - 2019-07-05 17:36:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-05 17:36:09 --> Security Class Initialized
INFO - 2019-07-05 17:36:09 --> Input Class Initialized
INFO - 2019-07-05 17:36:09 --> Language Class Initialized
DEBUG - 2019-07-05 17:36:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-05 17:36:09 --> Language Class Initialized
INFO - 2019-07-05 17:36:09 --> Input Class Initialized
INFO - 2019-07-05 17:36:09 --> Config Class Initialized
INFO - 2019-07-05 17:36:09 --> Language Class Initialized
INFO - 2019-07-05 17:36:09 --> Loader Class Initialized
DEBUG - 2019-07-05 17:36:09 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-05 17:36:09 --> Language Class Initialized
INFO - 2019-07-05 17:36:09 --> Helper loaded: url_helper
INFO - 2019-07-05 17:36:09 --> Config Class Initialized
INFO - 2019-07-05 17:36:09 --> Loader Class Initialized
INFO - 2019-07-05 17:36:09 --> Helper loaded: inflector_helper
DEBUG - 2019-07-05 17:36:09 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-05 17:36:09 --> Helper loaded: string_helper
INFO - 2019-07-05 17:36:09 --> Helper loaded: url_helper
INFO - 2019-07-05 17:36:09 --> Helper loaded: array_helper
INFO - 2019-07-05 17:36:09 --> Helper loaded: inflector_helper
INFO - 2019-07-05 17:36:09 --> Session: Class initialized using 'files' driver.
INFO - 2019-07-05 17:36:09 --> Helper loaded: string_helper
DEBUG - 2019-07-05 17:36:09 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-05 17:36:09 --> Helper loaded: array_helper
INFO - 2019-07-05 17:36:09 --> Database Driver Class Initialized
INFO - 2019-07-05 17:36:09 --> Controller Class Initialized
INFO - 2019-07-05 23:36:09 --> Helper loaded: language_helper
INFO - 2019-07-05 23:36:09 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-05 23:36:09 --> Model Class Initialized
INFO - 2019-07-05 23:36:09 --> Model Class Initialized
INFO - 2019-07-05 23:36:09 --> Model Class Initialized
INFO - 2019-07-05 23:36:09 --> Model Class Initialized
INFO - 2019-07-05 23:36:09 --> Model Class Initialized
INFO - 2019-07-05 23:36:09 --> Final output sent to browser
DEBUG - 2019-07-05 23:36:09 --> Total execution time: 0.4936
INFO - 2019-07-05 17:36:09 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-05 17:36:09 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-05 17:36:09 --> Database Driver Class Initialized
INFO - 2019-07-05 17:36:09 --> Controller Class Initialized
INFO - 2019-07-05 23:36:09 --> Helper loaded: language_helper
INFO - 2019-07-05 23:36:09 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-05 23:36:09 --> Model Class Initialized
INFO - 2019-07-05 23:36:09 --> Model Class Initialized
INFO - 2019-07-05 23:36:09 --> Model Class Initialized
INFO - 2019-07-05 23:36:09 --> Model Class Initialized
INFO - 2019-07-05 23:36:09 --> Helper loaded: form_helper
INFO - 2019-07-05 23:36:09 --> Form Validation Class Initialized
DEBUG - 2019-07-05 23:36:09 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-05 23:36:09 --> Model Class Initialized
INFO - 2019-07-05 23:36:09 --> Model Class Initialized
INFO - 2019-07-05 23:36:09 --> Final output sent to browser
DEBUG - 2019-07-05 23:36:09 --> Total execution time: 0.6551
INFO - 2019-07-05 17:36:24 --> Config Class Initialized
INFO - 2019-07-05 17:36:24 --> Config Class Initialized
INFO - 2019-07-05 17:36:24 --> Hooks Class Initialized
INFO - 2019-07-05 17:36:24 --> Hooks Class Initialized
DEBUG - 2019-07-05 17:36:24 --> UTF-8 Support Enabled
DEBUG - 2019-07-05 17:36:24 --> UTF-8 Support Enabled
INFO - 2019-07-05 17:36:24 --> Utf8 Class Initialized
INFO - 2019-07-05 17:36:24 --> Utf8 Class Initialized
INFO - 2019-07-05 17:36:24 --> URI Class Initialized
INFO - 2019-07-05 17:36:24 --> URI Class Initialized
INFO - 2019-07-05 17:36:24 --> Router Class Initialized
INFO - 2019-07-05 17:36:24 --> Router Class Initialized
INFO - 2019-07-05 17:36:24 --> Output Class Initialized
INFO - 2019-07-05 17:36:24 --> Output Class Initialized
INFO - 2019-07-05 17:36:24 --> Security Class Initialized
INFO - 2019-07-05 17:36:24 --> Security Class Initialized
DEBUG - 2019-07-05 17:36:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-05 17:36:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-05 17:36:24 --> Input Class Initialized
INFO - 2019-07-05 17:36:24 --> Input Class Initialized
INFO - 2019-07-05 17:36:24 --> Language Class Initialized
INFO - 2019-07-05 17:36:24 --> Language Class Initialized
INFO - 2019-07-05 17:36:24 --> Language Class Initialized
INFO - 2019-07-05 17:36:24 --> Language Class Initialized
INFO - 2019-07-05 17:36:24 --> Config Class Initialized
INFO - 2019-07-05 17:36:24 --> Loader Class Initialized
INFO - 2019-07-05 17:36:24 --> Config Class Initialized
INFO - 2019-07-05 17:36:24 --> Loader Class Initialized
DEBUG - 2019-07-05 17:36:24 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-05 17:36:24 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-05 17:36:24 --> Helper loaded: url_helper
INFO - 2019-07-05 17:36:24 --> Helper loaded: url_helper
INFO - 2019-07-05 17:36:24 --> Helper loaded: inflector_helper
INFO - 2019-07-05 17:36:24 --> Helper loaded: inflector_helper
INFO - 2019-07-05 17:36:24 --> Helper loaded: string_helper
INFO - 2019-07-05 17:36:24 --> Helper loaded: string_helper
INFO - 2019-07-05 17:36:24 --> Helper loaded: array_helper
INFO - 2019-07-05 17:36:24 --> Helper loaded: array_helper
INFO - 2019-07-05 17:36:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-05 17:36:24 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-05 17:36:24 --> Database Driver Class Initialized
INFO - 2019-07-05 17:36:24 --> Controller Class Initialized
INFO - 2019-07-05 23:36:24 --> Helper loaded: language_helper
INFO - 2019-07-05 23:36:24 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-05 23:36:24 --> Model Class Initialized
INFO - 2019-07-05 23:36:24 --> Model Class Initialized
INFO - 2019-07-05 23:36:24 --> Model Class Initialized
INFO - 2019-07-05 23:36:24 --> Model Class Initialized
INFO - 2019-07-05 23:36:24 --> Model Class Initialized
INFO - 2019-07-05 23:36:24 --> Final output sent to browser
DEBUG - 2019-07-05 23:36:24 --> Total execution time: 0.4426
INFO - 2019-07-05 17:36:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-05 17:36:24 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-05 17:36:24 --> Database Driver Class Initialized
INFO - 2019-07-05 17:36:24 --> Controller Class Initialized
INFO - 2019-07-05 23:36:24 --> Helper loaded: language_helper
INFO - 2019-07-05 23:36:24 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-05 23:36:24 --> Model Class Initialized
INFO - 2019-07-05 23:36:24 --> Model Class Initialized
INFO - 2019-07-05 23:36:24 --> Model Class Initialized
INFO - 2019-07-05 23:36:24 --> Model Class Initialized
INFO - 2019-07-05 23:36:24 --> Helper loaded: form_helper
INFO - 2019-07-05 23:36:24 --> Form Validation Class Initialized
DEBUG - 2019-07-05 23:36:24 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-05 23:36:24 --> Model Class Initialized
INFO - 2019-07-05 23:36:24 --> Model Class Initialized
INFO - 2019-07-05 23:36:24 --> Final output sent to browser
DEBUG - 2019-07-05 23:36:24 --> Total execution time: 0.6011
INFO - 2019-07-05 17:36:30 --> Config Class Initialized
INFO - 2019-07-05 17:36:30 --> Config Class Initialized
INFO - 2019-07-05 17:36:30 --> Hooks Class Initialized
INFO - 2019-07-05 17:36:30 --> Hooks Class Initialized
DEBUG - 2019-07-05 17:36:30 --> UTF-8 Support Enabled
DEBUG - 2019-07-05 17:36:30 --> UTF-8 Support Enabled
INFO - 2019-07-05 17:36:30 --> Utf8 Class Initialized
INFO - 2019-07-05 17:36:30 --> Utf8 Class Initialized
INFO - 2019-07-05 17:36:30 --> URI Class Initialized
INFO - 2019-07-05 17:36:30 --> URI Class Initialized
INFO - 2019-07-05 17:36:30 --> Router Class Initialized
INFO - 2019-07-05 17:36:30 --> Router Class Initialized
INFO - 2019-07-05 17:36:30 --> Output Class Initialized
INFO - 2019-07-05 17:36:30 --> Output Class Initialized
INFO - 2019-07-05 17:36:30 --> Security Class Initialized
INFO - 2019-07-05 17:36:30 --> Security Class Initialized
DEBUG - 2019-07-05 17:36:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-05 17:36:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-05 17:36:30 --> Input Class Initialized
INFO - 2019-07-05 17:36:30 --> Input Class Initialized
INFO - 2019-07-05 17:36:30 --> Language Class Initialized
INFO - 2019-07-05 17:36:30 --> Language Class Initialized
INFO - 2019-07-05 17:36:30 --> Language Class Initialized
INFO - 2019-07-05 17:36:30 --> Language Class Initialized
INFO - 2019-07-05 17:36:30 --> Config Class Initialized
INFO - 2019-07-05 17:36:30 --> Loader Class Initialized
INFO - 2019-07-05 17:36:30 --> Config Class Initialized
INFO - 2019-07-05 17:36:30 --> Loader Class Initialized
DEBUG - 2019-07-05 17:36:30 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-05 17:36:30 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-05 17:36:30 --> Helper loaded: url_helper
INFO - 2019-07-05 17:36:30 --> Helper loaded: url_helper
INFO - 2019-07-05 17:36:30 --> Helper loaded: inflector_helper
INFO - 2019-07-05 17:36:30 --> Helper loaded: inflector_helper
INFO - 2019-07-05 17:36:30 --> Helper loaded: string_helper
INFO - 2019-07-05 17:36:30 --> Helper loaded: string_helper
INFO - 2019-07-05 17:36:30 --> Helper loaded: array_helper
INFO - 2019-07-05 17:36:30 --> Helper loaded: array_helper
INFO - 2019-07-05 17:36:30 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-05 17:36:30 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-05 17:36:30 --> Database Driver Class Initialized
INFO - 2019-07-05 17:36:30 --> Controller Class Initialized
INFO - 2019-07-05 23:36:30 --> Helper loaded: language_helper
INFO - 2019-07-05 23:36:30 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-05 23:36:30 --> Model Class Initialized
INFO - 2019-07-05 23:36:30 --> Model Class Initialized
INFO - 2019-07-05 23:36:30 --> Model Class Initialized
INFO - 2019-07-05 23:36:30 --> Model Class Initialized
INFO - 2019-07-05 23:36:30 --> Model Class Initialized
INFO - 2019-07-05 23:36:30 --> Final output sent to browser
DEBUG - 2019-07-05 23:36:30 --> Total execution time: 0.4345
INFO - 2019-07-05 17:36:30 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-05 17:36:30 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-05 17:36:30 --> Database Driver Class Initialized
INFO - 2019-07-05 17:36:30 --> Controller Class Initialized
INFO - 2019-07-05 23:36:30 --> Helper loaded: language_helper
INFO - 2019-07-05 23:36:30 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-05 23:36:30 --> Model Class Initialized
INFO - 2019-07-05 23:36:30 --> Model Class Initialized
INFO - 2019-07-05 23:36:30 --> Model Class Initialized
INFO - 2019-07-05 23:36:30 --> Model Class Initialized
INFO - 2019-07-05 23:36:30 --> Helper loaded: form_helper
INFO - 2019-07-05 23:36:30 --> Form Validation Class Initialized
DEBUG - 2019-07-05 23:36:30 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-05 23:36:30 --> Model Class Initialized
INFO - 2019-07-05 23:36:30 --> Model Class Initialized
INFO - 2019-07-05 23:36:30 --> Final output sent to browser
DEBUG - 2019-07-05 23:36:30 --> Total execution time: 0.5667
INFO - 2019-07-05 17:36:32 --> Config Class Initialized
INFO - 2019-07-05 17:36:32 --> Config Class Initialized
INFO - 2019-07-05 17:36:32 --> Hooks Class Initialized
INFO - 2019-07-05 17:36:32 --> Hooks Class Initialized
DEBUG - 2019-07-05 17:36:32 --> UTF-8 Support Enabled
DEBUG - 2019-07-05 17:36:32 --> UTF-8 Support Enabled
INFO - 2019-07-05 17:36:32 --> Utf8 Class Initialized
INFO - 2019-07-05 17:36:32 --> Utf8 Class Initialized
INFO - 2019-07-05 17:36:32 --> URI Class Initialized
INFO - 2019-07-05 17:36:32 --> URI Class Initialized
INFO - 2019-07-05 17:36:32 --> Router Class Initialized
INFO - 2019-07-05 17:36:32 --> Router Class Initialized
INFO - 2019-07-05 17:36:32 --> Output Class Initialized
INFO - 2019-07-05 17:36:32 --> Output Class Initialized
INFO - 2019-07-05 17:36:32 --> Security Class Initialized
INFO - 2019-07-05 17:36:32 --> Security Class Initialized
DEBUG - 2019-07-05 17:36:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-05 17:36:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-05 17:36:32 --> Input Class Initialized
INFO - 2019-07-05 17:36:32 --> Input Class Initialized
INFO - 2019-07-05 17:36:32 --> Language Class Initialized
INFO - 2019-07-05 17:36:32 --> Language Class Initialized
INFO - 2019-07-05 17:36:32 --> Language Class Initialized
INFO - 2019-07-05 17:36:32 --> Language Class Initialized
INFO - 2019-07-05 17:36:32 --> Config Class Initialized
INFO - 2019-07-05 17:36:32 --> Config Class Initialized
INFO - 2019-07-05 17:36:32 --> Loader Class Initialized
INFO - 2019-07-05 17:36:32 --> Loader Class Initialized
DEBUG - 2019-07-05 17:36:32 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-05 17:36:32 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-05 17:36:32 --> Helper loaded: url_helper
INFO - 2019-07-05 17:36:32 --> Helper loaded: url_helper
INFO - 2019-07-05 17:36:32 --> Helper loaded: inflector_helper
INFO - 2019-07-05 17:36:32 --> Helper loaded: inflector_helper
INFO - 2019-07-05 17:36:32 --> Helper loaded: string_helper
INFO - 2019-07-05 17:36:32 --> Helper loaded: string_helper
INFO - 2019-07-05 17:36:32 --> Helper loaded: array_helper
INFO - 2019-07-05 17:36:32 --> Helper loaded: array_helper
INFO - 2019-07-05 17:36:32 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-05 17:36:32 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-05 17:36:32 --> Database Driver Class Initialized
INFO - 2019-07-05 17:36:32 --> Controller Class Initialized
INFO - 2019-07-05 23:36:32 --> Helper loaded: language_helper
INFO - 2019-07-05 23:36:32 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-05 23:36:32 --> Model Class Initialized
INFO - 2019-07-05 23:36:32 --> Model Class Initialized
INFO - 2019-07-05 23:36:32 --> Model Class Initialized
INFO - 2019-07-05 23:36:32 --> Model Class Initialized
INFO - 2019-07-05 23:36:32 --> Helper loaded: form_helper
INFO - 2019-07-05 23:36:32 --> Form Validation Class Initialized
DEBUG - 2019-07-05 23:36:32 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-05 23:36:32 --> Model Class Initialized
INFO - 2019-07-05 23:36:32 --> Model Class Initialized
INFO - 2019-07-05 23:36:32 --> Final output sent to browser
DEBUG - 2019-07-05 23:36:32 --> Total execution time: 0.4264
INFO - 2019-07-05 17:36:32 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-05 17:36:32 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-05 17:36:32 --> Database Driver Class Initialized
INFO - 2019-07-05 17:36:32 --> Controller Class Initialized
INFO - 2019-07-05 23:36:33 --> Helper loaded: language_helper
INFO - 2019-07-05 23:36:33 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-05 23:36:33 --> Model Class Initialized
INFO - 2019-07-05 23:36:33 --> Model Class Initialized
INFO - 2019-07-05 23:36:33 --> Model Class Initialized
INFO - 2019-07-05 23:36:33 --> Model Class Initialized
INFO - 2019-07-05 23:36:33 --> Model Class Initialized
INFO - 2019-07-05 23:36:33 --> Final output sent to browser
DEBUG - 2019-07-05 23:36:33 --> Total execution time: 0.5596
INFO - 2019-07-05 17:36:35 --> Config Class Initialized
INFO - 2019-07-05 17:36:35 --> Config Class Initialized
INFO - 2019-07-05 17:36:35 --> Hooks Class Initialized
INFO - 2019-07-05 17:36:35 --> Hooks Class Initialized
DEBUG - 2019-07-05 17:36:35 --> UTF-8 Support Enabled
INFO - 2019-07-05 17:36:35 --> Utf8 Class Initialized
DEBUG - 2019-07-05 17:36:35 --> UTF-8 Support Enabled
INFO - 2019-07-05 17:36:35 --> Utf8 Class Initialized
INFO - 2019-07-05 17:36:35 --> URI Class Initialized
INFO - 2019-07-05 17:36:35 --> URI Class Initialized
INFO - 2019-07-05 17:36:35 --> Router Class Initialized
INFO - 2019-07-05 17:36:35 --> Router Class Initialized
INFO - 2019-07-05 17:36:35 --> Output Class Initialized
INFO - 2019-07-05 17:36:35 --> Output Class Initialized
INFO - 2019-07-05 17:36:35 --> Security Class Initialized
INFO - 2019-07-05 17:36:36 --> Security Class Initialized
DEBUG - 2019-07-05 17:36:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-05 17:36:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-05 17:36:36 --> Input Class Initialized
INFO - 2019-07-05 17:36:36 --> Input Class Initialized
INFO - 2019-07-05 17:36:36 --> Language Class Initialized
INFO - 2019-07-05 17:36:36 --> Language Class Initialized
INFO - 2019-07-05 17:36:36 --> Language Class Initialized
INFO - 2019-07-05 17:36:36 --> Language Class Initialized
INFO - 2019-07-05 17:36:36 --> Config Class Initialized
INFO - 2019-07-05 17:36:36 --> Config Class Initialized
INFO - 2019-07-05 17:36:36 --> Loader Class Initialized
INFO - 2019-07-05 17:36:36 --> Loader Class Initialized
DEBUG - 2019-07-05 17:36:36 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-05 17:36:36 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-05 17:36:36 --> Helper loaded: url_helper
INFO - 2019-07-05 17:36:36 --> Helper loaded: url_helper
INFO - 2019-07-05 17:36:36 --> Helper loaded: inflector_helper
INFO - 2019-07-05 17:36:36 --> Helper loaded: inflector_helper
INFO - 2019-07-05 17:36:36 --> Helper loaded: string_helper
INFO - 2019-07-05 17:36:36 --> Helper loaded: string_helper
INFO - 2019-07-05 17:36:36 --> Helper loaded: array_helper
INFO - 2019-07-05 17:36:36 --> Helper loaded: array_helper
INFO - 2019-07-05 17:36:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-05 17:36:36 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-05 17:36:36 --> Database Driver Class Initialized
INFO - 2019-07-05 17:36:36 --> Controller Class Initialized
INFO - 2019-07-05 23:36:36 --> Helper loaded: language_helper
INFO - 2019-07-05 23:36:36 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-05 23:36:36 --> Model Class Initialized
INFO - 2019-07-05 23:36:36 --> Model Class Initialized
INFO - 2019-07-05 23:36:36 --> Model Class Initialized
INFO - 2019-07-05 23:36:36 --> Model Class Initialized
INFO - 2019-07-05 23:36:36 --> Model Class Initialized
INFO - 2019-07-05 23:36:36 --> Final output sent to browser
DEBUG - 2019-07-05 23:36:36 --> Total execution time: 0.4637
INFO - 2019-07-05 17:36:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-05 17:36:36 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-05 17:36:36 --> Database Driver Class Initialized
INFO - 2019-07-05 17:36:36 --> Controller Class Initialized
INFO - 2019-07-05 23:36:36 --> Helper loaded: language_helper
INFO - 2019-07-05 23:36:36 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-05 23:36:36 --> Model Class Initialized
INFO - 2019-07-05 23:36:36 --> Model Class Initialized
INFO - 2019-07-05 23:36:36 --> Model Class Initialized
INFO - 2019-07-05 23:36:36 --> Model Class Initialized
INFO - 2019-07-05 23:36:36 --> Helper loaded: form_helper
INFO - 2019-07-05 23:36:36 --> Form Validation Class Initialized
DEBUG - 2019-07-05 23:36:36 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-05 23:36:36 --> Model Class Initialized
INFO - 2019-07-05 23:36:36 --> Model Class Initialized
INFO - 2019-07-05 23:36:36 --> Final output sent to browser
DEBUG - 2019-07-05 23:36:36 --> Total execution time: 0.6236
INFO - 2019-07-05 17:38:02 --> Config Class Initialized
INFO - 2019-07-05 17:38:02 --> Config Class Initialized
INFO - 2019-07-05 17:38:02 --> Hooks Class Initialized
INFO - 2019-07-05 17:38:02 --> Hooks Class Initialized
DEBUG - 2019-07-05 17:38:02 --> UTF-8 Support Enabled
DEBUG - 2019-07-05 17:38:02 --> UTF-8 Support Enabled
INFO - 2019-07-05 17:38:02 --> Utf8 Class Initialized
INFO - 2019-07-05 17:38:02 --> Utf8 Class Initialized
INFO - 2019-07-05 17:38:03 --> URI Class Initialized
INFO - 2019-07-05 17:38:03 --> URI Class Initialized
INFO - 2019-07-05 17:38:03 --> Router Class Initialized
INFO - 2019-07-05 17:38:03 --> Output Class Initialized
INFO - 2019-07-05 17:38:03 --> Router Class Initialized
INFO - 2019-07-05 17:38:03 --> Security Class Initialized
INFO - 2019-07-05 17:38:03 --> Output Class Initialized
DEBUG - 2019-07-05 17:38:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-05 17:38:03 --> Security Class Initialized
INFO - 2019-07-05 17:38:03 --> Input Class Initialized
INFO - 2019-07-05 17:38:03 --> Language Class Initialized
DEBUG - 2019-07-05 17:38:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-05 17:38:03 --> Language Class Initialized
INFO - 2019-07-05 17:38:03 --> Input Class Initialized
INFO - 2019-07-05 17:38:03 --> Config Class Initialized
INFO - 2019-07-05 17:38:03 --> Language Class Initialized
INFO - 2019-07-05 17:38:03 --> Loader Class Initialized
DEBUG - 2019-07-05 17:38:03 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-05 17:38:03 --> Language Class Initialized
INFO - 2019-07-05 17:38:03 --> Helper loaded: url_helper
INFO - 2019-07-05 17:38:03 --> Config Class Initialized
INFO - 2019-07-05 17:38:03 --> Loader Class Initialized
INFO - 2019-07-05 17:38:03 --> Helper loaded: inflector_helper
DEBUG - 2019-07-05 17:38:03 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-05 17:38:03 --> Helper loaded: string_helper
INFO - 2019-07-05 17:38:03 --> Helper loaded: url_helper
INFO - 2019-07-05 17:38:03 --> Helper loaded: array_helper
INFO - 2019-07-05 17:38:03 --> Helper loaded: inflector_helper
INFO - 2019-07-05 17:38:03 --> Session: Class initialized using 'files' driver.
INFO - 2019-07-05 17:38:03 --> Helper loaded: string_helper
DEBUG - 2019-07-05 17:38:03 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-05 17:38:03 --> Helper loaded: array_helper
INFO - 2019-07-05 17:38:03 --> Database Driver Class Initialized
INFO - 2019-07-05 17:38:03 --> Controller Class Initialized
INFO - 2019-07-05 23:38:03 --> Helper loaded: language_helper
INFO - 2019-07-05 23:38:03 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-05 23:38:03 --> Model Class Initialized
INFO - 2019-07-05 23:38:03 --> Model Class Initialized
INFO - 2019-07-05 23:38:03 --> Model Class Initialized
INFO - 2019-07-05 23:38:03 --> Model Class Initialized
INFO - 2019-07-05 23:38:03 --> Model Class Initialized
INFO - 2019-07-05 23:38:03 --> Final output sent to browser
DEBUG - 2019-07-05 23:38:03 --> Total execution time: 0.4909
INFO - 2019-07-05 17:38:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-05 17:38:03 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-05 17:38:03 --> Database Driver Class Initialized
INFO - 2019-07-05 17:38:03 --> Controller Class Initialized
INFO - 2019-07-05 23:38:03 --> Helper loaded: language_helper
INFO - 2019-07-05 23:38:03 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-05 23:38:03 --> Model Class Initialized
INFO - 2019-07-05 23:38:03 --> Model Class Initialized
INFO - 2019-07-05 23:38:03 --> Model Class Initialized
INFO - 2019-07-05 23:38:03 --> Model Class Initialized
INFO - 2019-07-05 23:38:03 --> Helper loaded: form_helper
INFO - 2019-07-05 23:38:03 --> Form Validation Class Initialized
DEBUG - 2019-07-05 23:38:03 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-05 23:38:03 --> Model Class Initialized
INFO - 2019-07-05 23:38:03 --> Model Class Initialized
INFO - 2019-07-05 23:38:03 --> Final output sent to browser
DEBUG - 2019-07-05 23:38:03 --> Total execution time: 0.6529
INFO - 2019-07-05 17:38:06 --> Config Class Initialized
INFO - 2019-07-05 17:38:06 --> Config Class Initialized
INFO - 2019-07-05 17:38:06 --> Hooks Class Initialized
INFO - 2019-07-05 17:38:06 --> Hooks Class Initialized
DEBUG - 2019-07-05 17:38:06 --> UTF-8 Support Enabled
DEBUG - 2019-07-05 17:38:06 --> UTF-8 Support Enabled
INFO - 2019-07-05 17:38:06 --> Utf8 Class Initialized
INFO - 2019-07-05 17:38:06 --> Utf8 Class Initialized
INFO - 2019-07-05 17:38:06 --> URI Class Initialized
INFO - 2019-07-05 17:38:06 --> URI Class Initialized
INFO - 2019-07-05 17:38:06 --> Router Class Initialized
INFO - 2019-07-05 17:38:06 --> Router Class Initialized
INFO - 2019-07-05 17:38:06 --> Output Class Initialized
INFO - 2019-07-05 17:38:06 --> Output Class Initialized
INFO - 2019-07-05 17:38:06 --> Security Class Initialized
INFO - 2019-07-05 17:38:06 --> Security Class Initialized
DEBUG - 2019-07-05 17:38:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-05 17:38:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-05 17:38:06 --> Input Class Initialized
INFO - 2019-07-05 17:38:06 --> Input Class Initialized
INFO - 2019-07-05 17:38:06 --> Language Class Initialized
INFO - 2019-07-05 17:38:06 --> Language Class Initialized
INFO - 2019-07-05 17:38:06 --> Language Class Initialized
INFO - 2019-07-05 17:38:06 --> Language Class Initialized
INFO - 2019-07-05 17:38:06 --> Config Class Initialized
INFO - 2019-07-05 17:38:06 --> Config Class Initialized
INFO - 2019-07-05 17:38:06 --> Loader Class Initialized
INFO - 2019-07-05 17:38:06 --> Loader Class Initialized
DEBUG - 2019-07-05 17:38:06 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-05 17:38:06 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-05 17:38:06 --> Helper loaded: url_helper
INFO - 2019-07-05 17:38:06 --> Helper loaded: url_helper
INFO - 2019-07-05 17:38:06 --> Helper loaded: inflector_helper
INFO - 2019-07-05 17:38:06 --> Helper loaded: inflector_helper
INFO - 2019-07-05 17:38:06 --> Helper loaded: string_helper
INFO - 2019-07-05 17:38:06 --> Helper loaded: string_helper
INFO - 2019-07-05 17:38:06 --> Helper loaded: array_helper
INFO - 2019-07-05 17:38:06 --> Helper loaded: array_helper
INFO - 2019-07-05 17:38:06 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-05 17:38:06 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-05 17:38:06 --> Database Driver Class Initialized
INFO - 2019-07-05 17:38:06 --> Controller Class Initialized
INFO - 2019-07-05 23:38:06 --> Helper loaded: language_helper
INFO - 2019-07-05 23:38:06 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-05 23:38:06 --> Model Class Initialized
INFO - 2019-07-05 23:38:06 --> Model Class Initialized
INFO - 2019-07-05 23:38:06 --> Model Class Initialized
INFO - 2019-07-05 23:38:06 --> Model Class Initialized
INFO - 2019-07-05 23:38:06 --> Model Class Initialized
INFO - 2019-07-05 23:38:06 --> Final output sent to browser
DEBUG - 2019-07-05 23:38:06 --> Total execution time: 0.4052
INFO - 2019-07-05 17:38:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-05 17:38:07 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-05 17:38:07 --> Database Driver Class Initialized
INFO - 2019-07-05 17:38:07 --> Controller Class Initialized
INFO - 2019-07-05 23:38:07 --> Helper loaded: language_helper
INFO - 2019-07-05 23:38:07 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-05 23:38:07 --> Model Class Initialized
INFO - 2019-07-05 23:38:07 --> Model Class Initialized
INFO - 2019-07-05 23:38:07 --> Model Class Initialized
INFO - 2019-07-05 23:38:07 --> Model Class Initialized
INFO - 2019-07-05 23:38:07 --> Helper loaded: form_helper
INFO - 2019-07-05 23:38:07 --> Form Validation Class Initialized
DEBUG - 2019-07-05 23:38:07 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-05 23:38:07 --> Model Class Initialized
INFO - 2019-07-05 23:38:07 --> Model Class Initialized
INFO - 2019-07-05 23:38:07 --> Final output sent to browser
DEBUG - 2019-07-05 23:38:07 --> Total execution time: 0.5645
INFO - 2019-07-05 17:39:30 --> Config Class Initialized
INFO - 2019-07-05 17:39:30 --> Config Class Initialized
INFO - 2019-07-05 17:39:30 --> Hooks Class Initialized
INFO - 2019-07-05 17:39:30 --> Hooks Class Initialized
DEBUG - 2019-07-05 17:39:30 --> UTF-8 Support Enabled
DEBUG - 2019-07-05 17:39:30 --> UTF-8 Support Enabled
INFO - 2019-07-05 17:39:30 --> Utf8 Class Initialized
INFO - 2019-07-05 17:39:30 --> Utf8 Class Initialized
INFO - 2019-07-05 17:39:30 --> URI Class Initialized
INFO - 2019-07-05 17:39:30 --> URI Class Initialized
INFO - 2019-07-05 17:39:30 --> Router Class Initialized
INFO - 2019-07-05 17:39:30 --> Router Class Initialized
INFO - 2019-07-05 17:39:30 --> Output Class Initialized
INFO - 2019-07-05 17:39:30 --> Output Class Initialized
INFO - 2019-07-05 17:39:30 --> Security Class Initialized
INFO - 2019-07-05 17:39:30 --> Security Class Initialized
DEBUG - 2019-07-05 17:39:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-05 17:39:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-05 17:39:30 --> Input Class Initialized
INFO - 2019-07-05 17:39:30 --> Input Class Initialized
INFO - 2019-07-05 17:39:30 --> Language Class Initialized
INFO - 2019-07-05 17:39:30 --> Language Class Initialized
INFO - 2019-07-05 17:39:30 --> Language Class Initialized
INFO - 2019-07-05 17:39:30 --> Language Class Initialized
INFO - 2019-07-05 17:39:30 --> Config Class Initialized
INFO - 2019-07-05 17:39:30 --> Config Class Initialized
INFO - 2019-07-05 17:39:30 --> Loader Class Initialized
INFO - 2019-07-05 17:39:30 --> Loader Class Initialized
DEBUG - 2019-07-05 17:39:30 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-05 17:39:31 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-05 17:39:31 --> Helper loaded: url_helper
INFO - 2019-07-05 17:39:31 --> Helper loaded: url_helper
INFO - 2019-07-05 17:39:31 --> Helper loaded: inflector_helper
INFO - 2019-07-05 17:39:31 --> Helper loaded: inflector_helper
INFO - 2019-07-05 17:39:31 --> Helper loaded: string_helper
INFO - 2019-07-05 17:39:31 --> Helper loaded: string_helper
INFO - 2019-07-05 17:39:31 --> Helper loaded: array_helper
INFO - 2019-07-05 17:39:31 --> Helper loaded: array_helper
INFO - 2019-07-05 17:39:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-05 17:39:31 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-05 17:39:31 --> Database Driver Class Initialized
INFO - 2019-07-05 17:39:31 --> Controller Class Initialized
INFO - 2019-07-05 23:39:31 --> Helper loaded: language_helper
INFO - 2019-07-05 23:39:31 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-05 23:39:31 --> Model Class Initialized
INFO - 2019-07-05 23:39:31 --> Model Class Initialized
INFO - 2019-07-05 23:39:31 --> Model Class Initialized
INFO - 2019-07-05 23:39:31 --> Model Class Initialized
INFO - 2019-07-05 23:39:31 --> Helper loaded: form_helper
INFO - 2019-07-05 23:39:31 --> Form Validation Class Initialized
DEBUG - 2019-07-05 23:39:31 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-05 23:39:31 --> Model Class Initialized
INFO - 2019-07-05 23:39:31 --> Model Class Initialized
INFO - 2019-07-05 23:39:31 --> Final output sent to browser
DEBUG - 2019-07-05 23:39:31 --> Total execution time: 0.5302
INFO - 2019-07-05 17:39:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-05 17:39:31 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-05 17:39:31 --> Database Driver Class Initialized
INFO - 2019-07-05 17:39:31 --> Controller Class Initialized
INFO - 2019-07-05 23:39:31 --> Helper loaded: language_helper
INFO - 2019-07-05 23:39:31 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-05 23:39:31 --> Model Class Initialized
INFO - 2019-07-05 23:39:31 --> Model Class Initialized
INFO - 2019-07-05 23:39:31 --> Model Class Initialized
INFO - 2019-07-05 23:39:31 --> Model Class Initialized
INFO - 2019-07-05 23:39:31 --> Model Class Initialized
INFO - 2019-07-05 23:39:31 --> Final output sent to browser
DEBUG - 2019-07-05 23:39:31 --> Total execution time: 0.7281
INFO - 2019-07-05 17:39:48 --> Config Class Initialized
INFO - 2019-07-05 17:39:48 --> Config Class Initialized
INFO - 2019-07-05 17:39:48 --> Hooks Class Initialized
INFO - 2019-07-05 17:39:48 --> Hooks Class Initialized
DEBUG - 2019-07-05 17:39:48 --> UTF-8 Support Enabled
DEBUG - 2019-07-05 17:39:48 --> UTF-8 Support Enabled
INFO - 2019-07-05 17:39:48 --> Utf8 Class Initialized
INFO - 2019-07-05 17:39:48 --> Utf8 Class Initialized
INFO - 2019-07-05 17:39:48 --> URI Class Initialized
INFO - 2019-07-05 17:39:48 --> URI Class Initialized
INFO - 2019-07-05 17:39:48 --> Router Class Initialized
INFO - 2019-07-05 17:39:48 --> Router Class Initialized
INFO - 2019-07-05 17:39:48 --> Output Class Initialized
INFO - 2019-07-05 17:39:48 --> Output Class Initialized
INFO - 2019-07-05 17:39:48 --> Security Class Initialized
INFO - 2019-07-05 17:39:48 --> Security Class Initialized
DEBUG - 2019-07-05 17:39:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-05 17:39:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-05 17:39:48 --> Input Class Initialized
INFO - 2019-07-05 17:39:48 --> Input Class Initialized
INFO - 2019-07-05 17:39:48 --> Language Class Initialized
INFO - 2019-07-05 17:39:48 --> Language Class Initialized
INFO - 2019-07-05 17:39:48 --> Language Class Initialized
INFO - 2019-07-05 17:39:48 --> Language Class Initialized
INFO - 2019-07-05 17:39:48 --> Config Class Initialized
INFO - 2019-07-05 17:39:48 --> Loader Class Initialized
INFO - 2019-07-05 17:39:48 --> Config Class Initialized
INFO - 2019-07-05 17:39:48 --> Loader Class Initialized
DEBUG - 2019-07-05 17:39:48 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-05 17:39:48 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-05 17:39:48 --> Helper loaded: url_helper
INFO - 2019-07-05 17:39:48 --> Helper loaded: url_helper
INFO - 2019-07-05 17:39:48 --> Helper loaded: inflector_helper
INFO - 2019-07-05 17:39:48 --> Helper loaded: inflector_helper
INFO - 2019-07-05 17:39:48 --> Helper loaded: string_helper
INFO - 2019-07-05 17:39:48 --> Helper loaded: string_helper
INFO - 2019-07-05 17:39:48 --> Helper loaded: array_helper
INFO - 2019-07-05 17:39:48 --> Helper loaded: array_helper
INFO - 2019-07-05 17:39:48 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-05 17:39:48 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-05 17:39:48 --> Database Driver Class Initialized
INFO - 2019-07-05 17:39:48 --> Controller Class Initialized
INFO - 2019-07-05 23:39:48 --> Helper loaded: language_helper
INFO - 2019-07-05 23:39:48 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-05 23:39:48 --> Model Class Initialized
INFO - 2019-07-05 23:39:48 --> Model Class Initialized
INFO - 2019-07-05 23:39:48 --> Model Class Initialized
INFO - 2019-07-05 23:39:48 --> Model Class Initialized
INFO - 2019-07-05 23:39:48 --> Model Class Initialized
INFO - 2019-07-05 23:39:48 --> Final output sent to browser
DEBUG - 2019-07-05 23:39:48 --> Total execution time: 0.4725
INFO - 2019-07-05 17:39:48 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-05 17:39:48 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-05 17:39:48 --> Database Driver Class Initialized
INFO - 2019-07-05 17:39:48 --> Controller Class Initialized
INFO - 2019-07-05 23:39:48 --> Helper loaded: language_helper
INFO - 2019-07-05 23:39:48 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-05 23:39:48 --> Model Class Initialized
INFO - 2019-07-05 23:39:48 --> Model Class Initialized
INFO - 2019-07-05 23:39:48 --> Model Class Initialized
INFO - 2019-07-05 23:39:48 --> Model Class Initialized
INFO - 2019-07-05 23:39:48 --> Helper loaded: form_helper
INFO - 2019-07-05 23:39:48 --> Form Validation Class Initialized
DEBUG - 2019-07-05 23:39:48 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-05 23:39:48 --> Model Class Initialized
INFO - 2019-07-05 23:39:48 --> Model Class Initialized
INFO - 2019-07-05 23:39:48 --> Final output sent to browser
DEBUG - 2019-07-05 23:39:48 --> Total execution time: 0.6555
INFO - 2019-07-05 17:40:51 --> Config Class Initialized
INFO - 2019-07-05 17:40:51 --> Hooks Class Initialized
DEBUG - 2019-07-05 17:40:51 --> UTF-8 Support Enabled
INFO - 2019-07-05 17:40:51 --> Utf8 Class Initialized
INFO - 2019-07-05 17:40:51 --> Config Class Initialized
INFO - 2019-07-05 17:40:51 --> URI Class Initialized
INFO - 2019-07-05 17:40:51 --> Hooks Class Initialized
INFO - 2019-07-05 17:40:51 --> Router Class Initialized
DEBUG - 2019-07-05 17:40:51 --> UTF-8 Support Enabled
INFO - 2019-07-05 17:40:51 --> Output Class Initialized
INFO - 2019-07-05 17:40:51 --> Utf8 Class Initialized
INFO - 2019-07-05 17:40:51 --> URI Class Initialized
INFO - 2019-07-05 17:40:51 --> Security Class Initialized
INFO - 2019-07-05 17:40:51 --> Router Class Initialized
DEBUG - 2019-07-05 17:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-05 17:40:51 --> Output Class Initialized
INFO - 2019-07-05 17:40:51 --> Input Class Initialized
INFO - 2019-07-05 17:40:51 --> Language Class Initialized
INFO - 2019-07-05 17:40:51 --> Security Class Initialized
INFO - 2019-07-05 17:40:51 --> Language Class Initialized
DEBUG - 2019-07-05 17:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-05 17:40:51 --> Config Class Initialized
INFO - 2019-07-05 17:40:51 --> Input Class Initialized
INFO - 2019-07-05 17:40:51 --> Loader Class Initialized
INFO - 2019-07-05 17:40:51 --> Language Class Initialized
DEBUG - 2019-07-05 17:40:51 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-05 17:40:51 --> Helper loaded: url_helper
INFO - 2019-07-05 17:40:51 --> Language Class Initialized
INFO - 2019-07-05 17:40:51 --> Helper loaded: inflector_helper
INFO - 2019-07-05 17:40:51 --> Config Class Initialized
INFO - 2019-07-05 17:40:51 --> Loader Class Initialized
INFO - 2019-07-05 17:40:51 --> Helper loaded: string_helper
DEBUG - 2019-07-05 17:40:51 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-05 17:40:51 --> Helper loaded: array_helper
INFO - 2019-07-05 17:40:51 --> Helper loaded: url_helper
INFO - 2019-07-05 17:40:51 --> Session: Class initialized using 'files' driver.
INFO - 2019-07-05 17:40:51 --> Helper loaded: inflector_helper
DEBUG - 2019-07-05 17:40:51 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-05 17:40:51 --> Helper loaded: string_helper
INFO - 2019-07-05 17:40:51 --> Database Driver Class Initialized
INFO - 2019-07-05 17:40:51 --> Helper loaded: array_helper
INFO - 2019-07-05 17:40:51 --> Controller Class Initialized
INFO - 2019-07-05 23:40:51 --> Helper loaded: language_helper
INFO - 2019-07-05 23:40:51 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-05 23:40:51 --> Model Class Initialized
INFO - 2019-07-05 23:40:51 --> Model Class Initialized
INFO - 2019-07-05 23:40:51 --> Model Class Initialized
INFO - 2019-07-05 23:40:51 --> Model Class Initialized
INFO - 2019-07-05 23:40:51 --> Helper loaded: form_helper
INFO - 2019-07-05 23:40:51 --> Form Validation Class Initialized
DEBUG - 2019-07-05 23:40:51 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-05 23:40:51 --> Model Class Initialized
INFO - 2019-07-05 23:40:51 --> Model Class Initialized
INFO - 2019-07-05 23:40:51 --> Final output sent to browser
DEBUG - 2019-07-05 23:40:51 --> Total execution time: 0.5326
INFO - 2019-07-05 17:40:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-05 17:40:51 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-05 17:40:51 --> Database Driver Class Initialized
INFO - 2019-07-05 17:40:51 --> Controller Class Initialized
INFO - 2019-07-05 23:40:51 --> Helper loaded: language_helper
INFO - 2019-07-05 23:40:51 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-05 23:40:51 --> Model Class Initialized
INFO - 2019-07-05 23:40:51 --> Model Class Initialized
INFO - 2019-07-05 23:40:51 --> Model Class Initialized
INFO - 2019-07-05 23:40:51 --> Model Class Initialized
INFO - 2019-07-05 23:40:52 --> Model Class Initialized
INFO - 2019-07-05 23:40:52 --> Final output sent to browser
DEBUG - 2019-07-05 23:40:52 --> Total execution time: 0.6712
INFO - 2019-07-05 17:40:56 --> Config Class Initialized
INFO - 2019-07-05 17:40:56 --> Config Class Initialized
INFO - 2019-07-05 17:40:56 --> Hooks Class Initialized
INFO - 2019-07-05 17:40:56 --> Hooks Class Initialized
DEBUG - 2019-07-05 17:40:56 --> UTF-8 Support Enabled
INFO - 2019-07-05 17:40:56 --> Utf8 Class Initialized
DEBUG - 2019-07-05 17:40:56 --> UTF-8 Support Enabled
INFO - 2019-07-05 17:40:56 --> Utf8 Class Initialized
INFO - 2019-07-05 17:40:56 --> URI Class Initialized
INFO - 2019-07-05 17:40:56 --> URI Class Initialized
INFO - 2019-07-05 17:40:56 --> Router Class Initialized
INFO - 2019-07-05 17:40:56 --> Router Class Initialized
INFO - 2019-07-05 17:40:57 --> Output Class Initialized
INFO - 2019-07-05 17:40:57 --> Output Class Initialized
INFO - 2019-07-05 17:40:57 --> Security Class Initialized
INFO - 2019-07-05 17:40:57 --> Security Class Initialized
DEBUG - 2019-07-05 17:40:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-05 17:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-05 17:40:57 --> Input Class Initialized
INFO - 2019-07-05 17:40:57 --> Input Class Initialized
INFO - 2019-07-05 17:40:57 --> Language Class Initialized
INFO - 2019-07-05 17:40:57 --> Language Class Initialized
INFO - 2019-07-05 17:40:57 --> Language Class Initialized
INFO - 2019-07-05 17:40:57 --> Language Class Initialized
INFO - 2019-07-05 17:40:57 --> Config Class Initialized
INFO - 2019-07-05 17:40:57 --> Loader Class Initialized
INFO - 2019-07-05 17:40:57 --> Config Class Initialized
INFO - 2019-07-05 17:40:57 --> Loader Class Initialized
DEBUG - 2019-07-05 17:40:57 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-05 17:40:57 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-05 17:40:57 --> Helper loaded: url_helper
INFO - 2019-07-05 17:40:57 --> Helper loaded: url_helper
INFO - 2019-07-05 17:40:57 --> Helper loaded: inflector_helper
INFO - 2019-07-05 17:40:57 --> Helper loaded: inflector_helper
INFO - 2019-07-05 17:40:57 --> Helper loaded: string_helper
INFO - 2019-07-05 17:40:57 --> Helper loaded: string_helper
INFO - 2019-07-05 17:40:57 --> Helper loaded: array_helper
INFO - 2019-07-05 17:40:57 --> Helper loaded: array_helper
INFO - 2019-07-05 17:40:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-05 17:40:57 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-05 17:40:57 --> Database Driver Class Initialized
INFO - 2019-07-05 17:40:57 --> Controller Class Initialized
INFO - 2019-07-05 23:40:57 --> Helper loaded: language_helper
INFO - 2019-07-05 23:40:57 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-05 23:40:57 --> Model Class Initialized
INFO - 2019-07-05 23:40:57 --> Model Class Initialized
INFO - 2019-07-05 23:40:57 --> Model Class Initialized
INFO - 2019-07-05 23:40:57 --> Model Class Initialized
INFO - 2019-07-05 23:40:57 --> Helper loaded: form_helper
INFO - 2019-07-05 23:40:57 --> Form Validation Class Initialized
DEBUG - 2019-07-05 23:40:57 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-05 23:40:57 --> Model Class Initialized
INFO - 2019-07-05 23:40:57 --> Model Class Initialized
INFO - 2019-07-05 23:40:57 --> Final output sent to browser
DEBUG - 2019-07-05 23:40:57 --> Total execution time: 0.4973
INFO - 2019-07-05 17:40:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-05 17:40:57 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-05 17:40:57 --> Database Driver Class Initialized
INFO - 2019-07-05 17:40:57 --> Controller Class Initialized
INFO - 2019-07-05 23:40:57 --> Helper loaded: language_helper
INFO - 2019-07-05 23:40:57 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-05 23:40:57 --> Model Class Initialized
INFO - 2019-07-05 23:40:57 --> Model Class Initialized
INFO - 2019-07-05 23:40:57 --> Model Class Initialized
INFO - 2019-07-05 23:40:57 --> Model Class Initialized
INFO - 2019-07-05 23:40:57 --> Model Class Initialized
INFO - 2019-07-05 23:40:57 --> Final output sent to browser
DEBUG - 2019-07-05 23:40:57 --> Total execution time: 0.6429
INFO - 2019-07-05 17:43:20 --> Config Class Initialized
INFO - 2019-07-05 17:43:20 --> Config Class Initialized
INFO - 2019-07-05 17:43:20 --> Hooks Class Initialized
INFO - 2019-07-05 17:43:20 --> Hooks Class Initialized
DEBUG - 2019-07-05 17:43:20 --> UTF-8 Support Enabled
DEBUG - 2019-07-05 17:43:20 --> UTF-8 Support Enabled
INFO - 2019-07-05 17:43:20 --> Utf8 Class Initialized
INFO - 2019-07-05 17:43:20 --> Utf8 Class Initialized
INFO - 2019-07-05 17:43:20 --> URI Class Initialized
INFO - 2019-07-05 17:43:20 --> URI Class Initialized
INFO - 2019-07-05 17:43:20 --> Router Class Initialized
INFO - 2019-07-05 17:43:20 --> Router Class Initialized
INFO - 2019-07-05 17:43:20 --> Output Class Initialized
INFO - 2019-07-05 17:43:20 --> Output Class Initialized
INFO - 2019-07-05 17:43:20 --> Security Class Initialized
INFO - 2019-07-05 17:43:20 --> Security Class Initialized
DEBUG - 2019-07-05 17:43:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-05 17:43:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-05 17:43:20 --> Input Class Initialized
INFO - 2019-07-05 17:43:20 --> Input Class Initialized
INFO - 2019-07-05 17:43:20 --> Language Class Initialized
INFO - 2019-07-05 17:43:20 --> Language Class Initialized
INFO - 2019-07-05 17:43:20 --> Language Class Initialized
INFO - 2019-07-05 17:43:20 --> Language Class Initialized
INFO - 2019-07-05 17:43:20 --> Config Class Initialized
INFO - 2019-07-05 17:43:20 --> Loader Class Initialized
INFO - 2019-07-05 17:43:20 --> Config Class Initialized
INFO - 2019-07-05 17:43:20 --> Loader Class Initialized
DEBUG - 2019-07-05 17:43:20 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-05 17:43:20 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-05 17:43:20 --> Helper loaded: url_helper
INFO - 2019-07-05 17:43:20 --> Helper loaded: url_helper
INFO - 2019-07-05 17:43:20 --> Helper loaded: inflector_helper
INFO - 2019-07-05 17:43:20 --> Helper loaded: inflector_helper
INFO - 2019-07-05 17:43:20 --> Helper loaded: string_helper
INFO - 2019-07-05 17:43:21 --> Helper loaded: string_helper
INFO - 2019-07-05 17:43:21 --> Helper loaded: array_helper
INFO - 2019-07-05 17:43:21 --> Helper loaded: array_helper
INFO - 2019-07-05 17:43:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-05 17:43:21 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-05 17:43:21 --> Database Driver Class Initialized
INFO - 2019-07-05 17:43:21 --> Controller Class Initialized
INFO - 2019-07-05 23:43:21 --> Helper loaded: language_helper
INFO - 2019-07-05 23:43:21 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-05 23:43:21 --> Model Class Initialized
INFO - 2019-07-05 23:43:21 --> Model Class Initialized
INFO - 2019-07-05 23:43:21 --> Model Class Initialized
INFO - 2019-07-05 23:43:21 --> Model Class Initialized
INFO - 2019-07-05 23:43:21 --> Model Class Initialized
INFO - 2019-07-05 23:43:21 --> Final output sent to browser
DEBUG - 2019-07-05 23:43:21 --> Total execution time: 0.4567
INFO - 2019-07-05 17:43:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-05 17:43:21 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-05 17:43:21 --> Database Driver Class Initialized
INFO - 2019-07-05 17:43:21 --> Controller Class Initialized
INFO - 2019-07-05 23:43:21 --> Helper loaded: language_helper
INFO - 2019-07-05 23:43:21 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-05 23:43:21 --> Model Class Initialized
INFO - 2019-07-05 23:43:21 --> Model Class Initialized
INFO - 2019-07-05 23:43:21 --> Model Class Initialized
INFO - 2019-07-05 23:43:21 --> Model Class Initialized
INFO - 2019-07-05 23:43:21 --> Helper loaded: form_helper
INFO - 2019-07-05 23:43:21 --> Form Validation Class Initialized
DEBUG - 2019-07-05 23:43:21 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-05 23:43:21 --> Model Class Initialized
INFO - 2019-07-05 23:43:21 --> Model Class Initialized
INFO - 2019-07-05 23:43:21 --> Final output sent to browser
DEBUG - 2019-07-05 23:43:21 --> Total execution time: 0.6323
INFO - 2019-07-05 17:44:15 --> Config Class Initialized
INFO - 2019-07-05 17:44:15 --> Hooks Class Initialized
INFO - 2019-07-05 17:44:15 --> Config Class Initialized
INFO - 2019-07-05 17:44:15 --> Hooks Class Initialized
DEBUG - 2019-07-05 17:44:15 --> UTF-8 Support Enabled
DEBUG - 2019-07-05 17:44:15 --> UTF-8 Support Enabled
INFO - 2019-07-05 17:44:15 --> Utf8 Class Initialized
INFO - 2019-07-05 17:44:15 --> Utf8 Class Initialized
INFO - 2019-07-05 17:44:15 --> URI Class Initialized
INFO - 2019-07-05 17:44:15 --> URI Class Initialized
INFO - 2019-07-05 17:44:15 --> Router Class Initialized
INFO - 2019-07-05 17:44:15 --> Router Class Initialized
INFO - 2019-07-05 17:44:15 --> Output Class Initialized
INFO - 2019-07-05 17:44:15 --> Output Class Initialized
INFO - 2019-07-05 17:44:15 --> Security Class Initialized
INFO - 2019-07-05 17:44:15 --> Security Class Initialized
DEBUG - 2019-07-05 17:44:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-05 17:44:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-05 17:44:15 --> Input Class Initialized
INFO - 2019-07-05 17:44:15 --> Input Class Initialized
INFO - 2019-07-05 17:44:15 --> Language Class Initialized
INFO - 2019-07-05 17:44:16 --> Language Class Initialized
INFO - 2019-07-05 17:44:16 --> Language Class Initialized
INFO - 2019-07-05 17:44:16 --> Language Class Initialized
INFO - 2019-07-05 17:44:16 --> Config Class Initialized
INFO - 2019-07-05 17:44:16 --> Config Class Initialized
INFO - 2019-07-05 17:44:16 --> Loader Class Initialized
INFO - 2019-07-05 17:44:16 --> Loader Class Initialized
DEBUG - 2019-07-05 17:44:16 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-05 17:44:16 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-05 17:44:16 --> Helper loaded: url_helper
INFO - 2019-07-05 17:44:16 --> Helper loaded: url_helper
INFO - 2019-07-05 17:44:16 --> Helper loaded: inflector_helper
INFO - 2019-07-05 17:44:16 --> Helper loaded: inflector_helper
INFO - 2019-07-05 17:44:16 --> Helper loaded: string_helper
INFO - 2019-07-05 17:44:16 --> Helper loaded: string_helper
INFO - 2019-07-05 17:44:16 --> Helper loaded: array_helper
INFO - 2019-07-05 17:44:16 --> Helper loaded: array_helper
INFO - 2019-07-05 17:44:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-05 17:44:16 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-05 17:44:16 --> Database Driver Class Initialized
INFO - 2019-07-05 17:44:16 --> Controller Class Initialized
INFO - 2019-07-05 23:44:16 --> Helper loaded: language_helper
INFO - 2019-07-05 23:44:16 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-05 23:44:16 --> Model Class Initialized
INFO - 2019-07-05 23:44:16 --> Model Class Initialized
INFO - 2019-07-05 23:44:16 --> Model Class Initialized
INFO - 2019-07-05 23:44:16 --> Model Class Initialized
INFO - 2019-07-05 23:44:16 --> Model Class Initialized
INFO - 2019-07-05 23:44:16 --> Final output sent to browser
DEBUG - 2019-07-05 23:44:16 --> Total execution time: 0.5351
INFO - 2019-07-05 17:44:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-05 17:44:16 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-05 17:44:16 --> Database Driver Class Initialized
INFO - 2019-07-05 17:44:16 --> Controller Class Initialized
INFO - 2019-07-05 23:44:16 --> Helper loaded: language_helper
INFO - 2019-07-05 23:44:16 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-05 23:44:16 --> Model Class Initialized
INFO - 2019-07-05 23:44:16 --> Model Class Initialized
INFO - 2019-07-05 23:44:16 --> Model Class Initialized
INFO - 2019-07-05 23:44:16 --> Model Class Initialized
INFO - 2019-07-05 23:44:16 --> Helper loaded: form_helper
INFO - 2019-07-05 23:44:16 --> Form Validation Class Initialized
DEBUG - 2019-07-05 23:44:16 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-05 23:44:16 --> Model Class Initialized
INFO - 2019-07-05 23:44:16 --> Model Class Initialized
INFO - 2019-07-05 23:44:16 --> Final output sent to browser
DEBUG - 2019-07-05 23:44:16 --> Total execution time: 0.7188
INFO - 2019-07-05 17:44:52 --> Config Class Initialized
INFO - 2019-07-05 17:44:52 --> Config Class Initialized
INFO - 2019-07-05 17:44:52 --> Hooks Class Initialized
INFO - 2019-07-05 17:44:52 --> Hooks Class Initialized
DEBUG - 2019-07-05 17:44:52 --> UTF-8 Support Enabled
DEBUG - 2019-07-05 17:44:52 --> UTF-8 Support Enabled
INFO - 2019-07-05 17:44:52 --> Utf8 Class Initialized
INFO - 2019-07-05 17:44:52 --> Utf8 Class Initialized
INFO - 2019-07-05 17:44:52 --> URI Class Initialized
INFO - 2019-07-05 17:44:52 --> URI Class Initialized
INFO - 2019-07-05 17:44:52 --> Router Class Initialized
INFO - 2019-07-05 17:44:52 --> Router Class Initialized
INFO - 2019-07-05 17:44:52 --> Output Class Initialized
INFO - 2019-07-05 17:44:52 --> Output Class Initialized
INFO - 2019-07-05 17:44:52 --> Security Class Initialized
INFO - 2019-07-05 17:44:52 --> Security Class Initialized
DEBUG - 2019-07-05 17:44:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-05 17:44:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-05 17:44:52 --> Input Class Initialized
INFO - 2019-07-05 17:44:52 --> Input Class Initialized
INFO - 2019-07-05 17:44:52 --> Language Class Initialized
INFO - 2019-07-05 17:44:52 --> Language Class Initialized
INFO - 2019-07-05 17:44:52 --> Language Class Initialized
INFO - 2019-07-05 17:44:52 --> Language Class Initialized
INFO - 2019-07-05 17:44:52 --> Config Class Initialized
INFO - 2019-07-05 17:44:52 --> Config Class Initialized
INFO - 2019-07-05 17:44:52 --> Loader Class Initialized
INFO - 2019-07-05 17:44:52 --> Loader Class Initialized
DEBUG - 2019-07-05 17:44:52 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-05 17:44:53 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-05 17:44:53 --> Helper loaded: url_helper
INFO - 2019-07-05 17:44:53 --> Helper loaded: url_helper
INFO - 2019-07-05 17:44:53 --> Helper loaded: inflector_helper
INFO - 2019-07-05 17:44:53 --> Helper loaded: inflector_helper
INFO - 2019-07-05 17:44:53 --> Helper loaded: string_helper
INFO - 2019-07-05 17:44:53 --> Helper loaded: string_helper
INFO - 2019-07-05 17:44:53 --> Helper loaded: array_helper
INFO - 2019-07-05 17:44:53 --> Helper loaded: array_helper
INFO - 2019-07-05 17:44:53 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-05 17:44:53 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-05 17:44:53 --> Database Driver Class Initialized
INFO - 2019-07-05 17:44:53 --> Controller Class Initialized
INFO - 2019-07-05 23:44:53 --> Helper loaded: language_helper
INFO - 2019-07-05 23:44:53 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-05 23:44:53 --> Model Class Initialized
INFO - 2019-07-05 23:44:53 --> Model Class Initialized
INFO - 2019-07-05 23:44:53 --> Model Class Initialized
INFO - 2019-07-05 23:44:53 --> Model Class Initialized
INFO - 2019-07-05 23:44:53 --> Model Class Initialized
INFO - 2019-07-05 23:44:53 --> Final output sent to browser
DEBUG - 2019-07-05 23:44:53 --> Total execution time: 0.4421
INFO - 2019-07-05 17:44:53 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-05 17:44:53 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-05 17:44:53 --> Database Driver Class Initialized
INFO - 2019-07-05 17:44:53 --> Controller Class Initialized
INFO - 2019-07-05 23:44:53 --> Helper loaded: language_helper
INFO - 2019-07-05 23:44:53 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-05 23:44:53 --> Model Class Initialized
INFO - 2019-07-05 23:44:53 --> Model Class Initialized
INFO - 2019-07-05 23:44:53 --> Model Class Initialized
INFO - 2019-07-05 23:44:53 --> Model Class Initialized
INFO - 2019-07-05 23:44:53 --> Helper loaded: form_helper
INFO - 2019-07-05 23:44:53 --> Form Validation Class Initialized
DEBUG - 2019-07-05 23:44:53 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-05 23:44:53 --> Model Class Initialized
INFO - 2019-07-05 23:44:53 --> Model Class Initialized
INFO - 2019-07-05 23:44:53 --> Final output sent to browser
DEBUG - 2019-07-05 23:44:53 --> Total execution time: 0.6186
INFO - 2019-07-05 17:47:47 --> Config Class Initialized
INFO - 2019-07-05 17:47:47 --> Config Class Initialized
INFO - 2019-07-05 17:47:47 --> Hooks Class Initialized
INFO - 2019-07-05 17:47:47 --> Hooks Class Initialized
DEBUG - 2019-07-05 17:47:47 --> UTF-8 Support Enabled
DEBUG - 2019-07-05 17:47:47 --> UTF-8 Support Enabled
INFO - 2019-07-05 17:47:47 --> Utf8 Class Initialized
INFO - 2019-07-05 17:47:47 --> Utf8 Class Initialized
INFO - 2019-07-05 17:47:47 --> URI Class Initialized
INFO - 2019-07-05 17:47:47 --> URI Class Initialized
INFO - 2019-07-05 17:47:47 --> Router Class Initialized
INFO - 2019-07-05 17:47:47 --> Router Class Initialized
INFO - 2019-07-05 17:47:47 --> Output Class Initialized
INFO - 2019-07-05 17:47:47 --> Output Class Initialized
INFO - 2019-07-05 17:47:47 --> Security Class Initialized
INFO - 2019-07-05 17:47:47 --> Security Class Initialized
DEBUG - 2019-07-05 17:47:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-05 17:47:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-05 17:47:47 --> Input Class Initialized
INFO - 2019-07-05 17:47:47 --> Input Class Initialized
INFO - 2019-07-05 17:47:47 --> Language Class Initialized
INFO - 2019-07-05 17:47:47 --> Language Class Initialized
INFO - 2019-07-05 17:47:47 --> Language Class Initialized
INFO - 2019-07-05 17:47:47 --> Language Class Initialized
INFO - 2019-07-05 17:47:47 --> Config Class Initialized
INFO - 2019-07-05 17:47:47 --> Config Class Initialized
INFO - 2019-07-05 17:47:47 --> Loader Class Initialized
INFO - 2019-07-05 17:47:47 --> Loader Class Initialized
DEBUG - 2019-07-05 17:47:47 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-05 17:47:47 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-05 17:47:47 --> Helper loaded: url_helper
INFO - 2019-07-05 17:47:47 --> Helper loaded: url_helper
INFO - 2019-07-05 17:47:47 --> Helper loaded: inflector_helper
INFO - 2019-07-05 17:47:47 --> Helper loaded: inflector_helper
INFO - 2019-07-05 17:47:47 --> Helper loaded: string_helper
INFO - 2019-07-05 17:47:47 --> Helper loaded: array_helper
INFO - 2019-07-05 17:47:47 --> Helper loaded: string_helper
INFO - 2019-07-05 17:47:48 --> Session: Class initialized using 'files' driver.
INFO - 2019-07-05 17:47:48 --> Helper loaded: array_helper
DEBUG - 2019-07-05 17:47:48 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-05 17:47:48 --> Database Driver Class Initialized
INFO - 2019-07-05 17:47:48 --> Controller Class Initialized
INFO - 2019-07-05 23:47:48 --> Helper loaded: language_helper
INFO - 2019-07-05 23:47:48 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-05 23:47:48 --> Model Class Initialized
INFO - 2019-07-05 23:47:48 --> Model Class Initialized
INFO - 2019-07-05 23:47:48 --> Model Class Initialized
INFO - 2019-07-05 23:47:48 --> Model Class Initialized
INFO - 2019-07-05 23:47:48 --> Model Class Initialized
INFO - 2019-07-05 23:47:48 --> Final output sent to browser
DEBUG - 2019-07-05 23:47:48 --> Total execution time: 0.4784
INFO - 2019-07-05 17:47:48 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-05 17:47:48 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-05 17:47:48 --> Database Driver Class Initialized
INFO - 2019-07-05 17:47:48 --> Controller Class Initialized
INFO - 2019-07-05 23:47:48 --> Helper loaded: language_helper
INFO - 2019-07-05 23:47:48 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-05 23:47:48 --> Model Class Initialized
INFO - 2019-07-05 23:47:48 --> Model Class Initialized
INFO - 2019-07-05 23:47:48 --> Model Class Initialized
INFO - 2019-07-05 23:47:48 --> Model Class Initialized
INFO - 2019-07-05 23:47:48 --> Helper loaded: form_helper
INFO - 2019-07-05 23:47:48 --> Form Validation Class Initialized
DEBUG - 2019-07-05 23:47:48 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-05 23:47:48 --> Model Class Initialized
INFO - 2019-07-05 23:47:48 --> Model Class Initialized
INFO - 2019-07-05 23:47:48 --> Final output sent to browser
DEBUG - 2019-07-05 23:47:48 --> Total execution time: 0.6637
INFO - 2019-07-05 17:49:10 --> Config Class Initialized
INFO - 2019-07-05 17:49:10 --> Hooks Class Initialized
INFO - 2019-07-05 17:49:10 --> Config Class Initialized
DEBUG - 2019-07-05 17:49:10 --> UTF-8 Support Enabled
INFO - 2019-07-05 17:49:10 --> Hooks Class Initialized
INFO - 2019-07-05 17:49:10 --> Utf8 Class Initialized
DEBUG - 2019-07-05 17:49:10 --> UTF-8 Support Enabled
INFO - 2019-07-05 17:49:10 --> URI Class Initialized
INFO - 2019-07-05 17:49:10 --> Utf8 Class Initialized
INFO - 2019-07-05 17:49:10 --> URI Class Initialized
INFO - 2019-07-05 17:49:10 --> Router Class Initialized
INFO - 2019-07-05 17:49:10 --> Router Class Initialized
INFO - 2019-07-05 17:49:10 --> Output Class Initialized
INFO - 2019-07-05 17:49:10 --> Output Class Initialized
INFO - 2019-07-05 17:49:10 --> Security Class Initialized
INFO - 2019-07-05 17:49:10 --> Security Class Initialized
DEBUG - 2019-07-05 17:49:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-05 17:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-05 17:49:10 --> Input Class Initialized
INFO - 2019-07-05 17:49:10 --> Input Class Initialized
INFO - 2019-07-05 17:49:10 --> Language Class Initialized
INFO - 2019-07-05 17:49:10 --> Language Class Initialized
INFO - 2019-07-05 17:49:10 --> Language Class Initialized
INFO - 2019-07-05 17:49:10 --> Language Class Initialized
INFO - 2019-07-05 17:49:10 --> Config Class Initialized
INFO - 2019-07-05 17:49:10 --> Loader Class Initialized
INFO - 2019-07-05 17:49:10 --> Config Class Initialized
INFO - 2019-07-05 17:49:10 --> Loader Class Initialized
DEBUG - 2019-07-05 17:49:10 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-05 17:49:10 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-05 17:49:10 --> Helper loaded: url_helper
INFO - 2019-07-05 17:49:10 --> Helper loaded: url_helper
INFO - 2019-07-05 17:49:10 --> Helper loaded: inflector_helper
INFO - 2019-07-05 17:49:10 --> Helper loaded: inflector_helper
INFO - 2019-07-05 17:49:10 --> Helper loaded: string_helper
INFO - 2019-07-05 17:49:10 --> Helper loaded: string_helper
INFO - 2019-07-05 17:49:10 --> Helper loaded: array_helper
INFO - 2019-07-05 17:49:10 --> Helper loaded: array_helper
INFO - 2019-07-05 17:49:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-05 17:49:10 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-05 17:49:10 --> Database Driver Class Initialized
INFO - 2019-07-05 17:49:10 --> Controller Class Initialized
INFO - 2019-07-05 23:49:10 --> Helper loaded: language_helper
INFO - 2019-07-05 23:49:10 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-05 23:49:10 --> Model Class Initialized
INFO - 2019-07-05 23:49:10 --> Model Class Initialized
INFO - 2019-07-05 23:49:10 --> Model Class Initialized
INFO - 2019-07-05 23:49:10 --> Model Class Initialized
INFO - 2019-07-05 23:49:10 --> Model Class Initialized
INFO - 2019-07-05 23:49:10 --> Final output sent to browser
DEBUG - 2019-07-05 23:49:10 --> Total execution time: 0.4448
INFO - 2019-07-05 17:49:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-05 17:49:10 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-05 17:49:11 --> Database Driver Class Initialized
INFO - 2019-07-05 17:49:11 --> Controller Class Initialized
INFO - 2019-07-05 23:49:11 --> Helper loaded: language_helper
INFO - 2019-07-05 23:49:11 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-05 23:49:11 --> Model Class Initialized
INFO - 2019-07-05 23:49:11 --> Model Class Initialized
INFO - 2019-07-05 23:49:11 --> Model Class Initialized
INFO - 2019-07-05 23:49:11 --> Model Class Initialized
INFO - 2019-07-05 23:49:11 --> Helper loaded: form_helper
INFO - 2019-07-05 23:49:11 --> Form Validation Class Initialized
DEBUG - 2019-07-05 23:49:11 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-05 23:49:11 --> Model Class Initialized
INFO - 2019-07-05 23:49:11 --> Model Class Initialized
INFO - 2019-07-05 23:49:11 --> Final output sent to browser
DEBUG - 2019-07-05 23:49:11 --> Total execution time: 0.6040
INFO - 2019-07-05 17:49:34 --> Config Class Initialized
INFO - 2019-07-05 17:49:34 --> Hooks Class Initialized
INFO - 2019-07-05 17:49:34 --> Config Class Initialized
INFO - 2019-07-05 17:49:34 --> Hooks Class Initialized
DEBUG - 2019-07-05 17:49:34 --> UTF-8 Support Enabled
DEBUG - 2019-07-05 17:49:34 --> UTF-8 Support Enabled
INFO - 2019-07-05 17:49:34 --> Utf8 Class Initialized
INFO - 2019-07-05 17:49:34 --> Utf8 Class Initialized
INFO - 2019-07-05 17:49:34 --> URI Class Initialized
INFO - 2019-07-05 17:49:34 --> URI Class Initialized
INFO - 2019-07-05 17:49:34 --> Router Class Initialized
INFO - 2019-07-05 17:49:34 --> Router Class Initialized
INFO - 2019-07-05 17:49:34 --> Output Class Initialized
INFO - 2019-07-05 17:49:34 --> Output Class Initialized
INFO - 2019-07-05 17:49:34 --> Security Class Initialized
INFO - 2019-07-05 17:49:34 --> Security Class Initialized
DEBUG - 2019-07-05 17:49:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-05 17:49:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-05 17:49:34 --> Input Class Initialized
INFO - 2019-07-05 17:49:34 --> Input Class Initialized
INFO - 2019-07-05 17:49:34 --> Language Class Initialized
INFO - 2019-07-05 17:49:34 --> Language Class Initialized
INFO - 2019-07-05 17:49:34 --> Language Class Initialized
INFO - 2019-07-05 17:49:34 --> Language Class Initialized
INFO - 2019-07-05 17:49:34 --> Config Class Initialized
INFO - 2019-07-05 17:49:34 --> Loader Class Initialized
INFO - 2019-07-05 17:49:34 --> Config Class Initialized
INFO - 2019-07-05 17:49:34 --> Loader Class Initialized
DEBUG - 2019-07-05 17:49:34 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-05 17:49:34 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-05 17:49:34 --> Helper loaded: url_helper
INFO - 2019-07-05 17:49:34 --> Helper loaded: url_helper
INFO - 2019-07-05 17:49:34 --> Helper loaded: inflector_helper
INFO - 2019-07-05 17:49:34 --> Helper loaded: inflector_helper
INFO - 2019-07-05 17:49:34 --> Helper loaded: string_helper
INFO - 2019-07-05 17:49:34 --> Helper loaded: string_helper
INFO - 2019-07-05 17:49:34 --> Helper loaded: array_helper
INFO - 2019-07-05 17:49:34 --> Helper loaded: array_helper
INFO - 2019-07-05 17:49:34 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-05 17:49:34 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-05 17:49:34 --> Database Driver Class Initialized
INFO - 2019-07-05 17:49:34 --> Controller Class Initialized
INFO - 2019-07-05 23:49:34 --> Helper loaded: language_helper
INFO - 2019-07-05 23:49:34 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-05 23:49:34 --> Model Class Initialized
INFO - 2019-07-05 23:49:34 --> Model Class Initialized
INFO - 2019-07-05 23:49:34 --> Model Class Initialized
INFO - 2019-07-05 23:49:34 --> Model Class Initialized
INFO - 2019-07-05 23:49:34 --> Model Class Initialized
INFO - 2019-07-05 23:49:34 --> Final output sent to browser
DEBUG - 2019-07-05 23:49:34 --> Total execution time: 0.5672
INFO - 2019-07-05 17:49:34 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-05 17:49:34 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-05 17:49:34 --> Database Driver Class Initialized
INFO - 2019-07-05 17:49:34 --> Controller Class Initialized
INFO - 2019-07-05 23:49:34 --> Helper loaded: language_helper
INFO - 2019-07-05 23:49:34 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-05 23:49:34 --> Model Class Initialized
INFO - 2019-07-05 23:49:34 --> Model Class Initialized
INFO - 2019-07-05 23:49:34 --> Model Class Initialized
INFO - 2019-07-05 23:49:34 --> Model Class Initialized
INFO - 2019-07-05 23:49:34 --> Helper loaded: form_helper
INFO - 2019-07-05 23:49:34 --> Form Validation Class Initialized
DEBUG - 2019-07-05 23:49:34 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-05 23:49:34 --> Model Class Initialized
INFO - 2019-07-05 23:49:34 --> Model Class Initialized
INFO - 2019-07-05 23:49:34 --> Final output sent to browser
DEBUG - 2019-07-05 23:49:34 --> Total execution time: 0.7522
INFO - 2019-07-05 17:50:01 --> Config Class Initialized
INFO - 2019-07-05 17:50:01 --> Hooks Class Initialized
DEBUG - 2019-07-05 17:50:01 --> UTF-8 Support Enabled
INFO - 2019-07-05 17:50:01 --> Config Class Initialized
INFO - 2019-07-05 17:50:01 --> Utf8 Class Initialized
INFO - 2019-07-05 17:50:01 --> URI Class Initialized
INFO - 2019-07-05 17:50:01 --> Hooks Class Initialized
INFO - 2019-07-05 17:50:01 --> Router Class Initialized
DEBUG - 2019-07-05 17:50:01 --> UTF-8 Support Enabled
INFO - 2019-07-05 17:50:01 --> Utf8 Class Initialized
INFO - 2019-07-05 17:50:01 --> Output Class Initialized
INFO - 2019-07-05 17:50:01 --> Security Class Initialized
DEBUG - 2019-07-05 17:50:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-05 17:50:01 --> Input Class Initialized
INFO - 2019-07-05 17:50:01 --> Language Class Initialized
INFO - 2019-07-05 17:50:01 --> Language Class Initialized
INFO - 2019-07-05 17:50:01 --> Config Class Initialized
INFO - 2019-07-05 17:50:01 --> Loader Class Initialized
DEBUG - 2019-07-05 17:50:01 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-05 17:50:01 --> Helper loaded: url_helper
INFO - 2019-07-05 17:50:01 --> URI Class Initialized
INFO - 2019-07-05 17:50:01 --> Helper loaded: inflector_helper
INFO - 2019-07-05 17:50:01 --> Helper loaded: string_helper
INFO - 2019-07-05 17:50:01 --> Router Class Initialized
INFO - 2019-07-05 17:50:01 --> Helper loaded: array_helper
INFO - 2019-07-05 17:50:01 --> Output Class Initialized
INFO - 2019-07-05 17:50:01 --> Session: Class initialized using 'files' driver.
INFO - 2019-07-05 17:50:01 --> Security Class Initialized
DEBUG - 2019-07-05 17:50:01 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
DEBUG - 2019-07-05 17:50:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-05 17:50:01 --> Input Class Initialized
INFO - 2019-07-05 17:50:01 --> Database Driver Class Initialized
INFO - 2019-07-05 17:50:01 --> Language Class Initialized
INFO - 2019-07-05 17:50:01 --> Controller Class Initialized
INFO - 2019-07-05 17:50:01 --> Language Class Initialized
INFO - 2019-07-05 23:50:01 --> Helper loaded: language_helper
INFO - 2019-07-05 17:50:01 --> Config Class Initialized
INFO - 2019-07-05 23:50:01 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-05 17:50:01 --> Loader Class Initialized
DEBUG - 2019-07-05 17:50:01 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-05 23:50:01 --> Model Class Initialized
INFO - 2019-07-05 17:50:01 --> Helper loaded: url_helper
INFO - 2019-07-05 23:50:01 --> Model Class Initialized
INFO - 2019-07-05 17:50:01 --> Helper loaded: inflector_helper
INFO - 2019-07-05 23:50:01 --> Model Class Initialized
INFO - 2019-07-05 17:50:01 --> Helper loaded: string_helper
INFO - 2019-07-05 23:50:01 --> Model Class Initialized
INFO - 2019-07-05 17:50:01 --> Helper loaded: array_helper
INFO - 2019-07-05 23:50:01 --> Model Class Initialized
INFO - 2019-07-05 23:50:02 --> Final output sent to browser
DEBUG - 2019-07-05 23:50:02 --> Total execution time: 0.7957
INFO - 2019-07-05 17:50:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-05 17:50:02 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-05 17:50:02 --> Database Driver Class Initialized
INFO - 2019-07-05 17:50:02 --> Controller Class Initialized
INFO - 2019-07-05 23:50:02 --> Helper loaded: language_helper
INFO - 2019-07-05 23:50:02 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-05 23:50:02 --> Model Class Initialized
INFO - 2019-07-05 23:50:02 --> Model Class Initialized
INFO - 2019-07-05 23:50:02 --> Model Class Initialized
INFO - 2019-07-05 23:50:02 --> Model Class Initialized
INFO - 2019-07-05 23:50:02 --> Helper loaded: form_helper
INFO - 2019-07-05 23:50:02 --> Form Validation Class Initialized
DEBUG - 2019-07-05 23:50:02 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-05 23:50:02 --> Model Class Initialized
INFO - 2019-07-05 23:50:02 --> Model Class Initialized
INFO - 2019-07-05 23:50:02 --> Final output sent to browser
DEBUG - 2019-07-05 23:50:02 --> Total execution time: 1.0255
INFO - 2019-07-05 17:50:25 --> Config Class Initialized
INFO - 2019-07-05 17:50:25 --> Config Class Initialized
INFO - 2019-07-05 17:50:25 --> Hooks Class Initialized
INFO - 2019-07-05 17:50:25 --> Hooks Class Initialized
DEBUG - 2019-07-05 17:50:25 --> UTF-8 Support Enabled
DEBUG - 2019-07-05 17:50:25 --> UTF-8 Support Enabled
INFO - 2019-07-05 17:50:25 --> Utf8 Class Initialized
INFO - 2019-07-05 17:50:25 --> Utf8 Class Initialized
INFO - 2019-07-05 17:50:25 --> URI Class Initialized
INFO - 2019-07-05 17:50:25 --> URI Class Initialized
INFO - 2019-07-05 17:50:25 --> Router Class Initialized
INFO - 2019-07-05 17:50:25 --> Router Class Initialized
INFO - 2019-07-05 17:50:25 --> Output Class Initialized
INFO - 2019-07-05 17:50:25 --> Output Class Initialized
INFO - 2019-07-05 17:50:25 --> Security Class Initialized
INFO - 2019-07-05 17:50:25 --> Security Class Initialized
DEBUG - 2019-07-05 17:50:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-05 17:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-05 17:50:25 --> Input Class Initialized
INFO - 2019-07-05 17:50:25 --> Input Class Initialized
INFO - 2019-07-05 17:50:25 --> Language Class Initialized
INFO - 2019-07-05 17:50:25 --> Language Class Initialized
INFO - 2019-07-05 17:50:25 --> Language Class Initialized
INFO - 2019-07-05 17:50:25 --> Language Class Initialized
INFO - 2019-07-05 17:50:25 --> Config Class Initialized
INFO - 2019-07-05 17:50:25 --> Loader Class Initialized
INFO - 2019-07-05 17:50:25 --> Config Class Initialized
INFO - 2019-07-05 17:50:25 --> Loader Class Initialized
DEBUG - 2019-07-05 17:50:25 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-05 17:50:25 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-05 17:50:25 --> Helper loaded: url_helper
INFO - 2019-07-05 17:50:25 --> Helper loaded: url_helper
INFO - 2019-07-05 17:50:25 --> Helper loaded: inflector_helper
INFO - 2019-07-05 17:50:25 --> Helper loaded: inflector_helper
INFO - 2019-07-05 17:50:25 --> Helper loaded: string_helper
INFO - 2019-07-05 17:50:25 --> Helper loaded: string_helper
INFO - 2019-07-05 17:50:25 --> Helper loaded: array_helper
INFO - 2019-07-05 17:50:25 --> Helper loaded: array_helper
INFO - 2019-07-05 17:50:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-05 17:50:25 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-05 17:50:25 --> Database Driver Class Initialized
INFO - 2019-07-05 17:50:25 --> Controller Class Initialized
INFO - 2019-07-05 23:50:25 --> Helper loaded: language_helper
INFO - 2019-07-05 23:50:25 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-05 23:50:25 --> Model Class Initialized
INFO - 2019-07-05 23:50:25 --> Model Class Initialized
INFO - 2019-07-05 23:50:25 --> Model Class Initialized
INFO - 2019-07-05 23:50:25 --> Model Class Initialized
INFO - 2019-07-05 23:50:25 --> Helper loaded: form_helper
INFO - 2019-07-05 23:50:25 --> Form Validation Class Initialized
DEBUG - 2019-07-05 23:50:25 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-05 23:50:25 --> Model Class Initialized
INFO - 2019-07-05 23:50:25 --> Model Class Initialized
INFO - 2019-07-05 23:50:25 --> Final output sent to browser
DEBUG - 2019-07-05 23:50:25 --> Total execution time: 0.4848
INFO - 2019-07-05 17:50:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-05 17:50:26 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-05 17:50:26 --> Database Driver Class Initialized
INFO - 2019-07-05 17:50:26 --> Controller Class Initialized
INFO - 2019-07-05 23:50:26 --> Helper loaded: language_helper
INFO - 2019-07-05 23:50:26 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-05 23:50:26 --> Model Class Initialized
INFO - 2019-07-05 23:50:26 --> Model Class Initialized
INFO - 2019-07-05 23:50:26 --> Model Class Initialized
INFO - 2019-07-05 23:50:26 --> Model Class Initialized
INFO - 2019-07-05 23:50:26 --> Model Class Initialized
INFO - 2019-07-05 23:50:26 --> Final output sent to browser
DEBUG - 2019-07-05 23:50:26 --> Total execution time: 0.6468
INFO - 2019-07-05 17:51:03 --> Config Class Initialized
INFO - 2019-07-05 17:51:03 --> Hooks Class Initialized
INFO - 2019-07-05 17:51:03 --> Config Class Initialized
INFO - 2019-07-05 17:51:03 --> Hooks Class Initialized
DEBUG - 2019-07-05 17:51:03 --> UTF-8 Support Enabled
INFO - 2019-07-05 17:51:03 --> Utf8 Class Initialized
DEBUG - 2019-07-05 17:51:03 --> UTF-8 Support Enabled
INFO - 2019-07-05 17:51:03 --> Utf8 Class Initialized
INFO - 2019-07-05 17:51:03 --> URI Class Initialized
INFO - 2019-07-05 17:51:03 --> URI Class Initialized
INFO - 2019-07-05 17:51:03 --> Router Class Initialized
INFO - 2019-07-05 17:51:03 --> Router Class Initialized
INFO - 2019-07-05 17:51:03 --> Output Class Initialized
INFO - 2019-07-05 17:51:03 --> Security Class Initialized
INFO - 2019-07-05 17:51:03 --> Output Class Initialized
DEBUG - 2019-07-05 17:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-05 17:51:03 --> Input Class Initialized
INFO - 2019-07-05 17:51:03 --> Language Class Initialized
INFO - 2019-07-05 17:51:03 --> Security Class Initialized
INFO - 2019-07-05 17:51:03 --> Language Class Initialized
INFO - 2019-07-05 17:51:03 --> Config Class Initialized
INFO - 2019-07-05 17:51:03 --> Config Class Initialized
INFO - 2019-07-05 17:51:03 --> Loader Class Initialized
INFO - 2019-07-05 17:51:03 --> Hooks Class Initialized
DEBUG - 2019-07-05 17:51:03 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-05 17:51:03 --> UTF-8 Support Enabled
INFO - 2019-07-05 17:51:03 --> Helper loaded: url_helper
DEBUG - 2019-07-05 17:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-05 17:51:03 --> Utf8 Class Initialized
INFO - 2019-07-05 17:51:03 --> Config Class Initialized
INFO - 2019-07-05 17:51:03 --> Input Class Initialized
INFO - 2019-07-05 17:51:03 --> Helper loaded: inflector_helper
INFO - 2019-07-05 17:51:03 --> URI Class Initialized
INFO - 2019-07-05 17:51:03 --> Hooks Class Initialized
INFO - 2019-07-05 17:51:03 --> Language Class Initialized
INFO - 2019-07-05 17:51:03 --> Router Class Initialized
DEBUG - 2019-07-05 17:51:03 --> UTF-8 Support Enabled
INFO - 2019-07-05 17:51:03 --> Helper loaded: string_helper
INFO - 2019-07-05 17:51:03 --> Language Class Initialized
INFO - 2019-07-05 17:51:03 --> Output Class Initialized
INFO - 2019-07-05 17:51:03 --> Utf8 Class Initialized
INFO - 2019-07-05 17:51:03 --> Helper loaded: array_helper
INFO - 2019-07-05 17:51:03 --> Config Class Initialized
INFO - 2019-07-05 17:51:03 --> Security Class Initialized
INFO - 2019-07-05 17:51:03 --> Loader Class Initialized
INFO - 2019-07-05 17:51:03 --> Session: Class initialized using 'files' driver.
INFO - 2019-07-05 17:51:03 --> URI Class Initialized
DEBUG - 2019-07-05 17:51:03 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-05 17:51:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-05 17:51:03 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-05 17:51:03 --> Router Class Initialized
INFO - 2019-07-05 17:51:03 --> Input Class Initialized
INFO - 2019-07-05 17:51:03 --> Database Driver Class Initialized
INFO - 2019-07-05 17:51:03 --> Helper loaded: url_helper
INFO - 2019-07-05 17:51:03 --> Output Class Initialized
INFO - 2019-07-05 17:51:03 --> Language Class Initialized
INFO - 2019-07-05 17:51:04 --> Controller Class Initialized
INFO - 2019-07-05 17:51:04 --> Helper loaded: inflector_helper
INFO - 2019-07-05 17:51:04 --> Language Class Initialized
INFO - 2019-07-05 17:51:04 --> Security Class Initialized
INFO - 2019-07-05 23:51:04 --> Helper loaded: language_helper
INFO - 2019-07-05 17:51:04 --> Config Class Initialized
INFO - 2019-07-05 17:51:04 --> Helper loaded: string_helper
DEBUG - 2019-07-05 17:51:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-05 17:51:04 --> Loader Class Initialized
INFO - 2019-07-05 23:51:04 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-05 17:51:04 --> Helper loaded: array_helper
INFO - 2019-07-05 17:51:04 --> Input Class Initialized
DEBUG - 2019-07-05 17:51:04 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-05 17:51:04 --> Language Class Initialized
INFO - 2019-07-05 23:51:04 --> Model Class Initialized
INFO - 2019-07-05 17:51:04 --> Language Class Initialized
INFO - 2019-07-05 17:51:04 --> Helper loaded: url_helper
INFO - 2019-07-05 23:51:04 --> Model Class Initialized
INFO - 2019-07-05 17:51:04 --> Config Class Initialized
INFO - 2019-07-05 17:51:04 --> Helper loaded: inflector_helper
INFO - 2019-07-05 17:51:04 --> Loader Class Initialized
INFO - 2019-07-05 23:51:04 --> Model Class Initialized
DEBUG - 2019-07-05 17:51:04 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-05 17:51:04 --> Helper loaded: string_helper
INFO - 2019-07-05 23:51:04 --> Model Class Initialized
INFO - 2019-07-05 17:51:04 --> Helper loaded: url_helper
INFO - 2019-07-05 17:51:04 --> Helper loaded: array_helper
INFO - 2019-07-05 23:51:04 --> Helper loaded: form_helper
INFO - 2019-07-05 17:51:04 --> Helper loaded: inflector_helper
INFO - 2019-07-05 23:51:04 --> Form Validation Class Initialized
INFO - 2019-07-05 17:51:04 --> Helper loaded: string_helper
DEBUG - 2019-07-05 23:51:04 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-05 17:51:04 --> Helper loaded: array_helper
INFO - 2019-07-05 23:51:04 --> Model Class Initialized
INFO - 2019-07-05 23:51:04 --> Model Class Initialized
INFO - 2019-07-05 23:51:04 --> Final output sent to browser
DEBUG - 2019-07-05 23:51:04 --> Total execution time: 0.8247
INFO - 2019-07-05 17:51:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-05 17:51:04 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-05 17:51:04 --> Database Driver Class Initialized
INFO - 2019-07-05 17:51:04 --> Controller Class Initialized
INFO - 2019-07-05 23:51:04 --> Helper loaded: language_helper
INFO - 2019-07-05 23:51:04 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-05 23:51:04 --> Model Class Initialized
INFO - 2019-07-05 23:51:04 --> Model Class Initialized
INFO - 2019-07-05 23:51:04 --> Model Class Initialized
INFO - 2019-07-05 23:51:04 --> Model Class Initialized
INFO - 2019-07-05 23:51:04 --> Model Class Initialized
INFO - 2019-07-05 23:51:04 --> Final output sent to browser
DEBUG - 2019-07-05 23:51:04 --> Total execution time: 0.9645
INFO - 2019-07-05 17:51:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-05 17:51:04 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-05 17:51:04 --> Database Driver Class Initialized
INFO - 2019-07-05 17:51:04 --> Controller Class Initialized
INFO - 2019-07-05 23:51:04 --> Helper loaded: language_helper
INFO - 2019-07-05 23:51:04 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-05 23:51:04 --> Model Class Initialized
INFO - 2019-07-05 23:51:04 --> Model Class Initialized
INFO - 2019-07-05 23:51:04 --> Model Class Initialized
INFO - 2019-07-05 23:51:04 --> Model Class Initialized
INFO - 2019-07-05 23:51:04 --> Model Class Initialized
INFO - 2019-07-05 23:51:04 --> Final output sent to browser
DEBUG - 2019-07-05 23:51:04 --> Total execution time: 0.6660
INFO - 2019-07-05 17:51:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-05 17:51:04 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-05 17:51:04 --> Database Driver Class Initialized
INFO - 2019-07-05 17:51:04 --> Controller Class Initialized
INFO - 2019-07-05 23:51:04 --> Helper loaded: language_helper
INFO - 2019-07-05 23:51:04 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-05 23:51:04 --> Model Class Initialized
INFO - 2019-07-05 23:51:04 --> Model Class Initialized
INFO - 2019-07-05 23:51:04 --> Model Class Initialized
INFO - 2019-07-05 23:51:04 --> Model Class Initialized
INFO - 2019-07-05 23:51:04 --> Helper loaded: form_helper
INFO - 2019-07-05 23:51:04 --> Form Validation Class Initialized
DEBUG - 2019-07-05 23:51:04 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-05 23:51:04 --> Model Class Initialized
INFO - 2019-07-05 23:51:04 --> Model Class Initialized
INFO - 2019-07-05 23:51:04 --> Final output sent to browser
DEBUG - 2019-07-05 23:51:04 --> Total execution time: 0.8102
INFO - 2019-07-05 18:18:56 --> Config Class Initialized
INFO - 2019-07-05 18:18:57 --> Hooks Class Initialized
DEBUG - 2019-07-05 18:18:57 --> UTF-8 Support Enabled
INFO - 2019-07-05 18:18:57 --> Utf8 Class Initialized
INFO - 2019-07-05 18:18:57 --> URI Class Initialized
INFO - 2019-07-05 18:18:57 --> Router Class Initialized
INFO - 2019-07-05 18:18:57 --> Output Class Initialized
INFO - 2019-07-05 18:18:57 --> Security Class Initialized
DEBUG - 2019-07-05 18:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-05 18:18:57 --> Input Class Initialized
INFO - 2019-07-05 18:18:57 --> Language Class Initialized
INFO - 2019-07-05 18:18:57 --> Language Class Initialized
INFO - 2019-07-05 18:18:57 --> Config Class Initialized
INFO - 2019-07-05 18:18:57 --> Loader Class Initialized
DEBUG - 2019-07-05 18:18:57 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-05 18:18:57 --> Helper loaded: url_helper
INFO - 2019-07-05 18:18:57 --> Helper loaded: inflector_helper
INFO - 2019-07-05 18:18:57 --> Helper loaded: string_helper
INFO - 2019-07-05 18:18:57 --> Helper loaded: array_helper
INFO - 2019-07-05 18:18:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-05 18:18:57 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-05 18:18:57 --> Database Driver Class Initialized
INFO - 2019-07-05 18:18:57 --> Controller Class Initialized
INFO - 2019-07-05 18:19:22 --> Config Class Initialized
INFO - 2019-07-05 18:19:22 --> Hooks Class Initialized
INFO - 2019-07-05 18:19:22 --> Config Class Initialized
INFO - 2019-07-05 18:19:22 --> Hooks Class Initialized
DEBUG - 2019-07-05 18:19:22 --> UTF-8 Support Enabled
DEBUG - 2019-07-05 18:19:22 --> UTF-8 Support Enabled
INFO - 2019-07-05 18:19:22 --> Utf8 Class Initialized
INFO - 2019-07-05 18:19:22 --> Utf8 Class Initialized
INFO - 2019-07-05 18:19:22 --> URI Class Initialized
INFO - 2019-07-05 18:19:22 --> URI Class Initialized
INFO - 2019-07-05 18:19:22 --> Router Class Initialized
INFO - 2019-07-05 18:19:22 --> Router Class Initialized
INFO - 2019-07-05 18:19:22 --> Output Class Initialized
INFO - 2019-07-05 18:19:22 --> Output Class Initialized
INFO - 2019-07-05 18:19:22 --> Security Class Initialized
INFO - 2019-07-05 18:19:22 --> Security Class Initialized
DEBUG - 2019-07-05 18:19:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-05 18:19:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-05 18:19:22 --> Input Class Initialized
INFO - 2019-07-05 18:19:22 --> Input Class Initialized
INFO - 2019-07-05 18:19:22 --> Language Class Initialized
INFO - 2019-07-05 18:19:22 --> Language Class Initialized
INFO - 2019-07-05 18:19:22 --> Language Class Initialized
INFO - 2019-07-05 18:19:22 --> Config Class Initialized
INFO - 2019-07-05 18:19:22 --> Loader Class Initialized
INFO - 2019-07-05 18:19:22 --> Language Class Initialized
DEBUG - 2019-07-05 18:19:22 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-05 18:19:22 --> Config Class Initialized
INFO - 2019-07-05 18:19:22 --> Loader Class Initialized
INFO - 2019-07-05 18:19:22 --> Helper loaded: url_helper
DEBUG - 2019-07-05 18:19:22 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-05 18:19:22 --> Helper loaded: inflector_helper
INFO - 2019-07-05 18:19:22 --> Helper loaded: url_helper
INFO - 2019-07-05 18:19:22 --> Helper loaded: string_helper
INFO - 2019-07-05 18:19:22 --> Helper loaded: inflector_helper
INFO - 2019-07-05 18:19:22 --> Helper loaded: array_helper
INFO - 2019-07-05 18:19:22 --> Helper loaded: string_helper
INFO - 2019-07-05 18:19:22 --> Session: Class initialized using 'files' driver.
INFO - 2019-07-05 18:19:22 --> Helper loaded: array_helper
DEBUG - 2019-07-05 18:19:22 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-05 18:19:22 --> Database Driver Class Initialized
INFO - 2019-07-05 18:19:22 --> Controller Class Initialized
INFO - 2019-07-05 18:19:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-05 18:19:22 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-05 18:19:22 --> Database Driver Class Initialized
INFO - 2019-07-05 18:19:22 --> Controller Class Initialized
INFO - 2019-07-05 18:19:26 --> Config Class Initialized
INFO - 2019-07-05 18:19:26 --> Config Class Initialized
INFO - 2019-07-05 18:19:26 --> Hooks Class Initialized
INFO - 2019-07-05 18:19:26 --> Hooks Class Initialized
DEBUG - 2019-07-05 18:19:26 --> UTF-8 Support Enabled
DEBUG - 2019-07-05 18:19:26 --> UTF-8 Support Enabled
INFO - 2019-07-05 18:19:26 --> Utf8 Class Initialized
INFO - 2019-07-05 18:19:26 --> Utf8 Class Initialized
INFO - 2019-07-05 18:19:26 --> URI Class Initialized
INFO - 2019-07-05 18:19:27 --> URI Class Initialized
INFO - 2019-07-05 18:19:27 --> Router Class Initialized
INFO - 2019-07-05 18:19:27 --> Router Class Initialized
INFO - 2019-07-05 18:19:27 --> Output Class Initialized
INFO - 2019-07-05 18:19:27 --> Output Class Initialized
INFO - 2019-07-05 18:19:27 --> Security Class Initialized
INFO - 2019-07-05 18:19:27 --> Security Class Initialized
DEBUG - 2019-07-05 18:19:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-05 18:19:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-05 18:19:27 --> Input Class Initialized
INFO - 2019-07-05 18:19:27 --> Input Class Initialized
INFO - 2019-07-05 18:19:27 --> Language Class Initialized
INFO - 2019-07-05 18:19:27 --> Language Class Initialized
INFO - 2019-07-05 18:19:27 --> Language Class Initialized
INFO - 2019-07-05 18:19:27 --> Language Class Initialized
INFO - 2019-07-05 18:19:27 --> Config Class Initialized
INFO - 2019-07-05 18:19:27 --> Config Class Initialized
INFO - 2019-07-05 18:19:27 --> Loader Class Initialized
INFO - 2019-07-05 18:19:27 --> Loader Class Initialized
DEBUG - 2019-07-05 18:19:27 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-05 18:19:27 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-05 18:19:27 --> Helper loaded: url_helper
INFO - 2019-07-05 18:19:27 --> Helper loaded: url_helper
INFO - 2019-07-05 18:19:27 --> Helper loaded: inflector_helper
INFO - 2019-07-05 18:19:27 --> Helper loaded: inflector_helper
INFO - 2019-07-05 18:19:27 --> Helper loaded: string_helper
INFO - 2019-07-05 18:19:27 --> Helper loaded: string_helper
INFO - 2019-07-05 18:19:27 --> Helper loaded: array_helper
INFO - 2019-07-05 18:19:27 --> Helper loaded: array_helper
INFO - 2019-07-05 18:19:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-05 18:19:27 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-05 18:19:27 --> Database Driver Class Initialized
INFO - 2019-07-05 18:19:27 --> Controller Class Initialized
INFO - 2019-07-05 18:19:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-05 18:19:27 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-05 18:19:27 --> Database Driver Class Initialized
INFO - 2019-07-05 18:19:27 --> Controller Class Initialized
INFO - 2019-07-05 18:35:13 --> Config Class Initialized
INFO - 2019-07-05 18:35:13 --> Hooks Class Initialized
DEBUG - 2019-07-05 18:35:13 --> UTF-8 Support Enabled
INFO - 2019-07-05 18:35:13 --> Utf8 Class Initialized
INFO - 2019-07-05 18:35:13 --> URI Class Initialized
INFO - 2019-07-05 18:35:13 --> Router Class Initialized
INFO - 2019-07-05 18:35:13 --> Output Class Initialized
INFO - 2019-07-05 18:35:13 --> Security Class Initialized
DEBUG - 2019-07-05 18:35:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-05 18:35:13 --> Input Class Initialized
INFO - 2019-07-05 18:35:13 --> Language Class Initialized
INFO - 2019-07-05 18:35:13 --> Language Class Initialized
INFO - 2019-07-05 18:35:13 --> Config Class Initialized
INFO - 2019-07-05 18:35:13 --> Loader Class Initialized
DEBUG - 2019-07-05 18:35:13 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-05 18:35:14 --> Helper loaded: url_helper
INFO - 2019-07-05 18:35:14 --> Helper loaded: inflector_helper
INFO - 2019-07-05 18:35:14 --> Helper loaded: string_helper
INFO - 2019-07-05 18:35:14 --> Helper loaded: array_helper
INFO - 2019-07-05 18:35:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-05 18:35:14 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-05 18:35:14 --> Database Driver Class Initialized
INFO - 2019-07-05 18:35:14 --> Controller Class Initialized
