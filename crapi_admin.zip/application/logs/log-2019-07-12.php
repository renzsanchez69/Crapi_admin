<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-07-12 00:00:32 --> Helper loaded: language_helper
INFO - 2019-07-12 00:00:32 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:00:32 --> Model Class Initialized
INFO - 2019-07-12 00:00:32 --> Model Class Initialized
INFO - 2019-07-12 00:00:32 --> Model Class Initialized
INFO - 2019-07-12 00:00:32 --> Model Class Initialized
INFO - 2019-07-12 00:00:32 --> Helper loaded: form_helper
INFO - 2019-07-12 00:00:32 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:00:32 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:00:32 --> Model Class Initialized
INFO - 2019-07-12 00:00:32 --> Model Class Initialized
INFO - 2019-07-12 00:00:32 --> Final output sent to browser
DEBUG - 2019-07-12 00:00:32 --> Total execution time: 0.4197
INFO - 2019-07-12 00:00:33 --> Helper loaded: language_helper
INFO - 2019-07-12 00:00:33 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:00:33 --> Model Class Initialized
INFO - 2019-07-12 00:00:33 --> Model Class Initialized
INFO - 2019-07-12 00:00:33 --> Model Class Initialized
INFO - 2019-07-12 00:00:33 --> Model Class Initialized
INFO - 2019-07-12 00:00:33 --> Helper loaded: form_helper
INFO - 2019-07-12 00:00:33 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:00:33 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:00:33 --> Model Class Initialized
INFO - 2019-07-12 00:00:33 --> Model Class Initialized
INFO - 2019-07-12 00:00:33 --> Final output sent to browser
DEBUG - 2019-07-12 00:00:33 --> Total execution time: 0.4445
INFO - 2019-07-12 00:00:34 --> Helper loaded: language_helper
INFO - 2019-07-12 00:00:34 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:00:34 --> Model Class Initialized
INFO - 2019-07-12 00:00:34 --> Model Class Initialized
INFO - 2019-07-12 00:00:34 --> Model Class Initialized
INFO - 2019-07-12 00:00:34 --> Model Class Initialized
INFO - 2019-07-12 00:00:34 --> Helper loaded: form_helper
INFO - 2019-07-12 00:00:34 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:00:34 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:00:34 --> Model Class Initialized
INFO - 2019-07-12 00:00:34 --> Model Class Initialized
INFO - 2019-07-12 00:00:34 --> Final output sent to browser
DEBUG - 2019-07-12 00:00:34 --> Total execution time: 0.4835
INFO - 2019-07-12 00:01:11 --> Helper loaded: language_helper
INFO - 2019-07-12 00:01:11 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:01:11 --> Model Class Initialized
INFO - 2019-07-12 00:01:11 --> Model Class Initialized
INFO - 2019-07-12 00:01:11 --> Model Class Initialized
INFO - 2019-07-12 00:01:11 --> Model Class Initialized
INFO - 2019-07-12 00:01:11 --> Helper loaded: form_helper
INFO - 2019-07-12 00:01:11 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:01:11 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:01:11 --> Model Class Initialized
INFO - 2019-07-12 00:01:11 --> Model Class Initialized
INFO - 2019-07-12 00:01:11 --> Final output sent to browser
DEBUG - 2019-07-12 00:01:11 --> Total execution time: 0.4482
INFO - 2019-07-12 00:01:12 --> Helper loaded: language_helper
INFO - 2019-07-12 00:01:12 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:01:12 --> Model Class Initialized
INFO - 2019-07-12 00:01:12 --> Model Class Initialized
INFO - 2019-07-12 00:01:12 --> Model Class Initialized
INFO - 2019-07-12 00:01:12 --> Model Class Initialized
INFO - 2019-07-12 00:01:12 --> Helper loaded: form_helper
INFO - 2019-07-12 00:01:12 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:01:12 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:01:12 --> Model Class Initialized
INFO - 2019-07-12 00:01:12 --> Model Class Initialized
INFO - 2019-07-12 00:01:12 --> Final output sent to browser
DEBUG - 2019-07-12 00:01:12 --> Total execution time: 0.4489
INFO - 2019-07-12 00:01:13 --> Helper loaded: language_helper
INFO - 2019-07-12 00:01:13 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:01:13 --> Model Class Initialized
INFO - 2019-07-12 00:01:13 --> Model Class Initialized
INFO - 2019-07-12 00:01:13 --> Model Class Initialized
INFO - 2019-07-12 00:01:13 --> Model Class Initialized
INFO - 2019-07-12 00:01:13 --> Helper loaded: form_helper
INFO - 2019-07-12 00:01:13 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:01:13 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:01:13 --> Model Class Initialized
INFO - 2019-07-12 00:01:13 --> Model Class Initialized
INFO - 2019-07-12 00:01:13 --> Final output sent to browser
DEBUG - 2019-07-12 00:01:13 --> Total execution time: 0.4655
INFO - 2019-07-12 00:01:14 --> Helper loaded: language_helper
INFO - 2019-07-12 00:01:14 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:01:14 --> Model Class Initialized
INFO - 2019-07-12 00:01:14 --> Model Class Initialized
INFO - 2019-07-12 00:01:14 --> Model Class Initialized
INFO - 2019-07-12 00:01:14 --> Model Class Initialized
INFO - 2019-07-12 00:01:15 --> Helper loaded: form_helper
INFO - 2019-07-12 00:01:15 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:01:15 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:01:15 --> Model Class Initialized
INFO - 2019-07-12 00:01:15 --> Model Class Initialized
INFO - 2019-07-12 00:01:15 --> Final output sent to browser
DEBUG - 2019-07-12 00:01:15 --> Total execution time: 0.4303
INFO - 2019-07-12 00:01:16 --> Helper loaded: language_helper
INFO - 2019-07-12 00:01:16 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:01:16 --> Model Class Initialized
INFO - 2019-07-12 00:01:16 --> Model Class Initialized
INFO - 2019-07-12 00:01:16 --> Model Class Initialized
INFO - 2019-07-12 00:01:16 --> Model Class Initialized
INFO - 2019-07-12 00:01:16 --> Helper loaded: form_helper
INFO - 2019-07-12 00:01:16 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:01:16 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:01:16 --> Model Class Initialized
INFO - 2019-07-12 00:01:16 --> Model Class Initialized
INFO - 2019-07-12 00:01:16 --> Final output sent to browser
DEBUG - 2019-07-12 00:01:16 --> Total execution time: 0.4270
INFO - 2019-07-12 00:01:16 --> Helper loaded: language_helper
INFO - 2019-07-12 00:01:16 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:01:16 --> Model Class Initialized
INFO - 2019-07-12 00:01:16 --> Model Class Initialized
INFO - 2019-07-12 00:01:16 --> Model Class Initialized
INFO - 2019-07-12 00:01:16 --> Model Class Initialized
INFO - 2019-07-12 00:01:16 --> Helper loaded: form_helper
INFO - 2019-07-12 00:01:16 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:01:16 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:01:16 --> Model Class Initialized
INFO - 2019-07-12 00:01:16 --> Model Class Initialized
INFO - 2019-07-12 00:01:16 --> Final output sent to browser
DEBUG - 2019-07-12 00:01:16 --> Total execution time: 0.4869
INFO - 2019-07-12 00:01:36 --> Helper loaded: language_helper
INFO - 2019-07-12 00:01:36 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:01:36 --> Model Class Initialized
INFO - 2019-07-12 00:01:36 --> Model Class Initialized
INFO - 2019-07-12 00:01:36 --> Model Class Initialized
INFO - 2019-07-12 00:01:36 --> Model Class Initialized
INFO - 2019-07-12 00:01:36 --> Helper loaded: form_helper
INFO - 2019-07-12 00:01:36 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:01:36 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:01:36 --> Model Class Initialized
INFO - 2019-07-12 00:01:36 --> Model Class Initialized
INFO - 2019-07-12 00:01:36 --> Final output sent to browser
DEBUG - 2019-07-12 00:01:36 --> Total execution time: 0.4658
INFO - 2019-07-12 00:02:44 --> Helper loaded: language_helper
INFO - 2019-07-12 00:02:44 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:02:44 --> Model Class Initialized
INFO - 2019-07-12 00:02:44 --> Model Class Initialized
INFO - 2019-07-12 00:02:44 --> Model Class Initialized
INFO - 2019-07-12 00:02:44 --> Model Class Initialized
INFO - 2019-07-12 00:02:44 --> Model Class Initialized
INFO - 2019-07-12 00:02:44 --> Final output sent to browser
DEBUG - 2019-07-12 00:02:44 --> Total execution time: 0.4501
INFO - 2019-07-12 00:02:44 --> Helper loaded: language_helper
INFO - 2019-07-12 00:02:44 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:02:44 --> Model Class Initialized
INFO - 2019-07-12 00:02:44 --> Model Class Initialized
INFO - 2019-07-12 00:02:44 --> Model Class Initialized
INFO - 2019-07-12 00:02:44 --> Model Class Initialized
INFO - 2019-07-12 00:02:44 --> Helper loaded: form_helper
INFO - 2019-07-12 00:02:44 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:02:44 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:02:44 --> Model Class Initialized
INFO - 2019-07-12 00:02:44 --> Model Class Initialized
INFO - 2019-07-12 00:02:44 --> Final output sent to browser
DEBUG - 2019-07-12 00:02:44 --> Total execution time: 0.4857
INFO - 2019-07-12 00:02:47 --> Helper loaded: language_helper
INFO - 2019-07-12 00:02:47 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:02:47 --> Model Class Initialized
INFO - 2019-07-12 00:02:47 --> Model Class Initialized
INFO - 2019-07-12 00:02:47 --> Model Class Initialized
INFO - 2019-07-12 00:02:47 --> Model Class Initialized
INFO - 2019-07-12 00:02:47 --> Helper loaded: form_helper
INFO - 2019-07-12 00:02:47 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:02:47 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:02:47 --> Model Class Initialized
INFO - 2019-07-12 00:02:47 --> Model Class Initialized
INFO - 2019-07-12 00:02:47 --> Final output sent to browser
DEBUG - 2019-07-12 00:02:47 --> Total execution time: 0.4345
INFO - 2019-07-12 00:02:53 --> Helper loaded: language_helper
INFO - 2019-07-12 00:02:53 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:02:53 --> Model Class Initialized
INFO - 2019-07-12 00:02:53 --> Model Class Initialized
INFO - 2019-07-12 00:02:53 --> Model Class Initialized
INFO - 2019-07-12 00:02:53 --> Model Class Initialized
INFO - 2019-07-12 00:02:53 --> Model Class Initialized
INFO - 2019-07-12 00:02:53 --> Final output sent to browser
DEBUG - 2019-07-12 00:02:53 --> Total execution time: 0.4929
INFO - 2019-07-12 00:02:53 --> Helper loaded: language_helper
INFO - 2019-07-12 00:02:53 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:02:53 --> Model Class Initialized
INFO - 2019-07-12 00:02:53 --> Model Class Initialized
INFO - 2019-07-12 00:02:53 --> Model Class Initialized
INFO - 2019-07-12 00:02:53 --> Model Class Initialized
INFO - 2019-07-12 00:02:53 --> Helper loaded: form_helper
INFO - 2019-07-12 00:02:53 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:02:53 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:02:53 --> Model Class Initialized
INFO - 2019-07-12 00:02:53 --> Model Class Initialized
INFO - 2019-07-12 00:02:53 --> Final output sent to browser
DEBUG - 2019-07-12 00:02:53 --> Total execution time: 0.5140
INFO - 2019-07-12 00:02:54 --> Helper loaded: language_helper
INFO - 2019-07-12 00:02:54 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:02:54 --> Model Class Initialized
INFO - 2019-07-12 00:02:54 --> Model Class Initialized
INFO - 2019-07-12 00:02:54 --> Model Class Initialized
INFO - 2019-07-12 00:02:54 --> Model Class Initialized
INFO - 2019-07-12 00:02:54 --> Helper loaded: form_helper
INFO - 2019-07-12 00:02:54 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:02:54 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:02:54 --> Model Class Initialized
INFO - 2019-07-12 00:02:54 --> Model Class Initialized
INFO - 2019-07-12 00:02:54 --> Final output sent to browser
DEBUG - 2019-07-12 00:02:54 --> Total execution time: 0.5266
INFO - 2019-07-12 00:03:02 --> Helper loaded: language_helper
INFO - 2019-07-12 00:03:02 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:03:02 --> Model Class Initialized
INFO - 2019-07-12 00:03:02 --> Model Class Initialized
INFO - 2019-07-12 00:03:02 --> Model Class Initialized
INFO - 2019-07-12 00:03:02 --> Model Class Initialized
INFO - 2019-07-12 00:03:02 --> Model Class Initialized
INFO - 2019-07-12 00:03:02 --> Final output sent to browser
DEBUG - 2019-07-12 00:03:02 --> Total execution time: 0.4266
INFO - 2019-07-12 00:03:02 --> Helper loaded: language_helper
INFO - 2019-07-12 00:03:02 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:03:02 --> Model Class Initialized
INFO - 2019-07-12 00:03:02 --> Model Class Initialized
INFO - 2019-07-12 00:03:02 --> Model Class Initialized
INFO - 2019-07-12 00:03:02 --> Model Class Initialized
INFO - 2019-07-12 00:03:02 --> Helper loaded: form_helper
INFO - 2019-07-12 00:03:02 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:03:02 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:03:02 --> Model Class Initialized
INFO - 2019-07-12 00:03:02 --> Model Class Initialized
INFO - 2019-07-12 00:03:02 --> Final output sent to browser
DEBUG - 2019-07-12 00:03:02 --> Total execution time: 0.5270
INFO - 2019-07-12 00:03:04 --> Helper loaded: language_helper
INFO - 2019-07-12 00:03:04 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:03:04 --> Model Class Initialized
INFO - 2019-07-12 00:03:04 --> Model Class Initialized
INFO - 2019-07-12 00:03:04 --> Model Class Initialized
INFO - 2019-07-12 00:03:04 --> Model Class Initialized
INFO - 2019-07-12 00:03:04 --> Helper loaded: form_helper
INFO - 2019-07-12 00:03:04 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:03:04 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:03:04 --> Model Class Initialized
INFO - 2019-07-12 00:03:04 --> Model Class Initialized
INFO - 2019-07-12 00:03:04 --> Final output sent to browser
DEBUG - 2019-07-12 00:03:04 --> Total execution time: 0.4783
INFO - 2019-07-12 00:03:07 --> Helper loaded: language_helper
INFO - 2019-07-12 00:03:07 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:03:07 --> Model Class Initialized
INFO - 2019-07-12 00:03:07 --> Model Class Initialized
INFO - 2019-07-12 00:03:07 --> Model Class Initialized
INFO - 2019-07-12 00:03:07 --> Model Class Initialized
INFO - 2019-07-12 00:03:07 --> Helper loaded: form_helper
INFO - 2019-07-12 00:03:07 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:03:07 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:03:07 --> Model Class Initialized
INFO - 2019-07-12 00:03:07 --> Model Class Initialized
INFO - 2019-07-12 00:03:07 --> Final output sent to browser
DEBUG - 2019-07-12 00:03:07 --> Total execution time: 0.4618
INFO - 2019-07-12 00:04:35 --> Helper loaded: language_helper
INFO - 2019-07-12 00:04:35 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:04:35 --> Model Class Initialized
INFO - 2019-07-12 00:04:35 --> Model Class Initialized
INFO - 2019-07-12 00:04:35 --> Model Class Initialized
INFO - 2019-07-12 00:04:35 --> Model Class Initialized
INFO - 2019-07-12 00:04:35 --> Model Class Initialized
INFO - 2019-07-12 00:04:35 --> Final output sent to browser
DEBUG - 2019-07-12 00:04:35 --> Total execution time: 0.4238
INFO - 2019-07-12 00:04:35 --> Helper loaded: language_helper
INFO - 2019-07-12 00:04:35 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:04:35 --> Model Class Initialized
INFO - 2019-07-12 00:04:35 --> Model Class Initialized
INFO - 2019-07-12 00:04:35 --> Model Class Initialized
INFO - 2019-07-12 00:04:35 --> Model Class Initialized
INFO - 2019-07-12 00:04:35 --> Helper loaded: form_helper
INFO - 2019-07-12 00:04:35 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:04:35 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:04:35 --> Model Class Initialized
INFO - 2019-07-12 00:04:35 --> Model Class Initialized
INFO - 2019-07-12 00:04:35 --> Final output sent to browser
DEBUG - 2019-07-12 00:04:36 --> Total execution time: 0.4963
INFO - 2019-07-12 00:04:38 --> Helper loaded: language_helper
INFO - 2019-07-12 00:04:38 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:04:38 --> Model Class Initialized
INFO - 2019-07-12 00:04:38 --> Model Class Initialized
INFO - 2019-07-12 00:04:38 --> Model Class Initialized
INFO - 2019-07-12 00:04:38 --> Model Class Initialized
INFO - 2019-07-12 00:04:38 --> Helper loaded: form_helper
INFO - 2019-07-12 00:04:38 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:04:38 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:04:38 --> Model Class Initialized
INFO - 2019-07-12 00:04:38 --> Model Class Initialized
INFO - 2019-07-12 00:04:38 --> Final output sent to browser
DEBUG - 2019-07-12 00:04:38 --> Total execution time: 0.4531
INFO - 2019-07-12 00:05:17 --> Helper loaded: language_helper
INFO - 2019-07-12 00:05:17 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:05:17 --> Model Class Initialized
INFO - 2019-07-12 00:05:17 --> Model Class Initialized
INFO - 2019-07-12 00:05:17 --> Model Class Initialized
INFO - 2019-07-12 00:05:17 --> Model Class Initialized
INFO - 2019-07-12 00:05:17 --> Model Class Initialized
INFO - 2019-07-12 00:05:17 --> Final output sent to browser
DEBUG - 2019-07-12 00:05:17 --> Total execution time: 0.4540
INFO - 2019-07-12 00:05:18 --> Helper loaded: language_helper
INFO - 2019-07-12 00:05:18 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:05:18 --> Model Class Initialized
INFO - 2019-07-12 00:05:18 --> Model Class Initialized
INFO - 2019-07-12 00:05:18 --> Model Class Initialized
INFO - 2019-07-12 00:05:18 --> Model Class Initialized
INFO - 2019-07-12 00:05:18 --> Helper loaded: form_helper
INFO - 2019-07-12 00:05:18 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:05:18 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:05:18 --> Model Class Initialized
INFO - 2019-07-12 00:05:18 --> Model Class Initialized
INFO - 2019-07-12 00:05:18 --> Final output sent to browser
DEBUG - 2019-07-12 00:05:18 --> Total execution time: 0.6327
INFO - 2019-07-12 00:05:18 --> Helper loaded: language_helper
INFO - 2019-07-12 00:05:18 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:05:18 --> Model Class Initialized
INFO - 2019-07-12 00:05:18 --> Model Class Initialized
INFO - 2019-07-12 00:05:18 --> Model Class Initialized
INFO - 2019-07-12 00:05:18 --> Model Class Initialized
INFO - 2019-07-12 00:05:18 --> Helper loaded: form_helper
INFO - 2019-07-12 00:05:18 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:05:18 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:05:18 --> Model Class Initialized
INFO - 2019-07-12 00:05:18 --> Model Class Initialized
INFO - 2019-07-12 00:05:18 --> Final output sent to browser
DEBUG - 2019-07-12 00:05:18 --> Total execution time: 0.5985
INFO - 2019-07-12 00:05:20 --> Helper loaded: language_helper
INFO - 2019-07-12 00:05:20 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:05:20 --> Model Class Initialized
INFO - 2019-07-12 00:05:20 --> Model Class Initialized
INFO - 2019-07-12 00:05:20 --> Model Class Initialized
INFO - 2019-07-12 00:05:20 --> Model Class Initialized
INFO - 2019-07-12 00:05:20 --> Model Class Initialized
INFO - 2019-07-12 00:05:20 --> Final output sent to browser
DEBUG - 2019-07-12 00:05:20 --> Total execution time: 0.4357
INFO - 2019-07-12 00:05:21 --> Helper loaded: language_helper
INFO - 2019-07-12 00:05:21 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:05:21 --> Model Class Initialized
INFO - 2019-07-12 00:05:21 --> Model Class Initialized
INFO - 2019-07-12 00:05:21 --> Model Class Initialized
INFO - 2019-07-12 00:05:21 --> Model Class Initialized
INFO - 2019-07-12 00:05:21 --> Helper loaded: form_helper
INFO - 2019-07-12 00:05:21 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:05:21 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:05:21 --> Model Class Initialized
INFO - 2019-07-12 00:05:21 --> Model Class Initialized
INFO - 2019-07-12 00:05:21 --> Final output sent to browser
DEBUG - 2019-07-12 00:05:21 --> Total execution time: 0.5397
INFO - 2019-07-12 00:05:22 --> Helper loaded: language_helper
INFO - 2019-07-12 00:05:22 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:05:22 --> Model Class Initialized
INFO - 2019-07-12 00:05:22 --> Model Class Initialized
INFO - 2019-07-12 00:05:22 --> Model Class Initialized
INFO - 2019-07-12 00:05:22 --> Model Class Initialized
INFO - 2019-07-12 00:05:22 --> Helper loaded: form_helper
INFO - 2019-07-12 00:05:22 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:05:22 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:05:22 --> Model Class Initialized
INFO - 2019-07-12 00:05:22 --> Model Class Initialized
INFO - 2019-07-12 00:05:22 --> Final output sent to browser
DEBUG - 2019-07-12 00:05:22 --> Total execution time: 0.4985
INFO - 2019-07-12 00:07:11 --> Helper loaded: language_helper
INFO - 2019-07-12 00:07:11 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:07:11 --> Model Class Initialized
INFO - 2019-07-12 00:07:11 --> Model Class Initialized
INFO - 2019-07-12 00:07:11 --> Model Class Initialized
INFO - 2019-07-12 00:07:11 --> Model Class Initialized
INFO - 2019-07-12 00:07:11 --> Model Class Initialized
INFO - 2019-07-12 00:07:11 --> Final output sent to browser
DEBUG - 2019-07-12 00:07:11 --> Total execution time: 0.4300
INFO - 2019-07-12 00:07:12 --> Helper loaded: language_helper
INFO - 2019-07-12 00:07:12 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:07:12 --> Model Class Initialized
INFO - 2019-07-12 00:07:12 --> Model Class Initialized
INFO - 2019-07-12 00:07:12 --> Model Class Initialized
INFO - 2019-07-12 00:07:12 --> Model Class Initialized
INFO - 2019-07-12 00:07:12 --> Helper loaded: form_helper
INFO - 2019-07-12 00:07:12 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:07:12 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:07:12 --> Model Class Initialized
INFO - 2019-07-12 00:07:12 --> Model Class Initialized
INFO - 2019-07-12 00:07:12 --> Final output sent to browser
DEBUG - 2019-07-12 00:07:12 --> Total execution time: 0.7877
INFO - 2019-07-12 00:07:12 --> Helper loaded: language_helper
INFO - 2019-07-12 00:07:12 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:07:12 --> Model Class Initialized
INFO - 2019-07-12 00:07:12 --> Model Class Initialized
INFO - 2019-07-12 00:07:12 --> Model Class Initialized
INFO - 2019-07-12 00:07:12 --> Model Class Initialized
INFO - 2019-07-12 00:07:12 --> Helper loaded: form_helper
INFO - 2019-07-12 00:07:12 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:07:12 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:07:12 --> Model Class Initialized
INFO - 2019-07-12 00:07:12 --> Model Class Initialized
INFO - 2019-07-12 00:07:12 --> Final output sent to browser
DEBUG - 2019-07-12 00:07:12 --> Total execution time: 0.6371
INFO - 2019-07-12 00:07:32 --> Helper loaded: language_helper
INFO - 2019-07-12 00:07:32 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:07:32 --> Model Class Initialized
INFO - 2019-07-12 00:07:32 --> Model Class Initialized
INFO - 2019-07-12 00:07:32 --> Model Class Initialized
INFO - 2019-07-12 00:07:32 --> Model Class Initialized
INFO - 2019-07-12 00:07:32 --> Model Class Initialized
INFO - 2019-07-12 00:07:32 --> Final output sent to browser
DEBUG - 2019-07-12 00:07:32 --> Total execution time: 0.4353
INFO - 2019-07-12 00:07:33 --> Helper loaded: language_helper
INFO - 2019-07-12 00:07:33 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:07:33 --> Model Class Initialized
INFO - 2019-07-12 00:07:33 --> Model Class Initialized
INFO - 2019-07-12 00:07:33 --> Model Class Initialized
INFO - 2019-07-12 00:07:33 --> Model Class Initialized
INFO - 2019-07-12 00:07:33 --> Helper loaded: form_helper
INFO - 2019-07-12 00:07:33 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:07:33 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:07:33 --> Model Class Initialized
INFO - 2019-07-12 00:07:33 --> Model Class Initialized
INFO - 2019-07-12 00:07:33 --> Final output sent to browser
DEBUG - 2019-07-12 00:07:33 --> Total execution time: 0.8215
INFO - 2019-07-12 00:07:33 --> Helper loaded: language_helper
INFO - 2019-07-12 00:07:33 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:07:33 --> Model Class Initialized
INFO - 2019-07-12 00:07:33 --> Model Class Initialized
INFO - 2019-07-12 00:07:33 --> Model Class Initialized
INFO - 2019-07-12 00:07:33 --> Model Class Initialized
INFO - 2019-07-12 00:07:33 --> Helper loaded: form_helper
INFO - 2019-07-12 00:07:33 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:07:33 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:07:33 --> Model Class Initialized
INFO - 2019-07-12 00:07:33 --> Model Class Initialized
INFO - 2019-07-12 00:07:33 --> Final output sent to browser
DEBUG - 2019-07-12 00:07:33 --> Total execution time: 0.6409
INFO - 2019-07-12 00:07:38 --> Helper loaded: language_helper
INFO - 2019-07-12 00:07:38 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:07:38 --> Model Class Initialized
INFO - 2019-07-12 00:07:38 --> Model Class Initialized
INFO - 2019-07-12 00:07:38 --> Model Class Initialized
INFO - 2019-07-12 00:07:38 --> Model Class Initialized
INFO - 2019-07-12 00:07:38 --> Model Class Initialized
INFO - 2019-07-12 00:07:38 --> Final output sent to browser
DEBUG - 2019-07-12 00:07:38 --> Total execution time: 0.4338
INFO - 2019-07-12 00:07:39 --> Helper loaded: language_helper
INFO - 2019-07-12 00:07:39 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:07:39 --> Model Class Initialized
INFO - 2019-07-12 00:07:39 --> Model Class Initialized
INFO - 2019-07-12 00:07:39 --> Model Class Initialized
INFO - 2019-07-12 00:07:39 --> Model Class Initialized
INFO - 2019-07-12 00:07:39 --> Helper loaded: form_helper
INFO - 2019-07-12 00:07:39 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:07:39 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:07:39 --> Model Class Initialized
INFO - 2019-07-12 00:07:39 --> Model Class Initialized
INFO - 2019-07-12 00:07:39 --> Final output sent to browser
DEBUG - 2019-07-12 00:07:39 --> Total execution time: 0.7062
INFO - 2019-07-12 00:07:39 --> Helper loaded: language_helper
INFO - 2019-07-12 00:07:39 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:07:39 --> Model Class Initialized
INFO - 2019-07-12 00:07:39 --> Model Class Initialized
INFO - 2019-07-12 00:07:39 --> Model Class Initialized
INFO - 2019-07-12 00:07:39 --> Model Class Initialized
INFO - 2019-07-12 00:07:39 --> Helper loaded: form_helper
INFO - 2019-07-12 00:07:39 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:07:39 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:07:39 --> Model Class Initialized
INFO - 2019-07-12 00:07:39 --> Model Class Initialized
INFO - 2019-07-12 00:07:39 --> Final output sent to browser
DEBUG - 2019-07-12 00:07:39 --> Total execution time: 0.5952
INFO - 2019-07-12 00:08:02 --> Helper loaded: language_helper
INFO - 2019-07-12 00:08:02 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:08:02 --> Model Class Initialized
INFO - 2019-07-12 00:08:02 --> Model Class Initialized
INFO - 2019-07-12 00:08:02 --> Model Class Initialized
INFO - 2019-07-12 00:08:02 --> Model Class Initialized
INFO - 2019-07-12 00:08:02 --> Model Class Initialized
INFO - 2019-07-12 00:08:03 --> Final output sent to browser
DEBUG - 2019-07-12 00:08:03 --> Total execution time: 0.4309
INFO - 2019-07-12 00:08:03 --> Helper loaded: language_helper
INFO - 2019-07-12 00:08:03 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:08:03 --> Model Class Initialized
INFO - 2019-07-12 00:08:03 --> Model Class Initialized
INFO - 2019-07-12 00:08:03 --> Model Class Initialized
INFO - 2019-07-12 00:08:03 --> Model Class Initialized
INFO - 2019-07-12 00:08:03 --> Helper loaded: form_helper
INFO - 2019-07-12 00:08:03 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:08:03 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:08:03 --> Model Class Initialized
INFO - 2019-07-12 00:08:03 --> Model Class Initialized
INFO - 2019-07-12 00:08:03 --> Final output sent to browser
DEBUG - 2019-07-12 00:08:03 --> Total execution time: 0.7038
INFO - 2019-07-12 00:08:03 --> Helper loaded: language_helper
INFO - 2019-07-12 00:08:03 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:08:04 --> Model Class Initialized
INFO - 2019-07-12 00:08:04 --> Model Class Initialized
INFO - 2019-07-12 00:08:04 --> Model Class Initialized
INFO - 2019-07-12 00:08:04 --> Model Class Initialized
INFO - 2019-07-12 00:08:04 --> Helper loaded: form_helper
INFO - 2019-07-12 00:08:04 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:08:04 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:08:04 --> Model Class Initialized
INFO - 2019-07-12 00:08:04 --> Model Class Initialized
INFO - 2019-07-12 00:08:04 --> Final output sent to browser
DEBUG - 2019-07-12 00:08:04 --> Total execution time: 0.5804
INFO - 2019-07-12 00:08:48 --> Helper loaded: language_helper
INFO - 2019-07-12 00:08:49 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:08:49 --> Model Class Initialized
INFO - 2019-07-12 00:08:49 --> Model Class Initialized
INFO - 2019-07-12 00:08:49 --> Model Class Initialized
INFO - 2019-07-12 00:08:49 --> Model Class Initialized
INFO - 2019-07-12 00:08:49 --> Helper loaded: form_helper
INFO - 2019-07-12 00:08:49 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:08:49 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:08:49 --> Model Class Initialized
INFO - 2019-07-12 00:08:49 --> Model Class Initialized
INFO - 2019-07-12 00:08:49 --> Final output sent to browser
DEBUG - 2019-07-12 00:08:49 --> Total execution time: 0.5035
INFO - 2019-07-12 00:08:51 --> Helper loaded: language_helper
INFO - 2019-07-12 00:08:51 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:08:51 --> Model Class Initialized
INFO - 2019-07-12 00:08:51 --> Model Class Initialized
INFO - 2019-07-12 00:08:51 --> Model Class Initialized
INFO - 2019-07-12 00:08:51 --> Model Class Initialized
INFO - 2019-07-12 00:08:51 --> Model Class Initialized
INFO - 2019-07-12 00:08:51 --> Final output sent to browser
DEBUG - 2019-07-12 00:08:51 --> Total execution time: 0.4719
INFO - 2019-07-12 00:08:51 --> Helper loaded: language_helper
INFO - 2019-07-12 00:08:51 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:08:51 --> Model Class Initialized
INFO - 2019-07-12 00:08:51 --> Model Class Initialized
INFO - 2019-07-12 00:08:51 --> Model Class Initialized
INFO - 2019-07-12 00:08:51 --> Model Class Initialized
INFO - 2019-07-12 00:08:51 --> Helper loaded: form_helper
INFO - 2019-07-12 00:08:51 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:08:51 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:08:51 --> Model Class Initialized
INFO - 2019-07-12 00:08:51 --> Model Class Initialized
INFO - 2019-07-12 00:08:51 --> Final output sent to browser
DEBUG - 2019-07-12 00:08:51 --> Total execution time: 0.5229
INFO - 2019-07-12 00:08:57 --> Helper loaded: language_helper
INFO - 2019-07-12 00:08:57 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:08:57 --> Model Class Initialized
INFO - 2019-07-12 00:08:57 --> Model Class Initialized
INFO - 2019-07-12 00:08:57 --> Model Class Initialized
INFO - 2019-07-12 00:08:57 --> Model Class Initialized
INFO - 2019-07-12 00:08:57 --> Model Class Initialized
INFO - 2019-07-12 00:08:57 --> Final output sent to browser
DEBUG - 2019-07-12 00:08:57 --> Total execution time: 0.4321
INFO - 2019-07-12 00:08:57 --> Helper loaded: language_helper
INFO - 2019-07-12 00:08:57 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:08:57 --> Model Class Initialized
INFO - 2019-07-12 00:08:57 --> Model Class Initialized
INFO - 2019-07-12 00:08:57 --> Model Class Initialized
INFO - 2019-07-12 00:08:57 --> Model Class Initialized
INFO - 2019-07-12 00:08:57 --> Helper loaded: form_helper
INFO - 2019-07-12 00:08:57 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:08:57 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:08:57 --> Model Class Initialized
INFO - 2019-07-12 00:08:57 --> Model Class Initialized
INFO - 2019-07-12 00:08:57 --> Final output sent to browser
DEBUG - 2019-07-12 00:08:57 --> Total execution time: 0.6965
INFO - 2019-07-12 00:08:58 --> Helper loaded: language_helper
INFO - 2019-07-12 00:08:58 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:08:58 --> Model Class Initialized
INFO - 2019-07-12 00:08:58 --> Model Class Initialized
INFO - 2019-07-12 00:08:58 --> Model Class Initialized
INFO - 2019-07-12 00:08:58 --> Model Class Initialized
INFO - 2019-07-12 00:08:58 --> Helper loaded: form_helper
INFO - 2019-07-12 00:08:58 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:08:58 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:08:58 --> Model Class Initialized
INFO - 2019-07-12 00:08:58 --> Model Class Initialized
INFO - 2019-07-12 00:08:58 --> Final output sent to browser
DEBUG - 2019-07-12 00:08:58 --> Total execution time: 0.5736
INFO - 2019-07-12 00:10:00 --> Helper loaded: language_helper
INFO - 2019-07-12 00:10:00 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:10:00 --> Model Class Initialized
INFO - 2019-07-12 00:10:00 --> Model Class Initialized
INFO - 2019-07-12 00:10:00 --> Model Class Initialized
INFO - 2019-07-12 00:10:00 --> Model Class Initialized
INFO - 2019-07-12 00:10:00 --> Model Class Initialized
INFO - 2019-07-12 00:10:00 --> Final output sent to browser
DEBUG - 2019-07-12 00:10:00 --> Total execution time: 0.4589
INFO - 2019-07-12 00:10:00 --> Helper loaded: language_helper
INFO - 2019-07-12 00:10:00 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:10:01 --> Model Class Initialized
INFO - 2019-07-12 00:10:01 --> Model Class Initialized
INFO - 2019-07-12 00:10:01 --> Model Class Initialized
INFO - 2019-07-12 00:10:01 --> Model Class Initialized
INFO - 2019-07-12 00:10:01 --> Helper loaded: form_helper
INFO - 2019-07-12 00:10:01 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:10:01 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:10:01 --> Model Class Initialized
INFO - 2019-07-12 00:10:01 --> Model Class Initialized
INFO - 2019-07-12 00:10:01 --> Final output sent to browser
DEBUG - 2019-07-12 00:10:01 --> Total execution time: 0.7493
INFO - 2019-07-12 00:10:01 --> Helper loaded: language_helper
INFO - 2019-07-12 00:10:01 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:10:01 --> Model Class Initialized
INFO - 2019-07-12 00:10:01 --> Model Class Initialized
INFO - 2019-07-12 00:10:01 --> Model Class Initialized
INFO - 2019-07-12 00:10:01 --> Model Class Initialized
INFO - 2019-07-12 00:10:01 --> Helper loaded: form_helper
INFO - 2019-07-12 00:10:01 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:10:01 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:10:01 --> Model Class Initialized
INFO - 2019-07-12 00:10:01 --> Model Class Initialized
INFO - 2019-07-12 00:10:01 --> Final output sent to browser
DEBUG - 2019-07-12 00:10:01 --> Total execution time: 0.6373
INFO - 2019-07-12 00:10:13 --> Helper loaded: language_helper
INFO - 2019-07-12 00:10:13 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:10:13 --> Model Class Initialized
INFO - 2019-07-12 00:10:13 --> Model Class Initialized
INFO - 2019-07-12 00:10:13 --> Model Class Initialized
INFO - 2019-07-12 00:10:13 --> Model Class Initialized
INFO - 2019-07-12 00:10:13 --> Helper loaded: form_helper
INFO - 2019-07-12 00:10:13 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:10:13 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:10:13 --> Model Class Initialized
INFO - 2019-07-12 00:10:13 --> Model Class Initialized
INFO - 2019-07-12 00:10:13 --> Final output sent to browser
DEBUG - 2019-07-12 00:10:13 --> Total execution time: 0.5163
INFO - 2019-07-12 00:10:15 --> Helper loaded: language_helper
INFO - 2019-07-12 00:10:15 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:10:15 --> Model Class Initialized
INFO - 2019-07-12 00:10:15 --> Model Class Initialized
INFO - 2019-07-12 00:10:15 --> Model Class Initialized
INFO - 2019-07-12 00:10:15 --> Model Class Initialized
INFO - 2019-07-12 00:10:15 --> Model Class Initialized
INFO - 2019-07-12 00:10:15 --> Final output sent to browser
DEBUG - 2019-07-12 00:10:15 --> Total execution time: 0.4521
INFO - 2019-07-12 00:10:15 --> Helper loaded: language_helper
INFO - 2019-07-12 00:10:15 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:10:15 --> Model Class Initialized
INFO - 2019-07-12 00:10:15 --> Model Class Initialized
INFO - 2019-07-12 00:10:15 --> Model Class Initialized
INFO - 2019-07-12 00:10:15 --> Model Class Initialized
INFO - 2019-07-12 00:10:15 --> Helper loaded: form_helper
INFO - 2019-07-12 00:10:15 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:10:15 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:10:15 --> Model Class Initialized
INFO - 2019-07-12 00:10:15 --> Model Class Initialized
INFO - 2019-07-12 00:10:15 --> Final output sent to browser
DEBUG - 2019-07-12 00:10:15 --> Total execution time: 0.4903
INFO - 2019-07-12 00:11:12 --> Helper loaded: language_helper
INFO - 2019-07-12 00:11:12 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:11:12 --> Model Class Initialized
INFO - 2019-07-12 00:11:12 --> Model Class Initialized
INFO - 2019-07-12 00:11:12 --> Model Class Initialized
INFO - 2019-07-12 00:11:12 --> Model Class Initialized
INFO - 2019-07-12 00:11:12 --> Model Class Initialized
INFO - 2019-07-12 00:11:12 --> Final output sent to browser
DEBUG - 2019-07-12 00:11:12 --> Total execution time: 0.4385
INFO - 2019-07-12 00:11:13 --> Helper loaded: language_helper
INFO - 2019-07-12 00:11:13 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:11:13 --> Model Class Initialized
INFO - 2019-07-12 00:11:13 --> Model Class Initialized
INFO - 2019-07-12 00:11:13 --> Model Class Initialized
INFO - 2019-07-12 00:11:13 --> Model Class Initialized
INFO - 2019-07-12 00:11:13 --> Helper loaded: form_helper
INFO - 2019-07-12 00:11:13 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:11:13 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:11:13 --> Model Class Initialized
INFO - 2019-07-12 00:11:13 --> Model Class Initialized
INFO - 2019-07-12 00:11:13 --> Final output sent to browser
DEBUG - 2019-07-12 00:11:13 --> Total execution time: 0.6874
INFO - 2019-07-12 00:11:13 --> Helper loaded: language_helper
INFO - 2019-07-12 00:11:13 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:11:13 --> Model Class Initialized
INFO - 2019-07-12 00:11:13 --> Model Class Initialized
INFO - 2019-07-12 00:11:13 --> Model Class Initialized
INFO - 2019-07-12 00:11:13 --> Model Class Initialized
INFO - 2019-07-12 00:11:13 --> Helper loaded: form_helper
INFO - 2019-07-12 00:11:13 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:11:13 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:11:13 --> Model Class Initialized
INFO - 2019-07-12 00:11:13 --> Model Class Initialized
INFO - 2019-07-12 00:11:13 --> Final output sent to browser
DEBUG - 2019-07-12 00:11:13 --> Total execution time: 0.6086
INFO - 2019-07-12 00:11:15 --> Helper loaded: language_helper
INFO - 2019-07-12 00:11:15 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:11:15 --> Model Class Initialized
INFO - 2019-07-12 00:11:15 --> Model Class Initialized
INFO - 2019-07-12 00:11:15 --> Model Class Initialized
INFO - 2019-07-12 00:11:15 --> Model Class Initialized
INFO - 2019-07-12 00:11:15 --> Model Class Initialized
INFO - 2019-07-12 00:11:15 --> Final output sent to browser
DEBUG - 2019-07-12 00:11:15 --> Total execution time: 0.4697
INFO - 2019-07-12 00:11:16 --> Helper loaded: language_helper
INFO - 2019-07-12 00:11:16 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:11:16 --> Model Class Initialized
INFO - 2019-07-12 00:11:16 --> Model Class Initialized
INFO - 2019-07-12 00:11:16 --> Model Class Initialized
INFO - 2019-07-12 00:11:16 --> Model Class Initialized
INFO - 2019-07-12 00:11:16 --> Helper loaded: form_helper
INFO - 2019-07-12 00:11:16 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:11:16 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:11:16 --> Model Class Initialized
INFO - 2019-07-12 00:11:16 --> Model Class Initialized
INFO - 2019-07-12 00:11:16 --> Final output sent to browser
DEBUG - 2019-07-12 00:11:16 --> Total execution time: 0.6880
INFO - 2019-07-12 00:11:16 --> Helper loaded: language_helper
INFO - 2019-07-12 00:11:16 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:11:16 --> Model Class Initialized
INFO - 2019-07-12 00:11:16 --> Model Class Initialized
INFO - 2019-07-12 00:11:16 --> Model Class Initialized
INFO - 2019-07-12 00:11:16 --> Model Class Initialized
INFO - 2019-07-12 00:11:16 --> Helper loaded: form_helper
INFO - 2019-07-12 00:11:16 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:11:16 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:11:16 --> Model Class Initialized
INFO - 2019-07-12 00:11:16 --> Model Class Initialized
INFO - 2019-07-12 00:11:16 --> Final output sent to browser
DEBUG - 2019-07-12 00:11:16 --> Total execution time: 0.5451
INFO - 2019-07-12 00:11:44 --> Helper loaded: language_helper
INFO - 2019-07-12 00:11:44 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:11:44 --> Model Class Initialized
INFO - 2019-07-12 00:11:44 --> Model Class Initialized
INFO - 2019-07-12 00:11:44 --> Model Class Initialized
INFO - 2019-07-12 00:11:44 --> Model Class Initialized
INFO - 2019-07-12 00:11:44 --> Helper loaded: form_helper
INFO - 2019-07-12 00:11:44 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:11:44 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:11:44 --> Model Class Initialized
INFO - 2019-07-12 00:11:44 --> Model Class Initialized
INFO - 2019-07-12 00:11:44 --> Final output sent to browser
DEBUG - 2019-07-12 00:11:44 --> Total execution time: 0.5013
INFO - 2019-07-12 00:12:03 --> Helper loaded: language_helper
INFO - 2019-07-12 00:12:03 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:12:03 --> Model Class Initialized
INFO - 2019-07-12 00:12:03 --> Model Class Initialized
INFO - 2019-07-12 00:12:03 --> Model Class Initialized
INFO - 2019-07-12 00:12:03 --> Model Class Initialized
INFO - 2019-07-12 00:12:03 --> Model Class Initialized
INFO - 2019-07-12 00:12:03 --> Final output sent to browser
DEBUG - 2019-07-12 00:12:03 --> Total execution time: 0.4376
INFO - 2019-07-12 00:12:03 --> Helper loaded: language_helper
INFO - 2019-07-12 00:12:03 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:12:03 --> Model Class Initialized
INFO - 2019-07-12 00:12:03 --> Model Class Initialized
INFO - 2019-07-12 00:12:03 --> Model Class Initialized
INFO - 2019-07-12 00:12:03 --> Model Class Initialized
INFO - 2019-07-12 00:12:03 --> Helper loaded: form_helper
INFO - 2019-07-12 00:12:03 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:12:03 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:12:03 --> Model Class Initialized
INFO - 2019-07-12 00:12:03 --> Model Class Initialized
INFO - 2019-07-12 00:12:03 --> Final output sent to browser
DEBUG - 2019-07-12 00:12:03 --> Total execution time: 0.5273
INFO - 2019-07-12 00:12:15 --> Helper loaded: language_helper
INFO - 2019-07-12 00:12:15 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:12:15 --> Model Class Initialized
INFO - 2019-07-12 00:12:15 --> Model Class Initialized
INFO - 2019-07-12 00:12:15 --> Model Class Initialized
INFO - 2019-07-12 00:12:15 --> Model Class Initialized
INFO - 2019-07-12 00:12:15 --> Model Class Initialized
INFO - 2019-07-12 00:12:15 --> Final output sent to browser
DEBUG - 2019-07-12 00:12:15 --> Total execution time: 0.4698
INFO - 2019-07-12 00:12:15 --> Helper loaded: language_helper
INFO - 2019-07-12 00:12:15 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:12:15 --> Model Class Initialized
INFO - 2019-07-12 00:12:15 --> Model Class Initialized
INFO - 2019-07-12 00:12:15 --> Model Class Initialized
INFO - 2019-07-12 00:12:15 --> Model Class Initialized
INFO - 2019-07-12 00:12:15 --> Helper loaded: form_helper
INFO - 2019-07-12 00:12:15 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:12:15 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:12:15 --> Model Class Initialized
INFO - 2019-07-12 00:12:15 --> Model Class Initialized
INFO - 2019-07-12 00:12:15 --> Final output sent to browser
DEBUG - 2019-07-12 00:12:15 --> Total execution time: 0.5413
INFO - 2019-07-12 00:12:16 --> Helper loaded: language_helper
INFO - 2019-07-12 00:12:16 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:12:16 --> Model Class Initialized
INFO - 2019-07-12 00:12:16 --> Model Class Initialized
INFO - 2019-07-12 00:12:16 --> Model Class Initialized
INFO - 2019-07-12 00:12:16 --> Model Class Initialized
INFO - 2019-07-12 00:12:16 --> Helper loaded: form_helper
INFO - 2019-07-12 00:12:16 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:12:16 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:12:16 --> Model Class Initialized
INFO - 2019-07-12 00:12:16 --> Model Class Initialized
INFO - 2019-07-12 00:12:16 --> Final output sent to browser
DEBUG - 2019-07-12 00:12:16 --> Total execution time: 0.5207
INFO - 2019-07-12 00:12:54 --> Helper loaded: language_helper
INFO - 2019-07-12 00:12:54 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:12:54 --> Model Class Initialized
INFO - 2019-07-12 00:12:54 --> Model Class Initialized
INFO - 2019-07-12 00:12:54 --> Model Class Initialized
INFO - 2019-07-12 00:12:54 --> Model Class Initialized
INFO - 2019-07-12 00:12:54 --> Helper loaded: form_helper
INFO - 2019-07-12 00:12:54 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:12:54 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:12:54 --> Model Class Initialized
INFO - 2019-07-12 00:12:54 --> Model Class Initialized
INFO - 2019-07-12 00:12:54 --> Final output sent to browser
DEBUG - 2019-07-12 00:12:54 --> Total execution time: 0.5096
INFO - 2019-07-12 00:13:39 --> Helper loaded: language_helper
INFO - 2019-07-12 00:13:39 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:13:39 --> Model Class Initialized
INFO - 2019-07-12 00:13:39 --> Model Class Initialized
INFO - 2019-07-12 00:13:39 --> Model Class Initialized
INFO - 2019-07-12 00:13:39 --> Model Class Initialized
INFO - 2019-07-12 00:13:39 --> Model Class Initialized
INFO - 2019-07-12 00:13:39 --> Final output sent to browser
DEBUG - 2019-07-12 00:13:39 --> Total execution time: 0.4336
INFO - 2019-07-12 00:13:39 --> Helper loaded: language_helper
INFO - 2019-07-12 00:13:39 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:13:39 --> Model Class Initialized
INFO - 2019-07-12 00:13:39 --> Model Class Initialized
INFO - 2019-07-12 00:13:39 --> Model Class Initialized
INFO - 2019-07-12 00:13:39 --> Model Class Initialized
INFO - 2019-07-12 00:13:39 --> Helper loaded: form_helper
INFO - 2019-07-12 00:13:39 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:13:39 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:13:39 --> Model Class Initialized
INFO - 2019-07-12 00:13:40 --> Model Class Initialized
INFO - 2019-07-12 00:13:40 --> Final output sent to browser
DEBUG - 2019-07-12 00:13:40 --> Total execution time: 0.5542
INFO - 2019-07-12 00:13:41 --> Helper loaded: language_helper
INFO - 2019-07-12 00:13:41 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:13:41 --> Model Class Initialized
INFO - 2019-07-12 00:13:41 --> Model Class Initialized
INFO - 2019-07-12 00:13:41 --> Model Class Initialized
INFO - 2019-07-12 00:13:41 --> Model Class Initialized
INFO - 2019-07-12 00:13:41 --> Helper loaded: form_helper
INFO - 2019-07-12 00:13:41 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:13:41 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:13:41 --> Model Class Initialized
INFO - 2019-07-12 00:13:41 --> Model Class Initialized
INFO - 2019-07-12 00:13:41 --> Final output sent to browser
DEBUG - 2019-07-12 00:13:41 --> Total execution time: 0.4996
INFO - 2019-07-12 00:14:18 --> Helper loaded: language_helper
INFO - 2019-07-12 00:14:18 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:14:18 --> Model Class Initialized
INFO - 2019-07-12 00:14:18 --> Model Class Initialized
INFO - 2019-07-12 00:14:18 --> Model Class Initialized
INFO - 2019-07-12 00:14:18 --> Model Class Initialized
INFO - 2019-07-12 00:14:18 --> Model Class Initialized
INFO - 2019-07-12 00:14:18 --> Final output sent to browser
DEBUG - 2019-07-12 00:14:18 --> Total execution time: 0.4365
INFO - 2019-07-12 00:14:19 --> Helper loaded: language_helper
INFO - 2019-07-12 00:14:19 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:14:19 --> Model Class Initialized
INFO - 2019-07-12 00:14:19 --> Model Class Initialized
INFO - 2019-07-12 00:14:19 --> Model Class Initialized
INFO - 2019-07-12 00:14:19 --> Model Class Initialized
INFO - 2019-07-12 00:14:19 --> Helper loaded: form_helper
INFO - 2019-07-12 00:14:19 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:14:19 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:14:19 --> Model Class Initialized
INFO - 2019-07-12 00:14:19 --> Model Class Initialized
INFO - 2019-07-12 00:14:19 --> Final output sent to browser
DEBUG - 2019-07-12 00:14:19 --> Total execution time: 0.5037
INFO - 2019-07-12 00:14:21 --> Helper loaded: language_helper
INFO - 2019-07-12 00:14:21 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:14:21 --> Model Class Initialized
INFO - 2019-07-12 00:14:21 --> Model Class Initialized
INFO - 2019-07-12 00:14:21 --> Model Class Initialized
INFO - 2019-07-12 00:14:21 --> Model Class Initialized
INFO - 2019-07-12 00:14:21 --> Helper loaded: form_helper
INFO - 2019-07-12 00:14:21 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:14:21 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:14:21 --> Model Class Initialized
INFO - 2019-07-12 00:14:21 --> Model Class Initialized
INFO - 2019-07-12 00:14:21 --> Final output sent to browser
DEBUG - 2019-07-12 00:14:21 --> Total execution time: 0.4615
INFO - 2019-07-12 00:15:06 --> Helper loaded: language_helper
INFO - 2019-07-12 00:15:06 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:15:06 --> Model Class Initialized
INFO - 2019-07-12 00:15:06 --> Model Class Initialized
INFO - 2019-07-12 00:15:06 --> Model Class Initialized
INFO - 2019-07-12 00:15:06 --> Model Class Initialized
INFO - 2019-07-12 00:15:06 --> Model Class Initialized
INFO - 2019-07-12 00:15:06 --> Final output sent to browser
DEBUG - 2019-07-12 00:15:06 --> Total execution time: 0.4481
INFO - 2019-07-12 00:15:07 --> Helper loaded: language_helper
INFO - 2019-07-12 00:15:07 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:15:07 --> Model Class Initialized
INFO - 2019-07-12 00:15:07 --> Model Class Initialized
INFO - 2019-07-12 00:15:07 --> Helper loaded: language_helper
INFO - 2019-07-12 00:15:07 --> Model Class Initialized
INFO - 2019-07-12 00:15:07 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:15:07 --> Model Class Initialized
INFO - 2019-07-12 00:15:07 --> Model Class Initialized
INFO - 2019-07-12 00:15:07 --> Helper loaded: form_helper
INFO - 2019-07-12 00:15:07 --> Model Class Initialized
INFO - 2019-07-12 00:15:07 --> Form Validation Class Initialized
INFO - 2019-07-12 00:15:07 --> Model Class Initialized
DEBUG - 2019-07-12 00:15:07 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:15:07 --> Model Class Initialized
INFO - 2019-07-12 00:15:07 --> Model Class Initialized
INFO - 2019-07-12 00:15:07 --> Helper loaded: form_helper
INFO - 2019-07-12 00:15:07 --> Model Class Initialized
INFO - 2019-07-12 00:15:07 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:15:07 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:15:07 --> Final output sent to browser
DEBUG - 2019-07-12 00:15:07 --> Total execution time: 0.7475
INFO - 2019-07-12 00:15:07 --> Model Class Initialized
INFO - 2019-07-12 00:15:07 --> Model Class Initialized
INFO - 2019-07-12 00:15:07 --> Final output sent to browser
DEBUG - 2019-07-12 00:15:07 --> Total execution time: 0.7190
INFO - 2019-07-12 00:15:15 --> Helper loaded: language_helper
INFO - 2019-07-12 00:15:15 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:15:15 --> Model Class Initialized
INFO - 2019-07-12 00:15:15 --> Model Class Initialized
INFO - 2019-07-12 00:15:15 --> Model Class Initialized
INFO - 2019-07-12 00:15:15 --> Model Class Initialized
INFO - 2019-07-12 00:15:15 --> Model Class Initialized
INFO - 2019-07-12 00:15:15 --> Final output sent to browser
DEBUG - 2019-07-12 00:15:15 --> Total execution time: 0.4949
INFO - 2019-07-12 00:15:16 --> Helper loaded: language_helper
INFO - 2019-07-12 00:15:16 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:15:16 --> Model Class Initialized
INFO - 2019-07-12 00:15:16 --> Model Class Initialized
INFO - 2019-07-12 00:15:16 --> Model Class Initialized
INFO - 2019-07-12 00:15:16 --> Model Class Initialized
INFO - 2019-07-12 00:15:16 --> Helper loaded: form_helper
INFO - 2019-07-12 00:15:16 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:15:16 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:15:16 --> Model Class Initialized
INFO - 2019-07-12 00:15:16 --> Model Class Initialized
INFO - 2019-07-12 00:15:16 --> Final output sent to browser
DEBUG - 2019-07-12 00:15:16 --> Total execution time: 0.5097
INFO - 2019-07-12 00:15:17 --> Helper loaded: language_helper
INFO - 2019-07-12 00:15:17 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:15:17 --> Model Class Initialized
INFO - 2019-07-12 00:15:17 --> Model Class Initialized
INFO - 2019-07-12 00:15:17 --> Model Class Initialized
INFO - 2019-07-12 00:15:17 --> Model Class Initialized
INFO - 2019-07-12 00:15:17 --> Helper loaded: form_helper
INFO - 2019-07-12 00:15:17 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:15:17 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:15:17 --> Model Class Initialized
INFO - 2019-07-12 00:15:17 --> Model Class Initialized
INFO - 2019-07-12 00:15:17 --> Final output sent to browser
DEBUG - 2019-07-12 00:15:17 --> Total execution time: 0.4864
INFO - 2019-07-12 00:15:45 --> Helper loaded: language_helper
INFO - 2019-07-12 00:15:45 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:15:45 --> Model Class Initialized
INFO - 2019-07-12 00:15:45 --> Model Class Initialized
INFO - 2019-07-12 00:15:45 --> Model Class Initialized
INFO - 2019-07-12 00:15:45 --> Model Class Initialized
INFO - 2019-07-12 00:15:45 --> Helper loaded: form_helper
INFO - 2019-07-12 00:15:45 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:15:45 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:15:45 --> Model Class Initialized
INFO - 2019-07-12 00:15:45 --> Model Class Initialized
INFO - 2019-07-12 00:15:45 --> Final output sent to browser
DEBUG - 2019-07-12 00:15:45 --> Total execution time: 0.4851
INFO - 2019-07-12 00:15:45 --> Helper loaded: language_helper
INFO - 2019-07-12 00:15:45 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:15:45 --> Model Class Initialized
INFO - 2019-07-12 00:15:45 --> Model Class Initialized
INFO - 2019-07-12 00:15:45 --> Model Class Initialized
INFO - 2019-07-12 00:15:46 --> Model Class Initialized
INFO - 2019-07-12 00:15:46 --> Model Class Initialized
INFO - 2019-07-12 00:15:46 --> Final output sent to browser
DEBUG - 2019-07-12 00:15:46 --> Total execution time: 0.4696
INFO - 2019-07-12 00:15:46 --> Helper loaded: language_helper
INFO - 2019-07-12 00:15:46 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:15:46 --> Model Class Initialized
INFO - 2019-07-12 00:15:46 --> Model Class Initialized
INFO - 2019-07-12 00:15:46 --> Model Class Initialized
INFO - 2019-07-12 00:15:46 --> Model Class Initialized
INFO - 2019-07-12 00:15:46 --> Helper loaded: form_helper
INFO - 2019-07-12 00:15:46 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:15:46 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:15:46 --> Model Class Initialized
INFO - 2019-07-12 00:15:46 --> Model Class Initialized
INFO - 2019-07-12 00:15:46 --> Final output sent to browser
DEBUG - 2019-07-12 00:15:46 --> Total execution time: 0.5419
INFO - 2019-07-12 00:16:07 --> Helper loaded: language_helper
INFO - 2019-07-12 00:16:07 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:16:07 --> Model Class Initialized
INFO - 2019-07-12 00:16:07 --> Model Class Initialized
INFO - 2019-07-12 00:16:07 --> Model Class Initialized
INFO - 2019-07-12 00:16:07 --> Model Class Initialized
INFO - 2019-07-12 00:16:07 --> Model Class Initialized
INFO - 2019-07-12 00:16:07 --> Final output sent to browser
DEBUG - 2019-07-12 00:16:07 --> Total execution time: 0.6063
INFO - 2019-07-12 00:16:07 --> Helper loaded: language_helper
INFO - 2019-07-12 00:16:07 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:16:07 --> Model Class Initialized
INFO - 2019-07-12 00:16:07 --> Model Class Initialized
INFO - 2019-07-12 00:16:07 --> Model Class Initialized
INFO - 2019-07-12 00:16:07 --> Model Class Initialized
INFO - 2019-07-12 00:16:07 --> Helper loaded: form_helper
INFO - 2019-07-12 00:16:07 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:16:07 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:16:07 --> Model Class Initialized
INFO - 2019-07-12 00:16:07 --> Model Class Initialized
INFO - 2019-07-12 00:16:07 --> Final output sent to browser
DEBUG - 2019-07-12 00:16:07 --> Total execution time: 0.6818
INFO - 2019-07-12 00:16:07 --> Helper loaded: language_helper
INFO - 2019-07-12 00:16:07 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:16:07 --> Model Class Initialized
INFO - 2019-07-12 00:16:07 --> Model Class Initialized
INFO - 2019-07-12 00:16:07 --> Model Class Initialized
INFO - 2019-07-12 00:16:07 --> Model Class Initialized
INFO - 2019-07-12 00:16:07 --> Helper loaded: form_helper
INFO - 2019-07-12 00:16:07 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:16:07 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:16:07 --> Model Class Initialized
INFO - 2019-07-12 00:16:07 --> Model Class Initialized
INFO - 2019-07-12 00:16:07 --> Final output sent to browser
DEBUG - 2019-07-12 00:16:07 --> Total execution time: 0.5104
INFO - 2019-07-12 00:16:13 --> Helper loaded: language_helper
INFO - 2019-07-12 00:16:13 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:16:13 --> Model Class Initialized
INFO - 2019-07-12 00:16:13 --> Model Class Initialized
INFO - 2019-07-12 00:16:13 --> Model Class Initialized
INFO - 2019-07-12 00:16:13 --> Model Class Initialized
INFO - 2019-07-12 00:16:13 --> Helper loaded: form_helper
INFO - 2019-07-12 00:16:13 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:16:13 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:16:13 --> Model Class Initialized
INFO - 2019-07-12 00:16:13 --> Model Class Initialized
INFO - 2019-07-12 00:16:13 --> Final output sent to browser
DEBUG - 2019-07-12 00:16:13 --> Total execution time: 0.5239
INFO - 2019-07-12 00:16:28 --> Helper loaded: language_helper
INFO - 2019-07-12 00:16:28 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:16:28 --> Model Class Initialized
INFO - 2019-07-12 00:16:28 --> Model Class Initialized
INFO - 2019-07-12 00:16:28 --> Model Class Initialized
INFO - 2019-07-12 00:16:28 --> Model Class Initialized
INFO - 2019-07-12 00:16:28 --> Model Class Initialized
INFO - 2019-07-12 00:16:28 --> Final output sent to browser
DEBUG - 2019-07-12 00:16:28 --> Total execution time: 0.5222
INFO - 2019-07-12 00:16:28 --> Helper loaded: language_helper
INFO - 2019-07-12 00:16:28 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:16:28 --> Model Class Initialized
INFO - 2019-07-12 00:16:28 --> Model Class Initialized
INFO - 2019-07-12 00:16:28 --> Model Class Initialized
INFO - 2019-07-12 00:16:28 --> Model Class Initialized
INFO - 2019-07-12 00:16:28 --> Helper loaded: form_helper
INFO - 2019-07-12 00:16:28 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:16:28 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:16:28 --> Model Class Initialized
INFO - 2019-07-12 00:16:28 --> Model Class Initialized
INFO - 2019-07-12 00:16:28 --> Final output sent to browser
DEBUG - 2019-07-12 00:16:29 --> Total execution time: 0.5711
INFO - 2019-07-12 00:16:29 --> Helper loaded: language_helper
INFO - 2019-07-12 00:16:29 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:16:29 --> Model Class Initialized
INFO - 2019-07-12 00:16:29 --> Model Class Initialized
INFO - 2019-07-12 00:16:29 --> Model Class Initialized
INFO - 2019-07-12 00:16:29 --> Model Class Initialized
INFO - 2019-07-12 00:16:29 --> Helper loaded: form_helper
INFO - 2019-07-12 00:16:29 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:16:29 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:16:29 --> Model Class Initialized
INFO - 2019-07-12 00:16:29 --> Model Class Initialized
INFO - 2019-07-12 00:16:29 --> Final output sent to browser
DEBUG - 2019-07-12 00:16:29 --> Total execution time: 0.5711
INFO - 2019-07-12 00:16:30 --> Helper loaded: language_helper
INFO - 2019-07-12 00:16:30 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:16:30 --> Model Class Initialized
INFO - 2019-07-12 00:16:30 --> Model Class Initialized
INFO - 2019-07-12 00:16:30 --> Model Class Initialized
INFO - 2019-07-12 00:16:30 --> Model Class Initialized
INFO - 2019-07-12 00:16:30 --> Helper loaded: form_helper
INFO - 2019-07-12 00:16:30 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:16:30 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:16:30 --> Model Class Initialized
INFO - 2019-07-12 00:16:30 --> Model Class Initialized
INFO - 2019-07-12 00:16:30 --> Final output sent to browser
DEBUG - 2019-07-12 00:16:30 --> Total execution time: 0.5261
INFO - 2019-07-12 00:16:32 --> Helper loaded: language_helper
INFO - 2019-07-12 00:16:32 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:16:32 --> Model Class Initialized
INFO - 2019-07-12 00:16:32 --> Model Class Initialized
INFO - 2019-07-12 00:16:32 --> Model Class Initialized
INFO - 2019-07-12 00:16:32 --> Model Class Initialized
INFO - 2019-07-12 00:16:32 --> Helper loaded: form_helper
INFO - 2019-07-12 00:16:32 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:16:32 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:16:32 --> Model Class Initialized
INFO - 2019-07-12 00:16:32 --> Model Class Initialized
INFO - 2019-07-12 00:16:32 --> Final output sent to browser
DEBUG - 2019-07-12 00:16:32 --> Total execution time: 0.4896
INFO - 2019-07-12 00:16:32 --> Helper loaded: language_helper
INFO - 2019-07-12 00:16:32 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:16:32 --> Model Class Initialized
INFO - 2019-07-12 00:16:32 --> Model Class Initialized
INFO - 2019-07-12 00:16:32 --> Model Class Initialized
INFO - 2019-07-12 00:16:32 --> Model Class Initialized
INFO - 2019-07-12 00:16:32 --> Helper loaded: form_helper
INFO - 2019-07-12 00:16:32 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:16:32 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:16:32 --> Model Class Initialized
INFO - 2019-07-12 00:16:32 --> Model Class Initialized
INFO - 2019-07-12 00:16:32 --> Final output sent to browser
DEBUG - 2019-07-12 00:16:32 --> Total execution time: 0.5298
INFO - 2019-07-12 00:16:46 --> Helper loaded: language_helper
INFO - 2019-07-12 00:16:46 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:16:46 --> Model Class Initialized
INFO - 2019-07-12 00:16:46 --> Model Class Initialized
INFO - 2019-07-12 00:16:46 --> Model Class Initialized
INFO - 2019-07-12 00:16:46 --> Model Class Initialized
INFO - 2019-07-12 00:16:46 --> Model Class Initialized
INFO - 2019-07-12 00:16:46 --> Final output sent to browser
DEBUG - 2019-07-12 00:16:46 --> Total execution time: 0.4756
INFO - 2019-07-12 00:16:46 --> Helper loaded: language_helper
INFO - 2019-07-12 00:16:46 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:16:47 --> Model Class Initialized
INFO - 2019-07-12 00:16:47 --> Model Class Initialized
INFO - 2019-07-12 00:16:47 --> Model Class Initialized
INFO - 2019-07-12 00:16:47 --> Model Class Initialized
INFO - 2019-07-12 00:16:47 --> Helper loaded: form_helper
INFO - 2019-07-12 00:16:47 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:16:47 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:16:47 --> Model Class Initialized
INFO - 2019-07-12 00:16:47 --> Model Class Initialized
INFO - 2019-07-12 00:16:47 --> Final output sent to browser
DEBUG - 2019-07-12 00:16:47 --> Total execution time: 0.6164
INFO - 2019-07-12 00:16:48 --> Helper loaded: language_helper
INFO - 2019-07-12 00:16:48 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:16:48 --> Model Class Initialized
INFO - 2019-07-12 00:16:48 --> Model Class Initialized
INFO - 2019-07-12 00:16:48 --> Model Class Initialized
INFO - 2019-07-12 00:16:48 --> Model Class Initialized
INFO - 2019-07-12 00:16:48 --> Helper loaded: form_helper
INFO - 2019-07-12 00:16:48 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:16:48 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:16:48 --> Model Class Initialized
INFO - 2019-07-12 00:16:48 --> Model Class Initialized
INFO - 2019-07-12 00:16:48 --> Final output sent to browser
DEBUG - 2019-07-12 00:16:48 --> Total execution time: 0.5495
INFO - 2019-07-12 00:17:02 --> Helper loaded: language_helper
INFO - 2019-07-12 00:17:02 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:17:02 --> Model Class Initialized
INFO - 2019-07-12 00:17:02 --> Model Class Initialized
INFO - 2019-07-12 00:17:02 --> Model Class Initialized
INFO - 2019-07-12 00:17:02 --> Model Class Initialized
INFO - 2019-07-12 00:17:02 --> Model Class Initialized
INFO - 2019-07-12 00:17:02 --> Final output sent to browser
DEBUG - 2019-07-12 00:17:02 --> Total execution time: 0.4941
INFO - 2019-07-12 00:17:02 --> Helper loaded: language_helper
INFO - 2019-07-12 00:17:02 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:17:02 --> Model Class Initialized
INFO - 2019-07-12 00:17:02 --> Model Class Initialized
INFO - 2019-07-12 00:17:02 --> Model Class Initialized
INFO - 2019-07-12 00:17:02 --> Model Class Initialized
INFO - 2019-07-12 00:17:02 --> Helper loaded: form_helper
INFO - 2019-07-12 00:17:02 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:17:02 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:17:02 --> Model Class Initialized
INFO - 2019-07-12 00:17:02 --> Model Class Initialized
INFO - 2019-07-12 00:17:03 --> Final output sent to browser
DEBUG - 2019-07-12 00:17:03 --> Total execution time: 0.5469
INFO - 2019-07-12 00:17:29 --> Helper loaded: language_helper
INFO - 2019-07-12 00:17:29 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:17:29 --> Model Class Initialized
INFO - 2019-07-12 00:17:29 --> Model Class Initialized
INFO - 2019-07-12 00:17:29 --> Model Class Initialized
INFO - 2019-07-12 00:17:29 --> Model Class Initialized
INFO - 2019-07-12 00:17:29 --> Model Class Initialized
INFO - 2019-07-12 00:17:29 --> Final output sent to browser
DEBUG - 2019-07-12 00:17:29 --> Total execution time: 0.4865
INFO - 2019-07-12 00:17:30 --> Helper loaded: language_helper
INFO - 2019-07-12 00:17:30 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:17:30 --> Model Class Initialized
INFO - 2019-07-12 00:17:30 --> Model Class Initialized
INFO - 2019-07-12 00:17:30 --> Model Class Initialized
INFO - 2019-07-12 00:17:30 --> Model Class Initialized
INFO - 2019-07-12 00:17:30 --> Helper loaded: form_helper
INFO - 2019-07-12 00:17:30 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:17:30 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:17:30 --> Model Class Initialized
INFO - 2019-07-12 00:17:30 --> Model Class Initialized
INFO - 2019-07-12 00:17:30 --> Final output sent to browser
DEBUG - 2019-07-12 00:17:30 --> Total execution time: 0.6314
INFO - 2019-07-12 00:17:31 --> Helper loaded: language_helper
INFO - 2019-07-12 00:17:31 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:17:31 --> Model Class Initialized
INFO - 2019-07-12 00:17:31 --> Model Class Initialized
INFO - 2019-07-12 00:17:31 --> Model Class Initialized
INFO - 2019-07-12 00:17:31 --> Model Class Initialized
INFO - 2019-07-12 00:17:31 --> Helper loaded: form_helper
INFO - 2019-07-12 00:17:31 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:17:31 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:17:31 --> Model Class Initialized
INFO - 2019-07-12 00:17:31 --> Model Class Initialized
INFO - 2019-07-12 00:17:31 --> Final output sent to browser
DEBUG - 2019-07-12 00:17:31 --> Total execution time: 0.5218
INFO - 2019-07-12 00:18:20 --> Helper loaded: language_helper
INFO - 2019-07-12 00:18:21 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:18:21 --> Model Class Initialized
INFO - 2019-07-12 00:18:21 --> Model Class Initialized
INFO - 2019-07-12 00:18:21 --> Model Class Initialized
INFO - 2019-07-12 00:18:21 --> Model Class Initialized
INFO - 2019-07-12 00:18:21 --> Model Class Initialized
INFO - 2019-07-12 00:18:21 --> Final output sent to browser
DEBUG - 2019-07-12 00:18:21 --> Total execution time: 0.4699
INFO - 2019-07-12 00:18:21 --> Helper loaded: language_helper
INFO - 2019-07-12 00:18:21 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:18:21 --> Model Class Initialized
INFO - 2019-07-12 00:18:21 --> Model Class Initialized
INFO - 2019-07-12 00:18:21 --> Model Class Initialized
INFO - 2019-07-12 00:18:21 --> Model Class Initialized
INFO - 2019-07-12 00:18:21 --> Helper loaded: form_helper
INFO - 2019-07-12 00:18:21 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:18:21 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:18:21 --> Model Class Initialized
INFO - 2019-07-12 00:18:21 --> Model Class Initialized
INFO - 2019-07-12 00:18:21 --> Final output sent to browser
DEBUG - 2019-07-12 00:18:21 --> Total execution time: 0.5412
INFO - 2019-07-12 00:19:04 --> Helper loaded: language_helper
INFO - 2019-07-12 00:19:04 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:19:04 --> Model Class Initialized
INFO - 2019-07-12 00:19:04 --> Model Class Initialized
INFO - 2019-07-12 00:19:04 --> Model Class Initialized
INFO - 2019-07-12 00:19:04 --> Model Class Initialized
INFO - 2019-07-12 00:19:04 --> Model Class Initialized
INFO - 2019-07-12 00:19:04 --> Final output sent to browser
DEBUG - 2019-07-12 00:19:04 --> Total execution time: 0.5065
INFO - 2019-07-12 00:19:05 --> Helper loaded: language_helper
INFO - 2019-07-12 00:19:05 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:19:05 --> Model Class Initialized
INFO - 2019-07-12 00:19:05 --> Model Class Initialized
INFO - 2019-07-12 00:19:05 --> Model Class Initialized
INFO - 2019-07-12 00:19:05 --> Model Class Initialized
INFO - 2019-07-12 00:19:05 --> Helper loaded: form_helper
INFO - 2019-07-12 00:19:05 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:19:05 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:19:05 --> Model Class Initialized
INFO - 2019-07-12 00:19:05 --> Model Class Initialized
INFO - 2019-07-12 00:19:05 --> Final output sent to browser
INFO - 2019-07-12 00:19:05 --> Helper loaded: language_helper
DEBUG - 2019-07-12 00:19:05 --> Total execution time: 0.6961
INFO - 2019-07-12 00:19:05 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:19:05 --> Model Class Initialized
INFO - 2019-07-12 00:19:05 --> Model Class Initialized
INFO - 2019-07-12 00:19:05 --> Model Class Initialized
INFO - 2019-07-12 00:19:05 --> Model Class Initialized
INFO - 2019-07-12 00:19:05 --> Helper loaded: form_helper
INFO - 2019-07-12 00:19:05 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:19:05 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:19:05 --> Model Class Initialized
INFO - 2019-07-12 00:19:05 --> Model Class Initialized
INFO - 2019-07-12 00:19:05 --> Final output sent to browser
DEBUG - 2019-07-12 00:19:05 --> Total execution time: 0.6847
INFO - 2019-07-12 00:19:07 --> Helper loaded: language_helper
INFO - 2019-07-12 00:19:07 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:19:07 --> Model Class Initialized
INFO - 2019-07-12 00:19:07 --> Model Class Initialized
INFO - 2019-07-12 00:19:07 --> Model Class Initialized
INFO - 2019-07-12 00:19:07 --> Model Class Initialized
INFO - 2019-07-12 00:19:07 --> Helper loaded: form_helper
INFO - 2019-07-12 00:19:07 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:19:07 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:19:07 --> Model Class Initialized
INFO - 2019-07-12 00:19:07 --> Model Class Initialized
INFO - 2019-07-12 00:19:07 --> Final output sent to browser
DEBUG - 2019-07-12 00:19:07 --> Total execution time: 0.7966
INFO - 2019-07-12 00:19:07 --> Helper loaded: language_helper
INFO - 2019-07-12 00:19:07 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:19:07 --> Model Class Initialized
INFO - 2019-07-12 00:19:07 --> Model Class Initialized
INFO - 2019-07-12 00:19:07 --> Model Class Initialized
INFO - 2019-07-12 00:19:07 --> Model Class Initialized
INFO - 2019-07-12 00:19:07 --> Model Class Initialized
INFO - 2019-07-12 00:19:07 --> Final output sent to browser
DEBUG - 2019-07-12 00:19:07 --> Total execution time: 0.7236
INFO - 2019-07-12 00:19:08 --> Helper loaded: language_helper
INFO - 2019-07-12 00:19:08 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:19:08 --> Model Class Initialized
INFO - 2019-07-12 00:19:08 --> Model Class Initialized
INFO - 2019-07-12 00:19:08 --> Model Class Initialized
INFO - 2019-07-12 00:19:08 --> Model Class Initialized
INFO - 2019-07-12 00:19:08 --> Helper loaded: form_helper
INFO - 2019-07-12 00:19:08 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:19:08 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:19:08 --> Model Class Initialized
INFO - 2019-07-12 00:19:08 --> Model Class Initialized
INFO - 2019-07-12 00:19:08 --> Final output sent to browser
DEBUG - 2019-07-12 00:19:08 --> Total execution time: 0.5554
INFO - 2019-07-12 00:19:46 --> Helper loaded: language_helper
INFO - 2019-07-12 00:19:46 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:19:46 --> Model Class Initialized
INFO - 2019-07-12 00:19:46 --> Model Class Initialized
INFO - 2019-07-12 00:19:46 --> Model Class Initialized
INFO - 2019-07-12 00:19:46 --> Model Class Initialized
INFO - 2019-07-12 00:19:46 --> Model Class Initialized
INFO - 2019-07-12 00:19:46 --> Final output sent to browser
DEBUG - 2019-07-12 00:19:46 --> Total execution time: 0.4833
INFO - 2019-07-12 00:19:47 --> Helper loaded: language_helper
INFO - 2019-07-12 00:19:47 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:19:47 --> Model Class Initialized
INFO - 2019-07-12 00:19:47 --> Model Class Initialized
INFO - 2019-07-12 00:19:47 --> Model Class Initialized
INFO - 2019-07-12 00:19:47 --> Model Class Initialized
INFO - 2019-07-12 00:19:47 --> Helper loaded: form_helper
INFO - 2019-07-12 00:19:47 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:19:47 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:19:47 --> Model Class Initialized
INFO - 2019-07-12 00:19:47 --> Model Class Initialized
INFO - 2019-07-12 00:19:47 --> Final output sent to browser
DEBUG - 2019-07-12 00:19:47 --> Total execution time: 0.5880
INFO - 2019-07-12 00:19:48 --> Helper loaded: language_helper
INFO - 2019-07-12 00:19:48 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:19:48 --> Model Class Initialized
INFO - 2019-07-12 00:19:48 --> Model Class Initialized
INFO - 2019-07-12 00:19:48 --> Model Class Initialized
INFO - 2019-07-12 00:19:48 --> Model Class Initialized
INFO - 2019-07-12 00:19:48 --> Helper loaded: form_helper
INFO - 2019-07-12 00:19:48 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:19:48 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:19:48 --> Model Class Initialized
INFO - 2019-07-12 00:19:48 --> Model Class Initialized
INFO - 2019-07-12 00:19:48 --> Final output sent to browser
DEBUG - 2019-07-12 00:19:48 --> Total execution time: 0.5339
INFO - 2019-07-12 00:20:01 --> Helper loaded: language_helper
INFO - 2019-07-12 00:20:01 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:20:01 --> Model Class Initialized
INFO - 2019-07-12 00:20:01 --> Model Class Initialized
INFO - 2019-07-12 00:20:01 --> Model Class Initialized
INFO - 2019-07-12 00:20:01 --> Model Class Initialized
INFO - 2019-07-12 00:20:01 --> Model Class Initialized
INFO - 2019-07-12 00:20:01 --> Final output sent to browser
DEBUG - 2019-07-12 00:20:01 --> Total execution time: 0.5421
INFO - 2019-07-12 00:20:02 --> Helper loaded: language_helper
INFO - 2019-07-12 00:20:02 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:20:02 --> Model Class Initialized
INFO - 2019-07-12 00:20:02 --> Model Class Initialized
INFO - 2019-07-12 00:20:02 --> Model Class Initialized
INFO - 2019-07-12 00:20:02 --> Model Class Initialized
INFO - 2019-07-12 00:20:02 --> Helper loaded: form_helper
INFO - 2019-07-12 00:20:02 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:20:02 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:20:02 --> Model Class Initialized
INFO - 2019-07-12 00:20:02 --> Model Class Initialized
INFO - 2019-07-12 00:20:02 --> Final output sent to browser
DEBUG - 2019-07-12 00:20:02 --> Total execution time: 0.5678
INFO - 2019-07-12 00:20:04 --> Helper loaded: language_helper
INFO - 2019-07-12 00:20:04 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:20:04 --> Model Class Initialized
INFO - 2019-07-12 00:20:04 --> Model Class Initialized
INFO - 2019-07-12 00:20:04 --> Model Class Initialized
INFO - 2019-07-12 00:20:04 --> Model Class Initialized
INFO - 2019-07-12 00:20:04 --> Helper loaded: form_helper
INFO - 2019-07-12 00:20:04 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:20:04 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:20:04 --> Model Class Initialized
INFO - 2019-07-12 00:20:04 --> Model Class Initialized
INFO - 2019-07-12 00:20:04 --> Final output sent to browser
DEBUG - 2019-07-12 00:20:04 --> Total execution time: 0.5241
INFO - 2019-07-12 00:21:20 --> Helper loaded: language_helper
INFO - 2019-07-12 00:21:20 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:21:20 --> Model Class Initialized
INFO - 2019-07-12 00:21:20 --> Model Class Initialized
INFO - 2019-07-12 00:21:20 --> Model Class Initialized
INFO - 2019-07-12 00:21:20 --> Model Class Initialized
INFO - 2019-07-12 00:21:20 --> Model Class Initialized
INFO - 2019-07-12 00:21:20 --> Final output sent to browser
DEBUG - 2019-07-12 00:21:20 --> Total execution time: 0.6156
INFO - 2019-07-12 00:21:20 --> Helper loaded: language_helper
INFO - 2019-07-12 00:21:20 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:21:20 --> Model Class Initialized
INFO - 2019-07-12 00:21:20 --> Model Class Initialized
INFO - 2019-07-12 00:21:20 --> Model Class Initialized
INFO - 2019-07-12 00:21:20 --> Model Class Initialized
INFO - 2019-07-12 00:21:20 --> Helper loaded: form_helper
INFO - 2019-07-12 00:21:20 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:21:20 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:21:20 --> Model Class Initialized
INFO - 2019-07-12 00:21:20 --> Model Class Initialized
INFO - 2019-07-12 00:21:20 --> Final output sent to browser
DEBUG - 2019-07-12 00:21:20 --> Total execution time: 0.7212
INFO - 2019-07-12 00:21:20 --> Helper loaded: language_helper
INFO - 2019-07-12 00:21:20 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:21:20 --> Model Class Initialized
INFO - 2019-07-12 00:21:20 --> Model Class Initialized
INFO - 2019-07-12 00:21:20 --> Model Class Initialized
INFO - 2019-07-12 00:21:20 --> Model Class Initialized
INFO - 2019-07-12 00:21:20 --> Helper loaded: form_helper
INFO - 2019-07-12 00:21:20 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:21:20 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:21:20 --> Model Class Initialized
INFO - 2019-07-12 00:21:20 --> Model Class Initialized
INFO - 2019-07-12 00:21:20 --> Final output sent to browser
DEBUG - 2019-07-12 00:21:20 --> Total execution time: 0.5757
INFO - 2019-07-12 00:21:44 --> Helper loaded: language_helper
INFO - 2019-07-12 00:21:44 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:21:44 --> Model Class Initialized
INFO - 2019-07-12 00:21:44 --> Model Class Initialized
INFO - 2019-07-12 00:21:44 --> Model Class Initialized
INFO - 2019-07-12 00:21:44 --> Model Class Initialized
INFO - 2019-07-12 00:21:44 --> Helper loaded: form_helper
INFO - 2019-07-12 00:21:44 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:21:44 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:21:44 --> Model Class Initialized
INFO - 2019-07-12 00:21:44 --> Model Class Initialized
INFO - 2019-07-12 00:21:44 --> Final output sent to browser
DEBUG - 2019-07-12 00:21:44 --> Total execution time: 0.5298
INFO - 2019-07-12 00:21:56 --> Helper loaded: language_helper
INFO - 2019-07-12 00:21:56 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:21:56 --> Model Class Initialized
INFO - 2019-07-12 00:21:56 --> Model Class Initialized
INFO - 2019-07-12 00:21:56 --> Model Class Initialized
INFO - 2019-07-12 00:21:56 --> Model Class Initialized
INFO - 2019-07-12 00:21:56 --> Model Class Initialized
INFO - 2019-07-12 00:21:56 --> Final output sent to browser
DEBUG - 2019-07-12 00:21:56 --> Total execution time: 0.5159
INFO - 2019-07-12 00:21:56 --> Helper loaded: language_helper
INFO - 2019-07-12 00:21:56 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:21:56 --> Model Class Initialized
INFO - 2019-07-12 00:21:56 --> Model Class Initialized
INFO - 2019-07-12 00:21:56 --> Model Class Initialized
INFO - 2019-07-12 00:21:56 --> Model Class Initialized
INFO - 2019-07-12 00:21:56 --> Helper loaded: form_helper
INFO - 2019-07-12 00:21:56 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:21:56 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:21:56 --> Model Class Initialized
INFO - 2019-07-12 00:21:56 --> Model Class Initialized
INFO - 2019-07-12 00:21:56 --> Final output sent to browser
DEBUG - 2019-07-12 00:21:56 --> Total execution time: 0.5603
INFO - 2019-07-12 00:21:57 --> Helper loaded: language_helper
INFO - 2019-07-12 00:21:57 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:21:57 --> Model Class Initialized
INFO - 2019-07-12 00:21:57 --> Model Class Initialized
INFO - 2019-07-12 00:21:57 --> Model Class Initialized
INFO - 2019-07-12 00:21:57 --> Model Class Initialized
INFO - 2019-07-12 00:21:57 --> Helper loaded: form_helper
INFO - 2019-07-12 00:21:57 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:21:57 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:21:57 --> Model Class Initialized
INFO - 2019-07-12 00:21:57 --> Model Class Initialized
INFO - 2019-07-12 00:21:57 --> Final output sent to browser
DEBUG - 2019-07-12 00:21:57 --> Total execution time: 0.5644
INFO - 2019-07-12 00:22:20 --> Helper loaded: language_helper
INFO - 2019-07-12 00:22:20 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:22:20 --> Model Class Initialized
INFO - 2019-07-12 00:22:20 --> Model Class Initialized
INFO - 2019-07-12 00:22:20 --> Model Class Initialized
INFO - 2019-07-12 00:22:20 --> Model Class Initialized
INFO - 2019-07-12 00:22:20 --> Model Class Initialized
INFO - 2019-07-12 00:22:20 --> Final output sent to browser
DEBUG - 2019-07-12 00:22:20 --> Total execution time: 0.4984
INFO - 2019-07-12 00:22:20 --> Helper loaded: language_helper
INFO - 2019-07-12 00:22:20 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:22:20 --> Model Class Initialized
INFO - 2019-07-12 00:22:20 --> Model Class Initialized
INFO - 2019-07-12 00:22:20 --> Model Class Initialized
INFO - 2019-07-12 00:22:20 --> Model Class Initialized
INFO - 2019-07-12 00:22:20 --> Helper loaded: form_helper
INFO - 2019-07-12 00:22:20 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:22:20 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:22:20 --> Model Class Initialized
INFO - 2019-07-12 00:22:20 --> Model Class Initialized
INFO - 2019-07-12 00:22:20 --> Final output sent to browser
DEBUG - 2019-07-12 00:22:20 --> Total execution time: 0.6314
INFO - 2019-07-12 00:22:22 --> Helper loaded: language_helper
INFO - 2019-07-12 00:22:22 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:22:22 --> Model Class Initialized
INFO - 2019-07-12 00:22:22 --> Model Class Initialized
INFO - 2019-07-12 00:22:22 --> Model Class Initialized
INFO - 2019-07-12 00:22:22 --> Model Class Initialized
INFO - 2019-07-12 00:22:22 --> Helper loaded: form_helper
INFO - 2019-07-12 00:22:22 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:22:22 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:22:22 --> Model Class Initialized
INFO - 2019-07-12 00:22:22 --> Model Class Initialized
INFO - 2019-07-12 00:22:22 --> Final output sent to browser
DEBUG - 2019-07-12 00:22:22 --> Total execution time: 0.5307
INFO - 2019-07-12 00:22:38 --> Helper loaded: language_helper
INFO - 2019-07-12 00:22:38 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:22:38 --> Model Class Initialized
INFO - 2019-07-12 00:22:38 --> Model Class Initialized
INFO - 2019-07-12 00:22:38 --> Model Class Initialized
INFO - 2019-07-12 00:22:38 --> Model Class Initialized
INFO - 2019-07-12 00:22:38 --> Model Class Initialized
INFO - 2019-07-12 00:22:38 --> Final output sent to browser
DEBUG - 2019-07-12 00:22:38 --> Total execution time: 0.6372
INFO - 2019-07-12 00:22:38 --> Helper loaded: language_helper
INFO - 2019-07-12 00:22:38 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:22:38 --> Model Class Initialized
INFO - 2019-07-12 00:22:38 --> Model Class Initialized
INFO - 2019-07-12 00:22:38 --> Model Class Initialized
INFO - 2019-07-12 00:22:38 --> Model Class Initialized
INFO - 2019-07-12 00:22:38 --> Helper loaded: form_helper
INFO - 2019-07-12 00:22:38 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:22:38 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:22:38 --> Model Class Initialized
INFO - 2019-07-12 00:22:38 --> Model Class Initialized
INFO - 2019-07-12 00:22:38 --> Final output sent to browser
DEBUG - 2019-07-12 00:22:38 --> Total execution time: 0.6505
INFO - 2019-07-12 00:22:39 --> Helper loaded: language_helper
INFO - 2019-07-12 00:22:39 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:22:39 --> Model Class Initialized
INFO - 2019-07-12 00:22:39 --> Model Class Initialized
INFO - 2019-07-12 00:22:39 --> Model Class Initialized
INFO - 2019-07-12 00:22:39 --> Model Class Initialized
INFO - 2019-07-12 00:22:39 --> Helper loaded: form_helper
INFO - 2019-07-12 00:22:39 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:22:39 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:22:39 --> Model Class Initialized
INFO - 2019-07-12 00:22:39 --> Model Class Initialized
INFO - 2019-07-12 00:22:39 --> Final output sent to browser
DEBUG - 2019-07-12 00:22:39 --> Total execution time: 0.5893
INFO - 2019-07-12 00:22:53 --> Helper loaded: language_helper
INFO - 2019-07-12 00:22:53 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:22:53 --> Model Class Initialized
INFO - 2019-07-12 00:22:53 --> Model Class Initialized
INFO - 2019-07-12 00:22:53 --> Model Class Initialized
INFO - 2019-07-12 00:22:53 --> Model Class Initialized
INFO - 2019-07-12 00:22:53 --> Model Class Initialized
INFO - 2019-07-12 00:22:53 --> Final output sent to browser
DEBUG - 2019-07-12 00:22:53 --> Total execution time: 0.5523
INFO - 2019-07-12 00:22:54 --> Helper loaded: language_helper
INFO - 2019-07-12 00:22:54 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:22:54 --> Model Class Initialized
INFO - 2019-07-12 00:22:54 --> Model Class Initialized
INFO - 2019-07-12 00:22:54 --> Model Class Initialized
INFO - 2019-07-12 00:22:54 --> Model Class Initialized
INFO - 2019-07-12 00:22:54 --> Helper loaded: language_helper
INFO - 2019-07-12 00:22:54 --> Helper loaded: form_helper
INFO - 2019-07-12 00:22:54 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:22:54 --> Form Validation Class Initialized
INFO - 2019-07-12 00:22:54 --> Model Class Initialized
DEBUG - 2019-07-12 00:22:54 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:22:54 --> Model Class Initialized
INFO - 2019-07-12 00:22:54 --> Model Class Initialized
INFO - 2019-07-12 00:22:54 --> Model Class Initialized
INFO - 2019-07-12 00:22:54 --> Model Class Initialized
INFO - 2019-07-12 00:22:54 --> Model Class Initialized
INFO - 2019-07-12 00:22:54 --> Final output sent to browser
INFO - 2019-07-12 00:22:54 --> Helper loaded: form_helper
DEBUG - 2019-07-12 00:22:54 --> Total execution time: 0.7878
INFO - 2019-07-12 00:22:54 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:22:54 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:22:54 --> Model Class Initialized
INFO - 2019-07-12 00:22:54 --> Model Class Initialized
INFO - 2019-07-12 00:22:54 --> Final output sent to browser
DEBUG - 2019-07-12 00:22:54 --> Total execution time: 0.7851
INFO - 2019-07-12 00:23:11 --> Helper loaded: language_helper
INFO - 2019-07-12 00:23:11 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:23:11 --> Model Class Initialized
INFO - 2019-07-12 00:23:11 --> Model Class Initialized
INFO - 2019-07-12 00:23:11 --> Model Class Initialized
INFO - 2019-07-12 00:23:11 --> Model Class Initialized
INFO - 2019-07-12 00:23:11 --> Model Class Initialized
INFO - 2019-07-12 00:23:11 --> Final output sent to browser
DEBUG - 2019-07-12 00:23:11 --> Total execution time: 0.4881
INFO - 2019-07-12 00:23:12 --> Helper loaded: language_helper
INFO - 2019-07-12 00:23:12 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:23:12 --> Model Class Initialized
INFO - 2019-07-12 00:23:12 --> Model Class Initialized
INFO - 2019-07-12 00:23:12 --> Model Class Initialized
INFO - 2019-07-12 00:23:12 --> Model Class Initialized
INFO - 2019-07-12 00:23:12 --> Helper loaded: form_helper
INFO - 2019-07-12 00:23:12 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:23:12 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:23:12 --> Model Class Initialized
INFO - 2019-07-12 00:23:12 --> Model Class Initialized
INFO - 2019-07-12 00:23:12 --> Final output sent to browser
DEBUG - 2019-07-12 00:23:12 --> Total execution time: 0.6710
INFO - 2019-07-12 00:23:13 --> Helper loaded: language_helper
INFO - 2019-07-12 00:23:13 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:23:13 --> Model Class Initialized
INFO - 2019-07-12 00:23:13 --> Model Class Initialized
INFO - 2019-07-12 00:23:13 --> Model Class Initialized
INFO - 2019-07-12 00:23:13 --> Model Class Initialized
INFO - 2019-07-12 00:23:13 --> Helper loaded: form_helper
INFO - 2019-07-12 00:23:13 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:23:13 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:23:13 --> Model Class Initialized
INFO - 2019-07-12 00:23:13 --> Model Class Initialized
INFO - 2019-07-12 00:23:13 --> Final output sent to browser
DEBUG - 2019-07-12 00:23:13 --> Total execution time: 0.5458
INFO - 2019-07-12 00:23:59 --> Helper loaded: language_helper
INFO - 2019-07-12 00:23:59 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:23:59 --> Model Class Initialized
INFO - 2019-07-12 00:23:59 --> Model Class Initialized
INFO - 2019-07-12 00:23:59 --> Model Class Initialized
INFO - 2019-07-12 00:23:59 --> Model Class Initialized
INFO - 2019-07-12 00:23:59 --> Helper loaded: form_helper
INFO - 2019-07-12 00:23:59 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:23:59 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:23:59 --> Model Class Initialized
INFO - 2019-07-12 00:23:59 --> Model Class Initialized
INFO - 2019-07-12 00:23:59 --> Final output sent to browser
DEBUG - 2019-07-12 00:23:59 --> Total execution time: 0.6610
INFO - 2019-07-12 00:23:59 --> Helper loaded: language_helper
INFO - 2019-07-12 00:23:59 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:23:59 --> Model Class Initialized
INFO - 2019-07-12 00:23:59 --> Model Class Initialized
INFO - 2019-07-12 00:23:59 --> Model Class Initialized
INFO - 2019-07-12 00:23:59 --> Model Class Initialized
INFO - 2019-07-12 00:23:59 --> Model Class Initialized
INFO - 2019-07-12 00:23:59 --> Final output sent to browser
DEBUG - 2019-07-12 00:23:59 --> Total execution time: 0.4862
INFO - 2019-07-12 00:24:00 --> Helper loaded: language_helper
INFO - 2019-07-12 00:24:00 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:24:00 --> Model Class Initialized
INFO - 2019-07-12 00:24:00 --> Model Class Initialized
INFO - 2019-07-12 00:24:00 --> Model Class Initialized
INFO - 2019-07-12 00:24:00 --> Model Class Initialized
INFO - 2019-07-12 00:24:00 --> Helper loaded: form_helper
INFO - 2019-07-12 00:24:00 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:24:00 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:24:00 --> Model Class Initialized
INFO - 2019-07-12 00:24:00 --> Model Class Initialized
INFO - 2019-07-12 00:24:00 --> Final output sent to browser
DEBUG - 2019-07-12 00:24:00 --> Total execution time: 0.5550
INFO - 2019-07-12 00:24:20 --> Helper loaded: language_helper
INFO - 2019-07-12 00:24:20 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:24:20 --> Model Class Initialized
INFO - 2019-07-12 00:24:20 --> Model Class Initialized
INFO - 2019-07-12 00:24:20 --> Model Class Initialized
INFO - 2019-07-12 00:24:20 --> Model Class Initialized
INFO - 2019-07-12 00:24:20 --> Model Class Initialized
INFO - 2019-07-12 00:24:20 --> Final output sent to browser
DEBUG - 2019-07-12 00:24:20 --> Total execution time: 0.4807
INFO - 2019-07-12 00:24:21 --> Helper loaded: language_helper
INFO - 2019-07-12 00:24:21 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:24:21 --> Model Class Initialized
INFO - 2019-07-12 00:24:21 --> Model Class Initialized
INFO - 2019-07-12 00:24:21 --> Model Class Initialized
INFO - 2019-07-12 00:24:21 --> Model Class Initialized
INFO - 2019-07-12 00:24:21 --> Helper loaded: form_helper
INFO - 2019-07-12 00:24:21 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:24:21 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:24:21 --> Model Class Initialized
INFO - 2019-07-12 00:24:21 --> Model Class Initialized
INFO - 2019-07-12 00:24:21 --> Final output sent to browser
DEBUG - 2019-07-12 00:24:21 --> Total execution time: 0.5697
INFO - 2019-07-12 00:24:24 --> Helper loaded: language_helper
INFO - 2019-07-12 00:24:24 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:24:24 --> Model Class Initialized
INFO - 2019-07-12 00:24:24 --> Model Class Initialized
INFO - 2019-07-12 00:24:24 --> Model Class Initialized
INFO - 2019-07-12 00:24:24 --> Model Class Initialized
INFO - 2019-07-12 00:24:24 --> Helper loaded: form_helper
INFO - 2019-07-12 00:24:24 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:24:24 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:24:24 --> Model Class Initialized
INFO - 2019-07-12 00:24:24 --> Model Class Initialized
INFO - 2019-07-12 00:24:24 --> Final output sent to browser
DEBUG - 2019-07-12 00:24:24 --> Total execution time: 0.5263
INFO - 2019-07-12 00:24:39 --> Helper loaded: language_helper
INFO - 2019-07-12 00:24:39 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:24:39 --> Model Class Initialized
INFO - 2019-07-12 00:24:39 --> Model Class Initialized
INFO - 2019-07-12 00:24:39 --> Model Class Initialized
INFO - 2019-07-12 00:24:39 --> Model Class Initialized
INFO - 2019-07-12 00:24:39 --> Model Class Initialized
INFO - 2019-07-12 00:24:39 --> Final output sent to browser
DEBUG - 2019-07-12 00:24:39 --> Total execution time: 0.5621
INFO - 2019-07-12 00:24:39 --> Helper loaded: language_helper
INFO - 2019-07-12 00:24:39 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:24:39 --> Model Class Initialized
INFO - 2019-07-12 00:24:39 --> Model Class Initialized
INFO - 2019-07-12 00:24:39 --> Model Class Initialized
INFO - 2019-07-12 00:24:39 --> Model Class Initialized
INFO - 2019-07-12 00:24:39 --> Helper loaded: form_helper
INFO - 2019-07-12 00:24:39 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:24:39 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:24:39 --> Model Class Initialized
INFO - 2019-07-12 00:24:39 --> Model Class Initialized
INFO - 2019-07-12 00:24:39 --> Final output sent to browser
DEBUG - 2019-07-12 00:24:39 --> Total execution time: 0.5759
INFO - 2019-07-12 00:24:40 --> Helper loaded: language_helper
INFO - 2019-07-12 00:24:40 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:24:40 --> Model Class Initialized
INFO - 2019-07-12 00:24:40 --> Model Class Initialized
INFO - 2019-07-12 00:24:40 --> Model Class Initialized
INFO - 2019-07-12 00:24:40 --> Model Class Initialized
INFO - 2019-07-12 00:24:40 --> Helper loaded: form_helper
INFO - 2019-07-12 00:24:40 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:24:40 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:24:40 --> Model Class Initialized
INFO - 2019-07-12 00:24:40 --> Model Class Initialized
INFO - 2019-07-12 00:24:40 --> Final output sent to browser
DEBUG - 2019-07-12 00:24:40 --> Total execution time: 0.5666
INFO - 2019-07-12 00:24:53 --> Helper loaded: language_helper
INFO - 2019-07-12 00:24:53 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:24:53 --> Model Class Initialized
INFO - 2019-07-12 00:24:53 --> Model Class Initialized
INFO - 2019-07-12 00:24:53 --> Model Class Initialized
INFO - 2019-07-12 00:24:53 --> Model Class Initialized
INFO - 2019-07-12 00:24:53 --> Model Class Initialized
INFO - 2019-07-12 00:24:53 --> Final output sent to browser
DEBUG - 2019-07-12 00:24:53 --> Total execution time: 0.5096
INFO - 2019-07-12 00:24:54 --> Helper loaded: language_helper
INFO - 2019-07-12 00:24:54 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:24:54 --> Model Class Initialized
INFO - 2019-07-12 00:24:54 --> Model Class Initialized
INFO - 2019-07-12 00:24:54 --> Model Class Initialized
INFO - 2019-07-12 00:24:54 --> Model Class Initialized
INFO - 2019-07-12 00:24:54 --> Helper loaded: form_helper
INFO - 2019-07-12 00:24:54 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:24:54 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:24:54 --> Model Class Initialized
INFO - 2019-07-12 00:24:54 --> Model Class Initialized
INFO - 2019-07-12 00:24:54 --> Final output sent to browser
DEBUG - 2019-07-12 00:24:54 --> Total execution time: 0.5702
INFO - 2019-07-12 00:24:56 --> Helper loaded: language_helper
INFO - 2019-07-12 00:24:56 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:24:56 --> Model Class Initialized
INFO - 2019-07-12 00:24:56 --> Model Class Initialized
INFO - 2019-07-12 00:24:56 --> Model Class Initialized
INFO - 2019-07-12 00:24:56 --> Model Class Initialized
INFO - 2019-07-12 00:24:56 --> Helper loaded: form_helper
INFO - 2019-07-12 00:24:56 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:24:56 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:24:56 --> Model Class Initialized
INFO - 2019-07-12 00:24:56 --> Model Class Initialized
INFO - 2019-07-12 00:24:56 --> Final output sent to browser
DEBUG - 2019-07-12 00:24:56 --> Total execution time: 0.6138
INFO - 2019-07-12 00:24:56 --> Helper loaded: language_helper
INFO - 2019-07-12 00:24:56 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:24:56 --> Model Class Initialized
INFO - 2019-07-12 00:24:56 --> Model Class Initialized
INFO - 2019-07-12 00:24:56 --> Model Class Initialized
INFO - 2019-07-12 00:24:56 --> Model Class Initialized
INFO - 2019-07-12 00:24:56 --> Model Class Initialized
INFO - 2019-07-12 00:24:56 --> Final output sent to browser
DEBUG - 2019-07-12 00:24:56 --> Total execution time: 0.4894
INFO - 2019-07-12 00:24:57 --> Helper loaded: language_helper
INFO - 2019-07-12 00:24:57 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:24:57 --> Model Class Initialized
INFO - 2019-07-12 00:24:57 --> Model Class Initialized
INFO - 2019-07-12 00:24:57 --> Model Class Initialized
INFO - 2019-07-12 00:24:57 --> Model Class Initialized
INFO - 2019-07-12 00:24:57 --> Helper loaded: form_helper
INFO - 2019-07-12 00:24:57 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:24:57 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:24:57 --> Model Class Initialized
INFO - 2019-07-12 00:24:57 --> Model Class Initialized
INFO - 2019-07-12 00:24:57 --> Final output sent to browser
DEBUG - 2019-07-12 00:24:57 --> Total execution time: 0.5612
INFO - 2019-07-12 00:26:24 --> Helper loaded: language_helper
INFO - 2019-07-12 00:26:24 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:26:24 --> Model Class Initialized
INFO - 2019-07-12 00:26:24 --> Model Class Initialized
INFO - 2019-07-12 00:26:24 --> Model Class Initialized
INFO - 2019-07-12 00:26:24 --> Model Class Initialized
INFO - 2019-07-12 00:26:24 --> Model Class Initialized
INFO - 2019-07-12 00:26:24 --> Final output sent to browser
DEBUG - 2019-07-12 00:26:24 --> Total execution time: 0.6569
INFO - 2019-07-12 00:26:24 --> Helper loaded: language_helper
INFO - 2019-07-12 00:26:24 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:26:24 --> Model Class Initialized
INFO - 2019-07-12 00:26:24 --> Model Class Initialized
INFO - 2019-07-12 00:26:24 --> Model Class Initialized
INFO - 2019-07-12 00:26:24 --> Model Class Initialized
INFO - 2019-07-12 00:26:24 --> Helper loaded: form_helper
INFO - 2019-07-12 00:26:24 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:26:24 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:26:24 --> Model Class Initialized
INFO - 2019-07-12 00:26:24 --> Model Class Initialized
INFO - 2019-07-12 00:26:24 --> Final output sent to browser
DEBUG - 2019-07-12 00:26:24 --> Total execution time: 0.6965
INFO - 2019-07-12 00:26:24 --> Helper loaded: language_helper
INFO - 2019-07-12 00:26:24 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:26:24 --> Model Class Initialized
INFO - 2019-07-12 00:26:24 --> Model Class Initialized
INFO - 2019-07-12 00:26:24 --> Model Class Initialized
INFO - 2019-07-12 00:26:24 --> Model Class Initialized
INFO - 2019-07-12 00:26:24 --> Helper loaded: form_helper
INFO - 2019-07-12 00:26:24 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:26:24 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:26:24 --> Model Class Initialized
INFO - 2019-07-12 00:26:24 --> Model Class Initialized
INFO - 2019-07-12 00:26:24 --> Final output sent to browser
DEBUG - 2019-07-12 00:26:24 --> Total execution time: 0.5827
INFO - 2019-07-12 00:27:31 --> Helper loaded: language_helper
INFO - 2019-07-12 00:27:31 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:27:31 --> Model Class Initialized
INFO - 2019-07-12 00:27:31 --> Model Class Initialized
INFO - 2019-07-12 00:27:31 --> Model Class Initialized
INFO - 2019-07-12 00:27:31 --> Model Class Initialized
INFO - 2019-07-12 00:27:31 --> Helper loaded: form_helper
INFO - 2019-07-12 00:27:31 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:27:31 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:27:31 --> Model Class Initialized
INFO - 2019-07-12 00:27:31 --> Model Class Initialized
INFO - 2019-07-12 00:27:31 --> Final output sent to browser
DEBUG - 2019-07-12 00:27:31 --> Total execution time: 0.5549
INFO - 2019-07-12 00:27:33 --> Helper loaded: language_helper
INFO - 2019-07-12 00:27:33 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:27:33 --> Model Class Initialized
INFO - 2019-07-12 00:27:33 --> Model Class Initialized
INFO - 2019-07-12 00:27:33 --> Model Class Initialized
INFO - 2019-07-12 00:27:33 --> Model Class Initialized
INFO - 2019-07-12 00:27:33 --> Model Class Initialized
INFO - 2019-07-12 00:27:33 --> Final output sent to browser
DEBUG - 2019-07-12 00:27:33 --> Total execution time: 0.5209
INFO - 2019-07-12 00:27:33 --> Helper loaded: language_helper
INFO - 2019-07-12 00:27:33 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:27:33 --> Model Class Initialized
INFO - 2019-07-12 00:27:33 --> Model Class Initialized
INFO - 2019-07-12 00:27:33 --> Model Class Initialized
INFO - 2019-07-12 00:27:33 --> Model Class Initialized
INFO - 2019-07-12 00:27:33 --> Helper loaded: form_helper
INFO - 2019-07-12 00:27:33 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:27:33 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:27:33 --> Model Class Initialized
INFO - 2019-07-12 00:27:33 --> Model Class Initialized
INFO - 2019-07-12 00:27:33 --> Final output sent to browser
DEBUG - 2019-07-12 00:27:33 --> Total execution time: 0.5716
INFO - 2019-07-12 00:27:34 --> Helper loaded: language_helper
INFO - 2019-07-12 00:27:34 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:27:34 --> Model Class Initialized
INFO - 2019-07-12 00:27:34 --> Model Class Initialized
INFO - 2019-07-12 00:27:34 --> Model Class Initialized
INFO - 2019-07-12 00:27:34 --> Model Class Initialized
INFO - 2019-07-12 00:27:34 --> Helper loaded: form_helper
INFO - 2019-07-12 00:27:34 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:27:34 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:27:34 --> Model Class Initialized
INFO - 2019-07-12 00:27:34 --> Model Class Initialized
INFO - 2019-07-12 00:27:34 --> Final output sent to browser
DEBUG - 2019-07-12 00:27:34 --> Total execution time: 0.5598
INFO - 2019-07-12 00:27:34 --> Helper loaded: language_helper
INFO - 2019-07-12 00:27:34 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:27:34 --> Model Class Initialized
INFO - 2019-07-12 00:27:34 --> Model Class Initialized
INFO - 2019-07-12 00:27:34 --> Model Class Initialized
INFO - 2019-07-12 00:27:34 --> Model Class Initialized
INFO - 2019-07-12 00:27:34 --> Helper loaded: form_helper
INFO - 2019-07-12 00:27:34 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:27:34 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:27:34 --> Model Class Initialized
INFO - 2019-07-12 00:27:34 --> Model Class Initialized
INFO - 2019-07-12 00:27:34 --> Final output sent to browser
DEBUG - 2019-07-12 00:27:34 --> Total execution time: 0.5538
INFO - 2019-07-12 00:27:48 --> Helper loaded: language_helper
INFO - 2019-07-12 00:27:48 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:27:48 --> Model Class Initialized
INFO - 2019-07-12 00:27:48 --> Model Class Initialized
INFO - 2019-07-12 00:27:48 --> Model Class Initialized
INFO - 2019-07-12 00:27:48 --> Model Class Initialized
INFO - 2019-07-12 00:27:48 --> Model Class Initialized
INFO - 2019-07-12 00:27:48 --> Final output sent to browser
DEBUG - 2019-07-12 00:27:48 --> Total execution time: 0.5439
INFO - 2019-07-12 00:27:48 --> Helper loaded: language_helper
INFO - 2019-07-12 00:27:48 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:27:48 --> Model Class Initialized
INFO - 2019-07-12 00:27:48 --> Model Class Initialized
INFO - 2019-07-12 00:27:48 --> Model Class Initialized
INFO - 2019-07-12 00:27:48 --> Model Class Initialized
INFO - 2019-07-12 00:27:48 --> Helper loaded: form_helper
INFO - 2019-07-12 00:27:48 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:27:48 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:27:48 --> Model Class Initialized
INFO - 2019-07-12 00:27:48 --> Model Class Initialized
INFO - 2019-07-12 00:27:48 --> Final output sent to browser
DEBUG - 2019-07-12 00:27:48 --> Total execution time: 0.6401
INFO - 2019-07-12 00:27:50 --> Helper loaded: language_helper
INFO - 2019-07-12 00:27:50 --> Helper loaded: language_helper
INFO - 2019-07-12 00:27:50 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:27:50 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:27:50 --> Model Class Initialized
INFO - 2019-07-12 00:27:50 --> Model Class Initialized
INFO - 2019-07-12 00:27:50 --> Model Class Initialized
INFO - 2019-07-12 00:27:50 --> Model Class Initialized
INFO - 2019-07-12 00:27:50 --> Model Class Initialized
INFO - 2019-07-12 00:27:50 --> Model Class Initialized
INFO - 2019-07-12 00:27:50 --> Model Class Initialized
INFO - 2019-07-12 00:27:50 --> Model Class Initialized
INFO - 2019-07-12 00:27:50 --> Helper loaded: form_helper
INFO - 2019-07-12 00:27:50 --> Helper loaded: form_helper
INFO - 2019-07-12 00:27:50 --> Form Validation Class Initialized
INFO - 2019-07-12 00:27:50 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:27:50 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
DEBUG - 2019-07-12 00:27:50 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:27:50 --> Model Class Initialized
INFO - 2019-07-12 00:27:50 --> Model Class Initialized
INFO - 2019-07-12 00:27:50 --> Model Class Initialized
INFO - 2019-07-12 00:27:50 --> Model Class Initialized
INFO - 2019-07-12 00:27:50 --> Final output sent to browser
INFO - 2019-07-12 00:27:50 --> Final output sent to browser
DEBUG - 2019-07-12 00:27:50 --> Total execution time: 0.8753
DEBUG - 2019-07-12 00:27:50 --> Total execution time: 0.8751
INFO - 2019-07-12 00:28:42 --> Helper loaded: language_helper
INFO - 2019-07-12 00:28:42 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:28:42 --> Model Class Initialized
INFO - 2019-07-12 00:28:42 --> Model Class Initialized
INFO - 2019-07-12 00:28:42 --> Helper loaded: language_helper
INFO - 2019-07-12 00:28:42 --> Model Class Initialized
INFO - 2019-07-12 00:28:42 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:28:42 --> Model Class Initialized
INFO - 2019-07-12 00:28:42 --> Model Class Initialized
INFO - 2019-07-12 00:28:42 --> Model Class Initialized
INFO - 2019-07-12 00:28:42 --> Model Class Initialized
INFO - 2019-07-12 00:28:42 --> Final output sent to browser
INFO - 2019-07-12 00:28:42 --> Model Class Initialized
DEBUG - 2019-07-12 00:28:42 --> Total execution time: 0.7008
INFO - 2019-07-12 00:28:42 --> Model Class Initialized
INFO - 2019-07-12 00:28:42 --> Helper loaded: form_helper
INFO - 2019-07-12 00:28:42 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:28:42 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:28:42 --> Model Class Initialized
INFO - 2019-07-12 00:28:42 --> Model Class Initialized
INFO - 2019-07-12 00:28:42 --> Final output sent to browser
DEBUG - 2019-07-12 00:28:42 --> Total execution time: 0.7695
INFO - 2019-07-12 00:28:43 --> Helper loaded: language_helper
INFO - 2019-07-12 00:28:43 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:28:43 --> Model Class Initialized
INFO - 2019-07-12 00:28:43 --> Model Class Initialized
INFO - 2019-07-12 00:28:43 --> Model Class Initialized
INFO - 2019-07-12 00:28:43 --> Model Class Initialized
INFO - 2019-07-12 00:28:43 --> Helper loaded: form_helper
INFO - 2019-07-12 00:28:43 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:28:43 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:28:43 --> Model Class Initialized
INFO - 2019-07-12 00:28:43 --> Model Class Initialized
INFO - 2019-07-12 00:28:43 --> Final output sent to browser
DEBUG - 2019-07-12 00:28:43 --> Total execution time: 0.5672
INFO - 2019-07-12 00:28:44 --> Helper loaded: language_helper
INFO - 2019-07-12 00:28:44 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:28:44 --> Model Class Initialized
INFO - 2019-07-12 00:28:44 --> Model Class Initialized
INFO - 2019-07-12 00:28:44 --> Model Class Initialized
INFO - 2019-07-12 00:28:44 --> Model Class Initialized
INFO - 2019-07-12 00:28:44 --> Helper loaded: form_helper
INFO - 2019-07-12 00:28:44 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:28:44 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:28:44 --> Model Class Initialized
INFO - 2019-07-12 00:28:44 --> Model Class Initialized
INFO - 2019-07-12 00:28:44 --> Final output sent to browser
DEBUG - 2019-07-12 00:28:44 --> Total execution time: 0.5385
INFO - 2019-07-12 00:29:03 --> Helper loaded: language_helper
INFO - 2019-07-12 00:29:03 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:29:03 --> Model Class Initialized
INFO - 2019-07-12 00:29:03 --> Model Class Initialized
INFO - 2019-07-12 00:29:03 --> Model Class Initialized
INFO - 2019-07-12 00:29:03 --> Model Class Initialized
INFO - 2019-07-12 00:29:03 --> Model Class Initialized
INFO - 2019-07-12 00:29:03 --> Final output sent to browser
DEBUG - 2019-07-12 00:29:03 --> Total execution time: 0.5129
INFO - 2019-07-12 00:29:04 --> Helper loaded: language_helper
INFO - 2019-07-12 00:29:04 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:29:04 --> Model Class Initialized
INFO - 2019-07-12 00:29:04 --> Model Class Initialized
INFO - 2019-07-12 00:29:04 --> Model Class Initialized
INFO - 2019-07-12 00:29:04 --> Model Class Initialized
INFO - 2019-07-12 00:29:04 --> Helper loaded: form_helper
INFO - 2019-07-12 00:29:04 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:29:04 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:29:04 --> Model Class Initialized
INFO - 2019-07-12 00:29:04 --> Model Class Initialized
INFO - 2019-07-12 00:29:04 --> Final output sent to browser
INFO - 2019-07-12 00:29:04 --> Helper loaded: language_helper
DEBUG - 2019-07-12 00:29:04 --> Total execution time: 0.6865
INFO - 2019-07-12 00:29:04 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:29:04 --> Model Class Initialized
INFO - 2019-07-12 00:29:04 --> Model Class Initialized
INFO - 2019-07-12 00:29:04 --> Model Class Initialized
INFO - 2019-07-12 00:29:04 --> Model Class Initialized
INFO - 2019-07-12 00:29:04 --> Helper loaded: form_helper
INFO - 2019-07-12 00:29:04 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:29:04 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:29:04 --> Model Class Initialized
INFO - 2019-07-12 00:29:04 --> Model Class Initialized
INFO - 2019-07-12 00:29:04 --> Final output sent to browser
DEBUG - 2019-07-12 00:29:04 --> Total execution time: 0.6898
INFO - 2019-07-12 00:29:06 --> Helper loaded: language_helper
INFO - 2019-07-12 00:29:06 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:29:06 --> Model Class Initialized
INFO - 2019-07-12 00:29:06 --> Model Class Initialized
INFO - 2019-07-12 00:29:06 --> Model Class Initialized
INFO - 2019-07-12 00:29:06 --> Model Class Initialized
INFO - 2019-07-12 00:29:06 --> Model Class Initialized
INFO - 2019-07-12 00:29:06 --> Final output sent to browser
DEBUG - 2019-07-12 00:29:06 --> Total execution time: 0.4957
INFO - 2019-07-12 00:29:07 --> Helper loaded: language_helper
INFO - 2019-07-12 00:29:07 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:29:07 --> Model Class Initialized
INFO - 2019-07-12 00:29:07 --> Model Class Initialized
INFO - 2019-07-12 00:29:07 --> Model Class Initialized
INFO - 2019-07-12 00:29:07 --> Model Class Initialized
INFO - 2019-07-12 00:29:07 --> Helper loaded: form_helper
INFO - 2019-07-12 00:29:07 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:29:07 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:29:07 --> Model Class Initialized
INFO - 2019-07-12 00:29:07 --> Model Class Initialized
INFO - 2019-07-12 00:29:07 --> Final output sent to browser
DEBUG - 2019-07-12 00:29:07 --> Total execution time: 0.6056
INFO - 2019-07-12 00:29:08 --> Helper loaded: language_helper
INFO - 2019-07-12 00:29:08 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:29:08 --> Model Class Initialized
INFO - 2019-07-12 00:29:08 --> Model Class Initialized
INFO - 2019-07-12 00:29:08 --> Model Class Initialized
INFO - 2019-07-12 00:29:08 --> Model Class Initialized
INFO - 2019-07-12 00:29:08 --> Helper loaded: language_helper
INFO - 2019-07-12 00:29:08 --> Helper loaded: form_helper
INFO - 2019-07-12 00:29:08 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:29:08 --> Form Validation Class Initialized
INFO - 2019-07-12 00:29:08 --> Model Class Initialized
DEBUG - 2019-07-12 00:29:08 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:29:08 --> Model Class Initialized
INFO - 2019-07-12 00:29:08 --> Model Class Initialized
INFO - 2019-07-12 00:29:08 --> Model Class Initialized
INFO - 2019-07-12 00:29:08 --> Model Class Initialized
INFO - 2019-07-12 00:29:08 --> Model Class Initialized
INFO - 2019-07-12 00:29:08 --> Final output sent to browser
INFO - 2019-07-12 00:29:08 --> Helper loaded: form_helper
DEBUG - 2019-07-12 00:29:08 --> Total execution time: 0.7999
INFO - 2019-07-12 00:29:08 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:29:08 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:29:08 --> Model Class Initialized
INFO - 2019-07-12 00:29:08 --> Model Class Initialized
INFO - 2019-07-12 00:29:08 --> Final output sent to browser
DEBUG - 2019-07-12 00:29:08 --> Total execution time: 0.7765
INFO - 2019-07-12 00:33:27 --> Helper loaded: language_helper
INFO - 2019-07-12 00:33:27 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:33:27 --> Model Class Initialized
INFO - 2019-07-12 00:33:27 --> Model Class Initialized
INFO - 2019-07-12 00:33:27 --> Model Class Initialized
INFO - 2019-07-12 00:33:27 --> Model Class Initialized
INFO - 2019-07-12 00:33:27 --> Model Class Initialized
INFO - 2019-07-12 00:33:27 --> Final output sent to browser
DEBUG - 2019-07-12 00:33:27 --> Total execution time: 0.4953
INFO - 2019-07-12 00:33:28 --> Helper loaded: language_helper
INFO - 2019-07-12 00:33:28 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:33:28 --> Model Class Initialized
INFO - 2019-07-12 00:33:28 --> Model Class Initialized
INFO - 2019-07-12 00:33:28 --> Model Class Initialized
INFO - 2019-07-12 00:33:28 --> Model Class Initialized
INFO - 2019-07-12 00:33:28 --> Helper loaded: form_helper
INFO - 2019-07-12 00:33:28 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:33:28 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:33:28 --> Model Class Initialized
INFO - 2019-07-12 00:33:28 --> Model Class Initialized
INFO - 2019-07-12 00:33:28 --> Final output sent to browser
DEBUG - 2019-07-12 00:33:28 --> Total execution time: 0.5784
INFO - 2019-07-12 00:33:30 --> Helper loaded: language_helper
INFO - 2019-07-12 00:33:30 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:33:30 --> Model Class Initialized
INFO - 2019-07-12 00:33:30 --> Model Class Initialized
INFO - 2019-07-12 00:33:30 --> Model Class Initialized
INFO - 2019-07-12 00:33:30 --> Model Class Initialized
INFO - 2019-07-12 00:33:30 --> Helper loaded: form_helper
INFO - 2019-07-12 00:33:30 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:33:30 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:33:30 --> Model Class Initialized
INFO - 2019-07-12 00:33:30 --> Model Class Initialized
INFO - 2019-07-12 00:33:30 --> Final output sent to browser
DEBUG - 2019-07-12 00:33:30 --> Total execution time: 0.5582
INFO - 2019-07-12 00:33:33 --> Helper loaded: language_helper
INFO - 2019-07-12 00:33:33 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:33:33 --> Model Class Initialized
INFO - 2019-07-12 00:33:33 --> Model Class Initialized
INFO - 2019-07-12 00:33:33 --> Model Class Initialized
INFO - 2019-07-12 00:33:33 --> Model Class Initialized
INFO - 2019-07-12 00:33:33 --> Model Class Initialized
INFO - 2019-07-12 00:33:33 --> Final output sent to browser
DEBUG - 2019-07-12 00:33:33 --> Total execution time: 0.5526
INFO - 2019-07-12 00:33:34 --> Helper loaded: language_helper
INFO - 2019-07-12 00:33:34 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:33:34 --> Model Class Initialized
INFO - 2019-07-12 00:33:34 --> Model Class Initialized
INFO - 2019-07-12 00:33:34 --> Model Class Initialized
INFO - 2019-07-12 00:33:34 --> Model Class Initialized
INFO - 2019-07-12 00:33:34 --> Helper loaded: form_helper
INFO - 2019-07-12 00:33:34 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:33:34 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:33:34 --> Model Class Initialized
INFO - 2019-07-12 00:33:34 --> Model Class Initialized
INFO - 2019-07-12 00:33:34 --> Final output sent to browser
DEBUG - 2019-07-12 00:33:34 --> Total execution time: 0.6982
INFO - 2019-07-12 00:33:34 --> Helper loaded: language_helper
INFO - 2019-07-12 00:33:34 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:33:34 --> Model Class Initialized
INFO - 2019-07-12 00:33:34 --> Model Class Initialized
INFO - 2019-07-12 00:33:34 --> Model Class Initialized
INFO - 2019-07-12 00:33:34 --> Model Class Initialized
INFO - 2019-07-12 00:33:34 --> Helper loaded: form_helper
INFO - 2019-07-12 00:33:34 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:33:34 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:33:34 --> Model Class Initialized
INFO - 2019-07-12 00:33:34 --> Model Class Initialized
INFO - 2019-07-12 00:33:34 --> Final output sent to browser
DEBUG - 2019-07-12 00:33:34 --> Total execution time: 0.6235
INFO - 2019-07-12 00:33:39 --> Helper loaded: language_helper
INFO - 2019-07-12 00:33:40 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:33:40 --> Model Class Initialized
INFO - 2019-07-12 00:33:40 --> Model Class Initialized
INFO - 2019-07-12 00:33:40 --> Model Class Initialized
INFO - 2019-07-12 00:33:40 --> Model Class Initialized
INFO - 2019-07-12 00:33:40 --> Model Class Initialized
INFO - 2019-07-12 00:33:40 --> Final output sent to browser
DEBUG - 2019-07-12 00:33:40 --> Total execution time: 0.5282
INFO - 2019-07-12 00:33:40 --> Helper loaded: language_helper
INFO - 2019-07-12 00:33:40 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:33:40 --> Model Class Initialized
INFO - 2019-07-12 00:33:40 --> Model Class Initialized
INFO - 2019-07-12 00:33:40 --> Model Class Initialized
INFO - 2019-07-12 00:33:40 --> Model Class Initialized
INFO - 2019-07-12 00:33:40 --> Helper loaded: form_helper
INFO - 2019-07-12 00:33:40 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:33:40 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:33:40 --> Model Class Initialized
INFO - 2019-07-12 00:33:40 --> Model Class Initialized
INFO - 2019-07-12 00:33:40 --> Final output sent to browser
DEBUG - 2019-07-12 00:33:40 --> Total execution time: 0.5976
INFO - 2019-07-12 00:33:41 --> Helper loaded: language_helper
INFO - 2019-07-12 00:33:41 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:33:41 --> Model Class Initialized
INFO - 2019-07-12 00:33:41 --> Model Class Initialized
INFO - 2019-07-12 00:33:41 --> Model Class Initialized
INFO - 2019-07-12 00:33:41 --> Model Class Initialized
INFO - 2019-07-12 00:33:41 --> Helper loaded: form_helper
INFO - 2019-07-12 00:33:41 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:33:41 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:33:41 --> Model Class Initialized
INFO - 2019-07-12 00:33:41 --> Model Class Initialized
INFO - 2019-07-12 00:33:41 --> Final output sent to browser
DEBUG - 2019-07-12 00:33:41 --> Total execution time: 0.5555
INFO - 2019-07-12 00:33:42 --> Helper loaded: language_helper
INFO - 2019-07-12 00:33:42 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:33:42 --> Model Class Initialized
INFO - 2019-07-12 00:33:42 --> Model Class Initialized
INFO - 2019-07-12 00:33:42 --> Model Class Initialized
INFO - 2019-07-12 00:33:42 --> Model Class Initialized
INFO - 2019-07-12 00:33:42 --> Helper loaded: form_helper
INFO - 2019-07-12 00:33:42 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:33:42 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:33:42 --> Model Class Initialized
INFO - 2019-07-12 00:33:42 --> Model Class Initialized
INFO - 2019-07-12 00:33:42 --> Final output sent to browser
DEBUG - 2019-07-12 00:33:42 --> Total execution time: 0.5524
INFO - 2019-07-12 00:33:58 --> Helper loaded: language_helper
INFO - 2019-07-12 00:33:58 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:33:58 --> Model Class Initialized
INFO - 2019-07-12 00:33:58 --> Model Class Initialized
INFO - 2019-07-12 00:33:58 --> Model Class Initialized
INFO - 2019-07-12 00:33:58 --> Model Class Initialized
INFO - 2019-07-12 00:33:58 --> Model Class Initialized
INFO - 2019-07-12 00:33:58 --> Final output sent to browser
DEBUG - 2019-07-12 00:33:58 --> Total execution time: 0.5031
INFO - 2019-07-12 00:33:58 --> Helper loaded: language_helper
INFO - 2019-07-12 00:33:58 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:33:58 --> Model Class Initialized
INFO - 2019-07-12 00:33:58 --> Model Class Initialized
INFO - 2019-07-12 00:33:58 --> Model Class Initialized
INFO - 2019-07-12 00:33:58 --> Model Class Initialized
INFO - 2019-07-12 00:33:58 --> Helper loaded: form_helper
INFO - 2019-07-12 00:33:58 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:33:58 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:33:58 --> Model Class Initialized
INFO - 2019-07-12 00:33:58 --> Model Class Initialized
INFO - 2019-07-12 00:33:58 --> Final output sent to browser
DEBUG - 2019-07-12 00:33:58 --> Total execution time: 0.5816
INFO - 2019-07-12 00:34:00 --> Helper loaded: language_helper
INFO - 2019-07-12 00:34:00 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:34:00 --> Model Class Initialized
INFO - 2019-07-12 00:34:00 --> Model Class Initialized
INFO - 2019-07-12 00:34:00 --> Model Class Initialized
INFO - 2019-07-12 00:34:00 --> Model Class Initialized
INFO - 2019-07-12 00:34:00 --> Helper loaded: form_helper
INFO - 2019-07-12 00:34:00 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:34:00 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:34:00 --> Model Class Initialized
INFO - 2019-07-12 00:34:00 --> Model Class Initialized
INFO - 2019-07-12 00:34:00 --> Final output sent to browser
DEBUG - 2019-07-12 00:34:00 --> Total execution time: 0.5446
INFO - 2019-07-12 00:34:07 --> Helper loaded: language_helper
INFO - 2019-07-12 00:34:07 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:34:07 --> Model Class Initialized
INFO - 2019-07-12 00:34:07 --> Model Class Initialized
INFO - 2019-07-12 00:34:07 --> Model Class Initialized
INFO - 2019-07-12 00:34:07 --> Model Class Initialized
INFO - 2019-07-12 00:34:07 --> Helper loaded: form_helper
INFO - 2019-07-12 00:34:07 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:34:07 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:34:07 --> Model Class Initialized
INFO - 2019-07-12 00:34:07 --> Model Class Initialized
INFO - 2019-07-12 00:34:07 --> Final output sent to browser
DEBUG - 2019-07-12 00:34:07 --> Total execution time: 0.5506
INFO - 2019-07-12 00:34:19 --> Helper loaded: language_helper
INFO - 2019-07-12 00:34:19 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:34:19 --> Model Class Initialized
INFO - 2019-07-12 00:34:19 --> Model Class Initialized
INFO - 2019-07-12 00:34:19 --> Model Class Initialized
INFO - 2019-07-12 00:34:19 --> Model Class Initialized
INFO - 2019-07-12 00:34:19 --> Model Class Initialized
INFO - 2019-07-12 00:34:19 --> Final output sent to browser
DEBUG - 2019-07-12 00:34:19 --> Total execution time: 0.6846
INFO - 2019-07-12 00:34:19 --> Helper loaded: language_helper
INFO - 2019-07-12 00:34:19 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:34:19 --> Model Class Initialized
INFO - 2019-07-12 00:34:19 --> Model Class Initialized
INFO - 2019-07-12 00:34:19 --> Model Class Initialized
INFO - 2019-07-12 00:34:19 --> Model Class Initialized
INFO - 2019-07-12 00:34:19 --> Helper loaded: form_helper
INFO - 2019-07-12 00:34:19 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:34:19 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:34:19 --> Model Class Initialized
INFO - 2019-07-12 00:34:19 --> Model Class Initialized
INFO - 2019-07-12 00:34:19 --> Final output sent to browser
DEBUG - 2019-07-12 00:34:19 --> Total execution time: 0.7271
INFO - 2019-07-12 00:34:19 --> Helper loaded: language_helper
INFO - 2019-07-12 00:34:20 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:34:20 --> Model Class Initialized
INFO - 2019-07-12 00:34:20 --> Model Class Initialized
INFO - 2019-07-12 00:34:20 --> Model Class Initialized
INFO - 2019-07-12 00:34:20 --> Model Class Initialized
INFO - 2019-07-12 00:34:20 --> Helper loaded: form_helper
INFO - 2019-07-12 00:34:20 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:34:20 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:34:20 --> Model Class Initialized
INFO - 2019-07-12 00:34:20 --> Model Class Initialized
INFO - 2019-07-12 00:34:20 --> Final output sent to browser
DEBUG - 2019-07-12 00:34:20 --> Total execution time: 0.6315
INFO - 2019-07-12 00:34:22 --> Helper loaded: language_helper
INFO - 2019-07-12 00:34:22 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:34:22 --> Model Class Initialized
INFO - 2019-07-12 00:34:22 --> Model Class Initialized
INFO - 2019-07-12 00:34:22 --> Model Class Initialized
INFO - 2019-07-12 00:34:22 --> Model Class Initialized
INFO - 2019-07-12 00:34:22 --> Model Class Initialized
INFO - 2019-07-12 00:34:22 --> Final output sent to browser
DEBUG - 2019-07-12 00:34:22 --> Total execution time: 0.5816
INFO - 2019-07-12 00:34:23 --> Helper loaded: language_helper
INFO - 2019-07-12 00:34:23 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:34:23 --> Model Class Initialized
INFO - 2019-07-12 00:34:23 --> Model Class Initialized
INFO - 2019-07-12 00:34:23 --> Model Class Initialized
INFO - 2019-07-12 00:34:23 --> Model Class Initialized
INFO - 2019-07-12 00:34:23 --> Helper loaded: form_helper
INFO - 2019-07-12 00:34:23 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:34:23 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:34:23 --> Model Class Initialized
INFO - 2019-07-12 00:34:23 --> Model Class Initialized
INFO - 2019-07-12 00:34:23 --> Helper loaded: language_helper
INFO - 2019-07-12 00:34:23 --> Final output sent to browser
INFO - 2019-07-12 00:34:23 --> Language file loaded: language/english/general_lang.php
DEBUG - 2019-07-12 00:34:23 --> Total execution time: 0.7520
INFO - 2019-07-12 00:34:23 --> Model Class Initialized
INFO - 2019-07-12 00:34:23 --> Model Class Initialized
INFO - 2019-07-12 00:34:23 --> Model Class Initialized
INFO - 2019-07-12 00:34:23 --> Model Class Initialized
INFO - 2019-07-12 00:34:23 --> Helper loaded: form_helper
INFO - 2019-07-12 00:34:23 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:34:23 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:34:23 --> Model Class Initialized
INFO - 2019-07-12 00:34:23 --> Model Class Initialized
INFO - 2019-07-12 00:34:23 --> Final output sent to browser
DEBUG - 2019-07-12 00:34:23 --> Total execution time: 0.7181
INFO - 2019-07-12 00:34:31 --> Helper loaded: language_helper
INFO - 2019-07-12 00:34:31 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:34:31 --> Model Class Initialized
INFO - 2019-07-12 00:34:31 --> Model Class Initialized
INFO - 2019-07-12 00:34:31 --> Model Class Initialized
INFO - 2019-07-12 00:34:31 --> Model Class Initialized
INFO - 2019-07-12 00:34:31 --> Model Class Initialized
INFO - 2019-07-12 00:34:31 --> Final output sent to browser
DEBUG - 2019-07-12 00:34:31 --> Total execution time: 0.8224
INFO - 2019-07-12 00:34:31 --> Helper loaded: language_helper
INFO - 2019-07-12 00:34:31 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:34:31 --> Model Class Initialized
INFO - 2019-07-12 00:34:32 --> Model Class Initialized
INFO - 2019-07-12 00:34:32 --> Model Class Initialized
INFO - 2019-07-12 00:34:32 --> Model Class Initialized
INFO - 2019-07-12 00:34:32 --> Model Class Initialized
INFO - 2019-07-12 00:34:32 --> Final output sent to browser
DEBUG - 2019-07-12 00:34:32 --> Total execution time: 0.7972
INFO - 2019-07-12 00:34:32 --> Helper loaded: language_helper
INFO - 2019-07-12 00:34:32 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:34:32 --> Model Class Initialized
INFO - 2019-07-12 00:34:32 --> Model Class Initialized
INFO - 2019-07-12 00:34:32 --> Model Class Initialized
INFO - 2019-07-12 00:34:32 --> Model Class Initialized
INFO - 2019-07-12 00:34:32 --> Helper loaded: form_helper
INFO - 2019-07-12 00:34:32 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:34:32 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:34:32 --> Model Class Initialized
INFO - 2019-07-12 00:34:32 --> Model Class Initialized
INFO - 2019-07-12 00:34:32 --> Final output sent to browser
DEBUG - 2019-07-12 00:34:32 --> Total execution time: 0.5806
INFO - 2019-07-12 00:34:33 --> Helper loaded: language_helper
INFO - 2019-07-12 00:34:33 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:34:33 --> Model Class Initialized
INFO - 2019-07-12 00:34:33 --> Model Class Initialized
INFO - 2019-07-12 00:34:33 --> Model Class Initialized
INFO - 2019-07-12 00:34:33 --> Model Class Initialized
INFO - 2019-07-12 00:34:33 --> Helper loaded: form_helper
INFO - 2019-07-12 00:34:33 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:34:33 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:34:33 --> Model Class Initialized
INFO - 2019-07-12 00:34:33 --> Model Class Initialized
INFO - 2019-07-12 00:34:33 --> Final output sent to browser
DEBUG - 2019-07-12 00:34:33 --> Total execution time: 0.5913
INFO - 2019-07-12 00:34:36 --> Helper loaded: language_helper
INFO - 2019-07-12 00:34:36 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:34:36 --> Model Class Initialized
INFO - 2019-07-12 00:34:36 --> Model Class Initialized
INFO - 2019-07-12 00:34:36 --> Model Class Initialized
INFO - 2019-07-12 00:34:36 --> Model Class Initialized
INFO - 2019-07-12 00:34:36 --> Helper loaded: form_helper
INFO - 2019-07-12 00:34:36 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:34:36 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:34:36 --> Model Class Initialized
INFO - 2019-07-12 00:34:36 --> Model Class Initialized
INFO - 2019-07-12 00:34:36 --> Final output sent to browser
DEBUG - 2019-07-12 00:34:36 --> Total execution time: 0.5694
INFO - 2019-07-12 00:36:40 --> Helper loaded: language_helper
INFO - 2019-07-12 00:36:40 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:36:40 --> Model Class Initialized
INFO - 2019-07-12 00:36:40 --> Model Class Initialized
INFO - 2019-07-12 00:36:40 --> Model Class Initialized
INFO - 2019-07-12 00:36:40 --> Model Class Initialized
INFO - 2019-07-12 00:36:40 --> Model Class Initialized
INFO - 2019-07-12 00:36:40 --> Final output sent to browser
DEBUG - 2019-07-12 00:36:40 --> Total execution time: 0.5369
INFO - 2019-07-12 00:36:41 --> Helper loaded: language_helper
INFO - 2019-07-12 00:36:41 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:36:41 --> Model Class Initialized
INFO - 2019-07-12 00:36:41 --> Model Class Initialized
INFO - 2019-07-12 00:36:41 --> Model Class Initialized
INFO - 2019-07-12 00:36:41 --> Model Class Initialized
INFO - 2019-07-12 00:36:41 --> Helper loaded: form_helper
INFO - 2019-07-12 00:36:41 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:36:41 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:36:41 --> Model Class Initialized
INFO - 2019-07-12 00:36:41 --> Model Class Initialized
INFO - 2019-07-12 00:36:41 --> Final output sent to browser
DEBUG - 2019-07-12 00:36:41 --> Total execution time: 0.6044
INFO - 2019-07-12 00:36:43 --> Helper loaded: language_helper
INFO - 2019-07-12 00:36:43 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:36:43 --> Model Class Initialized
INFO - 2019-07-12 00:36:43 --> Model Class Initialized
INFO - 2019-07-12 00:36:43 --> Model Class Initialized
INFO - 2019-07-12 00:36:43 --> Model Class Initialized
INFO - 2019-07-12 00:36:43 --> Helper loaded: form_helper
INFO - 2019-07-12 00:36:43 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:36:43 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:36:43 --> Model Class Initialized
INFO - 2019-07-12 00:36:43 --> Model Class Initialized
INFO - 2019-07-12 00:36:43 --> Final output sent to browser
DEBUG - 2019-07-12 00:36:43 --> Total execution time: 0.7306
INFO - 2019-07-12 00:36:43 --> Helper loaded: language_helper
INFO - 2019-07-12 00:36:43 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:36:43 --> Model Class Initialized
INFO - 2019-07-12 00:36:43 --> Model Class Initialized
INFO - 2019-07-12 00:36:43 --> Model Class Initialized
INFO - 2019-07-12 00:36:43 --> Model Class Initialized
INFO - 2019-07-12 00:36:43 --> Helper loaded: form_helper
INFO - 2019-07-12 00:36:43 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:36:43 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:36:43 --> Model Class Initialized
INFO - 2019-07-12 00:36:43 --> Model Class Initialized
INFO - 2019-07-12 00:36:43 --> Final output sent to browser
DEBUG - 2019-07-12 00:36:43 --> Total execution time: 0.7554
INFO - 2019-07-12 00:38:00 --> Helper loaded: language_helper
INFO - 2019-07-12 00:38:00 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:38:00 --> Model Class Initialized
INFO - 2019-07-12 00:38:00 --> Model Class Initialized
INFO - 2019-07-12 00:38:00 --> Model Class Initialized
INFO - 2019-07-12 00:38:00 --> Model Class Initialized
INFO - 2019-07-12 00:38:00 --> Model Class Initialized
INFO - 2019-07-12 00:38:00 --> Final output sent to browser
DEBUG - 2019-07-12 00:38:00 --> Total execution time: 0.5175
INFO - 2019-07-12 00:38:01 --> Helper loaded: language_helper
INFO - 2019-07-12 00:38:01 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:38:01 --> Model Class Initialized
INFO - 2019-07-12 00:38:01 --> Model Class Initialized
INFO - 2019-07-12 00:38:01 --> Model Class Initialized
INFO - 2019-07-12 00:38:01 --> Model Class Initialized
INFO - 2019-07-12 00:38:01 --> Helper loaded: form_helper
INFO - 2019-07-12 00:38:01 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:38:01 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:38:01 --> Model Class Initialized
INFO - 2019-07-12 00:38:01 --> Model Class Initialized
INFO - 2019-07-12 00:38:01 --> Final output sent to browser
DEBUG - 2019-07-12 00:38:01 --> Total execution time: 0.5914
INFO - 2019-07-12 00:38:02 --> Helper loaded: language_helper
INFO - 2019-07-12 00:38:02 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:38:02 --> Model Class Initialized
INFO - 2019-07-12 00:38:02 --> Model Class Initialized
INFO - 2019-07-12 00:38:02 --> Model Class Initialized
INFO - 2019-07-12 00:38:02 --> Model Class Initialized
INFO - 2019-07-12 00:38:02 --> Helper loaded: form_helper
INFO - 2019-07-12 00:38:02 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:38:02 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:38:02 --> Model Class Initialized
INFO - 2019-07-12 00:38:02 --> Model Class Initialized
INFO - 2019-07-12 00:38:02 --> Final output sent to browser
DEBUG - 2019-07-12 00:38:02 --> Total execution time: 0.5562
INFO - 2019-07-12 00:38:54 --> Helper loaded: language_helper
INFO - 2019-07-12 00:38:54 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:38:54 --> Model Class Initialized
INFO - 2019-07-12 00:38:54 --> Model Class Initialized
INFO - 2019-07-12 00:38:54 --> Model Class Initialized
INFO - 2019-07-12 00:38:54 --> Model Class Initialized
INFO - 2019-07-12 00:38:54 --> Model Class Initialized
INFO - 2019-07-12 00:38:54 --> Final output sent to browser
DEBUG - 2019-07-12 00:38:54 --> Total execution time: 0.5201
INFO - 2019-07-12 00:38:55 --> Helper loaded: language_helper
INFO - 2019-07-12 00:38:55 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:38:55 --> Model Class Initialized
INFO - 2019-07-12 00:38:55 --> Model Class Initialized
INFO - 2019-07-12 00:38:55 --> Model Class Initialized
INFO - 2019-07-12 00:38:55 --> Model Class Initialized
INFO - 2019-07-12 00:38:55 --> Helper loaded: form_helper
INFO - 2019-07-12 00:38:55 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:38:55 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:38:55 --> Model Class Initialized
INFO - 2019-07-12 00:38:55 --> Model Class Initialized
INFO - 2019-07-12 00:38:55 --> Final output sent to browser
DEBUG - 2019-07-12 00:38:55 --> Total execution time: 0.6272
INFO - 2019-07-12 00:38:56 --> Helper loaded: language_helper
INFO - 2019-07-12 00:38:56 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:38:56 --> Model Class Initialized
INFO - 2019-07-12 00:38:56 --> Model Class Initialized
INFO - 2019-07-12 00:38:56 --> Model Class Initialized
INFO - 2019-07-12 00:38:56 --> Model Class Initialized
INFO - 2019-07-12 00:38:56 --> Helper loaded: form_helper
INFO - 2019-07-12 00:38:56 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:38:56 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:38:56 --> Model Class Initialized
INFO - 2019-07-12 00:38:56 --> Model Class Initialized
INFO - 2019-07-12 00:38:56 --> Final output sent to browser
DEBUG - 2019-07-12 00:38:56 --> Total execution time: 0.5665
INFO - 2019-07-12 00:39:18 --> Helper loaded: language_helper
INFO - 2019-07-12 00:39:18 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:39:18 --> Model Class Initialized
INFO - 2019-07-12 00:39:18 --> Model Class Initialized
INFO - 2019-07-12 00:39:18 --> Model Class Initialized
INFO - 2019-07-12 00:39:18 --> Model Class Initialized
INFO - 2019-07-12 00:39:18 --> Model Class Initialized
INFO - 2019-07-12 00:39:18 --> Final output sent to browser
DEBUG - 2019-07-12 00:39:18 --> Total execution time: 0.5189
INFO - 2019-07-12 00:39:19 --> Helper loaded: language_helper
INFO - 2019-07-12 00:39:19 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:39:19 --> Model Class Initialized
INFO - 2019-07-12 00:39:19 --> Model Class Initialized
INFO - 2019-07-12 00:39:19 --> Model Class Initialized
INFO - 2019-07-12 00:39:19 --> Model Class Initialized
INFO - 2019-07-12 00:39:19 --> Helper loaded: form_helper
INFO - 2019-07-12 00:39:19 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:39:19 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:39:19 --> Model Class Initialized
INFO - 2019-07-12 00:39:19 --> Model Class Initialized
INFO - 2019-07-12 00:39:19 --> Final output sent to browser
DEBUG - 2019-07-12 00:39:19 --> Total execution time: 0.6812
INFO - 2019-07-12 00:39:21 --> Helper loaded: language_helper
INFO - 2019-07-12 00:39:21 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:39:21 --> Model Class Initialized
INFO - 2019-07-12 00:39:21 --> Model Class Initialized
INFO - 2019-07-12 00:39:21 --> Model Class Initialized
INFO - 2019-07-12 00:39:21 --> Model Class Initialized
INFO - 2019-07-12 00:39:21 --> Helper loaded: form_helper
INFO - 2019-07-12 00:39:21 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:39:21 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:39:21 --> Model Class Initialized
INFO - 2019-07-12 00:39:21 --> Model Class Initialized
INFO - 2019-07-12 00:39:21 --> Final output sent to browser
DEBUG - 2019-07-12 00:39:21 --> Total execution time: 0.5767
INFO - 2019-07-12 00:39:23 --> Helper loaded: language_helper
INFO - 2019-07-12 00:39:23 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:39:23 --> Model Class Initialized
INFO - 2019-07-12 00:39:23 --> Model Class Initialized
INFO - 2019-07-12 00:39:23 --> Model Class Initialized
INFO - 2019-07-12 00:39:23 --> Model Class Initialized
INFO - 2019-07-12 00:39:23 --> Helper loaded: form_helper
INFO - 2019-07-12 00:39:23 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:39:23 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:39:23 --> Model Class Initialized
INFO - 2019-07-12 00:39:23 --> Model Class Initialized
INFO - 2019-07-12 00:39:23 --> Final output sent to browser
DEBUG - 2019-07-12 00:39:23 --> Total execution time: 0.5648
INFO - 2019-07-12 00:39:42 --> Helper loaded: language_helper
INFO - 2019-07-12 00:39:42 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:39:42 --> Model Class Initialized
INFO - 2019-07-12 00:39:42 --> Model Class Initialized
INFO - 2019-07-12 00:39:42 --> Model Class Initialized
INFO - 2019-07-12 00:39:42 --> Model Class Initialized
INFO - 2019-07-12 00:39:42 --> Model Class Initialized
INFO - 2019-07-12 00:39:42 --> Final output sent to browser
DEBUG - 2019-07-12 00:39:42 --> Total execution time: 0.5643
INFO - 2019-07-12 00:39:43 --> Helper loaded: language_helper
INFO - 2019-07-12 00:39:43 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:39:43 --> Model Class Initialized
INFO - 2019-07-12 00:39:43 --> Model Class Initialized
INFO - 2019-07-12 00:39:43 --> Model Class Initialized
INFO - 2019-07-12 00:39:43 --> Model Class Initialized
INFO - 2019-07-12 00:39:43 --> Helper loaded: form_helper
INFO - 2019-07-12 00:39:43 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:39:43 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:39:43 --> Model Class Initialized
INFO - 2019-07-12 00:39:43 --> Model Class Initialized
INFO - 2019-07-12 00:39:43 --> Final output sent to browser
DEBUG - 2019-07-12 00:39:43 --> Total execution time: 0.7386
INFO - 2019-07-12 00:39:43 --> Helper loaded: language_helper
INFO - 2019-07-12 00:39:43 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:39:43 --> Model Class Initialized
INFO - 2019-07-12 00:39:43 --> Model Class Initialized
INFO - 2019-07-12 00:39:43 --> Model Class Initialized
INFO - 2019-07-12 00:39:43 --> Model Class Initialized
INFO - 2019-07-12 00:39:43 --> Helper loaded: form_helper
INFO - 2019-07-12 00:39:43 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:39:43 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:39:43 --> Model Class Initialized
INFO - 2019-07-12 00:39:43 --> Model Class Initialized
INFO - 2019-07-12 00:39:43 --> Final output sent to browser
DEBUG - 2019-07-12 00:39:43 --> Total execution time: 0.6802
INFO - 2019-07-12 00:39:45 --> Helper loaded: language_helper
INFO - 2019-07-12 00:39:45 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:39:45 --> Model Class Initialized
INFO - 2019-07-12 00:39:45 --> Model Class Initialized
INFO - 2019-07-12 00:39:45 --> Model Class Initialized
INFO - 2019-07-12 00:39:45 --> Model Class Initialized
INFO - 2019-07-12 00:39:45 --> Helper loaded: form_helper
INFO - 2019-07-12 00:39:45 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:39:45 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:39:45 --> Model Class Initialized
INFO - 2019-07-12 00:39:45 --> Model Class Initialized
INFO - 2019-07-12 00:39:45 --> Final output sent to browser
DEBUG - 2019-07-12 00:39:45 --> Total execution time: 0.5673
INFO - 2019-07-12 00:40:19 --> Helper loaded: language_helper
INFO - 2019-07-12 00:40:19 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:40:19 --> Model Class Initialized
INFO - 2019-07-12 00:40:19 --> Model Class Initialized
INFO - 2019-07-12 00:40:19 --> Model Class Initialized
INFO - 2019-07-12 00:40:19 --> Model Class Initialized
INFO - 2019-07-12 00:40:19 --> Model Class Initialized
INFO - 2019-07-12 00:40:19 --> Final output sent to browser
DEBUG - 2019-07-12 00:40:19 --> Total execution time: 0.6057
INFO - 2019-07-12 00:40:19 --> Helper loaded: language_helper
INFO - 2019-07-12 00:40:19 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:40:19 --> Model Class Initialized
INFO - 2019-07-12 00:40:19 --> Model Class Initialized
INFO - 2019-07-12 00:40:19 --> Model Class Initialized
INFO - 2019-07-12 00:40:19 --> Model Class Initialized
INFO - 2019-07-12 00:40:19 --> Helper loaded: form_helper
INFO - 2019-07-12 00:40:19 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:40:19 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:40:19 --> Model Class Initialized
INFO - 2019-07-12 00:40:19 --> Model Class Initialized
INFO - 2019-07-12 00:40:19 --> Final output sent to browser
DEBUG - 2019-07-12 00:40:19 --> Total execution time: 0.6039
INFO - 2019-07-12 00:40:20 --> Helper loaded: language_helper
INFO - 2019-07-12 00:40:20 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:40:20 --> Model Class Initialized
INFO - 2019-07-12 00:40:20 --> Model Class Initialized
INFO - 2019-07-12 00:40:20 --> Model Class Initialized
INFO - 2019-07-12 00:40:20 --> Model Class Initialized
INFO - 2019-07-12 00:40:20 --> Helper loaded: form_helper
INFO - 2019-07-12 00:40:20 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:40:20 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:40:20 --> Model Class Initialized
INFO - 2019-07-12 00:40:20 --> Model Class Initialized
INFO - 2019-07-12 00:40:20 --> Final output sent to browser
DEBUG - 2019-07-12 00:40:20 --> Total execution time: 0.5796
INFO - 2019-07-12 00:40:57 --> Helper loaded: language_helper
INFO - 2019-07-12 00:40:57 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:40:57 --> Model Class Initialized
INFO - 2019-07-12 00:40:57 --> Model Class Initialized
INFO - 2019-07-12 00:40:57 --> Model Class Initialized
INFO - 2019-07-12 00:40:57 --> Model Class Initialized
INFO - 2019-07-12 00:40:57 --> Helper loaded: form_helper
INFO - 2019-07-12 00:40:57 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:40:57 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:40:57 --> Model Class Initialized
INFO - 2019-07-12 00:40:57 --> Model Class Initialized
INFO - 2019-07-12 00:40:57 --> Final output sent to browser
DEBUG - 2019-07-12 00:40:57 --> Total execution time: 0.5807
INFO - 2019-07-12 00:40:58 --> Helper loaded: language_helper
INFO - 2019-07-12 00:40:58 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:40:58 --> Model Class Initialized
INFO - 2019-07-12 00:40:58 --> Model Class Initialized
INFO - 2019-07-12 00:40:58 --> Model Class Initialized
INFO - 2019-07-12 00:40:58 --> Model Class Initialized
INFO - 2019-07-12 00:40:58 --> Model Class Initialized
INFO - 2019-07-12 00:40:58 --> Final output sent to browser
DEBUG - 2019-07-12 00:40:58 --> Total execution time: 0.5117
INFO - 2019-07-12 00:40:58 --> Helper loaded: language_helper
INFO - 2019-07-12 00:40:58 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:40:58 --> Model Class Initialized
INFO - 2019-07-12 00:40:58 --> Model Class Initialized
INFO - 2019-07-12 00:40:58 --> Model Class Initialized
INFO - 2019-07-12 00:40:58 --> Model Class Initialized
INFO - 2019-07-12 00:40:58 --> Helper loaded: form_helper
INFO - 2019-07-12 00:40:58 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:40:58 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:40:58 --> Model Class Initialized
INFO - 2019-07-12 00:40:58 --> Model Class Initialized
INFO - 2019-07-12 00:40:58 --> Final output sent to browser
DEBUG - 2019-07-12 00:40:58 --> Total execution time: 0.5818
INFO - 2019-07-12 00:41:04 --> Helper loaded: language_helper
INFO - 2019-07-12 00:41:04 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:41:04 --> Model Class Initialized
INFO - 2019-07-12 00:41:04 --> Model Class Initialized
INFO - 2019-07-12 00:41:04 --> Model Class Initialized
INFO - 2019-07-12 00:41:04 --> Model Class Initialized
INFO - 2019-07-12 00:41:04 --> Helper loaded: language_helper
INFO - 2019-07-12 00:41:04 --> Model Class Initialized
INFO - 2019-07-12 00:41:04 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:41:04 --> Final output sent to browser
INFO - 2019-07-12 00:41:04 --> Model Class Initialized
DEBUG - 2019-07-12 00:41:04 --> Total execution time: 0.7538
INFO - 2019-07-12 00:41:04 --> Model Class Initialized
INFO - 2019-07-12 00:41:04 --> Model Class Initialized
INFO - 2019-07-12 00:41:04 --> Model Class Initialized
INFO - 2019-07-12 00:41:04 --> Helper loaded: form_helper
INFO - 2019-07-12 00:41:04 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:41:04 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:41:04 --> Model Class Initialized
INFO - 2019-07-12 00:41:04 --> Model Class Initialized
INFO - 2019-07-12 00:41:04 --> Final output sent to browser
DEBUG - 2019-07-12 00:41:04 --> Total execution time: 0.8493
INFO - 2019-07-12 00:41:05 --> Helper loaded: language_helper
INFO - 2019-07-12 00:41:05 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:41:05 --> Model Class Initialized
INFO - 2019-07-12 00:41:05 --> Model Class Initialized
INFO - 2019-07-12 00:41:05 --> Model Class Initialized
INFO - 2019-07-12 00:41:05 --> Model Class Initialized
INFO - 2019-07-12 00:41:05 --> Helper loaded: form_helper
INFO - 2019-07-12 00:41:05 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:41:05 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:41:05 --> Model Class Initialized
INFO - 2019-07-12 00:41:05 --> Model Class Initialized
INFO - 2019-07-12 00:41:05 --> Final output sent to browser
DEBUG - 2019-07-12 00:41:05 --> Total execution time: 0.5891
INFO - 2019-07-12 00:41:06 --> Helper loaded: language_helper
INFO - 2019-07-12 00:41:06 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:41:06 --> Model Class Initialized
INFO - 2019-07-12 00:41:06 --> Model Class Initialized
INFO - 2019-07-12 00:41:06 --> Model Class Initialized
INFO - 2019-07-12 00:41:06 --> Model Class Initialized
INFO - 2019-07-12 00:41:06 --> Helper loaded: form_helper
INFO - 2019-07-12 00:41:06 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:41:06 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:41:06 --> Model Class Initialized
INFO - 2019-07-12 00:41:06 --> Model Class Initialized
INFO - 2019-07-12 00:41:06 --> Final output sent to browser
DEBUG - 2019-07-12 00:41:06 --> Total execution time: 0.5877
INFO - 2019-07-12 00:41:19 --> Helper loaded: language_helper
INFO - 2019-07-12 00:41:19 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:41:19 --> Model Class Initialized
INFO - 2019-07-12 00:41:19 --> Model Class Initialized
INFO - 2019-07-12 00:41:19 --> Model Class Initialized
INFO - 2019-07-12 00:41:19 --> Model Class Initialized
INFO - 2019-07-12 00:41:19 --> Model Class Initialized
INFO - 2019-07-12 00:41:19 --> Final output sent to browser
DEBUG - 2019-07-12 00:41:19 --> Total execution time: 0.5669
INFO - 2019-07-12 00:41:20 --> Helper loaded: language_helper
INFO - 2019-07-12 00:41:20 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:41:20 --> Model Class Initialized
INFO - 2019-07-12 00:41:20 --> Model Class Initialized
INFO - 2019-07-12 00:41:20 --> Model Class Initialized
INFO - 2019-07-12 00:41:20 --> Helper loaded: language_helper
INFO - 2019-07-12 00:41:20 --> Model Class Initialized
INFO - 2019-07-12 00:41:20 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:41:20 --> Helper loaded: form_helper
INFO - 2019-07-12 00:41:20 --> Model Class Initialized
INFO - 2019-07-12 00:41:20 --> Form Validation Class Initialized
INFO - 2019-07-12 00:41:20 --> Model Class Initialized
DEBUG - 2019-07-12 00:41:20 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:41:20 --> Model Class Initialized
INFO - 2019-07-12 00:41:20 --> Model Class Initialized
INFO - 2019-07-12 00:41:20 --> Model Class Initialized
INFO - 2019-07-12 00:41:20 --> Model Class Initialized
INFO - 2019-07-12 00:41:20 --> Helper loaded: form_helper
INFO - 2019-07-12 00:41:20 --> Final output sent to browser
INFO - 2019-07-12 00:41:20 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:41:20 --> Total execution time: 0.8783
DEBUG - 2019-07-12 00:41:20 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:41:20 --> Model Class Initialized
INFO - 2019-07-12 00:41:20 --> Model Class Initialized
INFO - 2019-07-12 00:41:20 --> Final output sent to browser
DEBUG - 2019-07-12 00:41:20 --> Total execution time: 0.8738
INFO - 2019-07-12 00:41:21 --> Helper loaded: language_helper
INFO - 2019-07-12 00:41:21 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:41:21 --> Model Class Initialized
INFO - 2019-07-12 00:41:21 --> Model Class Initialized
INFO - 2019-07-12 00:41:21 --> Model Class Initialized
INFO - 2019-07-12 00:41:21 --> Model Class Initialized
INFO - 2019-07-12 00:41:21 --> Helper loaded: form_helper
INFO - 2019-07-12 00:41:22 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:41:22 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:41:22 --> Model Class Initialized
INFO - 2019-07-12 00:41:22 --> Model Class Initialized
INFO - 2019-07-12 00:41:22 --> Final output sent to browser
DEBUG - 2019-07-12 00:41:22 --> Total execution time: 0.5697
INFO - 2019-07-12 00:41:37 --> Helper loaded: language_helper
INFO - 2019-07-12 00:41:37 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:41:37 --> Model Class Initialized
INFO - 2019-07-12 00:41:37 --> Model Class Initialized
INFO - 2019-07-12 00:41:37 --> Model Class Initialized
INFO - 2019-07-12 00:41:37 --> Model Class Initialized
INFO - 2019-07-12 00:41:37 --> Model Class Initialized
INFO - 2019-07-12 00:41:37 --> Final output sent to browser
DEBUG - 2019-07-12 00:41:37 --> Total execution time: 0.5629
INFO - 2019-07-12 00:41:38 --> Helper loaded: language_helper
INFO - 2019-07-12 00:41:38 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:41:38 --> Model Class Initialized
INFO - 2019-07-12 00:41:38 --> Model Class Initialized
INFO - 2019-07-12 00:41:38 --> Model Class Initialized
INFO - 2019-07-12 00:41:38 --> Model Class Initialized
INFO - 2019-07-12 00:41:38 --> Helper loaded: form_helper
INFO - 2019-07-12 00:41:38 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:41:38 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:41:38 --> Model Class Initialized
INFO - 2019-07-12 00:41:38 --> Model Class Initialized
INFO - 2019-07-12 00:41:38 --> Final output sent to browser
DEBUG - 2019-07-12 00:41:38 --> Total execution time: 0.6599
INFO - 2019-07-12 00:41:39 --> Helper loaded: language_helper
INFO - 2019-07-12 00:41:39 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:41:39 --> Model Class Initialized
INFO - 2019-07-12 00:41:39 --> Model Class Initialized
INFO - 2019-07-12 00:41:39 --> Model Class Initialized
INFO - 2019-07-12 00:41:39 --> Model Class Initialized
INFO - 2019-07-12 00:41:39 --> Helper loaded: form_helper
INFO - 2019-07-12 00:41:39 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:41:39 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:41:39 --> Model Class Initialized
INFO - 2019-07-12 00:41:39 --> Model Class Initialized
INFO - 2019-07-12 00:41:39 --> Final output sent to browser
DEBUG - 2019-07-12 00:41:39 --> Total execution time: 0.6722
INFO - 2019-07-12 00:41:39 --> Helper loaded: language_helper
INFO - 2019-07-12 00:41:39 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:41:39 --> Model Class Initialized
INFO - 2019-07-12 00:41:39 --> Model Class Initialized
INFO - 2019-07-12 00:41:39 --> Model Class Initialized
INFO - 2019-07-12 00:41:39 --> Model Class Initialized
INFO - 2019-07-12 00:41:39 --> Helper loaded: form_helper
INFO - 2019-07-12 00:41:39 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:41:39 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:41:39 --> Model Class Initialized
INFO - 2019-07-12 00:41:39 --> Model Class Initialized
INFO - 2019-07-12 00:41:39 --> Final output sent to browser
DEBUG - 2019-07-12 00:41:39 --> Total execution time: 0.6648
INFO - 2019-07-12 00:41:52 --> Helper loaded: language_helper
INFO - 2019-07-12 00:41:52 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:41:52 --> Model Class Initialized
INFO - 2019-07-12 00:41:52 --> Model Class Initialized
INFO - 2019-07-12 00:41:52 --> Model Class Initialized
INFO - 2019-07-12 00:41:52 --> Model Class Initialized
INFO - 2019-07-12 00:41:52 --> Model Class Initialized
INFO - 2019-07-12 00:41:52 --> Final output sent to browser
DEBUG - 2019-07-12 00:41:52 --> Total execution time: 0.5401
INFO - 2019-07-12 00:41:53 --> Helper loaded: language_helper
INFO - 2019-07-12 00:41:53 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:41:53 --> Model Class Initialized
INFO - 2019-07-12 00:41:53 --> Model Class Initialized
INFO - 2019-07-12 00:41:53 --> Model Class Initialized
INFO - 2019-07-12 00:41:53 --> Model Class Initialized
INFO - 2019-07-12 00:41:53 --> Helper loaded: form_helper
INFO - 2019-07-12 00:41:53 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:41:53 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:41:53 --> Model Class Initialized
INFO - 2019-07-12 00:41:53 --> Model Class Initialized
INFO - 2019-07-12 00:41:53 --> Final output sent to browser
DEBUG - 2019-07-12 00:41:53 --> Total execution time: 0.5899
INFO - 2019-07-12 00:41:55 --> Helper loaded: language_helper
INFO - 2019-07-12 00:41:55 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:41:55 --> Model Class Initialized
INFO - 2019-07-12 00:41:55 --> Model Class Initialized
INFO - 2019-07-12 00:41:55 --> Model Class Initialized
INFO - 2019-07-12 00:41:55 --> Model Class Initialized
INFO - 2019-07-12 00:41:55 --> Helper loaded: form_helper
INFO - 2019-07-12 00:41:55 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:41:55 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:41:55 --> Model Class Initialized
INFO - 2019-07-12 00:41:55 --> Model Class Initialized
INFO - 2019-07-12 00:41:55 --> Final output sent to browser
DEBUG - 2019-07-12 00:41:55 --> Total execution time: 0.5774
INFO - 2019-07-12 00:41:58 --> Helper loaded: language_helper
INFO - 2019-07-12 00:41:58 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:41:58 --> Model Class Initialized
INFO - 2019-07-12 00:41:58 --> Model Class Initialized
INFO - 2019-07-12 00:41:58 --> Model Class Initialized
INFO - 2019-07-12 00:41:58 --> Model Class Initialized
INFO - 2019-07-12 00:41:58 --> Model Class Initialized
INFO - 2019-07-12 00:41:58 --> Final output sent to browser
DEBUG - 2019-07-12 00:41:58 --> Total execution time: 0.5243
INFO - 2019-07-12 00:41:59 --> Helper loaded: language_helper
INFO - 2019-07-12 00:41:59 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:41:59 --> Model Class Initialized
INFO - 2019-07-12 00:41:59 --> Model Class Initialized
INFO - 2019-07-12 00:41:59 --> Model Class Initialized
INFO - 2019-07-12 00:41:59 --> Model Class Initialized
INFO - 2019-07-12 00:41:59 --> Helper loaded: form_helper
INFO - 2019-07-12 00:41:59 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:41:59 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:41:59 --> Model Class Initialized
INFO - 2019-07-12 00:41:59 --> Model Class Initialized
INFO - 2019-07-12 00:41:59 --> Final output sent to browser
INFO - 2019-07-12 00:41:59 --> Helper loaded: language_helper
DEBUG - 2019-07-12 00:41:59 --> Total execution time: 0.7629
INFO - 2019-07-12 00:41:59 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:41:59 --> Model Class Initialized
INFO - 2019-07-12 00:41:59 --> Model Class Initialized
INFO - 2019-07-12 00:41:59 --> Model Class Initialized
INFO - 2019-07-12 00:41:59 --> Model Class Initialized
INFO - 2019-07-12 00:41:59 --> Helper loaded: form_helper
INFO - 2019-07-12 00:41:59 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:41:59 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:41:59 --> Model Class Initialized
INFO - 2019-07-12 00:41:59 --> Model Class Initialized
INFO - 2019-07-12 00:41:59 --> Final output sent to browser
DEBUG - 2019-07-12 00:41:59 --> Total execution time: 0.7172
INFO - 2019-07-12 00:42:00 --> Helper loaded: language_helper
INFO - 2019-07-12 00:42:00 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:42:00 --> Model Class Initialized
INFO - 2019-07-12 00:42:00 --> Model Class Initialized
INFO - 2019-07-12 00:42:00 --> Model Class Initialized
INFO - 2019-07-12 00:42:00 --> Model Class Initialized
INFO - 2019-07-12 00:42:00 --> Helper loaded: form_helper
INFO - 2019-07-12 00:42:00 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:42:00 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:42:00 --> Model Class Initialized
INFO - 2019-07-12 00:42:00 --> Model Class Initialized
INFO - 2019-07-12 00:42:00 --> Final output sent to browser
DEBUG - 2019-07-12 00:42:00 --> Total execution time: 0.5816
INFO - 2019-07-12 00:42:22 --> Helper loaded: language_helper
INFO - 2019-07-12 00:42:22 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:42:22 --> Model Class Initialized
INFO - 2019-07-12 00:42:22 --> Model Class Initialized
INFO - 2019-07-12 00:42:22 --> Model Class Initialized
INFO - 2019-07-12 00:42:23 --> Model Class Initialized
INFO - 2019-07-12 00:42:23 --> Model Class Initialized
INFO - 2019-07-12 00:42:23 --> Final output sent to browser
DEBUG - 2019-07-12 00:42:23 --> Total execution time: 0.5711
INFO - 2019-07-12 00:42:23 --> Helper loaded: language_helper
INFO - 2019-07-12 00:42:23 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:42:23 --> Model Class Initialized
INFO - 2019-07-12 00:42:23 --> Model Class Initialized
INFO - 2019-07-12 00:42:23 --> Model Class Initialized
INFO - 2019-07-12 00:42:23 --> Model Class Initialized
INFO - 2019-07-12 00:42:23 --> Helper loaded: form_helper
INFO - 2019-07-12 00:42:23 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:42:23 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:42:23 --> Model Class Initialized
INFO - 2019-07-12 00:42:23 --> Model Class Initialized
INFO - 2019-07-12 00:42:23 --> Final output sent to browser
DEBUG - 2019-07-12 00:42:23 --> Total execution time: 0.6079
INFO - 2019-07-12 00:42:24 --> Helper loaded: language_helper
INFO - 2019-07-12 00:42:24 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:42:24 --> Model Class Initialized
INFO - 2019-07-12 00:42:24 --> Model Class Initialized
INFO - 2019-07-12 00:42:24 --> Model Class Initialized
INFO - 2019-07-12 00:42:24 --> Model Class Initialized
INFO - 2019-07-12 00:42:24 --> Helper loaded: form_helper
INFO - 2019-07-12 00:42:24 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:42:24 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:42:24 --> Model Class Initialized
INFO - 2019-07-12 00:42:24 --> Model Class Initialized
INFO - 2019-07-12 00:42:24 --> Final output sent to browser
DEBUG - 2019-07-12 00:42:24 --> Total execution time: 0.5820
INFO - 2019-07-12 00:42:24 --> Helper loaded: language_helper
INFO - 2019-07-12 00:42:24 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:42:24 --> Model Class Initialized
INFO - 2019-07-12 00:42:24 --> Model Class Initialized
INFO - 2019-07-12 00:42:24 --> Model Class Initialized
INFO - 2019-07-12 00:42:25 --> Model Class Initialized
INFO - 2019-07-12 00:42:25 --> Helper loaded: form_helper
INFO - 2019-07-12 00:42:25 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:42:25 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:42:25 --> Model Class Initialized
INFO - 2019-07-12 00:42:25 --> Model Class Initialized
INFO - 2019-07-12 00:42:25 --> Final output sent to browser
DEBUG - 2019-07-12 00:42:25 --> Total execution time: 0.5733
INFO - 2019-07-12 00:42:43 --> Helper loaded: language_helper
INFO - 2019-07-12 00:42:43 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:42:43 --> Model Class Initialized
INFO - 2019-07-12 00:42:43 --> Model Class Initialized
INFO - 2019-07-12 00:42:43 --> Model Class Initialized
INFO - 2019-07-12 00:42:43 --> Model Class Initialized
INFO - 2019-07-12 00:42:43 --> Helper loaded: form_helper
INFO - 2019-07-12 00:42:43 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:42:43 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:42:43 --> Model Class Initialized
INFO - 2019-07-12 00:42:43 --> Model Class Initialized
INFO - 2019-07-12 00:42:43 --> Final output sent to browser
DEBUG - 2019-07-12 00:42:43 --> Total execution time: 0.5784
INFO - 2019-07-12 00:42:44 --> Helper loaded: language_helper
INFO - 2019-07-12 00:42:44 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:42:44 --> Model Class Initialized
INFO - 2019-07-12 00:42:44 --> Model Class Initialized
INFO - 2019-07-12 00:42:44 --> Model Class Initialized
INFO - 2019-07-12 00:42:44 --> Model Class Initialized
INFO - 2019-07-12 00:42:44 --> Model Class Initialized
INFO - 2019-07-12 00:42:44 --> Final output sent to browser
DEBUG - 2019-07-12 00:42:44 --> Total execution time: 0.5330
INFO - 2019-07-12 00:42:44 --> Helper loaded: language_helper
INFO - 2019-07-12 00:42:44 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:42:44 --> Model Class Initialized
INFO - 2019-07-12 00:42:44 --> Model Class Initialized
INFO - 2019-07-12 00:42:44 --> Model Class Initialized
INFO - 2019-07-12 00:42:44 --> Model Class Initialized
INFO - 2019-07-12 00:42:44 --> Helper loaded: form_helper
INFO - 2019-07-12 00:42:44 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:42:44 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:42:44 --> Model Class Initialized
INFO - 2019-07-12 00:42:44 --> Model Class Initialized
INFO - 2019-07-12 00:42:44 --> Final output sent to browser
DEBUG - 2019-07-12 00:42:44 --> Total execution time: 0.5873
INFO - 2019-07-12 00:43:05 --> Helper loaded: language_helper
INFO - 2019-07-12 00:43:05 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:43:05 --> Model Class Initialized
INFO - 2019-07-12 00:43:05 --> Model Class Initialized
INFO - 2019-07-12 00:43:05 --> Model Class Initialized
INFO - 2019-07-12 00:43:05 --> Model Class Initialized
INFO - 2019-07-12 00:43:05 --> Helper loaded: language_helper
INFO - 2019-07-12 00:43:05 --> Model Class Initialized
INFO - 2019-07-12 00:43:05 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:43:05 --> Final output sent to browser
INFO - 2019-07-12 00:43:05 --> Model Class Initialized
DEBUG - 2019-07-12 00:43:05 --> Total execution time: 0.7594
INFO - 2019-07-12 00:43:05 --> Model Class Initialized
INFO - 2019-07-12 00:43:05 --> Model Class Initialized
INFO - 2019-07-12 00:43:05 --> Model Class Initialized
INFO - 2019-07-12 00:43:05 --> Helper loaded: form_helper
INFO - 2019-07-12 00:43:05 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:43:05 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:43:05 --> Model Class Initialized
INFO - 2019-07-12 00:43:05 --> Model Class Initialized
INFO - 2019-07-12 00:43:05 --> Final output sent to browser
DEBUG - 2019-07-12 00:43:05 --> Total execution time: 0.8630
INFO - 2019-07-12 00:43:05 --> Helper loaded: language_helper
INFO - 2019-07-12 00:43:05 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:43:06 --> Model Class Initialized
INFO - 2019-07-12 00:43:06 --> Model Class Initialized
INFO - 2019-07-12 00:43:06 --> Model Class Initialized
INFO - 2019-07-12 00:43:06 --> Model Class Initialized
INFO - 2019-07-12 00:43:06 --> Helper loaded: form_helper
INFO - 2019-07-12 00:43:06 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:43:06 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:43:06 --> Model Class Initialized
INFO - 2019-07-12 00:43:06 --> Model Class Initialized
INFO - 2019-07-12 00:43:06 --> Final output sent to browser
DEBUG - 2019-07-12 00:43:06 --> Total execution time: 0.5953
INFO - 2019-07-12 00:43:07 --> Helper loaded: language_helper
INFO - 2019-07-12 00:43:07 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:43:07 --> Model Class Initialized
INFO - 2019-07-12 00:43:07 --> Model Class Initialized
INFO - 2019-07-12 00:43:07 --> Model Class Initialized
INFO - 2019-07-12 00:43:07 --> Model Class Initialized
INFO - 2019-07-12 00:43:07 --> Helper loaded: form_helper
INFO - 2019-07-12 00:43:07 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:43:07 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:43:07 --> Model Class Initialized
INFO - 2019-07-12 00:43:07 --> Model Class Initialized
INFO - 2019-07-12 00:43:07 --> Final output sent to browser
DEBUG - 2019-07-12 00:43:07 --> Total execution time: 0.5842
INFO - 2019-07-12 00:44:41 --> Helper loaded: language_helper
INFO - 2019-07-12 00:44:41 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:44:41 --> Model Class Initialized
INFO - 2019-07-12 00:44:41 --> Model Class Initialized
INFO - 2019-07-12 00:44:41 --> Model Class Initialized
INFO - 2019-07-12 00:44:41 --> Model Class Initialized
INFO - 2019-07-12 00:44:41 --> Model Class Initialized
INFO - 2019-07-12 00:44:41 --> Final output sent to browser
DEBUG - 2019-07-12 00:44:41 --> Total execution time: 0.5829
INFO - 2019-07-12 00:44:42 --> Helper loaded: language_helper
INFO - 2019-07-12 00:44:42 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:44:42 --> Model Class Initialized
INFO - 2019-07-12 00:44:42 --> Model Class Initialized
INFO - 2019-07-12 00:44:42 --> Model Class Initialized
INFO - 2019-07-12 00:44:42 --> Model Class Initialized
INFO - 2019-07-12 00:44:42 --> Helper loaded: form_helper
INFO - 2019-07-12 00:44:42 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:44:42 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:44:42 --> Model Class Initialized
INFO - 2019-07-12 00:44:42 --> Model Class Initialized
INFO - 2019-07-12 00:44:42 --> Final output sent to browser
DEBUG - 2019-07-12 00:44:42 --> Total execution time: 0.7265
INFO - 2019-07-12 00:44:42 --> Helper loaded: language_helper
INFO - 2019-07-12 00:44:42 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:44:42 --> Model Class Initialized
INFO - 2019-07-12 00:44:42 --> Model Class Initialized
INFO - 2019-07-12 00:44:42 --> Model Class Initialized
INFO - 2019-07-12 00:44:42 --> Model Class Initialized
INFO - 2019-07-12 00:44:42 --> Helper loaded: form_helper
INFO - 2019-07-12 00:44:42 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:44:42 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:44:42 --> Model Class Initialized
INFO - 2019-07-12 00:44:42 --> Model Class Initialized
INFO - 2019-07-12 00:44:42 --> Final output sent to browser
DEBUG - 2019-07-12 00:44:42 --> Total execution time: 0.7130
INFO - 2019-07-12 00:45:19 --> Helper loaded: language_helper
INFO - 2019-07-12 00:45:19 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:45:19 --> Model Class Initialized
INFO - 2019-07-12 00:45:19 --> Model Class Initialized
INFO - 2019-07-12 00:45:19 --> Model Class Initialized
INFO - 2019-07-12 00:45:19 --> Model Class Initialized
INFO - 2019-07-12 00:45:19 --> Helper loaded: form_helper
INFO - 2019-07-12 00:45:19 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:45:19 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:45:19 --> Model Class Initialized
INFO - 2019-07-12 00:45:19 --> Model Class Initialized
INFO - 2019-07-12 00:45:19 --> Final output sent to browser
DEBUG - 2019-07-12 00:45:19 --> Total execution time: 0.6016
INFO - 2019-07-12 00:47:44 --> Helper loaded: language_helper
INFO - 2019-07-12 00:47:44 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:47:44 --> Model Class Initialized
INFO - 2019-07-12 00:47:44 --> Model Class Initialized
INFO - 2019-07-12 00:47:44 --> Model Class Initialized
INFO - 2019-07-12 00:47:44 --> Model Class Initialized
INFO - 2019-07-12 00:47:44 --> Model Class Initialized
INFO - 2019-07-12 00:47:44 --> Final output sent to browser
DEBUG - 2019-07-12 00:47:44 --> Total execution time: 0.5487
INFO - 2019-07-12 00:47:45 --> Helper loaded: language_helper
INFO - 2019-07-12 00:47:45 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:47:45 --> Model Class Initialized
INFO - 2019-07-12 00:47:45 --> Model Class Initialized
INFO - 2019-07-12 00:47:45 --> Model Class Initialized
INFO - 2019-07-12 00:47:45 --> Model Class Initialized
INFO - 2019-07-12 00:47:45 --> Helper loaded: form_helper
INFO - 2019-07-12 00:47:45 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:47:45 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:47:45 --> Model Class Initialized
INFO - 2019-07-12 00:47:45 --> Model Class Initialized
INFO - 2019-07-12 00:47:45 --> Final output sent to browser
DEBUG - 2019-07-12 00:47:45 --> Total execution time: 0.6183
INFO - 2019-07-12 00:47:47 --> Helper loaded: language_helper
INFO - 2019-07-12 00:47:47 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:47:47 --> Model Class Initialized
INFO - 2019-07-12 00:47:47 --> Model Class Initialized
INFO - 2019-07-12 00:47:47 --> Model Class Initialized
INFO - 2019-07-12 00:47:47 --> Model Class Initialized
INFO - 2019-07-12 00:47:47 --> Helper loaded: form_helper
INFO - 2019-07-12 00:47:47 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:47:47 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:47:47 --> Model Class Initialized
INFO - 2019-07-12 00:47:47 --> Model Class Initialized
INFO - 2019-07-12 00:47:47 --> Final output sent to browser
DEBUG - 2019-07-12 00:47:47 --> Total execution time: 0.5914
INFO - 2019-07-12 00:48:18 --> Helper loaded: language_helper
INFO - 2019-07-12 00:48:18 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:48:18 --> Model Class Initialized
INFO - 2019-07-12 00:48:18 --> Model Class Initialized
INFO - 2019-07-12 00:48:18 --> Model Class Initialized
INFO - 2019-07-12 00:48:18 --> Model Class Initialized
INFO - 2019-07-12 00:48:18 --> Helper loaded: form_helper
INFO - 2019-07-12 00:48:18 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:48:18 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:48:18 --> Model Class Initialized
INFO - 2019-07-12 00:48:18 --> Model Class Initialized
INFO - 2019-07-12 00:48:18 --> Final output sent to browser
DEBUG - 2019-07-12 00:48:18 --> Total execution time: 0.5954
INFO - 2019-07-12 00:49:14 --> Helper loaded: language_helper
INFO - 2019-07-12 00:49:14 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:49:14 --> Model Class Initialized
INFO - 2019-07-12 00:49:14 --> Model Class Initialized
INFO - 2019-07-12 00:49:14 --> Model Class Initialized
INFO - 2019-07-12 00:49:14 --> Model Class Initialized
INFO - 2019-07-12 00:49:15 --> Model Class Initialized
INFO - 2019-07-12 00:49:15 --> Final output sent to browser
DEBUG - 2019-07-12 00:49:15 --> Total execution time: 0.6454
INFO - 2019-07-12 00:49:15 --> Helper loaded: language_helper
INFO - 2019-07-12 00:49:15 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:49:15 --> Model Class Initialized
INFO - 2019-07-12 00:49:15 --> Model Class Initialized
INFO - 2019-07-12 00:49:15 --> Model Class Initialized
INFO - 2019-07-12 00:49:15 --> Model Class Initialized
INFO - 2019-07-12 00:49:15 --> Helper loaded: form_helper
INFO - 2019-07-12 00:49:15 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:49:15 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:49:15 --> Model Class Initialized
INFO - 2019-07-12 00:49:15 --> Model Class Initialized
INFO - 2019-07-12 00:49:15 --> Final output sent to browser
DEBUG - 2019-07-12 00:49:15 --> Total execution time: 0.8239
INFO - 2019-07-12 00:49:15 --> Helper loaded: language_helper
INFO - 2019-07-12 00:49:15 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:49:15 --> Model Class Initialized
INFO - 2019-07-12 00:49:15 --> Model Class Initialized
INFO - 2019-07-12 00:49:15 --> Model Class Initialized
INFO - 2019-07-12 00:49:15 --> Model Class Initialized
INFO - 2019-07-12 00:49:15 --> Helper loaded: form_helper
INFO - 2019-07-12 00:49:15 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:49:15 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:49:15 --> Model Class Initialized
INFO - 2019-07-12 00:49:15 --> Model Class Initialized
INFO - 2019-07-12 00:49:15 --> Final output sent to browser
DEBUG - 2019-07-12 00:49:15 --> Total execution time: 0.7610
INFO - 2019-07-12 00:49:17 --> Helper loaded: language_helper
INFO - 2019-07-12 00:49:17 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:49:17 --> Model Class Initialized
INFO - 2019-07-12 00:49:18 --> Model Class Initialized
INFO - 2019-07-12 00:49:18 --> Model Class Initialized
INFO - 2019-07-12 00:49:18 --> Model Class Initialized
INFO - 2019-07-12 00:49:18 --> Model Class Initialized
INFO - 2019-07-12 00:49:18 --> Final output sent to browser
DEBUG - 2019-07-12 00:49:18 --> Total execution time: 0.6763
INFO - 2019-07-12 00:49:18 --> Helper loaded: language_helper
INFO - 2019-07-12 00:49:18 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:49:18 --> Model Class Initialized
INFO - 2019-07-12 00:49:18 --> Model Class Initialized
INFO - 2019-07-12 00:49:18 --> Model Class Initialized
INFO - 2019-07-12 00:49:18 --> Model Class Initialized
INFO - 2019-07-12 00:49:18 --> Helper loaded: form_helper
INFO - 2019-07-12 00:49:18 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:49:18 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:49:18 --> Model Class Initialized
INFO - 2019-07-12 00:49:18 --> Model Class Initialized
INFO - 2019-07-12 00:49:18 --> Final output sent to browser
DEBUG - 2019-07-12 00:49:18 --> Total execution time: 0.6570
INFO - 2019-07-12 00:49:19 --> Helper loaded: language_helper
INFO - 2019-07-12 00:49:19 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:49:19 --> Model Class Initialized
INFO - 2019-07-12 00:49:19 --> Model Class Initialized
INFO - 2019-07-12 00:49:19 --> Model Class Initialized
INFO - 2019-07-12 00:49:19 --> Model Class Initialized
INFO - 2019-07-12 00:49:19 --> Helper loaded: form_helper
INFO - 2019-07-12 00:49:19 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:49:19 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:49:19 --> Model Class Initialized
INFO - 2019-07-12 00:49:19 --> Model Class Initialized
INFO - 2019-07-12 00:49:19 --> Final output sent to browser
DEBUG - 2019-07-12 00:49:19 --> Total execution time: 0.6417
INFO - 2019-07-12 00:49:22 --> Helper loaded: language_helper
INFO - 2019-07-12 00:49:22 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:49:22 --> Model Class Initialized
INFO - 2019-07-12 00:49:22 --> Model Class Initialized
INFO - 2019-07-12 00:49:22 --> Model Class Initialized
INFO - 2019-07-12 00:49:22 --> Model Class Initialized
INFO - 2019-07-12 00:49:22 --> Helper loaded: form_helper
INFO - 2019-07-12 00:49:22 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:49:22 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:49:22 --> Model Class Initialized
INFO - 2019-07-12 00:49:22 --> Model Class Initialized
INFO - 2019-07-12 00:49:22 --> Final output sent to browser
DEBUG - 2019-07-12 00:49:22 --> Total execution time: 0.6323
INFO - 2019-07-12 00:49:28 --> Helper loaded: language_helper
INFO - 2019-07-12 00:49:28 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:49:28 --> Model Class Initialized
INFO - 2019-07-12 00:49:28 --> Model Class Initialized
INFO - 2019-07-12 00:49:28 --> Model Class Initialized
INFO - 2019-07-12 00:49:28 --> Model Class Initialized
INFO - 2019-07-12 00:49:28 --> Helper loaded: form_helper
INFO - 2019-07-12 00:49:28 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:49:28 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:49:28 --> Model Class Initialized
INFO - 2019-07-12 00:49:29 --> Model Class Initialized
INFO - 2019-07-12 00:49:29 --> Final output sent to browser
DEBUG - 2019-07-12 00:49:29 --> Total execution time: 0.6509
INFO - 2019-07-12 00:49:53 --> Helper loaded: language_helper
INFO - 2019-07-12 00:49:53 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:49:54 --> Model Class Initialized
INFO - 2019-07-12 00:49:54 --> Model Class Initialized
INFO - 2019-07-12 00:49:54 --> Model Class Initialized
INFO - 2019-07-12 00:49:54 --> Model Class Initialized
INFO - 2019-07-12 00:49:54 --> Model Class Initialized
INFO - 2019-07-12 00:49:54 --> Final output sent to browser
DEBUG - 2019-07-12 00:49:54 --> Total execution time: 0.5591
INFO - 2019-07-12 00:49:54 --> Helper loaded: language_helper
INFO - 2019-07-12 00:49:54 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:49:54 --> Model Class Initialized
INFO - 2019-07-12 00:49:54 --> Model Class Initialized
INFO - 2019-07-12 00:49:54 --> Model Class Initialized
INFO - 2019-07-12 00:49:54 --> Model Class Initialized
INFO - 2019-07-12 00:49:54 --> Helper loaded: form_helper
INFO - 2019-07-12 00:49:54 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:49:54 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:49:54 --> Model Class Initialized
INFO - 2019-07-12 00:49:54 --> Model Class Initialized
INFO - 2019-07-12 00:49:54 --> Final output sent to browser
DEBUG - 2019-07-12 00:49:54 --> Total execution time: 0.6691
INFO - 2019-07-12 00:49:56 --> Helper loaded: language_helper
INFO - 2019-07-12 00:49:56 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:49:56 --> Model Class Initialized
INFO - 2019-07-12 00:49:56 --> Model Class Initialized
INFO - 2019-07-12 00:49:56 --> Model Class Initialized
INFO - 2019-07-12 00:49:56 --> Model Class Initialized
INFO - 2019-07-12 00:49:56 --> Helper loaded: form_helper
INFO - 2019-07-12 00:49:56 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:49:56 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:49:56 --> Model Class Initialized
INFO - 2019-07-12 00:49:56 --> Model Class Initialized
INFO - 2019-07-12 00:49:56 --> Final output sent to browser
DEBUG - 2019-07-12 00:49:56 --> Total execution time: 0.6096
INFO - 2019-07-12 00:50:24 --> Helper loaded: language_helper
INFO - 2019-07-12 00:50:24 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:50:24 --> Model Class Initialized
INFO - 2019-07-12 00:50:24 --> Model Class Initialized
INFO - 2019-07-12 00:50:24 --> Model Class Initialized
INFO - 2019-07-12 00:50:24 --> Helper loaded: language_helper
INFO - 2019-07-12 00:50:24 --> Model Class Initialized
INFO - 2019-07-12 00:50:24 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:50:24 --> Model Class Initialized
INFO - 2019-07-12 00:50:24 --> Model Class Initialized
INFO - 2019-07-12 00:50:24 --> Final output sent to browser
INFO - 2019-07-12 00:50:24 --> Model Class Initialized
DEBUG - 2019-07-12 00:50:24 --> Total execution time: 0.8701
INFO - 2019-07-12 00:50:24 --> Model Class Initialized
INFO - 2019-07-12 00:50:24 --> Model Class Initialized
INFO - 2019-07-12 00:50:24 --> Helper loaded: form_helper
INFO - 2019-07-12 00:50:24 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:50:24 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:50:24 --> Model Class Initialized
INFO - 2019-07-12 00:50:24 --> Model Class Initialized
INFO - 2019-07-12 00:50:24 --> Final output sent to browser
DEBUG - 2019-07-12 00:50:24 --> Total execution time: 0.9314
INFO - 2019-07-12 00:50:25 --> Helper loaded: language_helper
INFO - 2019-07-12 00:50:25 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:50:25 --> Model Class Initialized
INFO - 2019-07-12 00:50:25 --> Model Class Initialized
INFO - 2019-07-12 00:50:25 --> Model Class Initialized
INFO - 2019-07-12 00:50:25 --> Model Class Initialized
INFO - 2019-07-12 00:50:25 --> Helper loaded: form_helper
INFO - 2019-07-12 00:50:25 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:50:25 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:50:25 --> Model Class Initialized
INFO - 2019-07-12 00:50:25 --> Model Class Initialized
INFO - 2019-07-12 00:50:25 --> Final output sent to browser
DEBUG - 2019-07-12 00:50:25 --> Total execution time: 0.6594
INFO - 2019-07-12 00:50:39 --> Helper loaded: language_helper
INFO - 2019-07-12 00:50:39 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:50:39 --> Model Class Initialized
INFO - 2019-07-12 00:50:39 --> Model Class Initialized
INFO - 2019-07-12 00:50:39 --> Model Class Initialized
INFO - 2019-07-12 00:50:39 --> Model Class Initialized
INFO - 2019-07-12 00:50:39 --> Model Class Initialized
INFO - 2019-07-12 00:50:39 --> Final output sent to browser
DEBUG - 2019-07-12 00:50:39 --> Total execution time: 0.6150
INFO - 2019-07-12 00:50:40 --> Helper loaded: language_helper
INFO - 2019-07-12 00:50:40 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:50:40 --> Model Class Initialized
INFO - 2019-07-12 00:50:40 --> Model Class Initialized
INFO - 2019-07-12 00:50:40 --> Model Class Initialized
INFO - 2019-07-12 00:50:40 --> Model Class Initialized
INFO - 2019-07-12 00:50:40 --> Helper loaded: form_helper
INFO - 2019-07-12 00:50:40 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:50:40 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:50:40 --> Model Class Initialized
INFO - 2019-07-12 00:50:40 --> Model Class Initialized
INFO - 2019-07-12 00:50:40 --> Final output sent to browser
DEBUG - 2019-07-12 00:50:40 --> Total execution time: 0.7580
INFO - 2019-07-12 00:50:40 --> Helper loaded: language_helper
INFO - 2019-07-12 00:50:40 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:50:40 --> Model Class Initialized
INFO - 2019-07-12 00:50:40 --> Model Class Initialized
INFO - 2019-07-12 00:50:40 --> Model Class Initialized
INFO - 2019-07-12 00:50:40 --> Model Class Initialized
INFO - 2019-07-12 00:50:40 --> Helper loaded: form_helper
INFO - 2019-07-12 00:50:40 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:50:40 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:50:40 --> Model Class Initialized
INFO - 2019-07-12 00:50:40 --> Model Class Initialized
INFO - 2019-07-12 00:50:40 --> Final output sent to browser
DEBUG - 2019-07-12 00:50:40 --> Total execution time: 0.7460
INFO - 2019-07-12 00:50:41 --> Helper loaded: language_helper
INFO - 2019-07-12 00:50:41 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:50:41 --> Model Class Initialized
INFO - 2019-07-12 00:50:41 --> Model Class Initialized
INFO - 2019-07-12 00:50:41 --> Model Class Initialized
INFO - 2019-07-12 00:50:41 --> Model Class Initialized
INFO - 2019-07-12 00:50:41 --> Helper loaded: form_helper
INFO - 2019-07-12 00:50:41 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:50:41 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:50:41 --> Model Class Initialized
INFO - 2019-07-12 00:50:41 --> Model Class Initialized
INFO - 2019-07-12 00:50:41 --> Final output sent to browser
DEBUG - 2019-07-12 00:50:41 --> Total execution time: 0.6105
INFO - 2019-07-12 00:50:43 --> Helper loaded: language_helper
INFO - 2019-07-12 00:50:43 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:50:43 --> Model Class Initialized
INFO - 2019-07-12 00:50:43 --> Model Class Initialized
INFO - 2019-07-12 00:50:43 --> Model Class Initialized
INFO - 2019-07-12 00:50:43 --> Model Class Initialized
INFO - 2019-07-12 00:50:43 --> Helper loaded: form_helper
INFO - 2019-07-12 00:50:43 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:50:43 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:50:43 --> Model Class Initialized
INFO - 2019-07-12 00:50:43 --> Model Class Initialized
INFO - 2019-07-12 00:50:43 --> Final output sent to browser
DEBUG - 2019-07-12 00:50:43 --> Total execution time: 0.6128
INFO - 2019-07-12 00:50:46 --> Helper loaded: language_helper
INFO - 2019-07-12 00:50:46 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:50:46 --> Model Class Initialized
INFO - 2019-07-12 00:50:46 --> Model Class Initialized
INFO - 2019-07-12 00:50:46 --> Model Class Initialized
INFO - 2019-07-12 00:50:46 --> Model Class Initialized
INFO - 2019-07-12 00:50:46 --> Helper loaded: form_helper
INFO - 2019-07-12 00:50:46 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:50:46 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:50:46 --> Model Class Initialized
INFO - 2019-07-12 00:50:46 --> Model Class Initialized
INFO - 2019-07-12 00:50:46 --> Final output sent to browser
DEBUG - 2019-07-12 00:50:46 --> Total execution time: 0.6904
INFO - 2019-07-12 00:50:47 --> Helper loaded: language_helper
INFO - 2019-07-12 00:50:47 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:50:47 --> Model Class Initialized
INFO - 2019-07-12 00:50:47 --> Model Class Initialized
INFO - 2019-07-12 00:50:47 --> Model Class Initialized
INFO - 2019-07-12 00:50:47 --> Model Class Initialized
INFO - 2019-07-12 00:50:47 --> Helper loaded: form_helper
INFO - 2019-07-12 00:50:47 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:50:47 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:50:47 --> Model Class Initialized
INFO - 2019-07-12 00:50:47 --> Model Class Initialized
INFO - 2019-07-12 00:50:47 --> Final output sent to browser
DEBUG - 2019-07-12 00:50:47 --> Total execution time: 0.6403
INFO - 2019-07-12 00:50:48 --> Helper loaded: language_helper
INFO - 2019-07-12 00:50:48 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:50:48 --> Model Class Initialized
INFO - 2019-07-12 00:50:48 --> Model Class Initialized
INFO - 2019-07-12 00:50:48 --> Model Class Initialized
INFO - 2019-07-12 00:50:48 --> Model Class Initialized
INFO - 2019-07-12 00:50:48 --> Helper loaded: form_helper
INFO - 2019-07-12 00:50:48 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:50:48 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:50:48 --> Model Class Initialized
INFO - 2019-07-12 00:50:48 --> Model Class Initialized
INFO - 2019-07-12 00:50:48 --> Final output sent to browser
DEBUG - 2019-07-12 00:50:48 --> Total execution time: 0.6372
INFO - 2019-07-12 00:50:50 --> Helper loaded: language_helper
INFO - 2019-07-12 00:50:50 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:50:50 --> Model Class Initialized
INFO - 2019-07-12 00:50:50 --> Model Class Initialized
INFO - 2019-07-12 00:50:50 --> Model Class Initialized
INFO - 2019-07-12 00:50:50 --> Model Class Initialized
INFO - 2019-07-12 00:50:50 --> Helper loaded: form_helper
INFO - 2019-07-12 00:50:50 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:50:50 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:50:50 --> Model Class Initialized
INFO - 2019-07-12 00:50:50 --> Model Class Initialized
INFO - 2019-07-12 00:50:50 --> Final output sent to browser
DEBUG - 2019-07-12 00:50:50 --> Total execution time: 0.6370
INFO - 2019-07-12 00:50:51 --> Helper loaded: language_helper
INFO - 2019-07-12 00:50:51 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:50:51 --> Model Class Initialized
INFO - 2019-07-12 00:50:51 --> Model Class Initialized
INFO - 2019-07-12 00:50:51 --> Model Class Initialized
INFO - 2019-07-12 00:50:51 --> Model Class Initialized
INFO - 2019-07-12 00:50:51 --> Helper loaded: form_helper
INFO - 2019-07-12 00:50:51 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:50:51 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:50:51 --> Model Class Initialized
INFO - 2019-07-12 00:50:51 --> Model Class Initialized
INFO - 2019-07-12 00:50:51 --> Final output sent to browser
DEBUG - 2019-07-12 00:50:51 --> Total execution time: 0.6195
INFO - 2019-07-12 00:50:52 --> Helper loaded: language_helper
INFO - 2019-07-12 00:50:52 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:50:52 --> Model Class Initialized
INFO - 2019-07-12 00:50:52 --> Model Class Initialized
INFO - 2019-07-12 00:50:52 --> Model Class Initialized
INFO - 2019-07-12 00:50:52 --> Model Class Initialized
INFO - 2019-07-12 00:50:52 --> Helper loaded: form_helper
INFO - 2019-07-12 00:50:52 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:50:52 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:50:52 --> Model Class Initialized
INFO - 2019-07-12 00:50:52 --> Model Class Initialized
INFO - 2019-07-12 00:50:52 --> Final output sent to browser
DEBUG - 2019-07-12 00:50:52 --> Total execution time: 0.6265
INFO - 2019-07-12 00:50:59 --> Helper loaded: language_helper
INFO - 2019-07-12 00:50:59 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:50:59 --> Model Class Initialized
INFO - 2019-07-12 00:50:59 --> Model Class Initialized
INFO - 2019-07-12 00:50:59 --> Model Class Initialized
INFO - 2019-07-12 00:50:59 --> Model Class Initialized
INFO - 2019-07-12 00:50:59 --> Helper loaded: form_helper
INFO - 2019-07-12 00:50:59 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:50:59 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:50:59 --> Model Class Initialized
INFO - 2019-07-12 00:50:59 --> Model Class Initialized
INFO - 2019-07-12 00:50:59 --> Final output sent to browser
DEBUG - 2019-07-12 00:50:59 --> Total execution time: 0.6203
INFO - 2019-07-12 00:51:01 --> Helper loaded: language_helper
INFO - 2019-07-12 00:51:01 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:51:01 --> Model Class Initialized
INFO - 2019-07-12 00:51:01 --> Model Class Initialized
INFO - 2019-07-12 00:51:01 --> Model Class Initialized
INFO - 2019-07-12 00:51:01 --> Model Class Initialized
INFO - 2019-07-12 00:51:01 --> Helper loaded: form_helper
INFO - 2019-07-12 00:51:01 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:51:01 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:51:01 --> Model Class Initialized
INFO - 2019-07-12 00:51:01 --> Model Class Initialized
INFO - 2019-07-12 00:51:01 --> Final output sent to browser
DEBUG - 2019-07-12 00:51:01 --> Total execution time: 0.6521
INFO - 2019-07-12 00:51:14 --> Helper loaded: language_helper
INFO - 2019-07-12 00:51:14 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:51:14 --> Model Class Initialized
INFO - 2019-07-12 00:51:14 --> Model Class Initialized
INFO - 2019-07-12 00:51:14 --> Model Class Initialized
INFO - 2019-07-12 00:51:14 --> Model Class Initialized
INFO - 2019-07-12 00:51:14 --> Model Class Initialized
INFO - 2019-07-12 00:51:14 --> Final output sent to browser
DEBUG - 2019-07-12 00:51:14 --> Total execution time: 0.5568
INFO - 2019-07-12 00:51:15 --> Helper loaded: language_helper
INFO - 2019-07-12 00:51:15 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:51:15 --> Model Class Initialized
INFO - 2019-07-12 00:51:15 --> Model Class Initialized
INFO - 2019-07-12 00:51:15 --> Model Class Initialized
INFO - 2019-07-12 00:51:15 --> Model Class Initialized
INFO - 2019-07-12 00:51:15 --> Helper loaded: form_helper
INFO - 2019-07-12 00:51:15 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:51:15 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:51:15 --> Model Class Initialized
INFO - 2019-07-12 00:51:15 --> Model Class Initialized
INFO - 2019-07-12 00:51:15 --> Final output sent to browser
DEBUG - 2019-07-12 00:51:15 --> Total execution time: 0.6425
INFO - 2019-07-12 00:51:20 --> Helper loaded: language_helper
INFO - 2019-07-12 00:51:20 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:51:20 --> Model Class Initialized
INFO - 2019-07-12 00:51:20 --> Model Class Initialized
INFO - 2019-07-12 00:51:20 --> Model Class Initialized
INFO - 2019-07-12 00:51:20 --> Model Class Initialized
INFO - 2019-07-12 00:51:20 --> Helper loaded: form_helper
INFO - 2019-07-12 00:51:20 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:51:20 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:51:20 --> Model Class Initialized
INFO - 2019-07-12 00:51:20 --> Model Class Initialized
INFO - 2019-07-12 00:51:20 --> Final output sent to browser
DEBUG - 2019-07-12 00:51:20 --> Total execution time: 0.6365
INFO - 2019-07-12 00:51:26 --> Helper loaded: language_helper
INFO - 2019-07-12 00:51:26 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:51:26 --> Model Class Initialized
INFO - 2019-07-12 00:51:26 --> Model Class Initialized
INFO - 2019-07-12 00:51:26 --> Model Class Initialized
INFO - 2019-07-12 00:51:26 --> Model Class Initialized
INFO - 2019-07-12 00:51:26 --> Helper loaded: form_helper
INFO - 2019-07-12 00:51:26 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:51:26 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:51:26 --> Model Class Initialized
INFO - 2019-07-12 00:51:26 --> Model Class Initialized
INFO - 2019-07-12 00:51:26 --> Final output sent to browser
DEBUG - 2019-07-12 00:51:26 --> Total execution time: 0.6379
INFO - 2019-07-12 00:51:38 --> Helper loaded: language_helper
INFO - 2019-07-12 00:51:38 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:51:38 --> Model Class Initialized
INFO - 2019-07-12 00:51:38 --> Model Class Initialized
INFO - 2019-07-12 00:51:38 --> Model Class Initialized
INFO - 2019-07-12 00:51:38 --> Model Class Initialized
INFO - 2019-07-12 00:51:38 --> Helper loaded: form_helper
INFO - 2019-07-12 00:51:38 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:51:38 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:51:38 --> Model Class Initialized
INFO - 2019-07-12 00:51:38 --> Model Class Initialized
INFO - 2019-07-12 00:51:38 --> Final output sent to browser
DEBUG - 2019-07-12 00:51:38 --> Total execution time: 0.8532
INFO - 2019-07-12 00:51:39 --> Helper loaded: language_helper
INFO - 2019-07-12 00:51:39 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:51:39 --> Model Class Initialized
INFO - 2019-07-12 00:51:39 --> Model Class Initialized
INFO - 2019-07-12 00:51:39 --> Model Class Initialized
INFO - 2019-07-12 00:51:39 --> Model Class Initialized
INFO - 2019-07-12 00:51:39 --> Model Class Initialized
INFO - 2019-07-12 00:51:39 --> Final output sent to browser
DEBUG - 2019-07-12 00:51:39 --> Total execution time: 0.5850
INFO - 2019-07-12 00:51:39 --> Helper loaded: language_helper
INFO - 2019-07-12 00:51:39 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:51:39 --> Model Class Initialized
INFO - 2019-07-12 00:51:39 --> Model Class Initialized
INFO - 2019-07-12 00:51:39 --> Model Class Initialized
INFO - 2019-07-12 00:51:39 --> Model Class Initialized
INFO - 2019-07-12 00:51:39 --> Helper loaded: form_helper
INFO - 2019-07-12 00:51:39 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:51:39 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:51:39 --> Model Class Initialized
INFO - 2019-07-12 00:51:39 --> Model Class Initialized
INFO - 2019-07-12 00:51:39 --> Final output sent to browser
DEBUG - 2019-07-12 00:51:39 --> Total execution time: 0.6716
INFO - 2019-07-12 00:51:41 --> Helper loaded: language_helper
INFO - 2019-07-12 00:51:41 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:51:41 --> Model Class Initialized
INFO - 2019-07-12 00:51:41 --> Model Class Initialized
INFO - 2019-07-12 00:51:41 --> Model Class Initialized
INFO - 2019-07-12 00:51:41 --> Model Class Initialized
INFO - 2019-07-12 00:51:41 --> Helper loaded: form_helper
INFO - 2019-07-12 00:51:41 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:51:41 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:51:41 --> Model Class Initialized
INFO - 2019-07-12 00:51:41 --> Model Class Initialized
INFO - 2019-07-12 00:51:41 --> Final output sent to browser
DEBUG - 2019-07-12 00:51:41 --> Total execution time: 0.6298
INFO - 2019-07-12 00:52:18 --> Helper loaded: language_helper
INFO - 2019-07-12 00:52:18 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:52:18 --> Model Class Initialized
INFO - 2019-07-12 00:52:18 --> Model Class Initialized
INFO - 2019-07-12 00:52:18 --> Model Class Initialized
INFO - 2019-07-12 00:52:18 --> Model Class Initialized
INFO - 2019-07-12 00:52:18 --> Model Class Initialized
INFO - 2019-07-12 00:52:18 --> Final output sent to browser
DEBUG - 2019-07-12 00:52:18 --> Total execution time: 0.6684
INFO - 2019-07-12 00:52:18 --> Helper loaded: language_helper
INFO - 2019-07-12 00:52:18 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:52:18 --> Model Class Initialized
INFO - 2019-07-12 00:52:18 --> Model Class Initialized
INFO - 2019-07-12 00:52:18 --> Model Class Initialized
INFO - 2019-07-12 00:52:18 --> Model Class Initialized
INFO - 2019-07-12 00:52:18 --> Helper loaded: form_helper
INFO - 2019-07-12 00:52:18 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:52:18 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:52:18 --> Model Class Initialized
INFO - 2019-07-12 00:52:18 --> Model Class Initialized
INFO - 2019-07-12 00:52:18 --> Final output sent to browser
DEBUG - 2019-07-12 00:52:18 --> Total execution time: 0.8391
INFO - 2019-07-12 00:52:18 --> Helper loaded: language_helper
INFO - 2019-07-12 00:52:18 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:52:18 --> Model Class Initialized
INFO - 2019-07-12 00:52:18 --> Model Class Initialized
INFO - 2019-07-12 00:52:18 --> Model Class Initialized
INFO - 2019-07-12 00:52:18 --> Model Class Initialized
INFO - 2019-07-12 00:52:18 --> Helper loaded: form_helper
INFO - 2019-07-12 00:52:18 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:52:18 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:52:18 --> Model Class Initialized
INFO - 2019-07-12 00:52:18 --> Model Class Initialized
INFO - 2019-07-12 00:52:18 --> Final output sent to browser
DEBUG - 2019-07-12 00:52:18 --> Total execution time: 0.7345
INFO - 2019-07-12 00:52:20 --> Helper loaded: language_helper
INFO - 2019-07-12 00:52:20 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:52:20 --> Model Class Initialized
INFO - 2019-07-12 00:52:20 --> Model Class Initialized
INFO - 2019-07-12 00:52:20 --> Model Class Initialized
INFO - 2019-07-12 00:52:20 --> Model Class Initialized
INFO - 2019-07-12 00:52:20 --> Helper loaded: form_helper
INFO - 2019-07-12 00:52:20 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:52:20 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:52:20 --> Model Class Initialized
INFO - 2019-07-12 00:52:20 --> Model Class Initialized
INFO - 2019-07-12 00:52:20 --> Final output sent to browser
DEBUG - 2019-07-12 00:52:20 --> Total execution time: 0.7548
INFO - 2019-07-12 00:52:21 --> Helper loaded: language_helper
INFO - 2019-07-12 00:52:21 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:52:21 --> Model Class Initialized
INFO - 2019-07-12 00:52:21 --> Model Class Initialized
INFO - 2019-07-12 00:52:21 --> Model Class Initialized
INFO - 2019-07-12 00:52:21 --> Model Class Initialized
INFO - 2019-07-12 00:52:21 --> Model Class Initialized
INFO - 2019-07-12 00:52:21 --> Final output sent to browser
DEBUG - 2019-07-12 00:52:21 --> Total execution time: 0.5806
INFO - 2019-07-12 00:52:21 --> Helper loaded: language_helper
INFO - 2019-07-12 00:52:21 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:52:21 --> Model Class Initialized
INFO - 2019-07-12 00:52:21 --> Model Class Initialized
INFO - 2019-07-12 00:52:21 --> Model Class Initialized
INFO - 2019-07-12 00:52:21 --> Model Class Initialized
INFO - 2019-07-12 00:52:21 --> Helper loaded: form_helper
INFO - 2019-07-12 00:52:21 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:52:21 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:52:21 --> Model Class Initialized
INFO - 2019-07-12 00:52:21 --> Model Class Initialized
INFO - 2019-07-12 00:52:21 --> Final output sent to browser
DEBUG - 2019-07-12 00:52:21 --> Total execution time: 0.6353
INFO - 2019-07-12 00:52:30 --> Helper loaded: language_helper
INFO - 2019-07-12 00:52:30 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:52:30 --> Model Class Initialized
INFO - 2019-07-12 00:52:30 --> Model Class Initialized
INFO - 2019-07-12 00:52:30 --> Model Class Initialized
INFO - 2019-07-12 00:52:30 --> Model Class Initialized
INFO - 2019-07-12 00:52:30 --> Helper loaded: form_helper
INFO - 2019-07-12 00:52:30 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:52:30 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:52:30 --> Model Class Initialized
INFO - 2019-07-12 00:52:30 --> Model Class Initialized
INFO - 2019-07-12 00:52:30 --> Final output sent to browser
DEBUG - 2019-07-12 00:52:30 --> Total execution time: 0.6756
INFO - 2019-07-12 00:52:46 --> Helper loaded: language_helper
INFO - 2019-07-12 00:52:46 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:52:46 --> Model Class Initialized
INFO - 2019-07-12 00:52:46 --> Model Class Initialized
INFO - 2019-07-12 00:52:46 --> Model Class Initialized
INFO - 2019-07-12 00:52:46 --> Model Class Initialized
INFO - 2019-07-12 00:52:46 --> Helper loaded: form_helper
INFO - 2019-07-12 00:52:46 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:52:46 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:52:46 --> Model Class Initialized
INFO - 2019-07-12 00:52:46 --> Model Class Initialized
INFO - 2019-07-12 00:52:46 --> Final output sent to browser
DEBUG - 2019-07-12 00:52:46 --> Total execution time: 0.6379
INFO - 2019-07-12 00:52:53 --> Helper loaded: language_helper
INFO - 2019-07-12 00:52:53 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:52:53 --> Model Class Initialized
INFO - 2019-07-12 00:52:53 --> Model Class Initialized
INFO - 2019-07-12 00:52:53 --> Model Class Initialized
INFO - 2019-07-12 00:52:53 --> Model Class Initialized
INFO - 2019-07-12 00:52:53 --> Helper loaded: form_helper
INFO - 2019-07-12 00:52:53 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:52:53 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:52:53 --> Model Class Initialized
INFO - 2019-07-12 00:52:53 --> Model Class Initialized
INFO - 2019-07-12 00:52:53 --> Final output sent to browser
DEBUG - 2019-07-12 00:52:53 --> Total execution time: 0.6044
INFO - 2019-07-12 00:52:54 --> Helper loaded: language_helper
INFO - 2019-07-12 00:52:54 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:52:54 --> Model Class Initialized
INFO - 2019-07-12 00:52:54 --> Model Class Initialized
INFO - 2019-07-12 00:52:54 --> Model Class Initialized
INFO - 2019-07-12 00:52:54 --> Model Class Initialized
INFO - 2019-07-12 00:52:54 --> Model Class Initialized
INFO - 2019-07-12 00:52:54 --> Final output sent to browser
DEBUG - 2019-07-12 00:52:54 --> Total execution time: 0.5817
INFO - 2019-07-12 00:52:54 --> Helper loaded: language_helper
INFO - 2019-07-12 00:52:54 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:52:54 --> Model Class Initialized
INFO - 2019-07-12 00:52:54 --> Model Class Initialized
INFO - 2019-07-12 00:52:54 --> Model Class Initialized
INFO - 2019-07-12 00:52:54 --> Model Class Initialized
INFO - 2019-07-12 00:52:54 --> Helper loaded: form_helper
INFO - 2019-07-12 00:52:54 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:52:54 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:52:54 --> Model Class Initialized
INFO - 2019-07-12 00:52:54 --> Model Class Initialized
INFO - 2019-07-12 00:52:54 --> Final output sent to browser
DEBUG - 2019-07-12 00:52:54 --> Total execution time: 0.6571
INFO - 2019-07-12 00:52:56 --> Helper loaded: language_helper
INFO - 2019-07-12 00:52:56 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:52:56 --> Model Class Initialized
INFO - 2019-07-12 00:52:56 --> Model Class Initialized
INFO - 2019-07-12 00:52:56 --> Model Class Initialized
INFO - 2019-07-12 00:52:56 --> Model Class Initialized
INFO - 2019-07-12 00:52:56 --> Helper loaded: form_helper
INFO - 2019-07-12 00:52:56 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:52:56 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:52:56 --> Model Class Initialized
INFO - 2019-07-12 00:52:56 --> Model Class Initialized
INFO - 2019-07-12 00:52:56 --> Final output sent to browser
DEBUG - 2019-07-12 00:52:56 --> Total execution time: 0.6326
INFO - 2019-07-12 00:52:57 --> Helper loaded: language_helper
INFO - 2019-07-12 00:52:57 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:52:57 --> Model Class Initialized
INFO - 2019-07-12 00:52:57 --> Model Class Initialized
INFO - 2019-07-12 00:52:57 --> Model Class Initialized
INFO - 2019-07-12 00:52:57 --> Model Class Initialized
INFO - 2019-07-12 00:52:57 --> Model Class Initialized
INFO - 2019-07-12 00:52:57 --> Final output sent to browser
DEBUG - 2019-07-12 00:52:57 --> Total execution time: 0.5822
INFO - 2019-07-12 00:52:57 --> Helper loaded: language_helper
INFO - 2019-07-12 00:52:57 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:52:57 --> Model Class Initialized
INFO - 2019-07-12 00:52:57 --> Model Class Initialized
INFO - 2019-07-12 00:52:57 --> Model Class Initialized
INFO - 2019-07-12 00:52:57 --> Model Class Initialized
INFO - 2019-07-12 00:52:57 --> Helper loaded: form_helper
INFO - 2019-07-12 00:52:57 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:52:57 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:52:58 --> Model Class Initialized
INFO - 2019-07-12 00:52:58 --> Model Class Initialized
INFO - 2019-07-12 00:52:58 --> Final output sent to browser
DEBUG - 2019-07-12 00:52:58 --> Total execution time: 0.6604
INFO - 2019-07-12 00:52:59 --> Helper loaded: language_helper
INFO - 2019-07-12 00:52:59 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:52:59 --> Model Class Initialized
INFO - 2019-07-12 00:52:59 --> Model Class Initialized
INFO - 2019-07-12 00:52:59 --> Model Class Initialized
INFO - 2019-07-12 00:52:59 --> Model Class Initialized
INFO - 2019-07-12 00:52:59 --> Helper loaded: form_helper
INFO - 2019-07-12 00:52:59 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:52:59 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:52:59 --> Model Class Initialized
INFO - 2019-07-12 00:52:59 --> Model Class Initialized
INFO - 2019-07-12 00:52:59 --> Final output sent to browser
DEBUG - 2019-07-12 00:52:59 --> Total execution time: 0.6496
INFO - 2019-07-12 00:53:57 --> Helper loaded: language_helper
INFO - 2019-07-12 00:53:57 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:53:57 --> Helper loaded: language_helper
INFO - 2019-07-12 00:53:57 --> Model Class Initialized
INFO - 2019-07-12 00:53:57 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:53:57 --> Model Class Initialized
INFO - 2019-07-12 00:53:57 --> Model Class Initialized
INFO - 2019-07-12 00:53:57 --> Model Class Initialized
INFO - 2019-07-12 00:53:57 --> Model Class Initialized
INFO - 2019-07-12 00:53:57 --> Model Class Initialized
INFO - 2019-07-12 00:53:57 --> Model Class Initialized
INFO - 2019-07-12 00:53:57 --> Helper loaded: form_helper
INFO - 2019-07-12 00:53:57 --> Model Class Initialized
INFO - 2019-07-12 00:53:57 --> Form Validation Class Initialized
INFO - 2019-07-12 00:53:57 --> Model Class Initialized
DEBUG - 2019-07-12 00:53:57 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:53:57 --> Final output sent to browser
INFO - 2019-07-12 00:53:57 --> Model Class Initialized
DEBUG - 2019-07-12 00:53:57 --> Total execution time: 0.9708
INFO - 2019-07-12 00:53:57 --> Model Class Initialized
INFO - 2019-07-12 00:53:57 --> Final output sent to browser
DEBUG - 2019-07-12 00:53:57 --> Total execution time: 1.0576
INFO - 2019-07-12 00:53:58 --> Helper loaded: language_helper
INFO - 2019-07-12 00:53:58 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:53:58 --> Model Class Initialized
INFO - 2019-07-12 00:53:58 --> Model Class Initialized
INFO - 2019-07-12 00:53:58 --> Model Class Initialized
INFO - 2019-07-12 00:53:58 --> Model Class Initialized
INFO - 2019-07-12 00:53:58 --> Helper loaded: form_helper
INFO - 2019-07-12 00:53:58 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:53:58 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:53:58 --> Model Class Initialized
INFO - 2019-07-12 00:53:58 --> Model Class Initialized
INFO - 2019-07-12 00:53:58 --> Final output sent to browser
DEBUG - 2019-07-12 00:53:58 --> Total execution time: 0.6598
INFO - 2019-07-12 00:54:09 --> Helper loaded: language_helper
INFO - 2019-07-12 00:54:09 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:54:09 --> Model Class Initialized
INFO - 2019-07-12 00:54:09 --> Model Class Initialized
INFO - 2019-07-12 00:54:09 --> Model Class Initialized
INFO - 2019-07-12 00:54:09 --> Model Class Initialized
INFO - 2019-07-12 00:54:09 --> Model Class Initialized
INFO - 2019-07-12 00:54:09 --> Final output sent to browser
DEBUG - 2019-07-12 00:54:09 --> Total execution time: 0.6889
INFO - 2019-07-12 00:54:10 --> Helper loaded: language_helper
INFO - 2019-07-12 00:54:10 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:54:10 --> Model Class Initialized
INFO - 2019-07-12 00:54:10 --> Model Class Initialized
INFO - 2019-07-12 00:54:10 --> Model Class Initialized
INFO - 2019-07-12 00:54:10 --> Model Class Initialized
INFO - 2019-07-12 00:54:10 --> Helper loaded: form_helper
INFO - 2019-07-12 00:54:10 --> Helper loaded: language_helper
INFO - 2019-07-12 00:54:10 --> Form Validation Class Initialized
INFO - 2019-07-12 00:54:10 --> Language file loaded: language/english/general_lang.php
DEBUG - 2019-07-12 00:54:10 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:54:10 --> Model Class Initialized
INFO - 2019-07-12 00:54:10 --> Model Class Initialized
INFO - 2019-07-12 00:54:10 --> Model Class Initialized
INFO - 2019-07-12 00:54:10 --> Model Class Initialized
INFO - 2019-07-12 00:54:10 --> Model Class Initialized
INFO - 2019-07-12 00:54:10 --> Model Class Initialized
INFO - 2019-07-12 00:54:10 --> Final output sent to browser
INFO - 2019-07-12 00:54:10 --> Helper loaded: form_helper
DEBUG - 2019-07-12 00:54:10 --> Total execution time: 0.9421
INFO - 2019-07-12 00:54:10 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:54:10 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:54:10 --> Model Class Initialized
INFO - 2019-07-12 00:54:10 --> Model Class Initialized
INFO - 2019-07-12 00:54:10 --> Final output sent to browser
DEBUG - 2019-07-12 00:54:10 --> Total execution time: 0.9461
INFO - 2019-07-12 00:54:15 --> Helper loaded: language_helper
INFO - 2019-07-12 00:54:15 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:54:15 --> Model Class Initialized
INFO - 2019-07-12 00:54:15 --> Model Class Initialized
INFO - 2019-07-12 00:54:15 --> Model Class Initialized
INFO - 2019-07-12 00:54:15 --> Model Class Initialized
INFO - 2019-07-12 00:54:15 --> Model Class Initialized
INFO - 2019-07-12 00:54:15 --> Final output sent to browser
DEBUG - 2019-07-12 00:54:15 --> Total execution time: 0.6427
INFO - 2019-07-12 00:54:16 --> Helper loaded: language_helper
INFO - 2019-07-12 00:54:16 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:54:16 --> Model Class Initialized
INFO - 2019-07-12 00:54:16 --> Model Class Initialized
INFO - 2019-07-12 00:54:16 --> Model Class Initialized
INFO - 2019-07-12 00:54:16 --> Model Class Initialized
INFO - 2019-07-12 00:54:16 --> Helper loaded: form_helper
INFO - 2019-07-12 00:54:16 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:54:16 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:54:16 --> Model Class Initialized
INFO - 2019-07-12 00:54:16 --> Model Class Initialized
INFO - 2019-07-12 00:54:16 --> Final output sent to browser
DEBUG - 2019-07-12 00:54:16 --> Total execution time: 0.7265
INFO - 2019-07-12 00:54:17 --> Helper loaded: language_helper
INFO - 2019-07-12 00:54:17 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:54:17 --> Model Class Initialized
INFO - 2019-07-12 00:54:17 --> Model Class Initialized
INFO - 2019-07-12 00:54:17 --> Model Class Initialized
INFO - 2019-07-12 00:54:17 --> Model Class Initialized
INFO - 2019-07-12 00:54:17 --> Helper loaded: form_helper
INFO - 2019-07-12 00:54:17 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:54:17 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:54:17 --> Model Class Initialized
INFO - 2019-07-12 00:54:17 --> Model Class Initialized
INFO - 2019-07-12 00:54:17 --> Final output sent to browser
DEBUG - 2019-07-12 00:54:17 --> Total execution time: 0.6446
INFO - 2019-07-12 00:54:27 --> Helper loaded: language_helper
INFO - 2019-07-12 00:54:27 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:54:27 --> Model Class Initialized
INFO - 2019-07-12 00:54:27 --> Model Class Initialized
INFO - 2019-07-12 00:54:27 --> Model Class Initialized
INFO - 2019-07-12 00:54:27 --> Model Class Initialized
INFO - 2019-07-12 00:54:27 --> Model Class Initialized
INFO - 2019-07-12 00:54:27 --> Final output sent to browser
DEBUG - 2019-07-12 00:54:27 --> Total execution time: 0.5992
INFO - 2019-07-12 00:54:28 --> Helper loaded: language_helper
INFO - 2019-07-12 00:54:28 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:54:28 --> Model Class Initialized
INFO - 2019-07-12 00:54:28 --> Model Class Initialized
INFO - 2019-07-12 00:54:28 --> Model Class Initialized
INFO - 2019-07-12 00:54:28 --> Model Class Initialized
INFO - 2019-07-12 00:54:28 --> Helper loaded: form_helper
INFO - 2019-07-12 00:54:28 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:54:28 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:54:28 --> Model Class Initialized
INFO - 2019-07-12 00:54:28 --> Model Class Initialized
INFO - 2019-07-12 00:54:28 --> Final output sent to browser
DEBUG - 2019-07-12 00:54:28 --> Total execution time: 0.6581
INFO - 2019-07-12 00:54:30 --> Helper loaded: language_helper
INFO - 2019-07-12 00:54:30 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:54:30 --> Model Class Initialized
INFO - 2019-07-12 00:54:30 --> Model Class Initialized
INFO - 2019-07-12 00:54:30 --> Model Class Initialized
INFO - 2019-07-12 00:54:30 --> Model Class Initialized
INFO - 2019-07-12 00:54:30 --> Helper loaded: form_helper
INFO - 2019-07-12 00:54:30 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:54:30 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:54:30 --> Model Class Initialized
INFO - 2019-07-12 00:54:30 --> Model Class Initialized
INFO - 2019-07-12 00:54:30 --> Final output sent to browser
DEBUG - 2019-07-12 00:54:30 --> Total execution time: 0.6605
INFO - 2019-07-12 00:54:54 --> Helper loaded: language_helper
INFO - 2019-07-12 00:54:55 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:54:55 --> Model Class Initialized
INFO - 2019-07-12 00:54:55 --> Model Class Initialized
INFO - 2019-07-12 00:54:55 --> Model Class Initialized
INFO - 2019-07-12 00:54:55 --> Model Class Initialized
INFO - 2019-07-12 00:54:55 --> Model Class Initialized
INFO - 2019-07-12 00:54:55 --> Final output sent to browser
DEBUG - 2019-07-12 00:54:55 --> Total execution time: 0.6708
INFO - 2019-07-12 00:54:55 --> Helper loaded: language_helper
INFO - 2019-07-12 00:54:55 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:54:55 --> Model Class Initialized
INFO - 2019-07-12 00:54:55 --> Model Class Initialized
INFO - 2019-07-12 00:54:55 --> Model Class Initialized
INFO - 2019-07-12 00:54:55 --> Model Class Initialized
INFO - 2019-07-12 00:54:55 --> Helper loaded: form_helper
INFO - 2019-07-12 00:54:55 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:54:55 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:54:55 --> Model Class Initialized
INFO - 2019-07-12 00:54:55 --> Model Class Initialized
INFO - 2019-07-12 00:54:55 --> Final output sent to browser
DEBUG - 2019-07-12 00:54:55 --> Total execution time: 0.8707
INFO - 2019-07-12 00:54:55 --> Helper loaded: language_helper
INFO - 2019-07-12 00:54:55 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:54:55 --> Model Class Initialized
INFO - 2019-07-12 00:54:55 --> Model Class Initialized
INFO - 2019-07-12 00:54:55 --> Model Class Initialized
INFO - 2019-07-12 00:54:55 --> Model Class Initialized
INFO - 2019-07-12 00:54:55 --> Helper loaded: form_helper
INFO - 2019-07-12 00:54:55 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:54:55 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:54:55 --> Model Class Initialized
INFO - 2019-07-12 00:54:55 --> Model Class Initialized
INFO - 2019-07-12 00:54:55 --> Final output sent to browser
DEBUG - 2019-07-12 00:54:55 --> Total execution time: 0.7665
INFO - 2019-07-12 00:55:17 --> Helper loaded: language_helper
INFO - 2019-07-12 00:55:17 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:55:17 --> Model Class Initialized
INFO - 2019-07-12 00:55:17 --> Model Class Initialized
INFO - 2019-07-12 00:55:17 --> Model Class Initialized
INFO - 2019-07-12 00:55:17 --> Model Class Initialized
INFO - 2019-07-12 00:55:17 --> Helper loaded: form_helper
INFO - 2019-07-12 00:55:17 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:55:17 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:55:17 --> Model Class Initialized
INFO - 2019-07-12 00:55:17 --> Model Class Initialized
INFO - 2019-07-12 00:55:17 --> Final output sent to browser
DEBUG - 2019-07-12 00:55:17 --> Total execution time: 0.6123
INFO - 2019-07-12 00:55:19 --> Helper loaded: language_helper
INFO - 2019-07-12 00:55:19 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:55:19 --> Model Class Initialized
INFO - 2019-07-12 00:55:19 --> Model Class Initialized
INFO - 2019-07-12 00:55:19 --> Model Class Initialized
INFO - 2019-07-12 00:55:19 --> Model Class Initialized
INFO - 2019-07-12 00:55:19 --> Model Class Initialized
INFO - 2019-07-12 00:55:19 --> Final output sent to browser
DEBUG - 2019-07-12 00:55:19 --> Total execution time: 0.7124
INFO - 2019-07-12 00:55:19 --> Helper loaded: language_helper
INFO - 2019-07-12 00:55:19 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:55:19 --> Model Class Initialized
INFO - 2019-07-12 00:55:19 --> Model Class Initialized
INFO - 2019-07-12 00:55:19 --> Model Class Initialized
INFO - 2019-07-12 00:55:19 --> Model Class Initialized
INFO - 2019-07-12 00:55:19 --> Helper loaded: form_helper
INFO - 2019-07-12 00:55:19 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:55:19 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:55:19 --> Model Class Initialized
INFO - 2019-07-12 00:55:19 --> Model Class Initialized
INFO - 2019-07-12 00:55:19 --> Final output sent to browser
DEBUG - 2019-07-12 00:55:19 --> Total execution time: 0.6853
INFO - 2019-07-12 00:55:21 --> Helper loaded: language_helper
INFO - 2019-07-12 00:55:21 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:55:21 --> Model Class Initialized
INFO - 2019-07-12 00:55:21 --> Model Class Initialized
INFO - 2019-07-12 00:55:21 --> Model Class Initialized
INFO - 2019-07-12 00:55:21 --> Model Class Initialized
INFO - 2019-07-12 00:55:21 --> Helper loaded: form_helper
INFO - 2019-07-12 00:55:21 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:55:21 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:55:21 --> Model Class Initialized
INFO - 2019-07-12 00:55:21 --> Model Class Initialized
INFO - 2019-07-12 00:55:21 --> Final output sent to browser
DEBUG - 2019-07-12 00:55:21 --> Total execution time: 0.6403
INFO - 2019-07-12 00:55:22 --> Helper loaded: language_helper
INFO - 2019-07-12 00:55:22 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:55:22 --> Model Class Initialized
INFO - 2019-07-12 00:55:22 --> Model Class Initialized
INFO - 2019-07-12 00:55:22 --> Model Class Initialized
INFO - 2019-07-12 00:55:22 --> Model Class Initialized
INFO - 2019-07-12 00:55:22 --> Helper loaded: form_helper
INFO - 2019-07-12 00:55:22 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:55:22 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:55:22 --> Model Class Initialized
INFO - 2019-07-12 00:55:22 --> Model Class Initialized
INFO - 2019-07-12 00:55:22 --> Final output sent to browser
DEBUG - 2019-07-12 00:55:22 --> Total execution time: 0.6580
INFO - 2019-07-12 00:56:44 --> Helper loaded: language_helper
INFO - 2019-07-12 00:56:44 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:56:44 --> Model Class Initialized
INFO - 2019-07-12 00:56:44 --> Model Class Initialized
INFO - 2019-07-12 00:56:44 --> Model Class Initialized
INFO - 2019-07-12 00:56:44 --> Model Class Initialized
INFO - 2019-07-12 00:56:44 --> Helper loaded: form_helper
INFO - 2019-07-12 00:56:44 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:56:44 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:56:44 --> Model Class Initialized
INFO - 2019-07-12 00:56:44 --> Model Class Initialized
INFO - 2019-07-12 00:56:44 --> Final output sent to browser
DEBUG - 2019-07-12 00:56:44 --> Total execution time: 0.6613
INFO - 2019-07-12 00:57:10 --> Helper loaded: language_helper
INFO - 2019-07-12 00:57:10 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:57:10 --> Model Class Initialized
INFO - 2019-07-12 00:57:10 --> Model Class Initialized
INFO - 2019-07-12 00:57:10 --> Model Class Initialized
INFO - 2019-07-12 00:57:10 --> Model Class Initialized
INFO - 2019-07-12 00:57:10 --> Model Class Initialized
INFO - 2019-07-12 00:57:10 --> Final output sent to browser
DEBUG - 2019-07-12 00:57:10 --> Total execution time: 0.6660
INFO - 2019-07-12 00:57:10 --> Helper loaded: language_helper
INFO - 2019-07-12 00:57:10 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:57:10 --> Model Class Initialized
INFO - 2019-07-12 00:57:10 --> Model Class Initialized
INFO - 2019-07-12 00:57:11 --> Model Class Initialized
INFO - 2019-07-12 00:57:11 --> Model Class Initialized
INFO - 2019-07-12 00:57:11 --> Helper loaded: form_helper
INFO - 2019-07-12 00:57:11 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:57:11 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:57:11 --> Model Class Initialized
INFO - 2019-07-12 00:57:11 --> Model Class Initialized
INFO - 2019-07-12 00:57:11 --> Final output sent to browser
DEBUG - 2019-07-12 00:57:11 --> Total execution time: 0.6532
INFO - 2019-07-12 00:57:12 --> Helper loaded: language_helper
INFO - 2019-07-12 00:57:13 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:57:13 --> Model Class Initialized
INFO - 2019-07-12 00:57:13 --> Model Class Initialized
INFO - 2019-07-12 00:57:13 --> Model Class Initialized
INFO - 2019-07-12 00:57:13 --> Model Class Initialized
INFO - 2019-07-12 00:57:13 --> Helper loaded: form_helper
INFO - 2019-07-12 00:57:13 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:57:13 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:57:13 --> Model Class Initialized
INFO - 2019-07-12 00:57:13 --> Model Class Initialized
INFO - 2019-07-12 00:57:13 --> Final output sent to browser
DEBUG - 2019-07-12 00:57:13 --> Total execution time: 0.7336
INFO - 2019-07-12 00:57:13 --> Helper loaded: language_helper
INFO - 2019-07-12 00:57:13 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:57:13 --> Model Class Initialized
INFO - 2019-07-12 00:57:13 --> Model Class Initialized
INFO - 2019-07-12 00:57:13 --> Model Class Initialized
INFO - 2019-07-12 00:57:13 --> Model Class Initialized
INFO - 2019-07-12 00:57:13 --> Helper loaded: form_helper
INFO - 2019-07-12 00:57:13 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:57:13 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:57:13 --> Model Class Initialized
INFO - 2019-07-12 00:57:13 --> Model Class Initialized
INFO - 2019-07-12 00:57:13 --> Final output sent to browser
DEBUG - 2019-07-12 00:57:13 --> Total execution time: 0.7581
INFO - 2019-07-12 00:57:15 --> Helper loaded: language_helper
INFO - 2019-07-12 00:57:15 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:57:15 --> Model Class Initialized
INFO - 2019-07-12 00:57:15 --> Model Class Initialized
INFO - 2019-07-12 00:57:15 --> Model Class Initialized
INFO - 2019-07-12 00:57:15 --> Model Class Initialized
INFO - 2019-07-12 00:57:15 --> Helper loaded: form_helper
INFO - 2019-07-12 00:57:15 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:57:15 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:57:15 --> Model Class Initialized
INFO - 2019-07-12 00:57:15 --> Model Class Initialized
INFO - 2019-07-12 00:57:15 --> Final output sent to browser
DEBUG - 2019-07-12 00:57:15 --> Total execution time: 0.6134
INFO - 2019-07-12 00:57:15 --> Helper loaded: language_helper
INFO - 2019-07-12 00:57:15 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:57:15 --> Model Class Initialized
INFO - 2019-07-12 00:57:15 --> Model Class Initialized
INFO - 2019-07-12 00:57:15 --> Model Class Initialized
INFO - 2019-07-12 00:57:15 --> Model Class Initialized
INFO - 2019-07-12 00:57:15 --> Helper loaded: form_helper
INFO - 2019-07-12 00:57:15 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:57:15 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:57:15 --> Model Class Initialized
INFO - 2019-07-12 00:57:15 --> Model Class Initialized
INFO - 2019-07-12 00:57:15 --> Final output sent to browser
DEBUG - 2019-07-12 00:57:16 --> Total execution time: 0.6819
INFO - 2019-07-12 00:58:46 --> Helper loaded: language_helper
INFO - 2019-07-12 00:58:46 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:58:46 --> Model Class Initialized
INFO - 2019-07-12 00:58:46 --> Model Class Initialized
INFO - 2019-07-12 00:58:46 --> Model Class Initialized
INFO - 2019-07-12 00:58:46 --> Model Class Initialized
INFO - 2019-07-12 00:58:46 --> Model Class Initialized
INFO - 2019-07-12 00:58:46 --> Final output sent to browser
DEBUG - 2019-07-12 00:58:46 --> Total execution time: 0.6300
INFO - 2019-07-12 00:58:47 --> Helper loaded: language_helper
INFO - 2019-07-12 00:58:47 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:58:47 --> Model Class Initialized
INFO - 2019-07-12 00:58:47 --> Model Class Initialized
INFO - 2019-07-12 00:58:47 --> Model Class Initialized
INFO - 2019-07-12 00:58:47 --> Model Class Initialized
INFO - 2019-07-12 00:58:47 --> Helper loaded: form_helper
INFO - 2019-07-12 00:58:47 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:58:47 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:58:47 --> Model Class Initialized
INFO - 2019-07-12 00:58:47 --> Model Class Initialized
INFO - 2019-07-12 00:58:47 --> Final output sent to browser
DEBUG - 2019-07-12 00:58:47 --> Total execution time: 0.8244
INFO - 2019-07-12 00:58:47 --> Helper loaded: language_helper
INFO - 2019-07-12 00:58:47 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:58:47 --> Model Class Initialized
INFO - 2019-07-12 00:58:47 --> Model Class Initialized
INFO - 2019-07-12 00:58:47 --> Model Class Initialized
INFO - 2019-07-12 00:58:47 --> Model Class Initialized
INFO - 2019-07-12 00:58:47 --> Helper loaded: form_helper
INFO - 2019-07-12 00:58:47 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:58:47 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:58:47 --> Model Class Initialized
INFO - 2019-07-12 00:58:47 --> Model Class Initialized
INFO - 2019-07-12 00:58:47 --> Final output sent to browser
DEBUG - 2019-07-12 00:58:47 --> Total execution time: 0.8027
INFO - 2019-07-12 00:58:54 --> Helper loaded: language_helper
INFO - 2019-07-12 00:58:54 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:58:54 --> Model Class Initialized
INFO - 2019-07-12 00:58:54 --> Model Class Initialized
INFO - 2019-07-12 00:58:54 --> Model Class Initialized
INFO - 2019-07-12 00:58:54 --> Model Class Initialized
INFO - 2019-07-12 00:58:54 --> Helper loaded: form_helper
INFO - 2019-07-12 00:58:54 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:58:54 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:58:54 --> Model Class Initialized
INFO - 2019-07-12 00:58:54 --> Model Class Initialized
INFO - 2019-07-12 00:58:54 --> Final output sent to browser
DEBUG - 2019-07-12 00:58:54 --> Total execution time: 0.6249
INFO - 2019-07-12 00:58:55 --> Helper loaded: language_helper
INFO - 2019-07-12 00:58:55 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:58:55 --> Model Class Initialized
INFO - 2019-07-12 00:58:55 --> Model Class Initialized
INFO - 2019-07-12 00:58:55 --> Model Class Initialized
INFO - 2019-07-12 00:58:55 --> Model Class Initialized
INFO - 2019-07-12 00:58:55 --> Model Class Initialized
INFO - 2019-07-12 00:58:55 --> Final output sent to browser
DEBUG - 2019-07-12 00:58:55 --> Total execution time: 0.6356
INFO - 2019-07-12 00:58:56 --> Helper loaded: language_helper
INFO - 2019-07-12 00:58:56 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:58:56 --> Model Class Initialized
INFO - 2019-07-12 00:58:56 --> Model Class Initialized
INFO - 2019-07-12 00:58:56 --> Model Class Initialized
INFO - 2019-07-12 00:58:56 --> Model Class Initialized
INFO - 2019-07-12 00:58:56 --> Helper loaded: form_helper
INFO - 2019-07-12 00:58:56 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:58:56 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:58:56 --> Model Class Initialized
INFO - 2019-07-12 00:58:56 --> Model Class Initialized
INFO - 2019-07-12 00:58:56 --> Final output sent to browser
DEBUG - 2019-07-12 00:58:56 --> Total execution time: 0.6447
INFO - 2019-07-12 00:59:10 --> Helper loaded: language_helper
INFO - 2019-07-12 00:59:10 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:59:10 --> Model Class Initialized
INFO - 2019-07-12 00:59:10 --> Model Class Initialized
INFO - 2019-07-12 00:59:10 --> Model Class Initialized
INFO - 2019-07-12 00:59:10 --> Model Class Initialized
INFO - 2019-07-12 00:59:10 --> Model Class Initialized
INFO - 2019-07-12 00:59:10 --> Final output sent to browser
DEBUG - 2019-07-12 00:59:10 --> Total execution time: 0.5954
INFO - 2019-07-12 00:59:11 --> Helper loaded: language_helper
INFO - 2019-07-12 00:59:11 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:59:11 --> Model Class Initialized
INFO - 2019-07-12 00:59:11 --> Model Class Initialized
INFO - 2019-07-12 00:59:11 --> Model Class Initialized
INFO - 2019-07-12 00:59:11 --> Model Class Initialized
INFO - 2019-07-12 00:59:11 --> Helper loaded: form_helper
INFO - 2019-07-12 00:59:11 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:59:11 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:59:11 --> Model Class Initialized
INFO - 2019-07-12 00:59:11 --> Model Class Initialized
INFO - 2019-07-12 00:59:11 --> Final output sent to browser
DEBUG - 2019-07-12 00:59:11 --> Total execution time: 0.6634
INFO - 2019-07-12 00:59:13 --> Helper loaded: language_helper
INFO - 2019-07-12 00:59:13 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 00:59:13 --> Model Class Initialized
INFO - 2019-07-12 00:59:13 --> Model Class Initialized
INFO - 2019-07-12 00:59:13 --> Model Class Initialized
INFO - 2019-07-12 00:59:13 --> Model Class Initialized
INFO - 2019-07-12 00:59:13 --> Helper loaded: form_helper
INFO - 2019-07-12 00:59:13 --> Form Validation Class Initialized
DEBUG - 2019-07-12 00:59:13 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 00:59:13 --> Model Class Initialized
INFO - 2019-07-12 00:59:13 --> Model Class Initialized
INFO - 2019-07-12 00:59:13 --> Final output sent to browser
DEBUG - 2019-07-12 00:59:13 --> Total execution time: 0.6297
INFO - 2019-07-12 01:00:31 --> Helper loaded: language_helper
INFO - 2019-07-12 01:00:31 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:00:31 --> Model Class Initialized
INFO - 2019-07-12 01:00:31 --> Model Class Initialized
INFO - 2019-07-12 01:00:31 --> Model Class Initialized
INFO - 2019-07-12 01:00:31 --> Model Class Initialized
INFO - 2019-07-12 01:00:31 --> Model Class Initialized
INFO - 2019-07-12 01:00:31 --> Final output sent to browser
DEBUG - 2019-07-12 01:00:31 --> Total execution time: 0.6398
INFO - 2019-07-12 01:00:32 --> Helper loaded: language_helper
INFO - 2019-07-12 01:00:32 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:00:32 --> Model Class Initialized
INFO - 2019-07-12 01:00:32 --> Model Class Initialized
INFO - 2019-07-12 01:00:32 --> Model Class Initialized
INFO - 2019-07-12 01:00:32 --> Model Class Initialized
INFO - 2019-07-12 01:00:32 --> Helper loaded: form_helper
INFO - 2019-07-12 01:00:32 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:00:32 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:00:32 --> Model Class Initialized
INFO - 2019-07-12 01:00:32 --> Model Class Initialized
INFO - 2019-07-12 01:00:32 --> Final output sent to browser
INFO - 2019-07-12 01:00:32 --> Helper loaded: language_helper
DEBUG - 2019-07-12 01:00:32 --> Total execution time: 0.8681
INFO - 2019-07-12 01:00:32 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:00:32 --> Model Class Initialized
INFO - 2019-07-12 01:00:32 --> Model Class Initialized
INFO - 2019-07-12 01:00:32 --> Model Class Initialized
INFO - 2019-07-12 01:00:32 --> Model Class Initialized
INFO - 2019-07-12 01:00:32 --> Helper loaded: form_helper
INFO - 2019-07-12 01:00:32 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:00:32 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:00:32 --> Model Class Initialized
INFO - 2019-07-12 01:00:32 --> Model Class Initialized
INFO - 2019-07-12 01:00:32 --> Final output sent to browser
DEBUG - 2019-07-12 01:00:32 --> Total execution time: 0.8306
INFO - 2019-07-12 01:00:58 --> Helper loaded: language_helper
INFO - 2019-07-12 01:00:58 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:00:58 --> Model Class Initialized
INFO - 2019-07-12 01:00:58 --> Model Class Initialized
INFO - 2019-07-12 01:00:58 --> Model Class Initialized
INFO - 2019-07-12 01:00:58 --> Model Class Initialized
INFO - 2019-07-12 01:00:59 --> Model Class Initialized
INFO - 2019-07-12 01:00:59 --> Final output sent to browser
DEBUG - 2019-07-12 01:00:59 --> Total execution time: 0.6664
INFO - 2019-07-12 01:00:59 --> Helper loaded: language_helper
INFO - 2019-07-12 01:00:59 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:00:59 --> Model Class Initialized
INFO - 2019-07-12 01:00:59 --> Model Class Initialized
INFO - 2019-07-12 01:00:59 --> Model Class Initialized
INFO - 2019-07-12 01:00:59 --> Model Class Initialized
INFO - 2019-07-12 01:00:59 --> Helper loaded: form_helper
INFO - 2019-07-12 01:00:59 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:00:59 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:00:59 --> Model Class Initialized
INFO - 2019-07-12 01:00:59 --> Model Class Initialized
INFO - 2019-07-12 01:00:59 --> Final output sent to browser
DEBUG - 2019-07-12 01:00:59 --> Total execution time: 0.6617
INFO - 2019-07-12 01:01:00 --> Helper loaded: language_helper
INFO - 2019-07-12 01:01:00 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:01:00 --> Model Class Initialized
INFO - 2019-07-12 01:01:00 --> Model Class Initialized
INFO - 2019-07-12 01:01:00 --> Model Class Initialized
INFO - 2019-07-12 01:01:00 --> Model Class Initialized
INFO - 2019-07-12 01:01:00 --> Helper loaded: form_helper
INFO - 2019-07-12 01:01:00 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:01:00 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:01:00 --> Model Class Initialized
INFO - 2019-07-12 01:01:00 --> Model Class Initialized
INFO - 2019-07-12 01:01:00 --> Final output sent to browser
DEBUG - 2019-07-12 01:01:00 --> Total execution time: 0.6326
INFO - 2019-07-12 01:01:46 --> Helper loaded: language_helper
INFO - 2019-07-12 01:01:46 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:01:46 --> Model Class Initialized
INFO - 2019-07-12 01:01:46 --> Model Class Initialized
INFO - 2019-07-12 01:01:46 --> Model Class Initialized
INFO - 2019-07-12 01:01:46 --> Model Class Initialized
INFO - 2019-07-12 01:01:46 --> Helper loaded: form_helper
INFO - 2019-07-12 01:01:46 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:01:46 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:01:46 --> Model Class Initialized
INFO - 2019-07-12 01:01:46 --> Model Class Initialized
INFO - 2019-07-12 01:01:46 --> Final output sent to browser
DEBUG - 2019-07-12 01:01:46 --> Total execution time: 0.8381
INFO - 2019-07-12 01:01:47 --> Helper loaded: language_helper
INFO - 2019-07-12 01:01:47 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:01:47 --> Model Class Initialized
INFO - 2019-07-12 01:01:47 --> Model Class Initialized
INFO - 2019-07-12 01:01:47 --> Model Class Initialized
INFO - 2019-07-12 01:01:47 --> Model Class Initialized
INFO - 2019-07-12 01:01:47 --> Model Class Initialized
INFO - 2019-07-12 01:01:47 --> Final output sent to browser
DEBUG - 2019-07-12 01:01:47 --> Total execution time: 0.6437
INFO - 2019-07-12 01:01:47 --> Helper loaded: language_helper
INFO - 2019-07-12 01:01:47 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:01:47 --> Model Class Initialized
INFO - 2019-07-12 01:01:47 --> Model Class Initialized
INFO - 2019-07-12 01:01:47 --> Model Class Initialized
INFO - 2019-07-12 01:01:47 --> Model Class Initialized
INFO - 2019-07-12 01:01:47 --> Helper loaded: form_helper
INFO - 2019-07-12 01:01:47 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:01:47 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:01:47 --> Model Class Initialized
INFO - 2019-07-12 01:01:47 --> Model Class Initialized
INFO - 2019-07-12 01:01:47 --> Final output sent to browser
DEBUG - 2019-07-12 01:01:47 --> Total execution time: 0.6563
INFO - 2019-07-12 01:01:51 --> Helper loaded: language_helper
INFO - 2019-07-12 01:01:51 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:01:51 --> Model Class Initialized
INFO - 2019-07-12 01:01:51 --> Model Class Initialized
INFO - 2019-07-12 01:01:51 --> Model Class Initialized
INFO - 2019-07-12 01:01:51 --> Model Class Initialized
INFO - 2019-07-12 01:01:51 --> Helper loaded: form_helper
INFO - 2019-07-12 01:01:51 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:01:51 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:01:51 --> Model Class Initialized
INFO - 2019-07-12 01:01:51 --> Model Class Initialized
INFO - 2019-07-12 01:01:51 --> Final output sent to browser
DEBUG - 2019-07-12 01:01:51 --> Total execution time: 0.6478
INFO - 2019-07-12 01:01:53 --> Helper loaded: language_helper
INFO - 2019-07-12 01:01:53 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:01:53 --> Model Class Initialized
INFO - 2019-07-12 01:01:53 --> Model Class Initialized
INFO - 2019-07-12 01:01:53 --> Model Class Initialized
INFO - 2019-07-12 01:01:53 --> Model Class Initialized
INFO - 2019-07-12 01:01:53 --> Helper loaded: form_helper
INFO - 2019-07-12 01:01:53 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:01:53 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:01:53 --> Model Class Initialized
INFO - 2019-07-12 01:01:53 --> Model Class Initialized
INFO - 2019-07-12 01:01:53 --> Final output sent to browser
DEBUG - 2019-07-12 01:01:53 --> Total execution time: 0.6315
INFO - 2019-07-12 01:01:53 --> Helper loaded: language_helper
INFO - 2019-07-12 01:01:53 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:01:53 --> Model Class Initialized
INFO - 2019-07-12 01:01:53 --> Model Class Initialized
INFO - 2019-07-12 01:01:53 --> Model Class Initialized
INFO - 2019-07-12 01:01:53 --> Model Class Initialized
INFO - 2019-07-12 01:01:53 --> Helper loaded: form_helper
INFO - 2019-07-12 01:01:53 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:01:53 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:01:53 --> Model Class Initialized
INFO - 2019-07-12 01:01:53 --> Model Class Initialized
INFO - 2019-07-12 01:01:53 --> Final output sent to browser
DEBUG - 2019-07-12 01:01:53 --> Total execution time: 0.6639
INFO - 2019-07-12 01:02:08 --> Helper loaded: language_helper
INFO - 2019-07-12 01:02:08 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:02:08 --> Model Class Initialized
INFO - 2019-07-12 01:02:08 --> Model Class Initialized
INFO - 2019-07-12 01:02:08 --> Model Class Initialized
INFO - 2019-07-12 01:02:08 --> Model Class Initialized
INFO - 2019-07-12 01:02:08 --> Model Class Initialized
INFO - 2019-07-12 01:02:08 --> Helper loaded: language_helper
INFO - 2019-07-12 01:02:08 --> Final output sent to browser
INFO - 2019-07-12 01:02:08 --> Language file loaded: language/english/general_lang.php
DEBUG - 2019-07-12 01:02:08 --> Total execution time: 0.8748
INFO - 2019-07-12 01:02:08 --> Model Class Initialized
INFO - 2019-07-12 01:02:08 --> Model Class Initialized
INFO - 2019-07-12 01:02:08 --> Model Class Initialized
INFO - 2019-07-12 01:02:08 --> Model Class Initialized
INFO - 2019-07-12 01:02:08 --> Helper loaded: form_helper
INFO - 2019-07-12 01:02:08 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:02:08 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:02:08 --> Model Class Initialized
INFO - 2019-07-12 01:02:08 --> Model Class Initialized
INFO - 2019-07-12 01:02:08 --> Final output sent to browser
DEBUG - 2019-07-12 01:02:08 --> Total execution time: 0.9539
INFO - 2019-07-12 01:02:09 --> Helper loaded: language_helper
INFO - 2019-07-12 01:02:09 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:02:09 --> Model Class Initialized
INFO - 2019-07-12 01:02:09 --> Model Class Initialized
INFO - 2019-07-12 01:02:09 --> Model Class Initialized
INFO - 2019-07-12 01:02:09 --> Model Class Initialized
INFO - 2019-07-12 01:02:09 --> Helper loaded: form_helper
INFO - 2019-07-12 01:02:09 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:02:09 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:02:09 --> Model Class Initialized
INFO - 2019-07-12 01:02:09 --> Model Class Initialized
INFO - 2019-07-12 01:02:09 --> Final output sent to browser
DEBUG - 2019-07-12 01:02:09 --> Total execution time: 0.7525
INFO - 2019-07-12 01:02:20 --> Helper loaded: language_helper
INFO - 2019-07-12 01:02:20 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:02:20 --> Model Class Initialized
INFO - 2019-07-12 01:02:20 --> Model Class Initialized
INFO - 2019-07-12 01:02:20 --> Model Class Initialized
INFO - 2019-07-12 01:02:20 --> Model Class Initialized
INFO - 2019-07-12 01:02:20 --> Model Class Initialized
INFO - 2019-07-12 01:02:20 --> Final output sent to browser
DEBUG - 2019-07-12 01:02:20 --> Total execution time: 0.5902
INFO - 2019-07-12 01:02:21 --> Helper loaded: language_helper
INFO - 2019-07-12 01:02:21 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:02:21 --> Model Class Initialized
INFO - 2019-07-12 01:02:21 --> Model Class Initialized
INFO - 2019-07-12 01:02:21 --> Model Class Initialized
INFO - 2019-07-12 01:02:21 --> Model Class Initialized
INFO - 2019-07-12 01:02:21 --> Helper loaded: form_helper
INFO - 2019-07-12 01:02:21 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:02:21 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:02:21 --> Model Class Initialized
INFO - 2019-07-12 01:02:21 --> Model Class Initialized
INFO - 2019-07-12 01:02:21 --> Final output sent to browser
DEBUG - 2019-07-12 01:02:21 --> Total execution time: 0.7063
INFO - 2019-07-12 01:02:24 --> Helper loaded: language_helper
INFO - 2019-07-12 01:02:24 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:02:24 --> Model Class Initialized
INFO - 2019-07-12 01:02:24 --> Model Class Initialized
INFO - 2019-07-12 01:02:24 --> Model Class Initialized
INFO - 2019-07-12 01:02:24 --> Model Class Initialized
INFO - 2019-07-12 01:02:24 --> Helper loaded: form_helper
INFO - 2019-07-12 01:02:24 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:02:24 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:02:24 --> Model Class Initialized
INFO - 2019-07-12 01:02:24 --> Model Class Initialized
INFO - 2019-07-12 01:02:24 --> Final output sent to browser
DEBUG - 2019-07-12 01:02:24 --> Total execution time: 0.6826
INFO - 2019-07-12 01:02:26 --> Helper loaded: language_helper
INFO - 2019-07-12 01:02:26 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:02:26 --> Model Class Initialized
INFO - 2019-07-12 01:02:26 --> Model Class Initialized
INFO - 2019-07-12 01:02:26 --> Model Class Initialized
INFO - 2019-07-12 01:02:26 --> Model Class Initialized
INFO - 2019-07-12 01:02:26 --> Helper loaded: form_helper
INFO - 2019-07-12 01:02:26 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:02:26 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:02:26 --> Model Class Initialized
INFO - 2019-07-12 01:02:26 --> Model Class Initialized
INFO - 2019-07-12 01:02:26 --> Final output sent to browser
DEBUG - 2019-07-12 01:02:26 --> Total execution time: 0.6765
INFO - 2019-07-12 01:02:26 --> Helper loaded: language_helper
INFO - 2019-07-12 01:02:26 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:02:26 --> Model Class Initialized
INFO - 2019-07-12 01:02:26 --> Model Class Initialized
INFO - 2019-07-12 01:02:27 --> Model Class Initialized
INFO - 2019-07-12 01:02:27 --> Model Class Initialized
INFO - 2019-07-12 01:02:27 --> Helper loaded: form_helper
INFO - 2019-07-12 01:02:27 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:02:27 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:02:27 --> Model Class Initialized
INFO - 2019-07-12 01:02:27 --> Model Class Initialized
INFO - 2019-07-12 01:02:27 --> Final output sent to browser
DEBUG - 2019-07-12 01:02:27 --> Total execution time: 0.7493
INFO - 2019-07-12 01:03:50 --> Helper loaded: language_helper
INFO - 2019-07-12 01:03:50 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:03:50 --> Model Class Initialized
INFO - 2019-07-12 01:03:50 --> Model Class Initialized
INFO - 2019-07-12 01:03:50 --> Model Class Initialized
INFO - 2019-07-12 01:03:50 --> Model Class Initialized
INFO - 2019-07-12 01:03:50 --> Model Class Initialized
INFO - 2019-07-12 01:03:50 --> Final output sent to browser
DEBUG - 2019-07-12 01:03:50 --> Total execution time: 0.6310
INFO - 2019-07-12 01:03:51 --> Helper loaded: language_helper
INFO - 2019-07-12 01:03:51 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:03:51 --> Model Class Initialized
INFO - 2019-07-12 01:03:51 --> Model Class Initialized
INFO - 2019-07-12 01:03:51 --> Model Class Initialized
INFO - 2019-07-12 01:03:51 --> Model Class Initialized
INFO - 2019-07-12 01:03:51 --> Helper loaded: language_helper
INFO - 2019-07-12 01:03:51 --> Helper loaded: form_helper
INFO - 2019-07-12 01:03:51 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:03:51 --> Form Validation Class Initialized
INFO - 2019-07-12 01:03:51 --> Model Class Initialized
DEBUG - 2019-07-12 01:03:51 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:03:51 --> Model Class Initialized
INFO - 2019-07-12 01:03:51 --> Model Class Initialized
INFO - 2019-07-12 01:03:51 --> Model Class Initialized
INFO - 2019-07-12 01:03:51 --> Model Class Initialized
INFO - 2019-07-12 01:03:51 --> Model Class Initialized
INFO - 2019-07-12 01:03:51 --> Final output sent to browser
INFO - 2019-07-12 01:03:51 --> Helper loaded: form_helper
DEBUG - 2019-07-12 01:03:51 --> Total execution time: 1.0310
INFO - 2019-07-12 01:03:51 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:03:51 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:03:51 --> Model Class Initialized
INFO - 2019-07-12 01:03:51 --> Model Class Initialized
INFO - 2019-07-12 01:03:51 --> Final output sent to browser
DEBUG - 2019-07-12 01:03:51 --> Total execution time: 0.9986
INFO - 2019-07-12 01:04:50 --> Helper loaded: language_helper
INFO - 2019-07-12 01:04:50 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:04:50 --> Model Class Initialized
INFO - 2019-07-12 01:04:50 --> Model Class Initialized
INFO - 2019-07-12 01:04:50 --> Model Class Initialized
INFO - 2019-07-12 01:04:50 --> Model Class Initialized
INFO - 2019-07-12 01:04:50 --> Model Class Initialized
INFO - 2019-07-12 01:04:50 --> Final output sent to browser
DEBUG - 2019-07-12 01:04:50 --> Total execution time: 0.6389
INFO - 2019-07-12 01:04:51 --> Helper loaded: language_helper
INFO - 2019-07-12 01:04:51 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:04:51 --> Model Class Initialized
INFO - 2019-07-12 01:04:51 --> Model Class Initialized
INFO - 2019-07-12 01:04:51 --> Model Class Initialized
INFO - 2019-07-12 01:04:51 --> Model Class Initialized
INFO - 2019-07-12 01:04:51 --> Helper loaded: form_helper
INFO - 2019-07-12 01:04:51 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:04:51 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:04:51 --> Model Class Initialized
INFO - 2019-07-12 01:04:51 --> Model Class Initialized
INFO - 2019-07-12 01:04:51 --> Final output sent to browser
DEBUG - 2019-07-12 01:04:51 --> Total execution time: 0.7868
INFO - 2019-07-12 01:04:52 --> Helper loaded: language_helper
INFO - 2019-07-12 01:04:52 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:04:52 --> Model Class Initialized
INFO - 2019-07-12 01:04:52 --> Model Class Initialized
INFO - 2019-07-12 01:04:52 --> Model Class Initialized
INFO - 2019-07-12 01:04:52 --> Model Class Initialized
INFO - 2019-07-12 01:04:52 --> Helper loaded: form_helper
INFO - 2019-07-12 01:04:52 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:04:52 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:04:52 --> Model Class Initialized
INFO - 2019-07-12 01:04:52 --> Model Class Initialized
INFO - 2019-07-12 01:04:52 --> Final output sent to browser
DEBUG - 2019-07-12 01:04:52 --> Total execution time: 0.6879
INFO - 2019-07-12 01:04:53 --> Helper loaded: language_helper
INFO - 2019-07-12 01:04:53 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:04:53 --> Model Class Initialized
INFO - 2019-07-12 01:04:53 --> Model Class Initialized
INFO - 2019-07-12 01:04:53 --> Model Class Initialized
INFO - 2019-07-12 01:04:53 --> Model Class Initialized
INFO - 2019-07-12 01:04:53 --> Model Class Initialized
INFO - 2019-07-12 01:04:54 --> Final output sent to browser
DEBUG - 2019-07-12 01:04:54 --> Total execution time: 0.5908
INFO - 2019-07-12 01:04:54 --> Helper loaded: language_helper
INFO - 2019-07-12 01:04:54 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:04:54 --> Model Class Initialized
INFO - 2019-07-12 01:04:54 --> Model Class Initialized
INFO - 2019-07-12 01:04:54 --> Model Class Initialized
INFO - 2019-07-12 01:04:54 --> Model Class Initialized
INFO - 2019-07-12 01:04:54 --> Helper loaded: form_helper
INFO - 2019-07-12 01:04:54 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:04:54 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:04:54 --> Model Class Initialized
INFO - 2019-07-12 01:04:54 --> Model Class Initialized
INFO - 2019-07-12 01:04:54 --> Final output sent to browser
DEBUG - 2019-07-12 01:04:54 --> Total execution time: 0.7147
INFO - 2019-07-12 01:04:56 --> Helper loaded: language_helper
INFO - 2019-07-12 01:04:56 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:04:56 --> Model Class Initialized
INFO - 2019-07-12 01:04:56 --> Model Class Initialized
INFO - 2019-07-12 01:04:56 --> Model Class Initialized
INFO - 2019-07-12 01:04:56 --> Model Class Initialized
INFO - 2019-07-12 01:04:56 --> Helper loaded: form_helper
INFO - 2019-07-12 01:04:56 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:04:56 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:04:56 --> Model Class Initialized
INFO - 2019-07-12 01:04:56 --> Model Class Initialized
INFO - 2019-07-12 01:04:56 --> Final output sent to browser
DEBUG - 2019-07-12 01:04:56 --> Total execution time: 0.7012
INFO - 2019-07-12 01:05:27 --> Helper loaded: language_helper
INFO - 2019-07-12 01:05:27 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:05:27 --> Model Class Initialized
INFO - 2019-07-12 01:05:27 --> Model Class Initialized
INFO - 2019-07-12 01:05:27 --> Model Class Initialized
INFO - 2019-07-12 01:05:27 --> Model Class Initialized
INFO - 2019-07-12 01:05:27 --> Model Class Initialized
INFO - 2019-07-12 01:05:27 --> Final output sent to browser
DEBUG - 2019-07-12 01:05:27 --> Total execution time: 0.6274
INFO - 2019-07-12 01:05:27 --> Helper loaded: language_helper
INFO - 2019-07-12 01:05:27 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:05:27 --> Model Class Initialized
INFO - 2019-07-12 01:05:27 --> Model Class Initialized
INFO - 2019-07-12 01:05:27 --> Model Class Initialized
INFO - 2019-07-12 01:05:27 --> Model Class Initialized
INFO - 2019-07-12 01:05:27 --> Helper loaded: form_helper
INFO - 2019-07-12 01:05:27 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:05:27 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:05:27 --> Model Class Initialized
INFO - 2019-07-12 01:05:27 --> Model Class Initialized
INFO - 2019-07-12 01:05:27 --> Final output sent to browser
DEBUG - 2019-07-12 01:05:28 --> Total execution time: 0.7417
INFO - 2019-07-12 01:05:29 --> Helper loaded: language_helper
INFO - 2019-07-12 01:05:29 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:05:29 --> Model Class Initialized
INFO - 2019-07-12 01:05:29 --> Model Class Initialized
INFO - 2019-07-12 01:05:29 --> Model Class Initialized
INFO - 2019-07-12 01:05:29 --> Model Class Initialized
INFO - 2019-07-12 01:05:29 --> Helper loaded: form_helper
INFO - 2019-07-12 01:05:29 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:05:29 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:05:29 --> Model Class Initialized
INFO - 2019-07-12 01:05:29 --> Model Class Initialized
INFO - 2019-07-12 01:05:29 --> Final output sent to browser
DEBUG - 2019-07-12 01:05:29 --> Total execution time: 0.6942
INFO - 2019-07-12 01:05:40 --> Helper loaded: language_helper
INFO - 2019-07-12 01:05:40 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:05:40 --> Model Class Initialized
INFO - 2019-07-12 01:05:40 --> Model Class Initialized
INFO - 2019-07-12 01:05:40 --> Model Class Initialized
INFO - 2019-07-12 01:05:40 --> Model Class Initialized
INFO - 2019-07-12 01:05:40 --> Model Class Initialized
INFO - 2019-07-12 01:05:40 --> Final output sent to browser
DEBUG - 2019-07-12 01:05:40 --> Total execution time: 0.6104
INFO - 2019-07-12 01:05:41 --> Helper loaded: language_helper
INFO - 2019-07-12 01:05:41 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:05:41 --> Model Class Initialized
INFO - 2019-07-12 01:05:41 --> Model Class Initialized
INFO - 2019-07-12 01:05:41 --> Model Class Initialized
INFO - 2019-07-12 01:05:41 --> Model Class Initialized
INFO - 2019-07-12 01:05:41 --> Helper loaded: form_helper
INFO - 2019-07-12 01:05:41 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:05:41 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:05:41 --> Model Class Initialized
INFO - 2019-07-12 01:05:41 --> Model Class Initialized
INFO - 2019-07-12 01:05:41 --> Final output sent to browser
DEBUG - 2019-07-12 01:05:41 --> Total execution time: 0.7402
INFO - 2019-07-12 01:05:42 --> Helper loaded: language_helper
INFO - 2019-07-12 01:05:42 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:05:42 --> Model Class Initialized
INFO - 2019-07-12 01:05:42 --> Model Class Initialized
INFO - 2019-07-12 01:05:42 --> Model Class Initialized
INFO - 2019-07-12 01:05:42 --> Model Class Initialized
INFO - 2019-07-12 01:05:42 --> Helper loaded: form_helper
INFO - 2019-07-12 01:05:42 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:05:42 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:05:42 --> Model Class Initialized
INFO - 2019-07-12 01:05:42 --> Model Class Initialized
INFO - 2019-07-12 01:05:42 --> Final output sent to browser
DEBUG - 2019-07-12 01:05:42 --> Total execution time: 0.6950
INFO - 2019-07-12 01:05:44 --> Helper loaded: language_helper
INFO - 2019-07-12 01:05:44 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:05:44 --> Model Class Initialized
INFO - 2019-07-12 01:05:44 --> Model Class Initialized
INFO - 2019-07-12 01:05:44 --> Model Class Initialized
INFO - 2019-07-12 01:05:44 --> Model Class Initialized
INFO - 2019-07-12 01:05:44 --> Helper loaded: form_helper
INFO - 2019-07-12 01:05:44 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:05:44 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:05:44 --> Model Class Initialized
INFO - 2019-07-12 01:05:44 --> Model Class Initialized
INFO - 2019-07-12 01:05:44 --> Final output sent to browser
DEBUG - 2019-07-12 01:05:44 --> Total execution time: 0.6492
INFO - 2019-07-12 01:05:45 --> Helper loaded: language_helper
INFO - 2019-07-12 01:05:45 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:05:45 --> Model Class Initialized
INFO - 2019-07-12 01:05:45 --> Model Class Initialized
INFO - 2019-07-12 01:05:45 --> Model Class Initialized
INFO - 2019-07-12 01:05:45 --> Model Class Initialized
INFO - 2019-07-12 01:05:45 --> Helper loaded: form_helper
INFO - 2019-07-12 01:05:45 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:05:45 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:05:45 --> Model Class Initialized
INFO - 2019-07-12 01:05:45 --> Model Class Initialized
INFO - 2019-07-12 01:05:45 --> Final output sent to browser
DEBUG - 2019-07-12 01:05:45 --> Total execution time: 0.7125
INFO - 2019-07-12 01:05:50 --> Helper loaded: language_helper
INFO - 2019-07-12 01:05:50 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:05:50 --> Model Class Initialized
INFO - 2019-07-12 01:05:50 --> Model Class Initialized
INFO - 2019-07-12 01:05:50 --> Model Class Initialized
INFO - 2019-07-12 01:05:50 --> Model Class Initialized
INFO - 2019-07-12 01:05:50 --> Model Class Initialized
INFO - 2019-07-12 01:05:50 --> Final output sent to browser
DEBUG - 2019-07-12 01:05:50 --> Total execution time: 0.6147
INFO - 2019-07-12 01:05:50 --> Helper loaded: language_helper
INFO - 2019-07-12 01:05:50 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:05:50 --> Model Class Initialized
INFO - 2019-07-12 01:05:50 --> Model Class Initialized
INFO - 2019-07-12 01:05:50 --> Model Class Initialized
INFO - 2019-07-12 01:05:50 --> Model Class Initialized
INFO - 2019-07-12 01:05:50 --> Helper loaded: form_helper
INFO - 2019-07-12 01:05:50 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:05:51 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:05:51 --> Model Class Initialized
INFO - 2019-07-12 01:05:51 --> Model Class Initialized
INFO - 2019-07-12 01:05:51 --> Final output sent to browser
DEBUG - 2019-07-12 01:05:51 --> Total execution time: 0.7087
INFO - 2019-07-12 01:06:26 --> Helper loaded: language_helper
INFO - 2019-07-12 01:06:26 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:06:26 --> Model Class Initialized
INFO - 2019-07-12 01:06:26 --> Model Class Initialized
INFO - 2019-07-12 01:06:26 --> Model Class Initialized
INFO - 2019-07-12 01:06:26 --> Model Class Initialized
INFO - 2019-07-12 01:06:26 --> Model Class Initialized
INFO - 2019-07-12 01:06:26 --> Final output sent to browser
DEBUG - 2019-07-12 01:06:26 --> Total execution time: 0.7451
INFO - 2019-07-12 01:06:27 --> Helper loaded: language_helper
INFO - 2019-07-12 01:06:27 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:06:27 --> Model Class Initialized
INFO - 2019-07-12 01:06:27 --> Model Class Initialized
INFO - 2019-07-12 01:06:27 --> Model Class Initialized
INFO - 2019-07-12 01:06:27 --> Model Class Initialized
INFO - 2019-07-12 01:06:27 --> Helper loaded: form_helper
INFO - 2019-07-12 01:06:27 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:06:27 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:06:27 --> Model Class Initialized
INFO - 2019-07-12 01:06:27 --> Model Class Initialized
INFO - 2019-07-12 01:06:27 --> Final output sent to browser
DEBUG - 2019-07-12 01:06:27 --> Total execution time: 0.9163
INFO - 2019-07-12 01:06:27 --> Helper loaded: language_helper
INFO - 2019-07-12 01:06:27 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:06:27 --> Model Class Initialized
INFO - 2019-07-12 01:06:27 --> Model Class Initialized
INFO - 2019-07-12 01:06:27 --> Model Class Initialized
INFO - 2019-07-12 01:06:27 --> Model Class Initialized
INFO - 2019-07-12 01:06:27 --> Helper loaded: form_helper
INFO - 2019-07-12 01:06:27 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:06:27 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:06:27 --> Model Class Initialized
INFO - 2019-07-12 01:06:27 --> Model Class Initialized
INFO - 2019-07-12 01:06:27 --> Final output sent to browser
DEBUG - 2019-07-12 01:06:27 --> Total execution time: 0.8878
INFO - 2019-07-12 01:06:53 --> Helper loaded: language_helper
INFO - 2019-07-12 01:06:53 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:06:53 --> Model Class Initialized
INFO - 2019-07-12 01:06:53 --> Model Class Initialized
INFO - 2019-07-12 01:06:53 --> Model Class Initialized
INFO - 2019-07-12 01:06:53 --> Model Class Initialized
INFO - 2019-07-12 01:06:53 --> Model Class Initialized
INFO - 2019-07-12 01:06:53 --> Final output sent to browser
DEBUG - 2019-07-12 01:06:53 --> Total execution time: 0.6348
INFO - 2019-07-12 01:06:54 --> Helper loaded: language_helper
INFO - 2019-07-12 01:06:54 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:06:54 --> Model Class Initialized
INFO - 2019-07-12 01:06:54 --> Model Class Initialized
INFO - 2019-07-12 01:06:54 --> Model Class Initialized
INFO - 2019-07-12 01:06:54 --> Model Class Initialized
INFO - 2019-07-12 01:06:54 --> Helper loaded: form_helper
INFO - 2019-07-12 01:06:54 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:06:54 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:06:54 --> Model Class Initialized
INFO - 2019-07-12 01:06:54 --> Model Class Initialized
INFO - 2019-07-12 01:06:54 --> Final output sent to browser
DEBUG - 2019-07-12 01:06:54 --> Total execution time: 0.7687
INFO - 2019-07-12 01:06:55 --> Helper loaded: language_helper
INFO - 2019-07-12 01:06:55 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:06:55 --> Model Class Initialized
INFO - 2019-07-12 01:06:55 --> Model Class Initialized
INFO - 2019-07-12 01:06:55 --> Model Class Initialized
INFO - 2019-07-12 01:06:55 --> Model Class Initialized
INFO - 2019-07-12 01:06:55 --> Helper loaded: form_helper
INFO - 2019-07-12 01:06:55 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:06:55 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:06:55 --> Model Class Initialized
INFO - 2019-07-12 01:06:55 --> Model Class Initialized
INFO - 2019-07-12 01:06:55 --> Final output sent to browser
DEBUG - 2019-07-12 01:06:55 --> Total execution time: 0.6978
INFO - 2019-07-12 01:08:11 --> Helper loaded: language_helper
INFO - 2019-07-12 01:08:11 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:08:11 --> Model Class Initialized
INFO - 2019-07-12 01:08:11 --> Model Class Initialized
INFO - 2019-07-12 01:08:11 --> Model Class Initialized
INFO - 2019-07-12 01:08:11 --> Model Class Initialized
INFO - 2019-07-12 01:08:11 --> Helper loaded: language_helper
INFO - 2019-07-12 01:08:11 --> Helper loaded: form_helper
INFO - 2019-07-12 01:08:11 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:08:11 --> Form Validation Class Initialized
INFO - 2019-07-12 01:08:11 --> Model Class Initialized
DEBUG - 2019-07-12 01:08:11 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:08:11 --> Model Class Initialized
INFO - 2019-07-12 01:08:11 --> Model Class Initialized
INFO - 2019-07-12 01:08:11 --> Model Class Initialized
INFO - 2019-07-12 01:08:11 --> Model Class Initialized
INFO - 2019-07-12 01:08:11 --> Model Class Initialized
INFO - 2019-07-12 01:08:11 --> Final output sent to browser
INFO - 2019-07-12 01:08:11 --> Model Class Initialized
DEBUG - 2019-07-12 01:08:11 --> Total execution time: 1.1323
INFO - 2019-07-12 01:08:11 --> Final output sent to browser
DEBUG - 2019-07-12 01:08:11 --> Total execution time: 0.9187
INFO - 2019-07-12 01:08:12 --> Helper loaded: language_helper
INFO - 2019-07-12 01:08:12 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:08:12 --> Model Class Initialized
INFO - 2019-07-12 01:08:12 --> Model Class Initialized
INFO - 2019-07-12 01:08:12 --> Model Class Initialized
INFO - 2019-07-12 01:08:12 --> Model Class Initialized
INFO - 2019-07-12 01:08:12 --> Helper loaded: form_helper
INFO - 2019-07-12 01:08:12 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:08:12 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:08:12 --> Model Class Initialized
INFO - 2019-07-12 01:08:12 --> Model Class Initialized
INFO - 2019-07-12 01:08:12 --> Final output sent to browser
DEBUG - 2019-07-12 01:08:12 --> Total execution time: 0.7048
INFO - 2019-07-12 01:08:56 --> Helper loaded: language_helper
INFO - 2019-07-12 01:08:56 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:08:56 --> Model Class Initialized
INFO - 2019-07-12 01:08:56 --> Model Class Initialized
INFO - 2019-07-12 01:08:56 --> Model Class Initialized
INFO - 2019-07-12 01:08:56 --> Model Class Initialized
INFO - 2019-07-12 01:08:56 --> Model Class Initialized
INFO - 2019-07-12 01:08:56 --> Final output sent to browser
DEBUG - 2019-07-12 01:08:56 --> Total execution time: 0.7564
INFO - 2019-07-12 01:08:57 --> Helper loaded: language_helper
INFO - 2019-07-12 01:08:57 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:08:57 --> Model Class Initialized
INFO - 2019-07-12 01:08:57 --> Model Class Initialized
INFO - 2019-07-12 01:08:57 --> Model Class Initialized
INFO - 2019-07-12 01:08:57 --> Model Class Initialized
INFO - 2019-07-12 01:08:57 --> Helper loaded: form_helper
INFO - 2019-07-12 01:08:57 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:08:57 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:08:57 --> Model Class Initialized
INFO - 2019-07-12 01:08:57 --> Helper loaded: language_helper
INFO - 2019-07-12 01:08:57 --> Model Class Initialized
INFO - 2019-07-12 01:08:57 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:08:57 --> Final output sent to browser
INFO - 2019-07-12 01:08:57 --> Model Class Initialized
DEBUG - 2019-07-12 01:08:57 --> Total execution time: 0.9602
INFO - 2019-07-12 01:08:57 --> Model Class Initialized
INFO - 2019-07-12 01:08:57 --> Model Class Initialized
INFO - 2019-07-12 01:08:57 --> Model Class Initialized
INFO - 2019-07-12 01:08:57 --> Helper loaded: form_helper
INFO - 2019-07-12 01:08:57 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:08:57 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:08:57 --> Model Class Initialized
INFO - 2019-07-12 01:08:57 --> Model Class Initialized
INFO - 2019-07-12 01:08:57 --> Final output sent to browser
DEBUG - 2019-07-12 01:08:57 --> Total execution time: 0.9442
INFO - 2019-07-12 01:09:14 --> Helper loaded: language_helper
INFO - 2019-07-12 01:09:14 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:09:14 --> Model Class Initialized
INFO - 2019-07-12 01:09:14 --> Model Class Initialized
INFO - 2019-07-12 01:09:14 --> Model Class Initialized
INFO - 2019-07-12 01:09:14 --> Model Class Initialized
INFO - 2019-07-12 01:09:14 --> Model Class Initialized
INFO - 2019-07-12 01:09:14 --> Final output sent to browser
DEBUG - 2019-07-12 01:09:14 --> Total execution time: 0.6759
INFO - 2019-07-12 01:09:15 --> Helper loaded: language_helper
INFO - 2019-07-12 01:09:15 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:09:15 --> Model Class Initialized
INFO - 2019-07-12 01:09:15 --> Model Class Initialized
INFO - 2019-07-12 01:09:15 --> Model Class Initialized
INFO - 2019-07-12 01:09:15 --> Model Class Initialized
INFO - 2019-07-12 01:09:15 --> Helper loaded: form_helper
INFO - 2019-07-12 01:09:15 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:09:15 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:09:15 --> Model Class Initialized
INFO - 2019-07-12 01:09:15 --> Model Class Initialized
INFO - 2019-07-12 01:09:15 --> Final output sent to browser
DEBUG - 2019-07-12 01:09:15 --> Total execution time: 0.7571
INFO - 2019-07-12 01:09:16 --> Helper loaded: language_helper
INFO - 2019-07-12 01:09:16 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:09:16 --> Model Class Initialized
INFO - 2019-07-12 01:09:16 --> Model Class Initialized
INFO - 2019-07-12 01:09:16 --> Model Class Initialized
INFO - 2019-07-12 01:09:16 --> Model Class Initialized
INFO - 2019-07-12 01:09:16 --> Helper loaded: form_helper
INFO - 2019-07-12 01:09:16 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:09:16 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:09:16 --> Model Class Initialized
INFO - 2019-07-12 01:09:16 --> Model Class Initialized
INFO - 2019-07-12 01:09:16 --> Final output sent to browser
DEBUG - 2019-07-12 01:09:16 --> Total execution time: 0.7023
INFO - 2019-07-12 01:09:33 --> Helper loaded: language_helper
INFO - 2019-07-12 01:09:33 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:09:33 --> Model Class Initialized
INFO - 2019-07-12 01:09:33 --> Model Class Initialized
INFO - 2019-07-12 01:09:33 --> Model Class Initialized
INFO - 2019-07-12 01:09:33 --> Model Class Initialized
INFO - 2019-07-12 01:09:33 --> Helper loaded: form_helper
INFO - 2019-07-12 01:09:33 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:09:33 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:09:33 --> Model Class Initialized
INFO - 2019-07-12 01:09:33 --> Model Class Initialized
INFO - 2019-07-12 01:09:33 --> Final output sent to browser
DEBUG - 2019-07-12 01:09:33 --> Total execution time: 0.7041
INFO - 2019-07-12 01:09:35 --> Helper loaded: language_helper
INFO - 2019-07-12 01:09:35 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:09:36 --> Model Class Initialized
INFO - 2019-07-12 01:09:36 --> Model Class Initialized
INFO - 2019-07-12 01:09:36 --> Model Class Initialized
INFO - 2019-07-12 01:09:36 --> Model Class Initialized
INFO - 2019-07-12 01:09:36 --> Helper loaded: form_helper
INFO - 2019-07-12 01:09:36 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:09:36 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:09:36 --> Model Class Initialized
INFO - 2019-07-12 01:09:36 --> Model Class Initialized
INFO - 2019-07-12 01:09:36 --> Final output sent to browser
DEBUG - 2019-07-12 01:09:36 --> Total execution time: 0.6558
INFO - 2019-07-12 01:09:36 --> Helper loaded: language_helper
INFO - 2019-07-12 01:09:36 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:09:36 --> Model Class Initialized
INFO - 2019-07-12 01:09:36 --> Model Class Initialized
INFO - 2019-07-12 01:09:36 --> Model Class Initialized
INFO - 2019-07-12 01:09:36 --> Model Class Initialized
INFO - 2019-07-12 01:09:36 --> Helper loaded: form_helper
INFO - 2019-07-12 01:09:36 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:09:36 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:09:36 --> Model Class Initialized
INFO - 2019-07-12 01:09:36 --> Model Class Initialized
INFO - 2019-07-12 01:09:36 --> Final output sent to browser
DEBUG - 2019-07-12 01:09:36 --> Total execution time: 0.7312
INFO - 2019-07-12 01:10:05 --> Helper loaded: language_helper
INFO - 2019-07-12 01:10:05 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:10:05 --> Model Class Initialized
INFO - 2019-07-12 01:10:05 --> Model Class Initialized
INFO - 2019-07-12 01:10:05 --> Model Class Initialized
INFO - 2019-07-12 01:10:05 --> Model Class Initialized
INFO - 2019-07-12 01:10:05 --> Helper loaded: form_helper
INFO - 2019-07-12 01:10:05 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:10:05 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:10:05 --> Model Class Initialized
INFO - 2019-07-12 01:10:05 --> Model Class Initialized
INFO - 2019-07-12 01:10:05 --> Final output sent to browser
DEBUG - 2019-07-12 01:10:05 --> Total execution time: 0.7173
INFO - 2019-07-12 01:10:07 --> Helper loaded: language_helper
INFO - 2019-07-12 01:10:07 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:10:07 --> Model Class Initialized
INFO - 2019-07-12 01:10:07 --> Model Class Initialized
INFO - 2019-07-12 01:10:07 --> Model Class Initialized
INFO - 2019-07-12 01:10:07 --> Model Class Initialized
INFO - 2019-07-12 01:10:07 --> Helper loaded: form_helper
INFO - 2019-07-12 01:10:07 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:10:07 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:10:07 --> Model Class Initialized
INFO - 2019-07-12 01:10:07 --> Model Class Initialized
INFO - 2019-07-12 01:10:08 --> Final output sent to browser
DEBUG - 2019-07-12 01:10:08 --> Total execution time: 0.7169
INFO - 2019-07-12 01:12:27 --> Helper loaded: language_helper
INFO - 2019-07-12 01:12:27 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:12:27 --> Model Class Initialized
INFO - 2019-07-12 01:12:27 --> Model Class Initialized
INFO - 2019-07-12 01:12:27 --> Model Class Initialized
INFO - 2019-07-12 01:12:27 --> Model Class Initialized
INFO - 2019-07-12 01:12:27 --> Model Class Initialized
INFO - 2019-07-12 01:12:27 --> Final output sent to browser
DEBUG - 2019-07-12 01:12:27 --> Total execution time: 0.7713
INFO - 2019-07-12 01:12:28 --> Helper loaded: language_helper
INFO - 2019-07-12 01:12:28 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:12:28 --> Helper loaded: language_helper
INFO - 2019-07-12 01:12:28 --> Model Class Initialized
INFO - 2019-07-12 01:12:28 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:12:28 --> Model Class Initialized
INFO - 2019-07-12 01:12:28 --> Model Class Initialized
INFO - 2019-07-12 01:12:28 --> Model Class Initialized
INFO - 2019-07-12 01:12:28 --> Model Class Initialized
INFO - 2019-07-12 01:12:28 --> Model Class Initialized
INFO - 2019-07-12 01:12:28 --> Model Class Initialized
INFO - 2019-07-12 01:12:28 --> Helper loaded: form_helper
INFO - 2019-07-12 01:12:28 --> Model Class Initialized
INFO - 2019-07-12 01:12:28 --> Form Validation Class Initialized
INFO - 2019-07-12 01:12:28 --> Helper loaded: form_helper
DEBUG - 2019-07-12 01:12:28 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:12:28 --> Form Validation Class Initialized
INFO - 2019-07-12 01:12:28 --> Model Class Initialized
DEBUG - 2019-07-12 01:12:28 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:12:28 --> Model Class Initialized
INFO - 2019-07-12 01:12:28 --> Model Class Initialized
INFO - 2019-07-12 01:12:28 --> Final output sent to browser
INFO - 2019-07-12 01:12:28 --> Model Class Initialized
DEBUG - 2019-07-12 01:12:28 --> Total execution time: 1.2665
INFO - 2019-07-12 01:12:28 --> Final output sent to browser
DEBUG - 2019-07-12 01:12:28 --> Total execution time: 1.2248
INFO - 2019-07-12 01:12:30 --> Helper loaded: language_helper
INFO - 2019-07-12 01:12:30 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:12:30 --> Model Class Initialized
INFO - 2019-07-12 01:12:30 --> Model Class Initialized
INFO - 2019-07-12 01:12:30 --> Model Class Initialized
INFO - 2019-07-12 01:12:30 --> Model Class Initialized
INFO - 2019-07-12 01:12:30 --> Model Class Initialized
INFO - 2019-07-12 01:12:30 --> Final output sent to browser
DEBUG - 2019-07-12 01:12:30 --> Total execution time: 0.7841
INFO - 2019-07-12 01:12:31 --> Helper loaded: language_helper
INFO - 2019-07-12 01:12:31 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:12:31 --> Helper loaded: language_helper
INFO - 2019-07-12 01:12:31 --> Model Class Initialized
INFO - 2019-07-12 01:12:31 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:12:31 --> Model Class Initialized
INFO - 2019-07-12 01:12:31 --> Model Class Initialized
INFO - 2019-07-12 01:12:31 --> Model Class Initialized
INFO - 2019-07-12 01:12:31 --> Model Class Initialized
INFO - 2019-07-12 01:12:31 --> Model Class Initialized
INFO - 2019-07-12 01:12:31 --> Model Class Initialized
INFO - 2019-07-12 01:12:31 --> Helper loaded: form_helper
INFO - 2019-07-12 01:12:31 --> Model Class Initialized
INFO - 2019-07-12 01:12:31 --> Form Validation Class Initialized
INFO - 2019-07-12 01:12:31 --> Helper loaded: form_helper
DEBUG - 2019-07-12 01:12:31 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:12:31 --> Form Validation Class Initialized
INFO - 2019-07-12 01:12:31 --> Model Class Initialized
DEBUG - 2019-07-12 01:12:31 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:12:31 --> Model Class Initialized
INFO - 2019-07-12 01:12:31 --> Model Class Initialized
INFO - 2019-07-12 01:12:31 --> Final output sent to browser
DEBUG - 2019-07-12 01:12:31 --> Total execution time: 1.2513
INFO - 2019-07-12 01:12:31 --> Model Class Initialized
INFO - 2019-07-12 01:12:31 --> Final output sent to browser
DEBUG - 2019-07-12 01:12:31 --> Total execution time: 1.2783
INFO - 2019-07-12 01:12:48 --> Helper loaded: language_helper
INFO - 2019-07-12 01:12:48 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:12:48 --> Model Class Initialized
INFO - 2019-07-12 01:12:48 --> Model Class Initialized
INFO - 2019-07-12 01:12:48 --> Model Class Initialized
INFO - 2019-07-12 01:12:48 --> Model Class Initialized
INFO - 2019-07-12 01:12:48 --> Model Class Initialized
INFO - 2019-07-12 01:12:48 --> Final output sent to browser
DEBUG - 2019-07-12 01:12:48 --> Total execution time: 0.7247
INFO - 2019-07-12 01:12:49 --> Helper loaded: language_helper
INFO - 2019-07-12 01:12:49 --> Helper loaded: language_helper
INFO - 2019-07-12 01:12:49 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:12:49 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:12:49 --> Model Class Initialized
INFO - 2019-07-12 01:12:49 --> Model Class Initialized
INFO - 2019-07-12 01:12:49 --> Model Class Initialized
INFO - 2019-07-12 01:12:49 --> Model Class Initialized
INFO - 2019-07-12 01:12:49 --> Model Class Initialized
INFO - 2019-07-12 01:12:49 --> Model Class Initialized
INFO - 2019-07-12 01:12:49 --> Model Class Initialized
INFO - 2019-07-12 01:12:49 --> Model Class Initialized
INFO - 2019-07-12 01:12:49 --> Helper loaded: form_helper
INFO - 2019-07-12 01:12:49 --> Helper loaded: form_helper
INFO - 2019-07-12 01:12:49 --> Form Validation Class Initialized
INFO - 2019-07-12 01:12:49 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:12:49 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
DEBUG - 2019-07-12 01:12:49 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:12:49 --> Model Class Initialized
INFO - 2019-07-12 01:12:49 --> Model Class Initialized
INFO - 2019-07-12 01:12:49 --> Model Class Initialized
INFO - 2019-07-12 01:12:49 --> Model Class Initialized
INFO - 2019-07-12 01:12:49 --> Final output sent to browser
INFO - 2019-07-12 01:12:49 --> Final output sent to browser
DEBUG - 2019-07-12 01:12:49 --> Total execution time: 0.9613
DEBUG - 2019-07-12 01:12:49 --> Total execution time: 0.9897
INFO - 2019-07-12 01:13:09 --> Helper loaded: language_helper
INFO - 2019-07-12 01:13:10 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:13:10 --> Model Class Initialized
INFO - 2019-07-12 01:13:10 --> Model Class Initialized
INFO - 2019-07-12 01:13:10 --> Model Class Initialized
INFO - 2019-07-12 01:13:10 --> Model Class Initialized
INFO - 2019-07-12 01:13:10 --> Helper loaded: form_helper
INFO - 2019-07-12 01:13:10 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:13:10 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:13:10 --> Model Class Initialized
INFO - 2019-07-12 01:13:10 --> Model Class Initialized
INFO - 2019-07-12 01:13:10 --> Final output sent to browser
DEBUG - 2019-07-12 01:13:10 --> Total execution time: 0.7254
INFO - 2019-07-12 01:13:14 --> Helper loaded: language_helper
INFO - 2019-07-12 01:13:14 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:13:14 --> Model Class Initialized
INFO - 2019-07-12 01:13:14 --> Model Class Initialized
INFO - 2019-07-12 01:13:14 --> Model Class Initialized
INFO - 2019-07-12 01:13:14 --> Model Class Initialized
INFO - 2019-07-12 01:13:14 --> Helper loaded: form_helper
INFO - 2019-07-12 01:13:14 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:13:14 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:13:14 --> Model Class Initialized
INFO - 2019-07-12 01:13:14 --> Model Class Initialized
INFO - 2019-07-12 01:13:14 --> Final output sent to browser
DEBUG - 2019-07-12 01:13:14 --> Total execution time: 0.7231
INFO - 2019-07-12 01:13:17 --> Helper loaded: language_helper
INFO - 2019-07-12 01:13:17 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:13:17 --> Model Class Initialized
INFO - 2019-07-12 01:13:17 --> Model Class Initialized
INFO - 2019-07-12 01:13:17 --> Model Class Initialized
INFO - 2019-07-12 01:13:17 --> Model Class Initialized
INFO - 2019-07-12 01:13:17 --> Helper loaded: form_helper
INFO - 2019-07-12 01:13:17 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:13:17 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:13:17 --> Model Class Initialized
INFO - 2019-07-12 01:13:17 --> Model Class Initialized
INFO - 2019-07-12 01:13:17 --> Final output sent to browser
DEBUG - 2019-07-12 01:13:17 --> Total execution time: 0.7128
INFO - 2019-07-12 01:13:33 --> Helper loaded: language_helper
INFO - 2019-07-12 01:13:33 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:13:33 --> Model Class Initialized
INFO - 2019-07-12 01:13:33 --> Model Class Initialized
INFO - 2019-07-12 01:13:33 --> Model Class Initialized
INFO - 2019-07-12 01:13:33 --> Model Class Initialized
INFO - 2019-07-12 01:13:33 --> Model Class Initialized
INFO - 2019-07-12 01:13:33 --> Final output sent to browser
DEBUG - 2019-07-12 01:13:33 --> Total execution time: 0.6505
INFO - 2019-07-12 01:13:34 --> Helper loaded: language_helper
INFO - 2019-07-12 01:13:34 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:13:34 --> Model Class Initialized
INFO - 2019-07-12 01:13:34 --> Model Class Initialized
INFO - 2019-07-12 01:13:34 --> Model Class Initialized
INFO - 2019-07-12 01:13:34 --> Model Class Initialized
INFO - 2019-07-12 01:13:34 --> Helper loaded: form_helper
INFO - 2019-07-12 01:13:34 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:13:34 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:13:34 --> Model Class Initialized
INFO - 2019-07-12 01:13:34 --> Model Class Initialized
INFO - 2019-07-12 01:13:34 --> Final output sent to browser
DEBUG - 2019-07-12 01:13:34 --> Total execution time: 0.7230
INFO - 2019-07-12 01:13:35 --> Helper loaded: language_helper
INFO - 2019-07-12 01:13:35 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:13:35 --> Model Class Initialized
INFO - 2019-07-12 01:13:35 --> Model Class Initialized
INFO - 2019-07-12 01:13:35 --> Model Class Initialized
INFO - 2019-07-12 01:13:35 --> Model Class Initialized
INFO - 2019-07-12 01:13:35 --> Helper loaded: form_helper
INFO - 2019-07-12 01:13:35 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:13:35 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:13:35 --> Model Class Initialized
INFO - 2019-07-12 01:13:35 --> Model Class Initialized
INFO - 2019-07-12 01:13:35 --> Final output sent to browser
DEBUG - 2019-07-12 01:13:35 --> Total execution time: 0.7580
INFO - 2019-07-12 01:13:45 --> Helper loaded: language_helper
INFO - 2019-07-12 01:13:45 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:13:45 --> Model Class Initialized
INFO - 2019-07-12 01:13:45 --> Model Class Initialized
INFO - 2019-07-12 01:13:45 --> Model Class Initialized
INFO - 2019-07-12 01:13:45 --> Model Class Initialized
INFO - 2019-07-12 01:13:45 --> Model Class Initialized
INFO - 2019-07-12 01:13:45 --> Final output sent to browser
DEBUG - 2019-07-12 01:13:45 --> Total execution time: 0.6437
INFO - 2019-07-12 01:13:46 --> Helper loaded: language_helper
INFO - 2019-07-12 01:13:46 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:13:46 --> Model Class Initialized
INFO - 2019-07-12 01:13:46 --> Model Class Initialized
INFO - 2019-07-12 01:13:46 --> Model Class Initialized
INFO - 2019-07-12 01:13:46 --> Model Class Initialized
INFO - 2019-07-12 01:13:46 --> Helper loaded: form_helper
INFO - 2019-07-12 01:13:46 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:13:46 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:13:46 --> Model Class Initialized
INFO - 2019-07-12 01:13:46 --> Model Class Initialized
INFO - 2019-07-12 01:13:46 --> Final output sent to browser
DEBUG - 2019-07-12 01:13:46 --> Total execution time: 0.7278
INFO - 2019-07-12 01:13:47 --> Helper loaded: language_helper
INFO - 2019-07-12 01:13:47 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:13:47 --> Model Class Initialized
INFO - 2019-07-12 01:13:47 --> Model Class Initialized
INFO - 2019-07-12 01:13:47 --> Model Class Initialized
INFO - 2019-07-12 01:13:47 --> Model Class Initialized
INFO - 2019-07-12 01:13:47 --> Helper loaded: form_helper
INFO - 2019-07-12 01:13:47 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:13:47 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:13:47 --> Model Class Initialized
INFO - 2019-07-12 01:13:47 --> Model Class Initialized
INFO - 2019-07-12 01:13:47 --> Final output sent to browser
DEBUG - 2019-07-12 01:13:47 --> Total execution time: 0.7810
INFO - 2019-07-12 01:13:51 --> Helper loaded: language_helper
INFO - 2019-07-12 01:13:51 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:13:51 --> Model Class Initialized
INFO - 2019-07-12 01:13:51 --> Model Class Initialized
INFO - 2019-07-12 01:13:51 --> Model Class Initialized
INFO - 2019-07-12 01:13:51 --> Model Class Initialized
INFO - 2019-07-12 01:13:51 --> Helper loaded: form_helper
INFO - 2019-07-12 01:13:51 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:13:51 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:13:51 --> Model Class Initialized
INFO - 2019-07-12 01:13:51 --> Model Class Initialized
INFO - 2019-07-12 01:13:51 --> Final output sent to browser
DEBUG - 2019-07-12 01:13:51 --> Total execution time: 0.7256
INFO - 2019-07-12 01:13:54 --> Helper loaded: language_helper
INFO - 2019-07-12 01:13:54 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:13:54 --> Model Class Initialized
INFO - 2019-07-12 01:13:54 --> Model Class Initialized
INFO - 2019-07-12 01:13:54 --> Model Class Initialized
INFO - 2019-07-12 01:13:54 --> Model Class Initialized
INFO - 2019-07-12 01:13:54 --> Helper loaded: form_helper
INFO - 2019-07-12 01:13:54 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:13:54 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:13:54 --> Model Class Initialized
INFO - 2019-07-12 01:13:54 --> Model Class Initialized
INFO - 2019-07-12 01:13:54 --> Final output sent to browser
DEBUG - 2019-07-12 01:13:54 --> Total execution time: 0.7369
INFO - 2019-07-12 01:13:58 --> Helper loaded: language_helper
INFO - 2019-07-12 01:13:58 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:13:58 --> Model Class Initialized
INFO - 2019-07-12 01:13:58 --> Model Class Initialized
INFO - 2019-07-12 01:13:58 --> Model Class Initialized
INFO - 2019-07-12 01:13:58 --> Model Class Initialized
INFO - 2019-07-12 01:13:58 --> Helper loaded: form_helper
INFO - 2019-07-12 01:13:58 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:13:58 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:13:58 --> Model Class Initialized
INFO - 2019-07-12 01:13:58 --> Model Class Initialized
INFO - 2019-07-12 01:13:58 --> Final output sent to browser
DEBUG - 2019-07-12 01:13:58 --> Total execution time: 0.7102
INFO - 2019-07-12 01:14:01 --> Helper loaded: language_helper
INFO - 2019-07-12 01:14:01 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:14:01 --> Model Class Initialized
INFO - 2019-07-12 01:14:01 --> Model Class Initialized
INFO - 2019-07-12 01:14:01 --> Model Class Initialized
INFO - 2019-07-12 01:14:01 --> Model Class Initialized
INFO - 2019-07-12 01:14:01 --> Helper loaded: form_helper
INFO - 2019-07-12 01:14:01 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:14:01 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:14:01 --> Model Class Initialized
INFO - 2019-07-12 01:14:01 --> Model Class Initialized
INFO - 2019-07-12 01:14:01 --> Final output sent to browser
DEBUG - 2019-07-12 01:14:01 --> Total execution time: 0.7257
INFO - 2019-07-12 01:14:01 --> Helper loaded: language_helper
INFO - 2019-07-12 01:14:01 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:14:01 --> Model Class Initialized
INFO - 2019-07-12 01:14:01 --> Model Class Initialized
INFO - 2019-07-12 01:14:01 --> Model Class Initialized
INFO - 2019-07-12 01:14:01 --> Model Class Initialized
INFO - 2019-07-12 01:14:01 --> Helper loaded: form_helper
INFO - 2019-07-12 01:14:01 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:14:02 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:14:02 --> Model Class Initialized
INFO - 2019-07-12 01:14:02 --> Model Class Initialized
INFO - 2019-07-12 01:14:02 --> Final output sent to browser
DEBUG - 2019-07-12 01:14:02 --> Total execution time: 0.8207
INFO - 2019-07-12 01:14:05 --> Helper loaded: language_helper
INFO - 2019-07-12 01:14:05 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:14:05 --> Model Class Initialized
INFO - 2019-07-12 01:14:05 --> Model Class Initialized
INFO - 2019-07-12 01:14:05 --> Model Class Initialized
INFO - 2019-07-12 01:14:05 --> Model Class Initialized
INFO - 2019-07-12 01:14:05 --> Helper loaded: form_helper
INFO - 2019-07-12 01:14:05 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:14:05 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:14:05 --> Model Class Initialized
INFO - 2019-07-12 01:14:05 --> Model Class Initialized
INFO - 2019-07-12 01:14:05 --> Final output sent to browser
DEBUG - 2019-07-12 01:14:05 --> Total execution time: 0.7447
INFO - 2019-07-12 01:14:33 --> Helper loaded: language_helper
INFO - 2019-07-12 01:14:33 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:14:33 --> Model Class Initialized
INFO - 2019-07-12 01:14:33 --> Model Class Initialized
INFO - 2019-07-12 01:14:33 --> Model Class Initialized
INFO - 2019-07-12 01:14:33 --> Model Class Initialized
INFO - 2019-07-12 01:14:33 --> Model Class Initialized
INFO - 2019-07-12 01:14:33 --> Final output sent to browser
DEBUG - 2019-07-12 01:14:33 --> Total execution time: 0.6299
INFO - 2019-07-12 01:14:34 --> Helper loaded: language_helper
INFO - 2019-07-12 01:14:34 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:14:34 --> Model Class Initialized
INFO - 2019-07-12 01:14:34 --> Model Class Initialized
INFO - 2019-07-12 01:14:34 --> Model Class Initialized
INFO - 2019-07-12 01:14:34 --> Model Class Initialized
INFO - 2019-07-12 01:14:34 --> Helper loaded: form_helper
INFO - 2019-07-12 01:14:34 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:14:34 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:14:34 --> Model Class Initialized
INFO - 2019-07-12 01:14:34 --> Model Class Initialized
INFO - 2019-07-12 01:14:34 --> Final output sent to browser
DEBUG - 2019-07-12 01:14:34 --> Total execution time: 0.7373
INFO - 2019-07-12 01:14:35 --> Helper loaded: language_helper
INFO - 2019-07-12 01:14:35 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:14:35 --> Model Class Initialized
INFO - 2019-07-12 01:14:35 --> Model Class Initialized
INFO - 2019-07-12 01:14:35 --> Model Class Initialized
INFO - 2019-07-12 01:14:35 --> Model Class Initialized
INFO - 2019-07-12 01:14:35 --> Helper loaded: form_helper
INFO - 2019-07-12 01:14:35 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:14:35 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:14:35 --> Model Class Initialized
INFO - 2019-07-12 01:14:35 --> Model Class Initialized
INFO - 2019-07-12 01:14:35 --> Final output sent to browser
DEBUG - 2019-07-12 01:14:35 --> Total execution time: 0.7583
INFO - 2019-07-12 01:14:41 --> Helper loaded: language_helper
INFO - 2019-07-12 01:14:41 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:14:41 --> Model Class Initialized
INFO - 2019-07-12 01:14:41 --> Model Class Initialized
INFO - 2019-07-12 01:14:41 --> Model Class Initialized
INFO - 2019-07-12 01:14:41 --> Model Class Initialized
INFO - 2019-07-12 01:14:41 --> Helper loaded: form_helper
INFO - 2019-07-12 01:14:41 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:14:41 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:14:41 --> Model Class Initialized
INFO - 2019-07-12 01:14:41 --> Model Class Initialized
INFO - 2019-07-12 01:14:41 --> Final output sent to browser
DEBUG - 2019-07-12 01:14:41 --> Total execution time: 0.7264
INFO - 2019-07-12 01:14:45 --> Helper loaded: language_helper
INFO - 2019-07-12 01:14:45 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:14:45 --> Model Class Initialized
INFO - 2019-07-12 01:14:45 --> Model Class Initialized
INFO - 2019-07-12 01:14:45 --> Model Class Initialized
INFO - 2019-07-12 01:14:45 --> Model Class Initialized
INFO - 2019-07-12 01:14:45 --> Helper loaded: form_helper
INFO - 2019-07-12 01:14:45 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:14:45 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:14:45 --> Model Class Initialized
INFO - 2019-07-12 01:14:45 --> Model Class Initialized
INFO - 2019-07-12 01:14:45 --> Final output sent to browser
DEBUG - 2019-07-12 01:14:45 --> Total execution time: 0.7240
INFO - 2019-07-12 01:14:49 --> Helper loaded: language_helper
INFO - 2019-07-12 01:14:49 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:14:49 --> Model Class Initialized
INFO - 2019-07-12 01:14:49 --> Model Class Initialized
INFO - 2019-07-12 01:14:49 --> Model Class Initialized
INFO - 2019-07-12 01:14:49 --> Model Class Initialized
INFO - 2019-07-12 01:14:49 --> Helper loaded: form_helper
INFO - 2019-07-12 01:14:49 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:14:49 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:14:49 --> Model Class Initialized
INFO - 2019-07-12 01:14:49 --> Model Class Initialized
INFO - 2019-07-12 01:14:49 --> Final output sent to browser
DEBUG - 2019-07-12 01:14:49 --> Total execution time: 0.7219
INFO - 2019-07-12 01:15:45 --> Helper loaded: language_helper
INFO - 2019-07-12 01:15:45 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:15:45 --> Model Class Initialized
INFO - 2019-07-12 01:15:45 --> Model Class Initialized
INFO - 2019-07-12 01:15:45 --> Model Class Initialized
INFO - 2019-07-12 01:15:45 --> Model Class Initialized
INFO - 2019-07-12 01:15:45 --> Helper loaded: form_helper
INFO - 2019-07-12 01:15:45 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:15:45 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:15:45 --> Model Class Initialized
INFO - 2019-07-12 01:15:45 --> Model Class Initialized
INFO - 2019-07-12 01:15:45 --> Final output sent to browser
DEBUG - 2019-07-12 01:15:45 --> Total execution time: 0.8732
INFO - 2019-07-12 01:15:45 --> Helper loaded: language_helper
INFO - 2019-07-12 01:15:45 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:15:45 --> Model Class Initialized
INFO - 2019-07-12 01:15:45 --> Model Class Initialized
INFO - 2019-07-12 01:15:45 --> Model Class Initialized
INFO - 2019-07-12 01:15:45 --> Model Class Initialized
INFO - 2019-07-12 01:15:45 --> Model Class Initialized
INFO - 2019-07-12 01:15:45 --> Final output sent to browser
DEBUG - 2019-07-12 01:15:45 --> Total execution time: 0.7059
INFO - 2019-07-12 01:15:46 --> Helper loaded: language_helper
INFO - 2019-07-12 01:15:46 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:15:46 --> Model Class Initialized
INFO - 2019-07-12 01:15:46 --> Model Class Initialized
INFO - 2019-07-12 01:15:46 --> Model Class Initialized
INFO - 2019-07-12 01:15:46 --> Model Class Initialized
INFO - 2019-07-12 01:15:46 --> Helper loaded: form_helper
INFO - 2019-07-12 01:15:46 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:15:46 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:15:46 --> Model Class Initialized
INFO - 2019-07-12 01:15:46 --> Model Class Initialized
INFO - 2019-07-12 01:15:46 --> Final output sent to browser
DEBUG - 2019-07-12 01:15:46 --> Total execution time: 0.7893
INFO - 2019-07-12 01:16:30 --> Helper loaded: language_helper
INFO - 2019-07-12 01:16:30 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:16:30 --> Model Class Initialized
INFO - 2019-07-12 01:16:30 --> Model Class Initialized
INFO - 2019-07-12 01:16:30 --> Model Class Initialized
INFO - 2019-07-12 01:16:30 --> Model Class Initialized
INFO - 2019-07-12 01:16:30 --> Helper loaded: form_helper
INFO - 2019-07-12 01:16:30 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:16:30 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:16:30 --> Model Class Initialized
INFO - 2019-07-12 01:16:30 --> Model Class Initialized
INFO - 2019-07-12 01:16:30 --> Final output sent to browser
DEBUG - 2019-07-12 01:16:30 --> Total execution time: 1.1061
INFO - 2019-07-12 01:16:31 --> Helper loaded: language_helper
INFO - 2019-07-12 01:16:31 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:16:31 --> Model Class Initialized
INFO - 2019-07-12 01:16:31 --> Model Class Initialized
INFO - 2019-07-12 01:16:31 --> Model Class Initialized
INFO - 2019-07-12 01:16:31 --> Model Class Initialized
INFO - 2019-07-12 01:16:31 --> Model Class Initialized
INFO - 2019-07-12 01:16:31 --> Final output sent to browser
DEBUG - 2019-07-12 01:16:31 --> Total execution time: 0.7602
INFO - 2019-07-12 01:16:31 --> Helper loaded: language_helper
INFO - 2019-07-12 01:16:31 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:16:31 --> Model Class Initialized
INFO - 2019-07-12 01:16:31 --> Model Class Initialized
INFO - 2019-07-12 01:16:31 --> Model Class Initialized
INFO - 2019-07-12 01:16:31 --> Model Class Initialized
INFO - 2019-07-12 01:16:31 --> Helper loaded: form_helper
INFO - 2019-07-12 01:16:32 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:16:32 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:16:32 --> Model Class Initialized
INFO - 2019-07-12 01:16:32 --> Model Class Initialized
INFO - 2019-07-12 01:16:32 --> Final output sent to browser
DEBUG - 2019-07-12 01:16:32 --> Total execution time: 0.7790
INFO - 2019-07-12 01:16:36 --> Helper loaded: language_helper
INFO - 2019-07-12 01:16:36 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:16:36 --> Model Class Initialized
INFO - 2019-07-12 01:16:36 --> Model Class Initialized
INFO - 2019-07-12 01:16:36 --> Model Class Initialized
INFO - 2019-07-12 01:16:36 --> Model Class Initialized
INFO - 2019-07-12 01:16:36 --> Helper loaded: form_helper
INFO - 2019-07-12 01:16:36 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:16:36 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:16:36 --> Model Class Initialized
INFO - 2019-07-12 01:16:36 --> Model Class Initialized
INFO - 2019-07-12 01:16:37 --> Final output sent to browser
DEBUG - 2019-07-12 01:16:37 --> Total execution time: 0.9846
INFO - 2019-07-12 01:16:37 --> Helper loaded: language_helper
INFO - 2019-07-12 01:16:37 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:16:37 --> Model Class Initialized
INFO - 2019-07-12 01:16:37 --> Model Class Initialized
INFO - 2019-07-12 01:16:37 --> Model Class Initialized
INFO - 2019-07-12 01:16:37 --> Model Class Initialized
INFO - 2019-07-12 01:16:37 --> Model Class Initialized
INFO - 2019-07-12 01:16:37 --> Final output sent to browser
DEBUG - 2019-07-12 01:16:37 --> Total execution time: 0.7773
INFO - 2019-07-12 01:16:37 --> Helper loaded: language_helper
INFO - 2019-07-12 01:16:37 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:16:37 --> Model Class Initialized
INFO - 2019-07-12 01:16:37 --> Model Class Initialized
INFO - 2019-07-12 01:16:38 --> Model Class Initialized
INFO - 2019-07-12 01:16:38 --> Model Class Initialized
INFO - 2019-07-12 01:16:38 --> Helper loaded: form_helper
INFO - 2019-07-12 01:16:38 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:16:38 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:16:38 --> Model Class Initialized
INFO - 2019-07-12 01:16:38 --> Model Class Initialized
INFO - 2019-07-12 01:16:38 --> Final output sent to browser
DEBUG - 2019-07-12 01:16:38 --> Total execution time: 0.8223
INFO - 2019-07-12 01:16:39 --> Helper loaded: language_helper
INFO - 2019-07-12 01:16:39 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:16:39 --> Model Class Initialized
INFO - 2019-07-12 01:16:39 --> Model Class Initialized
INFO - 2019-07-12 01:16:39 --> Model Class Initialized
INFO - 2019-07-12 01:16:39 --> Model Class Initialized
INFO - 2019-07-12 01:16:39 --> Helper loaded: form_helper
INFO - 2019-07-12 01:16:39 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:16:39 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:16:39 --> Model Class Initialized
INFO - 2019-07-12 01:16:39 --> Model Class Initialized
INFO - 2019-07-12 01:16:39 --> Final output sent to browser
DEBUG - 2019-07-12 01:16:39 --> Total execution time: 0.7779
INFO - 2019-07-12 01:16:41 --> Helper loaded: language_helper
INFO - 2019-07-12 01:16:41 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:16:41 --> Model Class Initialized
INFO - 2019-07-12 01:16:41 --> Model Class Initialized
INFO - 2019-07-12 01:16:41 --> Model Class Initialized
INFO - 2019-07-12 01:16:41 --> Model Class Initialized
INFO - 2019-07-12 01:16:41 --> Helper loaded: form_helper
INFO - 2019-07-12 01:16:41 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:16:41 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:16:41 --> Model Class Initialized
INFO - 2019-07-12 01:16:41 --> Model Class Initialized
INFO - 2019-07-12 01:16:41 --> Final output sent to browser
DEBUG - 2019-07-12 01:16:41 --> Total execution time: 0.7273
INFO - 2019-07-12 01:16:42 --> Helper loaded: language_helper
INFO - 2019-07-12 01:16:42 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:16:43 --> Model Class Initialized
INFO - 2019-07-12 01:16:43 --> Model Class Initialized
INFO - 2019-07-12 01:16:43 --> Model Class Initialized
INFO - 2019-07-12 01:16:43 --> Model Class Initialized
INFO - 2019-07-12 01:16:43 --> Helper loaded: form_helper
INFO - 2019-07-12 01:16:43 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:16:43 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:16:43 --> Model Class Initialized
INFO - 2019-07-12 01:16:43 --> Model Class Initialized
INFO - 2019-07-12 01:16:43 --> Final output sent to browser
DEBUG - 2019-07-12 01:16:43 --> Total execution time: 0.7262
INFO - 2019-07-12 01:16:46 --> Helper loaded: language_helper
INFO - 2019-07-12 01:16:46 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:16:46 --> Model Class Initialized
INFO - 2019-07-12 01:16:46 --> Model Class Initialized
INFO - 2019-07-12 01:16:46 --> Model Class Initialized
INFO - 2019-07-12 01:16:46 --> Model Class Initialized
INFO - 2019-07-12 01:16:46 --> Helper loaded: form_helper
INFO - 2019-07-12 01:16:46 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:16:46 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:16:46 --> Model Class Initialized
INFO - 2019-07-12 01:16:46 --> Model Class Initialized
INFO - 2019-07-12 01:16:46 --> Final output sent to browser
DEBUG - 2019-07-12 01:16:46 --> Total execution time: 0.7338
INFO - 2019-07-12 01:16:47 --> Helper loaded: language_helper
INFO - 2019-07-12 01:16:47 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:16:47 --> Model Class Initialized
INFO - 2019-07-12 01:16:47 --> Model Class Initialized
INFO - 2019-07-12 01:16:47 --> Model Class Initialized
INFO - 2019-07-12 01:16:47 --> Model Class Initialized
INFO - 2019-07-12 01:16:47 --> Helper loaded: form_helper
INFO - 2019-07-12 01:16:48 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:16:48 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:16:48 --> Model Class Initialized
INFO - 2019-07-12 01:16:48 --> Model Class Initialized
INFO - 2019-07-12 01:16:48 --> Final output sent to browser
DEBUG - 2019-07-12 01:16:48 --> Total execution time: 0.7053
INFO - 2019-07-12 01:17:04 --> Helper loaded: language_helper
INFO - 2019-07-12 01:17:04 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:17:04 --> Model Class Initialized
INFO - 2019-07-12 01:17:04 --> Model Class Initialized
INFO - 2019-07-12 01:17:04 --> Model Class Initialized
INFO - 2019-07-12 01:17:04 --> Model Class Initialized
INFO - 2019-07-12 01:17:04 --> Helper loaded: form_helper
INFO - 2019-07-12 01:17:04 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:17:04 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:17:04 --> Model Class Initialized
INFO - 2019-07-12 01:17:04 --> Model Class Initialized
INFO - 2019-07-12 01:17:04 --> Final output sent to browser
DEBUG - 2019-07-12 01:17:04 --> Total execution time: 1.0383
INFO - 2019-07-12 01:17:04 --> Helper loaded: language_helper
INFO - 2019-07-12 01:17:04 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:17:04 --> Model Class Initialized
INFO - 2019-07-12 01:17:04 --> Model Class Initialized
INFO - 2019-07-12 01:17:04 --> Model Class Initialized
INFO - 2019-07-12 01:17:04 --> Model Class Initialized
INFO - 2019-07-12 01:17:04 --> Model Class Initialized
INFO - 2019-07-12 01:17:04 --> Final output sent to browser
DEBUG - 2019-07-12 01:17:04 --> Total execution time: 0.8003
INFO - 2019-07-12 01:17:05 --> Helper loaded: language_helper
INFO - 2019-07-12 01:17:05 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:17:05 --> Model Class Initialized
INFO - 2019-07-12 01:17:05 --> Model Class Initialized
INFO - 2019-07-12 01:17:05 --> Model Class Initialized
INFO - 2019-07-12 01:17:05 --> Model Class Initialized
INFO - 2019-07-12 01:17:05 --> Helper loaded: form_helper
INFO - 2019-07-12 01:17:05 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:17:05 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:17:05 --> Model Class Initialized
INFO - 2019-07-12 01:17:05 --> Model Class Initialized
INFO - 2019-07-12 01:17:05 --> Final output sent to browser
DEBUG - 2019-07-12 01:17:05 --> Total execution time: 0.8328
INFO - 2019-07-12 01:17:07 --> Helper loaded: language_helper
INFO - 2019-07-12 01:17:07 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:17:07 --> Model Class Initialized
INFO - 2019-07-12 01:17:07 --> Model Class Initialized
INFO - 2019-07-12 01:17:07 --> Model Class Initialized
INFO - 2019-07-12 01:17:07 --> Model Class Initialized
INFO - 2019-07-12 01:17:07 --> Helper loaded: form_helper
INFO - 2019-07-12 01:17:07 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:17:07 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:17:07 --> Model Class Initialized
INFO - 2019-07-12 01:17:07 --> Model Class Initialized
INFO - 2019-07-12 01:17:07 --> Final output sent to browser
DEBUG - 2019-07-12 01:17:07 --> Total execution time: 1.1712
INFO - 2019-07-12 01:17:07 --> Helper loaded: language_helper
INFO - 2019-07-12 01:17:07 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:17:07 --> Model Class Initialized
INFO - 2019-07-12 01:17:07 --> Model Class Initialized
INFO - 2019-07-12 01:17:07 --> Model Class Initialized
INFO - 2019-07-12 01:17:07 --> Model Class Initialized
INFO - 2019-07-12 01:17:07 --> Model Class Initialized
INFO - 2019-07-12 01:17:07 --> Final output sent to browser
DEBUG - 2019-07-12 01:17:07 --> Total execution time: 0.8378
INFO - 2019-07-12 01:17:08 --> Helper loaded: language_helper
INFO - 2019-07-12 01:17:08 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:17:08 --> Model Class Initialized
INFO - 2019-07-12 01:17:08 --> Model Class Initialized
INFO - 2019-07-12 01:17:08 --> Model Class Initialized
INFO - 2019-07-12 01:17:08 --> Model Class Initialized
INFO - 2019-07-12 01:17:08 --> Helper loaded: form_helper
INFO - 2019-07-12 01:17:08 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:17:08 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:17:08 --> Model Class Initialized
INFO - 2019-07-12 01:17:08 --> Model Class Initialized
INFO - 2019-07-12 01:17:08 --> Final output sent to browser
DEBUG - 2019-07-12 01:17:08 --> Total execution time: 0.9340
INFO - 2019-07-12 01:17:08 --> Helper loaded: language_helper
INFO - 2019-07-12 01:17:08 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:17:08 --> Model Class Initialized
INFO - 2019-07-12 01:17:09 --> Model Class Initialized
INFO - 2019-07-12 01:17:09 --> Model Class Initialized
INFO - 2019-07-12 01:17:09 --> Model Class Initialized
INFO - 2019-07-12 01:17:09 --> Helper loaded: form_helper
INFO - 2019-07-12 01:17:09 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:17:09 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:17:09 --> Model Class Initialized
INFO - 2019-07-12 01:17:09 --> Model Class Initialized
INFO - 2019-07-12 01:17:09 --> Final output sent to browser
DEBUG - 2019-07-12 01:17:09 --> Total execution time: 0.9190
INFO - 2019-07-12 01:17:13 --> Helper loaded: language_helper
INFO - 2019-07-12 01:17:13 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:17:13 --> Model Class Initialized
INFO - 2019-07-12 01:17:13 --> Model Class Initialized
INFO - 2019-07-12 01:17:13 --> Model Class Initialized
INFO - 2019-07-12 01:17:13 --> Model Class Initialized
INFO - 2019-07-12 01:17:13 --> Model Class Initialized
INFO - 2019-07-12 01:17:13 --> Final output sent to browser
DEBUG - 2019-07-12 01:17:13 --> Total execution time: 0.6417
INFO - 2019-07-12 01:17:14 --> Helper loaded: language_helper
INFO - 2019-07-12 01:17:14 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:17:14 --> Model Class Initialized
INFO - 2019-07-12 01:17:14 --> Model Class Initialized
INFO - 2019-07-12 01:17:14 --> Helper loaded: language_helper
INFO - 2019-07-12 01:17:14 --> Model Class Initialized
INFO - 2019-07-12 01:17:14 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:17:14 --> Model Class Initialized
INFO - 2019-07-12 01:17:14 --> Model Class Initialized
INFO - 2019-07-12 01:17:14 --> Helper loaded: form_helper
INFO - 2019-07-12 01:17:14 --> Model Class Initialized
INFO - 2019-07-12 01:17:15 --> Form Validation Class Initialized
INFO - 2019-07-12 01:17:15 --> Model Class Initialized
DEBUG - 2019-07-12 01:17:15 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:17:15 --> Model Class Initialized
INFO - 2019-07-12 01:17:15 --> Model Class Initialized
INFO - 2019-07-12 01:17:15 --> Helper loaded: form_helper
INFO - 2019-07-12 01:17:15 --> Model Class Initialized
INFO - 2019-07-12 01:17:15 --> Form Validation Class Initialized
INFO - 2019-07-12 01:17:15 --> Final output sent to browser
DEBUG - 2019-07-12 01:17:15 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
DEBUG - 2019-07-12 01:17:15 --> Total execution time: 1.4534
INFO - 2019-07-12 01:17:15 --> Model Class Initialized
INFO - 2019-07-12 01:17:15 --> Model Class Initialized
INFO - 2019-07-12 01:17:15 --> Final output sent to browser
DEBUG - 2019-07-12 01:17:15 --> Total execution time: 1.2734
INFO - 2019-07-12 01:17:16 --> Helper loaded: language_helper
INFO - 2019-07-12 01:17:16 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:17:16 --> Model Class Initialized
INFO - 2019-07-12 01:17:16 --> Model Class Initialized
INFO - 2019-07-12 01:17:16 --> Model Class Initialized
INFO - 2019-07-12 01:17:16 --> Model Class Initialized
INFO - 2019-07-12 01:17:16 --> Helper loaded: form_helper
INFO - 2019-07-12 01:17:16 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:17:16 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:17:16 --> Model Class Initialized
INFO - 2019-07-12 01:17:16 --> Model Class Initialized
INFO - 2019-07-12 01:17:17 --> Final output sent to browser
DEBUG - 2019-07-12 01:17:17 --> Total execution time: 0.8992
INFO - 2019-07-12 01:17:17 --> Helper loaded: language_helper
INFO - 2019-07-12 01:17:17 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:17:17 --> Model Class Initialized
INFO - 2019-07-12 01:17:17 --> Model Class Initialized
INFO - 2019-07-12 01:17:17 --> Model Class Initialized
INFO - 2019-07-12 01:17:17 --> Model Class Initialized
INFO - 2019-07-12 01:17:17 --> Helper loaded: form_helper
INFO - 2019-07-12 01:17:17 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:17:17 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:17:17 --> Model Class Initialized
INFO - 2019-07-12 01:17:17 --> Model Class Initialized
INFO - 2019-07-12 01:17:17 --> Final output sent to browser
DEBUG - 2019-07-12 01:17:17 --> Total execution time: 0.7185
INFO - 2019-07-12 01:17:18 --> Helper loaded: language_helper
INFO - 2019-07-12 01:17:18 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:17:18 --> Model Class Initialized
INFO - 2019-07-12 01:17:19 --> Model Class Initialized
INFO - 2019-07-12 01:17:19 --> Model Class Initialized
INFO - 2019-07-12 01:17:19 --> Model Class Initialized
INFO - 2019-07-12 01:17:19 --> Helper loaded: form_helper
INFO - 2019-07-12 01:17:19 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:17:19 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:17:19 --> Model Class Initialized
INFO - 2019-07-12 01:17:19 --> Model Class Initialized
INFO - 2019-07-12 01:17:19 --> Final output sent to browser
DEBUG - 2019-07-12 01:17:19 --> Total execution time: 0.7101
INFO - 2019-07-12 01:17:32 --> Helper loaded: language_helper
INFO - 2019-07-12 01:17:32 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:17:32 --> Model Class Initialized
INFO - 2019-07-12 01:17:32 --> Model Class Initialized
INFO - 2019-07-12 01:17:32 --> Model Class Initialized
INFO - 2019-07-12 01:17:32 --> Model Class Initialized
INFO - 2019-07-12 01:17:32 --> Helper loaded: form_helper
INFO - 2019-07-12 01:17:32 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:17:32 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:17:32 --> Model Class Initialized
INFO - 2019-07-12 01:17:32 --> Model Class Initialized
INFO - 2019-07-12 01:17:32 --> Final output sent to browser
DEBUG - 2019-07-12 01:17:32 --> Total execution time: 0.7419
INFO - 2019-07-12 01:17:34 --> Helper loaded: language_helper
INFO - 2019-07-12 01:17:34 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:17:34 --> Model Class Initialized
INFO - 2019-07-12 01:17:34 --> Model Class Initialized
INFO - 2019-07-12 01:17:34 --> Model Class Initialized
INFO - 2019-07-12 01:17:34 --> Model Class Initialized
INFO - 2019-07-12 01:17:34 --> Helper loaded: language_helper
INFO - 2019-07-12 01:17:34 --> Helper loaded: form_helper
INFO - 2019-07-12 01:17:34 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:17:34 --> Form Validation Class Initialized
INFO - 2019-07-12 01:17:34 --> Model Class Initialized
DEBUG - 2019-07-12 01:17:35 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:17:35 --> Model Class Initialized
INFO - 2019-07-12 01:17:35 --> Model Class Initialized
INFO - 2019-07-12 01:17:35 --> Model Class Initialized
INFO - 2019-07-12 01:17:35 --> Model Class Initialized
INFO - 2019-07-12 01:17:35 --> Model Class Initialized
INFO - 2019-07-12 01:17:35 --> Final output sent to browser
INFO - 2019-07-12 01:17:35 --> Model Class Initialized
DEBUG - 2019-07-12 01:17:35 --> Total execution time: 1.1808
INFO - 2019-07-12 01:17:35 --> Final output sent to browser
DEBUG - 2019-07-12 01:17:35 --> Total execution time: 1.0103
INFO - 2019-07-12 01:17:35 --> Helper loaded: language_helper
INFO - 2019-07-12 01:17:35 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:17:35 --> Model Class Initialized
INFO - 2019-07-12 01:17:35 --> Model Class Initialized
INFO - 2019-07-12 01:17:35 --> Model Class Initialized
INFO - 2019-07-12 01:17:35 --> Model Class Initialized
INFO - 2019-07-12 01:17:35 --> Helper loaded: form_helper
INFO - 2019-07-12 01:17:35 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:17:35 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:17:35 --> Model Class Initialized
INFO - 2019-07-12 01:17:35 --> Model Class Initialized
INFO - 2019-07-12 01:17:36 --> Final output sent to browser
DEBUG - 2019-07-12 01:17:36 --> Total execution time: 0.7979
INFO - 2019-07-12 01:17:37 --> Helper loaded: language_helper
INFO - 2019-07-12 01:17:37 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:17:37 --> Model Class Initialized
INFO - 2019-07-12 01:17:37 --> Model Class Initialized
INFO - 2019-07-12 01:17:37 --> Model Class Initialized
INFO - 2019-07-12 01:17:37 --> Model Class Initialized
INFO - 2019-07-12 01:17:37 --> Model Class Initialized
INFO - 2019-07-12 01:17:38 --> Final output sent to browser
DEBUG - 2019-07-12 01:17:38 --> Total execution time: 0.6834
INFO - 2019-07-12 01:17:38 --> Helper loaded: language_helper
INFO - 2019-07-12 01:17:38 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:17:38 --> Model Class Initialized
INFO - 2019-07-12 01:17:38 --> Model Class Initialized
INFO - 2019-07-12 01:17:38 --> Model Class Initialized
INFO - 2019-07-12 01:17:38 --> Model Class Initialized
INFO - 2019-07-12 01:17:38 --> Helper loaded: form_helper
INFO - 2019-07-12 01:17:38 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:17:38 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:17:38 --> Model Class Initialized
INFO - 2019-07-12 01:17:38 --> Model Class Initialized
INFO - 2019-07-12 01:17:38 --> Final output sent to browser
DEBUG - 2019-07-12 01:17:38 --> Total execution time: 0.7657
INFO - 2019-07-12 01:18:02 --> Helper loaded: language_helper
INFO - 2019-07-12 01:18:02 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:18:02 --> Model Class Initialized
INFO - 2019-07-12 01:18:02 --> Model Class Initialized
INFO - 2019-07-12 01:18:02 --> Model Class Initialized
INFO - 2019-07-12 01:18:02 --> Model Class Initialized
INFO - 2019-07-12 01:18:02 --> Helper loaded: form_helper
INFO - 2019-07-12 01:18:02 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:18:02 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:18:02 --> Model Class Initialized
INFO - 2019-07-12 01:18:02 --> Model Class Initialized
INFO - 2019-07-12 01:18:02 --> Final output sent to browser
DEBUG - 2019-07-12 01:18:02 --> Total execution time: 0.7351
INFO - 2019-07-12 01:18:04 --> Helper loaded: language_helper
INFO - 2019-07-12 01:18:04 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:18:04 --> Model Class Initialized
INFO - 2019-07-12 01:18:04 --> Model Class Initialized
INFO - 2019-07-12 01:18:04 --> Model Class Initialized
INFO - 2019-07-12 01:18:04 --> Model Class Initialized
INFO - 2019-07-12 01:18:04 --> Helper loaded: form_helper
INFO - 2019-07-12 01:18:04 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:18:04 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:18:04 --> Model Class Initialized
INFO - 2019-07-12 01:18:04 --> Model Class Initialized
INFO - 2019-07-12 01:18:04 --> Final output sent to browser
DEBUG - 2019-07-12 01:18:04 --> Total execution time: 0.7426
INFO - 2019-07-12 01:18:06 --> Helper loaded: language_helper
INFO - 2019-07-12 01:18:06 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:18:06 --> Model Class Initialized
INFO - 2019-07-12 01:18:06 --> Model Class Initialized
INFO - 2019-07-12 01:18:06 --> Model Class Initialized
INFO - 2019-07-12 01:18:06 --> Model Class Initialized
INFO - 2019-07-12 01:18:06 --> Helper loaded: form_helper
INFO - 2019-07-12 01:18:06 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:18:06 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:18:06 --> Model Class Initialized
INFO - 2019-07-12 01:18:06 --> Model Class Initialized
INFO - 2019-07-12 01:18:06 --> Final output sent to browser
DEBUG - 2019-07-12 01:18:06 --> Total execution time: 0.7166
INFO - 2019-07-12 01:18:07 --> Helper loaded: language_helper
INFO - 2019-07-12 01:18:07 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:18:07 --> Model Class Initialized
INFO - 2019-07-12 01:18:07 --> Model Class Initialized
INFO - 2019-07-12 01:18:07 --> Model Class Initialized
INFO - 2019-07-12 01:18:07 --> Model Class Initialized
INFO - 2019-07-12 01:18:07 --> Helper loaded: form_helper
INFO - 2019-07-12 01:18:07 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:18:07 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:18:07 --> Model Class Initialized
INFO - 2019-07-12 01:18:07 --> Model Class Initialized
INFO - 2019-07-12 01:18:07 --> Final output sent to browser
DEBUG - 2019-07-12 01:18:07 --> Total execution time: 0.7267
INFO - 2019-07-12 01:18:09 --> Helper loaded: language_helper
INFO - 2019-07-12 01:18:09 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:18:09 --> Model Class Initialized
INFO - 2019-07-12 01:18:09 --> Model Class Initialized
INFO - 2019-07-12 01:18:09 --> Model Class Initialized
INFO - 2019-07-12 01:18:09 --> Model Class Initialized
INFO - 2019-07-12 01:18:09 --> Helper loaded: form_helper
INFO - 2019-07-12 01:18:09 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:18:09 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:18:09 --> Model Class Initialized
INFO - 2019-07-12 01:18:09 --> Model Class Initialized
INFO - 2019-07-12 01:18:09 --> Final output sent to browser
DEBUG - 2019-07-12 01:18:09 --> Total execution time: 0.7478
INFO - 2019-07-12 01:18:11 --> Helper loaded: language_helper
INFO - 2019-07-12 01:18:11 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:18:11 --> Model Class Initialized
INFO - 2019-07-12 01:18:11 --> Model Class Initialized
INFO - 2019-07-12 01:18:11 --> Model Class Initialized
INFO - 2019-07-12 01:18:11 --> Model Class Initialized
INFO - 2019-07-12 01:18:12 --> Helper loaded: form_helper
INFO - 2019-07-12 01:18:12 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:18:12 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:18:12 --> Model Class Initialized
INFO - 2019-07-12 01:18:12 --> Model Class Initialized
INFO - 2019-07-12 01:18:12 --> Final output sent to browser
DEBUG - 2019-07-12 01:18:12 --> Total execution time: 0.7579
INFO - 2019-07-12 01:18:16 --> Helper loaded: language_helper
INFO - 2019-07-12 01:18:16 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:18:16 --> Model Class Initialized
INFO - 2019-07-12 01:18:16 --> Model Class Initialized
INFO - 2019-07-12 01:18:16 --> Model Class Initialized
INFO - 2019-07-12 01:18:16 --> Model Class Initialized
INFO - 2019-07-12 01:18:16 --> Helper loaded: form_helper
INFO - 2019-07-12 01:18:16 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:18:16 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:18:16 --> Model Class Initialized
INFO - 2019-07-12 01:18:16 --> Model Class Initialized
INFO - 2019-07-12 01:18:16 --> Final output sent to browser
DEBUG - 2019-07-12 01:18:16 --> Total execution time: 0.7083
INFO - 2019-07-12 01:18:48 --> Helper loaded: language_helper
INFO - 2019-07-12 01:18:48 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:18:48 --> Model Class Initialized
INFO - 2019-07-12 01:18:48 --> Model Class Initialized
INFO - 2019-07-12 01:18:48 --> Model Class Initialized
INFO - 2019-07-12 01:18:48 --> Model Class Initialized
INFO - 2019-07-12 01:18:48 --> Helper loaded: form_helper
INFO - 2019-07-12 01:18:48 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:18:48 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:18:48 --> Model Class Initialized
INFO - 2019-07-12 01:18:48 --> Model Class Initialized
INFO - 2019-07-12 01:18:48 --> Final output sent to browser
DEBUG - 2019-07-12 01:18:48 --> Total execution time: 0.7868
INFO - 2019-07-12 01:18:50 --> Helper loaded: language_helper
INFO - 2019-07-12 01:18:50 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:18:50 --> Model Class Initialized
INFO - 2019-07-12 01:18:50 --> Model Class Initialized
INFO - 2019-07-12 01:18:50 --> Model Class Initialized
INFO - 2019-07-12 01:18:50 --> Model Class Initialized
INFO - 2019-07-12 01:18:50 --> Model Class Initialized
INFO - 2019-07-12 01:18:50 --> Final output sent to browser
DEBUG - 2019-07-12 01:18:50 --> Total execution time: 0.8813
INFO - 2019-07-12 01:18:50 --> Helper loaded: language_helper
INFO - 2019-07-12 01:18:50 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:18:50 --> Model Class Initialized
INFO - 2019-07-12 01:18:50 --> Model Class Initialized
INFO - 2019-07-12 01:18:50 --> Model Class Initialized
INFO - 2019-07-12 01:18:50 --> Model Class Initialized
INFO - 2019-07-12 01:18:50 --> Helper loaded: form_helper
INFO - 2019-07-12 01:18:50 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:18:50 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:18:50 --> Model Class Initialized
INFO - 2019-07-12 01:18:50 --> Model Class Initialized
INFO - 2019-07-12 01:18:50 --> Final output sent to browser
DEBUG - 2019-07-12 01:18:50 --> Total execution time: 0.9532
INFO - 2019-07-12 01:18:50 --> Helper loaded: language_helper
INFO - 2019-07-12 01:18:50 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:18:51 --> Model Class Initialized
INFO - 2019-07-12 01:18:51 --> Model Class Initialized
INFO - 2019-07-12 01:18:51 --> Model Class Initialized
INFO - 2019-07-12 01:18:51 --> Model Class Initialized
INFO - 2019-07-12 01:18:51 --> Helper loaded: form_helper
INFO - 2019-07-12 01:18:51 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:18:51 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:18:51 --> Model Class Initialized
INFO - 2019-07-12 01:18:51 --> Model Class Initialized
INFO - 2019-07-12 01:18:51 --> Final output sent to browser
DEBUG - 2019-07-12 01:18:51 --> Total execution time: 0.8220
INFO - 2019-07-12 01:18:59 --> Helper loaded: language_helper
INFO - 2019-07-12 01:18:59 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:18:59 --> Model Class Initialized
INFO - 2019-07-12 01:18:59 --> Model Class Initialized
INFO - 2019-07-12 01:18:59 --> Model Class Initialized
INFO - 2019-07-12 01:18:59 --> Model Class Initialized
INFO - 2019-07-12 01:18:59 --> Helper loaded: form_helper
INFO - 2019-07-12 01:18:59 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:18:59 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:18:59 --> Model Class Initialized
INFO - 2019-07-12 01:18:59 --> Model Class Initialized
INFO - 2019-07-12 01:18:59 --> Final output sent to browser
DEBUG - 2019-07-12 01:18:59 --> Total execution time: 0.7559
INFO - 2019-07-12 01:19:01 --> Helper loaded: language_helper
INFO - 2019-07-12 01:19:01 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:19:01 --> Model Class Initialized
INFO - 2019-07-12 01:19:01 --> Model Class Initialized
INFO - 2019-07-12 01:19:01 --> Model Class Initialized
INFO - 2019-07-12 01:19:01 --> Model Class Initialized
INFO - 2019-07-12 01:19:01 --> Helper loaded: form_helper
INFO - 2019-07-12 01:19:01 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:19:01 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:19:01 --> Model Class Initialized
INFO - 2019-07-12 01:19:01 --> Model Class Initialized
INFO - 2019-07-12 01:19:01 --> Final output sent to browser
DEBUG - 2019-07-12 01:19:01 --> Total execution time: 0.7399
INFO - 2019-07-12 01:19:01 --> Helper loaded: language_helper
INFO - 2019-07-12 01:19:01 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:19:01 --> Model Class Initialized
INFO - 2019-07-12 01:19:01 --> Model Class Initialized
INFO - 2019-07-12 01:19:01 --> Model Class Initialized
INFO - 2019-07-12 01:19:01 --> Model Class Initialized
INFO - 2019-07-12 01:19:01 --> Helper loaded: form_helper
INFO - 2019-07-12 01:19:02 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:19:02 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:19:02 --> Model Class Initialized
INFO - 2019-07-12 01:19:02 --> Model Class Initialized
INFO - 2019-07-12 01:19:02 --> Final output sent to browser
DEBUG - 2019-07-12 01:19:02 --> Total execution time: 0.8477
INFO - 2019-07-12 01:19:26 --> Helper loaded: language_helper
INFO - 2019-07-12 01:19:26 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:19:26 --> Model Class Initialized
INFO - 2019-07-12 01:19:26 --> Model Class Initialized
INFO - 2019-07-12 01:19:26 --> Model Class Initialized
INFO - 2019-07-12 01:19:26 --> Model Class Initialized
INFO - 2019-07-12 01:19:26 --> Helper loaded: form_helper
INFO - 2019-07-12 01:19:26 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:19:26 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:19:26 --> Model Class Initialized
INFO - 2019-07-12 01:19:26 --> Model Class Initialized
INFO - 2019-07-12 01:19:26 --> Final output sent to browser
DEBUG - 2019-07-12 01:19:26 --> Total execution time: 0.8309
INFO - 2019-07-12 01:19:29 --> Helper loaded: language_helper
INFO - 2019-07-12 01:19:29 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:19:29 --> Model Class Initialized
INFO - 2019-07-12 01:19:29 --> Model Class Initialized
INFO - 2019-07-12 01:19:29 --> Model Class Initialized
INFO - 2019-07-12 01:19:29 --> Model Class Initialized
INFO - 2019-07-12 01:19:29 --> Model Class Initialized
INFO - 2019-07-12 01:19:29 --> Final output sent to browser
DEBUG - 2019-07-12 01:19:29 --> Total execution time: 0.6951
INFO - 2019-07-12 01:19:29 --> Helper loaded: language_helper
INFO - 2019-07-12 01:19:30 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:19:30 --> Model Class Initialized
INFO - 2019-07-12 01:19:30 --> Model Class Initialized
INFO - 2019-07-12 01:19:30 --> Model Class Initialized
INFO - 2019-07-12 01:19:30 --> Model Class Initialized
INFO - 2019-07-12 01:19:30 --> Helper loaded: form_helper
INFO - 2019-07-12 01:19:30 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:19:30 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:19:30 --> Model Class Initialized
INFO - 2019-07-12 01:19:30 --> Model Class Initialized
INFO - 2019-07-12 01:19:30 --> Final output sent to browser
DEBUG - 2019-07-12 01:19:30 --> Total execution time: 0.8011
INFO - 2019-07-12 01:19:37 --> Helper loaded: language_helper
INFO - 2019-07-12 01:19:37 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:19:37 --> Model Class Initialized
INFO - 2019-07-12 01:19:37 --> Model Class Initialized
INFO - 2019-07-12 01:19:37 --> Model Class Initialized
INFO - 2019-07-12 01:19:37 --> Model Class Initialized
INFO - 2019-07-12 01:19:37 --> Model Class Initialized
INFO - 2019-07-12 01:19:37 --> Final output sent to browser
DEBUG - 2019-07-12 01:19:37 --> Total execution time: 0.6609
INFO - 2019-07-12 01:19:38 --> Helper loaded: language_helper
INFO - 2019-07-12 01:19:38 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:19:38 --> Model Class Initialized
INFO - 2019-07-12 01:19:38 --> Model Class Initialized
INFO - 2019-07-12 01:19:38 --> Model Class Initialized
INFO - 2019-07-12 01:19:38 --> Model Class Initialized
INFO - 2019-07-12 01:19:38 --> Helper loaded: form_helper
INFO - 2019-07-12 01:19:38 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:19:38 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:19:38 --> Model Class Initialized
INFO - 2019-07-12 01:19:38 --> Model Class Initialized
INFO - 2019-07-12 01:19:38 --> Final output sent to browser
DEBUG - 2019-07-12 01:19:38 --> Total execution time: 0.7638
INFO - 2019-07-12 01:19:41 --> Helper loaded: language_helper
INFO - 2019-07-12 01:19:42 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:19:42 --> Model Class Initialized
INFO - 2019-07-12 01:19:42 --> Model Class Initialized
INFO - 2019-07-12 01:19:42 --> Model Class Initialized
INFO - 2019-07-12 01:19:42 --> Model Class Initialized
INFO - 2019-07-12 01:19:42 --> Helper loaded: form_helper
INFO - 2019-07-12 01:19:42 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:19:42 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:19:42 --> Model Class Initialized
INFO - 2019-07-12 01:19:42 --> Model Class Initialized
INFO - 2019-07-12 01:19:42 --> Final output sent to browser
DEBUG - 2019-07-12 01:19:42 --> Total execution time: 0.7407
INFO - 2019-07-12 01:19:46 --> Helper loaded: language_helper
INFO - 2019-07-12 01:19:46 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:19:46 --> Model Class Initialized
INFO - 2019-07-12 01:19:46 --> Model Class Initialized
INFO - 2019-07-12 01:19:46 --> Model Class Initialized
INFO - 2019-07-12 01:19:46 --> Model Class Initialized
INFO - 2019-07-12 01:19:46 --> Helper loaded: form_helper
INFO - 2019-07-12 01:19:46 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:19:46 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:19:46 --> Model Class Initialized
INFO - 2019-07-12 01:19:46 --> Model Class Initialized
INFO - 2019-07-12 01:19:46 --> Final output sent to browser
DEBUG - 2019-07-12 01:19:46 --> Total execution time: 0.6944
INFO - 2019-07-12 01:19:47 --> Helper loaded: language_helper
INFO - 2019-07-12 01:19:47 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:19:47 --> Model Class Initialized
INFO - 2019-07-12 01:19:47 --> Model Class Initialized
INFO - 2019-07-12 01:19:47 --> Model Class Initialized
INFO - 2019-07-12 01:19:47 --> Model Class Initialized
INFO - 2019-07-12 01:19:47 --> Helper loaded: form_helper
INFO - 2019-07-12 01:19:47 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:19:47 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:19:47 --> Model Class Initialized
INFO - 2019-07-12 01:19:47 --> Model Class Initialized
INFO - 2019-07-12 01:19:47 --> Final output sent to browser
DEBUG - 2019-07-12 01:19:47 --> Total execution time: 0.7746
INFO - 2019-07-12 01:19:53 --> Helper loaded: language_helper
INFO - 2019-07-12 01:19:53 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:19:53 --> Model Class Initialized
INFO - 2019-07-12 01:19:53 --> Model Class Initialized
INFO - 2019-07-12 01:19:53 --> Model Class Initialized
INFO - 2019-07-12 01:19:53 --> Model Class Initialized
INFO - 2019-07-12 01:19:53 --> Helper loaded: form_helper
INFO - 2019-07-12 01:19:53 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:19:53 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:19:53 --> Model Class Initialized
INFO - 2019-07-12 01:19:53 --> Model Class Initialized
INFO - 2019-07-12 01:19:53 --> Final output sent to browser
DEBUG - 2019-07-12 01:19:53 --> Total execution time: 0.7721
INFO - 2019-07-12 01:21:02 --> Helper loaded: language_helper
INFO - 2019-07-12 01:21:02 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:21:02 --> Model Class Initialized
INFO - 2019-07-12 01:21:02 --> Model Class Initialized
INFO - 2019-07-12 01:21:02 --> Model Class Initialized
INFO - 2019-07-12 01:21:02 --> Model Class Initialized
INFO - 2019-07-12 01:21:02 --> Helper loaded: form_helper
INFO - 2019-07-12 01:21:02 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:21:02 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:21:02 --> Model Class Initialized
INFO - 2019-07-12 01:21:02 --> Model Class Initialized
INFO - 2019-07-12 01:21:02 --> Final output sent to browser
DEBUG - 2019-07-12 01:21:02 --> Total execution time: 0.7629
INFO - 2019-07-12 01:21:31 --> Helper loaded: language_helper
INFO - 2019-07-12 01:21:31 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:21:31 --> Model Class Initialized
INFO - 2019-07-12 01:21:31 --> Model Class Initialized
INFO - 2019-07-12 01:21:31 --> Model Class Initialized
INFO - 2019-07-12 01:21:31 --> Model Class Initialized
INFO - 2019-07-12 01:21:32 --> Model Class Initialized
INFO - 2019-07-12 01:21:32 --> Final output sent to browser
DEBUG - 2019-07-12 01:21:32 --> Total execution time: 0.6566
INFO - 2019-07-12 01:21:32 --> Helper loaded: language_helper
INFO - 2019-07-12 01:21:32 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:21:32 --> Model Class Initialized
INFO - 2019-07-12 01:21:32 --> Model Class Initialized
INFO - 2019-07-12 01:21:32 --> Model Class Initialized
INFO - 2019-07-12 01:21:32 --> Model Class Initialized
INFO - 2019-07-12 01:21:32 --> Helper loaded: form_helper
INFO - 2019-07-12 01:21:32 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:21:32 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:21:32 --> Model Class Initialized
INFO - 2019-07-12 01:21:32 --> Model Class Initialized
INFO - 2019-07-12 01:21:32 --> Final output sent to browser
DEBUG - 2019-07-12 01:21:32 --> Total execution time: 0.7915
INFO - 2019-07-12 01:21:34 --> Helper loaded: language_helper
INFO - 2019-07-12 01:21:34 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:21:34 --> Model Class Initialized
INFO - 2019-07-12 01:21:34 --> Model Class Initialized
INFO - 2019-07-12 01:21:34 --> Model Class Initialized
INFO - 2019-07-12 01:21:34 --> Model Class Initialized
INFO - 2019-07-12 01:21:34 --> Helper loaded: form_helper
INFO - 2019-07-12 01:21:34 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:21:34 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:21:34 --> Model Class Initialized
INFO - 2019-07-12 01:21:34 --> Model Class Initialized
INFO - 2019-07-12 01:21:34 --> Final output sent to browser
DEBUG - 2019-07-12 01:21:34 --> Total execution time: 0.9636
INFO - 2019-07-12 01:21:34 --> Helper loaded: language_helper
INFO - 2019-07-12 01:21:34 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:21:34 --> Model Class Initialized
INFO - 2019-07-12 01:21:34 --> Model Class Initialized
INFO - 2019-07-12 01:21:34 --> Model Class Initialized
INFO - 2019-07-12 01:21:34 --> Model Class Initialized
INFO - 2019-07-12 01:21:34 --> Helper loaded: form_helper
INFO - 2019-07-12 01:21:34 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:21:34 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:21:34 --> Model Class Initialized
INFO - 2019-07-12 01:21:34 --> Model Class Initialized
INFO - 2019-07-12 01:21:34 --> Final output sent to browser
DEBUG - 2019-07-12 01:21:34 --> Total execution time: 0.9945
INFO - 2019-07-12 01:21:41 --> Helper loaded: language_helper
INFO - 2019-07-12 01:21:41 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:21:41 --> Model Class Initialized
INFO - 2019-07-12 01:21:41 --> Model Class Initialized
INFO - 2019-07-12 01:21:41 --> Model Class Initialized
INFO - 2019-07-12 01:21:41 --> Model Class Initialized
INFO - 2019-07-12 01:21:41 --> Helper loaded: form_helper
INFO - 2019-07-12 01:21:41 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:21:41 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:21:41 --> Model Class Initialized
INFO - 2019-07-12 01:21:41 --> Model Class Initialized
INFO - 2019-07-12 01:21:41 --> Final output sent to browser
DEBUG - 2019-07-12 01:21:41 --> Total execution time: 0.7682
INFO - 2019-07-12 01:21:51 --> Helper loaded: language_helper
INFO - 2019-07-12 01:21:51 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:21:51 --> Model Class Initialized
INFO - 2019-07-12 01:21:51 --> Model Class Initialized
INFO - 2019-07-12 01:21:51 --> Model Class Initialized
INFO - 2019-07-12 01:21:51 --> Model Class Initialized
INFO - 2019-07-12 01:21:51 --> Helper loaded: form_helper
INFO - 2019-07-12 01:21:51 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:21:51 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:21:52 --> Model Class Initialized
INFO - 2019-07-12 01:21:52 --> Model Class Initialized
INFO - 2019-07-12 01:21:52 --> Final output sent to browser
DEBUG - 2019-07-12 01:21:52 --> Total execution time: 0.7751
INFO - 2019-07-12 01:22:05 --> Helper loaded: language_helper
INFO - 2019-07-12 01:22:05 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:22:05 --> Model Class Initialized
INFO - 2019-07-12 01:22:05 --> Model Class Initialized
INFO - 2019-07-12 01:22:05 --> Model Class Initialized
INFO - 2019-07-12 01:22:05 --> Model Class Initialized
INFO - 2019-07-12 01:22:05 --> Helper loaded: form_helper
INFO - 2019-07-12 01:22:05 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:22:05 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:22:05 --> Model Class Initialized
INFO - 2019-07-12 01:22:05 --> Model Class Initialized
INFO - 2019-07-12 01:22:05 --> Final output sent to browser
DEBUG - 2019-07-12 01:22:05 --> Total execution time: 0.7572
INFO - 2019-07-12 01:22:09 --> Helper loaded: language_helper
INFO - 2019-07-12 01:22:09 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:22:09 --> Model Class Initialized
INFO - 2019-07-12 01:22:09 --> Model Class Initialized
INFO - 2019-07-12 01:22:09 --> Model Class Initialized
INFO - 2019-07-12 01:22:09 --> Model Class Initialized
INFO - 2019-07-12 01:22:09 --> Helper loaded: form_helper
INFO - 2019-07-12 01:22:09 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:22:09 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:22:09 --> Model Class Initialized
INFO - 2019-07-12 01:22:09 --> Model Class Initialized
INFO - 2019-07-12 01:22:09 --> Final output sent to browser
DEBUG - 2019-07-12 01:22:09 --> Total execution time: 0.6975
INFO - 2019-07-12 01:22:10 --> Helper loaded: language_helper
INFO - 2019-07-12 01:22:10 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:22:10 --> Model Class Initialized
INFO - 2019-07-12 01:22:10 --> Model Class Initialized
INFO - 2019-07-12 01:22:10 --> Model Class Initialized
INFO - 2019-07-12 01:22:11 --> Model Class Initialized
INFO - 2019-07-12 01:22:11 --> Helper loaded: form_helper
INFO - 2019-07-12 01:22:11 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:22:11 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:22:11 --> Model Class Initialized
INFO - 2019-07-12 01:22:11 --> Model Class Initialized
INFO - 2019-07-12 01:22:11 --> Final output sent to browser
DEBUG - 2019-07-12 01:22:11 --> Total execution time: 1.1610
INFO - 2019-07-12 01:22:11 --> Helper loaded: language_helper
INFO - 2019-07-12 01:22:11 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:22:11 --> Model Class Initialized
INFO - 2019-07-12 01:22:11 --> Model Class Initialized
INFO - 2019-07-12 01:22:11 --> Model Class Initialized
INFO - 2019-07-12 01:22:11 --> Model Class Initialized
INFO - 2019-07-12 01:22:11 --> Helper loaded: form_helper
INFO - 2019-07-12 01:22:11 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:22:11 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:22:11 --> Model Class Initialized
INFO - 2019-07-12 01:22:11 --> Model Class Initialized
INFO - 2019-07-12 01:22:11 --> Final output sent to browser
DEBUG - 2019-07-12 01:22:11 --> Total execution time: 1.5264
INFO - 2019-07-12 01:22:11 --> Helper loaded: language_helper
INFO - 2019-07-12 01:22:11 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:22:11 --> Model Class Initialized
INFO - 2019-07-12 01:22:11 --> Model Class Initialized
INFO - 2019-07-12 01:22:11 --> Model Class Initialized
INFO - 2019-07-12 01:22:11 --> Model Class Initialized
INFO - 2019-07-12 01:22:11 --> Helper loaded: form_helper
INFO - 2019-07-12 01:22:11 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:22:11 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:22:11 --> Model Class Initialized
INFO - 2019-07-12 01:22:11 --> Model Class Initialized
INFO - 2019-07-12 01:22:11 --> Final output sent to browser
DEBUG - 2019-07-12 01:22:11 --> Total execution time: 0.7827
INFO - 2019-07-12 01:22:17 --> Helper loaded: language_helper
INFO - 2019-07-12 01:22:17 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:22:17 --> Model Class Initialized
INFO - 2019-07-12 01:22:17 --> Model Class Initialized
INFO - 2019-07-12 01:22:17 --> Model Class Initialized
INFO - 2019-07-12 01:22:17 --> Model Class Initialized
INFO - 2019-07-12 01:22:17 --> Helper loaded: form_helper
INFO - 2019-07-12 01:22:17 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:22:17 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:22:17 --> Model Class Initialized
INFO - 2019-07-12 01:22:17 --> Model Class Initialized
INFO - 2019-07-12 01:22:17 --> Final output sent to browser
DEBUG - 2019-07-12 01:22:17 --> Total execution time: 0.7566
INFO - 2019-07-12 01:22:23 --> Helper loaded: language_helper
INFO - 2019-07-12 01:22:24 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:22:24 --> Model Class Initialized
INFO - 2019-07-12 01:22:24 --> Model Class Initialized
INFO - 2019-07-12 01:22:24 --> Model Class Initialized
INFO - 2019-07-12 01:22:24 --> Model Class Initialized
INFO - 2019-07-12 01:22:24 --> Helper loaded: form_helper
INFO - 2019-07-12 01:22:24 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:22:24 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:22:24 --> Model Class Initialized
INFO - 2019-07-12 01:22:24 --> Model Class Initialized
INFO - 2019-07-12 01:22:24 --> Final output sent to browser
DEBUG - 2019-07-12 01:22:24 --> Total execution time: 0.7372
INFO - 2019-07-12 01:22:27 --> Helper loaded: language_helper
INFO - 2019-07-12 01:22:27 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:22:27 --> Model Class Initialized
INFO - 2019-07-12 01:22:27 --> Model Class Initialized
INFO - 2019-07-12 01:22:27 --> Model Class Initialized
INFO - 2019-07-12 01:22:27 --> Model Class Initialized
INFO - 2019-07-12 01:22:27 --> Helper loaded: form_helper
INFO - 2019-07-12 01:22:27 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:22:27 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:22:27 --> Model Class Initialized
INFO - 2019-07-12 01:22:27 --> Model Class Initialized
INFO - 2019-07-12 01:22:27 --> Final output sent to browser
DEBUG - 2019-07-12 01:22:27 --> Total execution time: 0.7326
INFO - 2019-07-12 01:22:28 --> Helper loaded: language_helper
INFO - 2019-07-12 01:22:28 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:22:28 --> Model Class Initialized
INFO - 2019-07-12 01:22:28 --> Model Class Initialized
INFO - 2019-07-12 01:22:28 --> Model Class Initialized
INFO - 2019-07-12 01:22:28 --> Model Class Initialized
INFO - 2019-07-12 01:22:28 --> Helper loaded: form_helper
INFO - 2019-07-12 01:22:29 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:22:29 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:22:29 --> Model Class Initialized
INFO - 2019-07-12 01:22:29 --> Model Class Initialized
INFO - 2019-07-12 01:22:29 --> Final output sent to browser
DEBUG - 2019-07-12 01:22:29 --> Total execution time: 0.7511
INFO - 2019-07-12 01:22:33 --> Helper loaded: language_helper
INFO - 2019-07-12 01:22:33 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:22:33 --> Model Class Initialized
INFO - 2019-07-12 01:22:33 --> Model Class Initialized
INFO - 2019-07-12 01:22:33 --> Model Class Initialized
INFO - 2019-07-12 01:22:33 --> Model Class Initialized
INFO - 2019-07-12 01:22:33 --> Helper loaded: form_helper
INFO - 2019-07-12 01:22:33 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:22:33 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:22:33 --> Model Class Initialized
INFO - 2019-07-12 01:22:33 --> Model Class Initialized
INFO - 2019-07-12 01:22:33 --> Final output sent to browser
DEBUG - 2019-07-12 01:22:33 --> Total execution time: 0.7258
INFO - 2019-07-12 01:22:34 --> Helper loaded: language_helper
INFO - 2019-07-12 01:22:34 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:22:34 --> Model Class Initialized
INFO - 2019-07-12 01:22:34 --> Model Class Initialized
INFO - 2019-07-12 01:22:34 --> Model Class Initialized
INFO - 2019-07-12 01:22:34 --> Model Class Initialized
INFO - 2019-07-12 01:22:34 --> Helper loaded: form_helper
INFO - 2019-07-12 01:22:34 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:22:34 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:22:34 --> Model Class Initialized
INFO - 2019-07-12 01:22:34 --> Model Class Initialized
INFO - 2019-07-12 01:22:34 --> Final output sent to browser
DEBUG - 2019-07-12 01:22:34 --> Total execution time: 0.7493
INFO - 2019-07-12 01:22:37 --> Helper loaded: language_helper
INFO - 2019-07-12 01:22:37 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:22:37 --> Model Class Initialized
INFO - 2019-07-12 01:22:37 --> Model Class Initialized
INFO - 2019-07-12 01:22:37 --> Model Class Initialized
INFO - 2019-07-12 01:22:37 --> Model Class Initialized
INFO - 2019-07-12 01:22:38 --> Helper loaded: form_helper
INFO - 2019-07-12 01:22:38 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:22:38 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:22:38 --> Model Class Initialized
INFO - 2019-07-12 01:22:38 --> Model Class Initialized
INFO - 2019-07-12 01:22:38 --> Final output sent to browser
DEBUG - 2019-07-12 01:22:38 --> Total execution time: 0.7494
INFO - 2019-07-12 01:22:43 --> Helper loaded: language_helper
INFO - 2019-07-12 01:22:43 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:22:43 --> Model Class Initialized
INFO - 2019-07-12 01:22:43 --> Model Class Initialized
INFO - 2019-07-12 01:22:43 --> Model Class Initialized
INFO - 2019-07-12 01:22:43 --> Model Class Initialized
INFO - 2019-07-12 01:22:43 --> Model Class Initialized
INFO - 2019-07-12 01:22:44 --> Final output sent to browser
DEBUG - 2019-07-12 01:22:44 --> Total execution time: 0.6855
INFO - 2019-07-12 01:22:44 --> Helper loaded: language_helper
INFO - 2019-07-12 01:22:44 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:22:44 --> Model Class Initialized
INFO - 2019-07-12 01:22:44 --> Model Class Initialized
INFO - 2019-07-12 01:22:44 --> Model Class Initialized
INFO - 2019-07-12 01:22:44 --> Model Class Initialized
INFO - 2019-07-12 01:22:44 --> Helper loaded: form_helper
INFO - 2019-07-12 01:22:44 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:22:44 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:22:44 --> Model Class Initialized
INFO - 2019-07-12 01:22:44 --> Model Class Initialized
INFO - 2019-07-12 01:22:44 --> Final output sent to browser
DEBUG - 2019-07-12 01:22:44 --> Total execution time: 0.7748
INFO - 2019-07-12 01:23:44 --> Helper loaded: language_helper
INFO - 2019-07-12 01:23:44 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:23:44 --> Helper loaded: language_helper
INFO - 2019-07-12 01:23:44 --> Model Class Initialized
INFO - 2019-07-12 01:23:44 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:23:44 --> Model Class Initialized
INFO - 2019-07-12 01:23:44 --> Model Class Initialized
INFO - 2019-07-12 01:23:44 --> Model Class Initialized
INFO - 2019-07-12 01:23:44 --> Model Class Initialized
INFO - 2019-07-12 01:23:44 --> Model Class Initialized
INFO - 2019-07-12 01:23:44 --> Model Class Initialized
INFO - 2019-07-12 01:23:44 --> Model Class Initialized
INFO - 2019-07-12 01:23:44 --> Model Class Initialized
INFO - 2019-07-12 01:23:44 --> Final output sent to browser
INFO - 2019-07-12 01:23:44 --> Helper loaded: form_helper
DEBUG - 2019-07-12 01:23:44 --> Total execution time: 1.1918
INFO - 2019-07-12 01:23:44 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:23:44 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:23:44 --> Model Class Initialized
INFO - 2019-07-12 01:23:44 --> Model Class Initialized
INFO - 2019-07-12 01:23:44 --> Final output sent to browser
DEBUG - 2019-07-12 01:23:44 --> Total execution time: 1.2332
INFO - 2019-07-12 01:23:45 --> Helper loaded: language_helper
INFO - 2019-07-12 01:23:45 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:23:45 --> Model Class Initialized
INFO - 2019-07-12 01:23:45 --> Model Class Initialized
INFO - 2019-07-12 01:23:45 --> Model Class Initialized
INFO - 2019-07-12 01:23:45 --> Model Class Initialized
INFO - 2019-07-12 01:23:45 --> Helper loaded: form_helper
INFO - 2019-07-12 01:23:45 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:23:45 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:23:45 --> Model Class Initialized
INFO - 2019-07-12 01:23:45 --> Model Class Initialized
INFO - 2019-07-12 01:23:45 --> Final output sent to browser
DEBUG - 2019-07-12 01:23:45 --> Total execution time: 0.8592
INFO - 2019-07-12 01:24:17 --> Helper loaded: language_helper
INFO - 2019-07-12 01:24:17 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:24:17 --> Model Class Initialized
INFO - 2019-07-12 01:24:17 --> Model Class Initialized
INFO - 2019-07-12 01:24:17 --> Model Class Initialized
INFO - 2019-07-12 01:24:17 --> Model Class Initialized
INFO - 2019-07-12 01:24:17 --> Model Class Initialized
INFO - 2019-07-12 01:24:17 --> Helper loaded: language_helper
INFO - 2019-07-12 01:24:17 --> Final output sent to browser
INFO - 2019-07-12 01:24:17 --> Language file loaded: language/english/general_lang.php
DEBUG - 2019-07-12 01:24:17 --> Total execution time: 1.1531
INFO - 2019-07-12 01:24:17 --> Model Class Initialized
INFO - 2019-07-12 01:24:17 --> Model Class Initialized
INFO - 2019-07-12 01:24:17 --> Model Class Initialized
INFO - 2019-07-12 01:24:17 --> Model Class Initialized
INFO - 2019-07-12 01:24:17 --> Helper loaded: form_helper
INFO - 2019-07-12 01:24:18 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:24:18 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:24:18 --> Model Class Initialized
INFO - 2019-07-12 01:24:18 --> Model Class Initialized
INFO - 2019-07-12 01:24:18 --> Final output sent to browser
DEBUG - 2019-07-12 01:24:18 --> Total execution time: 1.1650
INFO - 2019-07-12 01:24:18 --> Helper loaded: language_helper
INFO - 2019-07-12 01:24:18 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:24:18 --> Model Class Initialized
INFO - 2019-07-12 01:24:18 --> Model Class Initialized
INFO - 2019-07-12 01:24:18 --> Model Class Initialized
INFO - 2019-07-12 01:24:18 --> Model Class Initialized
INFO - 2019-07-12 01:24:18 --> Helper loaded: form_helper
INFO - 2019-07-12 01:24:18 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:24:18 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:24:18 --> Model Class Initialized
INFO - 2019-07-12 01:24:18 --> Model Class Initialized
INFO - 2019-07-12 01:24:18 --> Final output sent to browser
DEBUG - 2019-07-12 01:24:18 --> Total execution time: 0.8426
INFO - 2019-07-12 01:24:26 --> Helper loaded: language_helper
INFO - 2019-07-12 01:24:26 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:24:26 --> Model Class Initialized
INFO - 2019-07-12 01:24:26 --> Model Class Initialized
INFO - 2019-07-12 01:24:26 --> Model Class Initialized
INFO - 2019-07-12 01:24:26 --> Model Class Initialized
INFO - 2019-07-12 01:24:26 --> Model Class Initialized
INFO - 2019-07-12 01:24:26 --> Final output sent to browser
DEBUG - 2019-07-12 01:24:26 --> Total execution time: 1.1475
INFO - 2019-07-12 01:24:26 --> Helper loaded: language_helper
INFO - 2019-07-12 01:24:27 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:24:27 --> Model Class Initialized
INFO - 2019-07-12 01:24:27 --> Model Class Initialized
INFO - 2019-07-12 01:24:27 --> Model Class Initialized
INFO - 2019-07-12 01:24:27 --> Model Class Initialized
INFO - 2019-07-12 01:24:27 --> Helper loaded: form_helper
INFO - 2019-07-12 01:24:27 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:24:27 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:24:27 --> Model Class Initialized
INFO - 2019-07-12 01:24:27 --> Model Class Initialized
INFO - 2019-07-12 01:24:27 --> Final output sent to browser
DEBUG - 2019-07-12 01:24:27 --> Total execution time: 1.0495
INFO - 2019-07-12 01:24:27 --> Helper loaded: language_helper
INFO - 2019-07-12 01:24:27 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:24:27 --> Model Class Initialized
INFO - 2019-07-12 01:24:27 --> Model Class Initialized
INFO - 2019-07-12 01:24:27 --> Model Class Initialized
INFO - 2019-07-12 01:24:27 --> Model Class Initialized
INFO - 2019-07-12 01:24:27 --> Helper loaded: form_helper
INFO - 2019-07-12 01:24:27 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:24:27 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:24:27 --> Model Class Initialized
INFO - 2019-07-12 01:24:27 --> Model Class Initialized
INFO - 2019-07-12 01:24:27 --> Final output sent to browser
DEBUG - 2019-07-12 01:24:27 --> Total execution time: 0.8296
INFO - 2019-07-12 01:24:39 --> Helper loaded: language_helper
INFO - 2019-07-12 01:24:39 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:24:39 --> Model Class Initialized
INFO - 2019-07-12 01:24:39 --> Model Class Initialized
INFO - 2019-07-12 01:24:39 --> Model Class Initialized
INFO - 2019-07-12 01:24:39 --> Model Class Initialized
INFO - 2019-07-12 01:24:39 --> Model Class Initialized
INFO - 2019-07-12 01:24:39 --> Final output sent to browser
DEBUG - 2019-07-12 01:24:39 --> Total execution time: 0.6776
INFO - 2019-07-12 01:24:40 --> Helper loaded: language_helper
INFO - 2019-07-12 01:24:40 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:24:40 --> Model Class Initialized
INFO - 2019-07-12 01:24:40 --> Model Class Initialized
INFO - 2019-07-12 01:24:40 --> Model Class Initialized
INFO - 2019-07-12 01:24:40 --> Model Class Initialized
INFO - 2019-07-12 01:24:40 --> Helper loaded: form_helper
INFO - 2019-07-12 01:24:40 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:24:40 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:24:40 --> Model Class Initialized
INFO - 2019-07-12 01:24:40 --> Model Class Initialized
INFO - 2019-07-12 01:24:40 --> Final output sent to browser
DEBUG - 2019-07-12 01:24:40 --> Total execution time: 0.7742
INFO - 2019-07-12 01:24:43 --> Helper loaded: language_helper
INFO - 2019-07-12 01:24:43 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:24:43 --> Model Class Initialized
INFO - 2019-07-12 01:24:43 --> Model Class Initialized
INFO - 2019-07-12 01:24:43 --> Model Class Initialized
INFO - 2019-07-12 01:24:43 --> Model Class Initialized
INFO - 2019-07-12 01:24:43 --> Model Class Initialized
INFO - 2019-07-12 01:24:43 --> Final output sent to browser
DEBUG - 2019-07-12 01:24:43 --> Total execution time: 0.7176
INFO - 2019-07-12 01:24:44 --> Helper loaded: language_helper
INFO - 2019-07-12 01:24:44 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:24:44 --> Model Class Initialized
INFO - 2019-07-12 01:24:44 --> Model Class Initialized
INFO - 2019-07-12 01:24:44 --> Model Class Initialized
INFO - 2019-07-12 01:24:44 --> Model Class Initialized
INFO - 2019-07-12 01:24:44 --> Model Class Initialized
INFO - 2019-07-12 01:24:44 --> Final output sent to browser
DEBUG - 2019-07-12 01:24:44 --> Total execution time: 0.7231
INFO - 2019-07-12 01:24:47 --> Helper loaded: language_helper
INFO - 2019-07-12 01:24:47 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:24:47 --> Model Class Initialized
INFO - 2019-07-12 01:24:47 --> Model Class Initialized
INFO - 2019-07-12 01:24:47 --> Model Class Initialized
INFO - 2019-07-12 01:24:47 --> Model Class Initialized
INFO - 2019-07-12 01:24:47 --> Model Class Initialized
INFO - 2019-07-12 01:24:47 --> Final output sent to browser
DEBUG - 2019-07-12 01:24:48 --> Total execution time: 0.7254
INFO - 2019-07-12 01:24:48 --> Helper loaded: language_helper
INFO - 2019-07-12 01:24:48 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:24:48 --> Model Class Initialized
INFO - 2019-07-12 01:24:48 --> Model Class Initialized
INFO - 2019-07-12 01:24:48 --> Model Class Initialized
INFO - 2019-07-12 01:24:48 --> Model Class Initialized
INFO - 2019-07-12 01:24:48 --> Helper loaded: form_helper
INFO - 2019-07-12 01:24:48 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:24:48 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:24:48 --> Model Class Initialized
INFO - 2019-07-12 01:24:48 --> Model Class Initialized
INFO - 2019-07-12 01:24:48 --> Final output sent to browser
DEBUG - 2019-07-12 01:24:48 --> Total execution time: 0.8269
INFO - 2019-07-12 01:24:54 --> Helper loaded: language_helper
INFO - 2019-07-12 01:24:54 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:24:54 --> Model Class Initialized
INFO - 2019-07-12 01:24:54 --> Model Class Initialized
INFO - 2019-07-12 01:24:54 --> Model Class Initialized
INFO - 2019-07-12 01:24:54 --> Model Class Initialized
INFO - 2019-07-12 01:24:54 --> Model Class Initialized
INFO - 2019-07-12 01:24:54 --> Final output sent to browser
DEBUG - 2019-07-12 01:24:54 --> Total execution time: 0.7305
INFO - 2019-07-12 01:24:56 --> Helper loaded: language_helper
INFO - 2019-07-12 01:24:56 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:24:56 --> Model Class Initialized
INFO - 2019-07-12 01:24:56 --> Model Class Initialized
INFO - 2019-07-12 01:24:56 --> Model Class Initialized
INFO - 2019-07-12 01:24:56 --> Model Class Initialized
INFO - 2019-07-12 01:24:56 --> Model Class Initialized
INFO - 2019-07-12 01:24:56 --> Final output sent to browser
DEBUG - 2019-07-12 01:24:56 --> Total execution time: 0.9063
INFO - 2019-07-12 01:24:59 --> Helper loaded: language_helper
INFO - 2019-07-12 01:24:59 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:24:59 --> Model Class Initialized
INFO - 2019-07-12 01:24:59 --> Model Class Initialized
INFO - 2019-07-12 01:24:59 --> Model Class Initialized
INFO - 2019-07-12 01:24:59 --> Model Class Initialized
INFO - 2019-07-12 01:24:59 --> Model Class Initialized
INFO - 2019-07-12 01:24:59 --> Final output sent to browser
DEBUG - 2019-07-12 01:24:59 --> Total execution time: 0.7782
INFO - 2019-07-12 01:25:01 --> Helper loaded: language_helper
INFO - 2019-07-12 01:25:01 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:25:01 --> Model Class Initialized
INFO - 2019-07-12 01:25:01 --> Model Class Initialized
INFO - 2019-07-12 01:25:01 --> Model Class Initialized
INFO - 2019-07-12 01:25:01 --> Model Class Initialized
INFO - 2019-07-12 01:25:01 --> Model Class Initialized
INFO - 2019-07-12 01:25:01 --> Final output sent to browser
DEBUG - 2019-07-12 01:25:01 --> Total execution time: 1.0300
INFO - 2019-07-12 01:25:06 --> Helper loaded: language_helper
INFO - 2019-07-12 01:25:06 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:25:06 --> Model Class Initialized
INFO - 2019-07-12 01:25:06 --> Model Class Initialized
INFO - 2019-07-12 01:25:06 --> Model Class Initialized
INFO - 2019-07-12 01:25:06 --> Model Class Initialized
INFO - 2019-07-12 01:25:06 --> Model Class Initialized
INFO - 2019-07-12 01:25:06 --> Final output sent to browser
DEBUG - 2019-07-12 01:25:06 --> Total execution time: 0.9619
INFO - 2019-07-12 01:25:07 --> Helper loaded: language_helper
INFO - 2019-07-12 01:25:07 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:25:07 --> Model Class Initialized
INFO - 2019-07-12 01:25:07 --> Model Class Initialized
INFO - 2019-07-12 01:25:07 --> Model Class Initialized
INFO - 2019-07-12 01:25:07 --> Model Class Initialized
INFO - 2019-07-12 01:25:07 --> Helper loaded: form_helper
INFO - 2019-07-12 01:25:07 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:25:07 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:25:07 --> Model Class Initialized
INFO - 2019-07-12 01:25:07 --> Model Class Initialized
INFO - 2019-07-12 01:25:07 --> Final output sent to browser
DEBUG - 2019-07-12 01:25:07 --> Total execution time: 1.3867
INFO - 2019-07-12 01:25:09 --> Helper loaded: language_helper
INFO - 2019-07-12 01:25:09 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:25:09 --> Model Class Initialized
INFO - 2019-07-12 01:25:09 --> Model Class Initialized
INFO - 2019-07-12 01:25:09 --> Model Class Initialized
INFO - 2019-07-12 01:25:09 --> Model Class Initialized
INFO - 2019-07-12 01:25:09 --> Model Class Initialized
INFO - 2019-07-12 01:25:09 --> Final output sent to browser
DEBUG - 2019-07-12 01:25:09 --> Total execution time: 0.7414
INFO - 2019-07-12 01:25:12 --> Helper loaded: language_helper
INFO - 2019-07-12 01:25:12 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:25:12 --> Model Class Initialized
INFO - 2019-07-12 01:25:12 --> Model Class Initialized
INFO - 2019-07-12 01:25:12 --> Model Class Initialized
INFO - 2019-07-12 01:25:12 --> Model Class Initialized
INFO - 2019-07-12 01:25:12 --> Helper loaded: form_helper
INFO - 2019-07-12 01:25:12 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:25:12 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:25:12 --> Model Class Initialized
INFO - 2019-07-12 01:25:12 --> Model Class Initialized
INFO - 2019-07-12 01:25:12 --> Final output sent to browser
DEBUG - 2019-07-12 01:25:12 --> Total execution time: 0.7871
INFO - 2019-07-12 01:25:13 --> Helper loaded: language_helper
INFO - 2019-07-12 01:25:13 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:25:13 --> Model Class Initialized
INFO - 2019-07-12 01:25:13 --> Model Class Initialized
INFO - 2019-07-12 01:25:13 --> Model Class Initialized
INFO - 2019-07-12 01:25:13 --> Model Class Initialized
INFO - 2019-07-12 01:25:13 --> Helper loaded: form_helper
INFO - 2019-07-12 01:25:13 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:25:13 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:25:13 --> Model Class Initialized
INFO - 2019-07-12 01:25:13 --> Model Class Initialized
INFO - 2019-07-12 01:25:13 --> Final output sent to browser
DEBUG - 2019-07-12 01:25:13 --> Total execution time: 0.8530
INFO - 2019-07-12 01:25:15 --> Helper loaded: language_helper
INFO - 2019-07-12 01:25:15 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:25:15 --> Model Class Initialized
INFO - 2019-07-12 01:25:15 --> Model Class Initialized
INFO - 2019-07-12 01:25:15 --> Model Class Initialized
INFO - 2019-07-12 01:25:15 --> Model Class Initialized
INFO - 2019-07-12 01:25:15 --> Helper loaded: form_helper
INFO - 2019-07-12 01:25:15 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:25:15 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:25:15 --> Model Class Initialized
INFO - 2019-07-12 01:25:15 --> Model Class Initialized
INFO - 2019-07-12 01:25:15 --> Final output sent to browser
DEBUG - 2019-07-12 01:25:15 --> Total execution time: 0.7985
INFO - 2019-07-12 01:25:16 --> Helper loaded: language_helper
INFO - 2019-07-12 01:25:16 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:25:16 --> Model Class Initialized
INFO - 2019-07-12 01:25:16 --> Model Class Initialized
INFO - 2019-07-12 01:25:16 --> Model Class Initialized
INFO - 2019-07-12 01:25:16 --> Model Class Initialized
INFO - 2019-07-12 01:25:16 --> Helper loaded: form_helper
INFO - 2019-07-12 01:25:16 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:25:16 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:25:16 --> Model Class Initialized
INFO - 2019-07-12 01:25:16 --> Model Class Initialized
INFO - 2019-07-12 01:25:16 --> Final output sent to browser
DEBUG - 2019-07-12 01:25:16 --> Total execution time: 0.7749
INFO - 2019-07-12 01:27:18 --> Helper loaded: language_helper
INFO - 2019-07-12 01:27:18 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:27:18 --> Model Class Initialized
INFO - 2019-07-12 01:27:18 --> Model Class Initialized
INFO - 2019-07-12 01:27:18 --> Model Class Initialized
INFO - 2019-07-12 01:27:18 --> Model Class Initialized
INFO - 2019-07-12 01:27:18 --> Model Class Initialized
INFO - 2019-07-12 01:27:18 --> Final output sent to browser
DEBUG - 2019-07-12 01:27:18 --> Total execution time: 0.9146
INFO - 2019-07-12 01:27:19 --> Helper loaded: language_helper
INFO - 2019-07-12 01:27:19 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:27:19 --> Model Class Initialized
INFO - 2019-07-12 01:27:19 --> Model Class Initialized
INFO - 2019-07-12 01:27:19 --> Model Class Initialized
INFO - 2019-07-12 01:27:19 --> Model Class Initialized
INFO - 2019-07-12 01:27:19 --> Helper loaded: form_helper
INFO - 2019-07-12 01:27:19 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:27:19 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:27:19 --> Model Class Initialized
INFO - 2019-07-12 01:27:19 --> Model Class Initialized
INFO - 2019-07-12 01:27:19 --> Final output sent to browser
INFO - 2019-07-12 01:27:19 --> Helper loaded: language_helper
DEBUG - 2019-07-12 01:27:19 --> Total execution time: 1.2611
INFO - 2019-07-12 01:27:19 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:27:19 --> Model Class Initialized
INFO - 2019-07-12 01:27:19 --> Model Class Initialized
INFO - 2019-07-12 01:27:19 --> Model Class Initialized
INFO - 2019-07-12 01:27:19 --> Model Class Initialized
INFO - 2019-07-12 01:27:19 --> Helper loaded: form_helper
INFO - 2019-07-12 01:27:19 --> Form Validation Class Initialized
INFO - 2019-07-12 01:27:19 --> Helper loaded: language_helper
DEBUG - 2019-07-12 01:27:19 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:27:19 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:27:19 --> Model Class Initialized
INFO - 2019-07-12 01:27:19 --> Model Class Initialized
INFO - 2019-07-12 01:27:19 --> Model Class Initialized
INFO - 2019-07-12 01:27:19 --> Model Class Initialized
INFO - 2019-07-12 01:27:19 --> Final output sent to browser
INFO - 2019-07-12 01:27:19 --> Model Class Initialized
DEBUG - 2019-07-12 01:27:19 --> Total execution time: 1.1351
INFO - 2019-07-12 01:27:19 --> Model Class Initialized
INFO - 2019-07-12 01:27:19 --> Model Class Initialized
INFO - 2019-07-12 01:27:19 --> Final output sent to browser
DEBUG - 2019-07-12 01:27:19 --> Total execution time: 1.5824
INFO - 2019-07-12 01:27:59 --> Helper loaded: language_helper
INFO - 2019-07-12 01:27:59 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:27:59 --> Model Class Initialized
INFO - 2019-07-12 01:27:59 --> Model Class Initialized
INFO - 2019-07-12 01:27:59 --> Model Class Initialized
INFO - 2019-07-12 01:27:59 --> Model Class Initialized
INFO - 2019-07-12 01:27:59 --> Model Class Initialized
INFO - 2019-07-12 01:28:01 --> Final output sent to browser
DEBUG - 2019-07-12 01:28:01 --> Total execution time: 2.4439
INFO - 2019-07-12 01:29:38 --> Helper loaded: language_helper
INFO - 2019-07-12 01:29:38 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:29:38 --> Model Class Initialized
INFO - 2019-07-12 01:29:38 --> Model Class Initialized
INFO - 2019-07-12 01:29:38 --> Model Class Initialized
INFO - 2019-07-12 01:29:38 --> Model Class Initialized
INFO - 2019-07-12 01:29:38 --> Helper loaded: form_helper
INFO - 2019-07-12 01:29:38 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:29:38 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:29:38 --> Model Class Initialized
INFO - 2019-07-12 01:29:38 --> Model Class Initialized
INFO - 2019-07-12 01:29:38 --> Final output sent to browser
DEBUG - 2019-07-12 01:29:38 --> Total execution time: 0.7912
INFO - 2019-07-12 01:29:43 --> Helper loaded: language_helper
INFO - 2019-07-12 01:29:43 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:29:43 --> Model Class Initialized
INFO - 2019-07-12 01:29:43 --> Model Class Initialized
INFO - 2019-07-12 01:29:43 --> Model Class Initialized
INFO - 2019-07-12 01:29:43 --> Model Class Initialized
INFO - 2019-07-12 01:29:43 --> Helper loaded: form_helper
INFO - 2019-07-12 01:29:43 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:29:43 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:29:43 --> Model Class Initialized
INFO - 2019-07-12 01:29:43 --> Model Class Initialized
INFO - 2019-07-12 01:29:43 --> Final output sent to browser
DEBUG - 2019-07-12 01:29:43 --> Total execution time: 0.8223
INFO - 2019-07-12 01:29:47 --> Helper loaded: language_helper
INFO - 2019-07-12 01:29:47 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:29:47 --> Model Class Initialized
INFO - 2019-07-12 01:29:48 --> Model Class Initialized
INFO - 2019-07-12 01:29:48 --> Model Class Initialized
INFO - 2019-07-12 01:29:48 --> Model Class Initialized
INFO - 2019-07-12 01:29:48 --> Model Class Initialized
INFO - 2019-07-12 01:29:48 --> Final output sent to browser
DEBUG - 2019-07-12 01:29:48 --> Total execution time: 0.6937
INFO - 2019-07-12 01:29:48 --> Helper loaded: language_helper
INFO - 2019-07-12 01:29:48 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:29:48 --> Model Class Initialized
INFO - 2019-07-12 01:29:48 --> Model Class Initialized
INFO - 2019-07-12 01:29:48 --> Model Class Initialized
INFO - 2019-07-12 01:29:48 --> Model Class Initialized
INFO - 2019-07-12 01:29:48 --> Helper loaded: form_helper
INFO - 2019-07-12 01:29:48 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:29:48 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:29:48 --> Model Class Initialized
INFO - 2019-07-12 01:29:48 --> Model Class Initialized
INFO - 2019-07-12 01:29:48 --> Final output sent to browser
DEBUG - 2019-07-12 01:29:48 --> Total execution time: 0.7976
INFO - 2019-07-12 01:30:19 --> Helper loaded: language_helper
INFO - 2019-07-12 01:30:19 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:30:19 --> Model Class Initialized
INFO - 2019-07-12 01:30:19 --> Model Class Initialized
INFO - 2019-07-12 01:30:19 --> Model Class Initialized
INFO - 2019-07-12 01:30:19 --> Model Class Initialized
INFO - 2019-07-12 01:30:19 --> Helper loaded: form_helper
INFO - 2019-07-12 01:30:19 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:30:19 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:30:19 --> Model Class Initialized
INFO - 2019-07-12 01:30:19 --> Model Class Initialized
INFO - 2019-07-12 01:30:19 --> Final output sent to browser
DEBUG - 2019-07-12 01:30:19 --> Total execution time: 0.7760
INFO - 2019-07-12 01:30:21 --> Helper loaded: language_helper
INFO - 2019-07-12 01:30:21 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:30:21 --> Model Class Initialized
INFO - 2019-07-12 01:30:21 --> Model Class Initialized
INFO - 2019-07-12 01:30:21 --> Model Class Initialized
INFO - 2019-07-12 01:30:21 --> Model Class Initialized
INFO - 2019-07-12 01:30:21 --> Helper loaded: form_helper
INFO - 2019-07-12 01:30:21 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:30:21 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:30:21 --> Model Class Initialized
INFO - 2019-07-12 01:30:21 --> Model Class Initialized
INFO - 2019-07-12 01:30:21 --> Final output sent to browser
DEBUG - 2019-07-12 01:30:21 --> Total execution time: 0.7487
INFO - 2019-07-12 01:30:22 --> Helper loaded: language_helper
INFO - 2019-07-12 01:30:22 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:30:22 --> Model Class Initialized
INFO - 2019-07-12 01:30:22 --> Model Class Initialized
INFO - 2019-07-12 01:30:22 --> Model Class Initialized
INFO - 2019-07-12 01:30:22 --> Model Class Initialized
INFO - 2019-07-12 01:30:22 --> Helper loaded: form_helper
INFO - 2019-07-12 01:30:22 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:30:22 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:30:22 --> Model Class Initialized
INFO - 2019-07-12 01:30:22 --> Model Class Initialized
INFO - 2019-07-12 01:30:22 --> Final output sent to browser
DEBUG - 2019-07-12 01:30:22 --> Total execution time: 0.8210
INFO - 2019-07-12 01:30:25 --> Helper loaded: language_helper
INFO - 2019-07-12 01:30:25 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:30:25 --> Model Class Initialized
INFO - 2019-07-12 01:30:25 --> Model Class Initialized
INFO - 2019-07-12 01:30:25 --> Model Class Initialized
INFO - 2019-07-12 01:30:25 --> Model Class Initialized
INFO - 2019-07-12 01:30:25 --> Helper loaded: form_helper
INFO - 2019-07-12 01:30:25 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:30:25 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:30:25 --> Model Class Initialized
INFO - 2019-07-12 01:30:25 --> Model Class Initialized
INFO - 2019-07-12 01:30:25 --> Final output sent to browser
DEBUG - 2019-07-12 01:30:25 --> Total execution time: 0.8272
INFO - 2019-07-12 01:30:47 --> Helper loaded: language_helper
INFO - 2019-07-12 01:30:47 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:30:47 --> Model Class Initialized
INFO - 2019-07-12 01:30:47 --> Model Class Initialized
INFO - 2019-07-12 01:30:47 --> Model Class Initialized
INFO - 2019-07-12 01:30:47 --> Model Class Initialized
INFO - 2019-07-12 01:30:47 --> Model Class Initialized
INFO - 2019-07-12 01:30:47 --> Final output sent to browser
DEBUG - 2019-07-12 01:30:47 --> Total execution time: 0.7158
INFO - 2019-07-12 01:30:48 --> Helper loaded: language_helper
INFO - 2019-07-12 01:30:48 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:30:48 --> Model Class Initialized
INFO - 2019-07-12 01:30:48 --> Model Class Initialized
INFO - 2019-07-12 01:30:48 --> Model Class Initialized
INFO - 2019-07-12 01:30:48 --> Model Class Initialized
INFO - 2019-07-12 01:30:48 --> Helper loaded: form_helper
INFO - 2019-07-12 01:30:48 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:30:48 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:30:48 --> Model Class Initialized
INFO - 2019-07-12 01:30:48 --> Model Class Initialized
INFO - 2019-07-12 01:30:48 --> Final output sent to browser
DEBUG - 2019-07-12 01:30:48 --> Total execution time: 0.8053
INFO - 2019-07-12 01:33:08 --> Helper loaded: language_helper
INFO - 2019-07-12 01:33:08 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:33:08 --> Model Class Initialized
INFO - 2019-07-12 01:33:08 --> Model Class Initialized
INFO - 2019-07-12 01:33:08 --> Model Class Initialized
INFO - 2019-07-12 01:33:08 --> Model Class Initialized
INFO - 2019-07-12 01:33:08 --> Helper loaded: form_helper
INFO - 2019-07-12 01:33:08 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:33:08 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:33:08 --> Model Class Initialized
INFO - 2019-07-12 01:33:08 --> Model Class Initialized
INFO - 2019-07-12 01:33:08 --> Final output sent to browser
DEBUG - 2019-07-12 01:33:08 --> Total execution time: 1.0844
INFO - 2019-07-12 01:33:08 --> Helper loaded: language_helper
INFO - 2019-07-12 01:33:09 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:33:09 --> Model Class Initialized
INFO - 2019-07-12 01:33:09 --> Model Class Initialized
INFO - 2019-07-12 01:33:09 --> Model Class Initialized
INFO - 2019-07-12 01:33:09 --> Model Class Initialized
INFO - 2019-07-12 01:33:09 --> Model Class Initialized
INFO - 2019-07-12 01:33:09 --> Final output sent to browser
DEBUG - 2019-07-12 01:33:09 --> Total execution time: 0.8472
INFO - 2019-07-12 01:33:09 --> Helper loaded: language_helper
INFO - 2019-07-12 01:33:09 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:33:09 --> Model Class Initialized
INFO - 2019-07-12 01:33:09 --> Model Class Initialized
INFO - 2019-07-12 01:33:09 --> Model Class Initialized
INFO - 2019-07-12 01:33:09 --> Model Class Initialized
INFO - 2019-07-12 01:33:09 --> Helper loaded: form_helper
INFO - 2019-07-12 01:33:09 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:33:09 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:33:09 --> Model Class Initialized
INFO - 2019-07-12 01:33:09 --> Model Class Initialized
INFO - 2019-07-12 01:33:09 --> Final output sent to browser
DEBUG - 2019-07-12 01:33:09 --> Total execution time: 0.7860
INFO - 2019-07-12 01:33:19 --> Helper loaded: language_helper
INFO - 2019-07-12 01:33:19 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:33:19 --> Model Class Initialized
INFO - 2019-07-12 01:33:19 --> Model Class Initialized
INFO - 2019-07-12 01:33:19 --> Model Class Initialized
INFO - 2019-07-12 01:33:19 --> Model Class Initialized
INFO - 2019-07-12 01:33:19 --> Helper loaded: form_helper
INFO - 2019-07-12 01:33:19 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:33:19 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:33:19 --> Model Class Initialized
INFO - 2019-07-12 01:33:19 --> Model Class Initialized
INFO - 2019-07-12 01:33:19 --> Final output sent to browser
DEBUG - 2019-07-12 01:33:19 --> Total execution time: 0.7787
INFO - 2019-07-12 01:33:20 --> Helper loaded: language_helper
INFO - 2019-07-12 01:33:21 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:33:21 --> Model Class Initialized
INFO - 2019-07-12 01:33:21 --> Model Class Initialized
INFO - 2019-07-12 01:33:21 --> Model Class Initialized
INFO - 2019-07-12 01:33:21 --> Model Class Initialized
INFO - 2019-07-12 01:33:21 --> Helper loaded: form_helper
INFO - 2019-07-12 01:33:21 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:33:21 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:33:21 --> Model Class Initialized
INFO - 2019-07-12 01:33:21 --> Model Class Initialized
INFO - 2019-07-12 01:33:21 --> Final output sent to browser
DEBUG - 2019-07-12 01:33:21 --> Total execution time: 0.8532
INFO - 2019-07-12 01:33:21 --> Helper loaded: language_helper
INFO - 2019-07-12 01:33:21 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:33:21 --> Model Class Initialized
INFO - 2019-07-12 01:33:21 --> Model Class Initialized
INFO - 2019-07-12 01:33:21 --> Model Class Initialized
INFO - 2019-07-12 01:33:21 --> Model Class Initialized
INFO - 2019-07-12 01:33:21 --> Helper loaded: form_helper
INFO - 2019-07-12 01:33:21 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:33:21 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:33:21 --> Model Class Initialized
INFO - 2019-07-12 01:33:21 --> Model Class Initialized
INFO - 2019-07-12 01:33:21 --> Final output sent to browser
DEBUG - 2019-07-12 01:33:21 --> Total execution time: 1.0906
INFO - 2019-07-12 01:33:22 --> Helper loaded: language_helper
INFO - 2019-07-12 01:33:22 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:33:22 --> Model Class Initialized
INFO - 2019-07-12 01:33:22 --> Model Class Initialized
INFO - 2019-07-12 01:33:22 --> Model Class Initialized
INFO - 2019-07-12 01:33:22 --> Model Class Initialized
INFO - 2019-07-12 01:33:22 --> Helper loaded: form_helper
INFO - 2019-07-12 01:33:22 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:33:22 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:33:22 --> Model Class Initialized
INFO - 2019-07-12 01:33:22 --> Model Class Initialized
INFO - 2019-07-12 01:33:22 --> Final output sent to browser
DEBUG - 2019-07-12 01:33:22 --> Total execution time: 1.0626
INFO - 2019-07-12 01:33:22 --> Helper loaded: language_helper
INFO - 2019-07-12 01:33:22 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:33:22 --> Model Class Initialized
INFO - 2019-07-12 01:33:22 --> Model Class Initialized
INFO - 2019-07-12 01:33:22 --> Model Class Initialized
INFO - 2019-07-12 01:33:22 --> Model Class Initialized
INFO - 2019-07-12 01:33:22 --> Helper loaded: form_helper
INFO - 2019-07-12 01:33:22 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:33:22 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:33:22 --> Model Class Initialized
INFO - 2019-07-12 01:33:22 --> Model Class Initialized
INFO - 2019-07-12 01:33:22 --> Final output sent to browser
DEBUG - 2019-07-12 01:33:22 --> Total execution time: 0.8406
INFO - 2019-07-12 01:33:27 --> Helper loaded: language_helper
INFO - 2019-07-12 01:33:27 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:33:27 --> Model Class Initialized
INFO - 2019-07-12 01:33:27 --> Model Class Initialized
INFO - 2019-07-12 01:33:27 --> Model Class Initialized
INFO - 2019-07-12 01:33:27 --> Model Class Initialized
INFO - 2019-07-12 01:33:27 --> Helper loaded: form_helper
INFO - 2019-07-12 01:33:27 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:33:27 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:33:27 --> Model Class Initialized
INFO - 2019-07-12 01:33:27 --> Model Class Initialized
INFO - 2019-07-12 01:33:27 --> Final output sent to browser
DEBUG - 2019-07-12 01:33:27 --> Total execution time: 0.7968
INFO - 2019-07-12 01:33:29 --> Helper loaded: language_helper
INFO - 2019-07-12 01:33:29 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:33:29 --> Model Class Initialized
INFO - 2019-07-12 01:33:29 --> Model Class Initialized
INFO - 2019-07-12 01:33:29 --> Model Class Initialized
INFO - 2019-07-12 01:33:29 --> Model Class Initialized
INFO - 2019-07-12 01:33:29 --> Helper loaded: form_helper
INFO - 2019-07-12 01:33:29 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:33:29 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:33:29 --> Model Class Initialized
INFO - 2019-07-12 01:33:29 --> Model Class Initialized
INFO - 2019-07-12 01:33:29 --> Final output sent to browser
DEBUG - 2019-07-12 01:33:29 --> Total execution time: 0.7627
INFO - 2019-07-12 01:33:30 --> Helper loaded: language_helper
INFO - 2019-07-12 01:33:30 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:33:30 --> Model Class Initialized
INFO - 2019-07-12 01:33:30 --> Model Class Initialized
INFO - 2019-07-12 01:33:30 --> Model Class Initialized
INFO - 2019-07-12 01:33:30 --> Model Class Initialized
INFO - 2019-07-12 01:33:30 --> Helper loaded: form_helper
INFO - 2019-07-12 01:33:30 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:33:30 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:33:30 --> Model Class Initialized
INFO - 2019-07-12 01:33:30 --> Model Class Initialized
INFO - 2019-07-12 01:33:30 --> Final output sent to browser
DEBUG - 2019-07-12 01:33:30 --> Total execution time: 0.9141
INFO - 2019-07-12 01:33:41 --> Helper loaded: language_helper
INFO - 2019-07-12 01:33:41 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:33:41 --> Model Class Initialized
INFO - 2019-07-12 01:33:41 --> Model Class Initialized
INFO - 2019-07-12 01:33:41 --> Model Class Initialized
INFO - 2019-07-12 01:33:41 --> Model Class Initialized
INFO - 2019-07-12 01:33:41 --> Helper loaded: form_helper
INFO - 2019-07-12 01:33:41 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:33:41 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:33:41 --> Model Class Initialized
INFO - 2019-07-12 01:33:41 --> Model Class Initialized
INFO - 2019-07-12 01:33:41 --> Final output sent to browser
DEBUG - 2019-07-12 01:33:41 --> Total execution time: 0.8086
INFO - 2019-07-12 01:33:51 --> Helper loaded: language_helper
INFO - 2019-07-12 01:33:51 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:33:51 --> Model Class Initialized
INFO - 2019-07-12 01:33:51 --> Model Class Initialized
INFO - 2019-07-12 01:33:51 --> Model Class Initialized
INFO - 2019-07-12 01:33:52 --> Model Class Initialized
INFO - 2019-07-12 01:33:52 --> Model Class Initialized
INFO - 2019-07-12 01:33:52 --> Final output sent to browser
DEBUG - 2019-07-12 01:33:52 --> Total execution time: 0.7357
INFO - 2019-07-12 01:33:54 --> Helper loaded: language_helper
INFO - 2019-07-12 01:33:54 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:33:54 --> Model Class Initialized
INFO - 2019-07-12 01:33:54 --> Model Class Initialized
INFO - 2019-07-12 01:33:54 --> Model Class Initialized
INFO - 2019-07-12 01:33:54 --> Model Class Initialized
INFO - 2019-07-12 01:33:54 --> Model Class Initialized
INFO - 2019-07-12 01:33:54 --> Final output sent to browser
DEBUG - 2019-07-12 01:33:54 --> Total execution time: 1.0830
INFO - 2019-07-12 01:33:57 --> Helper loaded: language_helper
INFO - 2019-07-12 01:33:57 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:33:57 --> Model Class Initialized
INFO - 2019-07-12 01:33:57 --> Model Class Initialized
INFO - 2019-07-12 01:33:57 --> Model Class Initialized
INFO - 2019-07-12 01:33:57 --> Model Class Initialized
INFO - 2019-07-12 01:33:57 --> Helper loaded: form_helper
INFO - 2019-07-12 01:33:57 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:33:57 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:33:57 --> Model Class Initialized
INFO - 2019-07-12 01:33:57 --> Model Class Initialized
INFO - 2019-07-12 01:33:57 --> Final output sent to browser
DEBUG - 2019-07-12 01:33:57 --> Total execution time: 1.0545
INFO - 2019-07-12 01:33:57 --> Helper loaded: language_helper
INFO - 2019-07-12 01:33:57 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:33:57 --> Model Class Initialized
INFO - 2019-07-12 01:33:57 --> Model Class Initialized
INFO - 2019-07-12 01:33:57 --> Model Class Initialized
INFO - 2019-07-12 01:33:57 --> Model Class Initialized
INFO - 2019-07-12 01:33:57 --> Model Class Initialized
INFO - 2019-07-12 01:33:57 --> Final output sent to browser
DEBUG - 2019-07-12 01:33:57 --> Total execution time: 1.2948
INFO - 2019-07-12 01:34:02 --> Helper loaded: language_helper
INFO - 2019-07-12 01:34:02 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:34:02 --> Model Class Initialized
INFO - 2019-07-12 01:34:02 --> Model Class Initialized
INFO - 2019-07-12 01:34:02 --> Model Class Initialized
INFO - 2019-07-12 01:34:02 --> Model Class Initialized
INFO - 2019-07-12 01:34:02 --> Model Class Initialized
INFO - 2019-07-12 01:34:02 --> Final output sent to browser
DEBUG - 2019-07-12 01:34:02 --> Total execution time: 0.7860
INFO - 2019-07-12 01:34:05 --> Helper loaded: language_helper
INFO - 2019-07-12 01:34:05 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:34:05 --> Model Class Initialized
INFO - 2019-07-12 01:34:05 --> Model Class Initialized
INFO - 2019-07-12 01:34:05 --> Model Class Initialized
INFO - 2019-07-12 01:34:05 --> Model Class Initialized
INFO - 2019-07-12 01:34:05 --> Helper loaded: form_helper
INFO - 2019-07-12 01:34:05 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:34:05 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:34:05 --> Model Class Initialized
INFO - 2019-07-12 01:34:05 --> Model Class Initialized
INFO - 2019-07-12 01:34:05 --> Final output sent to browser
DEBUG - 2019-07-12 01:34:05 --> Total execution time: 0.8354
INFO - 2019-07-12 01:34:06 --> Helper loaded: language_helper
INFO - 2019-07-12 01:34:06 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:34:06 --> Model Class Initialized
INFO - 2019-07-12 01:34:06 --> Model Class Initialized
INFO - 2019-07-12 01:34:06 --> Model Class Initialized
INFO - 2019-07-12 01:34:06 --> Model Class Initialized
INFO - 2019-07-12 01:34:06 --> Helper loaded: form_helper
INFO - 2019-07-12 01:34:06 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:34:06 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:34:06 --> Model Class Initialized
INFO - 2019-07-12 01:34:06 --> Model Class Initialized
INFO - 2019-07-12 01:34:06 --> Final output sent to browser
DEBUG - 2019-07-12 01:34:06 --> Total execution time: 0.8093
INFO - 2019-07-12 01:34:22 --> Helper loaded: language_helper
INFO - 2019-07-12 01:34:22 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:34:22 --> Model Class Initialized
INFO - 2019-07-12 01:34:22 --> Model Class Initialized
INFO - 2019-07-12 01:34:22 --> Model Class Initialized
INFO - 2019-07-12 01:34:22 --> Model Class Initialized
INFO - 2019-07-12 01:34:22 --> Helper loaded: form_helper
INFO - 2019-07-12 01:34:22 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:34:22 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:34:22 --> Model Class Initialized
INFO - 2019-07-12 01:34:22 --> Model Class Initialized
INFO - 2019-07-12 01:34:22 --> Final output sent to browser
DEBUG - 2019-07-12 01:34:22 --> Total execution time: 0.8100
INFO - 2019-07-12 01:34:23 --> Helper loaded: language_helper
INFO - 2019-07-12 01:34:23 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:34:23 --> Model Class Initialized
INFO - 2019-07-12 01:34:23 --> Model Class Initialized
INFO - 2019-07-12 01:34:23 --> Model Class Initialized
INFO - 2019-07-12 01:34:23 --> Model Class Initialized
INFO - 2019-07-12 01:34:23 --> Helper loaded: form_helper
INFO - 2019-07-12 01:34:23 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:34:23 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:34:23 --> Model Class Initialized
INFO - 2019-07-12 01:34:23 --> Model Class Initialized
INFO - 2019-07-12 01:34:23 --> Final output sent to browser
DEBUG - 2019-07-12 01:34:23 --> Total execution time: 0.7866
INFO - 2019-07-12 01:34:38 --> Helper loaded: language_helper
INFO - 2019-07-12 01:34:38 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:34:38 --> Model Class Initialized
INFO - 2019-07-12 01:34:38 --> Model Class Initialized
INFO - 2019-07-12 01:34:38 --> Model Class Initialized
INFO - 2019-07-12 01:34:38 --> Model Class Initialized
INFO - 2019-07-12 01:34:38 --> Helper loaded: form_helper
INFO - 2019-07-12 01:34:39 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:34:39 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:34:39 --> Model Class Initialized
INFO - 2019-07-12 01:34:39 --> Model Class Initialized
INFO - 2019-07-12 01:34:39 --> Final output sent to browser
DEBUG - 2019-07-12 01:34:39 --> Total execution time: 0.8125
INFO - 2019-07-12 01:35:05 --> Helper loaded: language_helper
INFO - 2019-07-12 01:35:05 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:35:05 --> Model Class Initialized
INFO - 2019-07-12 01:35:05 --> Model Class Initialized
INFO - 2019-07-12 01:35:05 --> Model Class Initialized
INFO - 2019-07-12 01:35:05 --> Model Class Initialized
INFO - 2019-07-12 01:35:05 --> Helper loaded: form_helper
INFO - 2019-07-12 01:35:05 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:35:05 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:35:05 --> Model Class Initialized
INFO - 2019-07-12 01:35:05 --> Model Class Initialized
INFO - 2019-07-12 01:35:05 --> Final output sent to browser
DEBUG - 2019-07-12 01:35:05 --> Total execution time: 0.8064
INFO - 2019-07-12 01:35:28 --> Helper loaded: language_helper
INFO - 2019-07-12 01:35:28 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:35:28 --> Model Class Initialized
INFO - 2019-07-12 01:35:28 --> Model Class Initialized
INFO - 2019-07-12 01:35:28 --> Model Class Initialized
INFO - 2019-07-12 01:35:28 --> Model Class Initialized
INFO - 2019-07-12 01:35:28 --> Helper loaded: form_helper
INFO - 2019-07-12 01:35:28 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:35:28 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:35:28 --> Model Class Initialized
INFO - 2019-07-12 01:35:28 --> Model Class Initialized
INFO - 2019-07-12 01:35:28 --> Final output sent to browser
DEBUG - 2019-07-12 01:35:28 --> Total execution time: 0.7635
INFO - 2019-07-12 01:35:59 --> Helper loaded: language_helper
INFO - 2019-07-12 01:35:59 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:35:59 --> Model Class Initialized
INFO - 2019-07-12 01:35:59 --> Model Class Initialized
INFO - 2019-07-12 01:35:59 --> Model Class Initialized
INFO - 2019-07-12 01:35:59 --> Model Class Initialized
INFO - 2019-07-12 01:35:59 --> Helper loaded: form_helper
INFO - 2019-07-12 01:35:59 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:35:59 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:35:59 --> Model Class Initialized
INFO - 2019-07-12 01:35:59 --> Model Class Initialized
INFO - 2019-07-12 01:35:59 --> Final output sent to browser
DEBUG - 2019-07-12 01:35:59 --> Total execution time: 0.7725
INFO - 2019-07-12 01:36:30 --> Helper loaded: language_helper
INFO - 2019-07-12 01:36:30 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:36:30 --> Model Class Initialized
INFO - 2019-07-12 01:36:30 --> Model Class Initialized
INFO - 2019-07-12 01:36:30 --> Model Class Initialized
INFO - 2019-07-12 01:36:30 --> Model Class Initialized
INFO - 2019-07-12 01:36:30 --> Model Class Initialized
INFO - 2019-07-12 01:36:30 --> Final output sent to browser
DEBUG - 2019-07-12 01:36:30 --> Total execution time: 0.8436
INFO - 2019-07-12 01:36:30 --> Helper loaded: language_helper
INFO - 2019-07-12 01:36:30 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:36:30 --> Model Class Initialized
INFO - 2019-07-12 01:36:30 --> Model Class Initialized
INFO - 2019-07-12 01:36:30 --> Model Class Initialized
INFO - 2019-07-12 01:36:30 --> Model Class Initialized
INFO - 2019-07-12 01:36:30 --> Helper loaded: form_helper
INFO - 2019-07-12 01:36:30 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:36:31 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:36:31 --> Model Class Initialized
INFO - 2019-07-12 01:36:31 --> Model Class Initialized
INFO - 2019-07-12 01:36:31 --> Final output sent to browser
DEBUG - 2019-07-12 01:36:31 --> Total execution time: 0.8086
INFO - 2019-07-12 01:36:32 --> Helper loaded: language_helper
INFO - 2019-07-12 01:36:32 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:36:32 --> Model Class Initialized
INFO - 2019-07-12 01:36:32 --> Model Class Initialized
INFO - 2019-07-12 01:36:32 --> Model Class Initialized
INFO - 2019-07-12 01:36:32 --> Model Class Initialized
INFO - 2019-07-12 01:36:32 --> Helper loaded: form_helper
INFO - 2019-07-12 01:36:32 --> Form Validation Class Initialized
INFO - 2019-07-12 01:36:32 --> Helper loaded: language_helper
DEBUG - 2019-07-12 01:36:33 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:36:33 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:36:33 --> Model Class Initialized
INFO - 2019-07-12 01:36:33 --> Model Class Initialized
INFO - 2019-07-12 01:36:33 --> Model Class Initialized
INFO - 2019-07-12 01:36:33 --> Model Class Initialized
INFO - 2019-07-12 01:36:33 --> Final output sent to browser
INFO - 2019-07-12 01:36:33 --> Model Class Initialized
DEBUG - 2019-07-12 01:36:33 --> Total execution time: 1.3147
INFO - 2019-07-12 01:36:33 --> Model Class Initialized
INFO - 2019-07-12 01:36:33 --> Helper loaded: form_helper
INFO - 2019-07-12 01:36:33 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:36:33 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:36:33 --> Model Class Initialized
INFO - 2019-07-12 01:36:33 --> Model Class Initialized
INFO - 2019-07-12 01:36:33 --> Final output sent to browser
DEBUG - 2019-07-12 01:36:33 --> Total execution time: 1.2995
INFO - 2019-07-12 01:36:40 --> Helper loaded: language_helper
INFO - 2019-07-12 01:36:40 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:36:40 --> Model Class Initialized
INFO - 2019-07-12 01:36:40 --> Model Class Initialized
INFO - 2019-07-12 01:36:40 --> Model Class Initialized
INFO - 2019-07-12 01:36:40 --> Model Class Initialized
INFO - 2019-07-12 01:36:40 --> Helper loaded: form_helper
INFO - 2019-07-12 01:36:40 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:36:40 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:36:40 --> Model Class Initialized
INFO - 2019-07-12 01:36:40 --> Model Class Initialized
INFO - 2019-07-12 01:36:40 --> Final output sent to browser
DEBUG - 2019-07-12 01:36:40 --> Total execution time: 0.7912
INFO - 2019-07-12 01:37:32 --> Helper loaded: language_helper
INFO - 2019-07-12 01:37:32 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:37:32 --> Model Class Initialized
INFO - 2019-07-12 01:37:32 --> Model Class Initialized
INFO - 2019-07-12 01:37:32 --> Model Class Initialized
INFO - 2019-07-12 01:37:32 --> Model Class Initialized
INFO - 2019-07-12 01:37:32 --> Model Class Initialized
INFO - 2019-07-12 01:37:32 --> Final output sent to browser
DEBUG - 2019-07-12 01:37:32 --> Total execution time: 0.8928
INFO - 2019-07-12 01:37:33 --> Helper loaded: language_helper
INFO - 2019-07-12 01:37:33 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:37:33 --> Model Class Initialized
INFO - 2019-07-12 01:37:33 --> Model Class Initialized
INFO - 2019-07-12 01:37:33 --> Model Class Initialized
INFO - 2019-07-12 01:37:33 --> Model Class Initialized
INFO - 2019-07-12 01:37:33 --> Helper loaded: form_helper
INFO - 2019-07-12 01:37:33 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:37:33 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:37:33 --> Model Class Initialized
INFO - 2019-07-12 01:37:33 --> Model Class Initialized
INFO - 2019-07-12 01:37:33 --> Final output sent to browser
DEBUG - 2019-07-12 01:37:33 --> Total execution time: 0.7979
INFO - 2019-07-12 01:37:35 --> Helper loaded: language_helper
INFO - 2019-07-12 01:37:35 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:37:35 --> Model Class Initialized
INFO - 2019-07-12 01:37:35 --> Model Class Initialized
INFO - 2019-07-12 01:37:35 --> Model Class Initialized
INFO - 2019-07-12 01:37:35 --> Model Class Initialized
INFO - 2019-07-12 01:37:35 --> Helper loaded: form_helper
INFO - 2019-07-12 01:37:35 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:37:35 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:37:35 --> Model Class Initialized
INFO - 2019-07-12 01:37:35 --> Model Class Initialized
INFO - 2019-07-12 01:37:35 --> Final output sent to browser
DEBUG - 2019-07-12 01:37:35 --> Total execution time: 0.7748
INFO - 2019-07-12 01:38:19 --> Helper loaded: language_helper
INFO - 2019-07-12 01:38:19 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:38:19 --> Model Class Initialized
INFO - 2019-07-12 01:38:19 --> Model Class Initialized
INFO - 2019-07-12 01:38:19 --> Model Class Initialized
INFO - 2019-07-12 01:38:19 --> Model Class Initialized
INFO - 2019-07-12 01:38:19 --> Helper loaded: form_helper
INFO - 2019-07-12 01:38:19 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:38:19 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:38:19 --> Model Class Initialized
INFO - 2019-07-12 01:38:19 --> Model Class Initialized
INFO - 2019-07-12 01:38:19 --> Final output sent to browser
DEBUG - 2019-07-12 01:38:19 --> Total execution time: 0.7795
INFO - 2019-07-12 01:38:57 --> Helper loaded: language_helper
INFO - 2019-07-12 01:38:57 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:38:57 --> Model Class Initialized
INFO - 2019-07-12 01:38:57 --> Model Class Initialized
INFO - 2019-07-12 01:38:57 --> Model Class Initialized
INFO - 2019-07-12 01:38:57 --> Model Class Initialized
INFO - 2019-07-12 01:38:57 --> Helper loaded: form_helper
INFO - 2019-07-12 01:38:57 --> Helper loaded: language_helper
INFO - 2019-07-12 01:38:57 --> Form Validation Class Initialized
INFO - 2019-07-12 01:38:57 --> Language file loaded: language/english/general_lang.php
DEBUG - 2019-07-12 01:38:57 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:38:57 --> Model Class Initialized
INFO - 2019-07-12 01:38:57 --> Model Class Initialized
INFO - 2019-07-12 01:38:57 --> Model Class Initialized
INFO - 2019-07-12 01:38:57 --> Model Class Initialized
INFO - 2019-07-12 01:38:57 --> Model Class Initialized
INFO - 2019-07-12 01:38:57 --> Final output sent to browser
INFO - 2019-07-12 01:38:57 --> Model Class Initialized
DEBUG - 2019-07-12 01:38:57 --> Total execution time: 1.3313
INFO - 2019-07-12 01:38:57 --> Model Class Initialized
INFO - 2019-07-12 01:38:57 --> Final output sent to browser
DEBUG - 2019-07-12 01:38:57 --> Total execution time: 1.1343
INFO - 2019-07-12 01:38:58 --> Helper loaded: language_helper
INFO - 2019-07-12 01:38:58 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:38:58 --> Model Class Initialized
INFO - 2019-07-12 01:38:58 --> Model Class Initialized
INFO - 2019-07-12 01:38:58 --> Model Class Initialized
INFO - 2019-07-12 01:38:58 --> Model Class Initialized
INFO - 2019-07-12 01:38:58 --> Helper loaded: form_helper
INFO - 2019-07-12 01:38:58 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:38:58 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:38:58 --> Model Class Initialized
INFO - 2019-07-12 01:38:58 --> Model Class Initialized
INFO - 2019-07-12 01:38:58 --> Final output sent to browser
DEBUG - 2019-07-12 01:38:58 --> Total execution time: 0.8856
INFO - 2019-07-12 01:39:44 --> Helper loaded: language_helper
INFO - 2019-07-12 01:39:44 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:39:44 --> Model Class Initialized
INFO - 2019-07-12 01:39:44 --> Model Class Initialized
INFO - 2019-07-12 01:39:44 --> Model Class Initialized
INFO - 2019-07-12 01:39:44 --> Model Class Initialized
INFO - 2019-07-12 01:39:45 --> Model Class Initialized
INFO - 2019-07-12 01:39:45 --> Final output sent to browser
DEBUG - 2019-07-12 01:39:45 --> Total execution time: 0.8266
INFO - 2019-07-12 01:39:45 --> Helper loaded: language_helper
INFO - 2019-07-12 01:39:45 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:39:45 --> Model Class Initialized
INFO - 2019-07-12 01:39:45 --> Model Class Initialized
INFO - 2019-07-12 01:39:45 --> Model Class Initialized
INFO - 2019-07-12 01:39:45 --> Model Class Initialized
INFO - 2019-07-12 01:39:45 --> Helper loaded: form_helper
INFO - 2019-07-12 01:39:46 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:39:46 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:39:46 --> Model Class Initialized
INFO - 2019-07-12 01:39:46 --> Model Class Initialized
INFO - 2019-07-12 01:39:46 --> Final output sent to browser
DEBUG - 2019-07-12 01:39:46 --> Total execution time: 0.9845
INFO - 2019-07-12 01:39:46 --> Helper loaded: language_helper
INFO - 2019-07-12 01:39:46 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:39:46 --> Model Class Initialized
INFO - 2019-07-12 01:39:46 --> Model Class Initialized
INFO - 2019-07-12 01:39:46 --> Model Class Initialized
INFO - 2019-07-12 01:39:46 --> Model Class Initialized
INFO - 2019-07-12 01:39:46 --> Helper loaded: form_helper
INFO - 2019-07-12 01:39:46 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:39:46 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:39:46 --> Model Class Initialized
INFO - 2019-07-12 01:39:46 --> Model Class Initialized
INFO - 2019-07-12 01:39:46 --> Final output sent to browser
DEBUG - 2019-07-12 01:39:46 --> Total execution time: 0.9245
INFO - 2019-07-12 01:39:50 --> Helper loaded: language_helper
INFO - 2019-07-12 01:39:50 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:39:50 --> Model Class Initialized
INFO - 2019-07-12 01:39:50 --> Model Class Initialized
INFO - 2019-07-12 01:39:50 --> Model Class Initialized
INFO - 2019-07-12 01:39:50 --> Model Class Initialized
INFO - 2019-07-12 01:39:51 --> Helper loaded: form_helper
INFO - 2019-07-12 01:39:51 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:39:51 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:39:51 --> Model Class Initialized
INFO - 2019-07-12 01:39:51 --> Model Class Initialized
INFO - 2019-07-12 01:39:51 --> Final output sent to browser
DEBUG - 2019-07-12 01:39:51 --> Total execution time: 0.8077
INFO - 2019-07-12 01:39:56 --> Helper loaded: language_helper
INFO - 2019-07-12 01:39:56 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:39:56 --> Model Class Initialized
INFO - 2019-07-12 01:39:56 --> Model Class Initialized
INFO - 2019-07-12 01:39:56 --> Model Class Initialized
INFO - 2019-07-12 01:39:56 --> Model Class Initialized
INFO - 2019-07-12 01:39:56 --> Helper loaded: form_helper
INFO - 2019-07-12 01:39:56 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:39:56 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:39:56 --> Model Class Initialized
INFO - 2019-07-12 01:39:56 --> Model Class Initialized
INFO - 2019-07-12 01:39:56 --> Final output sent to browser
DEBUG - 2019-07-12 01:39:56 --> Total execution time: 0.8104
INFO - 2019-07-12 01:40:02 --> Helper loaded: language_helper
INFO - 2019-07-12 01:40:02 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:40:02 --> Model Class Initialized
INFO - 2019-07-12 01:40:02 --> Model Class Initialized
INFO - 2019-07-12 01:40:02 --> Model Class Initialized
INFO - 2019-07-12 01:40:02 --> Model Class Initialized
INFO - 2019-07-12 01:40:02 --> Helper loaded: form_helper
INFO - 2019-07-12 01:40:02 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:40:03 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:40:03 --> Model Class Initialized
INFO - 2019-07-12 01:40:03 --> Model Class Initialized
INFO - 2019-07-12 01:40:03 --> Final output sent to browser
DEBUG - 2019-07-12 01:40:03 --> Total execution time: 0.8334
INFO - 2019-07-12 01:40:09 --> Helper loaded: language_helper
INFO - 2019-07-12 01:40:09 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:40:09 --> Model Class Initialized
INFO - 2019-07-12 01:40:09 --> Model Class Initialized
INFO - 2019-07-12 01:40:09 --> Model Class Initialized
INFO - 2019-07-12 01:40:09 --> Model Class Initialized
INFO - 2019-07-12 01:40:09 --> Helper loaded: form_helper
INFO - 2019-07-12 01:40:09 --> Form Validation Class Initialized
DEBUG - 2019-07-12 01:40:09 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-12 01:40:09 --> Model Class Initialized
INFO - 2019-07-12 01:40:09 --> Model Class Initialized
INFO - 2019-07-12 01:40:09 --> Final output sent to browser
DEBUG - 2019-07-12 01:40:09 --> Total execution time: 0.8332
INFO - 2019-07-12 01:42:04 --> Helper loaded: language_helper
INFO - 2019-07-12 01:42:04 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:42:04 --> Model Class Initialized
INFO - 2019-07-12 01:42:04 --> Model Class Initialized
INFO - 2019-07-12 01:42:04 --> Model Class Initialized
INFO - 2019-07-12 01:42:04 --> Model Class Initialized
INFO - 2019-07-12 01:42:04 --> Model Class Initialized
ERROR - 2019-07-12 01:42:04 --> Severity: Notice --> Undefined index: checkoutId C:\xampp\htdocs\crapi_admin\application\vendor\paymaya\paymaya-sdk\lib\PayMaya\API\Checkout.php 37
ERROR - 2019-07-12 01:42:04 --> Severity: Notice --> Undefined index: redirectUrl C:\xampp\htdocs\crapi_admin\application\vendor\paymaya\paymaya-sdk\lib\PayMaya\API\Checkout.php 38
ERROR - 2019-07-12 01:42:05 --> Severity: Notice --> Undefined index: status C:\xampp\htdocs\crapi_admin\application\vendor\paymaya\paymaya-sdk\lib\PayMaya\API\Checkout.php 48
ERROR - 2019-07-12 01:42:05 --> Severity: Notice --> Undefined index: transactionReferenceNumber C:\xampp\htdocs\crapi_admin\application\vendor\paymaya\paymaya-sdk\lib\PayMaya\API\Checkout.php 50
ERROR - 2019-07-12 01:42:05 --> Severity: Notice --> Undefined index: receiptNumber C:\xampp\htdocs\crapi_admin\application\vendor\paymaya\paymaya-sdk\lib\PayMaya\API\Checkout.php 51
ERROR - 2019-07-12 01:42:05 --> Severity: Notice --> Undefined index: paymentStatus C:\xampp\htdocs\crapi_admin\application\vendor\paymaya\paymaya-sdk\lib\PayMaya\API\Checkout.php 52
ERROR - 2019-07-12 01:42:05 --> Severity: Notice --> Undefined index: metadata C:\xampp\htdocs\crapi_admin\application\vendor\paymaya\paymaya-sdk\lib\PayMaya\API\Checkout.php 54
INFO - 2019-07-12 01:42:05 --> Final output sent to browser
DEBUG - 2019-07-12 01:42:05 --> Total execution time: 1.6355
INFO - 2019-07-12 01:45:44 --> Helper loaded: language_helper
INFO - 2019-07-12 01:45:44 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:45:44 --> Model Class Initialized
INFO - 2019-07-12 01:45:44 --> Model Class Initialized
INFO - 2019-07-12 01:45:44 --> Model Class Initialized
INFO - 2019-07-12 01:45:44 --> Model Class Initialized
INFO - 2019-07-12 01:45:44 --> Model Class Initialized
ERROR - 2019-07-12 01:45:44 --> Severity: Notice --> Undefined variable: order_details C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Payments.php 194
ERROR - 2019-07-12 01:45:44 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Payments.php 118
ERROR - 2019-07-12 01:45:44 --> Severity: Notice --> Undefined index: order_id C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Payments.php 204
ERROR - 2019-07-12 01:45:44 --> Severity: Notice --> Undefined index: order_id C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Payments.php 208
ERROR - 2019-07-12 01:45:44 --> Severity: Notice --> Undefined index: callback_url C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Payments.php 210
ERROR - 2019-07-12 01:45:44 --> Severity: Notice --> Undefined index: callback_url C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Payments.php 211
ERROR - 2019-07-12 01:45:44 --> Severity: Notice --> Undefined index: callback_url C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Payments.php 212
ERROR - 2019-07-12 01:45:45 --> Severity: Notice --> Undefined index: checkoutId C:\xampp\htdocs\crapi_admin\application\vendor\paymaya\paymaya-sdk\lib\PayMaya\API\Checkout.php 37
ERROR - 2019-07-12 01:45:45 --> Severity: Notice --> Undefined index: redirectUrl C:\xampp\htdocs\crapi_admin\application\vendor\paymaya\paymaya-sdk\lib\PayMaya\API\Checkout.php 38
ERROR - 2019-07-12 01:45:45 --> Severity: Notice --> Undefined index: status C:\xampp\htdocs\crapi_admin\application\vendor\paymaya\paymaya-sdk\lib\PayMaya\API\Checkout.php 48
ERROR - 2019-07-12 01:45:45 --> Severity: Notice --> Undefined index: transactionReferenceNumber C:\xampp\htdocs\crapi_admin\application\vendor\paymaya\paymaya-sdk\lib\PayMaya\API\Checkout.php 50
ERROR - 2019-07-12 01:45:45 --> Severity: Notice --> Undefined index: receiptNumber C:\xampp\htdocs\crapi_admin\application\vendor\paymaya\paymaya-sdk\lib\PayMaya\API\Checkout.php 51
ERROR - 2019-07-12 01:45:45 --> Severity: Notice --> Undefined index: paymentStatus C:\xampp\htdocs\crapi_admin\application\vendor\paymaya\paymaya-sdk\lib\PayMaya\API\Checkout.php 52
ERROR - 2019-07-12 01:45:45 --> Severity: Notice --> Undefined index: metadata C:\xampp\htdocs\crapi_admin\application\vendor\paymaya\paymaya-sdk\lib\PayMaya\API\Checkout.php 54
INFO - 2019-07-12 01:49:31 --> Helper loaded: language_helper
INFO - 2019-07-12 01:49:31 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:49:31 --> Model Class Initialized
INFO - 2019-07-12 01:49:31 --> Model Class Initialized
INFO - 2019-07-12 01:49:31 --> Model Class Initialized
INFO - 2019-07-12 01:49:31 --> Model Class Initialized
INFO - 2019-07-12 01:49:31 --> Model Class Initialized
ERROR - 2019-07-12 01:49:31 --> Severity: Notice --> Undefined variable: order_details C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Payments.php 203
ERROR - 2019-07-12 01:49:31 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Payments.php 118
ERROR - 2019-07-12 01:49:31 --> Severity: Notice --> Undefined index: order_id C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Payments.php 213
ERROR - 2019-07-12 01:49:31 --> Severity: Notice --> Undefined index: order_id C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Payments.php 217
ERROR - 2019-07-12 01:49:32 --> Severity: Notice --> Undefined index: callback_url C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Payments.php 219
ERROR - 2019-07-12 01:49:32 --> Severity: Notice --> Undefined index: callback_url C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Payments.php 220
ERROR - 2019-07-12 01:49:32 --> Severity: Notice --> Undefined index: callback_url C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Payments.php 221
ERROR - 2019-07-12 01:49:32 --> Severity: Notice --> Undefined index: checkoutId C:\xampp\htdocs\crapi_admin\application\vendor\paymaya\paymaya-sdk\lib\PayMaya\API\Checkout.php 37
ERROR - 2019-07-12 01:49:32 --> Severity: Notice --> Undefined index: redirectUrl C:\xampp\htdocs\crapi_admin\application\vendor\paymaya\paymaya-sdk\lib\PayMaya\API\Checkout.php 38
ERROR - 2019-07-12 01:49:32 --> Severity: Notice --> Undefined index: status C:\xampp\htdocs\crapi_admin\application\vendor\paymaya\paymaya-sdk\lib\PayMaya\API\Checkout.php 48
ERROR - 2019-07-12 01:49:32 --> Severity: Notice --> Undefined index: transactionReferenceNumber C:\xampp\htdocs\crapi_admin\application\vendor\paymaya\paymaya-sdk\lib\PayMaya\API\Checkout.php 50
ERROR - 2019-07-12 01:49:32 --> Severity: Notice --> Undefined index: receiptNumber C:\xampp\htdocs\crapi_admin\application\vendor\paymaya\paymaya-sdk\lib\PayMaya\API\Checkout.php 51
ERROR - 2019-07-12 01:49:32 --> Severity: Notice --> Undefined index: paymentStatus C:\xampp\htdocs\crapi_admin\application\vendor\paymaya\paymaya-sdk\lib\PayMaya\API\Checkout.php 52
ERROR - 2019-07-12 01:49:32 --> Severity: Notice --> Undefined index: metadata C:\xampp\htdocs\crapi_admin\application\vendor\paymaya\paymaya-sdk\lib\PayMaya\API\Checkout.php 54
INFO - 2019-07-12 01:49:42 --> Helper loaded: language_helper
INFO - 2019-07-12 01:49:42 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:49:42 --> Model Class Initialized
INFO - 2019-07-12 01:49:43 --> Model Class Initialized
INFO - 2019-07-12 01:49:43 --> Model Class Initialized
INFO - 2019-07-12 01:49:43 --> Model Class Initialized
INFO - 2019-07-12 01:49:43 --> Model Class Initialized
ERROR - 2019-07-12 01:49:43 --> Severity: Notice --> Undefined index: order_id C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Payments.php 213
ERROR - 2019-07-12 01:49:43 --> Severity: Notice --> Undefined index: order_id C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Payments.php 217
ERROR - 2019-07-12 01:49:43 --> Severity: Notice --> Undefined index: callback_url C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Payments.php 219
ERROR - 2019-07-12 01:49:43 --> Severity: Notice --> Undefined index: callback_url C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Payments.php 220
ERROR - 2019-07-12 01:49:43 --> Severity: Notice --> Undefined index: callback_url C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Payments.php 221
ERROR - 2019-07-12 01:49:43 --> Severity: Notice --> Undefined index: checkoutId C:\xampp\htdocs\crapi_admin\application\vendor\paymaya\paymaya-sdk\lib\PayMaya\API\Checkout.php 37
ERROR - 2019-07-12 01:49:43 --> Severity: Notice --> Undefined index: redirectUrl C:\xampp\htdocs\crapi_admin\application\vendor\paymaya\paymaya-sdk\lib\PayMaya\API\Checkout.php 38
ERROR - 2019-07-12 01:49:43 --> Severity: Notice --> Undefined index: status C:\xampp\htdocs\crapi_admin\application\vendor\paymaya\paymaya-sdk\lib\PayMaya\API\Checkout.php 48
ERROR - 2019-07-12 01:49:43 --> Severity: Notice --> Undefined index: transactionReferenceNumber C:\xampp\htdocs\crapi_admin\application\vendor\paymaya\paymaya-sdk\lib\PayMaya\API\Checkout.php 50
ERROR - 2019-07-12 01:49:43 --> Severity: Notice --> Undefined index: receiptNumber C:\xampp\htdocs\crapi_admin\application\vendor\paymaya\paymaya-sdk\lib\PayMaya\API\Checkout.php 51
ERROR - 2019-07-12 01:49:43 --> Severity: Notice --> Undefined index: paymentStatus C:\xampp\htdocs\crapi_admin\application\vendor\paymaya\paymaya-sdk\lib\PayMaya\API\Checkout.php 52
ERROR - 2019-07-12 01:49:43 --> Severity: Notice --> Undefined index: metadata C:\xampp\htdocs\crapi_admin\application\vendor\paymaya\paymaya-sdk\lib\PayMaya\API\Checkout.php 54
INFO - 2019-07-12 01:50:46 --> Helper loaded: language_helper
INFO - 2019-07-12 01:50:46 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:50:46 --> Model Class Initialized
INFO - 2019-07-12 01:50:46 --> Model Class Initialized
INFO - 2019-07-12 01:50:46 --> Model Class Initialized
INFO - 2019-07-12 01:50:47 --> Model Class Initialized
INFO - 2019-07-12 01:50:47 --> Model Class Initialized
ERROR - 2019-07-12 01:50:47 --> Severity: Notice --> Undefined index: callback_url C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Payments.php 218
ERROR - 2019-07-12 01:50:47 --> Severity: Notice --> Undefined index: callback_url C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Payments.php 219
ERROR - 2019-07-12 01:50:47 --> Severity: Notice --> Undefined index: callback_url C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Payments.php 220
ERROR - 2019-07-12 01:50:47 --> Severity: Notice --> Undefined index: checkoutId C:\xampp\htdocs\crapi_admin\application\vendor\paymaya\paymaya-sdk\lib\PayMaya\API\Checkout.php 37
ERROR - 2019-07-12 01:50:47 --> Severity: Notice --> Undefined index: redirectUrl C:\xampp\htdocs\crapi_admin\application\vendor\paymaya\paymaya-sdk\lib\PayMaya\API\Checkout.php 38
ERROR - 2019-07-12 01:50:47 --> Severity: Notice --> Undefined index: status C:\xampp\htdocs\crapi_admin\application\vendor\paymaya\paymaya-sdk\lib\PayMaya\API\Checkout.php 48
ERROR - 2019-07-12 01:50:47 --> Severity: Notice --> Undefined index: transactionReferenceNumber C:\xampp\htdocs\crapi_admin\application\vendor\paymaya\paymaya-sdk\lib\PayMaya\API\Checkout.php 50
ERROR - 2019-07-12 01:50:47 --> Severity: Notice --> Undefined index: receiptNumber C:\xampp\htdocs\crapi_admin\application\vendor\paymaya\paymaya-sdk\lib\PayMaya\API\Checkout.php 51
ERROR - 2019-07-12 01:50:47 --> Severity: Notice --> Undefined index: paymentStatus C:\xampp\htdocs\crapi_admin\application\vendor\paymaya\paymaya-sdk\lib\PayMaya\API\Checkout.php 52
ERROR - 2019-07-12 01:50:47 --> Severity: Notice --> Undefined index: metadata C:\xampp\htdocs\crapi_admin\application\vendor\paymaya\paymaya-sdk\lib\PayMaya\API\Checkout.php 54
INFO - 2019-07-12 01:51:30 --> Helper loaded: language_helper
INFO - 2019-07-12 01:51:30 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:51:30 --> Model Class Initialized
INFO - 2019-07-12 01:51:30 --> Model Class Initialized
INFO - 2019-07-12 01:51:30 --> Model Class Initialized
INFO - 2019-07-12 01:51:30 --> Model Class Initialized
INFO - 2019-07-12 01:51:30 --> Model Class Initialized
ERROR - 2019-07-12 01:51:31 --> Severity: Notice --> Undefined index: checkoutId C:\xampp\htdocs\crapi_admin\application\vendor\paymaya\paymaya-sdk\lib\PayMaya\API\Checkout.php 37
ERROR - 2019-07-12 01:51:31 --> Severity: Notice --> Undefined index: redirectUrl C:\xampp\htdocs\crapi_admin\application\vendor\paymaya\paymaya-sdk\lib\PayMaya\API\Checkout.php 38
ERROR - 2019-07-12 01:51:31 --> Severity: Notice --> Undefined index: status C:\xampp\htdocs\crapi_admin\application\vendor\paymaya\paymaya-sdk\lib\PayMaya\API\Checkout.php 48
ERROR - 2019-07-12 01:51:31 --> Severity: Notice --> Undefined index: transactionReferenceNumber C:\xampp\htdocs\crapi_admin\application\vendor\paymaya\paymaya-sdk\lib\PayMaya\API\Checkout.php 50
ERROR - 2019-07-12 01:51:31 --> Severity: Notice --> Undefined index: receiptNumber C:\xampp\htdocs\crapi_admin\application\vendor\paymaya\paymaya-sdk\lib\PayMaya\API\Checkout.php 51
ERROR - 2019-07-12 01:51:31 --> Severity: Notice --> Undefined index: paymentStatus C:\xampp\htdocs\crapi_admin\application\vendor\paymaya\paymaya-sdk\lib\PayMaya\API\Checkout.php 52
ERROR - 2019-07-12 01:51:31 --> Severity: Notice --> Undefined index: metadata C:\xampp\htdocs\crapi_admin\application\vendor\paymaya\paymaya-sdk\lib\PayMaya\API\Checkout.php 54
INFO - 2019-07-12 01:54:12 --> Helper loaded: language_helper
INFO - 2019-07-12 01:54:12 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:54:12 --> Model Class Initialized
INFO - 2019-07-12 01:54:12 --> Model Class Initialized
INFO - 2019-07-12 01:54:12 --> Model Class Initialized
INFO - 2019-07-12 01:54:12 --> Model Class Initialized
INFO - 2019-07-12 01:54:12 --> Model Class Initialized
ERROR - 2019-07-12 01:54:12 --> Severity: Notice --> Undefined index: checkoutId C:\xampp\htdocs\crapi_admin\application\vendor\paymaya\paymaya-sdk\lib\PayMaya\API\Checkout.php 37
ERROR - 2019-07-12 01:54:12 --> Severity: Notice --> Undefined index: redirectUrl C:\xampp\htdocs\crapi_admin\application\vendor\paymaya\paymaya-sdk\lib\PayMaya\API\Checkout.php 38
ERROR - 2019-07-12 01:54:13 --> Severity: Notice --> Undefined index: status C:\xampp\htdocs\crapi_admin\application\vendor\paymaya\paymaya-sdk\lib\PayMaya\API\Checkout.php 48
ERROR - 2019-07-12 01:54:13 --> Severity: Notice --> Undefined index: transactionReferenceNumber C:\xampp\htdocs\crapi_admin\application\vendor\paymaya\paymaya-sdk\lib\PayMaya\API\Checkout.php 50
ERROR - 2019-07-12 01:54:13 --> Severity: Notice --> Undefined index: receiptNumber C:\xampp\htdocs\crapi_admin\application\vendor\paymaya\paymaya-sdk\lib\PayMaya\API\Checkout.php 51
ERROR - 2019-07-12 01:54:13 --> Severity: Notice --> Undefined index: paymentStatus C:\xampp\htdocs\crapi_admin\application\vendor\paymaya\paymaya-sdk\lib\PayMaya\API\Checkout.php 52
ERROR - 2019-07-12 01:54:13 --> Severity: Notice --> Undefined index: metadata C:\xampp\htdocs\crapi_admin\application\vendor\paymaya\paymaya-sdk\lib\PayMaya\API\Checkout.php 54
INFO - 2019-07-12 01:55:04 --> Helper loaded: language_helper
INFO - 2019-07-12 01:55:04 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:55:04 --> Model Class Initialized
INFO - 2019-07-12 01:55:04 --> Model Class Initialized
INFO - 2019-07-12 01:55:04 --> Model Class Initialized
INFO - 2019-07-12 01:55:04 --> Model Class Initialized
INFO - 2019-07-12 01:55:04 --> Model Class Initialized
INFO - 2019-07-12 01:55:19 --> Helper loaded: language_helper
INFO - 2019-07-12 01:55:19 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:55:19 --> Model Class Initialized
INFO - 2019-07-12 01:55:19 --> Model Class Initialized
INFO - 2019-07-12 01:55:19 --> Model Class Initialized
INFO - 2019-07-12 01:55:19 --> Model Class Initialized
INFO - 2019-07-12 01:55:19 --> Model Class Initialized
INFO - 2019-07-12 01:55:33 --> Helper loaded: language_helper
INFO - 2019-07-12 01:55:33 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:55:33 --> Model Class Initialized
INFO - 2019-07-12 01:55:33 --> Model Class Initialized
INFO - 2019-07-12 01:55:33 --> Model Class Initialized
INFO - 2019-07-12 01:55:33 --> Model Class Initialized
INFO - 2019-07-12 01:55:33 --> Model Class Initialized
INFO - 2019-07-12 01:57:20 --> Helper loaded: language_helper
INFO - 2019-07-12 01:57:20 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:57:20 --> Model Class Initialized
INFO - 2019-07-12 01:57:20 --> Model Class Initialized
INFO - 2019-07-12 01:57:20 --> Model Class Initialized
INFO - 2019-07-12 01:57:20 --> Model Class Initialized
INFO - 2019-07-12 01:57:20 --> Model Class Initialized
INFO - 2019-07-12 01:58:05 --> Helper loaded: language_helper
INFO - 2019-07-12 01:58:05 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:58:05 --> Model Class Initialized
INFO - 2019-07-12 01:58:05 --> Model Class Initialized
INFO - 2019-07-12 01:58:05 --> Model Class Initialized
INFO - 2019-07-12 01:58:05 --> Model Class Initialized
INFO - 2019-07-12 01:58:05 --> Model Class Initialized
INFO - 2019-07-12 01:59:14 --> Helper loaded: language_helper
INFO - 2019-07-12 01:59:14 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:59:14 --> Model Class Initialized
INFO - 2019-07-12 01:59:14 --> Model Class Initialized
INFO - 2019-07-12 01:59:14 --> Model Class Initialized
INFO - 2019-07-12 01:59:14 --> Model Class Initialized
INFO - 2019-07-12 01:59:14 --> Model Class Initialized
ERROR - 2019-07-12 01:59:14 --> Severity: Notice --> Undefined index: checkoutId C:\xampp\htdocs\crapi_admin\application\vendor\paymaya\paymaya-sdk\lib\PayMaya\API\Checkout.php 37
ERROR - 2019-07-12 01:59:14 --> Severity: Notice --> Undefined index: redirectUrl C:\xampp\htdocs\crapi_admin\application\vendor\paymaya\paymaya-sdk\lib\PayMaya\API\Checkout.php 38
ERROR - 2019-07-12 01:59:14 --> Severity: Notice --> Undefined index: status C:\xampp\htdocs\crapi_admin\application\vendor\paymaya\paymaya-sdk\lib\PayMaya\API\Checkout.php 48
ERROR - 2019-07-12 01:59:15 --> Severity: Notice --> Undefined index: transactionReferenceNumber C:\xampp\htdocs\crapi_admin\application\vendor\paymaya\paymaya-sdk\lib\PayMaya\API\Checkout.php 50
ERROR - 2019-07-12 01:59:15 --> Severity: Notice --> Undefined index: receiptNumber C:\xampp\htdocs\crapi_admin\application\vendor\paymaya\paymaya-sdk\lib\PayMaya\API\Checkout.php 51
ERROR - 2019-07-12 01:59:15 --> Severity: Notice --> Undefined index: paymentStatus C:\xampp\htdocs\crapi_admin\application\vendor\paymaya\paymaya-sdk\lib\PayMaya\API\Checkout.php 52
ERROR - 2019-07-12 01:59:15 --> Severity: Notice --> Undefined index: metadata C:\xampp\htdocs\crapi_admin\application\vendor\paymaya\paymaya-sdk\lib\PayMaya\API\Checkout.php 54
INFO - 2019-07-12 01:59:31 --> Helper loaded: language_helper
INFO - 2019-07-12 01:59:31 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:59:31 --> Model Class Initialized
INFO - 2019-07-12 01:59:31 --> Model Class Initialized
INFO - 2019-07-12 01:59:31 --> Model Class Initialized
INFO - 2019-07-12 01:59:31 --> Model Class Initialized
INFO - 2019-07-12 01:59:31 --> Model Class Initialized
ERROR - 2019-07-12 01:59:31 --> Severity: Notice --> Undefined index: checkoutId C:\xampp\htdocs\crapi_admin\application\vendor\paymaya\paymaya-sdk\lib\PayMaya\API\Checkout.php 37
ERROR - 2019-07-12 01:59:31 --> Severity: Notice --> Undefined index: redirectUrl C:\xampp\htdocs\crapi_admin\application\vendor\paymaya\paymaya-sdk\lib\PayMaya\API\Checkout.php 38
INFO - 2019-07-12 01:59:41 --> Helper loaded: language_helper
INFO - 2019-07-12 01:59:41 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:59:41 --> Model Class Initialized
INFO - 2019-07-12 01:59:41 --> Model Class Initialized
INFO - 2019-07-12 01:59:41 --> Model Class Initialized
INFO - 2019-07-12 01:59:41 --> Model Class Initialized
INFO - 2019-07-12 01:59:41 --> Model Class Initialized
INFO - 2019-07-12 02:00:01 --> Helper loaded: language_helper
INFO - 2019-07-12 02:00:01 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 02:00:01 --> Model Class Initialized
INFO - 2019-07-12 02:00:01 --> Model Class Initialized
INFO - 2019-07-12 02:00:01 --> Model Class Initialized
INFO - 2019-07-12 02:00:01 --> Model Class Initialized
INFO - 2019-07-12 02:00:01 --> Model Class Initialized
ERROR - 2019-07-12 02:00:02 --> Severity: Notice --> Undefined index: checkoutId C:\xampp\htdocs\crapi_admin\application\vendor\paymaya\paymaya-sdk\lib\PayMaya\API\Checkout.php 37
ERROR - 2019-07-12 02:00:02 --> Severity: Notice --> Undefined index: redirectUrl C:\xampp\htdocs\crapi_admin\application\vendor\paymaya\paymaya-sdk\lib\PayMaya\API\Checkout.php 38
ERROR - 2019-07-12 02:00:02 --> Severity: Notice --> Undefined index: status C:\xampp\htdocs\crapi_admin\application\vendor\paymaya\paymaya-sdk\lib\PayMaya\API\Checkout.php 48
ERROR - 2019-07-12 02:00:02 --> Severity: Notice --> Undefined index: transactionReferenceNumber C:\xampp\htdocs\crapi_admin\application\vendor\paymaya\paymaya-sdk\lib\PayMaya\API\Checkout.php 50
ERROR - 2019-07-12 02:00:02 --> Severity: Notice --> Undefined index: receiptNumber C:\xampp\htdocs\crapi_admin\application\vendor\paymaya\paymaya-sdk\lib\PayMaya\API\Checkout.php 51
ERROR - 2019-07-12 02:00:02 --> Severity: Notice --> Undefined index: paymentStatus C:\xampp\htdocs\crapi_admin\application\vendor\paymaya\paymaya-sdk\lib\PayMaya\API\Checkout.php 52
ERROR - 2019-07-12 02:00:02 --> Severity: Notice --> Undefined index: metadata C:\xampp\htdocs\crapi_admin\application\vendor\paymaya\paymaya-sdk\lib\PayMaya\API\Checkout.php 54
INFO - 2019-07-12 02:01:01 --> Helper loaded: language_helper
INFO - 2019-07-12 02:01:01 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 02:01:01 --> Model Class Initialized
INFO - 2019-07-12 02:01:01 --> Model Class Initialized
INFO - 2019-07-12 02:01:01 --> Model Class Initialized
INFO - 2019-07-12 02:01:01 --> Model Class Initialized
INFO - 2019-07-12 02:01:01 --> Model Class Initialized
ERROR - 2019-07-12 02:01:01 --> Severity: Notice --> Undefined index: checkoutId C:\xampp\htdocs\crapi_admin\application\vendor\paymaya\paymaya-sdk\lib\PayMaya\API\Checkout.php 37
ERROR - 2019-07-12 02:01:01 --> Severity: Notice --> Undefined index: redirectUrl C:\xampp\htdocs\crapi_admin\application\vendor\paymaya\paymaya-sdk\lib\PayMaya\API\Checkout.php 38
ERROR - 2019-07-12 02:01:02 --> Severity: Notice --> Undefined index: status C:\xampp\htdocs\crapi_admin\application\vendor\paymaya\paymaya-sdk\lib\PayMaya\API\Checkout.php 48
ERROR - 2019-07-12 02:01:02 --> Severity: Notice --> Undefined index: transactionReferenceNumber C:\xampp\htdocs\crapi_admin\application\vendor\paymaya\paymaya-sdk\lib\PayMaya\API\Checkout.php 50
ERROR - 2019-07-12 02:01:02 --> Severity: Notice --> Undefined index: receiptNumber C:\xampp\htdocs\crapi_admin\application\vendor\paymaya\paymaya-sdk\lib\PayMaya\API\Checkout.php 51
ERROR - 2019-07-12 02:01:02 --> Severity: Notice --> Undefined index: paymentStatus C:\xampp\htdocs\crapi_admin\application\vendor\paymaya\paymaya-sdk\lib\PayMaya\API\Checkout.php 52
ERROR - 2019-07-12 02:01:02 --> Severity: Notice --> Undefined index: metadata C:\xampp\htdocs\crapi_admin\application\vendor\paymaya\paymaya-sdk\lib\PayMaya\API\Checkout.php 54
INFO - 2019-07-12 02:02:31 --> Helper loaded: language_helper
INFO - 2019-07-12 02:02:31 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 02:02:31 --> Model Class Initialized
INFO - 2019-07-12 02:02:31 --> Model Class Initialized
INFO - 2019-07-12 02:02:31 --> Model Class Initialized
INFO - 2019-07-12 02:02:31 --> Model Class Initialized
INFO - 2019-07-12 02:02:31 --> Model Class Initialized
INFO - 2019-07-12 02:02:45 --> Helper loaded: language_helper
INFO - 2019-07-12 02:02:45 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 02:02:45 --> Model Class Initialized
INFO - 2019-07-12 02:02:46 --> Model Class Initialized
INFO - 2019-07-12 02:02:46 --> Model Class Initialized
INFO - 2019-07-12 02:02:46 --> Model Class Initialized
INFO - 2019-07-12 02:02:46 --> Model Class Initialized
INFO - 2019-07-12 02:03:00 --> Helper loaded: language_helper
INFO - 2019-07-12 02:03:00 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 02:03:00 --> Model Class Initialized
INFO - 2019-07-12 02:03:00 --> Model Class Initialized
INFO - 2019-07-12 02:03:00 --> Model Class Initialized
INFO - 2019-07-12 02:03:00 --> Model Class Initialized
INFO - 2019-07-12 02:03:00 --> Model Class Initialized
INFO - 2019-07-12 02:04:55 --> Helper loaded: language_helper
INFO - 2019-07-12 02:04:55 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 02:04:55 --> Model Class Initialized
INFO - 2019-07-12 02:04:55 --> Model Class Initialized
INFO - 2019-07-12 02:04:55 --> Model Class Initialized
INFO - 2019-07-12 02:04:55 --> Model Class Initialized
INFO - 2019-07-12 02:04:55 --> Model Class Initialized
INFO - 2019-07-12 02:06:56 --> Helper loaded: language_helper
INFO - 2019-07-12 02:06:56 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 02:06:56 --> Model Class Initialized
INFO - 2019-07-12 02:06:56 --> Model Class Initialized
INFO - 2019-07-12 02:06:56 --> Model Class Initialized
INFO - 2019-07-12 02:06:56 --> Model Class Initialized
INFO - 2019-07-12 02:06:56 --> Model Class Initialized
INFO - 2019-07-12 02:09:45 --> Helper loaded: language_helper
INFO - 2019-07-12 02:09:45 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 02:09:45 --> Model Class Initialized
INFO - 2019-07-12 02:09:45 --> Model Class Initialized
INFO - 2019-07-12 02:09:45 --> Model Class Initialized
INFO - 2019-07-12 02:09:45 --> Model Class Initialized
INFO - 2019-07-12 02:09:45 --> Model Class Initialized
INFO - 2019-07-12 02:10:09 --> Helper loaded: language_helper
INFO - 2019-07-12 02:10:09 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 02:10:09 --> Model Class Initialized
INFO - 2019-07-12 02:10:09 --> Model Class Initialized
INFO - 2019-07-12 02:10:09 --> Model Class Initialized
INFO - 2019-07-12 02:10:09 --> Model Class Initialized
INFO - 2019-07-12 02:10:09 --> Model Class Initialized
INFO - 2019-07-12 02:30:27 --> Helper loaded: language_helper
INFO - 2019-07-12 02:30:27 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 02:30:27 --> Model Class Initialized
INFO - 2019-07-12 02:30:27 --> Model Class Initialized
INFO - 2019-07-12 02:30:27 --> Model Class Initialized
INFO - 2019-07-12 02:30:27 --> Model Class Initialized
INFO - 2019-07-12 02:30:27 --> Model Class Initialized
INFO - 2019-07-12 02:30:29 --> Final output sent to browser
DEBUG - 2019-07-12 02:30:29 --> Total execution time: 2.4353
INFO - 2019-07-12 02:37:30 --> Helper loaded: language_helper
INFO - 2019-07-12 02:37:30 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 02:37:30 --> Model Class Initialized
INFO - 2019-07-12 02:37:30 --> Model Class Initialized
INFO - 2019-07-12 02:37:30 --> Model Class Initialized
INFO - 2019-07-12 02:37:30 --> Model Class Initialized
INFO - 2019-07-12 02:37:30 --> Final output sent to browser
DEBUG - 2019-07-12 02:37:30 --> Total execution time: 1.2415
INFO - 2019-07-12 02:37:30 --> Helper loaded: language_helper
INFO - 2019-07-12 02:37:30 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 02:37:30 --> Model Class Initialized
INFO - 2019-07-12 02:37:30 --> Model Class Initialized
INFO - 2019-07-12 02:37:30 --> Model Class Initialized
INFO - 2019-07-12 02:37:30 --> Model Class Initialized
INFO - 2019-07-12 02:37:30 --> Model Class Initialized
INFO - 2019-07-12 02:37:30 --> Final output sent to browser
DEBUG - 2019-07-12 02:37:30 --> Total execution time: 1.5745
INFO - 2019-07-12 02:37:33 --> Helper loaded: language_helper
INFO - 2019-07-12 02:37:33 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 02:37:33 --> Model Class Initialized
INFO - 2019-07-12 02:37:33 --> Model Class Initialized
INFO - 2019-07-12 02:37:33 --> Model Class Initialized
INFO - 2019-07-12 02:37:33 --> Model Class Initialized
INFO - 2019-07-12 02:37:33 --> Model Class Initialized
INFO - 2019-07-12 02:37:33 --> Final output sent to browser
DEBUG - 2019-07-12 02:37:33 --> Total execution time: 1.1112
INFO - 2019-07-12 02:37:33 --> Helper loaded: language_helper
INFO - 2019-07-12 02:37:33 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 02:37:33 --> Model Class Initialized
INFO - 2019-07-12 02:37:33 --> Model Class Initialized
INFO - 2019-07-12 02:37:33 --> Model Class Initialized
INFO - 2019-07-12 02:37:33 --> Model Class Initialized
INFO - 2019-07-12 02:37:33 --> Final output sent to browser
DEBUG - 2019-07-12 02:37:33 --> Total execution time: 1.3402
INFO - 2019-07-12 02:37:39 --> Helper loaded: language_helper
INFO - 2019-07-12 02:37:39 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 02:37:39 --> Model Class Initialized
INFO - 2019-07-12 02:37:39 --> Model Class Initialized
INFO - 2019-07-12 02:37:39 --> Model Class Initialized
INFO - 2019-07-12 02:37:39 --> Model Class Initialized
INFO - 2019-07-12 02:37:39 --> Model Class Initialized
INFO - 2019-07-12 02:37:39 --> Final output sent to browser
DEBUG - 2019-07-12 02:37:39 --> Total execution time: 0.7532
INFO - 2019-07-12 02:40:48 --> Helper loaded: language_helper
INFO - 2019-07-12 02:40:48 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 02:40:48 --> Model Class Initialized
INFO - 2019-07-12 02:40:48 --> Model Class Initialized
INFO - 2019-07-12 02:40:48 --> Model Class Initialized
INFO - 2019-07-12 02:40:48 --> Model Class Initialized
INFO - 2019-07-12 02:40:48 --> Model Class Initialized
ERROR - 2019-07-12 02:40:48 --> Severity: error --> Exception: Error API call C:\xampp\htdocs\crapi_admin\application\vendor\paymaya\paymaya-sdk\lib\PayMaya\Core\HTTPConnection.php 50
INFO - 2019-07-12 02:41:50 --> Helper loaded: language_helper
INFO - 2019-07-12 02:41:50 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 02:41:50 --> Model Class Initialized
INFO - 2019-07-12 02:41:50 --> Model Class Initialized
INFO - 2019-07-12 02:41:50 --> Model Class Initialized
INFO - 2019-07-12 02:41:50 --> Model Class Initialized
INFO - 2019-07-12 02:41:50 --> Model Class Initialized
INFO - 2019-07-12 02:41:52 --> Final output sent to browser
DEBUG - 2019-07-12 02:41:52 --> Total execution time: 2.4024
INFO - 2019-07-12 02:43:13 --> Helper loaded: language_helper
INFO - 2019-07-12 02:43:13 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 02:43:13 --> Model Class Initialized
INFO - 2019-07-12 02:43:13 --> Model Class Initialized
INFO - 2019-07-12 02:43:13 --> Model Class Initialized
INFO - 2019-07-12 02:43:13 --> Model Class Initialized
INFO - 2019-07-12 02:43:13 --> Model Class Initialized
INFO - 2019-07-12 02:43:14 --> Final output sent to browser
DEBUG - 2019-07-12 02:43:14 --> Total execution time: 2.1193
INFO - 2019-07-12 02:48:38 --> Helper loaded: language_helper
INFO - 2019-07-12 02:48:38 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 02:48:38 --> Model Class Initialized
INFO - 2019-07-12 02:48:38 --> Model Class Initialized
INFO - 2019-07-12 02:48:38 --> Model Class Initialized
INFO - 2019-07-12 02:48:38 --> Model Class Initialized
INFO - 2019-07-12 02:48:38 --> Model Class Initialized
INFO - 2019-07-12 02:48:40 --> Final output sent to browser
DEBUG - 2019-07-12 02:48:40 --> Total execution time: 2.3989
INFO - 2019-07-12 02:49:02 --> Helper loaded: language_helper
INFO - 2019-07-12 02:49:02 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 02:49:02 --> Model Class Initialized
INFO - 2019-07-12 02:49:02 --> Model Class Initialized
INFO - 2019-07-12 02:49:03 --> Model Class Initialized
INFO - 2019-07-12 02:49:03 --> Model Class Initialized
INFO - 2019-07-12 02:49:03 --> Model Class Initialized
INFO - 2019-07-12 02:49:04 --> Final output sent to browser
DEBUG - 2019-07-12 02:49:04 --> Total execution time: 1.9490
INFO - 2019-07-12 02:51:49 --> Helper loaded: language_helper
INFO - 2019-07-12 02:51:49 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 02:51:49 --> Model Class Initialized
INFO - 2019-07-12 02:51:49 --> Model Class Initialized
INFO - 2019-07-12 02:51:49 --> Model Class Initialized
INFO - 2019-07-12 02:51:49 --> Model Class Initialized
INFO - 2019-07-12 02:51:49 --> Model Class Initialized
ERROR - 2019-07-12 02:51:49 --> Severity: Notice --> Undefined index: owner_id C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Payments.php 203
ERROR - 2019-07-12 02:51:49 --> Severity: Notice --> Undefined index: callback_url C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Payments.php 208
ERROR - 2019-07-12 02:51:49 --> Severity: Notice --> Undefined index: callback_url C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Payments.php 209
ERROR - 2019-07-12 02:51:49 --> Severity: Notice --> Undefined index: callback_url C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Payments.php 210
ERROR - 2019-07-12 02:51:50 --> Severity: Notice --> Undefined index: checkoutId C:\xampp\htdocs\crapi_admin\application\vendor\paymaya\paymaya-sdk\lib\PayMaya\API\Checkout.php 37
ERROR - 2019-07-12 02:51:50 --> Severity: Notice --> Undefined index: redirectUrl C:\xampp\htdocs\crapi_admin\application\vendor\paymaya\paymaya-sdk\lib\PayMaya\API\Checkout.php 38
ERROR - 2019-07-12 02:51:51 --> Severity: Notice --> Undefined index: status C:\xampp\htdocs\crapi_admin\application\vendor\paymaya\paymaya-sdk\lib\PayMaya\API\Checkout.php 48
ERROR - 2019-07-12 02:51:51 --> Severity: Notice --> Undefined index: transactionReferenceNumber C:\xampp\htdocs\crapi_admin\application\vendor\paymaya\paymaya-sdk\lib\PayMaya\API\Checkout.php 50
ERROR - 2019-07-12 02:51:51 --> Severity: Notice --> Undefined index: receiptNumber C:\xampp\htdocs\crapi_admin\application\vendor\paymaya\paymaya-sdk\lib\PayMaya\API\Checkout.php 51
ERROR - 2019-07-12 02:51:51 --> Severity: Notice --> Undefined index: paymentStatus C:\xampp\htdocs\crapi_admin\application\vendor\paymaya\paymaya-sdk\lib\PayMaya\API\Checkout.php 52
ERROR - 2019-07-12 02:51:51 --> Severity: Notice --> Undefined index: metadata C:\xampp\htdocs\crapi_admin\application\vendor\paymaya\paymaya-sdk\lib\PayMaya\API\Checkout.php 54
ERROR - 2019-07-12 02:51:51 --> Severity: Warning --> Cannot modify header information - headers already sent by (output started at C:\xampp\htdocs\crapi_admin\system\core\Exceptions.php:272) C:\xampp\htdocs\crapi_admin\system\core\Common.php 573
INFO - 2019-07-12 02:51:51 --> Final output sent to browser
DEBUG - 2019-07-12 02:51:51 --> Total execution time: 2.8366
INFO - 2019-07-12 02:51:56 --> Helper loaded: language_helper
INFO - 2019-07-12 02:51:56 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 02:51:56 --> Model Class Initialized
INFO - 2019-07-12 02:51:56 --> Model Class Initialized
INFO - 2019-07-12 02:51:57 --> Model Class Initialized
INFO - 2019-07-12 02:51:57 --> Model Class Initialized
INFO - 2019-07-12 02:51:57 --> Final output sent to browser
DEBUG - 2019-07-12 02:51:57 --> Total execution time: 0.7573
INFO - 2019-07-12 02:52:02 --> Helper loaded: language_helper
INFO - 2019-07-12 02:52:02 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 02:52:02 --> Model Class Initialized
INFO - 2019-07-12 02:52:02 --> Model Class Initialized
INFO - 2019-07-12 02:52:02 --> Model Class Initialized
INFO - 2019-07-12 02:52:02 --> Model Class Initialized
INFO - 2019-07-12 02:52:02 --> Final output sent to browser
DEBUG - 2019-07-12 02:52:02 --> Total execution time: 0.7564
INFO - 2019-07-12 02:52:19 --> Helper loaded: language_helper
INFO - 2019-07-12 02:52:19 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 02:52:19 --> Model Class Initialized
INFO - 2019-07-12 02:52:19 --> Model Class Initialized
INFO - 2019-07-12 02:52:19 --> Model Class Initialized
INFO - 2019-07-12 02:52:19 --> Model Class Initialized
INFO - 2019-07-12 02:52:19 --> Final output sent to browser
DEBUG - 2019-07-12 02:52:19 --> Total execution time: 0.7521
INFO - 2019-07-12 02:52:48 --> Helper loaded: language_helper
INFO - 2019-07-12 02:52:48 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 02:52:49 --> Model Class Initialized
INFO - 2019-07-12 02:52:49 --> Model Class Initialized
INFO - 2019-07-12 02:52:49 --> Model Class Initialized
INFO - 2019-07-12 02:52:49 --> Model Class Initialized
INFO - 2019-07-12 02:52:49 --> Final output sent to browser
DEBUG - 2019-07-12 02:52:49 --> Total execution time: 0.7470
INFO - 2019-07-12 02:58:45 --> Helper loaded: language_helper
INFO - 2019-07-12 02:58:45 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 02:58:45 --> Model Class Initialized
INFO - 2019-07-12 02:58:45 --> Model Class Initialized
INFO - 2019-07-12 02:58:45 --> Model Class Initialized
INFO - 2019-07-12 02:58:45 --> Model Class Initialized
INFO - 2019-07-12 02:58:45 --> Final output sent to browser
DEBUG - 2019-07-12 02:58:45 --> Total execution time: 0.9193
INFO - 2019-07-12 02:58:53 --> Helper loaded: language_helper
INFO - 2019-07-12 02:58:53 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 02:58:53 --> Model Class Initialized
INFO - 2019-07-12 02:58:53 --> Model Class Initialized
INFO - 2019-07-12 02:58:53 --> Model Class Initialized
INFO - 2019-07-12 02:58:53 --> Model Class Initialized
INFO - 2019-07-12 02:58:53 --> Final output sent to browser
DEBUG - 2019-07-12 02:58:53 --> Total execution time: 0.7778
INFO - 2019-07-12 02:59:04 --> Helper loaded: language_helper
INFO - 2019-07-12 02:59:04 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 02:59:04 --> Model Class Initialized
INFO - 2019-07-12 02:59:04 --> Model Class Initialized
INFO - 2019-07-12 02:59:04 --> Model Class Initialized
INFO - 2019-07-12 02:59:04 --> Model Class Initialized
INFO - 2019-07-12 02:59:04 --> Model Class Initialized
INFO - 2019-07-12 02:59:06 --> Final output sent to browser
DEBUG - 2019-07-12 02:59:06 --> Total execution time: 2.3721
INFO - 2019-07-12 02:59:27 --> Helper loaded: language_helper
INFO - 2019-07-12 02:59:27 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 02:59:27 --> Model Class Initialized
INFO - 2019-07-12 02:59:27 --> Model Class Initialized
INFO - 2019-07-12 02:59:27 --> Model Class Initialized
INFO - 2019-07-12 02:59:27 --> Model Class Initialized
INFO - 2019-07-12 02:59:27 --> Final output sent to browser
DEBUG - 2019-07-12 02:59:27 --> Total execution time: 0.7582
INFO - 2019-07-12 02:59:30 --> Helper loaded: language_helper
INFO - 2019-07-12 02:59:30 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 02:59:30 --> Model Class Initialized
INFO - 2019-07-12 02:59:30 --> Model Class Initialized
INFO - 2019-07-12 02:59:30 --> Model Class Initialized
INFO - 2019-07-12 02:59:30 --> Model Class Initialized
INFO - 2019-07-12 02:59:30 --> Final output sent to browser
DEBUG - 2019-07-12 02:59:30 --> Total execution time: 0.7873
INFO - 2019-07-12 00:09:07 --> Config Class Initialized
INFO - 2019-07-12 00:09:07 --> Hooks Class Initialized
DEBUG - 2019-07-12 00:09:07 --> UTF-8 Support Enabled
INFO - 2019-07-12 00:09:07 --> Utf8 Class Initialized
INFO - 2019-07-12 00:09:07 --> URI Class Initialized
INFO - 2019-07-12 00:09:07 --> Router Class Initialized
INFO - 2019-07-12 00:09:07 --> Output Class Initialized
INFO - 2019-07-12 00:09:07 --> Security Class Initialized
DEBUG - 2019-07-12 00:09:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 00:09:07 --> Input Class Initialized
INFO - 2019-07-12 00:09:07 --> Language Class Initialized
INFO - 2019-07-12 00:09:07 --> Language Class Initialized
INFO - 2019-07-12 00:09:07 --> Config Class Initialized
INFO - 2019-07-12 00:09:07 --> Loader Class Initialized
DEBUG - 2019-07-12 00:09:07 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 00:09:07 --> Helper loaded: url_helper
INFO - 2019-07-12 00:09:07 --> Helper loaded: inflector_helper
INFO - 2019-07-12 00:09:07 --> Helper loaded: string_helper
INFO - 2019-07-12 00:09:07 --> Helper loaded: array_helper
INFO - 2019-07-12 00:09:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 00:09:07 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 00:09:07 --> Database Driver Class Initialized
INFO - 2019-07-12 00:09:07 --> Controller Class Initialized
INFO - 2019-07-12 06:09:07 --> Helper loaded: language_helper
INFO - 2019-07-12 06:09:07 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 06:09:07 --> Model Class Initialized
INFO - 2019-07-12 06:09:07 --> Model Class Initialized
INFO - 2019-07-12 06:09:07 --> Model Class Initialized
INFO - 2019-07-12 06:09:07 --> Model Class Initialized
INFO - 2019-07-12 06:09:07 --> Final output sent to browser
DEBUG - 2019-07-12 06:09:07 --> Total execution time: 0.9804
INFO - 2019-07-12 00:09:23 --> Config Class Initialized
INFO - 2019-07-12 00:09:23 --> Hooks Class Initialized
DEBUG - 2019-07-12 00:09:23 --> UTF-8 Support Enabled
INFO - 2019-07-12 00:09:23 --> Utf8 Class Initialized
INFO - 2019-07-12 00:09:23 --> URI Class Initialized
INFO - 2019-07-12 00:09:23 --> Router Class Initialized
INFO - 2019-07-12 00:09:23 --> Output Class Initialized
INFO - 2019-07-12 00:09:23 --> Security Class Initialized
DEBUG - 2019-07-12 00:09:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 00:09:23 --> Input Class Initialized
INFO - 2019-07-12 00:09:23 --> Language Class Initialized
INFO - 2019-07-12 00:09:23 --> Language Class Initialized
INFO - 2019-07-12 00:09:23 --> Config Class Initialized
INFO - 2019-07-12 00:09:23 --> Loader Class Initialized
DEBUG - 2019-07-12 00:09:23 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 00:09:23 --> Helper loaded: url_helper
INFO - 2019-07-12 00:09:23 --> Helper loaded: inflector_helper
INFO - 2019-07-12 00:09:23 --> Helper loaded: string_helper
INFO - 2019-07-12 00:09:23 --> Helper loaded: array_helper
INFO - 2019-07-12 00:09:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 00:09:23 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 00:09:23 --> Database Driver Class Initialized
INFO - 2019-07-12 00:09:23 --> Controller Class Initialized
INFO - 2019-07-12 06:09:23 --> Helper loaded: language_helper
INFO - 2019-07-12 06:09:23 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 06:09:23 --> Model Class Initialized
INFO - 2019-07-12 06:09:23 --> Model Class Initialized
INFO - 2019-07-12 06:09:23 --> Model Class Initialized
INFO - 2019-07-12 06:09:23 --> Model Class Initialized
INFO - 2019-07-12 06:09:23 --> Final output sent to browser
DEBUG - 2019-07-12 06:09:23 --> Total execution time: 0.5368
INFO - 2019-07-12 00:10:12 --> Config Class Initialized
INFO - 2019-07-12 00:10:12 --> Hooks Class Initialized
DEBUG - 2019-07-12 00:10:12 --> UTF-8 Support Enabled
INFO - 2019-07-12 00:10:12 --> Utf8 Class Initialized
INFO - 2019-07-12 00:10:12 --> URI Class Initialized
INFO - 2019-07-12 00:10:12 --> Router Class Initialized
INFO - 2019-07-12 00:10:12 --> Output Class Initialized
INFO - 2019-07-12 00:10:12 --> Security Class Initialized
DEBUG - 2019-07-12 00:10:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 00:10:12 --> Input Class Initialized
INFO - 2019-07-12 00:10:12 --> Language Class Initialized
INFO - 2019-07-12 00:10:12 --> Language Class Initialized
INFO - 2019-07-12 00:10:12 --> Config Class Initialized
INFO - 2019-07-12 00:10:12 --> Loader Class Initialized
DEBUG - 2019-07-12 00:10:12 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 00:10:12 --> Helper loaded: url_helper
INFO - 2019-07-12 00:10:13 --> Helper loaded: inflector_helper
INFO - 2019-07-12 00:10:13 --> Helper loaded: string_helper
INFO - 2019-07-12 00:10:13 --> Helper loaded: array_helper
INFO - 2019-07-12 00:10:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 00:10:13 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 00:10:13 --> Database Driver Class Initialized
INFO - 2019-07-12 00:10:13 --> Controller Class Initialized
INFO - 2019-07-12 06:10:13 --> Helper loaded: language_helper
INFO - 2019-07-12 06:10:13 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 06:10:13 --> Model Class Initialized
INFO - 2019-07-12 06:10:13 --> Model Class Initialized
INFO - 2019-07-12 06:10:13 --> Model Class Initialized
INFO - 2019-07-12 06:10:13 --> Model Class Initialized
INFO - 2019-07-12 06:10:13 --> Model Class Initialized
INFO - 2019-07-12 06:10:14 --> Final output sent to browser
DEBUG - 2019-07-12 06:10:14 --> Total execution time: 2.2844
INFO - 2019-07-12 00:10:18 --> Config Class Initialized
INFO - 2019-07-12 00:10:18 --> Hooks Class Initialized
DEBUG - 2019-07-12 00:10:18 --> UTF-8 Support Enabled
INFO - 2019-07-12 00:10:18 --> Utf8 Class Initialized
INFO - 2019-07-12 00:10:18 --> URI Class Initialized
INFO - 2019-07-12 00:10:18 --> Router Class Initialized
INFO - 2019-07-12 00:10:18 --> Output Class Initialized
INFO - 2019-07-12 00:10:18 --> Security Class Initialized
DEBUG - 2019-07-12 00:10:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 00:10:18 --> Input Class Initialized
INFO - 2019-07-12 00:10:18 --> Language Class Initialized
INFO - 2019-07-12 00:10:18 --> Language Class Initialized
INFO - 2019-07-12 00:10:19 --> Config Class Initialized
INFO - 2019-07-12 00:10:19 --> Loader Class Initialized
DEBUG - 2019-07-12 00:10:19 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 00:10:19 --> Helper loaded: url_helper
INFO - 2019-07-12 00:10:19 --> Helper loaded: inflector_helper
INFO - 2019-07-12 00:10:19 --> Helper loaded: string_helper
INFO - 2019-07-12 00:10:19 --> Helper loaded: array_helper
INFO - 2019-07-12 00:10:19 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 00:10:19 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 00:10:19 --> Database Driver Class Initialized
INFO - 2019-07-12 00:10:19 --> Controller Class Initialized
INFO - 2019-07-12 06:10:19 --> Helper loaded: language_helper
INFO - 2019-07-12 06:10:19 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 06:10:19 --> Model Class Initialized
INFO - 2019-07-12 06:10:19 --> Model Class Initialized
INFO - 2019-07-12 06:10:19 --> Model Class Initialized
INFO - 2019-07-12 06:10:19 --> Model Class Initialized
INFO - 2019-07-12 06:10:19 --> Final output sent to browser
DEBUG - 2019-07-12 06:10:19 --> Total execution time: 0.7114
INFO - 2019-07-12 00:15:28 --> Config Class Initialized
INFO - 2019-07-12 00:15:28 --> Hooks Class Initialized
DEBUG - 2019-07-12 00:15:28 --> UTF-8 Support Enabled
INFO - 2019-07-12 00:15:28 --> Utf8 Class Initialized
INFO - 2019-07-12 00:15:28 --> URI Class Initialized
INFO - 2019-07-12 00:15:28 --> Router Class Initialized
INFO - 2019-07-12 00:15:29 --> Output Class Initialized
INFO - 2019-07-12 00:15:29 --> Security Class Initialized
DEBUG - 2019-07-12 00:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 00:15:29 --> Input Class Initialized
INFO - 2019-07-12 00:15:29 --> Language Class Initialized
INFO - 2019-07-12 00:15:29 --> Language Class Initialized
INFO - 2019-07-12 00:15:29 --> Config Class Initialized
INFO - 2019-07-12 00:15:29 --> Loader Class Initialized
DEBUG - 2019-07-12 00:15:29 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 00:15:29 --> Helper loaded: url_helper
INFO - 2019-07-12 00:15:29 --> Helper loaded: inflector_helper
INFO - 2019-07-12 00:15:29 --> Helper loaded: string_helper
INFO - 2019-07-12 00:15:29 --> Helper loaded: array_helper
INFO - 2019-07-12 00:15:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 00:15:29 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 00:15:29 --> Database Driver Class Initialized
INFO - 2019-07-12 00:15:29 --> Controller Class Initialized
INFO - 2019-07-12 06:15:29 --> Helper loaded: language_helper
INFO - 2019-07-12 06:15:29 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 06:15:29 --> Model Class Initialized
INFO - 2019-07-12 06:15:29 --> Model Class Initialized
INFO - 2019-07-12 06:15:29 --> Model Class Initialized
INFO - 2019-07-12 06:15:29 --> Model Class Initialized
INFO - 2019-07-12 06:15:29 --> Model Class Initialized
INFO - 2019-07-12 06:15:31 --> Final output sent to browser
DEBUG - 2019-07-12 06:15:31 --> Total execution time: 2.1425
INFO - 2019-07-12 00:15:33 --> Config Class Initialized
INFO - 2019-07-12 00:15:34 --> Hooks Class Initialized
DEBUG - 2019-07-12 00:15:34 --> UTF-8 Support Enabled
INFO - 2019-07-12 00:15:34 --> Utf8 Class Initialized
INFO - 2019-07-12 00:15:34 --> URI Class Initialized
INFO - 2019-07-12 00:15:34 --> Router Class Initialized
INFO - 2019-07-12 00:15:34 --> Output Class Initialized
INFO - 2019-07-12 00:15:34 --> Security Class Initialized
DEBUG - 2019-07-12 00:15:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 00:15:34 --> Input Class Initialized
INFO - 2019-07-12 00:15:34 --> Language Class Initialized
INFO - 2019-07-12 00:15:34 --> Language Class Initialized
INFO - 2019-07-12 00:15:34 --> Config Class Initialized
INFO - 2019-07-12 00:15:34 --> Loader Class Initialized
DEBUG - 2019-07-12 00:15:34 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 00:15:34 --> Helper loaded: url_helper
INFO - 2019-07-12 00:15:34 --> Helper loaded: inflector_helper
INFO - 2019-07-12 00:15:34 --> Helper loaded: string_helper
INFO - 2019-07-12 00:15:34 --> Helper loaded: array_helper
INFO - 2019-07-12 00:15:34 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 00:15:34 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 00:15:34 --> Database Driver Class Initialized
INFO - 2019-07-12 00:15:34 --> Controller Class Initialized
INFO - 2019-07-12 06:15:34 --> Helper loaded: language_helper
INFO - 2019-07-12 06:15:34 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 06:15:34 --> Model Class Initialized
INFO - 2019-07-12 06:15:34 --> Model Class Initialized
INFO - 2019-07-12 06:15:34 --> Model Class Initialized
INFO - 2019-07-12 06:15:34 --> Model Class Initialized
INFO - 2019-07-12 06:15:34 --> Final output sent to browser
DEBUG - 2019-07-12 06:15:34 --> Total execution time: 0.5862
INFO - 2019-07-12 00:29:07 --> Config Class Initialized
INFO - 2019-07-12 00:29:07 --> Hooks Class Initialized
DEBUG - 2019-07-12 00:29:07 --> UTF-8 Support Enabled
INFO - 2019-07-12 00:29:07 --> Utf8 Class Initialized
INFO - 2019-07-12 00:29:07 --> URI Class Initialized
INFO - 2019-07-12 00:29:07 --> Router Class Initialized
INFO - 2019-07-12 00:29:07 --> Output Class Initialized
INFO - 2019-07-12 00:29:07 --> Security Class Initialized
DEBUG - 2019-07-12 00:29:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 00:29:07 --> Input Class Initialized
INFO - 2019-07-12 00:29:07 --> Language Class Initialized
INFO - 2019-07-12 00:29:07 --> Language Class Initialized
INFO - 2019-07-12 00:29:07 --> Config Class Initialized
INFO - 2019-07-12 00:29:08 --> Loader Class Initialized
DEBUG - 2019-07-12 00:29:08 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 00:29:08 --> Helper loaded: url_helper
INFO - 2019-07-12 00:29:08 --> Helper loaded: inflector_helper
INFO - 2019-07-12 00:29:08 --> Helper loaded: string_helper
INFO - 2019-07-12 00:29:08 --> Helper loaded: array_helper
INFO - 2019-07-12 00:29:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 00:29:08 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 00:29:08 --> Database Driver Class Initialized
INFO - 2019-07-12 00:29:08 --> Controller Class Initialized
INFO - 2019-07-12 06:29:08 --> Helper loaded: language_helper
INFO - 2019-07-12 06:29:08 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 06:29:08 --> Model Class Initialized
INFO - 2019-07-12 06:29:08 --> Model Class Initialized
INFO - 2019-07-12 06:29:08 --> Model Class Initialized
INFO - 2019-07-12 06:29:08 --> Model Class Initialized
INFO - 2019-07-12 06:29:08 --> Final output sent to browser
DEBUG - 2019-07-12 06:29:08 --> Total execution time: 0.5355
INFO - 2019-07-12 00:29:10 --> Config Class Initialized
INFO - 2019-07-12 00:29:10 --> Hooks Class Initialized
DEBUG - 2019-07-12 00:29:10 --> UTF-8 Support Enabled
INFO - 2019-07-12 00:29:10 --> Utf8 Class Initialized
INFO - 2019-07-12 00:29:10 --> URI Class Initialized
INFO - 2019-07-12 00:29:10 --> Router Class Initialized
INFO - 2019-07-12 00:29:10 --> Output Class Initialized
INFO - 2019-07-12 00:29:10 --> Security Class Initialized
DEBUG - 2019-07-12 00:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 00:29:10 --> Input Class Initialized
INFO - 2019-07-12 00:29:10 --> Language Class Initialized
INFO - 2019-07-12 00:29:10 --> Language Class Initialized
INFO - 2019-07-12 00:29:10 --> Config Class Initialized
INFO - 2019-07-12 00:29:10 --> Loader Class Initialized
DEBUG - 2019-07-12 00:29:10 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 00:29:10 --> Helper loaded: url_helper
INFO - 2019-07-12 00:29:10 --> Helper loaded: inflector_helper
INFO - 2019-07-12 00:29:10 --> Helper loaded: string_helper
INFO - 2019-07-12 00:29:10 --> Helper loaded: array_helper
INFO - 2019-07-12 00:29:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 00:29:10 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 00:29:10 --> Database Driver Class Initialized
INFO - 2019-07-12 00:29:10 --> Controller Class Initialized
INFO - 2019-07-12 06:29:10 --> Helper loaded: language_helper
INFO - 2019-07-12 06:29:10 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 06:29:11 --> Model Class Initialized
INFO - 2019-07-12 06:29:11 --> Model Class Initialized
INFO - 2019-07-12 06:29:11 --> Model Class Initialized
INFO - 2019-07-12 06:29:11 --> Model Class Initialized
INFO - 2019-07-12 06:29:11 --> Final output sent to browser
DEBUG - 2019-07-12 06:29:11 --> Total execution time: 0.5027
INFO - 2019-07-12 00:29:45 --> Config Class Initialized
INFO - 2019-07-12 00:29:45 --> Hooks Class Initialized
DEBUG - 2019-07-12 00:29:45 --> UTF-8 Support Enabled
INFO - 2019-07-12 00:29:45 --> Utf8 Class Initialized
INFO - 2019-07-12 00:29:45 --> URI Class Initialized
INFO - 2019-07-12 00:29:45 --> Router Class Initialized
INFO - 2019-07-12 00:29:45 --> Output Class Initialized
INFO - 2019-07-12 00:29:45 --> Security Class Initialized
DEBUG - 2019-07-12 00:29:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 00:29:45 --> Input Class Initialized
INFO - 2019-07-12 00:29:45 --> Language Class Initialized
INFO - 2019-07-12 00:29:45 --> Language Class Initialized
INFO - 2019-07-12 00:29:45 --> Config Class Initialized
INFO - 2019-07-12 00:29:45 --> Loader Class Initialized
DEBUG - 2019-07-12 00:29:45 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 00:29:45 --> Helper loaded: url_helper
INFO - 2019-07-12 00:29:45 --> Helper loaded: inflector_helper
INFO - 2019-07-12 00:29:45 --> Helper loaded: string_helper
INFO - 2019-07-12 00:29:45 --> Helper loaded: array_helper
INFO - 2019-07-12 00:29:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 00:29:45 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 00:29:45 --> Database Driver Class Initialized
INFO - 2019-07-12 00:29:45 --> Controller Class Initialized
INFO - 2019-07-12 06:29:45 --> Helper loaded: language_helper
INFO - 2019-07-12 06:29:45 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 06:29:45 --> Model Class Initialized
INFO - 2019-07-12 06:29:46 --> Model Class Initialized
INFO - 2019-07-12 06:29:46 --> Model Class Initialized
INFO - 2019-07-12 06:29:46 --> Model Class Initialized
ERROR - 2019-07-12 06:29:46 --> Severity: Notice --> Undefined variable: hashed C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Owners.php 76
ERROR - 2019-07-12 06:29:46 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Owners.php 83
INFO - 2019-07-12 06:29:46 --> Final output sent to browser
DEBUG - 2019-07-12 06:29:46 --> Total execution time: 0.5431
INFO - 2019-07-12 00:30:02 --> Config Class Initialized
INFO - 2019-07-12 00:30:02 --> Hooks Class Initialized
DEBUG - 2019-07-12 00:30:02 --> UTF-8 Support Enabled
INFO - 2019-07-12 00:30:02 --> Utf8 Class Initialized
INFO - 2019-07-12 00:30:02 --> URI Class Initialized
INFO - 2019-07-12 00:30:02 --> Router Class Initialized
INFO - 2019-07-12 00:30:02 --> Output Class Initialized
INFO - 2019-07-12 00:30:02 --> Security Class Initialized
DEBUG - 2019-07-12 00:30:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 00:30:02 --> Input Class Initialized
INFO - 2019-07-12 00:30:02 --> Language Class Initialized
INFO - 2019-07-12 00:30:02 --> Language Class Initialized
INFO - 2019-07-12 00:30:02 --> Config Class Initialized
INFO - 2019-07-12 00:30:02 --> Loader Class Initialized
DEBUG - 2019-07-12 00:30:02 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 00:30:02 --> Helper loaded: url_helper
INFO - 2019-07-12 00:30:02 --> Helper loaded: inflector_helper
INFO - 2019-07-12 00:30:02 --> Helper loaded: string_helper
INFO - 2019-07-12 00:30:02 --> Helper loaded: array_helper
INFO - 2019-07-12 00:30:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 00:30:02 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 00:30:02 --> Database Driver Class Initialized
INFO - 2019-07-12 00:30:02 --> Controller Class Initialized
INFO - 2019-07-12 06:30:02 --> Helper loaded: language_helper
INFO - 2019-07-12 06:30:02 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 06:30:02 --> Model Class Initialized
INFO - 2019-07-12 06:30:02 --> Model Class Initialized
INFO - 2019-07-12 06:30:02 --> Model Class Initialized
INFO - 2019-07-12 06:30:02 --> Model Class Initialized
INFO - 2019-07-12 00:37:18 --> Config Class Initialized
INFO - 2019-07-12 00:37:18 --> Hooks Class Initialized
DEBUG - 2019-07-12 00:37:18 --> UTF-8 Support Enabled
INFO - 2019-07-12 00:37:18 --> Utf8 Class Initialized
INFO - 2019-07-12 00:37:18 --> URI Class Initialized
INFO - 2019-07-12 00:37:18 --> Router Class Initialized
INFO - 2019-07-12 00:37:18 --> Output Class Initialized
INFO - 2019-07-12 00:37:18 --> Security Class Initialized
DEBUG - 2019-07-12 00:37:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 00:37:18 --> Input Class Initialized
INFO - 2019-07-12 00:37:18 --> Language Class Initialized
INFO - 2019-07-12 00:37:18 --> Language Class Initialized
INFO - 2019-07-12 00:37:18 --> Config Class Initialized
INFO - 2019-07-12 00:37:18 --> Loader Class Initialized
DEBUG - 2019-07-12 00:37:18 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 00:37:19 --> Helper loaded: url_helper
INFO - 2019-07-12 00:37:19 --> Helper loaded: inflector_helper
INFO - 2019-07-12 00:37:19 --> Helper loaded: string_helper
INFO - 2019-07-12 00:37:19 --> Helper loaded: array_helper
INFO - 2019-07-12 00:37:19 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 00:37:19 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 00:37:19 --> Database Driver Class Initialized
INFO - 2019-07-12 00:37:19 --> Controller Class Initialized
INFO - 2019-07-12 06:37:19 --> Helper loaded: language_helper
INFO - 2019-07-12 06:37:19 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 06:37:19 --> Model Class Initialized
INFO - 2019-07-12 06:37:19 --> Model Class Initialized
INFO - 2019-07-12 06:37:19 --> Model Class Initialized
INFO - 2019-07-12 06:37:19 --> Model Class Initialized
ERROR - 2019-07-12 06:37:19 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Owners.php 89
INFO - 2019-07-12 06:37:19 --> Final output sent to browser
DEBUG - 2019-07-12 06:37:19 --> Total execution time: 0.5248
INFO - 2019-07-12 00:37:49 --> Config Class Initialized
INFO - 2019-07-12 00:37:49 --> Hooks Class Initialized
DEBUG - 2019-07-12 00:37:49 --> UTF-8 Support Enabled
INFO - 2019-07-12 00:37:49 --> Utf8 Class Initialized
INFO - 2019-07-12 00:37:49 --> URI Class Initialized
INFO - 2019-07-12 00:37:49 --> Router Class Initialized
INFO - 2019-07-12 00:37:49 --> Output Class Initialized
INFO - 2019-07-12 00:37:49 --> Security Class Initialized
DEBUG - 2019-07-12 00:37:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 00:37:49 --> Input Class Initialized
INFO - 2019-07-12 00:37:49 --> Language Class Initialized
INFO - 2019-07-12 00:37:49 --> Language Class Initialized
INFO - 2019-07-12 00:37:49 --> Config Class Initialized
INFO - 2019-07-12 00:37:49 --> Loader Class Initialized
DEBUG - 2019-07-12 00:37:49 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 00:37:49 --> Helper loaded: url_helper
INFO - 2019-07-12 00:37:49 --> Helper loaded: inflector_helper
INFO - 2019-07-12 00:37:49 --> Helper loaded: string_helper
INFO - 2019-07-12 00:37:49 --> Helper loaded: array_helper
INFO - 2019-07-12 00:37:49 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 00:37:49 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 00:37:49 --> Database Driver Class Initialized
INFO - 2019-07-12 00:37:49 --> Controller Class Initialized
INFO - 2019-07-12 06:37:49 --> Helper loaded: language_helper
INFO - 2019-07-12 06:37:49 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 06:37:49 --> Model Class Initialized
INFO - 2019-07-12 06:37:49 --> Model Class Initialized
INFO - 2019-07-12 06:37:49 --> Model Class Initialized
INFO - 2019-07-12 06:37:49 --> Model Class Initialized
INFO - 2019-07-12 00:38:46 --> Config Class Initialized
INFO - 2019-07-12 00:38:46 --> Hooks Class Initialized
DEBUG - 2019-07-12 00:38:46 --> UTF-8 Support Enabled
INFO - 2019-07-12 00:38:46 --> Utf8 Class Initialized
INFO - 2019-07-12 00:38:46 --> URI Class Initialized
INFO - 2019-07-12 00:38:46 --> Router Class Initialized
INFO - 2019-07-12 00:38:46 --> Output Class Initialized
INFO - 2019-07-12 00:38:46 --> Security Class Initialized
DEBUG - 2019-07-12 00:38:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 00:38:46 --> Input Class Initialized
INFO - 2019-07-12 00:38:46 --> Language Class Initialized
INFO - 2019-07-12 00:38:46 --> Language Class Initialized
INFO - 2019-07-12 00:38:46 --> Config Class Initialized
INFO - 2019-07-12 00:38:46 --> Loader Class Initialized
DEBUG - 2019-07-12 00:38:46 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 00:38:46 --> Helper loaded: url_helper
INFO - 2019-07-12 00:38:46 --> Helper loaded: inflector_helper
INFO - 2019-07-12 00:38:46 --> Helper loaded: string_helper
INFO - 2019-07-12 00:38:46 --> Helper loaded: array_helper
INFO - 2019-07-12 00:38:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 00:38:46 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 00:38:46 --> Database Driver Class Initialized
INFO - 2019-07-12 00:38:46 --> Controller Class Initialized
INFO - 2019-07-12 06:38:46 --> Helper loaded: language_helper
INFO - 2019-07-12 06:38:46 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 06:38:46 --> Model Class Initialized
INFO - 2019-07-12 06:38:46 --> Model Class Initialized
INFO - 2019-07-12 06:38:46 --> Model Class Initialized
INFO - 2019-07-12 06:38:46 --> Model Class Initialized
ERROR - 2019-07-12 06:38:46 --> Severity: Notice --> Undefined index: id C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Owners.php 91
ERROR - 2019-07-12 06:38:46 --> Query error: Unknown column 'subscription_end' in 'field list' - Invalid query: UPDATE `employees` SET `status` = 1, `subscription_end` = '2019-08-12 06:38:46', `updated_at` = '2019-07-12 06:38:46'
WHERE `id` IS NULL
INFO - 2019-07-12 06:38:46 --> Language file loaded: language/english/db_lang.php
INFO - 2019-07-12 00:39:17 --> Config Class Initialized
INFO - 2019-07-12 00:39:17 --> Hooks Class Initialized
DEBUG - 2019-07-12 00:39:17 --> UTF-8 Support Enabled
INFO - 2019-07-12 00:39:17 --> Utf8 Class Initialized
INFO - 2019-07-12 00:39:18 --> URI Class Initialized
INFO - 2019-07-12 00:39:18 --> Router Class Initialized
INFO - 2019-07-12 00:39:18 --> Output Class Initialized
INFO - 2019-07-12 00:39:18 --> Security Class Initialized
DEBUG - 2019-07-12 00:39:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 00:39:18 --> Input Class Initialized
INFO - 2019-07-12 00:39:18 --> Language Class Initialized
INFO - 2019-07-12 00:39:18 --> Language Class Initialized
INFO - 2019-07-12 00:39:18 --> Config Class Initialized
INFO - 2019-07-12 00:39:18 --> Loader Class Initialized
DEBUG - 2019-07-12 00:39:18 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 00:39:18 --> Helper loaded: url_helper
INFO - 2019-07-12 00:39:18 --> Helper loaded: inflector_helper
INFO - 2019-07-12 00:39:18 --> Helper loaded: string_helper
INFO - 2019-07-12 00:39:18 --> Helper loaded: array_helper
INFO - 2019-07-12 00:39:18 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 00:39:18 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 00:39:18 --> Database Driver Class Initialized
INFO - 2019-07-12 00:39:18 --> Controller Class Initialized
INFO - 2019-07-12 06:39:18 --> Helper loaded: language_helper
INFO - 2019-07-12 06:39:18 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 06:39:18 --> Model Class Initialized
INFO - 2019-07-12 06:39:18 --> Model Class Initialized
INFO - 2019-07-12 06:39:18 --> Model Class Initialized
INFO - 2019-07-12 06:39:18 --> Model Class Initialized
ERROR - 2019-07-12 06:39:18 --> Query error: Unknown column 'subscription_end' in 'field list' - Invalid query: UPDATE `employees` SET `status` = 1, `subscription_end` = '2019-08-12 06:39:18', `updated_at` = '2019-07-12 06:39:18'
WHERE `id` = '1'
INFO - 2019-07-12 06:39:18 --> Language file loaded: language/english/db_lang.php
INFO - 2019-07-12 00:40:33 --> Config Class Initialized
INFO - 2019-07-12 00:40:33 --> Hooks Class Initialized
DEBUG - 2019-07-12 00:40:33 --> UTF-8 Support Enabled
INFO - 2019-07-12 00:40:33 --> Utf8 Class Initialized
INFO - 2019-07-12 00:40:33 --> URI Class Initialized
INFO - 2019-07-12 00:40:33 --> Router Class Initialized
INFO - 2019-07-12 00:40:33 --> Output Class Initialized
INFO - 2019-07-12 00:40:33 --> Security Class Initialized
DEBUG - 2019-07-12 00:40:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 00:40:33 --> Input Class Initialized
INFO - 2019-07-12 00:40:33 --> Language Class Initialized
INFO - 2019-07-12 00:40:33 --> Language Class Initialized
INFO - 2019-07-12 00:40:33 --> Config Class Initialized
INFO - 2019-07-12 00:40:33 --> Loader Class Initialized
DEBUG - 2019-07-12 00:40:33 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 00:40:33 --> Helper loaded: url_helper
INFO - 2019-07-12 00:40:33 --> Helper loaded: inflector_helper
INFO - 2019-07-12 00:40:33 --> Helper loaded: string_helper
INFO - 2019-07-12 00:40:33 --> Helper loaded: array_helper
INFO - 2019-07-12 00:40:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 00:40:33 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 00:40:33 --> Database Driver Class Initialized
INFO - 2019-07-12 00:40:33 --> Controller Class Initialized
INFO - 2019-07-12 06:40:33 --> Helper loaded: language_helper
INFO - 2019-07-12 06:40:33 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 06:40:33 --> Model Class Initialized
INFO - 2019-07-12 06:40:33 --> Model Class Initialized
INFO - 2019-07-12 06:40:33 --> Model Class Initialized
INFO - 2019-07-12 06:40:33 --> Model Class Initialized
INFO - 2019-07-12 06:40:33 --> Final output sent to browser
DEBUG - 2019-07-12 06:40:33 --> Total execution time: 0.5203
INFO - 2019-07-12 00:43:17 --> Config Class Initialized
INFO - 2019-07-12 00:43:17 --> Hooks Class Initialized
DEBUG - 2019-07-12 00:43:17 --> UTF-8 Support Enabled
INFO - 2019-07-12 00:43:17 --> Utf8 Class Initialized
INFO - 2019-07-12 00:43:17 --> URI Class Initialized
INFO - 2019-07-12 00:43:17 --> Router Class Initialized
INFO - 2019-07-12 00:43:17 --> Output Class Initialized
INFO - 2019-07-12 00:43:17 --> Security Class Initialized
DEBUG - 2019-07-12 00:43:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 00:43:17 --> Input Class Initialized
INFO - 2019-07-12 00:43:17 --> Language Class Initialized
INFO - 2019-07-12 00:43:17 --> Language Class Initialized
INFO - 2019-07-12 00:43:17 --> Config Class Initialized
INFO - 2019-07-12 00:43:17 --> Loader Class Initialized
DEBUG - 2019-07-12 00:43:17 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 00:43:17 --> Helper loaded: url_helper
INFO - 2019-07-12 00:43:17 --> Helper loaded: inflector_helper
INFO - 2019-07-12 00:43:17 --> Helper loaded: string_helper
INFO - 2019-07-12 00:43:17 --> Helper loaded: array_helper
INFO - 2019-07-12 00:43:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 00:43:18 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 00:43:18 --> Database Driver Class Initialized
INFO - 2019-07-12 00:43:18 --> Controller Class Initialized
INFO - 2019-07-12 06:43:18 --> Helper loaded: language_helper
INFO - 2019-07-12 06:43:18 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 06:43:18 --> Model Class Initialized
INFO - 2019-07-12 06:43:18 --> Model Class Initialized
INFO - 2019-07-12 06:43:18 --> Model Class Initialized
INFO - 2019-07-12 06:43:18 --> Model Class Initialized
INFO - 2019-07-12 06:43:18 --> Final output sent to browser
DEBUG - 2019-07-12 06:43:18 --> Total execution time: 0.5043
INFO - 2019-07-12 00:43:54 --> Config Class Initialized
INFO - 2019-07-12 00:43:54 --> Hooks Class Initialized
DEBUG - 2019-07-12 00:43:54 --> UTF-8 Support Enabled
INFO - 2019-07-12 00:43:54 --> Utf8 Class Initialized
INFO - 2019-07-12 00:43:54 --> URI Class Initialized
INFO - 2019-07-12 00:43:54 --> Router Class Initialized
INFO - 2019-07-12 00:43:54 --> Output Class Initialized
INFO - 2019-07-12 00:43:54 --> Security Class Initialized
DEBUG - 2019-07-12 00:43:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 00:43:54 --> Input Class Initialized
INFO - 2019-07-12 00:43:54 --> Language Class Initialized
INFO - 2019-07-12 00:43:54 --> Language Class Initialized
INFO - 2019-07-12 00:43:54 --> Config Class Initialized
INFO - 2019-07-12 00:43:54 --> Loader Class Initialized
DEBUG - 2019-07-12 00:43:54 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 00:43:54 --> Helper loaded: url_helper
INFO - 2019-07-12 00:43:54 --> Helper loaded: inflector_helper
INFO - 2019-07-12 00:43:54 --> Helper loaded: string_helper
INFO - 2019-07-12 00:43:54 --> Helper loaded: array_helper
INFO - 2019-07-12 00:43:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 00:43:54 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 00:43:54 --> Database Driver Class Initialized
INFO - 2019-07-12 00:43:54 --> Controller Class Initialized
INFO - 2019-07-12 06:43:54 --> Helper loaded: language_helper
INFO - 2019-07-12 06:43:54 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 06:43:55 --> Model Class Initialized
INFO - 2019-07-12 06:43:55 --> Model Class Initialized
INFO - 2019-07-12 06:43:55 --> Model Class Initialized
INFO - 2019-07-12 06:43:55 --> Model Class Initialized
INFO - 2019-07-12 06:43:55 --> Final output sent to browser
DEBUG - 2019-07-12 06:43:55 --> Total execution time: 0.4329
INFO - 2019-07-12 00:45:43 --> Config Class Initialized
INFO - 2019-07-12 00:45:43 --> Hooks Class Initialized
DEBUG - 2019-07-12 00:45:43 --> UTF-8 Support Enabled
INFO - 2019-07-12 00:45:43 --> Utf8 Class Initialized
INFO - 2019-07-12 00:45:43 --> URI Class Initialized
INFO - 2019-07-12 00:45:43 --> Router Class Initialized
INFO - 2019-07-12 00:45:43 --> Output Class Initialized
INFO - 2019-07-12 00:45:43 --> Security Class Initialized
DEBUG - 2019-07-12 00:45:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 00:45:43 --> Input Class Initialized
INFO - 2019-07-12 00:45:43 --> Language Class Initialized
INFO - 2019-07-12 00:45:43 --> Language Class Initialized
INFO - 2019-07-12 00:45:43 --> Config Class Initialized
INFO - 2019-07-12 00:45:43 --> Loader Class Initialized
DEBUG - 2019-07-12 00:45:43 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 00:45:43 --> Helper loaded: url_helper
INFO - 2019-07-12 00:45:43 --> Helper loaded: inflector_helper
INFO - 2019-07-12 00:45:43 --> Helper loaded: string_helper
INFO - 2019-07-12 00:45:43 --> Helper loaded: array_helper
INFO - 2019-07-12 00:45:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 00:45:43 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 00:45:43 --> Database Driver Class Initialized
INFO - 2019-07-12 00:45:43 --> Controller Class Initialized
INFO - 2019-07-12 06:45:43 --> Helper loaded: language_helper
INFO - 2019-07-12 06:45:43 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 06:45:43 --> Model Class Initialized
INFO - 2019-07-12 06:45:43 --> Model Class Initialized
INFO - 2019-07-12 06:45:43 --> Model Class Initialized
INFO - 2019-07-12 06:45:43 --> Model Class Initialized
INFO - 2019-07-12 06:45:43 --> Final output sent to browser
DEBUG - 2019-07-12 06:45:43 --> Total execution time: 0.4917
INFO - 2019-07-12 00:45:55 --> Config Class Initialized
INFO - 2019-07-12 00:45:55 --> Hooks Class Initialized
DEBUG - 2019-07-12 00:45:55 --> UTF-8 Support Enabled
INFO - 2019-07-12 00:45:55 --> Utf8 Class Initialized
INFO - 2019-07-12 00:45:55 --> URI Class Initialized
INFO - 2019-07-12 00:45:55 --> Router Class Initialized
INFO - 2019-07-12 00:45:55 --> Output Class Initialized
INFO - 2019-07-12 00:45:55 --> Security Class Initialized
DEBUG - 2019-07-12 00:45:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 00:45:55 --> Input Class Initialized
INFO - 2019-07-12 00:45:55 --> Language Class Initialized
INFO - 2019-07-12 00:45:55 --> Language Class Initialized
INFO - 2019-07-12 00:45:55 --> Config Class Initialized
INFO - 2019-07-12 00:45:55 --> Loader Class Initialized
DEBUG - 2019-07-12 00:45:55 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 00:45:55 --> Helper loaded: url_helper
INFO - 2019-07-12 00:45:55 --> Helper loaded: inflector_helper
INFO - 2019-07-12 00:45:55 --> Helper loaded: string_helper
INFO - 2019-07-12 00:45:55 --> Helper loaded: array_helper
INFO - 2019-07-12 00:45:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 00:45:55 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 00:45:55 --> Database Driver Class Initialized
INFO - 2019-07-12 00:45:55 --> Controller Class Initialized
INFO - 2019-07-12 06:45:55 --> Helper loaded: language_helper
INFO - 2019-07-12 06:45:55 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 06:45:55 --> Model Class Initialized
INFO - 2019-07-12 06:45:55 --> Model Class Initialized
INFO - 2019-07-12 06:45:55 --> Model Class Initialized
INFO - 2019-07-12 06:45:55 --> Model Class Initialized
INFO - 2019-07-12 06:45:55 --> Final output sent to browser
DEBUG - 2019-07-12 06:45:55 --> Total execution time: 0.4668
INFO - 2019-07-12 00:46:04 --> Config Class Initialized
INFO - 2019-07-12 00:46:04 --> Hooks Class Initialized
DEBUG - 2019-07-12 00:46:04 --> UTF-8 Support Enabled
INFO - 2019-07-12 00:46:04 --> Utf8 Class Initialized
INFO - 2019-07-12 00:46:04 --> URI Class Initialized
INFO - 2019-07-12 00:46:04 --> Router Class Initialized
INFO - 2019-07-12 00:46:04 --> Output Class Initialized
INFO - 2019-07-12 00:46:04 --> Security Class Initialized
DEBUG - 2019-07-12 00:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 00:46:04 --> Input Class Initialized
INFO - 2019-07-12 00:46:04 --> Language Class Initialized
INFO - 2019-07-12 00:46:04 --> Language Class Initialized
INFO - 2019-07-12 00:46:04 --> Config Class Initialized
INFO - 2019-07-12 00:46:04 --> Loader Class Initialized
DEBUG - 2019-07-12 00:46:04 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 00:46:04 --> Helper loaded: url_helper
INFO - 2019-07-12 00:46:04 --> Helper loaded: inflector_helper
INFO - 2019-07-12 00:46:04 --> Helper loaded: string_helper
INFO - 2019-07-12 00:46:04 --> Helper loaded: array_helper
INFO - 2019-07-12 00:46:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 00:46:04 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 00:46:04 --> Database Driver Class Initialized
INFO - 2019-07-12 00:46:04 --> Controller Class Initialized
INFO - 2019-07-12 06:46:04 --> Helper loaded: language_helper
INFO - 2019-07-12 06:46:04 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 06:46:04 --> Model Class Initialized
INFO - 2019-07-12 06:46:04 --> Model Class Initialized
INFO - 2019-07-12 06:46:04 --> Model Class Initialized
INFO - 2019-07-12 06:46:04 --> Model Class Initialized
INFO - 2019-07-12 06:46:04 --> Final output sent to browser
DEBUG - 2019-07-12 06:46:04 --> Total execution time: 0.4889
INFO - 2019-07-12 00:46:31 --> Config Class Initialized
INFO - 2019-07-12 00:46:31 --> Hooks Class Initialized
DEBUG - 2019-07-12 00:46:31 --> UTF-8 Support Enabled
INFO - 2019-07-12 00:46:31 --> Utf8 Class Initialized
INFO - 2019-07-12 00:46:31 --> URI Class Initialized
INFO - 2019-07-12 00:46:31 --> Router Class Initialized
INFO - 2019-07-12 00:46:31 --> Output Class Initialized
INFO - 2019-07-12 00:46:31 --> Security Class Initialized
DEBUG - 2019-07-12 00:46:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 00:46:31 --> Input Class Initialized
INFO - 2019-07-12 00:46:31 --> Language Class Initialized
INFO - 2019-07-12 00:46:31 --> Language Class Initialized
INFO - 2019-07-12 00:46:31 --> Config Class Initialized
INFO - 2019-07-12 00:46:31 --> Loader Class Initialized
DEBUG - 2019-07-12 00:46:31 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 00:46:31 --> Helper loaded: url_helper
INFO - 2019-07-12 00:46:31 --> Helper loaded: inflector_helper
INFO - 2019-07-12 00:46:31 --> Helper loaded: string_helper
INFO - 2019-07-12 00:46:31 --> Helper loaded: array_helper
INFO - 2019-07-12 00:46:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 00:46:31 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 00:46:31 --> Database Driver Class Initialized
INFO - 2019-07-12 00:46:31 --> Controller Class Initialized
INFO - 2019-07-12 06:46:31 --> Helper loaded: language_helper
INFO - 2019-07-12 06:46:31 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 06:46:31 --> Model Class Initialized
INFO - 2019-07-12 06:46:31 --> Model Class Initialized
INFO - 2019-07-12 06:46:31 --> Model Class Initialized
INFO - 2019-07-12 06:46:32 --> Model Class Initialized
INFO - 2019-07-12 06:46:32 --> Final output sent to browser
DEBUG - 2019-07-12 06:46:32 --> Total execution time: 0.4700
INFO - 2019-07-12 00:51:16 --> Config Class Initialized
INFO - 2019-07-12 00:51:16 --> Hooks Class Initialized
DEBUG - 2019-07-12 00:51:16 --> UTF-8 Support Enabled
INFO - 2019-07-12 00:51:16 --> Utf8 Class Initialized
INFO - 2019-07-12 00:51:16 --> URI Class Initialized
INFO - 2019-07-12 00:51:16 --> Router Class Initialized
INFO - 2019-07-12 00:51:16 --> Output Class Initialized
INFO - 2019-07-12 00:51:16 --> Security Class Initialized
DEBUG - 2019-07-12 00:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 00:51:16 --> Input Class Initialized
INFO - 2019-07-12 00:51:16 --> Language Class Initialized
INFO - 2019-07-12 00:51:16 --> Language Class Initialized
INFO - 2019-07-12 00:51:16 --> Config Class Initialized
INFO - 2019-07-12 00:51:16 --> Loader Class Initialized
DEBUG - 2019-07-12 00:51:16 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 00:51:16 --> Helper loaded: url_helper
INFO - 2019-07-12 00:51:16 --> Helper loaded: inflector_helper
INFO - 2019-07-12 00:51:16 --> Helper loaded: string_helper
INFO - 2019-07-12 00:51:16 --> Helper loaded: array_helper
INFO - 2019-07-12 00:51:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 00:51:17 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 00:51:17 --> Database Driver Class Initialized
INFO - 2019-07-12 00:51:17 --> Controller Class Initialized
INFO - 2019-07-12 06:51:17 --> Helper loaded: language_helper
INFO - 2019-07-12 06:51:17 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 06:51:17 --> Model Class Initialized
INFO - 2019-07-12 06:51:17 --> Model Class Initialized
INFO - 2019-07-12 06:51:17 --> Model Class Initialized
INFO - 2019-07-12 06:51:17 --> Model Class Initialized
INFO - 2019-07-12 06:51:17 --> Final output sent to browser
DEBUG - 2019-07-12 06:51:17 --> Total execution time: 0.4612
INFO - 2019-07-12 00:51:43 --> Config Class Initialized
INFO - 2019-07-12 00:51:43 --> Hooks Class Initialized
INFO - 2019-07-12 00:51:43 --> Config Class Initialized
DEBUG - 2019-07-12 00:51:43 --> UTF-8 Support Enabled
INFO - 2019-07-12 00:51:43 --> Hooks Class Initialized
INFO - 2019-07-12 00:51:43 --> Utf8 Class Initialized
DEBUG - 2019-07-12 00:51:43 --> UTF-8 Support Enabled
INFO - 2019-07-12 00:51:43 --> URI Class Initialized
INFO - 2019-07-12 00:51:43 --> Utf8 Class Initialized
INFO - 2019-07-12 00:51:43 --> URI Class Initialized
INFO - 2019-07-12 00:51:43 --> Router Class Initialized
INFO - 2019-07-12 00:51:44 --> Router Class Initialized
INFO - 2019-07-12 00:51:44 --> Output Class Initialized
INFO - 2019-07-12 00:51:44 --> Output Class Initialized
INFO - 2019-07-12 00:51:44 --> Security Class Initialized
INFO - 2019-07-12 00:51:44 --> Security Class Initialized
DEBUG - 2019-07-12 00:51:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-12 00:51:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 00:51:44 --> Input Class Initialized
INFO - 2019-07-12 00:51:44 --> Input Class Initialized
INFO - 2019-07-12 00:51:44 --> Language Class Initialized
INFO - 2019-07-12 00:51:44 --> Language Class Initialized
INFO - 2019-07-12 00:51:44 --> Language Class Initialized
INFO - 2019-07-12 00:51:44 --> Language Class Initialized
INFO - 2019-07-12 00:51:44 --> Config Class Initialized
INFO - 2019-07-12 00:51:44 --> Loader Class Initialized
INFO - 2019-07-12 00:51:44 --> Config Class Initialized
INFO - 2019-07-12 00:51:44 --> Loader Class Initialized
DEBUG - 2019-07-12 00:51:44 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-12 00:51:44 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 00:51:44 --> Helper loaded: url_helper
INFO - 2019-07-12 00:51:44 --> Helper loaded: url_helper
INFO - 2019-07-12 00:51:44 --> Helper loaded: inflector_helper
INFO - 2019-07-12 00:51:44 --> Helper loaded: inflector_helper
INFO - 2019-07-12 00:51:44 --> Helper loaded: string_helper
INFO - 2019-07-12 00:51:44 --> Helper loaded: string_helper
INFO - 2019-07-12 00:51:44 --> Helper loaded: array_helper
INFO - 2019-07-12 00:51:44 --> Helper loaded: array_helper
INFO - 2019-07-12 00:51:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 00:51:44 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 00:51:44 --> Database Driver Class Initialized
INFO - 2019-07-12 00:51:44 --> Controller Class Initialized
INFO - 2019-07-12 06:51:44 --> Helper loaded: language_helper
INFO - 2019-07-12 06:51:44 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 06:51:44 --> Model Class Initialized
INFO - 2019-07-12 06:51:44 --> Model Class Initialized
INFO - 2019-07-12 06:51:44 --> Model Class Initialized
INFO - 2019-07-12 06:51:44 --> Model Class Initialized
ERROR - 2019-07-12 06:51:44 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Owners.php 79
INFO - 2019-07-12 06:51:44 --> Final output sent to browser
DEBUG - 2019-07-12 06:51:44 --> Total execution time: 0.6866
INFO - 2019-07-12 00:51:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 00:51:44 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 00:51:44 --> Database Driver Class Initialized
INFO - 2019-07-12 00:51:44 --> Controller Class Initialized
INFO - 2019-07-12 06:51:44 --> Helper loaded: language_helper
INFO - 2019-07-12 06:51:44 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 06:51:44 --> Model Class Initialized
INFO - 2019-07-12 06:51:44 --> Model Class Initialized
INFO - 2019-07-12 06:51:44 --> Model Class Initialized
INFO - 2019-07-12 06:51:44 --> Model Class Initialized
INFO - 2019-07-12 06:51:44 --> Final output sent to browser
DEBUG - 2019-07-12 06:51:44 --> Total execution time: 0.8748
INFO - 2019-07-12 00:52:04 --> Config Class Initialized
INFO - 2019-07-12 00:52:04 --> Hooks Class Initialized
INFO - 2019-07-12 00:52:04 --> Config Class Initialized
DEBUG - 2019-07-12 00:52:04 --> UTF-8 Support Enabled
INFO - 2019-07-12 00:52:04 --> Hooks Class Initialized
INFO - 2019-07-12 00:52:04 --> Utf8 Class Initialized
DEBUG - 2019-07-12 00:52:04 --> UTF-8 Support Enabled
INFO - 2019-07-12 00:52:05 --> URI Class Initialized
INFO - 2019-07-12 00:52:05 --> Utf8 Class Initialized
INFO - 2019-07-12 00:52:05 --> URI Class Initialized
INFO - 2019-07-12 00:52:05 --> Router Class Initialized
INFO - 2019-07-12 00:52:05 --> Router Class Initialized
INFO - 2019-07-12 00:52:05 --> Output Class Initialized
INFO - 2019-07-12 00:52:05 --> Output Class Initialized
INFO - 2019-07-12 00:52:05 --> Security Class Initialized
INFO - 2019-07-12 00:52:05 --> Security Class Initialized
DEBUG - 2019-07-12 00:52:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-12 00:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 00:52:05 --> Input Class Initialized
INFO - 2019-07-12 00:52:05 --> Input Class Initialized
INFO - 2019-07-12 00:52:05 --> Language Class Initialized
INFO - 2019-07-12 00:52:05 --> Language Class Initialized
INFO - 2019-07-12 00:52:05 --> Language Class Initialized
INFO - 2019-07-12 00:52:05 --> Language Class Initialized
INFO - 2019-07-12 00:52:05 --> Config Class Initialized
INFO - 2019-07-12 00:52:05 --> Loader Class Initialized
INFO - 2019-07-12 00:52:05 --> Config Class Initialized
INFO - 2019-07-12 00:52:05 --> Loader Class Initialized
DEBUG - 2019-07-12 00:52:05 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-12 00:52:05 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 00:52:05 --> Helper loaded: url_helper
INFO - 2019-07-12 00:52:05 --> Helper loaded: url_helper
INFO - 2019-07-12 00:52:05 --> Helper loaded: inflector_helper
INFO - 2019-07-12 00:52:05 --> Helper loaded: inflector_helper
INFO - 2019-07-12 00:52:05 --> Helper loaded: string_helper
INFO - 2019-07-12 00:52:05 --> Helper loaded: string_helper
INFO - 2019-07-12 00:52:05 --> Helper loaded: array_helper
INFO - 2019-07-12 00:52:05 --> Helper loaded: array_helper
INFO - 2019-07-12 00:52:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 00:52:05 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 00:52:05 --> Database Driver Class Initialized
INFO - 2019-07-12 00:52:05 --> Controller Class Initialized
INFO - 2019-07-12 06:52:05 --> Helper loaded: language_helper
INFO - 2019-07-12 06:52:05 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 06:52:05 --> Model Class Initialized
INFO - 2019-07-12 06:52:05 --> Model Class Initialized
INFO - 2019-07-12 06:52:05 --> Model Class Initialized
INFO - 2019-07-12 06:52:05 --> Model Class Initialized
INFO - 2019-07-12 06:52:05 --> Final output sent to browser
DEBUG - 2019-07-12 06:52:05 --> Total execution time: 0.6544
INFO - 2019-07-12 00:52:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 00:52:05 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 00:52:05 --> Database Driver Class Initialized
INFO - 2019-07-12 00:52:05 --> Controller Class Initialized
INFO - 2019-07-12 06:52:05 --> Helper loaded: language_helper
INFO - 2019-07-12 06:52:05 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 06:52:05 --> Model Class Initialized
INFO - 2019-07-12 06:52:05 --> Model Class Initialized
INFO - 2019-07-12 06:52:05 --> Model Class Initialized
INFO - 2019-07-12 06:52:05 --> Model Class Initialized
ERROR - 2019-07-12 06:52:05 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Owners.php 79
INFO - 2019-07-12 06:52:05 --> Final output sent to browser
DEBUG - 2019-07-12 06:52:05 --> Total execution time: 0.8453
INFO - 2019-07-12 00:52:31 --> Config Class Initialized
INFO - 2019-07-12 00:52:32 --> Config Class Initialized
INFO - 2019-07-12 00:52:32 --> Hooks Class Initialized
INFO - 2019-07-12 00:52:32 --> Hooks Class Initialized
DEBUG - 2019-07-12 00:52:32 --> UTF-8 Support Enabled
DEBUG - 2019-07-12 00:52:32 --> UTF-8 Support Enabled
INFO - 2019-07-12 00:52:32 --> Utf8 Class Initialized
INFO - 2019-07-12 00:52:32 --> Utf8 Class Initialized
INFO - 2019-07-12 00:52:32 --> URI Class Initialized
INFO - 2019-07-12 00:52:32 --> URI Class Initialized
INFO - 2019-07-12 00:52:32 --> Router Class Initialized
INFO - 2019-07-12 00:52:32 --> Router Class Initialized
INFO - 2019-07-12 00:52:32 --> Output Class Initialized
INFO - 2019-07-12 00:52:32 --> Output Class Initialized
INFO - 2019-07-12 00:52:32 --> Security Class Initialized
INFO - 2019-07-12 00:52:32 --> Security Class Initialized
DEBUG - 2019-07-12 00:52:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-12 00:52:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 00:52:32 --> Input Class Initialized
INFO - 2019-07-12 00:52:32 --> Input Class Initialized
INFO - 2019-07-12 00:52:32 --> Language Class Initialized
INFO - 2019-07-12 00:52:32 --> Language Class Initialized
INFO - 2019-07-12 00:52:32 --> Language Class Initialized
INFO - 2019-07-12 00:52:32 --> Language Class Initialized
INFO - 2019-07-12 00:52:32 --> Config Class Initialized
INFO - 2019-07-12 00:52:32 --> Loader Class Initialized
INFO - 2019-07-12 00:52:32 --> Config Class Initialized
INFO - 2019-07-12 00:52:32 --> Loader Class Initialized
DEBUG - 2019-07-12 00:52:32 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-12 00:52:32 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 00:52:32 --> Helper loaded: url_helper
INFO - 2019-07-12 00:52:32 --> Helper loaded: url_helper
INFO - 2019-07-12 00:52:32 --> Helper loaded: inflector_helper
INFO - 2019-07-12 00:52:32 --> Helper loaded: inflector_helper
INFO - 2019-07-12 00:52:32 --> Helper loaded: string_helper
INFO - 2019-07-12 00:52:32 --> Helper loaded: string_helper
INFO - 2019-07-12 00:52:32 --> Helper loaded: array_helper
INFO - 2019-07-12 00:52:32 --> Helper loaded: array_helper
INFO - 2019-07-12 00:52:32 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 00:52:32 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 00:52:32 --> Database Driver Class Initialized
INFO - 2019-07-12 00:52:32 --> Controller Class Initialized
INFO - 2019-07-12 06:52:32 --> Helper loaded: language_helper
INFO - 2019-07-12 06:52:32 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 06:52:32 --> Model Class Initialized
INFO - 2019-07-12 06:52:32 --> Model Class Initialized
INFO - 2019-07-12 06:52:32 --> Model Class Initialized
INFO - 2019-07-12 06:52:32 --> Model Class Initialized
INFO - 2019-07-12 06:52:32 --> Final output sent to browser
DEBUG - 2019-07-12 06:52:32 --> Total execution time: 0.6697
INFO - 2019-07-12 00:52:32 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 00:52:32 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 00:52:32 --> Database Driver Class Initialized
INFO - 2019-07-12 00:52:32 --> Controller Class Initialized
INFO - 2019-07-12 06:52:32 --> Helper loaded: language_helper
INFO - 2019-07-12 06:52:32 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 06:52:32 --> Model Class Initialized
INFO - 2019-07-12 06:52:32 --> Model Class Initialized
INFO - 2019-07-12 06:52:32 --> Model Class Initialized
INFO - 2019-07-12 06:52:32 --> Model Class Initialized
ERROR - 2019-07-12 06:52:32 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Owners.php 79
INFO - 2019-07-12 06:52:32 --> Final output sent to browser
DEBUG - 2019-07-12 06:52:32 --> Total execution time: 0.8889
INFO - 2019-07-12 00:52:41 --> Config Class Initialized
INFO - 2019-07-12 00:52:41 --> Hooks Class Initialized
INFO - 2019-07-12 00:52:41 --> Config Class Initialized
DEBUG - 2019-07-12 00:52:41 --> UTF-8 Support Enabled
INFO - 2019-07-12 00:52:41 --> Hooks Class Initialized
INFO - 2019-07-12 00:52:41 --> Utf8 Class Initialized
DEBUG - 2019-07-12 00:52:41 --> UTF-8 Support Enabled
INFO - 2019-07-12 00:52:41 --> URI Class Initialized
INFO - 2019-07-12 00:52:41 --> Utf8 Class Initialized
INFO - 2019-07-12 00:52:41 --> URI Class Initialized
INFO - 2019-07-12 00:52:41 --> Router Class Initialized
INFO - 2019-07-12 00:52:41 --> Router Class Initialized
INFO - 2019-07-12 00:52:41 --> Output Class Initialized
INFO - 2019-07-12 00:52:41 --> Output Class Initialized
INFO - 2019-07-12 00:52:41 --> Security Class Initialized
INFO - 2019-07-12 00:52:41 --> Security Class Initialized
DEBUG - 2019-07-12 00:52:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-12 00:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 00:52:41 --> Input Class Initialized
INFO - 2019-07-12 00:52:41 --> Input Class Initialized
INFO - 2019-07-12 00:52:41 --> Language Class Initialized
INFO - 2019-07-12 00:52:41 --> Language Class Initialized
INFO - 2019-07-12 00:52:41 --> Language Class Initialized
INFO - 2019-07-12 00:52:41 --> Language Class Initialized
INFO - 2019-07-12 00:52:41 --> Config Class Initialized
INFO - 2019-07-12 00:52:41 --> Config Class Initialized
INFO - 2019-07-12 00:52:41 --> Loader Class Initialized
INFO - 2019-07-12 00:52:41 --> Loader Class Initialized
DEBUG - 2019-07-12 00:52:41 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-12 00:52:41 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 00:52:41 --> Helper loaded: url_helper
INFO - 2019-07-12 00:52:41 --> Helper loaded: url_helper
INFO - 2019-07-12 00:52:41 --> Helper loaded: inflector_helper
INFO - 2019-07-12 00:52:41 --> Helper loaded: inflector_helper
INFO - 2019-07-12 00:52:41 --> Helper loaded: string_helper
INFO - 2019-07-12 00:52:41 --> Helper loaded: string_helper
INFO - 2019-07-12 00:52:41 --> Helper loaded: array_helper
INFO - 2019-07-12 00:52:41 --> Helper loaded: array_helper
INFO - 2019-07-12 00:52:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 00:52:41 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 00:52:41 --> Database Driver Class Initialized
INFO - 2019-07-12 00:52:41 --> Controller Class Initialized
INFO - 2019-07-12 06:52:41 --> Helper loaded: language_helper
INFO - 2019-07-12 06:52:41 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 06:52:41 --> Model Class Initialized
INFO - 2019-07-12 06:52:41 --> Model Class Initialized
INFO - 2019-07-12 06:52:41 --> Model Class Initialized
INFO - 2019-07-12 06:52:41 --> Model Class Initialized
INFO - 2019-07-12 06:52:41 --> Final output sent to browser
DEBUG - 2019-07-12 06:52:41 --> Total execution time: 0.6663
INFO - 2019-07-12 00:52:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 00:52:41 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 00:52:41 --> Database Driver Class Initialized
INFO - 2019-07-12 00:52:41 --> Controller Class Initialized
INFO - 2019-07-12 06:52:41 --> Helper loaded: language_helper
INFO - 2019-07-12 06:52:41 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 06:52:41 --> Model Class Initialized
INFO - 2019-07-12 06:52:41 --> Model Class Initialized
INFO - 2019-07-12 06:52:41 --> Model Class Initialized
INFO - 2019-07-12 06:52:41 --> Model Class Initialized
ERROR - 2019-07-12 06:52:41 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Owners.php 79
INFO - 2019-07-12 06:52:41 --> Final output sent to browser
DEBUG - 2019-07-12 06:52:41 --> Total execution time: 0.8759
INFO - 2019-07-12 00:52:44 --> Config Class Initialized
INFO - 2019-07-12 00:52:44 --> Config Class Initialized
INFO - 2019-07-12 00:52:44 --> Hooks Class Initialized
INFO - 2019-07-12 00:52:44 --> Hooks Class Initialized
DEBUG - 2019-07-12 00:52:44 --> UTF-8 Support Enabled
DEBUG - 2019-07-12 00:52:44 --> UTF-8 Support Enabled
INFO - 2019-07-12 00:52:44 --> Utf8 Class Initialized
INFO - 2019-07-12 00:52:45 --> Utf8 Class Initialized
INFO - 2019-07-12 00:52:45 --> URI Class Initialized
INFO - 2019-07-12 00:52:45 --> URI Class Initialized
INFO - 2019-07-12 00:52:45 --> Router Class Initialized
INFO - 2019-07-12 00:52:45 --> Router Class Initialized
INFO - 2019-07-12 00:52:45 --> Output Class Initialized
INFO - 2019-07-12 00:52:45 --> Output Class Initialized
INFO - 2019-07-12 00:52:45 --> Security Class Initialized
INFO - 2019-07-12 00:52:45 --> Security Class Initialized
DEBUG - 2019-07-12 00:52:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-12 00:52:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 00:52:45 --> Input Class Initialized
INFO - 2019-07-12 00:52:45 --> Input Class Initialized
INFO - 2019-07-12 00:52:45 --> Language Class Initialized
INFO - 2019-07-12 00:52:45 --> Language Class Initialized
INFO - 2019-07-12 00:52:45 --> Language Class Initialized
INFO - 2019-07-12 00:52:45 --> Language Class Initialized
INFO - 2019-07-12 00:52:45 --> Config Class Initialized
INFO - 2019-07-12 00:52:45 --> Config Class Initialized
INFO - 2019-07-12 00:52:45 --> Loader Class Initialized
INFO - 2019-07-12 00:52:45 --> Loader Class Initialized
DEBUG - 2019-07-12 00:52:45 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-12 00:52:45 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 00:52:45 --> Helper loaded: url_helper
INFO - 2019-07-12 00:52:45 --> Helper loaded: url_helper
INFO - 2019-07-12 00:52:45 --> Helper loaded: inflector_helper
INFO - 2019-07-12 00:52:45 --> Helper loaded: inflector_helper
INFO - 2019-07-12 00:52:45 --> Helper loaded: string_helper
INFO - 2019-07-12 00:52:45 --> Helper loaded: string_helper
INFO - 2019-07-12 00:52:45 --> Helper loaded: array_helper
INFO - 2019-07-12 00:52:45 --> Helper loaded: array_helper
INFO - 2019-07-12 00:52:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 00:52:45 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 00:52:45 --> Database Driver Class Initialized
INFO - 2019-07-12 00:52:45 --> Controller Class Initialized
INFO - 2019-07-12 06:52:45 --> Helper loaded: language_helper
INFO - 2019-07-12 06:52:45 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 06:52:45 --> Model Class Initialized
INFO - 2019-07-12 06:52:45 --> Model Class Initialized
INFO - 2019-07-12 06:52:45 --> Model Class Initialized
INFO - 2019-07-12 06:52:45 --> Model Class Initialized
ERROR - 2019-07-12 06:52:45 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Owners.php 79
INFO - 2019-07-12 06:52:45 --> Final output sent to browser
DEBUG - 2019-07-12 06:52:45 --> Total execution time: 0.6752
INFO - 2019-07-12 00:52:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 00:52:45 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 00:52:45 --> Database Driver Class Initialized
INFO - 2019-07-12 00:52:45 --> Controller Class Initialized
INFO - 2019-07-12 06:52:45 --> Helper loaded: language_helper
INFO - 2019-07-12 06:52:45 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 06:52:45 --> Model Class Initialized
INFO - 2019-07-12 06:52:45 --> Model Class Initialized
INFO - 2019-07-12 06:52:45 --> Model Class Initialized
INFO - 2019-07-12 06:52:45 --> Model Class Initialized
INFO - 2019-07-12 06:52:45 --> Final output sent to browser
DEBUG - 2019-07-12 06:52:45 --> Total execution time: 0.8823
INFO - 2019-07-12 00:53:44 --> Config Class Initialized
INFO - 2019-07-12 00:53:44 --> Hooks Class Initialized
INFO - 2019-07-12 00:53:44 --> Config Class Initialized
INFO - 2019-07-12 00:53:44 --> Hooks Class Initialized
DEBUG - 2019-07-12 00:53:44 --> UTF-8 Support Enabled
DEBUG - 2019-07-12 00:53:44 --> UTF-8 Support Enabled
INFO - 2019-07-12 00:53:44 --> Utf8 Class Initialized
INFO - 2019-07-12 00:53:44 --> Utf8 Class Initialized
INFO - 2019-07-12 00:53:44 --> URI Class Initialized
INFO - 2019-07-12 00:53:44 --> URI Class Initialized
INFO - 2019-07-12 00:53:44 --> Router Class Initialized
INFO - 2019-07-12 00:53:44 --> Router Class Initialized
INFO - 2019-07-12 00:53:44 --> Output Class Initialized
INFO - 2019-07-12 00:53:44 --> Output Class Initialized
INFO - 2019-07-12 00:53:44 --> Security Class Initialized
INFO - 2019-07-12 00:53:44 --> Security Class Initialized
DEBUG - 2019-07-12 00:53:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-12 00:53:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 00:53:44 --> Input Class Initialized
INFO - 2019-07-12 00:53:44 --> Input Class Initialized
INFO - 2019-07-12 00:53:44 --> Language Class Initialized
INFO - 2019-07-12 00:53:44 --> Language Class Initialized
INFO - 2019-07-12 00:53:44 --> Language Class Initialized
INFO - 2019-07-12 00:53:44 --> Language Class Initialized
INFO - 2019-07-12 00:53:44 --> Config Class Initialized
INFO - 2019-07-12 00:53:44 --> Loader Class Initialized
INFO - 2019-07-12 00:53:44 --> Config Class Initialized
INFO - 2019-07-12 00:53:44 --> Loader Class Initialized
DEBUG - 2019-07-12 00:53:44 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-12 00:53:44 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 00:53:44 --> Helper loaded: url_helper
INFO - 2019-07-12 00:53:44 --> Helper loaded: url_helper
INFO - 2019-07-12 00:53:44 --> Helper loaded: inflector_helper
INFO - 2019-07-12 00:53:44 --> Helper loaded: inflector_helper
INFO - 2019-07-12 00:53:44 --> Helper loaded: string_helper
INFO - 2019-07-12 00:53:44 --> Helper loaded: string_helper
INFO - 2019-07-12 00:53:44 --> Helper loaded: array_helper
INFO - 2019-07-12 00:53:44 --> Helper loaded: array_helper
INFO - 2019-07-12 00:53:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 00:53:44 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 00:53:44 --> Database Driver Class Initialized
INFO - 2019-07-12 00:53:44 --> Controller Class Initialized
INFO - 2019-07-12 06:53:44 --> Helper loaded: language_helper
INFO - 2019-07-12 06:53:44 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 06:53:44 --> Model Class Initialized
INFO - 2019-07-12 06:53:44 --> Model Class Initialized
INFO - 2019-07-12 06:53:44 --> Model Class Initialized
INFO - 2019-07-12 06:53:44 --> Model Class Initialized
INFO - 2019-07-12 06:53:44 --> Final output sent to browser
DEBUG - 2019-07-12 06:53:44 --> Total execution time: 0.6712
INFO - 2019-07-12 00:53:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 00:53:44 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 00:53:45 --> Database Driver Class Initialized
INFO - 2019-07-12 00:53:45 --> Controller Class Initialized
INFO - 2019-07-12 06:53:45 --> Helper loaded: language_helper
INFO - 2019-07-12 06:53:45 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 06:53:45 --> Model Class Initialized
INFO - 2019-07-12 06:53:45 --> Model Class Initialized
INFO - 2019-07-12 06:53:45 --> Model Class Initialized
INFO - 2019-07-12 06:53:45 --> Model Class Initialized
ERROR - 2019-07-12 06:53:45 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Owners.php 79
INFO - 2019-07-12 06:53:45 --> Final output sent to browser
DEBUG - 2019-07-12 06:53:45 --> Total execution time: 0.8813
INFO - 2019-07-12 00:54:29 --> Config Class Initialized
INFO - 2019-07-12 00:54:29 --> Hooks Class Initialized
DEBUG - 2019-07-12 00:54:29 --> UTF-8 Support Enabled
INFO - 2019-07-12 00:54:29 --> Utf8 Class Initialized
INFO - 2019-07-12 00:54:29 --> URI Class Initialized
INFO - 2019-07-12 00:54:29 --> Router Class Initialized
INFO - 2019-07-12 00:54:29 --> Output Class Initialized
INFO - 2019-07-12 00:54:29 --> Security Class Initialized
DEBUG - 2019-07-12 00:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 00:54:29 --> Input Class Initialized
INFO - 2019-07-12 00:54:29 --> Language Class Initialized
INFO - 2019-07-12 00:54:29 --> Language Class Initialized
INFO - 2019-07-12 00:54:29 --> Config Class Initialized
INFO - 2019-07-12 00:54:29 --> Loader Class Initialized
DEBUG - 2019-07-12 00:54:29 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 00:54:29 --> Helper loaded: url_helper
INFO - 2019-07-12 00:54:29 --> Helper loaded: inflector_helper
INFO - 2019-07-12 00:54:29 --> Helper loaded: string_helper
INFO - 2019-07-12 00:54:29 --> Helper loaded: array_helper
INFO - 2019-07-12 00:54:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 00:54:29 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 00:54:29 --> Database Driver Class Initialized
INFO - 2019-07-12 00:54:29 --> Controller Class Initialized
INFO - 2019-07-12 06:54:29 --> Helper loaded: language_helper
INFO - 2019-07-12 06:54:29 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 06:54:29 --> Model Class Initialized
INFO - 2019-07-12 06:54:29 --> Model Class Initialized
INFO - 2019-07-12 06:54:29 --> Model Class Initialized
INFO - 2019-07-12 06:54:29 --> Model Class Initialized
INFO - 2019-07-12 06:54:29 --> Final output sent to browser
DEBUG - 2019-07-12 06:54:29 --> Total execution time: 0.4935
INFO - 2019-07-12 00:54:30 --> Config Class Initialized
INFO - 2019-07-12 00:54:30 --> Hooks Class Initialized
DEBUG - 2019-07-12 00:54:30 --> UTF-8 Support Enabled
INFO - 2019-07-12 00:54:30 --> Utf8 Class Initialized
INFO - 2019-07-12 00:54:30 --> URI Class Initialized
INFO - 2019-07-12 00:54:30 --> Router Class Initialized
INFO - 2019-07-12 00:54:30 --> Output Class Initialized
INFO - 2019-07-12 00:54:30 --> Security Class Initialized
DEBUG - 2019-07-12 00:54:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 00:54:30 --> Input Class Initialized
INFO - 2019-07-12 00:54:30 --> Language Class Initialized
INFO - 2019-07-12 00:54:30 --> Language Class Initialized
INFO - 2019-07-12 00:54:30 --> Config Class Initialized
INFO - 2019-07-12 00:54:31 --> Loader Class Initialized
DEBUG - 2019-07-12 00:54:31 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 00:54:31 --> Helper loaded: url_helper
INFO - 2019-07-12 00:54:31 --> Helper loaded: inflector_helper
INFO - 2019-07-12 00:54:31 --> Helper loaded: string_helper
INFO - 2019-07-12 00:54:31 --> Helper loaded: array_helper
INFO - 2019-07-12 00:54:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 00:54:31 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 00:54:31 --> Database Driver Class Initialized
INFO - 2019-07-12 00:54:31 --> Controller Class Initialized
INFO - 2019-07-12 06:54:31 --> Helper loaded: language_helper
INFO - 2019-07-12 06:54:31 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 06:54:31 --> Model Class Initialized
INFO - 2019-07-12 06:54:31 --> Model Class Initialized
INFO - 2019-07-12 06:54:31 --> Model Class Initialized
INFO - 2019-07-12 06:54:31 --> Model Class Initialized
ERROR - 2019-07-12 06:54:31 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Owners.php 79
INFO - 2019-07-12 06:54:31 --> Final output sent to browser
DEBUG - 2019-07-12 06:54:31 --> Total execution time: 0.4998
INFO - 2019-07-12 00:54:32 --> Config Class Initialized
INFO - 2019-07-12 00:54:32 --> Hooks Class Initialized
DEBUG - 2019-07-12 00:54:32 --> UTF-8 Support Enabled
INFO - 2019-07-12 00:54:32 --> Utf8 Class Initialized
INFO - 2019-07-12 00:54:32 --> URI Class Initialized
INFO - 2019-07-12 00:54:32 --> Router Class Initialized
INFO - 2019-07-12 00:54:32 --> Output Class Initialized
INFO - 2019-07-12 00:54:32 --> Security Class Initialized
DEBUG - 2019-07-12 00:54:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 00:54:32 --> Input Class Initialized
INFO - 2019-07-12 00:54:32 --> Language Class Initialized
INFO - 2019-07-12 00:54:32 --> Language Class Initialized
INFO - 2019-07-12 00:54:32 --> Config Class Initialized
INFO - 2019-07-12 00:54:32 --> Loader Class Initialized
DEBUG - 2019-07-12 00:54:32 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 00:54:32 --> Helper loaded: url_helper
INFO - 2019-07-12 00:54:32 --> Helper loaded: inflector_helper
INFO - 2019-07-12 00:54:32 --> Helper loaded: string_helper
INFO - 2019-07-12 00:54:32 --> Helper loaded: array_helper
INFO - 2019-07-12 00:54:32 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 00:54:32 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 00:54:32 --> Database Driver Class Initialized
INFO - 2019-07-12 00:54:32 --> Controller Class Initialized
INFO - 2019-07-12 06:54:32 --> Helper loaded: language_helper
INFO - 2019-07-12 06:54:32 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 06:54:32 --> Model Class Initialized
INFO - 2019-07-12 06:54:32 --> Model Class Initialized
INFO - 2019-07-12 06:54:32 --> Model Class Initialized
INFO - 2019-07-12 06:54:32 --> Model Class Initialized
INFO - 2019-07-12 06:54:32 --> Final output sent to browser
DEBUG - 2019-07-12 06:54:32 --> Total execution time: 0.4738
INFO - 2019-07-12 00:54:33 --> Config Class Initialized
INFO - 2019-07-12 00:54:33 --> Hooks Class Initialized
DEBUG - 2019-07-12 00:54:33 --> UTF-8 Support Enabled
INFO - 2019-07-12 00:54:33 --> Utf8 Class Initialized
INFO - 2019-07-12 00:54:33 --> URI Class Initialized
INFO - 2019-07-12 00:54:33 --> Router Class Initialized
INFO - 2019-07-12 00:54:33 --> Output Class Initialized
INFO - 2019-07-12 00:54:33 --> Security Class Initialized
DEBUG - 2019-07-12 00:54:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 00:54:33 --> Input Class Initialized
INFO - 2019-07-12 00:54:33 --> Language Class Initialized
INFO - 2019-07-12 00:54:33 --> Language Class Initialized
INFO - 2019-07-12 00:54:33 --> Config Class Initialized
INFO - 2019-07-12 00:54:33 --> Loader Class Initialized
DEBUG - 2019-07-12 00:54:33 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 00:54:33 --> Helper loaded: url_helper
INFO - 2019-07-12 00:54:33 --> Helper loaded: inflector_helper
INFO - 2019-07-12 00:54:33 --> Helper loaded: string_helper
INFO - 2019-07-12 00:54:33 --> Helper loaded: array_helper
INFO - 2019-07-12 00:54:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 00:54:33 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 00:54:33 --> Database Driver Class Initialized
INFO - 2019-07-12 00:54:33 --> Controller Class Initialized
INFO - 2019-07-12 06:54:34 --> Helper loaded: language_helper
INFO - 2019-07-12 06:54:34 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 06:54:34 --> Model Class Initialized
INFO - 2019-07-12 06:54:34 --> Model Class Initialized
INFO - 2019-07-12 06:54:34 --> Model Class Initialized
INFO - 2019-07-12 06:54:34 --> Model Class Initialized
ERROR - 2019-07-12 06:54:34 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Owners.php 79
INFO - 2019-07-12 06:54:34 --> Final output sent to browser
DEBUG - 2019-07-12 06:54:34 --> Total execution time: 0.4869
INFO - 2019-07-12 00:55:02 --> Config Class Initialized
INFO - 2019-07-12 00:55:02 --> Hooks Class Initialized
DEBUG - 2019-07-12 00:55:02 --> UTF-8 Support Enabled
INFO - 2019-07-12 00:55:02 --> Utf8 Class Initialized
INFO - 2019-07-12 00:55:02 --> URI Class Initialized
INFO - 2019-07-12 00:55:02 --> Router Class Initialized
INFO - 2019-07-12 00:55:02 --> Output Class Initialized
INFO - 2019-07-12 00:55:02 --> Security Class Initialized
DEBUG - 2019-07-12 00:55:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 00:55:02 --> Input Class Initialized
INFO - 2019-07-12 00:55:02 --> Language Class Initialized
INFO - 2019-07-12 00:55:02 --> Language Class Initialized
INFO - 2019-07-12 00:55:02 --> Config Class Initialized
INFO - 2019-07-12 00:55:02 --> Loader Class Initialized
DEBUG - 2019-07-12 00:55:02 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 00:55:02 --> Helper loaded: url_helper
INFO - 2019-07-12 00:55:02 --> Helper loaded: inflector_helper
INFO - 2019-07-12 00:55:02 --> Helper loaded: string_helper
INFO - 2019-07-12 00:55:02 --> Helper loaded: array_helper
INFO - 2019-07-12 00:55:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 00:55:02 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 00:55:02 --> Database Driver Class Initialized
INFO - 2019-07-12 00:55:02 --> Controller Class Initialized
INFO - 2019-07-12 06:55:02 --> Helper loaded: language_helper
INFO - 2019-07-12 06:55:02 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 06:55:02 --> Model Class Initialized
INFO - 2019-07-12 06:55:02 --> Model Class Initialized
INFO - 2019-07-12 06:55:02 --> Model Class Initialized
INFO - 2019-07-12 06:55:02 --> Model Class Initialized
INFO - 2019-07-12 06:55:02 --> Final output sent to browser
DEBUG - 2019-07-12 06:55:02 --> Total execution time: 0.5093
INFO - 2019-07-12 00:55:03 --> Config Class Initialized
INFO - 2019-07-12 00:55:03 --> Hooks Class Initialized
DEBUG - 2019-07-12 00:55:03 --> UTF-8 Support Enabled
INFO - 2019-07-12 00:55:03 --> Utf8 Class Initialized
INFO - 2019-07-12 00:55:03 --> URI Class Initialized
INFO - 2019-07-12 00:55:03 --> Router Class Initialized
INFO - 2019-07-12 00:55:03 --> Output Class Initialized
INFO - 2019-07-12 00:55:03 --> Security Class Initialized
DEBUG - 2019-07-12 00:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 00:55:03 --> Input Class Initialized
INFO - 2019-07-12 00:55:03 --> Language Class Initialized
INFO - 2019-07-12 00:55:03 --> Language Class Initialized
INFO - 2019-07-12 00:55:03 --> Config Class Initialized
INFO - 2019-07-12 00:55:03 --> Loader Class Initialized
DEBUG - 2019-07-12 00:55:03 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 00:55:03 --> Helper loaded: url_helper
INFO - 2019-07-12 00:55:03 --> Helper loaded: inflector_helper
INFO - 2019-07-12 00:55:03 --> Helper loaded: string_helper
INFO - 2019-07-12 00:55:03 --> Helper loaded: array_helper
INFO - 2019-07-12 00:55:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 00:55:03 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 00:55:03 --> Database Driver Class Initialized
INFO - 2019-07-12 00:55:03 --> Controller Class Initialized
INFO - 2019-07-12 06:55:03 --> Helper loaded: language_helper
INFO - 2019-07-12 06:55:03 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 06:55:03 --> Model Class Initialized
INFO - 2019-07-12 06:55:03 --> Model Class Initialized
INFO - 2019-07-12 06:55:03 --> Model Class Initialized
INFO - 2019-07-12 06:55:03 --> Model Class Initialized
ERROR - 2019-07-12 06:55:03 --> Severity: Notice --> A non well formed numeric value encountered C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Owners.php 79
INFO - 2019-07-12 06:55:03 --> Final output sent to browser
DEBUG - 2019-07-12 06:55:03 --> Total execution time: 0.5035
INFO - 2019-07-12 00:55:41 --> Config Class Initialized
INFO - 2019-07-12 00:55:41 --> Hooks Class Initialized
DEBUG - 2019-07-12 00:55:41 --> UTF-8 Support Enabled
INFO - 2019-07-12 00:55:41 --> Utf8 Class Initialized
INFO - 2019-07-12 00:55:41 --> URI Class Initialized
INFO - 2019-07-12 00:55:41 --> Router Class Initialized
INFO - 2019-07-12 00:55:41 --> Output Class Initialized
INFO - 2019-07-12 00:55:41 --> Security Class Initialized
DEBUG - 2019-07-12 00:55:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 00:55:41 --> Input Class Initialized
INFO - 2019-07-12 00:55:41 --> Language Class Initialized
INFO - 2019-07-12 00:55:41 --> Language Class Initialized
INFO - 2019-07-12 00:55:42 --> Config Class Initialized
INFO - 2019-07-12 00:55:42 --> Loader Class Initialized
DEBUG - 2019-07-12 00:55:42 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 00:55:42 --> Helper loaded: url_helper
INFO - 2019-07-12 00:55:42 --> Helper loaded: inflector_helper
INFO - 2019-07-12 00:55:42 --> Helper loaded: string_helper
INFO - 2019-07-12 00:55:42 --> Helper loaded: array_helper
INFO - 2019-07-12 00:55:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 00:55:42 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 00:55:42 --> Database Driver Class Initialized
INFO - 2019-07-12 00:55:42 --> Controller Class Initialized
INFO - 2019-07-12 06:55:42 --> Helper loaded: language_helper
INFO - 2019-07-12 06:55:42 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 06:55:42 --> Model Class Initialized
INFO - 2019-07-12 06:55:42 --> Model Class Initialized
INFO - 2019-07-12 06:55:42 --> Model Class Initialized
INFO - 2019-07-12 06:55:42 --> Model Class Initialized
INFO - 2019-07-12 06:55:42 --> Final output sent to browser
DEBUG - 2019-07-12 06:55:42 --> Total execution time: 0.4729
INFO - 2019-07-12 00:55:48 --> Config Class Initialized
INFO - 2019-07-12 00:55:48 --> Hooks Class Initialized
DEBUG - 2019-07-12 00:55:48 --> UTF-8 Support Enabled
INFO - 2019-07-12 00:55:48 --> Utf8 Class Initialized
INFO - 2019-07-12 00:55:48 --> URI Class Initialized
INFO - 2019-07-12 00:55:48 --> Router Class Initialized
INFO - 2019-07-12 00:55:48 --> Output Class Initialized
INFO - 2019-07-12 00:55:48 --> Security Class Initialized
DEBUG - 2019-07-12 00:55:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 00:55:49 --> Input Class Initialized
INFO - 2019-07-12 00:55:49 --> Language Class Initialized
INFO - 2019-07-12 00:55:49 --> Language Class Initialized
INFO - 2019-07-12 00:55:49 --> Config Class Initialized
INFO - 2019-07-12 00:55:49 --> Loader Class Initialized
DEBUG - 2019-07-12 00:55:49 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 00:55:49 --> Helper loaded: url_helper
INFO - 2019-07-12 00:55:49 --> Helper loaded: inflector_helper
INFO - 2019-07-12 00:55:49 --> Helper loaded: string_helper
INFO - 2019-07-12 00:55:49 --> Helper loaded: array_helper
INFO - 2019-07-12 00:55:49 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 00:55:49 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 00:55:49 --> Database Driver Class Initialized
INFO - 2019-07-12 00:55:49 --> Controller Class Initialized
INFO - 2019-07-12 06:55:49 --> Helper loaded: language_helper
INFO - 2019-07-12 06:55:49 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 06:55:49 --> Model Class Initialized
INFO - 2019-07-12 06:55:49 --> Model Class Initialized
INFO - 2019-07-12 06:55:49 --> Model Class Initialized
INFO - 2019-07-12 06:55:49 --> Model Class Initialized
INFO - 2019-07-12 06:55:49 --> Final output sent to browser
DEBUG - 2019-07-12 06:55:49 --> Total execution time: 0.4765
INFO - 2019-07-12 00:55:49 --> Config Class Initialized
INFO - 2019-07-12 00:55:49 --> Hooks Class Initialized
DEBUG - 2019-07-12 00:55:49 --> UTF-8 Support Enabled
INFO - 2019-07-12 00:55:49 --> Utf8 Class Initialized
INFO - 2019-07-12 00:55:49 --> URI Class Initialized
INFO - 2019-07-12 00:55:49 --> Router Class Initialized
INFO - 2019-07-12 00:55:49 --> Output Class Initialized
INFO - 2019-07-12 00:55:49 --> Security Class Initialized
DEBUG - 2019-07-12 00:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 00:55:49 --> Input Class Initialized
INFO - 2019-07-12 00:55:49 --> Language Class Initialized
INFO - 2019-07-12 00:55:49 --> Language Class Initialized
INFO - 2019-07-12 00:55:49 --> Config Class Initialized
INFO - 2019-07-12 00:55:49 --> Loader Class Initialized
DEBUG - 2019-07-12 00:55:49 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 00:55:49 --> Helper loaded: url_helper
INFO - 2019-07-12 00:55:49 --> Helper loaded: inflector_helper
INFO - 2019-07-12 00:55:49 --> Helper loaded: string_helper
INFO - 2019-07-12 00:55:49 --> Helper loaded: array_helper
INFO - 2019-07-12 00:55:49 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 00:55:49 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 00:55:49 --> Database Driver Class Initialized
INFO - 2019-07-12 00:55:49 --> Controller Class Initialized
INFO - 2019-07-12 06:55:50 --> Helper loaded: language_helper
INFO - 2019-07-12 06:55:50 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 06:55:50 --> Model Class Initialized
INFO - 2019-07-12 06:55:50 --> Model Class Initialized
INFO - 2019-07-12 06:55:50 --> Model Class Initialized
INFO - 2019-07-12 06:55:50 --> Model Class Initialized
INFO - 2019-07-12 06:55:50 --> Final output sent to browser
DEBUG - 2019-07-12 06:55:50 --> Total execution time: 0.4869
INFO - 2019-07-12 00:56:07 --> Config Class Initialized
INFO - 2019-07-12 00:56:07 --> Hooks Class Initialized
DEBUG - 2019-07-12 00:56:07 --> UTF-8 Support Enabled
INFO - 2019-07-12 00:56:07 --> Utf8 Class Initialized
INFO - 2019-07-12 00:56:07 --> URI Class Initialized
INFO - 2019-07-12 00:56:07 --> Router Class Initialized
INFO - 2019-07-12 00:56:07 --> Output Class Initialized
INFO - 2019-07-12 00:56:07 --> Security Class Initialized
DEBUG - 2019-07-12 00:56:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 00:56:07 --> Input Class Initialized
INFO - 2019-07-12 00:56:07 --> Language Class Initialized
INFO - 2019-07-12 00:56:07 --> Language Class Initialized
INFO - 2019-07-12 00:56:07 --> Config Class Initialized
INFO - 2019-07-12 00:56:07 --> Loader Class Initialized
DEBUG - 2019-07-12 00:56:07 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 00:56:07 --> Helper loaded: url_helper
INFO - 2019-07-12 00:56:07 --> Helper loaded: inflector_helper
INFO - 2019-07-12 00:56:07 --> Helper loaded: string_helper
INFO - 2019-07-12 00:56:07 --> Helper loaded: array_helper
INFO - 2019-07-12 00:56:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 00:56:07 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 00:56:07 --> Database Driver Class Initialized
INFO - 2019-07-12 00:56:07 --> Controller Class Initialized
INFO - 2019-07-12 06:56:07 --> Helper loaded: language_helper
INFO - 2019-07-12 06:56:07 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 06:56:07 --> Model Class Initialized
INFO - 2019-07-12 06:56:07 --> Model Class Initialized
INFO - 2019-07-12 06:56:07 --> Model Class Initialized
INFO - 2019-07-12 06:56:07 --> Model Class Initialized
INFO - 2019-07-12 06:56:07 --> Final output sent to browser
DEBUG - 2019-07-12 06:56:07 --> Total execution time: 0.4891
INFO - 2019-07-12 00:56:19 --> Config Class Initialized
INFO - 2019-07-12 00:56:19 --> Hooks Class Initialized
DEBUG - 2019-07-12 00:56:19 --> UTF-8 Support Enabled
INFO - 2019-07-12 00:56:19 --> Utf8 Class Initialized
INFO - 2019-07-12 00:56:19 --> URI Class Initialized
INFO - 2019-07-12 00:56:19 --> Router Class Initialized
INFO - 2019-07-12 00:56:19 --> Output Class Initialized
INFO - 2019-07-12 00:56:19 --> Security Class Initialized
DEBUG - 2019-07-12 00:56:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 00:56:19 --> Input Class Initialized
INFO - 2019-07-12 00:56:19 --> Language Class Initialized
INFO - 2019-07-12 00:56:19 --> Language Class Initialized
INFO - 2019-07-12 00:56:19 --> Config Class Initialized
INFO - 2019-07-12 00:56:19 --> Loader Class Initialized
DEBUG - 2019-07-12 00:56:19 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 00:56:19 --> Helper loaded: url_helper
INFO - 2019-07-12 00:56:19 --> Helper loaded: inflector_helper
INFO - 2019-07-12 00:56:19 --> Helper loaded: string_helper
INFO - 2019-07-12 00:56:19 --> Helper loaded: array_helper
INFO - 2019-07-12 00:56:19 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 00:56:19 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 00:56:19 --> Database Driver Class Initialized
INFO - 2019-07-12 00:56:20 --> Controller Class Initialized
INFO - 2019-07-12 06:56:20 --> Helper loaded: language_helper
INFO - 2019-07-12 06:56:20 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 06:56:20 --> Model Class Initialized
INFO - 2019-07-12 06:56:20 --> Model Class Initialized
INFO - 2019-07-12 06:56:20 --> Model Class Initialized
INFO - 2019-07-12 06:56:20 --> Model Class Initialized
INFO - 2019-07-12 06:56:20 --> Final output sent to browser
DEBUG - 2019-07-12 06:56:20 --> Total execution time: 0.5044
INFO - 2019-07-12 00:57:34 --> Config Class Initialized
INFO - 2019-07-12 00:57:34 --> Hooks Class Initialized
DEBUG - 2019-07-12 00:57:34 --> UTF-8 Support Enabled
INFO - 2019-07-12 00:57:34 --> Utf8 Class Initialized
INFO - 2019-07-12 00:57:34 --> URI Class Initialized
INFO - 2019-07-12 00:57:34 --> Router Class Initialized
INFO - 2019-07-12 00:57:34 --> Output Class Initialized
INFO - 2019-07-12 00:57:34 --> Security Class Initialized
DEBUG - 2019-07-12 00:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 00:57:34 --> Input Class Initialized
INFO - 2019-07-12 00:57:34 --> Language Class Initialized
INFO - 2019-07-12 00:57:34 --> Language Class Initialized
INFO - 2019-07-12 00:57:35 --> Config Class Initialized
INFO - 2019-07-12 00:57:35 --> Loader Class Initialized
DEBUG - 2019-07-12 00:57:35 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 00:57:35 --> Helper loaded: url_helper
INFO - 2019-07-12 00:57:35 --> Helper loaded: inflector_helper
INFO - 2019-07-12 00:57:35 --> Helper loaded: string_helper
INFO - 2019-07-12 00:57:35 --> Helper loaded: array_helper
INFO - 2019-07-12 00:57:35 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 00:57:35 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 00:57:35 --> Database Driver Class Initialized
INFO - 2019-07-12 00:57:35 --> Controller Class Initialized
INFO - 2019-07-12 06:57:35 --> Helper loaded: language_helper
INFO - 2019-07-12 06:57:35 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 06:57:35 --> Model Class Initialized
INFO - 2019-07-12 06:57:35 --> Model Class Initialized
INFO - 2019-07-12 06:57:35 --> Model Class Initialized
INFO - 2019-07-12 06:57:35 --> Model Class Initialized
INFO - 2019-07-12 06:57:35 --> Final output sent to browser
DEBUG - 2019-07-12 06:57:35 --> Total execution time: 0.4891
INFO - 2019-07-12 00:58:51 --> Config Class Initialized
INFO - 2019-07-12 00:58:51 --> Hooks Class Initialized
DEBUG - 2019-07-12 00:58:51 --> UTF-8 Support Enabled
INFO - 2019-07-12 00:58:51 --> Utf8 Class Initialized
INFO - 2019-07-12 00:58:51 --> URI Class Initialized
INFO - 2019-07-12 00:58:51 --> Router Class Initialized
INFO - 2019-07-12 00:58:51 --> Output Class Initialized
INFO - 2019-07-12 00:58:51 --> Security Class Initialized
DEBUG - 2019-07-12 00:58:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 00:58:51 --> Input Class Initialized
INFO - 2019-07-12 00:58:51 --> Language Class Initialized
INFO - 2019-07-12 00:58:51 --> Language Class Initialized
INFO - 2019-07-12 00:58:51 --> Config Class Initialized
INFO - 2019-07-12 00:58:51 --> Loader Class Initialized
DEBUG - 2019-07-12 00:58:51 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 00:58:51 --> Helper loaded: url_helper
INFO - 2019-07-12 00:58:51 --> Helper loaded: inflector_helper
INFO - 2019-07-12 00:58:51 --> Helper loaded: string_helper
INFO - 2019-07-12 00:58:51 --> Helper loaded: array_helper
INFO - 2019-07-12 00:58:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 00:58:51 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 00:58:51 --> Database Driver Class Initialized
INFO - 2019-07-12 00:58:51 --> Controller Class Initialized
INFO - 2019-07-12 06:58:51 --> Helper loaded: language_helper
INFO - 2019-07-12 06:58:51 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 06:58:51 --> Model Class Initialized
INFO - 2019-07-12 06:58:51 --> Model Class Initialized
INFO - 2019-07-12 06:58:51 --> Model Class Initialized
INFO - 2019-07-12 06:58:51 --> Model Class Initialized
INFO - 2019-07-12 06:58:51 --> Final output sent to browser
DEBUG - 2019-07-12 06:58:51 --> Total execution time: 0.5151
INFO - 2019-07-12 01:01:44 --> Config Class Initialized
INFO - 2019-07-12 01:01:44 --> Hooks Class Initialized
DEBUG - 2019-07-12 01:01:44 --> UTF-8 Support Enabled
INFO - 2019-07-12 01:01:44 --> Utf8 Class Initialized
INFO - 2019-07-12 01:01:44 --> URI Class Initialized
INFO - 2019-07-12 01:01:44 --> Router Class Initialized
INFO - 2019-07-12 01:01:44 --> Output Class Initialized
INFO - 2019-07-12 01:01:44 --> Security Class Initialized
DEBUG - 2019-07-12 01:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 01:01:45 --> Input Class Initialized
INFO - 2019-07-12 01:01:45 --> Language Class Initialized
INFO - 2019-07-12 01:01:45 --> Language Class Initialized
INFO - 2019-07-12 01:01:45 --> Config Class Initialized
INFO - 2019-07-12 01:01:45 --> Loader Class Initialized
DEBUG - 2019-07-12 01:01:45 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 01:01:45 --> Helper loaded: url_helper
INFO - 2019-07-12 01:01:45 --> Helper loaded: inflector_helper
INFO - 2019-07-12 01:01:45 --> Helper loaded: string_helper
INFO - 2019-07-12 01:01:45 --> Helper loaded: array_helper
INFO - 2019-07-12 01:01:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 01:01:45 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 01:01:45 --> Database Driver Class Initialized
INFO - 2019-07-12 01:01:45 --> Controller Class Initialized
INFO - 2019-07-12 07:01:45 --> Helper loaded: language_helper
INFO - 2019-07-12 07:01:45 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 07:01:45 --> Model Class Initialized
INFO - 2019-07-12 07:01:45 --> Model Class Initialized
INFO - 2019-07-12 07:01:45 --> Model Class Initialized
INFO - 2019-07-12 07:01:45 --> Model Class Initialized
INFO - 2019-07-12 01:06:09 --> Config Class Initialized
INFO - 2019-07-12 01:06:09 --> Hooks Class Initialized
DEBUG - 2019-07-12 01:06:09 --> UTF-8 Support Enabled
INFO - 2019-07-12 01:06:09 --> Utf8 Class Initialized
INFO - 2019-07-12 01:06:09 --> URI Class Initialized
INFO - 2019-07-12 01:06:09 --> Router Class Initialized
INFO - 2019-07-12 01:06:09 --> Output Class Initialized
INFO - 2019-07-12 01:06:09 --> Security Class Initialized
DEBUG - 2019-07-12 01:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 01:06:09 --> Input Class Initialized
INFO - 2019-07-12 01:06:09 --> Language Class Initialized
INFO - 2019-07-12 01:06:09 --> Language Class Initialized
INFO - 2019-07-12 01:06:09 --> Config Class Initialized
INFO - 2019-07-12 01:06:09 --> Loader Class Initialized
DEBUG - 2019-07-12 01:06:09 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 01:06:09 --> Helper loaded: url_helper
INFO - 2019-07-12 01:06:09 --> Helper loaded: inflector_helper
INFO - 2019-07-12 01:06:09 --> Helper loaded: string_helper
INFO - 2019-07-12 01:06:09 --> Helper loaded: array_helper
INFO - 2019-07-12 01:06:09 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 01:06:09 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 01:06:09 --> Database Driver Class Initialized
INFO - 2019-07-12 01:06:09 --> Controller Class Initialized
INFO - 2019-07-12 07:06:09 --> Helper loaded: language_helper
INFO - 2019-07-12 07:06:09 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 07:06:09 --> Model Class Initialized
INFO - 2019-07-12 07:06:09 --> Model Class Initialized
INFO - 2019-07-12 07:06:09 --> Model Class Initialized
INFO - 2019-07-12 07:06:09 --> Model Class Initialized
INFO - 2019-07-12 01:06:22 --> Config Class Initialized
INFO - 2019-07-12 01:06:22 --> Hooks Class Initialized
DEBUG - 2019-07-12 01:06:22 --> UTF-8 Support Enabled
INFO - 2019-07-12 01:06:22 --> Utf8 Class Initialized
INFO - 2019-07-12 01:06:22 --> URI Class Initialized
INFO - 2019-07-12 01:06:22 --> Router Class Initialized
INFO - 2019-07-12 01:06:22 --> Output Class Initialized
INFO - 2019-07-12 01:06:22 --> Security Class Initialized
DEBUG - 2019-07-12 01:06:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 01:06:22 --> Input Class Initialized
INFO - 2019-07-12 01:06:22 --> Language Class Initialized
INFO - 2019-07-12 01:06:22 --> Language Class Initialized
INFO - 2019-07-12 01:06:22 --> Config Class Initialized
INFO - 2019-07-12 01:06:22 --> Loader Class Initialized
DEBUG - 2019-07-12 01:06:22 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 01:06:22 --> Helper loaded: url_helper
INFO - 2019-07-12 01:06:22 --> Helper loaded: inflector_helper
INFO - 2019-07-12 01:06:22 --> Helper loaded: string_helper
INFO - 2019-07-12 01:06:22 --> Helper loaded: array_helper
INFO - 2019-07-12 01:06:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 01:06:22 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 01:06:22 --> Database Driver Class Initialized
INFO - 2019-07-12 01:06:22 --> Controller Class Initialized
INFO - 2019-07-12 07:06:22 --> Helper loaded: language_helper
INFO - 2019-07-12 07:06:23 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 07:06:23 --> Model Class Initialized
INFO - 2019-07-12 07:06:23 --> Model Class Initialized
INFO - 2019-07-12 07:06:23 --> Model Class Initialized
INFO - 2019-07-12 07:06:23 --> Model Class Initialized
INFO - 2019-07-12 01:06:30 --> Config Class Initialized
INFO - 2019-07-12 01:06:30 --> Hooks Class Initialized
DEBUG - 2019-07-12 01:06:30 --> UTF-8 Support Enabled
INFO - 2019-07-12 01:06:30 --> Utf8 Class Initialized
INFO - 2019-07-12 01:06:30 --> URI Class Initialized
INFO - 2019-07-12 01:06:30 --> Router Class Initialized
INFO - 2019-07-12 01:06:30 --> Output Class Initialized
INFO - 2019-07-12 01:06:30 --> Security Class Initialized
DEBUG - 2019-07-12 01:06:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 01:06:30 --> Input Class Initialized
INFO - 2019-07-12 01:06:31 --> Language Class Initialized
INFO - 2019-07-12 01:06:31 --> Language Class Initialized
INFO - 2019-07-12 01:06:31 --> Config Class Initialized
INFO - 2019-07-12 01:06:31 --> Loader Class Initialized
DEBUG - 2019-07-12 01:06:31 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 01:06:31 --> Helper loaded: url_helper
INFO - 2019-07-12 01:06:31 --> Helper loaded: inflector_helper
INFO - 2019-07-12 01:06:31 --> Helper loaded: string_helper
INFO - 2019-07-12 01:06:31 --> Helper loaded: array_helper
INFO - 2019-07-12 01:06:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 01:06:31 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 01:06:31 --> Database Driver Class Initialized
INFO - 2019-07-12 01:06:31 --> Controller Class Initialized
INFO - 2019-07-12 07:06:31 --> Helper loaded: language_helper
INFO - 2019-07-12 07:06:31 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 07:06:31 --> Model Class Initialized
INFO - 2019-07-12 07:06:31 --> Model Class Initialized
INFO - 2019-07-12 07:06:31 --> Model Class Initialized
INFO - 2019-07-12 07:06:31 --> Model Class Initialized
INFO - 2019-07-12 01:06:32 --> Config Class Initialized
INFO - 2019-07-12 01:06:32 --> Hooks Class Initialized
DEBUG - 2019-07-12 01:06:32 --> UTF-8 Support Enabled
INFO - 2019-07-12 01:06:32 --> Utf8 Class Initialized
INFO - 2019-07-12 01:06:32 --> URI Class Initialized
INFO - 2019-07-12 01:06:32 --> Router Class Initialized
INFO - 2019-07-12 01:06:32 --> Output Class Initialized
INFO - 2019-07-12 01:06:32 --> Security Class Initialized
DEBUG - 2019-07-12 01:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 01:06:32 --> Input Class Initialized
INFO - 2019-07-12 01:06:32 --> Language Class Initialized
INFO - 2019-07-12 01:06:32 --> Language Class Initialized
INFO - 2019-07-12 01:06:32 --> Config Class Initialized
INFO - 2019-07-12 01:06:32 --> Loader Class Initialized
DEBUG - 2019-07-12 01:06:32 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 01:06:32 --> Helper loaded: url_helper
INFO - 2019-07-12 01:06:32 --> Helper loaded: inflector_helper
INFO - 2019-07-12 01:06:32 --> Helper loaded: string_helper
INFO - 2019-07-12 01:06:32 --> Helper loaded: array_helper
INFO - 2019-07-12 01:06:32 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 01:06:32 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 01:06:32 --> Database Driver Class Initialized
INFO - 2019-07-12 01:06:32 --> Controller Class Initialized
INFO - 2019-07-12 07:06:32 --> Helper loaded: language_helper
INFO - 2019-07-12 07:06:32 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 07:06:32 --> Model Class Initialized
INFO - 2019-07-12 07:06:32 --> Model Class Initialized
INFO - 2019-07-12 07:06:32 --> Model Class Initialized
INFO - 2019-07-12 07:06:32 --> Model Class Initialized
INFO - 2019-07-12 01:06:33 --> Config Class Initialized
INFO - 2019-07-12 01:06:33 --> Hooks Class Initialized
DEBUG - 2019-07-12 01:06:33 --> UTF-8 Support Enabled
INFO - 2019-07-12 01:06:33 --> Utf8 Class Initialized
INFO - 2019-07-12 01:06:33 --> URI Class Initialized
INFO - 2019-07-12 01:06:33 --> Router Class Initialized
INFO - 2019-07-12 01:06:33 --> Output Class Initialized
INFO - 2019-07-12 01:06:33 --> Security Class Initialized
DEBUG - 2019-07-12 01:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 01:06:33 --> Input Class Initialized
INFO - 2019-07-12 01:06:33 --> Language Class Initialized
INFO - 2019-07-12 01:06:33 --> Language Class Initialized
INFO - 2019-07-12 01:06:33 --> Config Class Initialized
INFO - 2019-07-12 01:06:33 --> Loader Class Initialized
DEBUG - 2019-07-12 01:06:33 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 01:06:33 --> Helper loaded: url_helper
INFO - 2019-07-12 01:06:33 --> Helper loaded: inflector_helper
INFO - 2019-07-12 01:06:33 --> Helper loaded: string_helper
INFO - 2019-07-12 01:06:33 --> Helper loaded: array_helper
INFO - 2019-07-12 01:06:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 01:06:33 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 01:06:33 --> Database Driver Class Initialized
INFO - 2019-07-12 01:06:33 --> Controller Class Initialized
INFO - 2019-07-12 07:06:33 --> Helper loaded: language_helper
INFO - 2019-07-12 07:06:33 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 07:06:33 --> Model Class Initialized
INFO - 2019-07-12 07:06:33 --> Model Class Initialized
INFO - 2019-07-12 07:06:33 --> Model Class Initialized
INFO - 2019-07-12 07:06:33 --> Model Class Initialized
INFO - 2019-07-12 01:06:34 --> Config Class Initialized
INFO - 2019-07-12 01:06:34 --> Hooks Class Initialized
DEBUG - 2019-07-12 01:06:34 --> UTF-8 Support Enabled
INFO - 2019-07-12 01:06:34 --> Utf8 Class Initialized
INFO - 2019-07-12 01:06:34 --> URI Class Initialized
INFO - 2019-07-12 01:06:34 --> Router Class Initialized
INFO - 2019-07-12 01:06:34 --> Output Class Initialized
INFO - 2019-07-12 01:06:34 --> Security Class Initialized
DEBUG - 2019-07-12 01:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 01:06:34 --> Input Class Initialized
INFO - 2019-07-12 01:06:34 --> Language Class Initialized
INFO - 2019-07-12 01:06:34 --> Language Class Initialized
INFO - 2019-07-12 01:06:34 --> Config Class Initialized
INFO - 2019-07-12 01:06:34 --> Loader Class Initialized
DEBUG - 2019-07-12 01:06:34 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 01:06:34 --> Helper loaded: url_helper
INFO - 2019-07-12 01:06:34 --> Helper loaded: inflector_helper
INFO - 2019-07-12 01:06:34 --> Helper loaded: string_helper
INFO - 2019-07-12 01:06:34 --> Helper loaded: array_helper
INFO - 2019-07-12 01:06:34 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 01:06:34 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 01:06:34 --> Database Driver Class Initialized
INFO - 2019-07-12 01:06:34 --> Controller Class Initialized
INFO - 2019-07-12 07:06:34 --> Helper loaded: language_helper
INFO - 2019-07-12 07:06:34 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 07:06:34 --> Model Class Initialized
INFO - 2019-07-12 07:06:34 --> Model Class Initialized
INFO - 2019-07-12 07:06:34 --> Model Class Initialized
INFO - 2019-07-12 07:06:34 --> Model Class Initialized
INFO - 2019-07-12 01:08:08 --> Config Class Initialized
INFO - 2019-07-12 01:08:08 --> Hooks Class Initialized
DEBUG - 2019-07-12 01:08:08 --> UTF-8 Support Enabled
INFO - 2019-07-12 01:08:08 --> Utf8 Class Initialized
INFO - 2019-07-12 01:08:08 --> URI Class Initialized
INFO - 2019-07-12 01:08:08 --> Router Class Initialized
INFO - 2019-07-12 01:08:08 --> Output Class Initialized
INFO - 2019-07-12 01:08:08 --> Security Class Initialized
DEBUG - 2019-07-12 01:08:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 01:08:08 --> Input Class Initialized
INFO - 2019-07-12 01:08:08 --> Language Class Initialized
INFO - 2019-07-12 01:08:08 --> Language Class Initialized
INFO - 2019-07-12 01:08:08 --> Config Class Initialized
INFO - 2019-07-12 01:08:08 --> Loader Class Initialized
DEBUG - 2019-07-12 01:08:08 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 01:08:08 --> Helper loaded: url_helper
INFO - 2019-07-12 01:08:08 --> Helper loaded: inflector_helper
INFO - 2019-07-12 01:08:08 --> Helper loaded: string_helper
INFO - 2019-07-12 01:08:08 --> Helper loaded: array_helper
INFO - 2019-07-12 01:08:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 01:08:08 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 01:08:08 --> Database Driver Class Initialized
INFO - 2019-07-12 01:08:08 --> Controller Class Initialized
INFO - 2019-07-12 07:08:08 --> Helper loaded: language_helper
INFO - 2019-07-12 07:08:08 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 07:08:08 --> Model Class Initialized
INFO - 2019-07-12 07:08:08 --> Model Class Initialized
INFO - 2019-07-12 07:08:08 --> Model Class Initialized
INFO - 2019-07-12 07:08:08 --> Model Class Initialized
INFO - 2019-07-12 01:08:26 --> Config Class Initialized
INFO - 2019-07-12 01:08:26 --> Hooks Class Initialized
DEBUG - 2019-07-12 01:08:26 --> UTF-8 Support Enabled
INFO - 2019-07-12 01:08:26 --> Utf8 Class Initialized
INFO - 2019-07-12 01:08:26 --> URI Class Initialized
INFO - 2019-07-12 01:08:26 --> Router Class Initialized
INFO - 2019-07-12 01:08:26 --> Output Class Initialized
INFO - 2019-07-12 01:08:26 --> Security Class Initialized
DEBUG - 2019-07-12 01:08:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 01:08:26 --> Input Class Initialized
INFO - 2019-07-12 01:08:26 --> Language Class Initialized
INFO - 2019-07-12 01:08:26 --> Language Class Initialized
INFO - 2019-07-12 01:08:26 --> Config Class Initialized
INFO - 2019-07-12 01:08:26 --> Loader Class Initialized
DEBUG - 2019-07-12 01:08:26 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 01:08:26 --> Helper loaded: url_helper
INFO - 2019-07-12 01:08:26 --> Helper loaded: inflector_helper
INFO - 2019-07-12 01:08:26 --> Helper loaded: string_helper
INFO - 2019-07-12 01:08:26 --> Helper loaded: array_helper
INFO - 2019-07-12 01:08:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 01:08:26 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 01:08:26 --> Database Driver Class Initialized
INFO - 2019-07-12 01:08:26 --> Controller Class Initialized
INFO - 2019-07-12 07:08:26 --> Helper loaded: language_helper
INFO - 2019-07-12 07:08:26 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 07:08:26 --> Model Class Initialized
INFO - 2019-07-12 07:08:26 --> Model Class Initialized
INFO - 2019-07-12 07:08:26 --> Model Class Initialized
INFO - 2019-07-12 07:08:26 --> Model Class Initialized
INFO - 2019-07-12 01:08:48 --> Config Class Initialized
INFO - 2019-07-12 01:08:48 --> Hooks Class Initialized
DEBUG - 2019-07-12 01:08:48 --> UTF-8 Support Enabled
INFO - 2019-07-12 01:08:48 --> Utf8 Class Initialized
INFO - 2019-07-12 01:08:48 --> URI Class Initialized
INFO - 2019-07-12 01:08:48 --> Router Class Initialized
INFO - 2019-07-12 01:08:48 --> Output Class Initialized
INFO - 2019-07-12 01:08:48 --> Security Class Initialized
DEBUG - 2019-07-12 01:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 01:08:48 --> Input Class Initialized
INFO - 2019-07-12 01:08:48 --> Language Class Initialized
INFO - 2019-07-12 01:08:48 --> Language Class Initialized
INFO - 2019-07-12 01:08:48 --> Config Class Initialized
INFO - 2019-07-12 01:08:48 --> Loader Class Initialized
DEBUG - 2019-07-12 01:08:48 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 01:08:48 --> Helper loaded: url_helper
INFO - 2019-07-12 01:08:48 --> Helper loaded: inflector_helper
INFO - 2019-07-12 01:08:48 --> Helper loaded: string_helper
INFO - 2019-07-12 01:08:48 --> Helper loaded: array_helper
INFO - 2019-07-12 01:08:48 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 01:08:48 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 01:08:48 --> Database Driver Class Initialized
INFO - 2019-07-12 01:08:48 --> Controller Class Initialized
INFO - 2019-07-12 07:08:48 --> Helper loaded: language_helper
INFO - 2019-07-12 07:08:48 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 07:08:48 --> Model Class Initialized
INFO - 2019-07-12 07:08:48 --> Model Class Initialized
INFO - 2019-07-12 07:08:48 --> Model Class Initialized
INFO - 2019-07-12 07:08:48 --> Model Class Initialized
INFO - 2019-07-12 01:09:22 --> Config Class Initialized
INFO - 2019-07-12 01:09:22 --> Hooks Class Initialized
DEBUG - 2019-07-12 01:09:22 --> UTF-8 Support Enabled
INFO - 2019-07-12 01:09:22 --> Utf8 Class Initialized
INFO - 2019-07-12 01:09:22 --> URI Class Initialized
INFO - 2019-07-12 01:09:22 --> Router Class Initialized
INFO - 2019-07-12 01:09:22 --> Output Class Initialized
INFO - 2019-07-12 01:09:22 --> Security Class Initialized
DEBUG - 2019-07-12 01:09:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 01:09:22 --> Input Class Initialized
INFO - 2019-07-12 01:09:22 --> Language Class Initialized
INFO - 2019-07-12 01:09:22 --> Language Class Initialized
INFO - 2019-07-12 01:09:22 --> Config Class Initialized
INFO - 2019-07-12 01:09:22 --> Loader Class Initialized
DEBUG - 2019-07-12 01:09:22 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 01:09:22 --> Helper loaded: url_helper
INFO - 2019-07-12 01:09:22 --> Helper loaded: inflector_helper
INFO - 2019-07-12 01:09:22 --> Helper loaded: string_helper
INFO - 2019-07-12 01:09:22 --> Helper loaded: array_helper
INFO - 2019-07-12 01:09:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 01:09:22 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 01:09:22 --> Database Driver Class Initialized
INFO - 2019-07-12 01:09:22 --> Controller Class Initialized
INFO - 2019-07-12 07:09:22 --> Helper loaded: language_helper
INFO - 2019-07-12 07:09:22 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 07:09:22 --> Model Class Initialized
INFO - 2019-07-12 07:09:22 --> Model Class Initialized
INFO - 2019-07-12 07:09:22 --> Model Class Initialized
INFO - 2019-07-12 07:09:22 --> Model Class Initialized
INFO - 2019-07-12 01:09:47 --> Config Class Initialized
INFO - 2019-07-12 01:09:47 --> Hooks Class Initialized
DEBUG - 2019-07-12 01:09:47 --> UTF-8 Support Enabled
INFO - 2019-07-12 01:09:47 --> Utf8 Class Initialized
INFO - 2019-07-12 01:09:47 --> URI Class Initialized
INFO - 2019-07-12 01:09:47 --> Router Class Initialized
INFO - 2019-07-12 01:09:47 --> Output Class Initialized
INFO - 2019-07-12 01:09:47 --> Security Class Initialized
DEBUG - 2019-07-12 01:09:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 01:09:47 --> Input Class Initialized
INFO - 2019-07-12 01:09:47 --> Language Class Initialized
INFO - 2019-07-12 01:09:47 --> Language Class Initialized
INFO - 2019-07-12 01:09:47 --> Config Class Initialized
INFO - 2019-07-12 01:09:47 --> Loader Class Initialized
DEBUG - 2019-07-12 01:09:47 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 01:09:47 --> Helper loaded: url_helper
INFO - 2019-07-12 01:09:47 --> Helper loaded: inflector_helper
INFO - 2019-07-12 01:09:47 --> Helper loaded: string_helper
INFO - 2019-07-12 01:09:47 --> Helper loaded: array_helper
INFO - 2019-07-12 01:09:47 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 01:09:47 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 01:09:47 --> Database Driver Class Initialized
INFO - 2019-07-12 01:09:47 --> Controller Class Initialized
INFO - 2019-07-12 07:09:47 --> Helper loaded: language_helper
INFO - 2019-07-12 07:09:47 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 07:09:47 --> Model Class Initialized
INFO - 2019-07-12 07:09:47 --> Model Class Initialized
INFO - 2019-07-12 07:09:47 --> Model Class Initialized
INFO - 2019-07-12 07:09:47 --> Model Class Initialized
INFO - 2019-07-12 01:09:49 --> Config Class Initialized
INFO - 2019-07-12 01:09:49 --> Hooks Class Initialized
DEBUG - 2019-07-12 01:09:49 --> UTF-8 Support Enabled
INFO - 2019-07-12 01:09:49 --> Utf8 Class Initialized
INFO - 2019-07-12 01:09:49 --> URI Class Initialized
INFO - 2019-07-12 01:09:50 --> Router Class Initialized
INFO - 2019-07-12 01:09:50 --> Output Class Initialized
INFO - 2019-07-12 01:09:50 --> Security Class Initialized
DEBUG - 2019-07-12 01:09:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 01:09:50 --> Input Class Initialized
INFO - 2019-07-12 01:09:50 --> Language Class Initialized
INFO - 2019-07-12 01:09:50 --> Language Class Initialized
INFO - 2019-07-12 01:09:50 --> Config Class Initialized
INFO - 2019-07-12 01:09:50 --> Loader Class Initialized
DEBUG - 2019-07-12 01:09:50 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 01:09:50 --> Helper loaded: url_helper
INFO - 2019-07-12 01:09:50 --> Helper loaded: inflector_helper
INFO - 2019-07-12 01:09:50 --> Helper loaded: string_helper
INFO - 2019-07-12 01:09:50 --> Helper loaded: array_helper
INFO - 2019-07-12 01:09:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 01:09:50 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 01:09:50 --> Database Driver Class Initialized
INFO - 2019-07-12 01:09:50 --> Controller Class Initialized
INFO - 2019-07-12 07:09:50 --> Helper loaded: language_helper
INFO - 2019-07-12 07:09:50 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 07:09:50 --> Model Class Initialized
INFO - 2019-07-12 07:09:50 --> Model Class Initialized
INFO - 2019-07-12 07:09:50 --> Model Class Initialized
INFO - 2019-07-12 07:09:50 --> Model Class Initialized
INFO - 2019-07-12 01:10:59 --> Config Class Initialized
INFO - 2019-07-12 01:10:59 --> Hooks Class Initialized
DEBUG - 2019-07-12 01:10:59 --> UTF-8 Support Enabled
INFO - 2019-07-12 01:10:59 --> Utf8 Class Initialized
INFO - 2019-07-12 01:10:59 --> URI Class Initialized
INFO - 2019-07-12 01:10:59 --> Router Class Initialized
INFO - 2019-07-12 01:10:59 --> Output Class Initialized
INFO - 2019-07-12 01:10:59 --> Security Class Initialized
DEBUG - 2019-07-12 01:10:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 01:10:59 --> Input Class Initialized
INFO - 2019-07-12 01:10:59 --> Language Class Initialized
ERROR - 2019-07-12 01:10:59 --> Severity: Parsing Error --> syntax error, unexpected 'if' (T_IF) C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Owners.php 33
INFO - 2019-07-12 01:11:07 --> Config Class Initialized
INFO - 2019-07-12 01:11:07 --> Hooks Class Initialized
DEBUG - 2019-07-12 01:11:07 --> UTF-8 Support Enabled
INFO - 2019-07-12 01:11:07 --> Utf8 Class Initialized
INFO - 2019-07-12 01:11:07 --> URI Class Initialized
INFO - 2019-07-12 01:11:07 --> Router Class Initialized
INFO - 2019-07-12 01:11:07 --> Output Class Initialized
INFO - 2019-07-12 01:11:07 --> Security Class Initialized
DEBUG - 2019-07-12 01:11:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 01:11:07 --> Input Class Initialized
INFO - 2019-07-12 01:11:07 --> Language Class Initialized
INFO - 2019-07-12 01:11:07 --> Language Class Initialized
INFO - 2019-07-12 01:11:07 --> Config Class Initialized
INFO - 2019-07-12 01:11:07 --> Loader Class Initialized
DEBUG - 2019-07-12 01:11:07 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 01:11:07 --> Helper loaded: url_helper
INFO - 2019-07-12 01:11:07 --> Helper loaded: inflector_helper
INFO - 2019-07-12 01:11:07 --> Helper loaded: string_helper
INFO - 2019-07-12 01:11:07 --> Helper loaded: array_helper
INFO - 2019-07-12 01:11:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 01:11:07 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 01:11:07 --> Database Driver Class Initialized
INFO - 2019-07-12 01:11:08 --> Controller Class Initialized
INFO - 2019-07-12 07:11:08 --> Helper loaded: language_helper
INFO - 2019-07-12 07:11:08 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 07:11:08 --> Model Class Initialized
INFO - 2019-07-12 07:11:08 --> Model Class Initialized
INFO - 2019-07-12 07:11:08 --> Model Class Initialized
INFO - 2019-07-12 07:11:08 --> Model Class Initialized
ERROR - 2019-07-12 07:11:08 --> Severity: Notice --> Undefined variable: subscription_end C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Owners.php 39
INFO - 2019-07-12 01:11:40 --> Config Class Initialized
INFO - 2019-07-12 01:11:40 --> Hooks Class Initialized
DEBUG - 2019-07-12 01:11:40 --> UTF-8 Support Enabled
INFO - 2019-07-12 01:11:40 --> Utf8 Class Initialized
INFO - 2019-07-12 01:11:41 --> URI Class Initialized
INFO - 2019-07-12 01:11:41 --> Router Class Initialized
INFO - 2019-07-12 01:11:41 --> Output Class Initialized
INFO - 2019-07-12 01:11:41 --> Security Class Initialized
DEBUG - 2019-07-12 01:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 01:11:41 --> Input Class Initialized
INFO - 2019-07-12 01:11:41 --> Language Class Initialized
INFO - 2019-07-12 01:11:41 --> Language Class Initialized
INFO - 2019-07-12 01:11:41 --> Config Class Initialized
INFO - 2019-07-12 01:11:41 --> Loader Class Initialized
DEBUG - 2019-07-12 01:11:41 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 01:11:41 --> Helper loaded: url_helper
INFO - 2019-07-12 01:11:41 --> Helper loaded: inflector_helper
INFO - 2019-07-12 01:11:41 --> Helper loaded: string_helper
INFO - 2019-07-12 01:11:41 --> Helper loaded: array_helper
INFO - 2019-07-12 01:11:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 01:11:41 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 01:11:41 --> Database Driver Class Initialized
INFO - 2019-07-12 01:11:41 --> Controller Class Initialized
INFO - 2019-07-12 07:11:41 --> Helper loaded: language_helper
INFO - 2019-07-12 07:11:41 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 07:11:41 --> Model Class Initialized
INFO - 2019-07-12 07:11:41 --> Model Class Initialized
INFO - 2019-07-12 07:11:41 --> Model Class Initialized
INFO - 2019-07-12 07:11:41 --> Model Class Initialized
INFO - 2019-07-12 07:11:41 --> Final output sent to browser
DEBUG - 2019-07-12 07:11:41 --> Total execution time: 0.4938
INFO - 2019-07-12 01:12:24 --> Config Class Initialized
INFO - 2019-07-12 01:12:24 --> Hooks Class Initialized
DEBUG - 2019-07-12 01:12:24 --> UTF-8 Support Enabled
INFO - 2019-07-12 01:12:24 --> Utf8 Class Initialized
INFO - 2019-07-12 01:12:24 --> URI Class Initialized
INFO - 2019-07-12 01:12:24 --> Router Class Initialized
INFO - 2019-07-12 01:12:24 --> Output Class Initialized
INFO - 2019-07-12 01:12:24 --> Security Class Initialized
DEBUG - 2019-07-12 01:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 01:12:24 --> Input Class Initialized
INFO - 2019-07-12 01:12:24 --> Language Class Initialized
INFO - 2019-07-12 01:12:24 --> Language Class Initialized
INFO - 2019-07-12 01:12:24 --> Config Class Initialized
INFO - 2019-07-12 01:12:24 --> Loader Class Initialized
DEBUG - 2019-07-12 01:12:24 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 01:12:24 --> Helper loaded: url_helper
INFO - 2019-07-12 01:12:25 --> Helper loaded: inflector_helper
INFO - 2019-07-12 01:12:25 --> Helper loaded: string_helper
INFO - 2019-07-12 01:12:25 --> Helper loaded: array_helper
INFO - 2019-07-12 01:12:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 01:12:25 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 01:12:25 --> Database Driver Class Initialized
INFO - 2019-07-12 01:12:25 --> Controller Class Initialized
INFO - 2019-07-12 07:12:25 --> Helper loaded: language_helper
INFO - 2019-07-12 07:12:25 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 07:12:25 --> Model Class Initialized
INFO - 2019-07-12 07:12:25 --> Model Class Initialized
INFO - 2019-07-12 07:12:25 --> Model Class Initialized
INFO - 2019-07-12 07:12:25 --> Model Class Initialized
INFO - 2019-07-12 07:12:25 --> Final output sent to browser
DEBUG - 2019-07-12 07:12:25 --> Total execution time: 0.4821
INFO - 2019-07-12 01:12:27 --> Config Class Initialized
INFO - 2019-07-12 01:12:27 --> Hooks Class Initialized
DEBUG - 2019-07-12 01:12:27 --> UTF-8 Support Enabled
INFO - 2019-07-12 01:12:27 --> Utf8 Class Initialized
INFO - 2019-07-12 01:12:27 --> URI Class Initialized
INFO - 2019-07-12 01:12:27 --> Router Class Initialized
INFO - 2019-07-12 01:12:27 --> Output Class Initialized
INFO - 2019-07-12 01:12:27 --> Security Class Initialized
DEBUG - 2019-07-12 01:12:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 01:12:27 --> Input Class Initialized
INFO - 2019-07-12 01:12:27 --> Language Class Initialized
INFO - 2019-07-12 01:12:27 --> Language Class Initialized
INFO - 2019-07-12 01:12:27 --> Config Class Initialized
INFO - 2019-07-12 01:12:27 --> Loader Class Initialized
DEBUG - 2019-07-12 01:12:27 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 01:12:27 --> Helper loaded: url_helper
INFO - 2019-07-12 01:12:27 --> Helper loaded: inflector_helper
INFO - 2019-07-12 01:12:27 --> Helper loaded: string_helper
INFO - 2019-07-12 01:12:27 --> Helper loaded: array_helper
INFO - 2019-07-12 01:12:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 01:12:27 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 01:12:27 --> Database Driver Class Initialized
INFO - 2019-07-12 01:12:27 --> Controller Class Initialized
INFO - 2019-07-12 07:12:27 --> Helper loaded: language_helper
INFO - 2019-07-12 07:12:27 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 07:12:27 --> Model Class Initialized
INFO - 2019-07-12 07:12:27 --> Model Class Initialized
INFO - 2019-07-12 07:12:27 --> Model Class Initialized
INFO - 2019-07-12 07:12:27 --> Model Class Initialized
INFO - 2019-07-12 07:12:27 --> Final output sent to browser
DEBUG - 2019-07-12 07:12:27 --> Total execution time: 0.4998
INFO - 2019-07-12 01:12:58 --> Config Class Initialized
INFO - 2019-07-12 01:12:58 --> Hooks Class Initialized
DEBUG - 2019-07-12 01:12:58 --> UTF-8 Support Enabled
INFO - 2019-07-12 01:12:58 --> Utf8 Class Initialized
INFO - 2019-07-12 01:12:58 --> URI Class Initialized
INFO - 2019-07-12 01:12:58 --> Router Class Initialized
INFO - 2019-07-12 01:12:58 --> Output Class Initialized
INFO - 2019-07-12 01:12:58 --> Security Class Initialized
DEBUG - 2019-07-12 01:12:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 01:12:58 --> Input Class Initialized
INFO - 2019-07-12 01:12:58 --> Language Class Initialized
INFO - 2019-07-12 01:12:58 --> Language Class Initialized
INFO - 2019-07-12 01:12:58 --> Config Class Initialized
INFO - 2019-07-12 01:12:59 --> Loader Class Initialized
DEBUG - 2019-07-12 01:12:59 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 01:12:59 --> Helper loaded: url_helper
INFO - 2019-07-12 01:12:59 --> Helper loaded: inflector_helper
INFO - 2019-07-12 01:12:59 --> Helper loaded: string_helper
INFO - 2019-07-12 01:12:59 --> Helper loaded: array_helper
INFO - 2019-07-12 01:12:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 01:12:59 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 01:12:59 --> Database Driver Class Initialized
INFO - 2019-07-12 01:12:59 --> Controller Class Initialized
INFO - 2019-07-12 07:12:59 --> Helper loaded: language_helper
INFO - 2019-07-12 07:12:59 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 07:12:59 --> Model Class Initialized
INFO - 2019-07-12 07:12:59 --> Model Class Initialized
INFO - 2019-07-12 07:12:59 --> Model Class Initialized
INFO - 2019-07-12 07:12:59 --> Model Class Initialized
INFO - 2019-07-12 07:12:59 --> Final output sent to browser
DEBUG - 2019-07-12 07:12:59 --> Total execution time: 0.4927
INFO - 2019-07-12 01:13:08 --> Config Class Initialized
INFO - 2019-07-12 01:13:08 --> Hooks Class Initialized
DEBUG - 2019-07-12 01:13:08 --> UTF-8 Support Enabled
INFO - 2019-07-12 01:13:08 --> Utf8 Class Initialized
INFO - 2019-07-12 01:13:08 --> URI Class Initialized
INFO - 2019-07-12 01:13:08 --> Router Class Initialized
INFO - 2019-07-12 01:13:08 --> Output Class Initialized
INFO - 2019-07-12 01:13:08 --> Security Class Initialized
DEBUG - 2019-07-12 01:13:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 01:13:08 --> Input Class Initialized
INFO - 2019-07-12 01:13:08 --> Language Class Initialized
INFO - 2019-07-12 01:13:08 --> Language Class Initialized
INFO - 2019-07-12 01:13:08 --> Config Class Initialized
INFO - 2019-07-12 01:13:08 --> Loader Class Initialized
DEBUG - 2019-07-12 01:13:08 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 01:13:08 --> Helper loaded: url_helper
INFO - 2019-07-12 01:13:08 --> Helper loaded: inflector_helper
INFO - 2019-07-12 01:13:08 --> Helper loaded: string_helper
INFO - 2019-07-12 01:13:08 --> Helper loaded: array_helper
INFO - 2019-07-12 01:13:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 01:13:08 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 01:13:08 --> Database Driver Class Initialized
INFO - 2019-07-12 01:13:08 --> Controller Class Initialized
INFO - 2019-07-12 07:13:08 --> Helper loaded: language_helper
INFO - 2019-07-12 07:13:08 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 07:13:08 --> Model Class Initialized
INFO - 2019-07-12 07:13:08 --> Model Class Initialized
INFO - 2019-07-12 07:13:08 --> Model Class Initialized
INFO - 2019-07-12 07:13:08 --> Model Class Initialized
INFO - 2019-07-12 01:13:31 --> Config Class Initialized
INFO - 2019-07-12 01:13:31 --> Hooks Class Initialized
DEBUG - 2019-07-12 01:13:31 --> UTF-8 Support Enabled
INFO - 2019-07-12 01:13:31 --> Utf8 Class Initialized
INFO - 2019-07-12 01:13:31 --> URI Class Initialized
INFO - 2019-07-12 01:13:31 --> Router Class Initialized
INFO - 2019-07-12 01:13:31 --> Output Class Initialized
INFO - 2019-07-12 01:13:31 --> Security Class Initialized
DEBUG - 2019-07-12 01:13:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 01:13:31 --> Input Class Initialized
INFO - 2019-07-12 01:13:31 --> Language Class Initialized
INFO - 2019-07-12 01:13:31 --> Language Class Initialized
INFO - 2019-07-12 01:13:31 --> Config Class Initialized
INFO - 2019-07-12 01:13:31 --> Loader Class Initialized
DEBUG - 2019-07-12 01:13:31 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 01:13:31 --> Helper loaded: url_helper
INFO - 2019-07-12 01:13:31 --> Helper loaded: inflector_helper
INFO - 2019-07-12 01:13:31 --> Helper loaded: string_helper
INFO - 2019-07-12 01:13:31 --> Helper loaded: array_helper
INFO - 2019-07-12 01:13:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 01:13:31 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 01:13:31 --> Database Driver Class Initialized
INFO - 2019-07-12 01:13:31 --> Controller Class Initialized
INFO - 2019-07-12 07:13:31 --> Helper loaded: language_helper
INFO - 2019-07-12 07:13:31 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 07:13:31 --> Model Class Initialized
INFO - 2019-07-12 07:13:31 --> Model Class Initialized
INFO - 2019-07-12 07:13:31 --> Model Class Initialized
INFO - 2019-07-12 07:13:31 --> Model Class Initialized
INFO - 2019-07-12 07:13:31 --> Final output sent to browser
DEBUG - 2019-07-12 07:13:31 --> Total execution time: 0.4904
INFO - 2019-07-12 01:13:45 --> Config Class Initialized
INFO - 2019-07-12 01:13:45 --> Hooks Class Initialized
DEBUG - 2019-07-12 01:13:45 --> UTF-8 Support Enabled
INFO - 2019-07-12 01:13:45 --> Utf8 Class Initialized
INFO - 2019-07-12 01:13:45 --> URI Class Initialized
INFO - 2019-07-12 01:13:45 --> Router Class Initialized
INFO - 2019-07-12 01:13:45 --> Output Class Initialized
INFO - 2019-07-12 01:13:45 --> Security Class Initialized
DEBUG - 2019-07-12 01:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 01:13:45 --> Input Class Initialized
INFO - 2019-07-12 01:13:45 --> Language Class Initialized
INFO - 2019-07-12 01:13:45 --> Language Class Initialized
INFO - 2019-07-12 01:13:45 --> Config Class Initialized
INFO - 2019-07-12 01:13:45 --> Loader Class Initialized
DEBUG - 2019-07-12 01:13:45 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 01:13:45 --> Helper loaded: url_helper
INFO - 2019-07-12 01:13:45 --> Helper loaded: inflector_helper
INFO - 2019-07-12 01:13:45 --> Helper loaded: string_helper
INFO - 2019-07-12 01:13:45 --> Helper loaded: array_helper
INFO - 2019-07-12 01:13:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 01:13:45 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 01:13:45 --> Database Driver Class Initialized
INFO - 2019-07-12 01:13:45 --> Controller Class Initialized
INFO - 2019-07-12 07:13:45 --> Helper loaded: language_helper
INFO - 2019-07-12 07:13:45 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 07:13:46 --> Model Class Initialized
INFO - 2019-07-12 07:13:46 --> Model Class Initialized
INFO - 2019-07-12 07:13:46 --> Model Class Initialized
INFO - 2019-07-12 07:13:46 --> Model Class Initialized
INFO - 2019-07-12 07:13:46 --> Final output sent to browser
DEBUG - 2019-07-12 07:13:46 --> Total execution time: 0.4883
INFO - 2019-07-12 01:14:37 --> Config Class Initialized
INFO - 2019-07-12 01:14:37 --> Hooks Class Initialized
DEBUG - 2019-07-12 01:14:37 --> UTF-8 Support Enabled
INFO - 2019-07-12 01:14:37 --> Utf8 Class Initialized
INFO - 2019-07-12 01:14:37 --> URI Class Initialized
INFO - 2019-07-12 01:14:37 --> Router Class Initialized
INFO - 2019-07-12 01:14:37 --> Output Class Initialized
INFO - 2019-07-12 01:14:37 --> Security Class Initialized
DEBUG - 2019-07-12 01:14:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 01:14:37 --> Input Class Initialized
INFO - 2019-07-12 01:14:37 --> Language Class Initialized
INFO - 2019-07-12 01:14:37 --> Language Class Initialized
INFO - 2019-07-12 01:14:37 --> Config Class Initialized
INFO - 2019-07-12 01:14:37 --> Loader Class Initialized
DEBUG - 2019-07-12 01:14:37 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 01:14:38 --> Helper loaded: url_helper
INFO - 2019-07-12 01:14:38 --> Helper loaded: inflector_helper
INFO - 2019-07-12 01:14:38 --> Helper loaded: string_helper
INFO - 2019-07-12 01:14:38 --> Helper loaded: array_helper
INFO - 2019-07-12 01:14:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 01:14:38 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 01:14:38 --> Database Driver Class Initialized
INFO - 2019-07-12 01:14:38 --> Controller Class Initialized
INFO - 2019-07-12 07:14:38 --> Helper loaded: language_helper
INFO - 2019-07-12 07:14:38 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 07:14:38 --> Model Class Initialized
INFO - 2019-07-12 07:14:38 --> Model Class Initialized
INFO - 2019-07-12 07:14:38 --> Model Class Initialized
INFO - 2019-07-12 07:14:38 --> Model Class Initialized
INFO - 2019-07-12 01:14:52 --> Config Class Initialized
INFO - 2019-07-12 01:14:52 --> Hooks Class Initialized
DEBUG - 2019-07-12 01:14:52 --> UTF-8 Support Enabled
INFO - 2019-07-12 01:14:52 --> Utf8 Class Initialized
INFO - 2019-07-12 01:14:52 --> URI Class Initialized
INFO - 2019-07-12 01:14:52 --> Router Class Initialized
INFO - 2019-07-12 01:14:52 --> Output Class Initialized
INFO - 2019-07-12 01:14:52 --> Security Class Initialized
DEBUG - 2019-07-12 01:14:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 01:14:52 --> Input Class Initialized
INFO - 2019-07-12 01:14:52 --> Language Class Initialized
INFO - 2019-07-12 01:14:52 --> Language Class Initialized
INFO - 2019-07-12 01:14:52 --> Config Class Initialized
INFO - 2019-07-12 01:14:52 --> Loader Class Initialized
DEBUG - 2019-07-12 01:14:52 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 01:14:52 --> Helper loaded: url_helper
INFO - 2019-07-12 01:14:52 --> Helper loaded: inflector_helper
INFO - 2019-07-12 01:14:52 --> Helper loaded: string_helper
INFO - 2019-07-12 01:14:52 --> Helper loaded: array_helper
INFO - 2019-07-12 01:14:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 01:14:52 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 01:14:52 --> Database Driver Class Initialized
INFO - 2019-07-12 01:14:52 --> Controller Class Initialized
INFO - 2019-07-12 07:14:52 --> Helper loaded: language_helper
INFO - 2019-07-12 07:14:52 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 07:14:52 --> Model Class Initialized
INFO - 2019-07-12 07:14:52 --> Model Class Initialized
INFO - 2019-07-12 07:14:52 --> Model Class Initialized
INFO - 2019-07-12 07:14:52 --> Model Class Initialized
INFO - 2019-07-12 01:15:04 --> Config Class Initialized
INFO - 2019-07-12 01:15:04 --> Hooks Class Initialized
DEBUG - 2019-07-12 01:15:04 --> UTF-8 Support Enabled
INFO - 2019-07-12 01:15:05 --> Utf8 Class Initialized
INFO - 2019-07-12 01:15:05 --> URI Class Initialized
INFO - 2019-07-12 01:15:05 --> Router Class Initialized
INFO - 2019-07-12 01:15:05 --> Output Class Initialized
INFO - 2019-07-12 01:15:05 --> Security Class Initialized
DEBUG - 2019-07-12 01:15:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 01:15:05 --> Input Class Initialized
INFO - 2019-07-12 01:15:05 --> Language Class Initialized
INFO - 2019-07-12 01:15:05 --> Language Class Initialized
INFO - 2019-07-12 01:15:05 --> Config Class Initialized
INFO - 2019-07-12 01:15:05 --> Loader Class Initialized
DEBUG - 2019-07-12 01:15:05 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 01:15:05 --> Helper loaded: url_helper
INFO - 2019-07-12 01:15:05 --> Helper loaded: inflector_helper
INFO - 2019-07-12 01:15:05 --> Helper loaded: string_helper
INFO - 2019-07-12 01:15:05 --> Helper loaded: array_helper
INFO - 2019-07-12 01:15:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 01:15:05 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 01:15:05 --> Database Driver Class Initialized
INFO - 2019-07-12 01:15:05 --> Controller Class Initialized
INFO - 2019-07-12 07:15:05 --> Helper loaded: language_helper
INFO - 2019-07-12 07:15:05 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 07:15:05 --> Model Class Initialized
INFO - 2019-07-12 07:15:05 --> Model Class Initialized
INFO - 2019-07-12 07:15:05 --> Model Class Initialized
INFO - 2019-07-12 07:15:05 --> Model Class Initialized
INFO - 2019-07-12 01:15:25 --> Config Class Initialized
INFO - 2019-07-12 01:15:25 --> Hooks Class Initialized
DEBUG - 2019-07-12 01:15:25 --> UTF-8 Support Enabled
INFO - 2019-07-12 01:15:25 --> Utf8 Class Initialized
INFO - 2019-07-12 01:15:25 --> URI Class Initialized
INFO - 2019-07-12 01:15:25 --> Router Class Initialized
INFO - 2019-07-12 01:15:25 --> Output Class Initialized
INFO - 2019-07-12 01:15:25 --> Security Class Initialized
DEBUG - 2019-07-12 01:15:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 01:15:25 --> Input Class Initialized
INFO - 2019-07-12 01:15:25 --> Language Class Initialized
INFO - 2019-07-12 01:15:25 --> Language Class Initialized
INFO - 2019-07-12 01:15:25 --> Config Class Initialized
INFO - 2019-07-12 01:15:25 --> Loader Class Initialized
DEBUG - 2019-07-12 01:15:25 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 01:15:25 --> Helper loaded: url_helper
INFO - 2019-07-12 01:15:25 --> Helper loaded: inflector_helper
INFO - 2019-07-12 01:15:25 --> Helper loaded: string_helper
INFO - 2019-07-12 01:15:25 --> Helper loaded: array_helper
INFO - 2019-07-12 01:15:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 01:15:25 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 01:15:25 --> Database Driver Class Initialized
INFO - 2019-07-12 01:15:25 --> Controller Class Initialized
INFO - 2019-07-12 07:15:25 --> Helper loaded: language_helper
INFO - 2019-07-12 07:15:25 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 07:15:25 --> Model Class Initialized
INFO - 2019-07-12 07:15:25 --> Model Class Initialized
INFO - 2019-07-12 07:15:25 --> Model Class Initialized
INFO - 2019-07-12 07:15:25 --> Model Class Initialized
INFO - 2019-07-12 01:15:48 --> Config Class Initialized
INFO - 2019-07-12 01:15:48 --> Hooks Class Initialized
DEBUG - 2019-07-12 01:15:48 --> UTF-8 Support Enabled
INFO - 2019-07-12 01:15:48 --> Utf8 Class Initialized
INFO - 2019-07-12 01:15:48 --> URI Class Initialized
INFO - 2019-07-12 01:15:48 --> Router Class Initialized
INFO - 2019-07-12 01:15:48 --> Output Class Initialized
INFO - 2019-07-12 01:15:48 --> Security Class Initialized
DEBUG - 2019-07-12 01:15:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 01:15:48 --> Input Class Initialized
INFO - 2019-07-12 01:15:48 --> Language Class Initialized
INFO - 2019-07-12 01:15:48 --> Language Class Initialized
INFO - 2019-07-12 01:15:48 --> Config Class Initialized
INFO - 2019-07-12 01:15:48 --> Loader Class Initialized
DEBUG - 2019-07-12 01:15:48 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 01:15:48 --> Helper loaded: url_helper
INFO - 2019-07-12 01:15:48 --> Helper loaded: inflector_helper
INFO - 2019-07-12 01:15:48 --> Helper loaded: string_helper
INFO - 2019-07-12 01:15:48 --> Helper loaded: array_helper
INFO - 2019-07-12 01:15:48 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 01:15:48 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 01:15:48 --> Database Driver Class Initialized
INFO - 2019-07-12 01:15:48 --> Controller Class Initialized
INFO - 2019-07-12 07:15:48 --> Helper loaded: language_helper
INFO - 2019-07-12 07:15:48 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 07:15:48 --> Model Class Initialized
INFO - 2019-07-12 07:15:48 --> Model Class Initialized
INFO - 2019-07-12 07:15:48 --> Model Class Initialized
INFO - 2019-07-12 07:15:48 --> Model Class Initialized
INFO - 2019-07-12 01:15:56 --> Config Class Initialized
INFO - 2019-07-12 01:15:56 --> Hooks Class Initialized
DEBUG - 2019-07-12 01:15:56 --> UTF-8 Support Enabled
INFO - 2019-07-12 01:15:56 --> Utf8 Class Initialized
INFO - 2019-07-12 01:15:56 --> URI Class Initialized
INFO - 2019-07-12 01:15:56 --> Router Class Initialized
INFO - 2019-07-12 01:15:56 --> Output Class Initialized
INFO - 2019-07-12 01:15:56 --> Security Class Initialized
DEBUG - 2019-07-12 01:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 01:15:56 --> Input Class Initialized
INFO - 2019-07-12 01:15:56 --> Language Class Initialized
INFO - 2019-07-12 01:15:56 --> Language Class Initialized
INFO - 2019-07-12 01:15:56 --> Config Class Initialized
INFO - 2019-07-12 01:15:56 --> Loader Class Initialized
DEBUG - 2019-07-12 01:15:56 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 01:15:57 --> Helper loaded: url_helper
INFO - 2019-07-12 01:15:57 --> Helper loaded: inflector_helper
INFO - 2019-07-12 01:15:57 --> Helper loaded: string_helper
INFO - 2019-07-12 01:15:57 --> Helper loaded: array_helper
INFO - 2019-07-12 01:15:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 01:15:57 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 01:15:57 --> Database Driver Class Initialized
INFO - 2019-07-12 01:15:57 --> Controller Class Initialized
INFO - 2019-07-12 07:15:57 --> Helper loaded: language_helper
INFO - 2019-07-12 07:15:57 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 07:15:57 --> Model Class Initialized
INFO - 2019-07-12 07:15:57 --> Model Class Initialized
INFO - 2019-07-12 07:15:57 --> Model Class Initialized
INFO - 2019-07-12 07:15:57 --> Model Class Initialized
INFO - 2019-07-12 01:16:05 --> Config Class Initialized
INFO - 2019-07-12 01:16:05 --> Hooks Class Initialized
DEBUG - 2019-07-12 01:16:05 --> UTF-8 Support Enabled
INFO - 2019-07-12 01:16:05 --> Utf8 Class Initialized
INFO - 2019-07-12 01:16:05 --> URI Class Initialized
INFO - 2019-07-12 01:16:05 --> Router Class Initialized
INFO - 2019-07-12 01:16:05 --> Output Class Initialized
INFO - 2019-07-12 01:16:05 --> Security Class Initialized
DEBUG - 2019-07-12 01:16:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 01:16:05 --> Input Class Initialized
INFO - 2019-07-12 01:16:05 --> Language Class Initialized
INFO - 2019-07-12 01:16:05 --> Language Class Initialized
INFO - 2019-07-12 01:16:05 --> Config Class Initialized
INFO - 2019-07-12 01:16:05 --> Loader Class Initialized
DEBUG - 2019-07-12 01:16:05 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 01:16:05 --> Helper loaded: url_helper
INFO - 2019-07-12 01:16:05 --> Helper loaded: inflector_helper
INFO - 2019-07-12 01:16:05 --> Helper loaded: string_helper
INFO - 2019-07-12 01:16:05 --> Helper loaded: array_helper
INFO - 2019-07-12 01:16:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 01:16:05 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 01:16:05 --> Database Driver Class Initialized
INFO - 2019-07-12 01:16:05 --> Controller Class Initialized
INFO - 2019-07-12 07:16:05 --> Helper loaded: language_helper
INFO - 2019-07-12 07:16:05 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 07:16:05 --> Model Class Initialized
INFO - 2019-07-12 07:16:05 --> Model Class Initialized
INFO - 2019-07-12 07:16:05 --> Model Class Initialized
INFO - 2019-07-12 07:16:05 --> Model Class Initialized
INFO - 2019-07-12 01:16:21 --> Config Class Initialized
INFO - 2019-07-12 01:16:21 --> Hooks Class Initialized
DEBUG - 2019-07-12 01:16:21 --> UTF-8 Support Enabled
INFO - 2019-07-12 01:16:21 --> Utf8 Class Initialized
INFO - 2019-07-12 01:16:21 --> URI Class Initialized
INFO - 2019-07-12 01:16:21 --> Router Class Initialized
INFO - 2019-07-12 01:16:21 --> Output Class Initialized
INFO - 2019-07-12 01:16:21 --> Security Class Initialized
DEBUG - 2019-07-12 01:16:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 01:16:21 --> Input Class Initialized
INFO - 2019-07-12 01:16:21 --> Language Class Initialized
INFO - 2019-07-12 01:16:21 --> Language Class Initialized
INFO - 2019-07-12 01:16:21 --> Config Class Initialized
INFO - 2019-07-12 01:16:21 --> Loader Class Initialized
DEBUG - 2019-07-12 01:16:21 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 01:16:21 --> Helper loaded: url_helper
INFO - 2019-07-12 01:16:21 --> Helper loaded: inflector_helper
INFO - 2019-07-12 01:16:21 --> Helper loaded: string_helper
INFO - 2019-07-12 01:16:22 --> Helper loaded: array_helper
INFO - 2019-07-12 01:16:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 01:16:22 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 01:16:22 --> Database Driver Class Initialized
INFO - 2019-07-12 01:16:22 --> Controller Class Initialized
INFO - 2019-07-12 07:16:22 --> Helper loaded: language_helper
INFO - 2019-07-12 07:16:22 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 07:16:22 --> Model Class Initialized
INFO - 2019-07-12 07:16:22 --> Model Class Initialized
INFO - 2019-07-12 07:16:22 --> Model Class Initialized
INFO - 2019-07-12 07:16:22 --> Model Class Initialized
INFO - 2019-07-12 07:16:22 --> Final output sent to browser
DEBUG - 2019-07-12 07:16:22 --> Total execution time: 0.5125
INFO - 2019-07-12 01:16:52 --> Config Class Initialized
INFO - 2019-07-12 01:16:52 --> Hooks Class Initialized
DEBUG - 2019-07-12 01:16:52 --> UTF-8 Support Enabled
INFO - 2019-07-12 01:16:52 --> Utf8 Class Initialized
INFO - 2019-07-12 01:16:52 --> URI Class Initialized
INFO - 2019-07-12 01:16:52 --> Router Class Initialized
INFO - 2019-07-12 01:16:52 --> Output Class Initialized
INFO - 2019-07-12 01:16:52 --> Security Class Initialized
DEBUG - 2019-07-12 01:16:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 01:16:52 --> Input Class Initialized
INFO - 2019-07-12 01:16:52 --> Language Class Initialized
INFO - 2019-07-12 01:16:52 --> Language Class Initialized
INFO - 2019-07-12 01:16:52 --> Config Class Initialized
INFO - 2019-07-12 01:16:52 --> Loader Class Initialized
DEBUG - 2019-07-12 01:16:52 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 01:16:52 --> Helper loaded: url_helper
INFO - 2019-07-12 01:16:52 --> Helper loaded: inflector_helper
INFO - 2019-07-12 01:16:53 --> Helper loaded: string_helper
INFO - 2019-07-12 01:16:53 --> Helper loaded: array_helper
INFO - 2019-07-12 01:16:53 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 01:16:53 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 01:16:53 --> Database Driver Class Initialized
INFO - 2019-07-12 01:16:53 --> Controller Class Initialized
INFO - 2019-07-12 07:16:53 --> Helper loaded: language_helper
INFO - 2019-07-12 07:16:53 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 07:16:53 --> Model Class Initialized
INFO - 2019-07-12 07:16:53 --> Model Class Initialized
INFO - 2019-07-12 07:16:53 --> Model Class Initialized
INFO - 2019-07-12 07:16:53 --> Model Class Initialized
INFO - 2019-07-12 07:16:53 --> Final output sent to browser
DEBUG - 2019-07-12 07:16:53 --> Total execution time: 0.5633
INFO - 2019-07-12 01:17:21 --> Config Class Initialized
INFO - 2019-07-12 01:17:21 --> Hooks Class Initialized
DEBUG - 2019-07-12 01:17:21 --> UTF-8 Support Enabled
INFO - 2019-07-12 01:17:21 --> Utf8 Class Initialized
INFO - 2019-07-12 01:17:21 --> URI Class Initialized
INFO - 2019-07-12 01:17:21 --> Router Class Initialized
INFO - 2019-07-12 01:17:21 --> Output Class Initialized
INFO - 2019-07-12 01:17:21 --> Security Class Initialized
DEBUG - 2019-07-12 01:17:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 01:17:21 --> Input Class Initialized
INFO - 2019-07-12 01:17:21 --> Language Class Initialized
INFO - 2019-07-12 01:17:21 --> Language Class Initialized
INFO - 2019-07-12 01:17:21 --> Config Class Initialized
INFO - 2019-07-12 01:17:21 --> Loader Class Initialized
DEBUG - 2019-07-12 01:17:21 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 01:17:21 --> Helper loaded: url_helper
INFO - 2019-07-12 01:17:21 --> Helper loaded: inflector_helper
INFO - 2019-07-12 01:17:21 --> Helper loaded: string_helper
INFO - 2019-07-12 01:17:21 --> Helper loaded: array_helper
INFO - 2019-07-12 01:17:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 01:17:21 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 01:17:21 --> Database Driver Class Initialized
INFO - 2019-07-12 01:17:21 --> Controller Class Initialized
INFO - 2019-07-12 07:17:21 --> Helper loaded: language_helper
INFO - 2019-07-12 07:17:21 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 07:17:21 --> Model Class Initialized
INFO - 2019-07-12 07:17:21 --> Model Class Initialized
INFO - 2019-07-12 07:17:21 --> Model Class Initialized
INFO - 2019-07-12 07:17:21 --> Model Class Initialized
INFO - 2019-07-12 07:17:21 --> Final output sent to browser
DEBUG - 2019-07-12 07:17:21 --> Total execution time: 0.5623
INFO - 2019-07-12 01:17:48 --> Config Class Initialized
INFO - 2019-07-12 01:17:48 --> Hooks Class Initialized
DEBUG - 2019-07-12 01:17:48 --> UTF-8 Support Enabled
INFO - 2019-07-12 01:17:48 --> Utf8 Class Initialized
INFO - 2019-07-12 01:17:48 --> URI Class Initialized
INFO - 2019-07-12 01:17:48 --> Router Class Initialized
INFO - 2019-07-12 01:17:48 --> Output Class Initialized
INFO - 2019-07-12 01:17:48 --> Security Class Initialized
DEBUG - 2019-07-12 01:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 01:17:48 --> Input Class Initialized
INFO - 2019-07-12 01:17:48 --> Language Class Initialized
INFO - 2019-07-12 01:17:48 --> Language Class Initialized
INFO - 2019-07-12 01:17:48 --> Config Class Initialized
INFO - 2019-07-12 01:17:48 --> Loader Class Initialized
DEBUG - 2019-07-12 01:17:48 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 01:17:48 --> Helper loaded: url_helper
INFO - 2019-07-12 01:17:48 --> Helper loaded: inflector_helper
INFO - 2019-07-12 01:17:48 --> Helper loaded: string_helper
INFO - 2019-07-12 01:17:48 --> Helper loaded: array_helper
INFO - 2019-07-12 01:17:49 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 01:17:49 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 01:17:49 --> Database Driver Class Initialized
INFO - 2019-07-12 01:17:49 --> Controller Class Initialized
INFO - 2019-07-12 07:17:49 --> Helper loaded: language_helper
INFO - 2019-07-12 07:17:49 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 07:17:49 --> Model Class Initialized
INFO - 2019-07-12 07:17:49 --> Model Class Initialized
INFO - 2019-07-12 07:17:49 --> Model Class Initialized
INFO - 2019-07-12 07:17:49 --> Model Class Initialized
INFO - 2019-07-12 07:17:49 --> Final output sent to browser
DEBUG - 2019-07-12 07:17:49 --> Total execution time: 0.7220
INFO - 2019-07-12 01:17:49 --> Config Class Initialized
INFO - 2019-07-12 01:17:49 --> Hooks Class Initialized
DEBUG - 2019-07-12 01:17:49 --> UTF-8 Support Enabled
INFO - 2019-07-12 01:17:49 --> Utf8 Class Initialized
INFO - 2019-07-12 01:17:49 --> URI Class Initialized
INFO - 2019-07-12 01:17:49 --> Router Class Initialized
INFO - 2019-07-12 01:17:49 --> Output Class Initialized
INFO - 2019-07-12 01:17:49 --> Security Class Initialized
DEBUG - 2019-07-12 01:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 01:17:49 --> Input Class Initialized
INFO - 2019-07-12 01:17:49 --> Language Class Initialized
INFO - 2019-07-12 01:17:49 --> Language Class Initialized
INFO - 2019-07-12 01:17:49 --> Config Class Initialized
INFO - 2019-07-12 01:17:49 --> Loader Class Initialized
DEBUG - 2019-07-12 01:17:49 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 01:17:49 --> Helper loaded: url_helper
INFO - 2019-07-12 01:17:49 --> Helper loaded: inflector_helper
INFO - 2019-07-12 01:17:49 --> Helper loaded: string_helper
INFO - 2019-07-12 01:17:49 --> Helper loaded: array_helper
INFO - 2019-07-12 01:17:49 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 01:17:49 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 01:17:49 --> Database Driver Class Initialized
INFO - 2019-07-12 01:17:49 --> Controller Class Initialized
INFO - 2019-07-12 07:17:49 --> Helper loaded: language_helper
INFO - 2019-07-12 07:17:49 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 07:17:49 --> Model Class Initialized
INFO - 2019-07-12 07:17:49 --> Model Class Initialized
INFO - 2019-07-12 07:17:49 --> Model Class Initialized
INFO - 2019-07-12 07:17:49 --> Model Class Initialized
INFO - 2019-07-12 07:17:50 --> Final output sent to browser
DEBUG - 2019-07-12 07:17:50 --> Total execution time: 0.5599
INFO - 2019-07-12 01:18:08 --> Config Class Initialized
INFO - 2019-07-12 01:18:08 --> Hooks Class Initialized
DEBUG - 2019-07-12 01:18:08 --> UTF-8 Support Enabled
INFO - 2019-07-12 01:18:08 --> Utf8 Class Initialized
INFO - 2019-07-12 01:18:08 --> URI Class Initialized
INFO - 2019-07-12 01:18:08 --> Router Class Initialized
INFO - 2019-07-12 01:18:09 --> Output Class Initialized
INFO - 2019-07-12 01:18:09 --> Security Class Initialized
DEBUG - 2019-07-12 01:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 01:18:09 --> Input Class Initialized
INFO - 2019-07-12 01:18:09 --> Language Class Initialized
INFO - 2019-07-12 01:18:09 --> Language Class Initialized
INFO - 2019-07-12 01:18:09 --> Config Class Initialized
INFO - 2019-07-12 01:18:09 --> Loader Class Initialized
DEBUG - 2019-07-12 01:18:09 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 01:18:09 --> Helper loaded: url_helper
INFO - 2019-07-12 01:18:09 --> Helper loaded: inflector_helper
INFO - 2019-07-12 01:18:09 --> Helper loaded: string_helper
INFO - 2019-07-12 01:18:09 --> Helper loaded: array_helper
INFO - 2019-07-12 01:18:09 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 01:18:09 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 01:18:09 --> Database Driver Class Initialized
INFO - 2019-07-12 01:18:09 --> Controller Class Initialized
INFO - 2019-07-12 07:18:09 --> Helper loaded: language_helper
INFO - 2019-07-12 07:18:09 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 07:18:09 --> Model Class Initialized
INFO - 2019-07-12 07:18:09 --> Model Class Initialized
INFO - 2019-07-12 07:18:09 --> Model Class Initialized
INFO - 2019-07-12 07:18:09 --> Model Class Initialized
INFO - 2019-07-12 07:18:09 --> Final output sent to browser
DEBUG - 2019-07-12 07:18:09 --> Total execution time: 0.6727
INFO - 2019-07-12 01:19:27 --> Config Class Initialized
INFO - 2019-07-12 01:19:27 --> Hooks Class Initialized
DEBUG - 2019-07-12 01:19:27 --> UTF-8 Support Enabled
INFO - 2019-07-12 01:19:27 --> Utf8 Class Initialized
INFO - 2019-07-12 01:19:27 --> URI Class Initialized
INFO - 2019-07-12 01:19:27 --> Router Class Initialized
INFO - 2019-07-12 01:19:27 --> Output Class Initialized
INFO - 2019-07-12 01:19:27 --> Security Class Initialized
DEBUG - 2019-07-12 01:19:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 01:19:27 --> Input Class Initialized
INFO - 2019-07-12 01:19:27 --> Language Class Initialized
INFO - 2019-07-12 01:19:27 --> Language Class Initialized
INFO - 2019-07-12 01:19:27 --> Config Class Initialized
INFO - 2019-07-12 01:19:27 --> Loader Class Initialized
DEBUG - 2019-07-12 01:19:27 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 01:19:27 --> Helper loaded: url_helper
INFO - 2019-07-12 01:19:27 --> Helper loaded: inflector_helper
INFO - 2019-07-12 01:19:27 --> Helper loaded: string_helper
INFO - 2019-07-12 01:19:27 --> Helper loaded: array_helper
INFO - 2019-07-12 01:19:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 01:19:27 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 01:19:27 --> Database Driver Class Initialized
INFO - 2019-07-12 01:19:27 --> Controller Class Initialized
INFO - 2019-07-12 07:19:27 --> Helper loaded: language_helper
INFO - 2019-07-12 07:19:27 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 07:19:27 --> Model Class Initialized
INFO - 2019-07-12 07:19:27 --> Model Class Initialized
INFO - 2019-07-12 07:19:27 --> Model Class Initialized
INFO - 2019-07-12 07:19:27 --> Model Class Initialized
INFO - 2019-07-12 07:19:27 --> Final output sent to browser
DEBUG - 2019-07-12 07:19:27 --> Total execution time: 0.6148
INFO - 2019-07-12 01:19:30 --> Config Class Initialized
INFO - 2019-07-12 01:19:30 --> Hooks Class Initialized
DEBUG - 2019-07-12 01:19:30 --> UTF-8 Support Enabled
INFO - 2019-07-12 01:19:30 --> Utf8 Class Initialized
INFO - 2019-07-12 01:19:30 --> URI Class Initialized
INFO - 2019-07-12 01:19:30 --> Router Class Initialized
INFO - 2019-07-12 01:19:30 --> Output Class Initialized
INFO - 2019-07-12 01:19:30 --> Security Class Initialized
DEBUG - 2019-07-12 01:19:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 01:19:30 --> Input Class Initialized
INFO - 2019-07-12 01:19:30 --> Language Class Initialized
INFO - 2019-07-12 01:19:30 --> Language Class Initialized
INFO - 2019-07-12 01:19:30 --> Config Class Initialized
INFO - 2019-07-12 01:19:30 --> Loader Class Initialized
DEBUG - 2019-07-12 01:19:30 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 01:19:30 --> Helper loaded: url_helper
INFO - 2019-07-12 01:19:30 --> Helper loaded: inflector_helper
INFO - 2019-07-12 01:19:30 --> Helper loaded: string_helper
INFO - 2019-07-12 01:19:30 --> Helper loaded: array_helper
INFO - 2019-07-12 01:19:30 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 01:19:30 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 01:19:30 --> Database Driver Class Initialized
INFO - 2019-07-12 01:19:30 --> Controller Class Initialized
INFO - 2019-07-12 07:19:30 --> Helper loaded: language_helper
INFO - 2019-07-12 07:19:30 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 07:19:30 --> Model Class Initialized
INFO - 2019-07-12 07:19:30 --> Model Class Initialized
INFO - 2019-07-12 07:19:30 --> Model Class Initialized
INFO - 2019-07-12 07:19:30 --> Model Class Initialized
INFO - 2019-07-12 07:19:30 --> Final output sent to browser
DEBUG - 2019-07-12 07:19:30 --> Total execution time: 0.5624
INFO - 2019-07-12 01:20:10 --> Config Class Initialized
INFO - 2019-07-12 01:20:10 --> Hooks Class Initialized
DEBUG - 2019-07-12 01:20:10 --> UTF-8 Support Enabled
INFO - 2019-07-12 01:20:10 --> Utf8 Class Initialized
INFO - 2019-07-12 01:20:10 --> URI Class Initialized
INFO - 2019-07-12 01:20:11 --> Router Class Initialized
INFO - 2019-07-12 01:20:11 --> Output Class Initialized
INFO - 2019-07-12 01:20:11 --> Security Class Initialized
DEBUG - 2019-07-12 01:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 01:20:11 --> Input Class Initialized
INFO - 2019-07-12 01:20:11 --> Language Class Initialized
INFO - 2019-07-12 01:20:11 --> Language Class Initialized
INFO - 2019-07-12 01:20:11 --> Config Class Initialized
INFO - 2019-07-12 01:20:11 --> Loader Class Initialized
DEBUG - 2019-07-12 01:20:11 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 01:20:11 --> Helper loaded: url_helper
INFO - 2019-07-12 01:20:11 --> Helper loaded: inflector_helper
INFO - 2019-07-12 01:20:11 --> Helper loaded: string_helper
INFO - 2019-07-12 01:20:11 --> Helper loaded: array_helper
INFO - 2019-07-12 01:20:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 01:20:11 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 01:20:11 --> Database Driver Class Initialized
INFO - 2019-07-12 01:20:11 --> Controller Class Initialized
INFO - 2019-07-12 07:20:11 --> Helper loaded: language_helper
INFO - 2019-07-12 07:20:11 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 07:20:11 --> Model Class Initialized
INFO - 2019-07-12 07:20:11 --> Model Class Initialized
INFO - 2019-07-12 07:20:11 --> Model Class Initialized
INFO - 2019-07-12 07:20:11 --> Model Class Initialized
INFO - 2019-07-12 07:20:11 --> Final output sent to browser
DEBUG - 2019-07-12 07:20:11 --> Total execution time: 0.5221
INFO - 2019-07-12 01:20:13 --> Config Class Initialized
INFO - 2019-07-12 01:20:13 --> Hooks Class Initialized
DEBUG - 2019-07-12 01:20:14 --> UTF-8 Support Enabled
INFO - 2019-07-12 01:20:14 --> Utf8 Class Initialized
INFO - 2019-07-12 01:20:14 --> URI Class Initialized
INFO - 2019-07-12 01:20:14 --> Router Class Initialized
INFO - 2019-07-12 01:20:14 --> Output Class Initialized
INFO - 2019-07-12 01:20:14 --> Security Class Initialized
DEBUG - 2019-07-12 01:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 01:20:14 --> Input Class Initialized
INFO - 2019-07-12 01:20:14 --> Language Class Initialized
INFO - 2019-07-12 01:20:14 --> Language Class Initialized
INFO - 2019-07-12 01:20:14 --> Config Class Initialized
INFO - 2019-07-12 01:20:14 --> Loader Class Initialized
DEBUG - 2019-07-12 01:20:14 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 01:20:14 --> Helper loaded: url_helper
INFO - 2019-07-12 01:20:14 --> Helper loaded: inflector_helper
INFO - 2019-07-12 01:20:14 --> Helper loaded: string_helper
INFO - 2019-07-12 01:20:14 --> Helper loaded: array_helper
INFO - 2019-07-12 01:20:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 01:20:14 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 01:20:14 --> Database Driver Class Initialized
INFO - 2019-07-12 01:20:14 --> Controller Class Initialized
INFO - 2019-07-12 07:20:14 --> Helper loaded: language_helper
INFO - 2019-07-12 07:20:14 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 07:20:14 --> Model Class Initialized
INFO - 2019-07-12 07:20:14 --> Model Class Initialized
INFO - 2019-07-12 07:20:14 --> Model Class Initialized
INFO - 2019-07-12 07:20:14 --> Model Class Initialized
INFO - 2019-07-12 07:20:14 --> Final output sent to browser
DEBUG - 2019-07-12 07:20:14 --> Total execution time: 0.5255
INFO - 2019-07-12 01:22:00 --> Config Class Initialized
INFO - 2019-07-12 01:22:00 --> Hooks Class Initialized
DEBUG - 2019-07-12 01:22:00 --> UTF-8 Support Enabled
INFO - 2019-07-12 01:22:00 --> Utf8 Class Initialized
INFO - 2019-07-12 01:22:00 --> URI Class Initialized
INFO - 2019-07-12 01:22:00 --> Router Class Initialized
INFO - 2019-07-12 01:22:00 --> Output Class Initialized
INFO - 2019-07-12 01:22:00 --> Security Class Initialized
DEBUG - 2019-07-12 01:22:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 01:22:00 --> Input Class Initialized
INFO - 2019-07-12 01:22:00 --> Language Class Initialized
INFO - 2019-07-12 01:22:00 --> Language Class Initialized
INFO - 2019-07-12 01:22:00 --> Config Class Initialized
INFO - 2019-07-12 01:22:00 --> Loader Class Initialized
DEBUG - 2019-07-12 01:22:00 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 01:22:00 --> Helper loaded: url_helper
INFO - 2019-07-12 01:22:00 --> Helper loaded: inflector_helper
INFO - 2019-07-12 01:22:00 --> Helper loaded: string_helper
INFO - 2019-07-12 01:22:00 --> Helper loaded: array_helper
INFO - 2019-07-12 01:22:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 01:22:00 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 01:22:00 --> Database Driver Class Initialized
INFO - 2019-07-12 01:22:00 --> Controller Class Initialized
INFO - 2019-07-12 07:22:00 --> Helper loaded: language_helper
INFO - 2019-07-12 07:22:00 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 07:22:00 --> Model Class Initialized
INFO - 2019-07-12 07:22:00 --> Model Class Initialized
INFO - 2019-07-12 07:22:00 --> Model Class Initialized
INFO - 2019-07-12 07:22:00 --> Model Class Initialized
INFO - 2019-07-12 07:22:00 --> Final output sent to browser
DEBUG - 2019-07-12 07:22:00 --> Total execution time: 0.5285
INFO - 2019-07-12 01:22:38 --> Config Class Initialized
INFO - 2019-07-12 01:22:38 --> Hooks Class Initialized
DEBUG - 2019-07-12 01:22:38 --> UTF-8 Support Enabled
INFO - 2019-07-12 01:22:38 --> Utf8 Class Initialized
INFO - 2019-07-12 01:22:38 --> URI Class Initialized
INFO - 2019-07-12 01:22:38 --> Router Class Initialized
INFO - 2019-07-12 01:22:38 --> Output Class Initialized
INFO - 2019-07-12 01:22:38 --> Security Class Initialized
DEBUG - 2019-07-12 01:22:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 01:22:38 --> Input Class Initialized
INFO - 2019-07-12 01:22:38 --> Language Class Initialized
INFO - 2019-07-12 01:22:38 --> Language Class Initialized
INFO - 2019-07-12 01:22:38 --> Config Class Initialized
INFO - 2019-07-12 01:22:38 --> Loader Class Initialized
DEBUG - 2019-07-12 01:22:38 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 01:22:38 --> Helper loaded: url_helper
INFO - 2019-07-12 01:22:38 --> Helper loaded: inflector_helper
INFO - 2019-07-12 01:22:38 --> Helper loaded: string_helper
INFO - 2019-07-12 01:22:38 --> Helper loaded: array_helper
INFO - 2019-07-12 01:22:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 01:22:38 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 01:22:38 --> Database Driver Class Initialized
INFO - 2019-07-12 01:22:38 --> Controller Class Initialized
INFO - 2019-07-12 07:22:38 --> Helper loaded: language_helper
INFO - 2019-07-12 07:22:38 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 07:22:38 --> Model Class Initialized
INFO - 2019-07-12 07:22:38 --> Model Class Initialized
INFO - 2019-07-12 07:22:38 --> Model Class Initialized
INFO - 2019-07-12 07:22:38 --> Model Class Initialized
INFO - 2019-07-12 07:22:38 --> Final output sent to browser
DEBUG - 2019-07-12 07:22:38 --> Total execution time: 0.5077
INFO - 2019-07-12 01:22:41 --> Config Class Initialized
INFO - 2019-07-12 01:22:41 --> Hooks Class Initialized
DEBUG - 2019-07-12 01:22:41 --> UTF-8 Support Enabled
INFO - 2019-07-12 01:22:41 --> Utf8 Class Initialized
INFO - 2019-07-12 01:22:41 --> URI Class Initialized
INFO - 2019-07-12 01:22:41 --> Router Class Initialized
INFO - 2019-07-12 01:22:41 --> Output Class Initialized
INFO - 2019-07-12 01:22:41 --> Security Class Initialized
DEBUG - 2019-07-12 01:22:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 01:22:41 --> Input Class Initialized
INFO - 2019-07-12 01:22:41 --> Language Class Initialized
INFO - 2019-07-12 01:22:41 --> Language Class Initialized
INFO - 2019-07-12 01:22:41 --> Config Class Initialized
INFO - 2019-07-12 01:22:41 --> Loader Class Initialized
DEBUG - 2019-07-12 01:22:41 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 01:22:41 --> Helper loaded: url_helper
INFO - 2019-07-12 01:22:41 --> Helper loaded: inflector_helper
INFO - 2019-07-12 01:22:41 --> Helper loaded: string_helper
INFO - 2019-07-12 01:22:41 --> Helper loaded: array_helper
INFO - 2019-07-12 01:22:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 01:22:41 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 01:22:41 --> Database Driver Class Initialized
INFO - 2019-07-12 01:22:41 --> Controller Class Initialized
INFO - 2019-07-12 07:22:41 --> Helper loaded: language_helper
INFO - 2019-07-12 07:22:41 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 07:22:41 --> Model Class Initialized
INFO - 2019-07-12 07:22:41 --> Model Class Initialized
INFO - 2019-07-12 07:22:41 --> Model Class Initialized
INFO - 2019-07-12 07:22:41 --> Model Class Initialized
INFO - 2019-07-12 07:22:41 --> Final output sent to browser
DEBUG - 2019-07-12 07:22:41 --> Total execution time: 0.5212
INFO - 2019-07-12 01:26:03 --> Config Class Initialized
INFO - 2019-07-12 01:26:03 --> Hooks Class Initialized
DEBUG - 2019-07-12 01:26:03 --> UTF-8 Support Enabled
INFO - 2019-07-12 01:26:03 --> Utf8 Class Initialized
INFO - 2019-07-12 01:26:03 --> URI Class Initialized
INFO - 2019-07-12 01:26:03 --> Router Class Initialized
INFO - 2019-07-12 01:26:03 --> Output Class Initialized
INFO - 2019-07-12 01:26:03 --> Security Class Initialized
DEBUG - 2019-07-12 01:26:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 01:26:03 --> Input Class Initialized
INFO - 2019-07-12 01:26:03 --> Language Class Initialized
INFO - 2019-07-12 01:26:03 --> Language Class Initialized
INFO - 2019-07-12 01:26:03 --> Config Class Initialized
INFO - 2019-07-12 01:26:03 --> Loader Class Initialized
DEBUG - 2019-07-12 01:26:03 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 01:26:03 --> Helper loaded: url_helper
INFO - 2019-07-12 01:26:03 --> Helper loaded: inflector_helper
INFO - 2019-07-12 01:26:03 --> Helper loaded: string_helper
INFO - 2019-07-12 01:26:03 --> Helper loaded: array_helper
INFO - 2019-07-12 01:26:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 01:26:03 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 01:26:03 --> Database Driver Class Initialized
INFO - 2019-07-12 01:26:03 --> Controller Class Initialized
INFO - 2019-07-12 07:26:03 --> Helper loaded: language_helper
INFO - 2019-07-12 07:26:03 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 07:26:03 --> Model Class Initialized
INFO - 2019-07-12 07:26:03 --> Model Class Initialized
INFO - 2019-07-12 07:26:03 --> Model Class Initialized
INFO - 2019-07-12 07:26:03 --> Model Class Initialized
INFO - 2019-07-12 07:26:03 --> Final output sent to browser
DEBUG - 2019-07-12 07:26:03 --> Total execution time: 0.5721
INFO - 2019-07-12 01:26:39 --> Config Class Initialized
INFO - 2019-07-12 01:26:39 --> Hooks Class Initialized
DEBUG - 2019-07-12 01:26:39 --> UTF-8 Support Enabled
INFO - 2019-07-12 01:26:39 --> Utf8 Class Initialized
INFO - 2019-07-12 01:26:39 --> URI Class Initialized
INFO - 2019-07-12 01:26:39 --> Router Class Initialized
INFO - 2019-07-12 01:26:39 --> Output Class Initialized
INFO - 2019-07-12 01:26:39 --> Security Class Initialized
DEBUG - 2019-07-12 01:26:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 01:26:39 --> Input Class Initialized
INFO - 2019-07-12 01:26:39 --> Language Class Initialized
INFO - 2019-07-12 01:26:39 --> Language Class Initialized
INFO - 2019-07-12 01:26:39 --> Config Class Initialized
INFO - 2019-07-12 01:26:39 --> Loader Class Initialized
DEBUG - 2019-07-12 01:26:39 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 01:26:39 --> Helper loaded: url_helper
INFO - 2019-07-12 01:26:39 --> Helper loaded: inflector_helper
INFO - 2019-07-12 01:26:39 --> Helper loaded: string_helper
INFO - 2019-07-12 01:26:39 --> Helper loaded: array_helper
INFO - 2019-07-12 01:26:39 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 01:26:39 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 01:26:39 --> Database Driver Class Initialized
INFO - 2019-07-12 01:26:39 --> Controller Class Initialized
INFO - 2019-07-12 07:26:39 --> Helper loaded: language_helper
INFO - 2019-07-12 07:26:39 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 07:26:39 --> Model Class Initialized
INFO - 2019-07-12 07:26:39 --> Model Class Initialized
INFO - 2019-07-12 07:26:39 --> Model Class Initialized
INFO - 2019-07-12 07:26:39 --> Model Class Initialized
INFO - 2019-07-12 07:26:39 --> Final output sent to browser
DEBUG - 2019-07-12 07:26:39 --> Total execution time: 0.5086
INFO - 2019-07-12 01:26:59 --> Config Class Initialized
INFO - 2019-07-12 01:26:59 --> Hooks Class Initialized
DEBUG - 2019-07-12 01:26:59 --> UTF-8 Support Enabled
INFO - 2019-07-12 01:26:59 --> Utf8 Class Initialized
INFO - 2019-07-12 01:26:59 --> URI Class Initialized
INFO - 2019-07-12 01:26:59 --> Router Class Initialized
INFO - 2019-07-12 01:26:59 --> Output Class Initialized
INFO - 2019-07-12 01:27:00 --> Security Class Initialized
DEBUG - 2019-07-12 01:27:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 01:27:00 --> Input Class Initialized
INFO - 2019-07-12 01:27:00 --> Language Class Initialized
INFO - 2019-07-12 01:27:00 --> Language Class Initialized
INFO - 2019-07-12 01:27:00 --> Config Class Initialized
INFO - 2019-07-12 01:27:00 --> Loader Class Initialized
DEBUG - 2019-07-12 01:27:00 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 01:27:00 --> Helper loaded: url_helper
INFO - 2019-07-12 01:27:00 --> Helper loaded: inflector_helper
INFO - 2019-07-12 01:27:00 --> Helper loaded: string_helper
INFO - 2019-07-12 01:27:00 --> Helper loaded: array_helper
INFO - 2019-07-12 01:27:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 01:27:00 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 01:27:00 --> Database Driver Class Initialized
INFO - 2019-07-12 01:27:00 --> Controller Class Initialized
INFO - 2019-07-12 07:27:00 --> Helper loaded: language_helper
INFO - 2019-07-12 07:27:00 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 07:27:00 --> Model Class Initialized
INFO - 2019-07-12 07:27:00 --> Model Class Initialized
INFO - 2019-07-12 07:27:00 --> Model Class Initialized
INFO - 2019-07-12 07:27:00 --> Model Class Initialized
INFO - 2019-07-12 07:27:00 --> Model Class Initialized
INFO - 2019-07-12 07:27:00 --> Final output sent to browser
DEBUG - 2019-07-12 07:27:00 --> Total execution time: 0.5673
INFO - 2019-07-12 01:27:00 --> Config Class Initialized
INFO - 2019-07-12 01:27:00 --> Hooks Class Initialized
DEBUG - 2019-07-12 01:27:00 --> UTF-8 Support Enabled
INFO - 2019-07-12 01:27:00 --> Utf8 Class Initialized
INFO - 2019-07-12 01:27:00 --> URI Class Initialized
INFO - 2019-07-12 01:27:00 --> Router Class Initialized
INFO - 2019-07-12 01:27:00 --> Output Class Initialized
INFO - 2019-07-12 01:27:00 --> Security Class Initialized
DEBUG - 2019-07-12 01:27:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 01:27:00 --> Input Class Initialized
INFO - 2019-07-12 01:27:00 --> Language Class Initialized
INFO - 2019-07-12 01:27:00 --> Language Class Initialized
INFO - 2019-07-12 01:27:00 --> Config Class Initialized
INFO - 2019-07-12 01:27:00 --> Loader Class Initialized
DEBUG - 2019-07-12 01:27:00 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 01:27:00 --> Helper loaded: url_helper
INFO - 2019-07-12 01:27:00 --> Helper loaded: inflector_helper
INFO - 2019-07-12 01:27:00 --> Helper loaded: string_helper
INFO - 2019-07-12 01:27:00 --> Helper loaded: array_helper
INFO - 2019-07-12 01:27:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 01:27:00 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 01:27:00 --> Database Driver Class Initialized
INFO - 2019-07-12 01:27:00 --> Controller Class Initialized
INFO - 2019-07-12 07:27:00 --> Helper loaded: language_helper
INFO - 2019-07-12 07:27:00 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 07:27:00 --> Model Class Initialized
INFO - 2019-07-12 07:27:00 --> Model Class Initialized
INFO - 2019-07-12 07:27:00 --> Model Class Initialized
INFO - 2019-07-12 07:27:01 --> Model Class Initialized
INFO - 2019-07-12 07:27:01 --> Model Class Initialized
INFO - 2019-07-12 07:27:01 --> Final output sent to browser
DEBUG - 2019-07-12 07:27:01 --> Total execution time: 0.5548
INFO - 2019-07-12 01:38:54 --> Config Class Initialized
INFO - 2019-07-12 01:38:54 --> Hooks Class Initialized
DEBUG - 2019-07-12 01:38:54 --> UTF-8 Support Enabled
INFO - 2019-07-12 01:38:54 --> Utf8 Class Initialized
INFO - 2019-07-12 01:38:54 --> URI Class Initialized
INFO - 2019-07-12 01:38:54 --> Router Class Initialized
INFO - 2019-07-12 01:38:54 --> Output Class Initialized
INFO - 2019-07-12 01:38:54 --> Security Class Initialized
DEBUG - 2019-07-12 01:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 01:38:54 --> Input Class Initialized
INFO - 2019-07-12 01:38:54 --> Language Class Initialized
INFO - 2019-07-12 01:38:54 --> Language Class Initialized
INFO - 2019-07-12 01:38:54 --> Config Class Initialized
INFO - 2019-07-12 01:38:54 --> Loader Class Initialized
DEBUG - 2019-07-12 01:38:54 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 01:38:54 --> Helper loaded: url_helper
INFO - 2019-07-12 01:38:54 --> Helper loaded: inflector_helper
INFO - 2019-07-12 01:38:54 --> Helper loaded: string_helper
INFO - 2019-07-12 01:38:54 --> Helper loaded: array_helper
INFO - 2019-07-12 01:38:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 01:38:54 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 01:38:54 --> Database Driver Class Initialized
INFO - 2019-07-12 01:38:54 --> Controller Class Initialized
INFO - 2019-07-12 07:38:54 --> Helper loaded: language_helper
INFO - 2019-07-12 07:38:54 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 07:38:54 --> Model Class Initialized
INFO - 2019-07-12 07:38:54 --> Model Class Initialized
INFO - 2019-07-12 07:38:54 --> Model Class Initialized
INFO - 2019-07-12 07:38:55 --> Model Class Initialized
ERROR - 2019-07-12 07:38:55 --> Severity: Error --> Call to undefined method Owners::check_required_fields() C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Owners.php 121
INFO - 2019-07-12 01:39:01 --> Config Class Initialized
INFO - 2019-07-12 01:39:01 --> Hooks Class Initialized
DEBUG - 2019-07-12 01:39:01 --> UTF-8 Support Enabled
INFO - 2019-07-12 01:39:01 --> Utf8 Class Initialized
INFO - 2019-07-12 01:39:01 --> URI Class Initialized
INFO - 2019-07-12 01:39:01 --> Router Class Initialized
INFO - 2019-07-12 01:39:01 --> Output Class Initialized
INFO - 2019-07-12 01:39:01 --> Security Class Initialized
DEBUG - 2019-07-12 01:39:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 01:39:01 --> Input Class Initialized
INFO - 2019-07-12 01:39:01 --> Language Class Initialized
INFO - 2019-07-12 01:39:01 --> Language Class Initialized
INFO - 2019-07-12 01:39:01 --> Config Class Initialized
INFO - 2019-07-12 01:39:01 --> Loader Class Initialized
DEBUG - 2019-07-12 01:39:01 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 01:39:01 --> Helper loaded: url_helper
INFO - 2019-07-12 01:39:01 --> Helper loaded: inflector_helper
INFO - 2019-07-12 01:39:01 --> Helper loaded: string_helper
INFO - 2019-07-12 01:39:01 --> Helper loaded: array_helper
INFO - 2019-07-12 01:39:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 01:39:01 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 01:39:01 --> Database Driver Class Initialized
INFO - 2019-07-12 01:39:01 --> Controller Class Initialized
INFO - 2019-07-12 07:39:01 --> Helper loaded: language_helper
INFO - 2019-07-12 07:39:01 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 07:39:01 --> Model Class Initialized
INFO - 2019-07-12 07:39:01 --> Model Class Initialized
INFO - 2019-07-12 07:39:01 --> Model Class Initialized
INFO - 2019-07-12 07:39:01 --> Model Class Initialized
ERROR - 2019-07-12 07:39:01 --> Severity: Error --> Call to undefined method Owners::check_required_fields() C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Owners.php 121
INFO - 2019-07-12 01:39:26 --> Config Class Initialized
INFO - 2019-07-12 01:39:26 --> Hooks Class Initialized
DEBUG - 2019-07-12 01:39:26 --> UTF-8 Support Enabled
INFO - 2019-07-12 01:39:26 --> Utf8 Class Initialized
INFO - 2019-07-12 01:39:26 --> URI Class Initialized
INFO - 2019-07-12 01:39:26 --> Router Class Initialized
INFO - 2019-07-12 01:39:26 --> Output Class Initialized
INFO - 2019-07-12 01:39:26 --> Security Class Initialized
DEBUG - 2019-07-12 01:39:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 01:39:26 --> Input Class Initialized
INFO - 2019-07-12 01:39:27 --> Language Class Initialized
INFO - 2019-07-12 01:39:27 --> Language Class Initialized
INFO - 2019-07-12 01:39:27 --> Config Class Initialized
INFO - 2019-07-12 01:39:27 --> Loader Class Initialized
DEBUG - 2019-07-12 01:39:27 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 01:39:27 --> Helper loaded: url_helper
INFO - 2019-07-12 01:39:27 --> Helper loaded: inflector_helper
INFO - 2019-07-12 01:39:27 --> Helper loaded: string_helper
INFO - 2019-07-12 01:39:27 --> Helper loaded: array_helper
INFO - 2019-07-12 01:39:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 01:39:27 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 01:39:27 --> Database Driver Class Initialized
INFO - 2019-07-12 01:39:27 --> Controller Class Initialized
INFO - 2019-07-12 07:39:27 --> Helper loaded: language_helper
INFO - 2019-07-12 07:39:27 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 07:39:27 --> Model Class Initialized
INFO - 2019-07-12 07:39:27 --> Model Class Initialized
INFO - 2019-07-12 07:39:27 --> Model Class Initialized
INFO - 2019-07-12 07:39:27 --> Model Class Initialized
INFO - 2019-07-12 07:39:27 --> Final output sent to browser
DEBUG - 2019-07-12 07:39:27 --> Total execution time: 0.5528
INFO - 2019-07-12 01:39:36 --> Config Class Initialized
INFO - 2019-07-12 01:39:36 --> Hooks Class Initialized
DEBUG - 2019-07-12 01:39:36 --> UTF-8 Support Enabled
INFO - 2019-07-12 01:39:36 --> Utf8 Class Initialized
INFO - 2019-07-12 01:39:36 --> URI Class Initialized
INFO - 2019-07-12 01:39:36 --> Router Class Initialized
INFO - 2019-07-12 01:39:36 --> Output Class Initialized
INFO - 2019-07-12 01:39:36 --> Security Class Initialized
DEBUG - 2019-07-12 01:39:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 01:39:36 --> Input Class Initialized
INFO - 2019-07-12 01:39:36 --> Language Class Initialized
INFO - 2019-07-12 01:39:36 --> Language Class Initialized
INFO - 2019-07-12 01:39:36 --> Config Class Initialized
INFO - 2019-07-12 01:39:36 --> Loader Class Initialized
DEBUG - 2019-07-12 01:39:36 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 01:39:36 --> Helper loaded: url_helper
INFO - 2019-07-12 01:39:36 --> Helper loaded: inflector_helper
INFO - 2019-07-12 01:39:36 --> Helper loaded: string_helper
INFO - 2019-07-12 01:39:36 --> Helper loaded: array_helper
INFO - 2019-07-12 01:39:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 01:39:36 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 01:39:36 --> Database Driver Class Initialized
INFO - 2019-07-12 01:39:36 --> Controller Class Initialized
INFO - 2019-07-12 07:39:36 --> Helper loaded: language_helper
INFO - 2019-07-12 07:39:36 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 07:39:37 --> Model Class Initialized
INFO - 2019-07-12 07:39:37 --> Model Class Initialized
INFO - 2019-07-12 07:39:37 --> Model Class Initialized
INFO - 2019-07-12 07:39:37 --> Model Class Initialized
INFO - 2019-07-12 07:39:37 --> Final output sent to browser
DEBUG - 2019-07-12 07:39:37 --> Total execution time: 0.6695
INFO - 2019-07-12 01:40:26 --> Config Class Initialized
INFO - 2019-07-12 01:40:26 --> Hooks Class Initialized
DEBUG - 2019-07-12 01:40:26 --> UTF-8 Support Enabled
INFO - 2019-07-12 01:40:26 --> Utf8 Class Initialized
INFO - 2019-07-12 01:40:26 --> URI Class Initialized
INFO - 2019-07-12 01:40:26 --> Router Class Initialized
INFO - 2019-07-12 01:40:26 --> Output Class Initialized
INFO - 2019-07-12 01:40:26 --> Security Class Initialized
DEBUG - 2019-07-12 01:40:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 01:40:26 --> Input Class Initialized
INFO - 2019-07-12 01:40:26 --> Language Class Initialized
INFO - 2019-07-12 01:40:26 --> Language Class Initialized
INFO - 2019-07-12 01:40:26 --> Config Class Initialized
INFO - 2019-07-12 01:40:26 --> Loader Class Initialized
DEBUG - 2019-07-12 01:40:26 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 01:40:26 --> Helper loaded: url_helper
INFO - 2019-07-12 01:40:26 --> Helper loaded: inflector_helper
INFO - 2019-07-12 01:40:26 --> Helper loaded: string_helper
INFO - 2019-07-12 01:40:26 --> Helper loaded: array_helper
INFO - 2019-07-12 01:40:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 01:40:26 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 01:40:26 --> Database Driver Class Initialized
INFO - 2019-07-12 01:40:26 --> Controller Class Initialized
INFO - 2019-07-12 07:40:26 --> Helper loaded: language_helper
INFO - 2019-07-12 07:40:26 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 07:40:26 --> Model Class Initialized
INFO - 2019-07-12 07:40:26 --> Model Class Initialized
INFO - 2019-07-12 07:40:26 --> Model Class Initialized
INFO - 2019-07-12 07:40:26 --> Model Class Initialized
INFO - 2019-07-12 07:40:26 --> Final output sent to browser
DEBUG - 2019-07-12 07:40:26 --> Total execution time: 0.5571
INFO - 2019-07-12 01:40:58 --> Config Class Initialized
INFO - 2019-07-12 01:40:58 --> Hooks Class Initialized
DEBUG - 2019-07-12 01:40:58 --> UTF-8 Support Enabled
INFO - 2019-07-12 01:40:59 --> Utf8 Class Initialized
INFO - 2019-07-12 01:40:59 --> URI Class Initialized
INFO - 2019-07-12 01:40:59 --> Router Class Initialized
INFO - 2019-07-12 01:40:59 --> Output Class Initialized
INFO - 2019-07-12 01:40:59 --> Security Class Initialized
DEBUG - 2019-07-12 01:40:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 01:40:59 --> Input Class Initialized
INFO - 2019-07-12 01:40:59 --> Language Class Initialized
INFO - 2019-07-12 01:40:59 --> Language Class Initialized
INFO - 2019-07-12 01:40:59 --> Config Class Initialized
INFO - 2019-07-12 01:40:59 --> Loader Class Initialized
DEBUG - 2019-07-12 01:40:59 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 01:40:59 --> Helper loaded: url_helper
INFO - 2019-07-12 01:40:59 --> Helper loaded: inflector_helper
INFO - 2019-07-12 01:40:59 --> Helper loaded: string_helper
INFO - 2019-07-12 01:40:59 --> Helper loaded: array_helper
INFO - 2019-07-12 01:40:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 01:40:59 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 01:40:59 --> Database Driver Class Initialized
INFO - 2019-07-12 01:40:59 --> Controller Class Initialized
INFO - 2019-07-12 07:40:59 --> Helper loaded: language_helper
INFO - 2019-07-12 07:40:59 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 07:40:59 --> Model Class Initialized
INFO - 2019-07-12 07:40:59 --> Model Class Initialized
INFO - 2019-07-12 07:40:59 --> Model Class Initialized
INFO - 2019-07-12 07:40:59 --> Model Class Initialized
INFO - 2019-07-12 07:40:59 --> Final output sent to browser
DEBUG - 2019-07-12 07:40:59 --> Total execution time: 0.6207
INFO - 2019-07-12 01:41:12 --> Config Class Initialized
INFO - 2019-07-12 01:41:12 --> Hooks Class Initialized
DEBUG - 2019-07-12 01:41:12 --> UTF-8 Support Enabled
INFO - 2019-07-12 01:41:12 --> Utf8 Class Initialized
INFO - 2019-07-12 01:41:12 --> URI Class Initialized
INFO - 2019-07-12 01:41:12 --> Router Class Initialized
INFO - 2019-07-12 01:41:12 --> Output Class Initialized
INFO - 2019-07-12 01:41:12 --> Security Class Initialized
DEBUG - 2019-07-12 01:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 01:41:12 --> Input Class Initialized
INFO - 2019-07-12 01:41:12 --> Language Class Initialized
INFO - 2019-07-12 01:41:12 --> Language Class Initialized
INFO - 2019-07-12 01:41:12 --> Config Class Initialized
INFO - 2019-07-12 01:41:12 --> Loader Class Initialized
DEBUG - 2019-07-12 01:41:12 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 01:41:12 --> Helper loaded: url_helper
INFO - 2019-07-12 01:41:12 --> Helper loaded: inflector_helper
INFO - 2019-07-12 01:41:12 --> Helper loaded: string_helper
INFO - 2019-07-12 01:41:12 --> Helper loaded: array_helper
INFO - 2019-07-12 01:41:12 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 01:41:12 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 01:41:12 --> Database Driver Class Initialized
INFO - 2019-07-12 01:41:12 --> Controller Class Initialized
INFO - 2019-07-12 07:41:12 --> Helper loaded: language_helper
INFO - 2019-07-12 07:41:12 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 07:41:12 --> Model Class Initialized
INFO - 2019-07-12 07:41:12 --> Model Class Initialized
INFO - 2019-07-12 07:41:12 --> Model Class Initialized
INFO - 2019-07-12 07:41:12 --> Model Class Initialized
INFO - 2019-07-12 07:41:12 --> Final output sent to browser
DEBUG - 2019-07-12 07:41:12 --> Total execution time: 0.5785
INFO - 2019-07-12 01:41:13 --> Config Class Initialized
INFO - 2019-07-12 01:41:13 --> Config Class Initialized
INFO - 2019-07-12 01:41:13 --> Hooks Class Initialized
INFO - 2019-07-12 01:41:13 --> Hooks Class Initialized
DEBUG - 2019-07-12 01:41:13 --> UTF-8 Support Enabled
INFO - 2019-07-12 01:41:13 --> Utf8 Class Initialized
DEBUG - 2019-07-12 01:41:13 --> UTF-8 Support Enabled
INFO - 2019-07-12 01:41:13 --> Utf8 Class Initialized
INFO - 2019-07-12 01:41:13 --> URI Class Initialized
INFO - 2019-07-12 01:41:13 --> URI Class Initialized
INFO - 2019-07-12 01:41:13 --> Router Class Initialized
INFO - 2019-07-12 01:41:13 --> Router Class Initialized
INFO - 2019-07-12 01:41:13 --> Output Class Initialized
INFO - 2019-07-12 01:41:13 --> Output Class Initialized
INFO - 2019-07-12 01:41:13 --> Security Class Initialized
INFO - 2019-07-12 01:41:13 --> Security Class Initialized
DEBUG - 2019-07-12 01:41:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-12 01:41:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 01:41:13 --> Input Class Initialized
INFO - 2019-07-12 01:41:13 --> Input Class Initialized
INFO - 2019-07-12 01:41:13 --> Language Class Initialized
INFO - 2019-07-12 01:41:13 --> Language Class Initialized
INFO - 2019-07-12 01:41:13 --> Language Class Initialized
INFO - 2019-07-12 01:41:13 --> Language Class Initialized
INFO - 2019-07-12 01:41:13 --> Config Class Initialized
INFO - 2019-07-12 01:41:13 --> Loader Class Initialized
INFO - 2019-07-12 01:41:13 --> Config Class Initialized
INFO - 2019-07-12 01:41:13 --> Loader Class Initialized
DEBUG - 2019-07-12 01:41:13 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-12 01:41:13 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 01:41:13 --> Helper loaded: url_helper
INFO - 2019-07-12 01:41:13 --> Helper loaded: url_helper
INFO - 2019-07-12 01:41:13 --> Helper loaded: inflector_helper
INFO - 2019-07-12 01:41:13 --> Helper loaded: inflector_helper
INFO - 2019-07-12 01:41:13 --> Helper loaded: string_helper
INFO - 2019-07-12 01:41:13 --> Helper loaded: string_helper
INFO - 2019-07-12 01:41:13 --> Helper loaded: array_helper
INFO - 2019-07-12 01:41:13 --> Helper loaded: array_helper
INFO - 2019-07-12 01:41:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 01:41:13 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 01:41:13 --> Database Driver Class Initialized
INFO - 2019-07-12 01:41:13 --> Controller Class Initialized
INFO - 2019-07-12 07:41:13 --> Helper loaded: language_helper
INFO - 2019-07-12 07:41:13 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 07:41:13 --> Model Class Initialized
INFO - 2019-07-12 07:41:13 --> Model Class Initialized
INFO - 2019-07-12 07:41:13 --> Model Class Initialized
INFO - 2019-07-12 07:41:13 --> Model Class Initialized
INFO - 2019-07-12 07:41:13 --> Final output sent to browser
DEBUG - 2019-07-12 07:41:13 --> Total execution time: 0.7871
INFO - 2019-07-12 01:41:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 01:41:14 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 01:41:14 --> Database Driver Class Initialized
INFO - 2019-07-12 01:41:14 --> Controller Class Initialized
INFO - 2019-07-12 07:41:14 --> Helper loaded: language_helper
INFO - 2019-07-12 07:41:14 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 07:41:14 --> Model Class Initialized
INFO - 2019-07-12 07:41:14 --> Model Class Initialized
INFO - 2019-07-12 07:41:14 --> Model Class Initialized
INFO - 2019-07-12 07:41:14 --> Model Class Initialized
INFO - 2019-07-12 07:41:14 --> Model Class Initialized
INFO - 2019-07-12 07:41:14 --> Final output sent to browser
DEBUG - 2019-07-12 07:41:14 --> Total execution time: 1.0746
INFO - 2019-07-12 01:41:33 --> Config Class Initialized
INFO - 2019-07-12 01:41:33 --> Hooks Class Initialized
DEBUG - 2019-07-12 01:41:33 --> UTF-8 Support Enabled
INFO - 2019-07-12 01:41:33 --> Utf8 Class Initialized
INFO - 2019-07-12 01:41:33 --> URI Class Initialized
INFO - 2019-07-12 01:41:33 --> Router Class Initialized
INFO - 2019-07-12 01:41:33 --> Output Class Initialized
INFO - 2019-07-12 01:41:33 --> Security Class Initialized
DEBUG - 2019-07-12 01:41:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 01:41:33 --> Input Class Initialized
INFO - 2019-07-12 01:41:33 --> Language Class Initialized
INFO - 2019-07-12 01:41:33 --> Language Class Initialized
INFO - 2019-07-12 01:41:33 --> Config Class Initialized
INFO - 2019-07-12 01:41:33 --> Loader Class Initialized
DEBUG - 2019-07-12 01:41:33 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 01:41:33 --> Helper loaded: url_helper
INFO - 2019-07-12 01:41:33 --> Helper loaded: inflector_helper
INFO - 2019-07-12 01:41:33 --> Helper loaded: string_helper
INFO - 2019-07-12 01:41:33 --> Helper loaded: array_helper
INFO - 2019-07-12 01:41:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 01:41:33 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 01:41:33 --> Database Driver Class Initialized
INFO - 2019-07-12 01:41:33 --> Controller Class Initialized
INFO - 2019-07-12 07:41:33 --> Helper loaded: language_helper
INFO - 2019-07-12 07:41:33 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 07:41:33 --> Model Class Initialized
INFO - 2019-07-12 07:41:33 --> Model Class Initialized
INFO - 2019-07-12 07:41:33 --> Model Class Initialized
INFO - 2019-07-12 07:41:33 --> Model Class Initialized
INFO - 2019-07-12 07:41:33 --> Final output sent to browser
DEBUG - 2019-07-12 07:41:33 --> Total execution time: 0.5009
INFO - 2019-07-12 01:41:52 --> Config Class Initialized
INFO - 2019-07-12 01:41:52 --> Hooks Class Initialized
DEBUG - 2019-07-12 01:41:52 --> UTF-8 Support Enabled
INFO - 2019-07-12 01:41:52 --> Utf8 Class Initialized
INFO - 2019-07-12 01:41:52 --> URI Class Initialized
INFO - 2019-07-12 01:41:52 --> Router Class Initialized
INFO - 2019-07-12 01:41:52 --> Output Class Initialized
INFO - 2019-07-12 01:41:52 --> Security Class Initialized
DEBUG - 2019-07-12 01:41:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 01:41:52 --> Input Class Initialized
INFO - 2019-07-12 01:41:52 --> Language Class Initialized
INFO - 2019-07-12 01:41:52 --> Language Class Initialized
INFO - 2019-07-12 01:41:52 --> Config Class Initialized
INFO - 2019-07-12 01:41:52 --> Loader Class Initialized
DEBUG - 2019-07-12 01:41:52 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 01:41:52 --> Helper loaded: url_helper
INFO - 2019-07-12 01:41:52 --> Helper loaded: inflector_helper
INFO - 2019-07-12 01:41:52 --> Helper loaded: string_helper
INFO - 2019-07-12 01:41:52 --> Helper loaded: array_helper
INFO - 2019-07-12 01:41:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 01:41:53 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 01:41:53 --> Database Driver Class Initialized
INFO - 2019-07-12 01:41:53 --> Controller Class Initialized
INFO - 2019-07-12 07:41:53 --> Helper loaded: language_helper
INFO - 2019-07-12 07:41:53 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 07:41:53 --> Model Class Initialized
INFO - 2019-07-12 07:41:53 --> Model Class Initialized
INFO - 2019-07-12 07:41:53 --> Model Class Initialized
INFO - 2019-07-12 07:41:53 --> Model Class Initialized
INFO - 2019-07-12 07:41:53 --> Final output sent to browser
DEBUG - 2019-07-12 07:41:53 --> Total execution time: 0.5590
INFO - 2019-07-12 01:41:53 --> Config Class Initialized
INFO - 2019-07-12 01:41:53 --> Config Class Initialized
INFO - 2019-07-12 01:41:53 --> Hooks Class Initialized
INFO - 2019-07-12 01:41:53 --> Hooks Class Initialized
DEBUG - 2019-07-12 01:41:53 --> UTF-8 Support Enabled
DEBUG - 2019-07-12 01:41:53 --> UTF-8 Support Enabled
INFO - 2019-07-12 01:41:53 --> Utf8 Class Initialized
INFO - 2019-07-12 01:41:53 --> Utf8 Class Initialized
INFO - 2019-07-12 01:41:53 --> URI Class Initialized
INFO - 2019-07-12 01:41:53 --> URI Class Initialized
INFO - 2019-07-12 01:41:53 --> Router Class Initialized
INFO - 2019-07-12 01:41:53 --> Router Class Initialized
INFO - 2019-07-12 01:41:53 --> Output Class Initialized
INFO - 2019-07-12 01:41:53 --> Output Class Initialized
INFO - 2019-07-12 01:41:53 --> Security Class Initialized
INFO - 2019-07-12 01:41:53 --> Security Class Initialized
DEBUG - 2019-07-12 01:41:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-12 01:41:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 01:41:53 --> Input Class Initialized
INFO - 2019-07-12 01:41:53 --> Input Class Initialized
INFO - 2019-07-12 01:41:53 --> Language Class Initialized
INFO - 2019-07-12 01:41:53 --> Language Class Initialized
INFO - 2019-07-12 01:41:53 --> Language Class Initialized
INFO - 2019-07-12 01:41:53 --> Language Class Initialized
INFO - 2019-07-12 01:41:53 --> Config Class Initialized
INFO - 2019-07-12 01:41:53 --> Loader Class Initialized
INFO - 2019-07-12 01:41:53 --> Config Class Initialized
INFO - 2019-07-12 01:41:53 --> Loader Class Initialized
DEBUG - 2019-07-12 01:41:53 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-12 01:41:53 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 01:41:53 --> Helper loaded: url_helper
INFO - 2019-07-12 01:41:54 --> Helper loaded: url_helper
INFO - 2019-07-12 01:41:54 --> Helper loaded: inflector_helper
INFO - 2019-07-12 01:41:54 --> Helper loaded: inflector_helper
INFO - 2019-07-12 01:41:54 --> Helper loaded: string_helper
INFO - 2019-07-12 01:41:54 --> Helper loaded: string_helper
INFO - 2019-07-12 01:41:54 --> Helper loaded: array_helper
INFO - 2019-07-12 01:41:54 --> Helper loaded: array_helper
INFO - 2019-07-12 01:41:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 01:41:54 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 01:41:54 --> Database Driver Class Initialized
INFO - 2019-07-12 01:41:54 --> Controller Class Initialized
INFO - 2019-07-12 07:41:54 --> Helper loaded: language_helper
INFO - 2019-07-12 07:41:54 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 07:41:54 --> Model Class Initialized
INFO - 2019-07-12 07:41:54 --> Model Class Initialized
INFO - 2019-07-12 07:41:54 --> Model Class Initialized
INFO - 2019-07-12 07:41:54 --> Model Class Initialized
INFO - 2019-07-12 07:41:54 --> Model Class Initialized
INFO - 2019-07-12 07:41:54 --> Final output sent to browser
DEBUG - 2019-07-12 07:41:54 --> Total execution time: 0.8129
INFO - 2019-07-12 01:41:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 01:41:54 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 01:41:54 --> Database Driver Class Initialized
INFO - 2019-07-12 01:41:54 --> Controller Class Initialized
INFO - 2019-07-12 07:41:54 --> Helper loaded: language_helper
INFO - 2019-07-12 07:41:54 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 07:41:54 --> Model Class Initialized
INFO - 2019-07-12 07:41:54 --> Model Class Initialized
INFO - 2019-07-12 07:41:54 --> Model Class Initialized
INFO - 2019-07-12 07:41:54 --> Model Class Initialized
INFO - 2019-07-12 07:41:54 --> Final output sent to browser
DEBUG - 2019-07-12 07:41:54 --> Total execution time: 1.0240
INFO - 2019-07-12 01:44:49 --> Config Class Initialized
INFO - 2019-07-12 01:44:49 --> Hooks Class Initialized
DEBUG - 2019-07-12 01:44:50 --> UTF-8 Support Enabled
INFO - 2019-07-12 01:44:50 --> Utf8 Class Initialized
INFO - 2019-07-12 01:44:50 --> URI Class Initialized
INFO - 2019-07-12 01:44:50 --> Router Class Initialized
INFO - 2019-07-12 01:44:50 --> Output Class Initialized
INFO - 2019-07-12 01:44:50 --> Security Class Initialized
DEBUG - 2019-07-12 01:44:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 01:44:50 --> Input Class Initialized
INFO - 2019-07-12 01:44:50 --> Language Class Initialized
INFO - 2019-07-12 01:44:50 --> Language Class Initialized
INFO - 2019-07-12 01:44:50 --> Config Class Initialized
INFO - 2019-07-12 01:44:50 --> Loader Class Initialized
DEBUG - 2019-07-12 01:44:50 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 01:44:50 --> Helper loaded: url_helper
INFO - 2019-07-12 01:44:50 --> Helper loaded: inflector_helper
INFO - 2019-07-12 01:44:50 --> Helper loaded: string_helper
INFO - 2019-07-12 01:44:50 --> Helper loaded: array_helper
INFO - 2019-07-12 01:44:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 01:44:50 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 01:44:50 --> Database Driver Class Initialized
INFO - 2019-07-12 01:44:50 --> Controller Class Initialized
INFO - 2019-07-12 07:44:50 --> Helper loaded: language_helper
INFO - 2019-07-12 07:44:50 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 07:44:50 --> Model Class Initialized
INFO - 2019-07-12 07:44:50 --> Model Class Initialized
INFO - 2019-07-12 07:44:50 --> Model Class Initialized
INFO - 2019-07-12 07:44:50 --> Model Class Initialized
INFO - 2019-07-12 07:44:50 --> Final output sent to browser
DEBUG - 2019-07-12 07:44:50 --> Total execution time: 0.5381
INFO - 2019-07-12 01:47:54 --> Config Class Initialized
INFO - 2019-07-12 01:47:54 --> Hooks Class Initialized
DEBUG - 2019-07-12 01:47:54 --> UTF-8 Support Enabled
INFO - 2019-07-12 01:47:54 --> Utf8 Class Initialized
INFO - 2019-07-12 01:47:54 --> URI Class Initialized
INFO - 2019-07-12 01:47:54 --> Router Class Initialized
INFO - 2019-07-12 01:47:54 --> Output Class Initialized
INFO - 2019-07-12 01:47:54 --> Security Class Initialized
DEBUG - 2019-07-12 01:47:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 01:47:54 --> Input Class Initialized
INFO - 2019-07-12 01:47:54 --> Language Class Initialized
INFO - 2019-07-12 01:47:54 --> Language Class Initialized
INFO - 2019-07-12 01:47:54 --> Config Class Initialized
INFO - 2019-07-12 01:47:54 --> Loader Class Initialized
DEBUG - 2019-07-12 01:47:54 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 01:47:54 --> Helper loaded: url_helper
INFO - 2019-07-12 01:47:54 --> Helper loaded: inflector_helper
INFO - 2019-07-12 01:47:54 --> Helper loaded: string_helper
INFO - 2019-07-12 01:47:54 --> Helper loaded: array_helper
INFO - 2019-07-12 01:47:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 01:47:54 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 01:47:54 --> Database Driver Class Initialized
INFO - 2019-07-12 01:47:54 --> Controller Class Initialized
INFO - 2019-07-12 07:47:54 --> Helper loaded: language_helper
INFO - 2019-07-12 07:47:54 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 07:47:54 --> Model Class Initialized
INFO - 2019-07-12 07:47:55 --> Model Class Initialized
INFO - 2019-07-12 07:47:55 --> Model Class Initialized
INFO - 2019-07-12 07:47:55 --> Model Class Initialized
INFO - 2019-07-12 07:47:55 --> Final output sent to browser
DEBUG - 2019-07-12 07:47:55 --> Total execution time: 0.6073
INFO - 2019-07-12 01:49:09 --> Config Class Initialized
INFO - 2019-07-12 01:49:09 --> Hooks Class Initialized
DEBUG - 2019-07-12 01:49:09 --> UTF-8 Support Enabled
INFO - 2019-07-12 01:49:09 --> Utf8 Class Initialized
INFO - 2019-07-12 01:49:09 --> URI Class Initialized
INFO - 2019-07-12 01:49:09 --> Router Class Initialized
INFO - 2019-07-12 01:49:09 --> Output Class Initialized
INFO - 2019-07-12 01:49:09 --> Security Class Initialized
DEBUG - 2019-07-12 01:49:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 01:49:10 --> Input Class Initialized
INFO - 2019-07-12 01:49:10 --> Language Class Initialized
INFO - 2019-07-12 01:49:10 --> Language Class Initialized
INFO - 2019-07-12 01:49:10 --> Config Class Initialized
INFO - 2019-07-12 01:49:10 --> Loader Class Initialized
DEBUG - 2019-07-12 01:49:10 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 01:49:10 --> Helper loaded: url_helper
INFO - 2019-07-12 01:49:10 --> Helper loaded: inflector_helper
INFO - 2019-07-12 01:49:10 --> Helper loaded: string_helper
INFO - 2019-07-12 01:49:10 --> Helper loaded: array_helper
INFO - 2019-07-12 01:49:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 01:49:10 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 01:49:10 --> Database Driver Class Initialized
INFO - 2019-07-12 01:49:10 --> Controller Class Initialized
INFO - 2019-07-12 07:49:10 --> Helper loaded: language_helper
INFO - 2019-07-12 07:49:10 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 07:49:10 --> Model Class Initialized
INFO - 2019-07-12 07:49:10 --> Model Class Initialized
INFO - 2019-07-12 07:49:10 --> Model Class Initialized
INFO - 2019-07-12 07:49:10 --> Model Class Initialized
INFO - 2019-07-12 07:49:10 --> Final output sent to browser
DEBUG - 2019-07-12 07:49:10 --> Total execution time: 0.5372
INFO - 2019-07-12 01:49:37 --> Config Class Initialized
INFO - 2019-07-12 01:49:37 --> Hooks Class Initialized
DEBUG - 2019-07-12 01:49:37 --> UTF-8 Support Enabled
INFO - 2019-07-12 01:49:37 --> Utf8 Class Initialized
INFO - 2019-07-12 01:49:37 --> URI Class Initialized
INFO - 2019-07-12 01:49:37 --> Router Class Initialized
INFO - 2019-07-12 01:49:37 --> Output Class Initialized
INFO - 2019-07-12 01:49:37 --> Security Class Initialized
DEBUG - 2019-07-12 01:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 01:49:37 --> Input Class Initialized
INFO - 2019-07-12 01:49:37 --> Language Class Initialized
INFO - 2019-07-12 01:49:37 --> Language Class Initialized
INFO - 2019-07-12 01:49:37 --> Config Class Initialized
INFO - 2019-07-12 01:49:37 --> Loader Class Initialized
DEBUG - 2019-07-12 01:49:37 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 01:49:37 --> Helper loaded: url_helper
INFO - 2019-07-12 01:49:37 --> Helper loaded: inflector_helper
INFO - 2019-07-12 01:49:37 --> Helper loaded: string_helper
INFO - 2019-07-12 01:49:37 --> Helper loaded: array_helper
INFO - 2019-07-12 01:49:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 01:49:37 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 01:49:38 --> Database Driver Class Initialized
INFO - 2019-07-12 01:49:38 --> Controller Class Initialized
INFO - 2019-07-12 07:49:38 --> Helper loaded: language_helper
INFO - 2019-07-12 07:49:38 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 07:49:38 --> Model Class Initialized
INFO - 2019-07-12 07:49:38 --> Model Class Initialized
INFO - 2019-07-12 07:49:38 --> Model Class Initialized
INFO - 2019-07-12 07:49:38 --> Model Class Initialized
INFO - 2019-07-12 07:49:38 --> Model Class Initialized
INFO - 2019-07-12 07:49:38 --> Final output sent to browser
DEBUG - 2019-07-12 07:49:38 --> Total execution time: 0.5352
INFO - 2019-07-12 01:49:44 --> Config Class Initialized
INFO - 2019-07-12 01:49:44 --> Hooks Class Initialized
DEBUG - 2019-07-12 01:49:44 --> UTF-8 Support Enabled
INFO - 2019-07-12 01:49:44 --> Utf8 Class Initialized
INFO - 2019-07-12 01:49:44 --> URI Class Initialized
INFO - 2019-07-12 01:49:44 --> Router Class Initialized
INFO - 2019-07-12 01:49:44 --> Output Class Initialized
INFO - 2019-07-12 01:49:44 --> Security Class Initialized
DEBUG - 2019-07-12 01:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 01:49:44 --> Input Class Initialized
INFO - 2019-07-12 01:49:44 --> Language Class Initialized
INFO - 2019-07-12 01:49:44 --> Language Class Initialized
INFO - 2019-07-12 01:49:44 --> Config Class Initialized
INFO - 2019-07-12 01:49:44 --> Loader Class Initialized
DEBUG - 2019-07-12 01:49:44 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 01:49:44 --> Helper loaded: url_helper
INFO - 2019-07-12 01:49:44 --> Helper loaded: inflector_helper
INFO - 2019-07-12 01:49:44 --> Helper loaded: string_helper
INFO - 2019-07-12 01:49:44 --> Helper loaded: array_helper
INFO - 2019-07-12 01:49:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 01:49:44 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 01:49:45 --> Database Driver Class Initialized
INFO - 2019-07-12 01:49:45 --> Controller Class Initialized
INFO - 2019-07-12 07:49:45 --> Helper loaded: language_helper
INFO - 2019-07-12 07:49:45 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 07:49:45 --> Model Class Initialized
INFO - 2019-07-12 07:49:45 --> Model Class Initialized
INFO - 2019-07-12 07:49:45 --> Model Class Initialized
INFO - 2019-07-12 07:49:45 --> Model Class Initialized
INFO - 2019-07-12 07:49:45 --> Model Class Initialized
INFO - 2019-07-12 07:49:45 --> Final output sent to browser
DEBUG - 2019-07-12 07:49:45 --> Total execution time: 0.5350
INFO - 2019-07-12 01:50:04 --> Config Class Initialized
INFO - 2019-07-12 01:50:04 --> Hooks Class Initialized
DEBUG - 2019-07-12 01:50:04 --> UTF-8 Support Enabled
INFO - 2019-07-12 01:50:04 --> Utf8 Class Initialized
INFO - 2019-07-12 01:50:04 --> URI Class Initialized
INFO - 2019-07-12 01:50:04 --> Router Class Initialized
INFO - 2019-07-12 01:50:04 --> Output Class Initialized
INFO - 2019-07-12 01:50:04 --> Security Class Initialized
DEBUG - 2019-07-12 01:50:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 01:50:04 --> Input Class Initialized
INFO - 2019-07-12 01:50:04 --> Language Class Initialized
INFO - 2019-07-12 01:50:04 --> Language Class Initialized
INFO - 2019-07-12 01:50:04 --> Config Class Initialized
INFO - 2019-07-12 01:50:04 --> Loader Class Initialized
DEBUG - 2019-07-12 01:50:04 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 01:50:04 --> Helper loaded: url_helper
INFO - 2019-07-12 01:50:04 --> Helper loaded: inflector_helper
INFO - 2019-07-12 01:50:05 --> Helper loaded: string_helper
INFO - 2019-07-12 01:50:05 --> Helper loaded: array_helper
INFO - 2019-07-12 01:50:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 01:50:05 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 01:50:05 --> Database Driver Class Initialized
INFO - 2019-07-12 01:50:05 --> Controller Class Initialized
INFO - 2019-07-12 07:50:05 --> Helper loaded: language_helper
INFO - 2019-07-12 07:50:05 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 07:50:05 --> Model Class Initialized
INFO - 2019-07-12 07:50:05 --> Model Class Initialized
INFO - 2019-07-12 07:50:05 --> Model Class Initialized
INFO - 2019-07-12 07:50:05 --> Model Class Initialized
INFO - 2019-07-12 07:50:05 --> Model Class Initialized
INFO - 2019-07-12 07:50:05 --> Final output sent to browser
DEBUG - 2019-07-12 07:50:05 --> Total execution time: 0.5696
INFO - 2019-07-12 01:50:22 --> Config Class Initialized
INFO - 2019-07-12 01:50:22 --> Config Class Initialized
INFO - 2019-07-12 01:50:22 --> Hooks Class Initialized
INFO - 2019-07-12 01:50:22 --> Hooks Class Initialized
DEBUG - 2019-07-12 01:50:22 --> UTF-8 Support Enabled
DEBUG - 2019-07-12 01:50:22 --> UTF-8 Support Enabled
INFO - 2019-07-12 01:50:22 --> Utf8 Class Initialized
INFO - 2019-07-12 01:50:22 --> Utf8 Class Initialized
INFO - 2019-07-12 01:50:22 --> URI Class Initialized
INFO - 2019-07-12 01:50:22 --> URI Class Initialized
INFO - 2019-07-12 01:50:22 --> Router Class Initialized
INFO - 2019-07-12 01:50:22 --> Output Class Initialized
INFO - 2019-07-12 01:50:22 --> Router Class Initialized
INFO - 2019-07-12 01:50:22 --> Security Class Initialized
INFO - 2019-07-12 01:50:22 --> Output Class Initialized
DEBUG - 2019-07-12 01:50:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 01:50:22 --> Security Class Initialized
INFO - 2019-07-12 01:50:22 --> Input Class Initialized
INFO - 2019-07-12 01:50:22 --> Language Class Initialized
DEBUG - 2019-07-12 01:50:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 01:50:22 --> Language Class Initialized
INFO - 2019-07-12 01:50:22 --> Input Class Initialized
INFO - 2019-07-12 01:50:22 --> Config Class Initialized
INFO - 2019-07-12 01:50:22 --> Language Class Initialized
INFO - 2019-07-12 01:50:22 --> Loader Class Initialized
DEBUG - 2019-07-12 01:50:22 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 01:50:22 --> Language Class Initialized
INFO - 2019-07-12 01:50:22 --> Helper loaded: url_helper
INFO - 2019-07-12 01:50:22 --> Config Class Initialized
INFO - 2019-07-12 01:50:22 --> Loader Class Initialized
INFO - 2019-07-12 01:50:22 --> Helper loaded: inflector_helper
DEBUG - 2019-07-12 01:50:22 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 01:50:22 --> Helper loaded: string_helper
INFO - 2019-07-12 01:50:22 --> Helper loaded: url_helper
INFO - 2019-07-12 01:50:22 --> Helper loaded: array_helper
INFO - 2019-07-12 01:50:22 --> Helper loaded: inflector_helper
INFO - 2019-07-12 01:50:22 --> Session: Class initialized using 'files' driver.
INFO - 2019-07-12 01:50:22 --> Helper loaded: string_helper
DEBUG - 2019-07-12 01:50:22 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 01:50:22 --> Helper loaded: array_helper
INFO - 2019-07-12 01:50:22 --> Database Driver Class Initialized
INFO - 2019-07-12 01:50:22 --> Controller Class Initialized
INFO - 2019-07-12 07:50:22 --> Helper loaded: language_helper
INFO - 2019-07-12 07:50:22 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 07:50:22 --> Model Class Initialized
INFO - 2019-07-12 07:50:22 --> Model Class Initialized
INFO - 2019-07-12 07:50:22 --> Model Class Initialized
INFO - 2019-07-12 07:50:22 --> Model Class Initialized
INFO - 2019-07-12 07:50:22 --> Final output sent to browser
DEBUG - 2019-07-12 07:50:22 --> Total execution time: 0.6955
INFO - 2019-07-12 01:50:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 01:50:22 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 01:50:23 --> Database Driver Class Initialized
INFO - 2019-07-12 01:50:23 --> Controller Class Initialized
INFO - 2019-07-12 07:50:23 --> Helper loaded: language_helper
INFO - 2019-07-12 01:50:23 --> Config Class Initialized
INFO - 2019-07-12 07:50:23 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:50:23 --> Hooks Class Initialized
INFO - 2019-07-12 07:50:23 --> Model Class Initialized
DEBUG - 2019-07-12 01:50:23 --> UTF-8 Support Enabled
INFO - 2019-07-12 07:50:23 --> Model Class Initialized
INFO - 2019-07-12 01:50:23 --> Utf8 Class Initialized
INFO - 2019-07-12 01:50:23 --> URI Class Initialized
INFO - 2019-07-12 01:50:23 --> Router Class Initialized
INFO - 2019-07-12 07:50:23 --> Model Class Initialized
INFO - 2019-07-12 01:50:23 --> Output Class Initialized
INFO - 2019-07-12 07:50:23 --> Model Class Initialized
INFO - 2019-07-12 01:50:23 --> Security Class Initialized
INFO - 2019-07-12 07:50:23 --> Model Class Initialized
DEBUG - 2019-07-12 01:50:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 07:50:23 --> Final output sent to browser
INFO - 2019-07-12 01:50:23 --> Input Class Initialized
DEBUG - 2019-07-12 07:50:23 --> Total execution time: 1.2414
INFO - 2019-07-12 01:50:23 --> Language Class Initialized
INFO - 2019-07-12 01:50:23 --> Language Class Initialized
INFO - 2019-07-12 01:50:23 --> Config Class Initialized
INFO - 2019-07-12 01:50:23 --> Loader Class Initialized
DEBUG - 2019-07-12 01:50:23 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 01:50:23 --> Helper loaded: url_helper
INFO - 2019-07-12 01:50:23 --> Helper loaded: inflector_helper
INFO - 2019-07-12 01:50:23 --> Helper loaded: string_helper
INFO - 2019-07-12 01:50:23 --> Helper loaded: array_helper
INFO - 2019-07-12 01:50:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 01:50:23 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 01:50:23 --> Database Driver Class Initialized
INFO - 2019-07-12 01:50:23 --> Controller Class Initialized
INFO - 2019-07-12 07:50:23 --> Helper loaded: language_helper
INFO - 2019-07-12 07:50:23 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 07:50:23 --> Model Class Initialized
INFO - 2019-07-12 07:50:23 --> Model Class Initialized
INFO - 2019-07-12 07:50:23 --> Model Class Initialized
INFO - 2019-07-12 07:50:23 --> Model Class Initialized
INFO - 2019-07-12 07:50:23 --> Final output sent to browser
DEBUG - 2019-07-12 07:50:23 --> Total execution time: 0.6326
INFO - 2019-07-12 01:50:26 --> Config Class Initialized
INFO - 2019-07-12 01:50:26 --> Hooks Class Initialized
DEBUG - 2019-07-12 01:50:26 --> UTF-8 Support Enabled
INFO - 2019-07-12 01:50:26 --> Utf8 Class Initialized
INFO - 2019-07-12 01:50:26 --> URI Class Initialized
INFO - 2019-07-12 01:50:26 --> Router Class Initialized
INFO - 2019-07-12 01:50:26 --> Output Class Initialized
INFO - 2019-07-12 01:50:26 --> Security Class Initialized
DEBUG - 2019-07-12 01:50:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 01:50:26 --> Input Class Initialized
INFO - 2019-07-12 01:50:26 --> Language Class Initialized
INFO - 2019-07-12 01:50:26 --> Language Class Initialized
INFO - 2019-07-12 01:50:26 --> Config Class Initialized
INFO - 2019-07-12 01:50:26 --> Loader Class Initialized
DEBUG - 2019-07-12 01:50:26 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 01:50:26 --> Helper loaded: url_helper
INFO - 2019-07-12 01:50:26 --> Helper loaded: inflector_helper
INFO - 2019-07-12 01:50:26 --> Helper loaded: string_helper
INFO - 2019-07-12 01:50:26 --> Helper loaded: array_helper
INFO - 2019-07-12 01:50:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 01:50:26 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 01:50:26 --> Database Driver Class Initialized
INFO - 2019-07-12 01:50:26 --> Controller Class Initialized
INFO - 2019-07-12 07:50:26 --> Helper loaded: language_helper
INFO - 2019-07-12 07:50:26 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 07:50:26 --> Model Class Initialized
INFO - 2019-07-12 07:50:26 --> Model Class Initialized
INFO - 2019-07-12 07:50:26 --> Model Class Initialized
INFO - 2019-07-12 07:50:26 --> Model Class Initialized
INFO - 2019-07-12 07:50:26 --> Final output sent to browser
DEBUG - 2019-07-12 07:50:26 --> Total execution time: 0.5457
INFO - 2019-07-12 01:50:38 --> Config Class Initialized
INFO - 2019-07-12 01:50:38 --> Hooks Class Initialized
DEBUG - 2019-07-12 01:50:38 --> UTF-8 Support Enabled
INFO - 2019-07-12 01:50:38 --> Utf8 Class Initialized
INFO - 2019-07-12 01:50:38 --> URI Class Initialized
INFO - 2019-07-12 01:50:38 --> Router Class Initialized
INFO - 2019-07-12 01:50:38 --> Output Class Initialized
INFO - 2019-07-12 01:50:38 --> Security Class Initialized
DEBUG - 2019-07-12 01:50:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 01:50:38 --> Input Class Initialized
INFO - 2019-07-12 01:50:38 --> Language Class Initialized
INFO - 2019-07-12 01:50:38 --> Language Class Initialized
INFO - 2019-07-12 01:50:38 --> Config Class Initialized
INFO - 2019-07-12 01:50:38 --> Loader Class Initialized
DEBUG - 2019-07-12 01:50:38 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 01:50:38 --> Helper loaded: url_helper
INFO - 2019-07-12 01:50:38 --> Helper loaded: inflector_helper
INFO - 2019-07-12 01:50:38 --> Helper loaded: string_helper
INFO - 2019-07-12 01:50:38 --> Helper loaded: array_helper
INFO - 2019-07-12 01:50:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 01:50:38 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 01:50:38 --> Database Driver Class Initialized
INFO - 2019-07-12 01:50:38 --> Controller Class Initialized
INFO - 2019-07-12 07:50:38 --> Helper loaded: language_helper
INFO - 2019-07-12 07:50:39 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 07:50:39 --> Model Class Initialized
INFO - 2019-07-12 07:50:39 --> Model Class Initialized
INFO - 2019-07-12 07:50:39 --> Model Class Initialized
INFO - 2019-07-12 07:50:39 --> Model Class Initialized
INFO - 2019-07-12 07:50:39 --> Final output sent to browser
DEBUG - 2019-07-12 07:50:39 --> Total execution time: 0.5999
INFO - 2019-07-12 01:50:50 --> Config Class Initialized
INFO - 2019-07-12 01:50:50 --> Hooks Class Initialized
DEBUG - 2019-07-12 01:50:50 --> UTF-8 Support Enabled
INFO - 2019-07-12 01:50:50 --> Utf8 Class Initialized
INFO - 2019-07-12 01:50:50 --> URI Class Initialized
INFO - 2019-07-12 01:50:50 --> Router Class Initialized
INFO - 2019-07-12 01:50:50 --> Output Class Initialized
INFO - 2019-07-12 01:50:50 --> Security Class Initialized
DEBUG - 2019-07-12 01:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 01:50:50 --> Input Class Initialized
INFO - 2019-07-12 01:50:50 --> Language Class Initialized
INFO - 2019-07-12 01:50:50 --> Language Class Initialized
INFO - 2019-07-12 01:50:50 --> Config Class Initialized
INFO - 2019-07-12 01:50:50 --> Loader Class Initialized
DEBUG - 2019-07-12 01:50:50 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 01:50:50 --> Helper loaded: url_helper
INFO - 2019-07-12 01:50:50 --> Helper loaded: inflector_helper
INFO - 2019-07-12 01:50:50 --> Helper loaded: string_helper
INFO - 2019-07-12 01:50:50 --> Helper loaded: array_helper
INFO - 2019-07-12 01:50:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 01:50:51 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 01:50:51 --> Database Driver Class Initialized
INFO - 2019-07-12 01:50:51 --> Controller Class Initialized
INFO - 2019-07-12 07:50:51 --> Helper loaded: language_helper
INFO - 2019-07-12 07:50:51 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 07:50:51 --> Model Class Initialized
INFO - 2019-07-12 07:50:51 --> Model Class Initialized
INFO - 2019-07-12 07:50:51 --> Model Class Initialized
INFO - 2019-07-12 07:50:51 --> Model Class Initialized
INFO - 2019-07-12 07:50:51 --> Final output sent to browser
DEBUG - 2019-07-12 07:50:51 --> Total execution time: 0.5759
INFO - 2019-07-12 01:51:08 --> Config Class Initialized
INFO - 2019-07-12 01:51:08 --> Hooks Class Initialized
DEBUG - 2019-07-12 01:51:08 --> UTF-8 Support Enabled
INFO - 2019-07-12 01:51:08 --> Utf8 Class Initialized
INFO - 2019-07-12 01:51:08 --> URI Class Initialized
INFO - 2019-07-12 01:51:08 --> Router Class Initialized
INFO - 2019-07-12 01:51:08 --> Output Class Initialized
INFO - 2019-07-12 01:51:08 --> Security Class Initialized
DEBUG - 2019-07-12 01:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 01:51:08 --> Input Class Initialized
INFO - 2019-07-12 01:51:08 --> Language Class Initialized
INFO - 2019-07-12 01:51:08 --> Language Class Initialized
INFO - 2019-07-12 01:51:08 --> Config Class Initialized
INFO - 2019-07-12 01:51:08 --> Loader Class Initialized
DEBUG - 2019-07-12 01:51:08 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 01:51:08 --> Helper loaded: url_helper
INFO - 2019-07-12 01:51:08 --> Helper loaded: inflector_helper
INFO - 2019-07-12 01:51:08 --> Helper loaded: string_helper
INFO - 2019-07-12 01:51:08 --> Helper loaded: array_helper
INFO - 2019-07-12 01:51:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 01:51:08 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 01:51:08 --> Database Driver Class Initialized
INFO - 2019-07-12 01:51:08 --> Controller Class Initialized
INFO - 2019-07-12 07:51:09 --> Helper loaded: language_helper
INFO - 2019-07-12 07:51:09 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 07:51:09 --> Model Class Initialized
INFO - 2019-07-12 07:51:09 --> Model Class Initialized
INFO - 2019-07-12 07:51:09 --> Model Class Initialized
INFO - 2019-07-12 07:51:09 --> Model Class Initialized
INFO - 2019-07-12 07:51:09 --> Final output sent to browser
DEBUG - 2019-07-12 07:51:09 --> Total execution time: 0.5986
INFO - 2019-07-12 01:51:10 --> Config Class Initialized
INFO - 2019-07-12 01:51:10 --> Config Class Initialized
INFO - 2019-07-12 01:51:10 --> Hooks Class Initialized
INFO - 2019-07-12 01:51:10 --> Hooks Class Initialized
DEBUG - 2019-07-12 01:51:10 --> UTF-8 Support Enabled
INFO - 2019-07-12 01:51:10 --> Config Class Initialized
INFO - 2019-07-12 01:51:10 --> Utf8 Class Initialized
DEBUG - 2019-07-12 01:51:10 --> UTF-8 Support Enabled
INFO - 2019-07-12 01:51:10 --> Utf8 Class Initialized
INFO - 2019-07-12 01:51:10 --> Hooks Class Initialized
INFO - 2019-07-12 01:51:10 --> URI Class Initialized
INFO - 2019-07-12 01:51:10 --> URI Class Initialized
DEBUG - 2019-07-12 01:51:10 --> UTF-8 Support Enabled
INFO - 2019-07-12 01:51:10 --> Utf8 Class Initialized
INFO - 2019-07-12 01:51:10 --> Router Class Initialized
INFO - 2019-07-12 01:51:10 --> URI Class Initialized
INFO - 2019-07-12 01:51:10 --> Router Class Initialized
INFO - 2019-07-12 01:51:10 --> Output Class Initialized
INFO - 2019-07-12 01:51:10 --> Output Class Initialized
INFO - 2019-07-12 01:51:10 --> Router Class Initialized
INFO - 2019-07-12 01:51:10 --> Security Class Initialized
INFO - 2019-07-12 01:51:10 --> Output Class Initialized
INFO - 2019-07-12 01:51:10 --> Security Class Initialized
DEBUG - 2019-07-12 01:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 01:51:10 --> Security Class Initialized
DEBUG - 2019-07-12 01:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 01:51:10 --> Input Class Initialized
INFO - 2019-07-12 01:51:10 --> Input Class Initialized
INFO - 2019-07-12 01:51:10 --> Language Class Initialized
DEBUG - 2019-07-12 01:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 01:51:10 --> Language Class Initialized
INFO - 2019-07-12 01:51:10 --> Input Class Initialized
INFO - 2019-07-12 01:51:10 --> Language Class Initialized
INFO - 2019-07-12 01:51:10 --> Language Class Initialized
INFO - 2019-07-12 01:51:10 --> Config Class Initialized
INFO - 2019-07-12 01:51:10 --> Language Class Initialized
INFO - 2019-07-12 01:51:11 --> Loader Class Initialized
INFO - 2019-07-12 01:51:11 --> Config Class Initialized
INFO - 2019-07-12 01:51:11 --> Language Class Initialized
INFO - 2019-07-12 01:51:11 --> Loader Class Initialized
DEBUG - 2019-07-12 01:51:11 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-12 01:51:11 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 01:51:11 --> Config Class Initialized
INFO - 2019-07-12 01:51:11 --> Helper loaded: url_helper
INFO - 2019-07-12 01:51:11 --> Loader Class Initialized
INFO - 2019-07-12 01:51:11 --> Helper loaded: url_helper
DEBUG - 2019-07-12 01:51:11 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 01:51:11 --> Helper loaded: inflector_helper
INFO - 2019-07-12 01:51:11 --> Helper loaded: inflector_helper
INFO - 2019-07-12 01:51:11 --> Helper loaded: string_helper
INFO - 2019-07-12 01:51:11 --> Helper loaded: url_helper
INFO - 2019-07-12 01:51:11 --> Helper loaded: string_helper
INFO - 2019-07-12 01:51:11 --> Helper loaded: inflector_helper
INFO - 2019-07-12 01:51:11 --> Helper loaded: array_helper
INFO - 2019-07-12 01:51:11 --> Helper loaded: array_helper
INFO - 2019-07-12 01:51:11 --> Helper loaded: string_helper
INFO - 2019-07-12 01:51:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 01:51:11 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 01:51:11 --> Helper loaded: array_helper
INFO - 2019-07-12 01:51:11 --> Database Driver Class Initialized
INFO - 2019-07-12 01:51:11 --> Controller Class Initialized
INFO - 2019-07-12 07:51:11 --> Helper loaded: language_helper
INFO - 2019-07-12 07:51:11 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 07:51:11 --> Model Class Initialized
INFO - 2019-07-12 07:51:11 --> Model Class Initialized
INFO - 2019-07-12 07:51:11 --> Model Class Initialized
INFO - 2019-07-12 07:51:11 --> Model Class Initialized
INFO - 2019-07-12 07:51:11 --> Model Class Initialized
INFO - 2019-07-12 07:51:11 --> Final output sent to browser
DEBUG - 2019-07-12 07:51:11 --> Total execution time: 0.8135
INFO - 2019-07-12 01:51:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 01:51:11 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 01:51:11 --> Database Driver Class Initialized
INFO - 2019-07-12 01:51:11 --> Controller Class Initialized
INFO - 2019-07-12 07:51:11 --> Helper loaded: language_helper
INFO - 2019-07-12 07:51:11 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 07:51:11 --> Model Class Initialized
INFO - 2019-07-12 07:51:11 --> Model Class Initialized
INFO - 2019-07-12 07:51:11 --> Model Class Initialized
INFO - 2019-07-12 07:51:11 --> Model Class Initialized
INFO - 2019-07-12 07:51:11 --> Final output sent to browser
DEBUG - 2019-07-12 07:51:11 --> Total execution time: 1.0639
INFO - 2019-07-12 01:51:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 01:51:11 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 01:51:11 --> Database Driver Class Initialized
INFO - 2019-07-12 01:51:11 --> Controller Class Initialized
INFO - 2019-07-12 07:51:11 --> Helper loaded: language_helper
INFO - 2019-07-12 01:51:11 --> Config Class Initialized
INFO - 2019-07-12 07:51:11 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 01:51:11 --> Hooks Class Initialized
INFO - 2019-07-12 07:51:11 --> Model Class Initialized
DEBUG - 2019-07-12 01:51:11 --> UTF-8 Support Enabled
INFO - 2019-07-12 07:51:11 --> Model Class Initialized
INFO - 2019-07-12 01:51:11 --> Utf8 Class Initialized
INFO - 2019-07-12 01:51:11 --> URI Class Initialized
INFO - 2019-07-12 07:51:12 --> Model Class Initialized
INFO - 2019-07-12 01:51:12 --> Router Class Initialized
INFO - 2019-07-12 07:51:12 --> Model Class Initialized
INFO - 2019-07-12 01:51:12 --> Output Class Initialized
INFO - 2019-07-12 07:51:12 --> Final output sent to browser
INFO - 2019-07-12 01:51:12 --> Security Class Initialized
DEBUG - 2019-07-12 07:51:12 --> Total execution time: 1.3859
DEBUG - 2019-07-12 01:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 01:51:12 --> Input Class Initialized
INFO - 2019-07-12 01:51:12 --> Language Class Initialized
INFO - 2019-07-12 01:51:12 --> Language Class Initialized
INFO - 2019-07-12 01:51:12 --> Config Class Initialized
INFO - 2019-07-12 01:51:12 --> Loader Class Initialized
DEBUG - 2019-07-12 01:51:12 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 01:51:12 --> Helper loaded: url_helper
INFO - 2019-07-12 01:51:12 --> Helper loaded: inflector_helper
INFO - 2019-07-12 01:51:12 --> Helper loaded: string_helper
INFO - 2019-07-12 01:51:12 --> Helper loaded: array_helper
INFO - 2019-07-12 01:51:12 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 01:51:12 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 01:51:12 --> Database Driver Class Initialized
INFO - 2019-07-12 01:51:12 --> Controller Class Initialized
INFO - 2019-07-12 07:51:12 --> Helper loaded: language_helper
INFO - 2019-07-12 07:51:12 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 07:51:12 --> Model Class Initialized
INFO - 2019-07-12 07:51:12 --> Model Class Initialized
INFO - 2019-07-12 07:51:12 --> Model Class Initialized
INFO - 2019-07-12 07:51:12 --> Model Class Initialized
INFO - 2019-07-12 07:51:12 --> Final output sent to browser
DEBUG - 2019-07-12 07:51:12 --> Total execution time: 0.6409
INFO - 2019-07-12 01:51:14 --> Config Class Initialized
INFO - 2019-07-12 01:51:14 --> Config Class Initialized
INFO - 2019-07-12 01:51:14 --> Hooks Class Initialized
INFO - 2019-07-12 01:51:14 --> Hooks Class Initialized
DEBUG - 2019-07-12 01:51:14 --> UTF-8 Support Enabled
DEBUG - 2019-07-12 01:51:14 --> UTF-8 Support Enabled
INFO - 2019-07-12 01:51:14 --> Utf8 Class Initialized
INFO - 2019-07-12 01:51:14 --> Utf8 Class Initialized
INFO - 2019-07-12 01:51:14 --> URI Class Initialized
INFO - 2019-07-12 01:51:14 --> URI Class Initialized
INFO - 2019-07-12 01:51:14 --> Router Class Initialized
INFO - 2019-07-12 01:51:14 --> Router Class Initialized
INFO - 2019-07-12 01:51:14 --> Output Class Initialized
INFO - 2019-07-12 01:51:14 --> Output Class Initialized
INFO - 2019-07-12 01:51:14 --> Security Class Initialized
INFO - 2019-07-12 01:51:14 --> Security Class Initialized
DEBUG - 2019-07-12 01:51:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-12 01:51:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 01:51:14 --> Input Class Initialized
INFO - 2019-07-12 01:51:14 --> Input Class Initialized
INFO - 2019-07-12 01:51:14 --> Language Class Initialized
INFO - 2019-07-12 01:51:14 --> Language Class Initialized
INFO - 2019-07-12 01:51:14 --> Language Class Initialized
INFO - 2019-07-12 01:51:14 --> Language Class Initialized
INFO - 2019-07-12 01:51:14 --> Config Class Initialized
INFO - 2019-07-12 01:51:14 --> Config Class Initialized
INFO - 2019-07-12 01:51:14 --> Loader Class Initialized
INFO - 2019-07-12 01:51:15 --> Loader Class Initialized
DEBUG - 2019-07-12 01:51:15 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-12 01:51:15 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 01:51:15 --> Helper loaded: url_helper
INFO - 2019-07-12 01:51:15 --> Helper loaded: url_helper
INFO - 2019-07-12 01:51:15 --> Helper loaded: inflector_helper
INFO - 2019-07-12 01:51:15 --> Helper loaded: inflector_helper
INFO - 2019-07-12 01:51:15 --> Helper loaded: string_helper
INFO - 2019-07-12 01:51:15 --> Helper loaded: string_helper
INFO - 2019-07-12 01:51:15 --> Helper loaded: array_helper
INFO - 2019-07-12 01:51:15 --> Helper loaded: array_helper
INFO - 2019-07-12 01:51:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 01:51:15 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 01:51:15 --> Database Driver Class Initialized
INFO - 2019-07-12 01:51:15 --> Controller Class Initialized
INFO - 2019-07-12 07:51:15 --> Helper loaded: language_helper
INFO - 2019-07-12 07:51:15 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 07:51:15 --> Model Class Initialized
INFO - 2019-07-12 07:51:15 --> Model Class Initialized
INFO - 2019-07-12 07:51:15 --> Model Class Initialized
INFO - 2019-07-12 07:51:15 --> Model Class Initialized
INFO - 2019-07-12 07:51:15 --> Final output sent to browser
DEBUG - 2019-07-12 07:51:15 --> Total execution time: 0.7871
INFO - 2019-07-12 01:51:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 01:51:15 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 01:51:15 --> Database Driver Class Initialized
INFO - 2019-07-12 01:51:15 --> Controller Class Initialized
INFO - 2019-07-12 01:51:15 --> Config Class Initialized
INFO - 2019-07-12 07:51:15 --> Helper loaded: language_helper
INFO - 2019-07-12 01:51:15 --> Hooks Class Initialized
INFO - 2019-07-12 07:51:15 --> Language file loaded: language/english/general_lang.php
DEBUG - 2019-07-12 01:51:15 --> UTF-8 Support Enabled
INFO - 2019-07-12 07:51:15 --> Model Class Initialized
INFO - 2019-07-12 01:51:15 --> Utf8 Class Initialized
INFO - 2019-07-12 07:51:15 --> Model Class Initialized
INFO - 2019-07-12 01:51:15 --> URI Class Initialized
INFO - 2019-07-12 07:51:15 --> Model Class Initialized
INFO - 2019-07-12 01:51:15 --> Router Class Initialized
INFO - 2019-07-12 07:51:15 --> Model Class Initialized
INFO - 2019-07-12 07:51:15 --> Model Class Initialized
INFO - 2019-07-12 01:51:16 --> Output Class Initialized
INFO - 2019-07-12 07:51:16 --> Final output sent to browser
DEBUG - 2019-07-12 07:51:16 --> Total execution time: 1.6520
INFO - 2019-07-12 01:51:16 --> Security Class Initialized
DEBUG - 2019-07-12 01:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 01:51:16 --> Input Class Initialized
INFO - 2019-07-12 01:51:16 --> Language Class Initialized
INFO - 2019-07-12 01:51:16 --> Language Class Initialized
INFO - 2019-07-12 01:51:16 --> Config Class Initialized
INFO - 2019-07-12 01:51:16 --> Loader Class Initialized
DEBUG - 2019-07-12 01:51:16 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 01:51:16 --> Helper loaded: url_helper
INFO - 2019-07-12 01:51:16 --> Helper loaded: inflector_helper
INFO - 2019-07-12 01:51:16 --> Helper loaded: string_helper
INFO - 2019-07-12 01:51:16 --> Helper loaded: array_helper
INFO - 2019-07-12 01:51:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 01:51:16 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 01:51:16 --> Database Driver Class Initialized
INFO - 2019-07-12 01:51:16 --> Controller Class Initialized
INFO - 2019-07-12 07:51:16 --> Helper loaded: language_helper
INFO - 2019-07-12 07:51:16 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 07:51:16 --> Model Class Initialized
INFO - 2019-07-12 07:51:16 --> Model Class Initialized
INFO - 2019-07-12 07:51:16 --> Model Class Initialized
INFO - 2019-07-12 07:51:16 --> Model Class Initialized
INFO - 2019-07-12 07:51:16 --> Final output sent to browser
DEBUG - 2019-07-12 07:51:16 --> Total execution time: 0.9448
INFO - 2019-07-12 01:51:28 --> Config Class Initialized
INFO - 2019-07-12 01:51:28 --> Hooks Class Initialized
DEBUG - 2019-07-12 01:51:28 --> UTF-8 Support Enabled
INFO - 2019-07-12 01:51:28 --> Utf8 Class Initialized
INFO - 2019-07-12 01:51:28 --> URI Class Initialized
INFO - 2019-07-12 01:51:28 --> Router Class Initialized
INFO - 2019-07-12 01:51:28 --> Output Class Initialized
INFO - 2019-07-12 01:51:28 --> Security Class Initialized
DEBUG - 2019-07-12 01:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 01:51:28 --> Input Class Initialized
INFO - 2019-07-12 01:51:28 --> Language Class Initialized
INFO - 2019-07-12 01:51:28 --> Language Class Initialized
INFO - 2019-07-12 01:51:28 --> Config Class Initialized
INFO - 2019-07-12 01:51:28 --> Loader Class Initialized
DEBUG - 2019-07-12 01:51:28 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 01:51:28 --> Helper loaded: url_helper
INFO - 2019-07-12 01:51:28 --> Helper loaded: inflector_helper
INFO - 2019-07-12 01:51:28 --> Helper loaded: string_helper
INFO - 2019-07-12 01:51:28 --> Helper loaded: array_helper
INFO - 2019-07-12 01:51:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 01:51:28 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 01:51:28 --> Database Driver Class Initialized
INFO - 2019-07-12 01:51:28 --> Controller Class Initialized
INFO - 2019-07-12 07:51:28 --> Helper loaded: language_helper
INFO - 2019-07-12 07:51:28 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 07:51:28 --> Model Class Initialized
INFO - 2019-07-12 07:51:28 --> Model Class Initialized
INFO - 2019-07-12 07:51:28 --> Model Class Initialized
INFO - 2019-07-12 07:51:28 --> Model Class Initialized
INFO - 2019-07-12 07:51:28 --> Final output sent to browser
DEBUG - 2019-07-12 07:51:28 --> Total execution time: 0.5737
INFO - 2019-07-12 01:51:43 --> Config Class Initialized
INFO - 2019-07-12 01:51:43 --> Hooks Class Initialized
DEBUG - 2019-07-12 01:51:43 --> UTF-8 Support Enabled
INFO - 2019-07-12 01:51:43 --> Utf8 Class Initialized
INFO - 2019-07-12 01:51:43 --> URI Class Initialized
INFO - 2019-07-12 01:51:43 --> Router Class Initialized
INFO - 2019-07-12 01:51:43 --> Output Class Initialized
INFO - 2019-07-12 01:51:43 --> Security Class Initialized
DEBUG - 2019-07-12 01:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 01:51:43 --> Input Class Initialized
INFO - 2019-07-12 01:51:43 --> Language Class Initialized
INFO - 2019-07-12 01:51:43 --> Language Class Initialized
INFO - 2019-07-12 01:51:43 --> Config Class Initialized
INFO - 2019-07-12 01:51:43 --> Loader Class Initialized
DEBUG - 2019-07-12 01:51:43 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 01:51:43 --> Helper loaded: url_helper
INFO - 2019-07-12 01:51:43 --> Helper loaded: inflector_helper
INFO - 2019-07-12 01:51:43 --> Helper loaded: string_helper
INFO - 2019-07-12 01:51:43 --> Helper loaded: array_helper
INFO - 2019-07-12 01:51:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 01:51:43 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 01:51:43 --> Database Driver Class Initialized
INFO - 2019-07-12 01:51:43 --> Controller Class Initialized
INFO - 2019-07-12 07:51:43 --> Helper loaded: language_helper
INFO - 2019-07-12 07:51:43 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 07:51:43 --> Model Class Initialized
INFO - 2019-07-12 07:51:43 --> Model Class Initialized
INFO - 2019-07-12 07:51:43 --> Model Class Initialized
INFO - 2019-07-12 07:51:43 --> Model Class Initialized
INFO - 2019-07-12 07:51:43 --> Final output sent to browser
DEBUG - 2019-07-12 07:51:43 --> Total execution time: 0.5648
INFO - 2019-07-12 01:51:45 --> Config Class Initialized
INFO - 2019-07-12 01:51:45 --> Hooks Class Initialized
DEBUG - 2019-07-12 01:51:45 --> UTF-8 Support Enabled
INFO - 2019-07-12 01:51:45 --> Utf8 Class Initialized
INFO - 2019-07-12 01:51:45 --> URI Class Initialized
INFO - 2019-07-12 01:51:45 --> Router Class Initialized
INFO - 2019-07-12 01:51:45 --> Output Class Initialized
INFO - 2019-07-12 01:51:45 --> Security Class Initialized
DEBUG - 2019-07-12 01:51:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 01:51:45 --> Input Class Initialized
INFO - 2019-07-12 01:51:45 --> Language Class Initialized
INFO - 2019-07-12 01:51:45 --> Language Class Initialized
INFO - 2019-07-12 01:51:45 --> Config Class Initialized
INFO - 2019-07-12 01:51:45 --> Loader Class Initialized
DEBUG - 2019-07-12 01:51:45 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 01:51:45 --> Helper loaded: url_helper
INFO - 2019-07-12 01:51:45 --> Helper loaded: inflector_helper
INFO - 2019-07-12 01:51:45 --> Helper loaded: string_helper
INFO - 2019-07-12 01:51:45 --> Helper loaded: array_helper
INFO - 2019-07-12 01:51:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 01:51:45 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 01:51:45 --> Database Driver Class Initialized
INFO - 2019-07-12 01:51:45 --> Controller Class Initialized
INFO - 2019-07-12 07:51:45 --> Helper loaded: language_helper
INFO - 2019-07-12 07:51:45 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 07:51:45 --> Model Class Initialized
INFO - 2019-07-12 07:51:45 --> Model Class Initialized
INFO - 2019-07-12 07:51:45 --> Model Class Initialized
INFO - 2019-07-12 07:51:45 --> Model Class Initialized
INFO - 2019-07-12 07:51:45 --> Model Class Initialized
INFO - 2019-07-12 07:51:47 --> Final output sent to browser
DEBUG - 2019-07-12 07:51:47 --> Total execution time: 2.2340
INFO - 2019-07-12 01:52:14 --> Config Class Initialized
INFO - 2019-07-12 01:52:14 --> Hooks Class Initialized
DEBUG - 2019-07-12 01:52:14 --> UTF-8 Support Enabled
INFO - 2019-07-12 01:52:14 --> Utf8 Class Initialized
INFO - 2019-07-12 01:52:14 --> URI Class Initialized
INFO - 2019-07-12 01:52:14 --> Router Class Initialized
INFO - 2019-07-12 01:52:14 --> Output Class Initialized
INFO - 2019-07-12 01:52:14 --> Security Class Initialized
DEBUG - 2019-07-12 01:52:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 01:52:14 --> Input Class Initialized
INFO - 2019-07-12 01:52:14 --> Language Class Initialized
INFO - 2019-07-12 01:52:14 --> Language Class Initialized
INFO - 2019-07-12 01:52:14 --> Config Class Initialized
INFO - 2019-07-12 01:52:14 --> Loader Class Initialized
DEBUG - 2019-07-12 01:52:14 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 01:52:14 --> Helper loaded: url_helper
INFO - 2019-07-12 01:52:14 --> Helper loaded: inflector_helper
INFO - 2019-07-12 01:52:14 --> Helper loaded: string_helper
INFO - 2019-07-12 01:52:14 --> Helper loaded: array_helper
INFO - 2019-07-12 01:52:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 01:52:14 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 01:52:14 --> Database Driver Class Initialized
INFO - 2019-07-12 01:52:14 --> Controller Class Initialized
INFO - 2019-07-12 07:52:14 --> Helper loaded: language_helper
INFO - 2019-07-12 07:52:14 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 07:52:14 --> Model Class Initialized
INFO - 2019-07-12 07:52:14 --> Model Class Initialized
INFO - 2019-07-12 07:52:14 --> Model Class Initialized
INFO - 2019-07-12 07:52:14 --> Model Class Initialized
INFO - 2019-07-12 07:52:14 --> Final output sent to browser
DEBUG - 2019-07-12 07:52:14 --> Total execution time: 0.5433
INFO - 2019-07-12 01:52:16 --> Config Class Initialized
INFO - 2019-07-12 01:52:16 --> Hooks Class Initialized
DEBUG - 2019-07-12 01:52:16 --> UTF-8 Support Enabled
INFO - 2019-07-12 01:52:16 --> Utf8 Class Initialized
INFO - 2019-07-12 01:52:16 --> URI Class Initialized
INFO - 2019-07-12 01:52:16 --> Router Class Initialized
INFO - 2019-07-12 01:52:16 --> Output Class Initialized
INFO - 2019-07-12 01:52:16 --> Security Class Initialized
DEBUG - 2019-07-12 01:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 01:52:16 --> Input Class Initialized
INFO - 2019-07-12 01:52:16 --> Language Class Initialized
INFO - 2019-07-12 01:52:16 --> Language Class Initialized
INFO - 2019-07-12 01:52:16 --> Config Class Initialized
INFO - 2019-07-12 01:52:16 --> Loader Class Initialized
DEBUG - 2019-07-12 01:52:16 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 01:52:16 --> Helper loaded: url_helper
INFO - 2019-07-12 01:52:16 --> Helper loaded: inflector_helper
INFO - 2019-07-12 01:52:16 --> Helper loaded: string_helper
INFO - 2019-07-12 01:52:16 --> Helper loaded: array_helper
INFO - 2019-07-12 01:52:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 01:52:16 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 01:52:16 --> Database Driver Class Initialized
INFO - 2019-07-12 01:52:16 --> Controller Class Initialized
INFO - 2019-07-12 07:52:16 --> Helper loaded: language_helper
INFO - 2019-07-12 07:52:16 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 07:52:17 --> Model Class Initialized
INFO - 2019-07-12 07:52:17 --> Model Class Initialized
INFO - 2019-07-12 07:52:17 --> Model Class Initialized
INFO - 2019-07-12 07:52:17 --> Model Class Initialized
INFO - 2019-07-12 07:52:17 --> Final output sent to browser
DEBUG - 2019-07-12 07:52:17 --> Total execution time: 0.5992
INFO - 2019-07-12 01:52:17 --> Config Class Initialized
INFO - 2019-07-12 01:52:17 --> Hooks Class Initialized
DEBUG - 2019-07-12 01:52:17 --> UTF-8 Support Enabled
INFO - 2019-07-12 01:52:17 --> Utf8 Class Initialized
INFO - 2019-07-12 01:52:17 --> URI Class Initialized
INFO - 2019-07-12 01:52:17 --> Router Class Initialized
INFO - 2019-07-12 01:52:17 --> Output Class Initialized
INFO - 2019-07-12 01:52:17 --> Security Class Initialized
DEBUG - 2019-07-12 01:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 01:52:17 --> Input Class Initialized
INFO - 2019-07-12 01:52:17 --> Language Class Initialized
INFO - 2019-07-12 01:52:17 --> Language Class Initialized
INFO - 2019-07-12 01:52:17 --> Config Class Initialized
INFO - 2019-07-12 01:52:17 --> Loader Class Initialized
DEBUG - 2019-07-12 01:52:17 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 01:52:17 --> Helper loaded: url_helper
INFO - 2019-07-12 01:52:17 --> Helper loaded: inflector_helper
INFO - 2019-07-12 01:52:17 --> Helper loaded: string_helper
INFO - 2019-07-12 01:52:17 --> Helper loaded: array_helper
INFO - 2019-07-12 01:52:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 01:52:17 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 01:52:17 --> Database Driver Class Initialized
INFO - 2019-07-12 01:52:17 --> Controller Class Initialized
INFO - 2019-07-12 07:52:17 --> Helper loaded: language_helper
INFO - 2019-07-12 07:52:17 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 07:52:17 --> Model Class Initialized
INFO - 2019-07-12 07:52:17 --> Model Class Initialized
INFO - 2019-07-12 07:52:17 --> Model Class Initialized
INFO - 2019-07-12 07:52:17 --> Model Class Initialized
INFO - 2019-07-12 07:52:17 --> Final output sent to browser
DEBUG - 2019-07-12 07:52:17 --> Total execution time: 0.6464
INFO - 2019-07-12 01:52:22 --> Config Class Initialized
INFO - 2019-07-12 01:52:22 --> Hooks Class Initialized
DEBUG - 2019-07-12 01:52:22 --> UTF-8 Support Enabled
INFO - 2019-07-12 01:52:22 --> Utf8 Class Initialized
INFO - 2019-07-12 01:52:22 --> URI Class Initialized
INFO - 2019-07-12 01:52:22 --> Router Class Initialized
INFO - 2019-07-12 01:52:22 --> Output Class Initialized
INFO - 2019-07-12 01:52:22 --> Security Class Initialized
DEBUG - 2019-07-12 01:52:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 01:52:22 --> Input Class Initialized
INFO - 2019-07-12 01:52:22 --> Language Class Initialized
INFO - 2019-07-12 01:52:22 --> Language Class Initialized
INFO - 2019-07-12 01:52:22 --> Config Class Initialized
INFO - 2019-07-12 01:52:22 --> Loader Class Initialized
DEBUG - 2019-07-12 01:52:22 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 01:52:22 --> Helper loaded: url_helper
INFO - 2019-07-12 01:52:22 --> Helper loaded: inflector_helper
INFO - 2019-07-12 01:52:22 --> Helper loaded: string_helper
INFO - 2019-07-12 01:52:22 --> Helper loaded: array_helper
INFO - 2019-07-12 01:52:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 01:52:22 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 01:52:22 --> Database Driver Class Initialized
INFO - 2019-07-12 01:52:22 --> Controller Class Initialized
INFO - 2019-07-12 07:52:22 --> Helper loaded: language_helper
INFO - 2019-07-12 07:52:22 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 07:52:22 --> Model Class Initialized
INFO - 2019-07-12 07:52:22 --> Model Class Initialized
INFO - 2019-07-12 07:52:22 --> Model Class Initialized
INFO - 2019-07-12 07:52:22 --> Model Class Initialized
INFO - 2019-07-12 07:52:22 --> Final output sent to browser
DEBUG - 2019-07-12 07:52:23 --> Total execution time: 0.5731
INFO - 2019-07-12 01:52:24 --> Config Class Initialized
INFO - 2019-07-12 01:52:24 --> Hooks Class Initialized
INFO - 2019-07-12 01:52:24 --> Config Class Initialized
INFO - 2019-07-12 01:52:24 --> Config Class Initialized
DEBUG - 2019-07-12 01:52:24 --> UTF-8 Support Enabled
INFO - 2019-07-12 01:52:24 --> Hooks Class Initialized
DEBUG - 2019-07-12 01:52:24 --> UTF-8 Support Enabled
INFO - 2019-07-12 01:52:24 --> Utf8 Class Initialized
INFO - 2019-07-12 01:52:24 --> URI Class Initialized
INFO - 2019-07-12 01:52:24 --> Hooks Class Initialized
INFO - 2019-07-12 01:52:24 --> Utf8 Class Initialized
INFO - 2019-07-12 01:52:24 --> Router Class Initialized
INFO - 2019-07-12 01:52:24 --> URI Class Initialized
DEBUG - 2019-07-12 01:52:24 --> UTF-8 Support Enabled
INFO - 2019-07-12 01:52:24 --> Output Class Initialized
INFO - 2019-07-12 01:52:24 --> Router Class Initialized
INFO - 2019-07-12 01:52:24 --> Utf8 Class Initialized
INFO - 2019-07-12 01:52:25 --> Security Class Initialized
INFO - 2019-07-12 01:52:25 --> Output Class Initialized
INFO - 2019-07-12 01:52:25 --> URI Class Initialized
DEBUG - 2019-07-12 01:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 01:52:25 --> Router Class Initialized
INFO - 2019-07-12 01:52:25 --> Security Class Initialized
INFO - 2019-07-12 01:52:25 --> Input Class Initialized
INFO - 2019-07-12 01:52:25 --> Language Class Initialized
INFO - 2019-07-12 01:52:25 --> Output Class Initialized
DEBUG - 2019-07-12 01:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 01:52:25 --> Language Class Initialized
INFO - 2019-07-12 01:52:25 --> Security Class Initialized
INFO - 2019-07-12 01:52:25 --> Input Class Initialized
INFO - 2019-07-12 01:52:25 --> Config Class Initialized
INFO - 2019-07-12 01:52:25 --> Language Class Initialized
INFO - 2019-07-12 01:52:25 --> Loader Class Initialized
DEBUG - 2019-07-12 01:52:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-12 01:52:25 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 01:52:25 --> Language Class Initialized
INFO - 2019-07-12 01:52:25 --> Input Class Initialized
INFO - 2019-07-12 01:52:25 --> Config Class Initialized
INFO - 2019-07-12 01:52:25 --> Language Class Initialized
INFO - 2019-07-12 01:52:25 --> Helper loaded: url_helper
INFO - 2019-07-12 01:52:25 --> Loader Class Initialized
DEBUG - 2019-07-12 01:52:25 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 01:52:25 --> Helper loaded: inflector_helper
INFO - 2019-07-12 01:52:25 --> Language Class Initialized
INFO - 2019-07-12 01:52:25 --> Helper loaded: url_helper
INFO - 2019-07-12 01:52:25 --> Helper loaded: string_helper
INFO - 2019-07-12 01:52:25 --> Config Class Initialized
INFO - 2019-07-12 01:52:25 --> Loader Class Initialized
INFO - 2019-07-12 01:52:25 --> Helper loaded: inflector_helper
INFO - 2019-07-12 01:52:25 --> Helper loaded: array_helper
DEBUG - 2019-07-12 01:52:25 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 01:52:25 --> Helper loaded: string_helper
INFO - 2019-07-12 01:52:25 --> Session: Class initialized using 'files' driver.
INFO - 2019-07-12 01:52:25 --> Helper loaded: url_helper
INFO - 2019-07-12 01:52:25 --> Helper loaded: array_helper
DEBUG - 2019-07-12 01:52:25 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 01:52:25 --> Helper loaded: inflector_helper
INFO - 2019-07-12 01:52:25 --> Database Driver Class Initialized
INFO - 2019-07-12 01:52:25 --> Helper loaded: string_helper
INFO - 2019-07-12 01:52:25 --> Controller Class Initialized
INFO - 2019-07-12 01:52:25 --> Helper loaded: array_helper
INFO - 2019-07-12 07:52:25 --> Helper loaded: language_helper
INFO - 2019-07-12 07:52:25 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 07:52:25 --> Model Class Initialized
INFO - 2019-07-12 07:52:25 --> Model Class Initialized
INFO - 2019-07-12 07:52:25 --> Model Class Initialized
INFO - 2019-07-12 07:52:25 --> Model Class Initialized
INFO - 2019-07-12 07:52:25 --> Final output sent to browser
DEBUG - 2019-07-12 07:52:25 --> Total execution time: 0.8161
INFO - 2019-07-12 01:52:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 01:52:25 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 01:52:25 --> Database Driver Class Initialized
INFO - 2019-07-12 01:52:25 --> Controller Class Initialized
INFO - 2019-07-12 07:52:25 --> Helper loaded: language_helper
INFO - 2019-07-12 07:52:25 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 07:52:25 --> Model Class Initialized
INFO - 2019-07-12 07:52:25 --> Model Class Initialized
INFO - 2019-07-12 07:52:25 --> Model Class Initialized
INFO - 2019-07-12 07:52:25 --> Model Class Initialized
INFO - 2019-07-12 07:52:25 --> Final output sent to browser
DEBUG - 2019-07-12 07:52:25 --> Total execution time: 1.1142
INFO - 2019-07-12 01:52:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 01:52:25 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 01:52:25 --> Database Driver Class Initialized
INFO - 2019-07-12 01:52:25 --> Controller Class Initialized
INFO - 2019-07-12 07:52:25 --> Helper loaded: language_helper
INFO - 2019-07-12 07:52:25 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 07:52:25 --> Model Class Initialized
INFO - 2019-07-12 07:52:25 --> Model Class Initialized
INFO - 2019-07-12 07:52:26 --> Model Class Initialized
INFO - 2019-07-12 07:52:26 --> Model Class Initialized
INFO - 2019-07-12 07:52:26 --> Model Class Initialized
INFO - 2019-07-12 07:52:26 --> Final output sent to browser
DEBUG - 2019-07-12 07:52:26 --> Total execution time: 1.3259
INFO - 2019-07-12 01:52:29 --> Config Class Initialized
INFO - 2019-07-12 01:52:29 --> Hooks Class Initialized
DEBUG - 2019-07-12 01:52:29 --> UTF-8 Support Enabled
INFO - 2019-07-12 01:52:29 --> Utf8 Class Initialized
INFO - 2019-07-12 01:52:29 --> URI Class Initialized
INFO - 2019-07-12 01:52:29 --> Router Class Initialized
INFO - 2019-07-12 01:52:29 --> Output Class Initialized
INFO - 2019-07-12 01:52:29 --> Security Class Initialized
DEBUG - 2019-07-12 01:52:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 01:52:29 --> Input Class Initialized
INFO - 2019-07-12 01:52:29 --> Language Class Initialized
INFO - 2019-07-12 01:52:29 --> Language Class Initialized
INFO - 2019-07-12 01:52:29 --> Config Class Initialized
INFO - 2019-07-12 01:52:29 --> Loader Class Initialized
DEBUG - 2019-07-12 01:52:29 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 01:52:29 --> Helper loaded: url_helper
INFO - 2019-07-12 01:52:29 --> Helper loaded: inflector_helper
INFO - 2019-07-12 01:52:29 --> Helper loaded: string_helper
INFO - 2019-07-12 01:52:29 --> Helper loaded: array_helper
INFO - 2019-07-12 01:52:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 01:52:29 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 01:52:29 --> Database Driver Class Initialized
INFO - 2019-07-12 01:52:29 --> Controller Class Initialized
INFO - 2019-07-12 07:52:29 --> Helper loaded: language_helper
INFO - 2019-07-12 07:52:29 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 07:52:29 --> Model Class Initialized
INFO - 2019-07-12 07:52:29 --> Model Class Initialized
INFO - 2019-07-12 07:52:29 --> Model Class Initialized
INFO - 2019-07-12 07:52:29 --> Model Class Initialized
INFO - 2019-07-12 07:52:29 --> Final output sent to browser
DEBUG - 2019-07-12 07:52:29 --> Total execution time: 0.7086
INFO - 2019-07-12 01:53:05 --> Config Class Initialized
INFO - 2019-07-12 01:53:05 --> Hooks Class Initialized
DEBUG - 2019-07-12 01:53:05 --> UTF-8 Support Enabled
INFO - 2019-07-12 01:53:05 --> Utf8 Class Initialized
INFO - 2019-07-12 01:53:05 --> URI Class Initialized
INFO - 2019-07-12 01:53:05 --> Router Class Initialized
INFO - 2019-07-12 01:53:05 --> Output Class Initialized
INFO - 2019-07-12 01:53:05 --> Security Class Initialized
DEBUG - 2019-07-12 01:53:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 01:53:05 --> Input Class Initialized
INFO - 2019-07-12 01:53:05 --> Language Class Initialized
INFO - 2019-07-12 01:53:05 --> Language Class Initialized
INFO - 2019-07-12 01:53:05 --> Config Class Initialized
INFO - 2019-07-12 01:53:05 --> Loader Class Initialized
DEBUG - 2019-07-12 01:53:05 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 01:53:05 --> Helper loaded: url_helper
INFO - 2019-07-12 01:53:05 --> Helper loaded: inflector_helper
INFO - 2019-07-12 01:53:05 --> Helper loaded: string_helper
INFO - 2019-07-12 01:53:05 --> Helper loaded: array_helper
INFO - 2019-07-12 01:53:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 01:53:05 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 01:53:05 --> Database Driver Class Initialized
INFO - 2019-07-12 01:53:05 --> Controller Class Initialized
INFO - 2019-07-12 07:53:05 --> Helper loaded: language_helper
INFO - 2019-07-12 07:53:05 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 07:53:05 --> Model Class Initialized
INFO - 2019-07-12 07:53:05 --> Model Class Initialized
INFO - 2019-07-12 07:53:05 --> Model Class Initialized
INFO - 2019-07-12 07:53:05 --> Model Class Initialized
INFO - 2019-07-12 07:53:05 --> Final output sent to browser
DEBUG - 2019-07-12 07:53:05 --> Total execution time: 0.5649
INFO - 2019-07-12 01:53:18 --> Config Class Initialized
INFO - 2019-07-12 01:53:18 --> Hooks Class Initialized
DEBUG - 2019-07-12 01:53:18 --> UTF-8 Support Enabled
INFO - 2019-07-12 01:53:18 --> Utf8 Class Initialized
INFO - 2019-07-12 01:53:18 --> URI Class Initialized
INFO - 2019-07-12 01:53:18 --> Router Class Initialized
INFO - 2019-07-12 01:53:18 --> Output Class Initialized
INFO - 2019-07-12 01:53:18 --> Security Class Initialized
DEBUG - 2019-07-12 01:53:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 01:53:18 --> Input Class Initialized
INFO - 2019-07-12 01:53:18 --> Language Class Initialized
INFO - 2019-07-12 01:53:18 --> Language Class Initialized
INFO - 2019-07-12 01:53:18 --> Config Class Initialized
INFO - 2019-07-12 01:53:18 --> Loader Class Initialized
DEBUG - 2019-07-12 01:53:18 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 01:53:18 --> Helper loaded: url_helper
INFO - 2019-07-12 01:53:18 --> Helper loaded: inflector_helper
INFO - 2019-07-12 01:53:18 --> Helper loaded: string_helper
INFO - 2019-07-12 01:53:18 --> Helper loaded: array_helper
INFO - 2019-07-12 01:53:18 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 01:53:18 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 01:53:18 --> Database Driver Class Initialized
INFO - 2019-07-12 01:53:18 --> Controller Class Initialized
INFO - 2019-07-12 07:53:18 --> Helper loaded: language_helper
INFO - 2019-07-12 07:53:18 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 07:53:18 --> Model Class Initialized
INFO - 2019-07-12 07:53:18 --> Model Class Initialized
INFO - 2019-07-12 07:53:18 --> Model Class Initialized
INFO - 2019-07-12 07:53:18 --> Model Class Initialized
INFO - 2019-07-12 07:53:18 --> Final output sent to browser
DEBUG - 2019-07-12 07:53:18 --> Total execution time: 0.5429
INFO - 2019-07-12 01:53:23 --> Config Class Initialized
INFO - 2019-07-12 01:53:23 --> Hooks Class Initialized
DEBUG - 2019-07-12 01:53:23 --> UTF-8 Support Enabled
INFO - 2019-07-12 01:53:23 --> Utf8 Class Initialized
INFO - 2019-07-12 01:53:23 --> URI Class Initialized
INFO - 2019-07-12 01:53:23 --> Router Class Initialized
INFO - 2019-07-12 01:53:23 --> Output Class Initialized
INFO - 2019-07-12 01:53:23 --> Security Class Initialized
DEBUG - 2019-07-12 01:53:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 01:53:23 --> Input Class Initialized
INFO - 2019-07-12 01:53:23 --> Language Class Initialized
INFO - 2019-07-12 01:53:23 --> Language Class Initialized
INFO - 2019-07-12 01:53:23 --> Config Class Initialized
INFO - 2019-07-12 01:53:23 --> Loader Class Initialized
DEBUG - 2019-07-12 01:53:23 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 01:53:23 --> Helper loaded: url_helper
INFO - 2019-07-12 01:53:23 --> Helper loaded: inflector_helper
INFO - 2019-07-12 01:53:23 --> Helper loaded: string_helper
INFO - 2019-07-12 01:53:23 --> Helper loaded: array_helper
INFO - 2019-07-12 01:53:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 01:53:23 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 01:53:23 --> Database Driver Class Initialized
INFO - 2019-07-12 01:53:23 --> Controller Class Initialized
INFO - 2019-07-12 07:53:23 --> Helper loaded: language_helper
INFO - 2019-07-12 07:53:23 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 07:53:23 --> Model Class Initialized
INFO - 2019-07-12 07:53:23 --> Model Class Initialized
INFO - 2019-07-12 07:53:23 --> Model Class Initialized
INFO - 2019-07-12 07:53:23 --> Model Class Initialized
INFO - 2019-07-12 07:53:23 --> Final output sent to browser
DEBUG - 2019-07-12 07:53:23 --> Total execution time: 0.6704
INFO - 2019-07-12 01:53:23 --> Config Class Initialized
INFO - 2019-07-12 01:53:24 --> Hooks Class Initialized
DEBUG - 2019-07-12 01:53:24 --> UTF-8 Support Enabled
INFO - 2019-07-12 01:53:24 --> Utf8 Class Initialized
INFO - 2019-07-12 01:53:24 --> URI Class Initialized
INFO - 2019-07-12 01:53:24 --> Router Class Initialized
INFO - 2019-07-12 01:53:24 --> Output Class Initialized
INFO - 2019-07-12 01:53:24 --> Security Class Initialized
DEBUG - 2019-07-12 01:53:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-12 01:53:24 --> Input Class Initialized
INFO - 2019-07-12 01:53:24 --> Language Class Initialized
INFO - 2019-07-12 01:53:24 --> Language Class Initialized
INFO - 2019-07-12 01:53:24 --> Config Class Initialized
INFO - 2019-07-12 01:53:24 --> Loader Class Initialized
DEBUG - 2019-07-12 01:53:24 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-12 01:53:24 --> Helper loaded: url_helper
INFO - 2019-07-12 01:53:24 --> Helper loaded: inflector_helper
INFO - 2019-07-12 01:53:24 --> Helper loaded: string_helper
INFO - 2019-07-12 01:53:24 --> Helper loaded: array_helper
INFO - 2019-07-12 01:53:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-12 01:53:24 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-12 01:53:24 --> Database Driver Class Initialized
INFO - 2019-07-12 01:53:24 --> Controller Class Initialized
INFO - 2019-07-12 07:53:24 --> Helper loaded: language_helper
INFO - 2019-07-12 07:53:24 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-12 07:53:24 --> Model Class Initialized
INFO - 2019-07-12 07:53:24 --> Model Class Initialized
INFO - 2019-07-12 07:53:24 --> Model Class Initialized
INFO - 2019-07-12 07:53:24 --> Model Class Initialized
INFO - 2019-07-12 07:53:24 --> Model Class Initialized
INFO - 2019-07-12 07:53:24 --> Final output sent to browser
DEBUG - 2019-07-12 07:53:24 --> Total execution time: 0.6266
