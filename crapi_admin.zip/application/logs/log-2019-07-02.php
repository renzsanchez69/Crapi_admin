<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-07-02 00:00:07 --> Helper loaded: language_helper
INFO - 2019-07-02 00:00:07 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:00:07 --> Model Class Initialized
INFO - 2019-07-02 00:00:07 --> Model Class Initialized
INFO - 2019-07-02 00:00:07 --> Model Class Initialized
INFO - 2019-07-02 00:00:07 --> Model Class Initialized
INFO - 2019-07-02 00:00:07 --> Model Class Initialized
ERROR - 2019-07-02 00:00:07 --> Severity: Notice --> Undefined variable: category C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Uploads.php 14
INFO - 2019-07-02 00:02:01 --> Helper loaded: language_helper
INFO - 2019-07-02 00:02:01 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:02:01 --> Model Class Initialized
INFO - 2019-07-02 00:02:01 --> Model Class Initialized
INFO - 2019-07-02 00:02:01 --> Model Class Initialized
INFO - 2019-07-02 00:02:01 --> Model Class Initialized
INFO - 2019-07-02 00:02:01 --> Model Class Initialized
INFO - 2019-07-02 00:02:01 --> Final output sent to browser
DEBUG - 2019-07-02 00:02:01 --> Total execution time: 0.7264
INFO - 2019-07-02 00:02:02 --> Helper loaded: language_helper
INFO - 2019-07-02 00:02:02 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:02:02 --> Model Class Initialized
INFO - 2019-07-02 00:02:02 --> Model Class Initialized
INFO - 2019-07-02 00:02:02 --> Model Class Initialized
INFO - 2019-07-02 00:02:02 --> Model Class Initialized
INFO - 2019-07-02 00:02:02 --> Model Class Initialized
INFO - 2019-07-02 00:02:02 --> Final output sent to browser
DEBUG - 2019-07-02 00:02:02 --> Total execution time: 0.6686
INFO - 2019-07-02 00:02:03 --> Helper loaded: language_helper
INFO - 2019-07-02 00:02:03 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:02:03 --> Model Class Initialized
INFO - 2019-07-02 00:02:03 --> Model Class Initialized
INFO - 2019-07-02 00:02:03 --> Model Class Initialized
INFO - 2019-07-02 00:02:03 --> Model Class Initialized
INFO - 2019-07-02 00:02:03 --> Final output sent to browser
DEBUG - 2019-07-02 00:02:03 --> Total execution time: 0.7031
INFO - 2019-07-02 00:02:06 --> Helper loaded: language_helper
INFO - 2019-07-02 00:02:06 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:02:06 --> Model Class Initialized
INFO - 2019-07-02 00:02:06 --> Model Class Initialized
INFO - 2019-07-02 00:02:06 --> Model Class Initialized
INFO - 2019-07-02 00:02:06 --> Model Class Initialized
INFO - 2019-07-02 00:02:06 --> Final output sent to browser
DEBUG - 2019-07-02 00:02:06 --> Total execution time: 0.6754
INFO - 2019-07-02 00:02:28 --> Helper loaded: language_helper
INFO - 2019-07-02 00:02:28 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:02:28 --> Final output sent to browser
DEBUG - 2019-07-02 00:02:28 --> Total execution time: 0.5806
INFO - 2019-07-02 00:02:55 --> Helper loaded: language_helper
INFO - 2019-07-02 00:02:55 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:02:55 --> Model Class Initialized
INFO - 2019-07-02 00:02:55 --> Model Class Initialized
INFO - 2019-07-02 00:02:55 --> Model Class Initialized
INFO - 2019-07-02 00:02:55 --> Model Class Initialized
INFO - 2019-07-02 00:02:55 --> Final output sent to browser
DEBUG - 2019-07-02 00:02:55 --> Total execution time: 0.6786
INFO - 2019-07-02 00:03:07 --> Helper loaded: language_helper
INFO - 2019-07-02 00:03:07 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:03:07 --> Model Class Initialized
INFO - 2019-07-02 00:03:07 --> Model Class Initialized
INFO - 2019-07-02 00:03:07 --> Model Class Initialized
INFO - 2019-07-02 00:03:07 --> Model Class Initialized
INFO - 2019-07-02 00:03:07 --> Final output sent to browser
DEBUG - 2019-07-02 00:03:07 --> Total execution time: 0.6745
INFO - 2019-07-02 00:03:43 --> Helper loaded: language_helper
INFO - 2019-07-02 00:03:43 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:03:43 --> Model Class Initialized
INFO - 2019-07-02 00:03:43 --> Model Class Initialized
INFO - 2019-07-02 00:03:43 --> Model Class Initialized
INFO - 2019-07-02 00:03:43 --> Model Class Initialized
INFO - 2019-07-02 00:03:43 --> Final output sent to browser
DEBUG - 2019-07-02 00:03:43 --> Total execution time: 0.6883
INFO - 2019-07-02 00:05:38 --> Helper loaded: language_helper
INFO - 2019-07-02 00:05:38 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:05:38 --> Model Class Initialized
INFO - 2019-07-02 00:05:38 --> Model Class Initialized
INFO - 2019-07-02 00:05:38 --> Model Class Initialized
INFO - 2019-07-02 00:05:38 --> Model Class Initialized
INFO - 2019-07-02 00:05:38 --> Final output sent to browser
DEBUG - 2019-07-02 00:05:38 --> Total execution time: 0.6889
INFO - 2019-07-02 00:06:00 --> Helper loaded: language_helper
INFO - 2019-07-02 00:06:00 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:06:00 --> Model Class Initialized
INFO - 2019-07-02 00:06:00 --> Model Class Initialized
INFO - 2019-07-02 00:06:00 --> Model Class Initialized
INFO - 2019-07-02 00:06:00 --> Model Class Initialized
INFO - 2019-07-02 00:06:00 --> Model Class Initialized
INFO - 2019-07-02 00:06:06 --> Helper loaded: language_helper
INFO - 2019-07-02 00:06:06 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:06:06 --> Final output sent to browser
DEBUG - 2019-07-02 00:06:06 --> Total execution time: 0.5903
INFO - 2019-07-02 00:06:21 --> Helper loaded: language_helper
INFO - 2019-07-02 00:06:21 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:06:21 --> Final output sent to browser
DEBUG - 2019-07-02 00:06:21 --> Total execution time: 0.5969
INFO - 2019-07-02 00:06:22 --> Helper loaded: language_helper
INFO - 2019-07-02 00:06:22 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:06:22 --> Final output sent to browser
DEBUG - 2019-07-02 00:06:22 --> Total execution time: 0.5753
INFO - 2019-07-02 00:06:24 --> Helper loaded: language_helper
INFO - 2019-07-02 00:06:24 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:06:24 --> Final output sent to browser
DEBUG - 2019-07-02 00:06:24 --> Total execution time: 0.5856
INFO - 2019-07-02 00:07:49 --> Helper loaded: language_helper
INFO - 2019-07-02 00:07:49 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:07:49 --> Final output sent to browser
DEBUG - 2019-07-02 00:07:49 --> Total execution time: 0.5909
INFO - 2019-07-02 00:07:52 --> Helper loaded: language_helper
INFO - 2019-07-02 00:07:52 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:07:52 --> Final output sent to browser
DEBUG - 2019-07-02 00:07:52 --> Total execution time: 0.5874
INFO - 2019-07-02 00:08:13 --> Helper loaded: language_helper
INFO - 2019-07-02 00:08:13 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:08:13 --> Final output sent to browser
DEBUG - 2019-07-02 00:08:13 --> Total execution time: 0.5902
INFO - 2019-07-02 00:08:27 --> Helper loaded: language_helper
INFO - 2019-07-02 00:08:27 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:08:27 --> Model Class Initialized
INFO - 2019-07-02 00:08:27 --> Model Class Initialized
INFO - 2019-07-02 00:08:27 --> Model Class Initialized
INFO - 2019-07-02 00:08:27 --> Model Class Initialized
INFO - 2019-07-02 00:08:27 --> Model Class Initialized
INFO - 2019-07-02 00:08:27 --> Final output sent to browser
DEBUG - 2019-07-02 00:08:27 --> Total execution time: 0.6865
INFO - 2019-07-02 00:08:41 --> Helper loaded: language_helper
INFO - 2019-07-02 00:08:41 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:08:41 --> Model Class Initialized
INFO - 2019-07-02 00:08:41 --> Model Class Initialized
INFO - 2019-07-02 00:08:41 --> Model Class Initialized
INFO - 2019-07-02 00:08:41 --> Model Class Initialized
INFO - 2019-07-02 00:08:41 --> Model Class Initialized
ERROR - 2019-07-02 00:08:41 --> Severity: Warning --> Missing argument 1 for Uploads::upload_image() C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Uploads.php 12
ERROR - 2019-07-02 00:08:41 --> Severity: Notice --> Undefined variable: category C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Uploads.php 14
INFO - 2019-07-02 00:08:47 --> Helper loaded: language_helper
INFO - 2019-07-02 00:08:47 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:08:47 --> Final output sent to browser
DEBUG - 2019-07-02 00:08:47 --> Total execution time: 0.5864
INFO - 2019-07-02 00:08:51 --> Helper loaded: language_helper
INFO - 2019-07-02 00:08:51 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:08:51 --> Model Class Initialized
INFO - 2019-07-02 00:08:51 --> Model Class Initialized
INFO - 2019-07-02 00:08:51 --> Model Class Initialized
INFO - 2019-07-02 00:08:51 --> Model Class Initialized
INFO - 2019-07-02 00:08:51 --> Model Class Initialized
ERROR - 2019-07-02 00:08:51 --> Severity: Warning --> Missing argument 1 for Uploads::upload_image() C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Uploads.php 12
ERROR - 2019-07-02 00:08:51 --> Severity: Notice --> Undefined variable: category C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Uploads.php 14
INFO - 2019-07-02 00:09:00 --> Helper loaded: language_helper
INFO - 2019-07-02 00:09:00 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:09:00 --> Final output sent to browser
DEBUG - 2019-07-02 00:09:00 --> Total execution time: 0.5994
INFO - 2019-07-02 00:09:03 --> Helper loaded: language_helper
INFO - 2019-07-02 00:09:03 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:09:03 --> Model Class Initialized
INFO - 2019-07-02 00:09:03 --> Model Class Initialized
INFO - 2019-07-02 00:09:03 --> Model Class Initialized
INFO - 2019-07-02 00:09:03 --> Model Class Initialized
INFO - 2019-07-02 00:09:03 --> Model Class Initialized
ERROR - 2019-07-02 00:09:03 --> Severity: Warning --> Missing argument 1 for Uploads::upload_image() C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Uploads.php 12
ERROR - 2019-07-02 00:09:03 --> Severity: Notice --> Undefined variable: category C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Uploads.php 14
INFO - 2019-07-02 00:09:27 --> Helper loaded: language_helper
INFO - 2019-07-02 00:09:27 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:09:27 --> Model Class Initialized
INFO - 2019-07-02 00:09:27 --> Model Class Initialized
INFO - 2019-07-02 00:09:27 --> Model Class Initialized
INFO - 2019-07-02 00:09:27 --> Model Class Initialized
INFO - 2019-07-02 00:09:27 --> Model Class Initialized
INFO - 2019-07-02 00:09:49 --> Helper loaded: language_helper
INFO - 2019-07-02 00:09:49 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:09:49 --> Final output sent to browser
DEBUG - 2019-07-02 00:09:49 --> Total execution time: 0.6015
INFO - 2019-07-02 00:09:57 --> Helper loaded: language_helper
INFO - 2019-07-02 00:09:57 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:09:57 --> Final output sent to browser
DEBUG - 2019-07-02 00:09:57 --> Total execution time: 0.5961
INFO - 2019-07-02 00:10:01 --> Helper loaded: language_helper
INFO - 2019-07-02 00:10:01 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:10:01 --> Final output sent to browser
DEBUG - 2019-07-02 00:10:01 --> Total execution time: 0.6167
INFO - 2019-07-02 00:11:07 --> Helper loaded: language_helper
INFO - 2019-07-02 00:11:07 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:11:07 --> Final output sent to browser
DEBUG - 2019-07-02 00:11:07 --> Total execution time: 0.6052
INFO - 2019-07-02 00:11:46 --> Helper loaded: language_helper
INFO - 2019-07-02 00:11:46 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:11:46 --> Final output sent to browser
DEBUG - 2019-07-02 00:11:46 --> Total execution time: 0.6038
INFO - 2019-07-02 00:11:49 --> Helper loaded: language_helper
INFO - 2019-07-02 00:11:49 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:11:49 --> Model Class Initialized
INFO - 2019-07-02 00:11:49 --> Model Class Initialized
INFO - 2019-07-02 00:11:49 --> Model Class Initialized
INFO - 2019-07-02 00:11:49 --> Model Class Initialized
INFO - 2019-07-02 00:11:49 --> Model Class Initialized
ERROR - 2019-07-02 00:11:49 --> Severity: Notice --> Undefined variable: category C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Uploads.php 13
INFO - 2019-07-02 00:11:56 --> Helper loaded: language_helper
INFO - 2019-07-02 00:11:56 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:11:56 --> Model Class Initialized
INFO - 2019-07-02 00:11:56 --> Model Class Initialized
INFO - 2019-07-02 00:11:56 --> Model Class Initialized
INFO - 2019-07-02 00:11:56 --> Model Class Initialized
INFO - 2019-07-02 00:11:56 --> Model Class Initialized
INFO - 2019-07-02 00:13:12 --> Helper loaded: language_helper
INFO - 2019-07-02 00:13:12 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:13:12 --> Final output sent to browser
DEBUG - 2019-07-02 00:13:12 --> Total execution time: 0.6031
INFO - 2019-07-02 00:13:12 --> Helper loaded: language_helper
INFO - 2019-07-02 00:13:12 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:13:12 --> Final output sent to browser
DEBUG - 2019-07-02 00:13:12 --> Total execution time: 0.5980
INFO - 2019-07-02 00:13:30 --> Helper loaded: language_helper
INFO - 2019-07-02 00:13:30 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:13:30 --> Final output sent to browser
DEBUG - 2019-07-02 00:13:30 --> Total execution time: 0.6111
INFO - 2019-07-02 00:13:42 --> Helper loaded: language_helper
INFO - 2019-07-02 00:13:42 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:13:42 --> Final output sent to browser
DEBUG - 2019-07-02 00:13:42 --> Total execution time: 0.6048
INFO - 2019-07-02 00:13:45 --> Helper loaded: language_helper
INFO - 2019-07-02 00:13:45 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:13:45 --> Final output sent to browser
DEBUG - 2019-07-02 00:13:45 --> Total execution time: 0.6063
INFO - 2019-07-02 00:14:08 --> Helper loaded: language_helper
INFO - 2019-07-02 00:14:08 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:14:08 --> Model Class Initialized
INFO - 2019-07-02 00:14:08 --> Model Class Initialized
INFO - 2019-07-02 00:14:08 --> Model Class Initialized
INFO - 2019-07-02 00:14:08 --> Model Class Initialized
INFO - 2019-07-02 00:14:08 --> Model Class Initialized
INFO - 2019-07-02 00:14:46 --> Helper loaded: language_helper
INFO - 2019-07-02 00:14:46 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:14:46 --> Model Class Initialized
INFO - 2019-07-02 00:14:46 --> Model Class Initialized
INFO - 2019-07-02 00:14:46 --> Model Class Initialized
INFO - 2019-07-02 00:14:46 --> Model Class Initialized
INFO - 2019-07-02 00:14:46 --> Model Class Initialized
ERROR - 2019-07-02 00:14:46 --> Severity: Notice --> Undefined index: image C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Uploads.php 15
ERROR - 2019-07-02 00:14:46 --> Severity: Notice --> Undefined variable: category C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Uploads.php 16
ERROR - 2019-07-02 00:14:46 --> Severity: Notice --> Undefined index: extension C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Uploads.php 16
ERROR - 2019-07-02 00:14:46 --> Severity: Notice --> Undefined variable: category C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Uploads.php 17
INFO - 2019-07-02 00:14:46 --> Final output sent to browser
DEBUG - 2019-07-02 00:14:46 --> Total execution time: 0.7284
INFO - 2019-07-02 00:15:17 --> Helper loaded: language_helper
INFO - 2019-07-02 00:15:17 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:15:17 --> Model Class Initialized
INFO - 2019-07-02 00:15:17 --> Model Class Initialized
INFO - 2019-07-02 00:15:17 --> Model Class Initialized
INFO - 2019-07-02 00:15:17 --> Model Class Initialized
INFO - 2019-07-02 00:15:17 --> Model Class Initialized
INFO - 2019-07-02 00:15:17 --> Final output sent to browser
DEBUG - 2019-07-02 00:15:17 --> Total execution time: 0.6905
INFO - 2019-07-02 00:15:18 --> Helper loaded: language_helper
INFO - 2019-07-02 00:15:18 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:15:18 --> Model Class Initialized
INFO - 2019-07-02 00:15:18 --> Model Class Initialized
INFO - 2019-07-02 00:15:18 --> Model Class Initialized
INFO - 2019-07-02 00:15:18 --> Model Class Initialized
INFO - 2019-07-02 00:15:18 --> Model Class Initialized
INFO - 2019-07-02 00:15:18 --> Final output sent to browser
DEBUG - 2019-07-02 00:15:18 --> Total execution time: 0.6801
INFO - 2019-07-02 00:15:48 --> Helper loaded: language_helper
INFO - 2019-07-02 00:15:48 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:15:48 --> Model Class Initialized
INFO - 2019-07-02 00:15:48 --> Model Class Initialized
INFO - 2019-07-02 00:15:48 --> Model Class Initialized
INFO - 2019-07-02 00:15:48 --> Model Class Initialized
INFO - 2019-07-02 00:15:48 --> Model Class Initialized
INFO - 2019-07-02 00:15:48 --> Final output sent to browser
DEBUG - 2019-07-02 00:15:48 --> Total execution time: 0.6869
INFO - 2019-07-02 00:15:49 --> Helper loaded: language_helper
INFO - 2019-07-02 00:15:49 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:15:49 --> Model Class Initialized
INFO - 2019-07-02 00:15:49 --> Model Class Initialized
INFO - 2019-07-02 00:15:49 --> Model Class Initialized
INFO - 2019-07-02 00:15:49 --> Model Class Initialized
INFO - 2019-07-02 00:15:49 --> Model Class Initialized
INFO - 2019-07-02 00:15:49 --> Final output sent to browser
DEBUG - 2019-07-02 00:15:49 --> Total execution time: 0.7304
INFO - 2019-07-02 00:15:52 --> Helper loaded: language_helper
INFO - 2019-07-02 00:15:52 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:15:52 --> Model Class Initialized
INFO - 2019-07-02 00:15:52 --> Model Class Initialized
INFO - 2019-07-02 00:15:52 --> Model Class Initialized
INFO - 2019-07-02 00:15:52 --> Model Class Initialized
INFO - 2019-07-02 00:15:52 --> Model Class Initialized
INFO - 2019-07-02 00:15:52 --> Final output sent to browser
DEBUG - 2019-07-02 00:15:52 --> Total execution time: 0.6857
INFO - 2019-07-02 00:15:53 --> Helper loaded: language_helper
INFO - 2019-07-02 00:15:53 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:15:53 --> Model Class Initialized
INFO - 2019-07-02 00:15:53 --> Model Class Initialized
INFO - 2019-07-02 00:15:53 --> Model Class Initialized
INFO - 2019-07-02 00:15:53 --> Model Class Initialized
INFO - 2019-07-02 00:15:53 --> Model Class Initialized
INFO - 2019-07-02 00:15:53 --> Final output sent to browser
DEBUG - 2019-07-02 00:15:53 --> Total execution time: 0.7314
INFO - 2019-07-02 00:15:56 --> Helper loaded: language_helper
INFO - 2019-07-02 00:15:56 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:15:56 --> Model Class Initialized
INFO - 2019-07-02 00:15:56 --> Model Class Initialized
INFO - 2019-07-02 00:15:56 --> Model Class Initialized
INFO - 2019-07-02 00:15:56 --> Model Class Initialized
INFO - 2019-07-02 00:15:56 --> Model Class Initialized
INFO - 2019-07-02 00:15:56 --> Final output sent to browser
DEBUG - 2019-07-02 00:15:56 --> Total execution time: 0.7202
INFO - 2019-07-02 00:15:57 --> Helper loaded: language_helper
INFO - 2019-07-02 00:15:57 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:15:57 --> Model Class Initialized
INFO - 2019-07-02 00:15:57 --> Model Class Initialized
INFO - 2019-07-02 00:15:57 --> Model Class Initialized
INFO - 2019-07-02 00:15:57 --> Model Class Initialized
INFO - 2019-07-02 00:15:57 --> Model Class Initialized
INFO - 2019-07-02 00:15:57 --> Final output sent to browser
DEBUG - 2019-07-02 00:15:57 --> Total execution time: 0.7035
INFO - 2019-07-02 00:16:06 --> Helper loaded: language_helper
INFO - 2019-07-02 00:16:06 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:16:06 --> Model Class Initialized
INFO - 2019-07-02 00:16:06 --> Model Class Initialized
INFO - 2019-07-02 00:16:06 --> Model Class Initialized
INFO - 2019-07-02 00:16:06 --> Model Class Initialized
INFO - 2019-07-02 00:16:06 --> Model Class Initialized
INFO - 2019-07-02 00:16:06 --> Final output sent to browser
DEBUG - 2019-07-02 00:16:06 --> Total execution time: 0.7260
INFO - 2019-07-02 00:16:07 --> Helper loaded: language_helper
INFO - 2019-07-02 00:16:07 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:16:07 --> Model Class Initialized
INFO - 2019-07-02 00:16:07 --> Model Class Initialized
INFO - 2019-07-02 00:16:07 --> Model Class Initialized
INFO - 2019-07-02 00:16:07 --> Model Class Initialized
INFO - 2019-07-02 00:16:07 --> Model Class Initialized
INFO - 2019-07-02 00:16:07 --> Final output sent to browser
DEBUG - 2019-07-02 00:16:07 --> Total execution time: 0.7636
INFO - 2019-07-02 00:16:09 --> Helper loaded: language_helper
INFO - 2019-07-02 00:16:09 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:16:09 --> Model Class Initialized
INFO - 2019-07-02 00:16:09 --> Model Class Initialized
INFO - 2019-07-02 00:16:09 --> Model Class Initialized
INFO - 2019-07-02 00:16:09 --> Model Class Initialized
INFO - 2019-07-02 00:16:09 --> Model Class Initialized
INFO - 2019-07-02 00:16:09 --> Final output sent to browser
DEBUG - 2019-07-02 00:16:09 --> Total execution time: 0.7270
INFO - 2019-07-02 00:16:15 --> Helper loaded: language_helper
INFO - 2019-07-02 00:16:15 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:16:15 --> Model Class Initialized
INFO - 2019-07-02 00:16:15 --> Model Class Initialized
INFO - 2019-07-02 00:16:15 --> Model Class Initialized
INFO - 2019-07-02 00:16:15 --> Model Class Initialized
INFO - 2019-07-02 00:16:15 --> Model Class Initialized
INFO - 2019-07-02 00:16:15 --> Final output sent to browser
DEBUG - 2019-07-02 00:16:15 --> Total execution time: 1.1702
INFO - 2019-07-02 00:16:15 --> Helper loaded: language_helper
INFO - 2019-07-02 00:16:15 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:16:15 --> Model Class Initialized
INFO - 2019-07-02 00:16:15 --> Model Class Initialized
INFO - 2019-07-02 00:16:15 --> Model Class Initialized
INFO - 2019-07-02 00:16:15 --> Model Class Initialized
INFO - 2019-07-02 00:16:15 --> Final output sent to browser
DEBUG - 2019-07-02 00:16:15 --> Total execution time: 1.4675
INFO - 2019-07-02 00:16:15 --> Helper loaded: language_helper
INFO - 2019-07-02 00:16:15 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:16:15 --> Model Class Initialized
INFO - 2019-07-02 00:16:15 --> Model Class Initialized
INFO - 2019-07-02 00:16:15 --> Model Class Initialized
INFO - 2019-07-02 00:16:15 --> Model Class Initialized
INFO - 2019-07-02 00:16:15 --> Model Class Initialized
INFO - 2019-07-02 00:16:15 --> Final output sent to browser
DEBUG - 2019-07-02 00:16:16 --> Total execution time: 0.8057
INFO - 2019-07-02 00:16:29 --> Helper loaded: language_helper
INFO - 2019-07-02 00:16:29 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:16:29 --> Model Class Initialized
INFO - 2019-07-02 00:16:29 --> Model Class Initialized
INFO - 2019-07-02 00:16:29 --> Model Class Initialized
INFO - 2019-07-02 00:16:29 --> Model Class Initialized
INFO - 2019-07-02 00:16:29 --> Model Class Initialized
ERROR - 2019-07-02 00:16:29 --> Severity: Notice --> Undefined index: image C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Uploads.php 15
ERROR - 2019-07-02 00:16:29 --> Severity: Notice --> Undefined variable: category C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Uploads.php 16
ERROR - 2019-07-02 00:16:29 --> Severity: Notice --> Undefined index: extension C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Uploads.php 16
ERROR - 2019-07-02 00:16:29 --> Severity: Notice --> Undefined variable: category C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Uploads.php 17
INFO - 2019-07-02 00:16:29 --> Final output sent to browser
DEBUG - 2019-07-02 00:16:29 --> Total execution time: 0.7506
INFO - 2019-07-02 00:17:01 --> Helper loaded: language_helper
INFO - 2019-07-02 00:17:01 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:17:01 --> Model Class Initialized
INFO - 2019-07-02 00:17:01 --> Model Class Initialized
INFO - 2019-07-02 00:17:01 --> Model Class Initialized
INFO - 2019-07-02 00:17:01 --> Model Class Initialized
INFO - 2019-07-02 00:17:01 --> Model Class Initialized
INFO - 2019-07-02 00:17:14 --> Helper loaded: language_helper
INFO - 2019-07-02 00:17:14 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:17:14 --> Model Class Initialized
INFO - 2019-07-02 00:17:14 --> Model Class Initialized
INFO - 2019-07-02 00:17:14 --> Model Class Initialized
INFO - 2019-07-02 00:17:14 --> Model Class Initialized
INFO - 2019-07-02 00:17:14 --> Model Class Initialized
INFO - 2019-07-02 00:17:14 --> Final output sent to browser
DEBUG - 2019-07-02 00:17:14 --> Total execution time: 0.7358
INFO - 2019-07-02 00:17:15 --> Helper loaded: language_helper
INFO - 2019-07-02 00:17:15 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:17:15 --> Model Class Initialized
INFO - 2019-07-02 00:17:15 --> Model Class Initialized
INFO - 2019-07-02 00:17:15 --> Model Class Initialized
INFO - 2019-07-02 00:17:15 --> Model Class Initialized
INFO - 2019-07-02 00:17:15 --> Model Class Initialized
INFO - 2019-07-02 00:17:15 --> Final output sent to browser
DEBUG - 2019-07-02 00:17:15 --> Total execution time: 0.7488
INFO - 2019-07-02 00:17:16 --> Helper loaded: language_helper
INFO - 2019-07-02 00:17:16 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:17:16 --> Model Class Initialized
INFO - 2019-07-02 00:17:16 --> Model Class Initialized
INFO - 2019-07-02 00:17:16 --> Model Class Initialized
INFO - 2019-07-02 00:17:16 --> Model Class Initialized
INFO - 2019-07-02 00:17:16 --> Model Class Initialized
INFO - 2019-07-02 00:17:16 --> Final output sent to browser
DEBUG - 2019-07-02 00:17:16 --> Total execution time: 0.7478
INFO - 2019-07-02 00:17:22 --> Helper loaded: language_helper
INFO - 2019-07-02 00:17:22 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:17:22 --> Model Class Initialized
INFO - 2019-07-02 00:17:22 --> Model Class Initialized
INFO - 2019-07-02 00:17:22 --> Model Class Initialized
INFO - 2019-07-02 00:17:22 --> Model Class Initialized
INFO - 2019-07-02 00:17:22 --> Model Class Initialized
INFO - 2019-07-02 00:17:22 --> Final output sent to browser
DEBUG - 2019-07-02 00:17:22 --> Total execution time: 1.0973
INFO - 2019-07-02 00:17:22 --> Helper loaded: language_helper
INFO - 2019-07-02 00:17:22 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:17:22 --> Model Class Initialized
INFO - 2019-07-02 00:17:22 --> Model Class Initialized
INFO - 2019-07-02 00:17:22 --> Model Class Initialized
INFO - 2019-07-02 00:17:22 --> Model Class Initialized
INFO - 2019-07-02 00:17:22 --> Final output sent to browser
DEBUG - 2019-07-02 00:17:22 --> Total execution time: 1.3738
INFO - 2019-07-02 00:17:23 --> Helper loaded: language_helper
INFO - 2019-07-02 00:17:23 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:17:23 --> Model Class Initialized
INFO - 2019-07-02 00:17:23 --> Model Class Initialized
INFO - 2019-07-02 00:17:23 --> Model Class Initialized
INFO - 2019-07-02 00:17:23 --> Model Class Initialized
INFO - 2019-07-02 00:17:23 --> Model Class Initialized
INFO - 2019-07-02 00:17:23 --> Final output sent to browser
DEBUG - 2019-07-02 00:17:23 --> Total execution time: 0.7952
INFO - 2019-07-02 00:18:00 --> Helper loaded: language_helper
INFO - 2019-07-02 00:18:00 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:18:00 --> Model Class Initialized
INFO - 2019-07-02 00:18:00 --> Model Class Initialized
INFO - 2019-07-02 00:18:00 --> Model Class Initialized
INFO - 2019-07-02 00:18:00 --> Model Class Initialized
INFO - 2019-07-02 00:18:00 --> Model Class Initialized
INFO - 2019-07-02 00:19:38 --> Helper loaded: language_helper
INFO - 2019-07-02 00:19:38 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:19:38 --> Model Class Initialized
INFO - 2019-07-02 00:19:38 --> Model Class Initialized
INFO - 2019-07-02 00:19:38 --> Model Class Initialized
INFO - 2019-07-02 00:19:38 --> Model Class Initialized
INFO - 2019-07-02 00:19:38 --> Model Class Initialized
INFO - 2019-07-02 00:19:47 --> Helper loaded: language_helper
INFO - 2019-07-02 00:19:47 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:19:47 --> Model Class Initialized
INFO - 2019-07-02 00:19:47 --> Model Class Initialized
INFO - 2019-07-02 00:19:47 --> Model Class Initialized
INFO - 2019-07-02 00:19:47 --> Model Class Initialized
INFO - 2019-07-02 00:19:47 --> Model Class Initialized
INFO - 2019-07-02 00:19:58 --> Helper loaded: language_helper
INFO - 2019-07-02 00:19:58 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:19:58 --> Model Class Initialized
INFO - 2019-07-02 00:19:58 --> Model Class Initialized
INFO - 2019-07-02 00:19:58 --> Model Class Initialized
INFO - 2019-07-02 00:19:58 --> Model Class Initialized
INFO - 2019-07-02 00:19:58 --> Model Class Initialized
INFO - 2019-07-02 00:20:52 --> Helper loaded: language_helper
INFO - 2019-07-02 00:20:52 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:20:52 --> Model Class Initialized
INFO - 2019-07-02 00:20:52 --> Model Class Initialized
INFO - 2019-07-02 00:20:52 --> Model Class Initialized
INFO - 2019-07-02 00:20:52 --> Model Class Initialized
INFO - 2019-07-02 00:20:52 --> Model Class Initialized
INFO - 2019-07-02 00:21:08 --> Helper loaded: language_helper
INFO - 2019-07-02 00:21:08 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:21:08 --> Model Class Initialized
INFO - 2019-07-02 00:21:08 --> Model Class Initialized
INFO - 2019-07-02 00:21:08 --> Model Class Initialized
INFO - 2019-07-02 00:21:08 --> Model Class Initialized
INFO - 2019-07-02 00:21:08 --> Model Class Initialized
INFO - 2019-07-02 00:21:48 --> Helper loaded: language_helper
INFO - 2019-07-02 00:21:48 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:21:48 --> Model Class Initialized
INFO - 2019-07-02 00:21:48 --> Model Class Initialized
INFO - 2019-07-02 00:21:48 --> Model Class Initialized
INFO - 2019-07-02 00:21:48 --> Model Class Initialized
INFO - 2019-07-02 00:21:48 --> Model Class Initialized
INFO - 2019-07-02 00:21:58 --> Helper loaded: language_helper
INFO - 2019-07-02 00:21:58 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:21:58 --> Model Class Initialized
INFO - 2019-07-02 00:21:58 --> Model Class Initialized
INFO - 2019-07-02 00:21:58 --> Model Class Initialized
INFO - 2019-07-02 00:21:58 --> Model Class Initialized
INFO - 2019-07-02 00:21:58 --> Model Class Initialized
ERROR - 2019-07-02 00:21:58 --> Severity: Notice --> Undefined index: image C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Uploads.php 17
ERROR - 2019-07-02 00:21:58 --> Severity: Notice --> Undefined variable: category C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Uploads.php 18
ERROR - 2019-07-02 00:21:58 --> Severity: Notice --> Undefined index: extension C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Uploads.php 18
ERROR - 2019-07-02 00:21:58 --> Severity: Notice --> Undefined variable: category C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Uploads.php 19
INFO - 2019-07-02 00:21:58 --> Final output sent to browser
DEBUG - 2019-07-02 00:21:58 --> Total execution time: 0.7675
INFO - 2019-07-02 00:22:18 --> Helper loaded: language_helper
INFO - 2019-07-02 00:22:18 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:22:18 --> Model Class Initialized
INFO - 2019-07-02 00:22:18 --> Model Class Initialized
INFO - 2019-07-02 00:22:18 --> Model Class Initialized
INFO - 2019-07-02 00:22:18 --> Model Class Initialized
INFO - 2019-07-02 00:22:18 --> Model Class Initialized
INFO - 2019-07-02 00:23:27 --> Helper loaded: language_helper
INFO - 2019-07-02 00:23:27 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:23:27 --> Model Class Initialized
INFO - 2019-07-02 00:23:27 --> Model Class Initialized
INFO - 2019-07-02 00:23:27 --> Model Class Initialized
INFO - 2019-07-02 00:23:27 --> Model Class Initialized
INFO - 2019-07-02 00:23:27 --> Model Class Initialized
INFO - 2019-07-02 00:23:27 --> Final output sent to browser
DEBUG - 2019-07-02 00:23:27 --> Total execution time: 0.7274
INFO - 2019-07-02 00:23:28 --> Helper loaded: language_helper
INFO - 2019-07-02 00:23:28 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:23:28 --> Model Class Initialized
INFO - 2019-07-02 00:23:28 --> Model Class Initialized
INFO - 2019-07-02 00:23:28 --> Model Class Initialized
INFO - 2019-07-02 00:23:28 --> Model Class Initialized
INFO - 2019-07-02 00:23:28 --> Model Class Initialized
INFO - 2019-07-02 00:23:28 --> Final output sent to browser
DEBUG - 2019-07-02 00:23:28 --> Total execution time: 0.7198
INFO - 2019-07-02 00:23:40 --> Helper loaded: language_helper
INFO - 2019-07-02 00:23:40 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:23:40 --> Model Class Initialized
INFO - 2019-07-02 00:23:40 --> Model Class Initialized
INFO - 2019-07-02 00:23:40 --> Model Class Initialized
INFO - 2019-07-02 00:23:40 --> Model Class Initialized
INFO - 2019-07-02 00:23:40 --> Model Class Initialized
INFO - 2019-07-02 00:23:56 --> Helper loaded: language_helper
INFO - 2019-07-02 00:23:56 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:23:56 --> Model Class Initialized
INFO - 2019-07-02 00:23:56 --> Model Class Initialized
INFO - 2019-07-02 00:23:56 --> Model Class Initialized
INFO - 2019-07-02 00:23:56 --> Model Class Initialized
INFO - 2019-07-02 00:23:56 --> Model Class Initialized
INFO - 2019-07-02 00:25:43 --> Helper loaded: language_helper
INFO - 2019-07-02 00:25:43 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:25:43 --> Model Class Initialized
INFO - 2019-07-02 00:25:43 --> Model Class Initialized
INFO - 2019-07-02 00:25:43 --> Model Class Initialized
INFO - 2019-07-02 00:25:43 --> Model Class Initialized
INFO - 2019-07-02 00:25:43 --> Model Class Initialized
INFO - 2019-07-02 00:25:43 --> Final output sent to browser
DEBUG - 2019-07-02 00:25:43 --> Total execution time: 0.7353
INFO - 2019-07-02 00:25:44 --> Helper loaded: language_helper
INFO - 2019-07-02 00:25:44 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:25:44 --> Model Class Initialized
INFO - 2019-07-02 00:25:44 --> Model Class Initialized
INFO - 2019-07-02 00:25:44 --> Model Class Initialized
INFO - 2019-07-02 00:25:44 --> Model Class Initialized
INFO - 2019-07-02 00:25:44 --> Model Class Initialized
INFO - 2019-07-02 00:25:44 --> Final output sent to browser
DEBUG - 2019-07-02 00:25:44 --> Total execution time: 0.8047
INFO - 2019-07-02 00:25:51 --> Helper loaded: language_helper
INFO - 2019-07-02 00:25:51 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:25:51 --> Model Class Initialized
INFO - 2019-07-02 00:25:51 --> Model Class Initialized
INFO - 2019-07-02 00:25:51 --> Model Class Initialized
INFO - 2019-07-02 00:25:51 --> Model Class Initialized
INFO - 2019-07-02 00:25:51 --> Model Class Initialized
INFO - 2019-07-02 00:25:51 --> Final output sent to browser
DEBUG - 2019-07-02 00:25:51 --> Total execution time: 0.7434
INFO - 2019-07-02 00:25:51 --> Helper loaded: language_helper
INFO - 2019-07-02 00:25:51 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:25:51 --> Model Class Initialized
INFO - 2019-07-02 00:25:51 --> Model Class Initialized
INFO - 2019-07-02 00:25:51 --> Model Class Initialized
INFO - 2019-07-02 00:25:51 --> Model Class Initialized
INFO - 2019-07-02 00:25:51 --> Model Class Initialized
INFO - 2019-07-02 00:25:51 --> Final output sent to browser
DEBUG - 2019-07-02 00:25:51 --> Total execution time: 0.7841
INFO - 2019-07-02 00:25:53 --> Helper loaded: language_helper
INFO - 2019-07-02 00:25:53 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:25:53 --> Model Class Initialized
INFO - 2019-07-02 00:25:53 --> Model Class Initialized
INFO - 2019-07-02 00:25:53 --> Model Class Initialized
INFO - 2019-07-02 00:25:53 --> Model Class Initialized
INFO - 2019-07-02 00:25:54 --> Model Class Initialized
INFO - 2019-07-02 00:25:54 --> Final output sent to browser
DEBUG - 2019-07-02 00:25:54 --> Total execution time: 0.7408
INFO - 2019-07-02 00:26:18 --> Helper loaded: language_helper
INFO - 2019-07-02 00:26:18 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:26:18 --> Model Class Initialized
INFO - 2019-07-02 00:26:18 --> Model Class Initialized
INFO - 2019-07-02 00:26:18 --> Model Class Initialized
INFO - 2019-07-02 00:26:18 --> Model Class Initialized
INFO - 2019-07-02 00:26:18 --> Model Class Initialized
INFO - 2019-07-02 00:26:18 --> Final output sent to browser
DEBUG - 2019-07-02 00:26:18 --> Total execution time: 0.7364
INFO - 2019-07-02 00:26:18 --> Helper loaded: language_helper
INFO - 2019-07-02 00:26:18 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:26:18 --> Model Class Initialized
INFO - 2019-07-02 00:26:18 --> Model Class Initialized
INFO - 2019-07-02 00:26:18 --> Model Class Initialized
INFO - 2019-07-02 00:26:18 --> Model Class Initialized
INFO - 2019-07-02 00:26:18 --> Model Class Initialized
INFO - 2019-07-02 00:26:18 --> Final output sent to browser
DEBUG - 2019-07-02 00:26:18 --> Total execution time: 0.7537
INFO - 2019-07-02 00:26:23 --> Helper loaded: language_helper
INFO - 2019-07-02 00:26:23 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:26:23 --> Model Class Initialized
INFO - 2019-07-02 00:26:23 --> Model Class Initialized
INFO - 2019-07-02 00:26:23 --> Model Class Initialized
INFO - 2019-07-02 00:26:23 --> Model Class Initialized
INFO - 2019-07-02 00:26:23 --> Model Class Initialized
INFO - 2019-07-02 00:26:23 --> Final output sent to browser
DEBUG - 2019-07-02 00:26:23 --> Total execution time: 0.7426
INFO - 2019-07-02 00:26:28 --> Helper loaded: language_helper
INFO - 2019-07-02 00:26:28 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:26:28 --> Model Class Initialized
INFO - 2019-07-02 00:26:28 --> Model Class Initialized
INFO - 2019-07-02 00:26:28 --> Model Class Initialized
INFO - 2019-07-02 00:26:28 --> Model Class Initialized
INFO - 2019-07-02 00:26:28 --> Model Class Initialized
INFO - 2019-07-02 00:26:28 --> Final output sent to browser
DEBUG - 2019-07-02 00:26:28 --> Total execution time: 1.1361
INFO - 2019-07-02 00:26:28 --> Helper loaded: language_helper
INFO - 2019-07-02 00:26:28 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:26:28 --> Model Class Initialized
INFO - 2019-07-02 00:26:28 --> Model Class Initialized
INFO - 2019-07-02 00:26:29 --> Model Class Initialized
INFO - 2019-07-02 00:26:29 --> Model Class Initialized
INFO - 2019-07-02 00:26:29 --> Final output sent to browser
DEBUG - 2019-07-02 00:26:29 --> Total execution time: 1.3878
INFO - 2019-07-02 00:26:29 --> Helper loaded: language_helper
INFO - 2019-07-02 00:26:29 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:26:29 --> Model Class Initialized
INFO - 2019-07-02 00:26:29 --> Model Class Initialized
INFO - 2019-07-02 00:26:29 --> Model Class Initialized
INFO - 2019-07-02 00:26:29 --> Model Class Initialized
INFO - 2019-07-02 00:26:29 --> Model Class Initialized
INFO - 2019-07-02 00:26:29 --> Final output sent to browser
DEBUG - 2019-07-02 00:26:29 --> Total execution time: 0.7993
INFO - 2019-07-02 00:26:58 --> Helper loaded: language_helper
INFO - 2019-07-02 00:26:58 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:26:58 --> Model Class Initialized
INFO - 2019-07-02 00:26:58 --> Model Class Initialized
INFO - 2019-07-02 00:26:58 --> Model Class Initialized
INFO - 2019-07-02 00:26:58 --> Model Class Initialized
INFO - 2019-07-02 00:26:58 --> Model Class Initialized
INFO - 2019-07-02 00:26:58 --> Final output sent to browser
DEBUG - 2019-07-02 00:26:58 --> Total execution time: 0.7176
INFO - 2019-07-02 00:26:59 --> Helper loaded: language_helper
INFO - 2019-07-02 00:26:59 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:26:59 --> Model Class Initialized
INFO - 2019-07-02 00:26:59 --> Model Class Initialized
INFO - 2019-07-02 00:26:59 --> Model Class Initialized
INFO - 2019-07-02 00:26:59 --> Model Class Initialized
INFO - 2019-07-02 00:26:59 --> Model Class Initialized
INFO - 2019-07-02 00:26:59 --> Final output sent to browser
DEBUG - 2019-07-02 00:26:59 --> Total execution time: 0.7076
INFO - 2019-07-02 00:27:03 --> Helper loaded: language_helper
INFO - 2019-07-02 00:27:03 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:27:03 --> Model Class Initialized
INFO - 2019-07-02 00:27:03 --> Model Class Initialized
INFO - 2019-07-02 00:27:03 --> Model Class Initialized
INFO - 2019-07-02 00:27:03 --> Model Class Initialized
INFO - 2019-07-02 00:27:03 --> Model Class Initialized
INFO - 2019-07-02 00:27:03 --> Final output sent to browser
DEBUG - 2019-07-02 00:27:03 --> Total execution time: 0.7475
INFO - 2019-07-02 00:27:03 --> Helper loaded: language_helper
INFO - 2019-07-02 00:27:03 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:27:03 --> Model Class Initialized
INFO - 2019-07-02 00:27:03 --> Model Class Initialized
INFO - 2019-07-02 00:27:03 --> Model Class Initialized
INFO - 2019-07-02 00:27:04 --> Model Class Initialized
INFO - 2019-07-02 00:27:04 --> Model Class Initialized
INFO - 2019-07-02 00:27:04 --> Final output sent to browser
DEBUG - 2019-07-02 00:27:04 --> Total execution time: 0.7693
INFO - 2019-07-02 00:27:05 --> Helper loaded: language_helper
INFO - 2019-07-02 00:27:05 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:27:05 --> Model Class Initialized
INFO - 2019-07-02 00:27:05 --> Model Class Initialized
INFO - 2019-07-02 00:27:05 --> Model Class Initialized
INFO - 2019-07-02 00:27:05 --> Model Class Initialized
INFO - 2019-07-02 00:27:05 --> Model Class Initialized
INFO - 2019-07-02 00:27:05 --> Final output sent to browser
DEBUG - 2019-07-02 00:27:05 --> Total execution time: 0.7609
INFO - 2019-07-02 00:27:14 --> Helper loaded: language_helper
INFO - 2019-07-02 00:27:14 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:27:14 --> Model Class Initialized
INFO - 2019-07-02 00:27:14 --> Model Class Initialized
INFO - 2019-07-02 00:27:14 --> Model Class Initialized
INFO - 2019-07-02 00:27:14 --> Model Class Initialized
INFO - 2019-07-02 00:27:14 --> Model Class Initialized
INFO - 2019-07-02 00:27:14 --> Helper loaded: language_helper
INFO - 2019-07-02 00:27:14 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:27:14 --> Model Class Initialized
INFO - 2019-07-02 00:27:14 --> Model Class Initialized
INFO - 2019-07-02 00:27:14 --> Model Class Initialized
INFO - 2019-07-02 00:27:14 --> Model Class Initialized
INFO - 2019-07-02 00:27:14 --> Model Class Initialized
INFO - 2019-07-02 00:27:14 --> Final output sent to browser
DEBUG - 2019-07-02 00:27:14 --> Total execution time: 1.3159
INFO - 2019-07-02 00:27:15 --> Helper loaded: language_helper
INFO - 2019-07-02 00:27:15 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:27:15 --> Model Class Initialized
INFO - 2019-07-02 00:27:15 --> Model Class Initialized
INFO - 2019-07-02 00:27:15 --> Model Class Initialized
INFO - 2019-07-02 00:27:15 --> Model Class Initialized
INFO - 2019-07-02 00:27:15 --> Model Class Initialized
INFO - 2019-07-02 00:27:15 --> Final output sent to browser
DEBUG - 2019-07-02 00:27:15 --> Total execution time: 0.7465
INFO - 2019-07-02 00:28:40 --> Helper loaded: language_helper
INFO - 2019-07-02 00:28:40 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:28:40 --> Model Class Initialized
INFO - 2019-07-02 00:28:40 --> Model Class Initialized
INFO - 2019-07-02 00:28:40 --> Model Class Initialized
INFO - 2019-07-02 00:28:40 --> Model Class Initialized
INFO - 2019-07-02 00:28:41 --> Model Class Initialized
INFO - 2019-07-02 00:28:41 --> Final output sent to browser
DEBUG - 2019-07-02 00:28:41 --> Total execution time: 0.7613
INFO - 2019-07-02 00:28:41 --> Helper loaded: language_helper
INFO - 2019-07-02 00:28:41 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:28:41 --> Model Class Initialized
INFO - 2019-07-02 00:28:41 --> Model Class Initialized
INFO - 2019-07-02 00:28:41 --> Model Class Initialized
INFO - 2019-07-02 00:28:41 --> Model Class Initialized
INFO - 2019-07-02 00:28:41 --> Model Class Initialized
INFO - 2019-07-02 00:28:41 --> Final output sent to browser
DEBUG - 2019-07-02 00:28:41 --> Total execution time: 0.7634
INFO - 2019-07-02 00:28:44 --> Helper loaded: language_helper
INFO - 2019-07-02 00:28:44 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:28:44 --> Model Class Initialized
INFO - 2019-07-02 00:28:44 --> Model Class Initialized
INFO - 2019-07-02 00:28:44 --> Model Class Initialized
INFO - 2019-07-02 00:28:44 --> Model Class Initialized
INFO - 2019-07-02 00:28:44 --> Model Class Initialized
INFO - 2019-07-02 00:28:44 --> Final output sent to browser
DEBUG - 2019-07-02 00:28:44 --> Total execution time: 0.7468
INFO - 2019-07-02 00:28:50 --> Helper loaded: language_helper
INFO - 2019-07-02 00:28:50 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:28:50 --> Model Class Initialized
INFO - 2019-07-02 00:28:50 --> Model Class Initialized
INFO - 2019-07-02 00:28:50 --> Model Class Initialized
INFO - 2019-07-02 00:28:50 --> Model Class Initialized
INFO - 2019-07-02 00:28:50 --> Model Class Initialized
INFO - 2019-07-02 00:28:50 --> Final output sent to browser
DEBUG - 2019-07-02 00:28:50 --> Total execution time: 1.0299
INFO - 2019-07-02 00:28:51 --> Helper loaded: language_helper
INFO - 2019-07-02 00:28:51 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:28:51 --> Model Class Initialized
INFO - 2019-07-02 00:28:51 --> Model Class Initialized
INFO - 2019-07-02 00:28:51 --> Model Class Initialized
INFO - 2019-07-02 00:28:51 --> Model Class Initialized
INFO - 2019-07-02 00:28:51 --> Model Class Initialized
INFO - 2019-07-02 00:28:51 --> Final output sent to browser
DEBUG - 2019-07-02 00:28:51 --> Total execution time: 0.7525
INFO - 2019-07-02 00:29:09 --> Helper loaded: language_helper
INFO - 2019-07-02 00:29:09 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:29:09 --> Model Class Initialized
INFO - 2019-07-02 00:29:09 --> Model Class Initialized
INFO - 2019-07-02 00:29:09 --> Model Class Initialized
INFO - 2019-07-02 00:29:09 --> Model Class Initialized
INFO - 2019-07-02 00:29:09 --> Final output sent to browser
DEBUG - 2019-07-02 00:29:09 --> Total execution time: 0.7265
INFO - 2019-07-02 00:29:23 --> Helper loaded: language_helper
INFO - 2019-07-02 00:29:23 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:29:23 --> Model Class Initialized
INFO - 2019-07-02 00:29:23 --> Model Class Initialized
INFO - 2019-07-02 00:29:23 --> Model Class Initialized
INFO - 2019-07-02 00:29:23 --> Model Class Initialized
INFO - 2019-07-02 00:29:23 --> Model Class Initialized
INFO - 2019-07-02 00:29:23 --> Final output sent to browser
DEBUG - 2019-07-02 00:29:23 --> Total execution time: 0.7440
INFO - 2019-07-02 00:29:23 --> Helper loaded: language_helper
INFO - 2019-07-02 00:29:23 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:29:23 --> Model Class Initialized
INFO - 2019-07-02 00:29:23 --> Model Class Initialized
INFO - 2019-07-02 00:29:23 --> Model Class Initialized
INFO - 2019-07-02 00:29:23 --> Model Class Initialized
INFO - 2019-07-02 00:29:23 --> Model Class Initialized
INFO - 2019-07-02 00:29:23 --> Final output sent to browser
DEBUG - 2019-07-02 00:29:23 --> Total execution time: 0.7473
INFO - 2019-07-02 00:29:44 --> Helper loaded: language_helper
INFO - 2019-07-02 00:29:44 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:29:44 --> Model Class Initialized
INFO - 2019-07-02 00:29:44 --> Model Class Initialized
INFO - 2019-07-02 00:29:44 --> Model Class Initialized
INFO - 2019-07-02 00:29:44 --> Model Class Initialized
INFO - 2019-07-02 00:29:44 --> Model Class Initialized
INFO - 2019-07-02 00:29:44 --> Final output sent to browser
DEBUG - 2019-07-02 00:29:44 --> Total execution time: 0.7777
INFO - 2019-07-02 00:29:45 --> Helper loaded: language_helper
INFO - 2019-07-02 00:29:45 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:29:45 --> Model Class Initialized
INFO - 2019-07-02 00:29:45 --> Model Class Initialized
INFO - 2019-07-02 00:29:45 --> Model Class Initialized
INFO - 2019-07-02 00:29:45 --> Model Class Initialized
INFO - 2019-07-02 00:29:45 --> Model Class Initialized
INFO - 2019-07-02 00:29:45 --> Final output sent to browser
DEBUG - 2019-07-02 00:29:45 --> Total execution time: 0.7576
INFO - 2019-07-02 00:30:02 --> Helper loaded: language_helper
INFO - 2019-07-02 00:30:02 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:30:02 --> Model Class Initialized
INFO - 2019-07-02 00:30:02 --> Model Class Initialized
INFO - 2019-07-02 00:30:02 --> Model Class Initialized
INFO - 2019-07-02 00:30:02 --> Model Class Initialized
INFO - 2019-07-02 00:30:02 --> Model Class Initialized
INFO - 2019-07-02 00:30:02 --> Final output sent to browser
DEBUG - 2019-07-02 00:30:02 --> Total execution time: 0.8922
INFO - 2019-07-02 00:30:03 --> Helper loaded: language_helper
INFO - 2019-07-02 00:30:03 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:30:03 --> Model Class Initialized
INFO - 2019-07-02 00:30:03 --> Model Class Initialized
INFO - 2019-07-02 00:30:03 --> Model Class Initialized
INFO - 2019-07-02 00:30:03 --> Model Class Initialized
INFO - 2019-07-02 00:30:03 --> Model Class Initialized
INFO - 2019-07-02 00:30:03 --> Final output sent to browser
DEBUG - 2019-07-02 00:30:03 --> Total execution time: 1.1609
INFO - 2019-07-02 00:30:04 --> Helper loaded: language_helper
INFO - 2019-07-02 00:30:04 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:30:04 --> Model Class Initialized
INFO - 2019-07-02 00:30:04 --> Model Class Initialized
INFO - 2019-07-02 00:30:04 --> Model Class Initialized
INFO - 2019-07-02 00:30:04 --> Model Class Initialized
INFO - 2019-07-02 00:30:04 --> Model Class Initialized
INFO - 2019-07-02 00:30:04 --> Final output sent to browser
DEBUG - 2019-07-02 00:30:04 --> Total execution time: 1.0798
INFO - 2019-07-02 00:30:04 --> Helper loaded: language_helper
INFO - 2019-07-02 00:30:04 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:30:04 --> Model Class Initialized
INFO - 2019-07-02 00:30:04 --> Model Class Initialized
INFO - 2019-07-02 00:30:04 --> Model Class Initialized
INFO - 2019-07-02 00:30:04 --> Model Class Initialized
INFO - 2019-07-02 00:30:04 --> Model Class Initialized
INFO - 2019-07-02 00:30:04 --> Final output sent to browser
DEBUG - 2019-07-02 00:30:04 --> Total execution time: 0.7469
INFO - 2019-07-02 00:30:52 --> Helper loaded: language_helper
INFO - 2019-07-02 00:30:52 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:30:52 --> Model Class Initialized
INFO - 2019-07-02 00:30:52 --> Model Class Initialized
INFO - 2019-07-02 00:30:52 --> Model Class Initialized
INFO - 2019-07-02 00:30:52 --> Model Class Initialized
INFO - 2019-07-02 00:30:52 --> Model Class Initialized
INFO - 2019-07-02 00:30:52 --> Final output sent to browser
DEBUG - 2019-07-02 00:30:52 --> Total execution time: 1.1845
INFO - 2019-07-02 00:30:52 --> Helper loaded: language_helper
INFO - 2019-07-02 00:30:52 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:30:52 --> Model Class Initialized
INFO - 2019-07-02 00:30:52 --> Model Class Initialized
INFO - 2019-07-02 00:30:52 --> Model Class Initialized
INFO - 2019-07-02 00:30:52 --> Model Class Initialized
INFO - 2019-07-02 00:30:52 --> Model Class Initialized
INFO - 2019-07-02 00:30:52 --> Final output sent to browser
DEBUG - 2019-07-02 00:30:52 --> Total execution time: 1.1020
INFO - 2019-07-02 00:30:53 --> Helper loaded: language_helper
INFO - 2019-07-02 00:30:53 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:30:53 --> Model Class Initialized
INFO - 2019-07-02 00:30:53 --> Model Class Initialized
INFO - 2019-07-02 00:30:53 --> Model Class Initialized
INFO - 2019-07-02 00:30:53 --> Model Class Initialized
INFO - 2019-07-02 00:30:53 --> Model Class Initialized
INFO - 2019-07-02 00:30:53 --> Final output sent to browser
DEBUG - 2019-07-02 00:30:53 --> Total execution time: 0.7919
INFO - 2019-07-02 00:30:55 --> Helper loaded: language_helper
INFO - 2019-07-02 00:30:55 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:30:55 --> Model Class Initialized
INFO - 2019-07-02 00:30:55 --> Model Class Initialized
INFO - 2019-07-02 00:30:55 --> Model Class Initialized
INFO - 2019-07-02 00:30:55 --> Model Class Initialized
INFO - 2019-07-02 00:30:55 --> Model Class Initialized
INFO - 2019-07-02 00:30:55 --> Final output sent to browser
DEBUG - 2019-07-02 00:30:55 --> Total execution time: 0.7460
INFO - 2019-07-02 00:31:00 --> Helper loaded: language_helper
INFO - 2019-07-02 00:31:00 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:31:00 --> Model Class Initialized
INFO - 2019-07-02 00:31:00 --> Model Class Initialized
INFO - 2019-07-02 00:31:00 --> Model Class Initialized
INFO - 2019-07-02 00:31:00 --> Model Class Initialized
INFO - 2019-07-02 00:31:00 --> Model Class Initialized
INFO - 2019-07-02 00:31:00 --> Final output sent to browser
DEBUG - 2019-07-02 00:31:00 --> Total execution time: 1.1319
INFO - 2019-07-02 00:31:01 --> Helper loaded: language_helper
INFO - 2019-07-02 00:31:01 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:31:01 --> Model Class Initialized
INFO - 2019-07-02 00:31:01 --> Model Class Initialized
INFO - 2019-07-02 00:31:01 --> Model Class Initialized
INFO - 2019-07-02 00:31:01 --> Model Class Initialized
INFO - 2019-07-02 00:31:01 --> Model Class Initialized
ERROR - 2019-07-02 00:31:01 --> Severity: Notice --> Undefined property: Uploads::$request C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Uploads.php 16
ERROR - 2019-07-02 00:31:01 --> Severity: Error --> Call to a member function post() on null C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Uploads.php 16
INFO - 2019-07-02 00:31:01 --> Helper loaded: language_helper
INFO - 2019-07-02 00:31:01 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:31:01 --> Model Class Initialized
INFO - 2019-07-02 00:31:01 --> Model Class Initialized
INFO - 2019-07-02 00:31:01 --> Model Class Initialized
INFO - 2019-07-02 00:31:01 --> Model Class Initialized
INFO - 2019-07-02 00:31:01 --> Model Class Initialized
INFO - 2019-07-02 00:31:01 --> Final output sent to browser
DEBUG - 2019-07-02 00:31:01 --> Total execution time: 0.9139
INFO - 2019-07-02 00:31:40 --> Helper loaded: language_helper
INFO - 2019-07-02 00:31:40 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:31:40 --> Model Class Initialized
INFO - 2019-07-02 00:31:40 --> Model Class Initialized
INFO - 2019-07-02 00:31:40 --> Model Class Initialized
INFO - 2019-07-02 00:31:40 --> Model Class Initialized
INFO - 2019-07-02 00:31:40 --> Model Class Initialized
INFO - 2019-07-02 00:35:07 --> Helper loaded: language_helper
INFO - 2019-07-02 00:35:07 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:35:07 --> Model Class Initialized
INFO - 2019-07-02 00:35:07 --> Model Class Initialized
INFO - 2019-07-02 00:35:07 --> Model Class Initialized
INFO - 2019-07-02 00:35:07 --> Model Class Initialized
INFO - 2019-07-02 00:35:07 --> Model Class Initialized
INFO - 2019-07-02 00:35:07 --> Final output sent to browser
DEBUG - 2019-07-02 00:35:07 --> Total execution time: 0.7701
INFO - 2019-07-02 00:35:08 --> Helper loaded: language_helper
INFO - 2019-07-02 00:35:08 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:35:08 --> Model Class Initialized
INFO - 2019-07-02 00:35:08 --> Model Class Initialized
INFO - 2019-07-02 00:35:08 --> Model Class Initialized
INFO - 2019-07-02 00:35:08 --> Model Class Initialized
INFO - 2019-07-02 00:35:08 --> Model Class Initialized
INFO - 2019-07-02 00:35:08 --> Final output sent to browser
DEBUG - 2019-07-02 00:35:08 --> Total execution time: 0.7572
INFO - 2019-07-02 00:35:31 --> Helper loaded: language_helper
INFO - 2019-07-02 00:35:31 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:35:31 --> Model Class Initialized
INFO - 2019-07-02 00:35:31 --> Model Class Initialized
INFO - 2019-07-02 00:35:31 --> Model Class Initialized
INFO - 2019-07-02 00:35:31 --> Model Class Initialized
INFO - 2019-07-02 00:35:31 --> Model Class Initialized
INFO - 2019-07-02 00:35:31 --> Final output sent to browser
DEBUG - 2019-07-02 00:35:31 --> Total execution time: 0.7629
INFO - 2019-07-02 00:35:32 --> Helper loaded: language_helper
INFO - 2019-07-02 00:35:32 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:35:32 --> Model Class Initialized
INFO - 2019-07-02 00:35:32 --> Model Class Initialized
INFO - 2019-07-02 00:35:32 --> Model Class Initialized
INFO - 2019-07-02 00:35:32 --> Model Class Initialized
INFO - 2019-07-02 00:35:32 --> Model Class Initialized
INFO - 2019-07-02 00:35:32 --> Final output sent to browser
DEBUG - 2019-07-02 00:35:32 --> Total execution time: 0.7451
INFO - 2019-07-02 00:35:46 --> Helper loaded: language_helper
INFO - 2019-07-02 00:35:46 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:35:46 --> Model Class Initialized
INFO - 2019-07-02 00:35:46 --> Model Class Initialized
INFO - 2019-07-02 00:35:46 --> Model Class Initialized
INFO - 2019-07-02 00:35:46 --> Model Class Initialized
INFO - 2019-07-02 00:35:46 --> Model Class Initialized
INFO - 2019-07-02 00:35:46 --> Final output sent to browser
DEBUG - 2019-07-02 00:35:46 --> Total execution time: 0.7578
INFO - 2019-07-02 00:35:47 --> Helper loaded: language_helper
INFO - 2019-07-02 00:35:47 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:35:47 --> Model Class Initialized
INFO - 2019-07-02 00:35:47 --> Model Class Initialized
INFO - 2019-07-02 00:35:47 --> Model Class Initialized
INFO - 2019-07-02 00:35:47 --> Model Class Initialized
INFO - 2019-07-02 00:35:47 --> Model Class Initialized
INFO - 2019-07-02 00:35:47 --> Final output sent to browser
DEBUG - 2019-07-02 00:35:47 --> Total execution time: 0.7768
INFO - 2019-07-02 00:35:49 --> Helper loaded: language_helper
INFO - 2019-07-02 00:35:49 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:35:49 --> Model Class Initialized
INFO - 2019-07-02 00:35:49 --> Model Class Initialized
INFO - 2019-07-02 00:35:49 --> Model Class Initialized
INFO - 2019-07-02 00:35:49 --> Model Class Initialized
INFO - 2019-07-02 00:35:49 --> Model Class Initialized
INFO - 2019-07-02 00:35:49 --> Final output sent to browser
DEBUG - 2019-07-02 00:35:49 --> Total execution time: 0.7711
INFO - 2019-07-02 00:35:50 --> Helper loaded: language_helper
INFO - 2019-07-02 00:35:50 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:35:50 --> Model Class Initialized
INFO - 2019-07-02 00:35:50 --> Model Class Initialized
INFO - 2019-07-02 00:35:50 --> Model Class Initialized
INFO - 2019-07-02 00:35:50 --> Model Class Initialized
INFO - 2019-07-02 00:35:50 --> Model Class Initialized
INFO - 2019-07-02 00:35:50 --> Final output sent to browser
DEBUG - 2019-07-02 00:35:50 --> Total execution time: 0.7561
INFO - 2019-07-02 00:41:09 --> Helper loaded: language_helper
INFO - 2019-07-02 00:41:09 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:41:09 --> Model Class Initialized
INFO - 2019-07-02 00:41:09 --> Model Class Initialized
INFO - 2019-07-02 00:41:09 --> Model Class Initialized
INFO - 2019-07-02 00:41:09 --> Model Class Initialized
INFO - 2019-07-02 00:41:09 --> Model Class Initialized
INFO - 2019-07-02 00:41:09 --> Final output sent to browser
DEBUG - 2019-07-02 00:41:09 --> Total execution time: 0.8022
INFO - 2019-07-02 00:41:10 --> Helper loaded: language_helper
INFO - 2019-07-02 00:41:10 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:41:10 --> Model Class Initialized
INFO - 2019-07-02 00:41:10 --> Model Class Initialized
INFO - 2019-07-02 00:41:10 --> Model Class Initialized
INFO - 2019-07-02 00:41:10 --> Model Class Initialized
INFO - 2019-07-02 00:41:10 --> Model Class Initialized
INFO - 2019-07-02 00:41:10 --> Final output sent to browser
DEBUG - 2019-07-02 00:41:10 --> Total execution time: 0.7960
INFO - 2019-07-02 00:41:14 --> Helper loaded: language_helper
INFO - 2019-07-02 00:41:14 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:41:14 --> Model Class Initialized
INFO - 2019-07-02 00:41:14 --> Model Class Initialized
INFO - 2019-07-02 00:41:14 --> Model Class Initialized
INFO - 2019-07-02 00:41:14 --> Model Class Initialized
INFO - 2019-07-02 00:41:14 --> Model Class Initialized
INFO - 2019-07-02 00:41:14 --> Final output sent to browser
DEBUG - 2019-07-02 00:41:14 --> Total execution time: 0.7864
INFO - 2019-07-02 00:41:19 --> Helper loaded: language_helper
INFO - 2019-07-02 00:41:19 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:41:19 --> Model Class Initialized
INFO - 2019-07-02 00:41:19 --> Model Class Initialized
INFO - 2019-07-02 00:41:19 --> Model Class Initialized
INFO - 2019-07-02 00:41:19 --> Model Class Initialized
INFO - 2019-07-02 00:41:19 --> Model Class Initialized
INFO - 2019-07-02 00:41:19 --> Final output sent to browser
DEBUG - 2019-07-02 00:41:19 --> Total execution time: 1.0148
INFO - 2019-07-02 00:41:20 --> Helper loaded: language_helper
INFO - 2019-07-02 00:41:20 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:41:20 --> Model Class Initialized
INFO - 2019-07-02 00:41:20 --> Model Class Initialized
INFO - 2019-07-02 00:41:20 --> Model Class Initialized
INFO - 2019-07-02 00:41:20 --> Model Class Initialized
INFO - 2019-07-02 00:41:20 --> Model Class Initialized
INFO - 2019-07-02 00:41:20 --> Final output sent to browser
DEBUG - 2019-07-02 00:41:20 --> Total execution time: 1.3038
INFO - 2019-07-02 00:41:20 --> Helper loaded: language_helper
INFO - 2019-07-02 00:41:20 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:41:20 --> Model Class Initialized
INFO - 2019-07-02 00:41:20 --> Model Class Initialized
INFO - 2019-07-02 00:41:20 --> Model Class Initialized
INFO - 2019-07-02 00:41:20 --> Model Class Initialized
INFO - 2019-07-02 00:41:20 --> Model Class Initialized
INFO - 2019-07-02 00:41:20 --> Final output sent to browser
DEBUG - 2019-07-02 00:41:20 --> Total execution time: 0.9242
INFO - 2019-07-02 00:42:38 --> Helper loaded: language_helper
INFO - 2019-07-02 00:42:38 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:42:38 --> Model Class Initialized
INFO - 2019-07-02 00:42:38 --> Model Class Initialized
INFO - 2019-07-02 00:42:38 --> Model Class Initialized
INFO - 2019-07-02 00:42:38 --> Model Class Initialized
INFO - 2019-07-02 00:42:38 --> Model Class Initialized
ERROR - 2019-07-02 00:42:38 --> Severity: Notice --> Undefined index: image C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Uploads.php 21
INFO - 2019-07-02 00:43:05 --> Helper loaded: language_helper
INFO - 2019-07-02 00:43:05 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:43:05 --> Model Class Initialized
INFO - 2019-07-02 00:43:05 --> Model Class Initialized
INFO - 2019-07-02 00:43:05 --> Model Class Initialized
INFO - 2019-07-02 00:43:05 --> Model Class Initialized
INFO - 2019-07-02 00:43:05 --> Model Class Initialized
ERROR - 2019-07-02 00:43:05 --> Severity: Notice --> Undefined variable: imgKey C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Uploads.php 32
INFO - 2019-07-02 00:43:05 --> Upload Class Initialized
INFO - 2019-07-02 00:43:05 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2019-07-02 00:43:05 --> You did not select a file to upload.
DEBUG - 2019-07-02 00:43:05 --> You did not select a file to upload.
INFO - 2019-07-02 00:43:05 --> Final output sent to browser
DEBUG - 2019-07-02 00:43:05 --> Total execution time: 0.8503
INFO - 2019-07-02 00:43:27 --> Helper loaded: language_helper
INFO - 2019-07-02 00:43:27 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:43:27 --> Model Class Initialized
INFO - 2019-07-02 00:43:27 --> Model Class Initialized
INFO - 2019-07-02 00:43:27 --> Model Class Initialized
INFO - 2019-07-02 00:43:27 --> Model Class Initialized
INFO - 2019-07-02 00:43:27 --> Model Class Initialized
INFO - 2019-07-02 00:43:27 --> Upload Class Initialized
INFO - 2019-07-02 00:43:27 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2019-07-02 00:43:27 --> You did not select a file to upload.
INFO - 2019-07-02 00:43:27 --> Final output sent to browser
DEBUG - 2019-07-02 00:43:27 --> Total execution time: 0.7916
INFO - 2019-07-02 00:47:45 --> Helper loaded: language_helper
INFO - 2019-07-02 00:47:45 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:47:45 --> Model Class Initialized
INFO - 2019-07-02 00:47:45 --> Model Class Initialized
INFO - 2019-07-02 00:47:45 --> Model Class Initialized
INFO - 2019-07-02 00:47:45 --> Model Class Initialized
INFO - 2019-07-02 00:47:45 --> Model Class Initialized
INFO - 2019-07-02 00:47:45 --> Final output sent to browser
DEBUG - 2019-07-02 00:47:45 --> Total execution time: 0.8348
INFO - 2019-07-02 00:47:46 --> Helper loaded: language_helper
INFO - 2019-07-02 00:47:46 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:47:46 --> Model Class Initialized
INFO - 2019-07-02 00:47:46 --> Model Class Initialized
INFO - 2019-07-02 00:47:46 --> Model Class Initialized
INFO - 2019-07-02 00:47:46 --> Model Class Initialized
INFO - 2019-07-02 00:47:46 --> Model Class Initialized
INFO - 2019-07-02 00:47:46 --> Final output sent to browser
DEBUG - 2019-07-02 00:47:46 --> Total execution time: 0.7827
INFO - 2019-07-02 00:48:03 --> Helper loaded: language_helper
INFO - 2019-07-02 00:48:03 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:48:03 --> Model Class Initialized
INFO - 2019-07-02 00:48:03 --> Model Class Initialized
INFO - 2019-07-02 00:48:03 --> Model Class Initialized
INFO - 2019-07-02 00:48:03 --> Model Class Initialized
INFO - 2019-07-02 00:48:03 --> Model Class Initialized
INFO - 2019-07-02 00:48:03 --> Final output sent to browser
DEBUG - 2019-07-02 00:48:03 --> Total execution time: 0.7920
INFO - 2019-07-02 00:48:04 --> Helper loaded: language_helper
INFO - 2019-07-02 00:48:04 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:48:04 --> Model Class Initialized
INFO - 2019-07-02 00:48:04 --> Model Class Initialized
INFO - 2019-07-02 00:48:04 --> Model Class Initialized
INFO - 2019-07-02 00:48:04 --> Model Class Initialized
INFO - 2019-07-02 00:48:04 --> Model Class Initialized
INFO - 2019-07-02 00:48:04 --> Final output sent to browser
DEBUG - 2019-07-02 00:48:04 --> Total execution time: 0.8417
INFO - 2019-07-02 00:49:33 --> Helper loaded: language_helper
INFO - 2019-07-02 00:49:33 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:49:33 --> Model Class Initialized
INFO - 2019-07-02 00:49:33 --> Model Class Initialized
INFO - 2019-07-02 00:49:33 --> Model Class Initialized
INFO - 2019-07-02 00:49:33 --> Model Class Initialized
INFO - 2019-07-02 00:49:33 --> Model Class Initialized
INFO - 2019-07-02 00:49:33 --> Final output sent to browser
DEBUG - 2019-07-02 00:49:33 --> Total execution time: 0.8393
INFO - 2019-07-02 00:49:34 --> Helper loaded: language_helper
INFO - 2019-07-02 00:49:34 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:49:34 --> Model Class Initialized
INFO - 2019-07-02 00:49:34 --> Model Class Initialized
INFO - 2019-07-02 00:49:34 --> Model Class Initialized
INFO - 2019-07-02 00:49:34 --> Model Class Initialized
INFO - 2019-07-02 00:49:34 --> Model Class Initialized
INFO - 2019-07-02 00:49:34 --> Final output sent to browser
DEBUG - 2019-07-02 00:49:34 --> Total execution time: 0.7808
INFO - 2019-07-02 00:50:45 --> Helper loaded: language_helper
INFO - 2019-07-02 00:50:45 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:50:45 --> Model Class Initialized
INFO - 2019-07-02 00:50:45 --> Model Class Initialized
INFO - 2019-07-02 00:50:46 --> Model Class Initialized
INFO - 2019-07-02 00:50:46 --> Model Class Initialized
INFO - 2019-07-02 00:50:46 --> Model Class Initialized
INFO - 2019-07-02 00:50:46 --> Final output sent to browser
DEBUG - 2019-07-02 00:50:46 --> Total execution time: 0.8379
INFO - 2019-07-02 00:50:46 --> Helper loaded: language_helper
INFO - 2019-07-02 00:50:46 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:50:46 --> Model Class Initialized
INFO - 2019-07-02 00:50:46 --> Model Class Initialized
INFO - 2019-07-02 00:50:46 --> Model Class Initialized
INFO - 2019-07-02 00:50:46 --> Model Class Initialized
INFO - 2019-07-02 00:50:46 --> Model Class Initialized
INFO - 2019-07-02 00:50:46 --> Final output sent to browser
DEBUG - 2019-07-02 00:50:46 --> Total execution time: 0.7766
INFO - 2019-07-02 00:51:47 --> Helper loaded: language_helper
INFO - 2019-07-02 00:51:47 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:51:47 --> Model Class Initialized
INFO - 2019-07-02 00:51:47 --> Model Class Initialized
INFO - 2019-07-02 00:51:47 --> Model Class Initialized
INFO - 2019-07-02 00:51:47 --> Model Class Initialized
INFO - 2019-07-02 00:51:47 --> Model Class Initialized
INFO - 2019-07-02 00:51:47 --> Final output sent to browser
DEBUG - 2019-07-02 00:51:47 --> Total execution time: 0.7733
INFO - 2019-07-02 00:51:49 --> Helper loaded: language_helper
INFO - 2019-07-02 00:51:49 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:51:50 --> Model Class Initialized
INFO - 2019-07-02 00:51:50 --> Model Class Initialized
INFO - 2019-07-02 00:51:50 --> Model Class Initialized
INFO - 2019-07-02 00:51:50 --> Model Class Initialized
INFO - 2019-07-02 00:51:50 --> Model Class Initialized
INFO - 2019-07-02 00:51:50 --> Final output sent to browser
DEBUG - 2019-07-02 00:51:50 --> Total execution time: 0.7731
INFO - 2019-07-02 00:51:52 --> Helper loaded: language_helper
INFO - 2019-07-02 00:51:52 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 00:51:52 --> Model Class Initialized
INFO - 2019-07-02 00:51:52 --> Model Class Initialized
INFO - 2019-07-02 00:51:52 --> Model Class Initialized
INFO - 2019-07-02 00:51:52 --> Model Class Initialized
INFO - 2019-07-02 00:51:52 --> Model Class Initialized
INFO - 2019-07-02 00:51:52 --> Final output sent to browser
DEBUG - 2019-07-02 00:51:52 --> Total execution time: 0.7755
INFO - 2019-07-02 13:51:42 --> Config Class Initialized
INFO - 2019-07-02 13:51:42 --> Hooks Class Initialized
DEBUG - 2019-07-02 13:51:42 --> UTF-8 Support Enabled
INFO - 2019-07-02 13:51:42 --> Utf8 Class Initialized
INFO - 2019-07-02 13:51:42 --> URI Class Initialized
INFO - 2019-07-02 13:51:42 --> Router Class Initialized
INFO - 2019-07-02 13:51:42 --> Output Class Initialized
INFO - 2019-07-02 13:51:42 --> Security Class Initialized
DEBUG - 2019-07-02 13:51:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 13:51:42 --> Input Class Initialized
INFO - 2019-07-02 13:51:42 --> Language Class Initialized
INFO - 2019-07-02 13:51:42 --> Language Class Initialized
INFO - 2019-07-02 13:51:42 --> Config Class Initialized
INFO - 2019-07-02 13:51:42 --> Loader Class Initialized
DEBUG - 2019-07-02 13:51:42 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 13:51:42 --> Helper loaded: url_helper
INFO - 2019-07-02 13:51:42 --> Helper loaded: inflector_helper
INFO - 2019-07-02 13:51:42 --> Helper loaded: string_helper
INFO - 2019-07-02 13:51:42 --> Helper loaded: array_helper
INFO - 2019-07-02 13:51:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 13:51:42 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 13:51:42 --> Database Driver Class Initialized
INFO - 2019-07-02 13:51:42 --> Controller Class Initialized
INFO - 2019-07-02 19:51:43 --> Helper loaded: language_helper
INFO - 2019-07-02 19:51:43 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 19:51:43 --> Model Class Initialized
INFO - 2019-07-02 19:51:43 --> Model Class Initialized
INFO - 2019-07-02 19:51:43 --> Model Class Initialized
INFO - 2019-07-02 19:51:43 --> Model Class Initialized
INFO - 2019-07-02 19:51:43 --> Final output sent to browser
DEBUG - 2019-07-02 19:51:43 --> Total execution time: 0.9558
INFO - 2019-07-02 13:51:43 --> Config Class Initialized
INFO - 2019-07-02 13:51:43 --> Config Class Initialized
INFO - 2019-07-02 13:51:43 --> Hooks Class Initialized
INFO - 2019-07-02 13:51:43 --> Hooks Class Initialized
DEBUG - 2019-07-02 13:51:43 --> UTF-8 Support Enabled
DEBUG - 2019-07-02 13:51:43 --> UTF-8 Support Enabled
INFO - 2019-07-02 13:51:43 --> Utf8 Class Initialized
INFO - 2019-07-02 13:51:43 --> Utf8 Class Initialized
INFO - 2019-07-02 13:51:43 --> URI Class Initialized
INFO - 2019-07-02 13:51:43 --> URI Class Initialized
INFO - 2019-07-02 13:51:43 --> Router Class Initialized
INFO - 2019-07-02 13:51:43 --> Router Class Initialized
INFO - 2019-07-02 13:51:43 --> Output Class Initialized
INFO - 2019-07-02 13:51:43 --> Output Class Initialized
INFO - 2019-07-02 13:51:43 --> Security Class Initialized
INFO - 2019-07-02 13:51:43 --> Security Class Initialized
DEBUG - 2019-07-02 13:51:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-02 13:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 13:51:43 --> Input Class Initialized
INFO - 2019-07-02 13:51:43 --> Input Class Initialized
INFO - 2019-07-02 13:51:43 --> Language Class Initialized
INFO - 2019-07-02 13:51:43 --> Language Class Initialized
INFO - 2019-07-02 13:51:43 --> Language Class Initialized
INFO - 2019-07-02 13:51:43 --> Config Class Initialized
INFO - 2019-07-02 13:51:43 --> Language Class Initialized
INFO - 2019-07-02 13:51:43 --> Loader Class Initialized
INFO - 2019-07-02 13:51:43 --> Config Class Initialized
DEBUG - 2019-07-02 13:51:43 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 13:51:43 --> Loader Class Initialized
DEBUG - 2019-07-02 13:51:43 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 13:51:43 --> Helper loaded: url_helper
INFO - 2019-07-02 13:51:43 --> Helper loaded: url_helper
INFO - 2019-07-02 13:51:43 --> Helper loaded: inflector_helper
INFO - 2019-07-02 13:51:43 --> Helper loaded: inflector_helper
INFO - 2019-07-02 13:51:43 --> Helper loaded: string_helper
INFO - 2019-07-02 13:51:43 --> Helper loaded: string_helper
INFO - 2019-07-02 13:51:43 --> Helper loaded: array_helper
INFO - 2019-07-02 13:51:43 --> Helper loaded: array_helper
INFO - 2019-07-02 13:51:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 13:51:43 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 13:51:43 --> Database Driver Class Initialized
INFO - 2019-07-02 13:51:43 --> Controller Class Initialized
INFO - 2019-07-02 19:51:43 --> Helper loaded: language_helper
INFO - 2019-07-02 19:51:43 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 19:51:43 --> Model Class Initialized
INFO - 2019-07-02 19:51:43 --> Model Class Initialized
INFO - 2019-07-02 19:51:43 --> Model Class Initialized
INFO - 2019-07-02 19:51:43 --> Model Class Initialized
INFO - 2019-07-02 19:51:43 --> Model Class Initialized
INFO - 2019-07-02 19:51:43 --> Final output sent to browser
DEBUG - 2019-07-02 19:51:43 --> Total execution time: 0.4422
INFO - 2019-07-02 13:51:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 13:51:44 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 13:51:44 --> Database Driver Class Initialized
INFO - 2019-07-02 13:51:44 --> Controller Class Initialized
INFO - 2019-07-02 19:51:44 --> Helper loaded: language_helper
INFO - 2019-07-02 19:51:44 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 19:51:44 --> Model Class Initialized
INFO - 2019-07-02 19:51:44 --> Model Class Initialized
INFO - 2019-07-02 19:51:44 --> Model Class Initialized
INFO - 2019-07-02 19:51:44 --> Model Class Initialized
INFO - 2019-07-02 19:51:44 --> Final output sent to browser
DEBUG - 2019-07-02 19:51:44 --> Total execution time: 0.5450
INFO - 2019-07-02 13:51:48 --> Config Class Initialized
INFO - 2019-07-02 13:51:48 --> Hooks Class Initialized
DEBUG - 2019-07-02 13:51:49 --> UTF-8 Support Enabled
INFO - 2019-07-02 13:51:49 --> Utf8 Class Initialized
INFO - 2019-07-02 13:51:49 --> URI Class Initialized
INFO - 2019-07-02 13:51:49 --> Router Class Initialized
INFO - 2019-07-02 13:51:49 --> Output Class Initialized
INFO - 2019-07-02 13:51:49 --> Security Class Initialized
DEBUG - 2019-07-02 13:51:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 13:51:49 --> Input Class Initialized
INFO - 2019-07-02 13:51:49 --> Language Class Initialized
INFO - 2019-07-02 13:51:49 --> Language Class Initialized
INFO - 2019-07-02 13:51:49 --> Config Class Initialized
INFO - 2019-07-02 13:51:49 --> Loader Class Initialized
DEBUG - 2019-07-02 13:51:49 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 13:51:49 --> Helper loaded: url_helper
INFO - 2019-07-02 13:51:49 --> Helper loaded: inflector_helper
INFO - 2019-07-02 13:51:49 --> Helper loaded: string_helper
INFO - 2019-07-02 13:51:49 --> Helper loaded: array_helper
INFO - 2019-07-02 13:51:49 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 13:51:49 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 13:51:49 --> Database Driver Class Initialized
INFO - 2019-07-02 13:51:49 --> Controller Class Initialized
INFO - 2019-07-02 19:51:49 --> Helper loaded: language_helper
INFO - 2019-07-02 19:51:49 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 19:51:49 --> Model Class Initialized
INFO - 2019-07-02 19:51:49 --> Model Class Initialized
INFO - 2019-07-02 19:51:49 --> Model Class Initialized
INFO - 2019-07-02 19:51:49 --> Model Class Initialized
INFO - 2019-07-02 19:51:49 --> Model Class Initialized
INFO - 2019-07-02 19:51:49 --> Final output sent to browser
DEBUG - 2019-07-02 19:51:49 --> Total execution time: 0.2765
INFO - 2019-07-02 13:51:49 --> Config Class Initialized
INFO - 2019-07-02 13:51:49 --> Hooks Class Initialized
DEBUG - 2019-07-02 13:51:49 --> UTF-8 Support Enabled
INFO - 2019-07-02 13:51:49 --> Utf8 Class Initialized
INFO - 2019-07-02 13:51:49 --> URI Class Initialized
INFO - 2019-07-02 13:51:49 --> Router Class Initialized
INFO - 2019-07-02 13:51:49 --> Output Class Initialized
INFO - 2019-07-02 13:51:49 --> Security Class Initialized
DEBUG - 2019-07-02 13:51:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 13:51:49 --> Input Class Initialized
INFO - 2019-07-02 13:51:49 --> Language Class Initialized
INFO - 2019-07-02 13:51:49 --> Language Class Initialized
INFO - 2019-07-02 13:51:49 --> Config Class Initialized
INFO - 2019-07-02 13:51:49 --> Loader Class Initialized
DEBUG - 2019-07-02 13:51:49 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 13:51:49 --> Helper loaded: url_helper
INFO - 2019-07-02 13:51:49 --> Helper loaded: inflector_helper
INFO - 2019-07-02 13:51:49 --> Helper loaded: string_helper
INFO - 2019-07-02 13:51:49 --> Helper loaded: array_helper
INFO - 2019-07-02 13:51:49 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 13:51:49 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 13:51:49 --> Database Driver Class Initialized
INFO - 2019-07-02 13:51:49 --> Controller Class Initialized
INFO - 2019-07-02 19:51:49 --> Helper loaded: language_helper
INFO - 2019-07-02 19:51:49 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 19:51:49 --> Model Class Initialized
INFO - 2019-07-02 19:51:49 --> Model Class Initialized
INFO - 2019-07-02 19:51:49 --> Model Class Initialized
INFO - 2019-07-02 19:51:49 --> Model Class Initialized
INFO - 2019-07-02 19:51:49 --> Model Class Initialized
INFO - 2019-07-02 19:51:49 --> Final output sent to browser
DEBUG - 2019-07-02 19:51:49 --> Total execution time: 0.2852
INFO - 2019-07-02 14:26:18 --> Config Class Initialized
INFO - 2019-07-02 14:26:18 --> Hooks Class Initialized
DEBUG - 2019-07-02 14:26:18 --> UTF-8 Support Enabled
INFO - 2019-07-02 14:26:18 --> Utf8 Class Initialized
INFO - 2019-07-02 14:26:18 --> URI Class Initialized
INFO - 2019-07-02 14:26:18 --> Router Class Initialized
INFO - 2019-07-02 14:26:18 --> Output Class Initialized
INFO - 2019-07-02 14:26:18 --> Security Class Initialized
DEBUG - 2019-07-02 14:26:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 14:26:18 --> Input Class Initialized
INFO - 2019-07-02 14:26:18 --> Language Class Initialized
INFO - 2019-07-02 14:26:18 --> Language Class Initialized
INFO - 2019-07-02 14:26:18 --> Config Class Initialized
INFO - 2019-07-02 14:26:18 --> Loader Class Initialized
DEBUG - 2019-07-02 14:26:18 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 14:26:18 --> Helper loaded: url_helper
INFO - 2019-07-02 14:26:18 --> Helper loaded: inflector_helper
INFO - 2019-07-02 14:26:18 --> Helper loaded: string_helper
INFO - 2019-07-02 14:26:18 --> Helper loaded: array_helper
INFO - 2019-07-02 14:26:18 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 14:26:18 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 14:26:18 --> Database Driver Class Initialized
INFO - 2019-07-02 14:26:18 --> Controller Class Initialized
INFO - 2019-07-02 20:26:18 --> Helper loaded: language_helper
INFO - 2019-07-02 20:26:18 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 20:26:18 --> Model Class Initialized
INFO - 2019-07-02 20:26:18 --> Model Class Initialized
INFO - 2019-07-02 20:26:18 --> Model Class Initialized
INFO - 2019-07-02 20:26:18 --> Model Class Initialized
INFO - 2019-07-02 20:26:18 --> Final output sent to browser
DEBUG - 2019-07-02 20:26:18 --> Total execution time: 0.3241
INFO - 2019-07-02 14:26:18 --> Config Class Initialized
INFO - 2019-07-02 14:26:18 --> Hooks Class Initialized
INFO - 2019-07-02 14:26:18 --> Config Class Initialized
DEBUG - 2019-07-02 14:26:18 --> UTF-8 Support Enabled
INFO - 2019-07-02 14:26:18 --> Hooks Class Initialized
INFO - 2019-07-02 14:26:18 --> Utf8 Class Initialized
DEBUG - 2019-07-02 14:26:18 --> UTF-8 Support Enabled
INFO - 2019-07-02 14:26:18 --> URI Class Initialized
INFO - 2019-07-02 14:26:18 --> Utf8 Class Initialized
INFO - 2019-07-02 14:26:18 --> URI Class Initialized
INFO - 2019-07-02 14:26:18 --> Router Class Initialized
INFO - 2019-07-02 14:26:18 --> Router Class Initialized
INFO - 2019-07-02 14:26:18 --> Output Class Initialized
INFO - 2019-07-02 14:26:18 --> Output Class Initialized
INFO - 2019-07-02 14:26:18 --> Security Class Initialized
INFO - 2019-07-02 14:26:18 --> Security Class Initialized
DEBUG - 2019-07-02 14:26:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-02 14:26:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 14:26:18 --> Input Class Initialized
INFO - 2019-07-02 14:26:18 --> Input Class Initialized
INFO - 2019-07-02 14:26:18 --> Language Class Initialized
INFO - 2019-07-02 14:26:18 --> Language Class Initialized
INFO - 2019-07-02 14:26:18 --> Language Class Initialized
INFO - 2019-07-02 14:26:18 --> Language Class Initialized
INFO - 2019-07-02 14:26:18 --> Config Class Initialized
INFO - 2019-07-02 14:26:18 --> Config Class Initialized
INFO - 2019-07-02 14:26:18 --> Loader Class Initialized
INFO - 2019-07-02 14:26:18 --> Loader Class Initialized
DEBUG - 2019-07-02 14:26:18 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-02 14:26:18 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 14:26:18 --> Helper loaded: url_helper
INFO - 2019-07-02 14:26:18 --> Helper loaded: url_helper
INFO - 2019-07-02 14:26:18 --> Helper loaded: inflector_helper
INFO - 2019-07-02 14:26:18 --> Helper loaded: inflector_helper
INFO - 2019-07-02 14:26:18 --> Helper loaded: string_helper
INFO - 2019-07-02 14:26:18 --> Helper loaded: string_helper
INFO - 2019-07-02 14:26:18 --> Helper loaded: array_helper
INFO - 2019-07-02 14:26:18 --> Helper loaded: array_helper
INFO - 2019-07-02 14:26:18 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 14:26:18 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 14:26:18 --> Database Driver Class Initialized
INFO - 2019-07-02 14:26:18 --> Controller Class Initialized
INFO - 2019-07-02 20:26:18 --> Helper loaded: language_helper
INFO - 2019-07-02 20:26:18 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 20:26:19 --> Model Class Initialized
INFO - 2019-07-02 20:26:19 --> Model Class Initialized
INFO - 2019-07-02 20:26:19 --> Model Class Initialized
INFO - 2019-07-02 20:26:19 --> Model Class Initialized
INFO - 2019-07-02 20:26:19 --> Model Class Initialized
INFO - 2019-07-02 20:26:19 --> Final output sent to browser
DEBUG - 2019-07-02 20:26:19 --> Total execution time: 0.3606
INFO - 2019-07-02 14:26:19 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 14:26:19 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 14:26:19 --> Database Driver Class Initialized
INFO - 2019-07-02 14:26:19 --> Controller Class Initialized
INFO - 2019-07-02 20:26:19 --> Helper loaded: language_helper
INFO - 2019-07-02 20:26:19 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 20:26:19 --> Model Class Initialized
INFO - 2019-07-02 20:26:19 --> Model Class Initialized
INFO - 2019-07-02 20:26:19 --> Model Class Initialized
INFO - 2019-07-02 20:26:19 --> Model Class Initialized
INFO - 2019-07-02 20:26:19 --> Final output sent to browser
DEBUG - 2019-07-02 20:26:19 --> Total execution time: 0.4770
INFO - 2019-07-02 14:26:32 --> Config Class Initialized
INFO - 2019-07-02 14:26:32 --> Hooks Class Initialized
DEBUG - 2019-07-02 14:26:32 --> UTF-8 Support Enabled
INFO - 2019-07-02 14:26:32 --> Utf8 Class Initialized
INFO - 2019-07-02 14:26:32 --> URI Class Initialized
INFO - 2019-07-02 14:26:32 --> Router Class Initialized
INFO - 2019-07-02 14:26:32 --> Output Class Initialized
INFO - 2019-07-02 14:26:32 --> Security Class Initialized
DEBUG - 2019-07-02 14:26:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 14:26:32 --> Input Class Initialized
INFO - 2019-07-02 14:26:32 --> Language Class Initialized
INFO - 2019-07-02 14:26:32 --> Language Class Initialized
INFO - 2019-07-02 14:26:32 --> Config Class Initialized
INFO - 2019-07-02 14:26:32 --> Loader Class Initialized
DEBUG - 2019-07-02 14:26:32 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 14:26:32 --> Helper loaded: url_helper
INFO - 2019-07-02 14:26:32 --> Helper loaded: inflector_helper
INFO - 2019-07-02 14:26:32 --> Helper loaded: string_helper
INFO - 2019-07-02 14:26:32 --> Helper loaded: array_helper
INFO - 2019-07-02 14:26:32 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 14:26:32 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 14:26:32 --> Database Driver Class Initialized
INFO - 2019-07-02 14:26:32 --> Controller Class Initialized
INFO - 2019-07-02 20:26:32 --> Helper loaded: language_helper
INFO - 2019-07-02 20:26:32 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 20:26:32 --> Model Class Initialized
INFO - 2019-07-02 20:26:32 --> Model Class Initialized
INFO - 2019-07-02 20:26:32 --> Model Class Initialized
INFO - 2019-07-02 20:26:32 --> Model Class Initialized
INFO - 2019-07-02 20:26:32 --> Model Class Initialized
INFO - 2019-07-02 20:26:32 --> Final output sent to browser
DEBUG - 2019-07-02 20:26:32 --> Total execution time: 0.2905
INFO - 2019-07-02 14:26:32 --> Config Class Initialized
INFO - 2019-07-02 14:26:32 --> Hooks Class Initialized
DEBUG - 2019-07-02 14:26:32 --> UTF-8 Support Enabled
INFO - 2019-07-02 14:26:32 --> Utf8 Class Initialized
INFO - 2019-07-02 14:26:32 --> URI Class Initialized
INFO - 2019-07-02 14:26:32 --> Router Class Initialized
INFO - 2019-07-02 14:26:32 --> Output Class Initialized
INFO - 2019-07-02 14:26:32 --> Security Class Initialized
DEBUG - 2019-07-02 14:26:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 14:26:32 --> Input Class Initialized
INFO - 2019-07-02 14:26:32 --> Language Class Initialized
INFO - 2019-07-02 14:26:32 --> Language Class Initialized
INFO - 2019-07-02 14:26:32 --> Config Class Initialized
INFO - 2019-07-02 14:26:32 --> Loader Class Initialized
DEBUG - 2019-07-02 14:26:32 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 14:26:32 --> Helper loaded: url_helper
INFO - 2019-07-02 14:26:32 --> Helper loaded: inflector_helper
INFO - 2019-07-02 14:26:32 --> Helper loaded: string_helper
INFO - 2019-07-02 14:26:32 --> Helper loaded: array_helper
INFO - 2019-07-02 14:26:32 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 14:26:32 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 14:26:32 --> Database Driver Class Initialized
INFO - 2019-07-02 14:26:32 --> Controller Class Initialized
INFO - 2019-07-02 20:26:32 --> Helper loaded: language_helper
INFO - 2019-07-02 20:26:32 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 20:26:32 --> Model Class Initialized
INFO - 2019-07-02 20:26:32 --> Model Class Initialized
INFO - 2019-07-02 20:26:32 --> Model Class Initialized
INFO - 2019-07-02 20:26:32 --> Model Class Initialized
INFO - 2019-07-02 20:26:32 --> Model Class Initialized
INFO - 2019-07-02 20:26:32 --> Final output sent to browser
DEBUG - 2019-07-02 20:26:32 --> Total execution time: 0.2876
INFO - 2019-07-02 14:26:44 --> Config Class Initialized
INFO - 2019-07-02 14:26:44 --> Hooks Class Initialized
DEBUG - 2019-07-02 14:26:44 --> UTF-8 Support Enabled
INFO - 2019-07-02 14:26:44 --> Utf8 Class Initialized
INFO - 2019-07-02 14:26:44 --> URI Class Initialized
INFO - 2019-07-02 14:26:44 --> Router Class Initialized
INFO - 2019-07-02 14:26:44 --> Output Class Initialized
INFO - 2019-07-02 14:26:44 --> Security Class Initialized
DEBUG - 2019-07-02 14:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 14:26:44 --> Input Class Initialized
INFO - 2019-07-02 14:26:44 --> Language Class Initialized
INFO - 2019-07-02 14:26:44 --> Language Class Initialized
INFO - 2019-07-02 14:26:44 --> Config Class Initialized
INFO - 2019-07-02 14:26:44 --> Loader Class Initialized
DEBUG - 2019-07-02 14:26:44 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 14:26:44 --> Helper loaded: url_helper
INFO - 2019-07-02 14:26:44 --> Helper loaded: inflector_helper
INFO - 2019-07-02 14:26:45 --> Helper loaded: string_helper
INFO - 2019-07-02 14:26:45 --> Helper loaded: array_helper
INFO - 2019-07-02 14:26:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 14:26:45 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 14:26:45 --> Database Driver Class Initialized
INFO - 2019-07-02 14:26:45 --> Controller Class Initialized
INFO - 2019-07-02 20:26:45 --> Helper loaded: language_helper
INFO - 2019-07-02 20:26:45 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 20:26:45 --> Model Class Initialized
INFO - 2019-07-02 20:26:45 --> Model Class Initialized
INFO - 2019-07-02 20:26:45 --> Model Class Initialized
INFO - 2019-07-02 20:26:45 --> Model Class Initialized
INFO - 2019-07-02 20:26:45 --> Final output sent to browser
DEBUG - 2019-07-02 20:26:45 --> Total execution time: 0.3181
INFO - 2019-07-02 14:26:48 --> Config Class Initialized
INFO - 2019-07-02 14:26:48 --> Hooks Class Initialized
DEBUG - 2019-07-02 14:26:48 --> UTF-8 Support Enabled
INFO - 2019-07-02 14:26:48 --> Utf8 Class Initialized
INFO - 2019-07-02 14:26:48 --> URI Class Initialized
INFO - 2019-07-02 14:26:48 --> Router Class Initialized
INFO - 2019-07-02 14:26:48 --> Output Class Initialized
INFO - 2019-07-02 14:26:48 --> Security Class Initialized
DEBUG - 2019-07-02 14:26:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 14:26:48 --> Input Class Initialized
INFO - 2019-07-02 14:26:48 --> Language Class Initialized
INFO - 2019-07-02 14:26:48 --> Language Class Initialized
INFO - 2019-07-02 14:26:48 --> Config Class Initialized
INFO - 2019-07-02 14:26:48 --> Loader Class Initialized
DEBUG - 2019-07-02 14:26:48 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 14:26:48 --> Helper loaded: url_helper
INFO - 2019-07-02 14:26:48 --> Helper loaded: inflector_helper
INFO - 2019-07-02 14:26:49 --> Helper loaded: string_helper
INFO - 2019-07-02 14:26:49 --> Helper loaded: array_helper
INFO - 2019-07-02 14:26:49 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 14:26:49 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 14:26:49 --> Database Driver Class Initialized
INFO - 2019-07-02 14:26:49 --> Controller Class Initialized
INFO - 2019-07-02 20:26:49 --> Helper loaded: language_helper
INFO - 2019-07-02 20:26:49 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 20:26:49 --> Model Class Initialized
INFO - 2019-07-02 20:26:49 --> Model Class Initialized
INFO - 2019-07-02 20:26:49 --> Model Class Initialized
INFO - 2019-07-02 20:26:49 --> Model Class Initialized
INFO - 2019-07-02 20:26:49 --> Final output sent to browser
DEBUG - 2019-07-02 20:26:49 --> Total execution time: 0.3412
INFO - 2019-07-02 14:26:49 --> Config Class Initialized
INFO - 2019-07-02 14:26:49 --> Hooks Class Initialized
DEBUG - 2019-07-02 14:26:49 --> UTF-8 Support Enabled
INFO - 2019-07-02 14:26:49 --> Utf8 Class Initialized
INFO - 2019-07-02 14:26:49 --> URI Class Initialized
INFO - 2019-07-02 14:26:49 --> Router Class Initialized
INFO - 2019-07-02 14:26:49 --> Output Class Initialized
INFO - 2019-07-02 14:26:49 --> Security Class Initialized
DEBUG - 2019-07-02 14:26:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 14:26:49 --> Input Class Initialized
INFO - 2019-07-02 14:26:49 --> Language Class Initialized
INFO - 2019-07-02 14:26:49 --> Language Class Initialized
INFO - 2019-07-02 14:26:49 --> Config Class Initialized
INFO - 2019-07-02 14:26:49 --> Loader Class Initialized
DEBUG - 2019-07-02 14:26:49 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 14:26:49 --> Helper loaded: url_helper
INFO - 2019-07-02 14:26:49 --> Helper loaded: inflector_helper
INFO - 2019-07-02 14:26:49 --> Helper loaded: string_helper
INFO - 2019-07-02 14:26:49 --> Helper loaded: array_helper
INFO - 2019-07-02 14:26:49 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 14:26:49 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 14:26:49 --> Database Driver Class Initialized
INFO - 2019-07-02 14:26:49 --> Controller Class Initialized
INFO - 2019-07-02 20:26:49 --> Helper loaded: language_helper
INFO - 2019-07-02 20:26:49 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 20:26:49 --> Model Class Initialized
INFO - 2019-07-02 20:26:49 --> Model Class Initialized
INFO - 2019-07-02 20:26:49 --> Model Class Initialized
INFO - 2019-07-02 20:26:49 --> Model Class Initialized
INFO - 2019-07-02 20:26:49 --> Model Class Initialized
INFO - 2019-07-02 20:26:49 --> Final output sent to browser
DEBUG - 2019-07-02 20:26:49 --> Total execution time: 0.3235
INFO - 2019-07-02 14:27:38 --> Config Class Initialized
INFO - 2019-07-02 14:27:38 --> Hooks Class Initialized
DEBUG - 2019-07-02 14:27:38 --> UTF-8 Support Enabled
INFO - 2019-07-02 14:27:38 --> Utf8 Class Initialized
INFO - 2019-07-02 14:27:38 --> URI Class Initialized
INFO - 2019-07-02 14:27:38 --> Router Class Initialized
INFO - 2019-07-02 14:27:38 --> Output Class Initialized
INFO - 2019-07-02 14:27:38 --> Security Class Initialized
DEBUG - 2019-07-02 14:27:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 14:27:38 --> Input Class Initialized
INFO - 2019-07-02 14:27:38 --> Language Class Initialized
INFO - 2019-07-02 14:27:38 --> Language Class Initialized
INFO - 2019-07-02 14:27:38 --> Config Class Initialized
INFO - 2019-07-02 14:27:38 --> Loader Class Initialized
DEBUG - 2019-07-02 14:27:38 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 14:27:38 --> Helper loaded: url_helper
INFO - 2019-07-02 14:27:38 --> Helper loaded: inflector_helper
INFO - 2019-07-02 14:27:38 --> Helper loaded: string_helper
INFO - 2019-07-02 14:27:38 --> Helper loaded: array_helper
INFO - 2019-07-02 14:27:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 14:27:38 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 14:27:38 --> Database Driver Class Initialized
INFO - 2019-07-02 14:27:38 --> Controller Class Initialized
INFO - 2019-07-02 20:27:38 --> Helper loaded: language_helper
INFO - 2019-07-02 20:27:38 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 20:27:38 --> Model Class Initialized
INFO - 2019-07-02 20:27:38 --> Model Class Initialized
INFO - 2019-07-02 20:27:38 --> Model Class Initialized
INFO - 2019-07-02 20:27:38 --> Model Class Initialized
INFO - 2019-07-02 20:27:38 --> Helper loaded: form_helper
INFO - 2019-07-02 20:27:38 --> Form Validation Class Initialized
DEBUG - 2019-07-02 20:27:38 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-02 20:27:38 --> Model Class Initialized
INFO - 2019-07-02 20:27:38 --> Model Class Initialized
INFO - 2019-07-02 20:27:38 --> Final output sent to browser
DEBUG - 2019-07-02 20:27:38 --> Total execution time: 0.5420
INFO - 2019-07-02 14:27:42 --> Config Class Initialized
INFO - 2019-07-02 14:27:42 --> Hooks Class Initialized
DEBUG - 2019-07-02 14:27:42 --> UTF-8 Support Enabled
INFO - 2019-07-02 14:27:42 --> Utf8 Class Initialized
INFO - 2019-07-02 14:27:42 --> URI Class Initialized
INFO - 2019-07-02 14:27:42 --> Router Class Initialized
INFO - 2019-07-02 14:27:42 --> Output Class Initialized
INFO - 2019-07-02 14:27:42 --> Security Class Initialized
DEBUG - 2019-07-02 14:27:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 14:27:42 --> Input Class Initialized
INFO - 2019-07-02 14:27:42 --> Language Class Initialized
INFO - 2019-07-02 14:27:42 --> Language Class Initialized
INFO - 2019-07-02 14:27:42 --> Config Class Initialized
INFO - 2019-07-02 14:27:42 --> Loader Class Initialized
DEBUG - 2019-07-02 14:27:42 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 14:27:42 --> Helper loaded: url_helper
INFO - 2019-07-02 14:27:42 --> Helper loaded: inflector_helper
INFO - 2019-07-02 14:27:42 --> Helper loaded: string_helper
INFO - 2019-07-02 14:27:42 --> Helper loaded: array_helper
INFO - 2019-07-02 14:27:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 14:27:42 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 14:27:42 --> Database Driver Class Initialized
INFO - 2019-07-02 14:27:42 --> Controller Class Initialized
INFO - 2019-07-02 20:27:42 --> Helper loaded: language_helper
INFO - 2019-07-02 20:27:42 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 20:27:42 --> Model Class Initialized
INFO - 2019-07-02 20:27:42 --> Model Class Initialized
INFO - 2019-07-02 20:27:42 --> Model Class Initialized
INFO - 2019-07-02 20:27:42 --> Model Class Initialized
INFO - 2019-07-02 20:27:42 --> Model Class Initialized
INFO - 2019-07-02 20:27:42 --> Final output sent to browser
DEBUG - 2019-07-02 20:27:42 --> Total execution time: 0.2932
INFO - 2019-07-02 14:27:45 --> Config Class Initialized
INFO - 2019-07-02 14:27:45 --> Hooks Class Initialized
DEBUG - 2019-07-02 14:27:45 --> UTF-8 Support Enabled
INFO - 2019-07-02 14:27:45 --> Utf8 Class Initialized
INFO - 2019-07-02 14:27:45 --> URI Class Initialized
INFO - 2019-07-02 14:27:45 --> Router Class Initialized
INFO - 2019-07-02 14:27:45 --> Output Class Initialized
INFO - 2019-07-02 14:27:45 --> Security Class Initialized
DEBUG - 2019-07-02 14:27:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 14:27:45 --> Input Class Initialized
INFO - 2019-07-02 14:27:45 --> Language Class Initialized
INFO - 2019-07-02 14:27:45 --> Language Class Initialized
INFO - 2019-07-02 14:27:45 --> Config Class Initialized
INFO - 2019-07-02 14:27:45 --> Loader Class Initialized
DEBUG - 2019-07-02 14:27:45 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 14:27:45 --> Helper loaded: url_helper
INFO - 2019-07-02 14:27:45 --> Helper loaded: inflector_helper
INFO - 2019-07-02 14:27:45 --> Helper loaded: string_helper
INFO - 2019-07-02 14:27:45 --> Helper loaded: array_helper
INFO - 2019-07-02 14:27:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 14:27:45 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 14:27:46 --> Database Driver Class Initialized
INFO - 2019-07-02 14:27:46 --> Controller Class Initialized
INFO - 2019-07-02 20:27:46 --> Helper loaded: language_helper
INFO - 2019-07-02 20:27:46 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 20:27:46 --> Model Class Initialized
INFO - 2019-07-02 20:27:46 --> Model Class Initialized
INFO - 2019-07-02 20:27:46 --> Model Class Initialized
INFO - 2019-07-02 20:27:46 --> Model Class Initialized
INFO - 2019-07-02 20:27:46 --> Helper loaded: form_helper
INFO - 2019-07-02 20:27:46 --> Form Validation Class Initialized
DEBUG - 2019-07-02 20:27:46 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-02 20:27:46 --> Model Class Initialized
INFO - 2019-07-02 20:27:46 --> Model Class Initialized
ERROR - 2019-07-02 20:27:46 --> Query error: Column 'resto_id' in where clause is ambiguous - Invalid query: SELECT `orders`.*, `order_details`.`qty`, `order_details`.`price`, `order_details`.`sub_total`, `order_details`.`status`, `order_details`.`product_id`, `order_details`.`created_at` AS `order_date`, `products`.`name`, CONCAT(`customers`.`firstname`, " ", `customers`.`lastname`) AS customer_fullname, `customers`.`address`, `customers`.`contact_number`, `customers`.`email`
FROM `orders`
LEFT JOIN `order_details` ON `order_details`.`order_id` = `orders`.`id`
LEFT JOIN `products` ON `products`.`id` = `order_details`.`product_id`
INNER JOIN `customers` as `customers` ON `customers`.`id` = `orders`.`customer_id`
WHERE `resto_id` = '2'
AND `customer_id` = '1'
AND `order_status` = 'pending'
INFO - 2019-07-02 20:27:46 --> Language file loaded: language/english/db_lang.php
INFO - 2019-07-02 14:27:46 --> Config Class Initialized
INFO - 2019-07-02 14:27:46 --> Hooks Class Initialized
DEBUG - 2019-07-02 14:27:46 --> UTF-8 Support Enabled
INFO - 2019-07-02 14:27:46 --> Utf8 Class Initialized
INFO - 2019-07-02 14:27:46 --> URI Class Initialized
INFO - 2019-07-02 14:27:46 --> Router Class Initialized
INFO - 2019-07-02 14:27:46 --> Output Class Initialized
INFO - 2019-07-02 14:27:46 --> Security Class Initialized
DEBUG - 2019-07-02 14:27:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 14:27:46 --> Input Class Initialized
INFO - 2019-07-02 14:27:46 --> Language Class Initialized
INFO - 2019-07-02 14:27:46 --> Language Class Initialized
INFO - 2019-07-02 14:27:46 --> Config Class Initialized
INFO - 2019-07-02 14:27:46 --> Loader Class Initialized
DEBUG - 2019-07-02 14:27:46 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 14:27:46 --> Helper loaded: url_helper
INFO - 2019-07-02 14:27:46 --> Helper loaded: inflector_helper
INFO - 2019-07-02 14:27:46 --> Helper loaded: string_helper
INFO - 2019-07-02 14:27:46 --> Helper loaded: array_helper
INFO - 2019-07-02 14:27:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 14:27:46 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 14:27:46 --> Database Driver Class Initialized
INFO - 2019-07-02 14:27:46 --> Controller Class Initialized
INFO - 2019-07-02 20:27:46 --> Helper loaded: language_helper
INFO - 2019-07-02 20:27:46 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 20:27:46 --> Model Class Initialized
INFO - 2019-07-02 20:27:46 --> Model Class Initialized
INFO - 2019-07-02 20:27:46 --> Model Class Initialized
INFO - 2019-07-02 20:27:46 --> Model Class Initialized
INFO - 2019-07-02 20:27:46 --> Helper loaded: form_helper
INFO - 2019-07-02 20:27:46 --> Form Validation Class Initialized
DEBUG - 2019-07-02 20:27:46 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-02 20:27:46 --> Model Class Initialized
INFO - 2019-07-02 20:27:46 --> Model Class Initialized
INFO - 2019-07-02 20:27:46 --> Final output sent to browser
DEBUG - 2019-07-02 20:27:46 --> Total execution time: 0.3466
INFO - 2019-07-02 14:27:51 --> Config Class Initialized
INFO - 2019-07-02 14:27:51 --> Hooks Class Initialized
DEBUG - 2019-07-02 14:27:51 --> UTF-8 Support Enabled
INFO - 2019-07-02 14:27:51 --> Utf8 Class Initialized
INFO - 2019-07-02 14:27:51 --> URI Class Initialized
INFO - 2019-07-02 14:27:51 --> Router Class Initialized
INFO - 2019-07-02 14:27:51 --> Output Class Initialized
INFO - 2019-07-02 14:27:51 --> Security Class Initialized
DEBUG - 2019-07-02 14:27:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 14:27:51 --> Input Class Initialized
INFO - 2019-07-02 14:27:51 --> Language Class Initialized
INFO - 2019-07-02 14:27:51 --> Language Class Initialized
INFO - 2019-07-02 14:27:51 --> Config Class Initialized
INFO - 2019-07-02 14:27:51 --> Loader Class Initialized
DEBUG - 2019-07-02 14:27:51 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 14:27:51 --> Helper loaded: url_helper
INFO - 2019-07-02 14:27:51 --> Helper loaded: inflector_helper
INFO - 2019-07-02 14:27:51 --> Helper loaded: string_helper
INFO - 2019-07-02 14:27:51 --> Helper loaded: array_helper
INFO - 2019-07-02 14:27:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 14:27:51 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 14:27:51 --> Database Driver Class Initialized
INFO - 2019-07-02 14:27:51 --> Controller Class Initialized
INFO - 2019-07-02 20:27:51 --> Helper loaded: language_helper
INFO - 2019-07-02 20:27:51 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 20:27:51 --> Model Class Initialized
INFO - 2019-07-02 20:27:51 --> Model Class Initialized
INFO - 2019-07-02 20:27:51 --> Model Class Initialized
INFO - 2019-07-02 20:27:51 --> Model Class Initialized
INFO - 2019-07-02 20:27:51 --> Helper loaded: form_helper
INFO - 2019-07-02 20:27:51 --> Form Validation Class Initialized
DEBUG - 2019-07-02 20:27:51 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-02 20:27:51 --> Model Class Initialized
INFO - 2019-07-02 20:27:51 --> Model Class Initialized
INFO - 2019-07-02 20:27:51 --> Final output sent to browser
DEBUG - 2019-07-02 20:27:51 --> Total execution time: 0.4227
INFO - 2019-07-02 14:28:05 --> Config Class Initialized
INFO - 2019-07-02 14:28:05 --> Hooks Class Initialized
DEBUG - 2019-07-02 14:28:05 --> UTF-8 Support Enabled
INFO - 2019-07-02 14:28:05 --> Utf8 Class Initialized
INFO - 2019-07-02 14:28:05 --> URI Class Initialized
INFO - 2019-07-02 14:28:05 --> Router Class Initialized
INFO - 2019-07-02 14:28:05 --> Output Class Initialized
INFO - 2019-07-02 14:28:05 --> Security Class Initialized
DEBUG - 2019-07-02 14:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 14:28:05 --> Input Class Initialized
INFO - 2019-07-02 14:28:05 --> Language Class Initialized
INFO - 2019-07-02 14:28:05 --> Language Class Initialized
INFO - 2019-07-02 14:28:05 --> Config Class Initialized
INFO - 2019-07-02 14:28:05 --> Loader Class Initialized
DEBUG - 2019-07-02 14:28:05 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 14:28:05 --> Helper loaded: url_helper
INFO - 2019-07-02 14:28:05 --> Helper loaded: inflector_helper
INFO - 2019-07-02 14:28:05 --> Helper loaded: string_helper
INFO - 2019-07-02 14:28:05 --> Helper loaded: array_helper
INFO - 2019-07-02 14:28:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 14:28:05 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 14:28:05 --> Database Driver Class Initialized
INFO - 2019-07-02 14:28:05 --> Controller Class Initialized
INFO - 2019-07-02 20:28:05 --> Helper loaded: language_helper
INFO - 2019-07-02 20:28:05 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 20:28:05 --> Model Class Initialized
INFO - 2019-07-02 20:28:05 --> Model Class Initialized
INFO - 2019-07-02 20:28:05 --> Model Class Initialized
INFO - 2019-07-02 20:28:05 --> Model Class Initialized
INFO - 2019-07-02 20:28:05 --> Model Class Initialized
INFO - 2019-07-02 20:28:05 --> Final output sent to browser
DEBUG - 2019-07-02 20:28:05 --> Total execution time: 0.3075
INFO - 2019-07-02 14:41:37 --> Config Class Initialized
INFO - 2019-07-02 14:41:37 --> Hooks Class Initialized
DEBUG - 2019-07-02 14:41:37 --> UTF-8 Support Enabled
INFO - 2019-07-02 14:41:37 --> Utf8 Class Initialized
INFO - 2019-07-02 14:41:37 --> URI Class Initialized
INFO - 2019-07-02 14:41:37 --> Router Class Initialized
INFO - 2019-07-02 14:41:37 --> Output Class Initialized
INFO - 2019-07-02 14:41:37 --> Security Class Initialized
DEBUG - 2019-07-02 14:41:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 14:41:37 --> Input Class Initialized
INFO - 2019-07-02 14:41:37 --> Language Class Initialized
INFO - 2019-07-02 14:41:37 --> Language Class Initialized
INFO - 2019-07-02 14:41:37 --> Config Class Initialized
INFO - 2019-07-02 14:41:37 --> Loader Class Initialized
DEBUG - 2019-07-02 14:41:37 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 14:41:37 --> Helper loaded: url_helper
INFO - 2019-07-02 14:41:37 --> Helper loaded: inflector_helper
INFO - 2019-07-02 14:41:37 --> Helper loaded: string_helper
INFO - 2019-07-02 14:41:37 --> Helper loaded: array_helper
INFO - 2019-07-02 14:41:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 14:41:37 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 14:41:37 --> Database Driver Class Initialized
INFO - 2019-07-02 14:41:37 --> Controller Class Initialized
INFO - 2019-07-02 20:41:37 --> Helper loaded: language_helper
INFO - 2019-07-02 20:41:37 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 20:41:37 --> Model Class Initialized
INFO - 2019-07-02 20:41:37 --> Model Class Initialized
INFO - 2019-07-02 20:41:37 --> Model Class Initialized
INFO - 2019-07-02 20:41:37 --> Model Class Initialized
INFO - 2019-07-02 20:41:37 --> Final output sent to browser
DEBUG - 2019-07-02 20:41:37 --> Total execution time: 0.3524
INFO - 2019-07-02 14:41:46 --> Config Class Initialized
INFO - 2019-07-02 14:41:46 --> Hooks Class Initialized
DEBUG - 2019-07-02 14:41:46 --> UTF-8 Support Enabled
INFO - 2019-07-02 14:41:46 --> Utf8 Class Initialized
INFO - 2019-07-02 14:41:46 --> URI Class Initialized
INFO - 2019-07-02 14:41:46 --> Router Class Initialized
INFO - 2019-07-02 14:41:46 --> Output Class Initialized
INFO - 2019-07-02 14:41:46 --> Security Class Initialized
DEBUG - 2019-07-02 14:41:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 14:41:46 --> Input Class Initialized
INFO - 2019-07-02 14:41:46 --> Language Class Initialized
INFO - 2019-07-02 14:41:46 --> Language Class Initialized
INFO - 2019-07-02 14:41:46 --> Config Class Initialized
INFO - 2019-07-02 14:41:46 --> Loader Class Initialized
DEBUG - 2019-07-02 14:41:46 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 14:41:46 --> Helper loaded: url_helper
INFO - 2019-07-02 14:41:46 --> Helper loaded: inflector_helper
INFO - 2019-07-02 14:41:46 --> Helper loaded: string_helper
INFO - 2019-07-02 14:41:46 --> Helper loaded: array_helper
INFO - 2019-07-02 14:41:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 14:41:46 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 14:41:46 --> Database Driver Class Initialized
INFO - 2019-07-02 14:41:46 --> Controller Class Initialized
INFO - 2019-07-02 20:41:46 --> Helper loaded: language_helper
INFO - 2019-07-02 20:41:46 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 20:41:46 --> Model Class Initialized
INFO - 2019-07-02 20:41:46 --> Model Class Initialized
INFO - 2019-07-02 20:41:46 --> Model Class Initialized
INFO - 2019-07-02 20:41:46 --> Model Class Initialized
INFO - 2019-07-02 20:41:46 --> Final output sent to browser
DEBUG - 2019-07-02 20:41:46 --> Total execution time: 0.3320
INFO - 2019-07-02 14:41:48 --> Config Class Initialized
INFO - 2019-07-02 14:41:48 --> Hooks Class Initialized
DEBUG - 2019-07-02 14:41:48 --> UTF-8 Support Enabled
INFO - 2019-07-02 14:41:48 --> Utf8 Class Initialized
INFO - 2019-07-02 14:41:48 --> URI Class Initialized
INFO - 2019-07-02 14:41:48 --> Router Class Initialized
INFO - 2019-07-02 14:41:48 --> Output Class Initialized
INFO - 2019-07-02 14:41:48 --> Security Class Initialized
DEBUG - 2019-07-02 14:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 14:41:48 --> Input Class Initialized
INFO - 2019-07-02 14:41:48 --> Language Class Initialized
INFO - 2019-07-02 14:41:48 --> Language Class Initialized
INFO - 2019-07-02 14:41:48 --> Config Class Initialized
INFO - 2019-07-02 14:41:48 --> Loader Class Initialized
DEBUG - 2019-07-02 14:41:48 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 14:41:48 --> Helper loaded: url_helper
INFO - 2019-07-02 14:41:48 --> Helper loaded: inflector_helper
INFO - 2019-07-02 14:41:48 --> Helper loaded: string_helper
INFO - 2019-07-02 14:41:48 --> Helper loaded: array_helper
INFO - 2019-07-02 14:41:48 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 14:41:48 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 14:41:48 --> Database Driver Class Initialized
INFO - 2019-07-02 14:41:48 --> Controller Class Initialized
INFO - 2019-07-02 20:41:48 --> Helper loaded: language_helper
INFO - 2019-07-02 20:41:48 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 20:41:48 --> Model Class Initialized
INFO - 2019-07-02 20:41:48 --> Model Class Initialized
INFO - 2019-07-02 20:41:48 --> Model Class Initialized
INFO - 2019-07-02 20:41:48 --> Model Class Initialized
INFO - 2019-07-02 20:41:48 --> Final output sent to browser
DEBUG - 2019-07-02 20:41:48 --> Total execution time: 0.3436
INFO - 2019-07-02 14:49:54 --> Config Class Initialized
INFO - 2019-07-02 14:49:54 --> Hooks Class Initialized
DEBUG - 2019-07-02 14:49:54 --> UTF-8 Support Enabled
INFO - 2019-07-02 14:49:55 --> Utf8 Class Initialized
INFO - 2019-07-02 14:49:55 --> URI Class Initialized
INFO - 2019-07-02 14:49:55 --> Router Class Initialized
INFO - 2019-07-02 14:49:55 --> Output Class Initialized
INFO - 2019-07-02 14:49:55 --> Security Class Initialized
DEBUG - 2019-07-02 14:49:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 14:49:55 --> Input Class Initialized
INFO - 2019-07-02 14:49:55 --> Language Class Initialized
INFO - 2019-07-02 14:49:55 --> Language Class Initialized
INFO - 2019-07-02 14:49:55 --> Config Class Initialized
INFO - 2019-07-02 14:49:55 --> Loader Class Initialized
DEBUG - 2019-07-02 14:49:55 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 14:49:55 --> Helper loaded: url_helper
INFO - 2019-07-02 14:49:55 --> Helper loaded: inflector_helper
INFO - 2019-07-02 14:49:55 --> Helper loaded: string_helper
INFO - 2019-07-02 14:49:55 --> Helper loaded: array_helper
INFO - 2019-07-02 14:49:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 14:49:55 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 14:49:55 --> Database Driver Class Initialized
INFO - 2019-07-02 14:49:55 --> Controller Class Initialized
INFO - 2019-07-02 20:49:55 --> Helper loaded: language_helper
INFO - 2019-07-02 20:49:55 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 20:49:55 --> Model Class Initialized
INFO - 2019-07-02 20:49:55 --> Model Class Initialized
INFO - 2019-07-02 20:49:55 --> Model Class Initialized
INFO - 2019-07-02 20:49:55 --> Model Class Initialized
INFO - 2019-07-02 20:49:55 --> Final output sent to browser
DEBUG - 2019-07-02 20:49:55 --> Total execution time: 0.3546
INFO - 2019-07-02 14:50:14 --> Config Class Initialized
INFO - 2019-07-02 14:50:14 --> Hooks Class Initialized
DEBUG - 2019-07-02 14:50:14 --> UTF-8 Support Enabled
INFO - 2019-07-02 14:50:14 --> Utf8 Class Initialized
INFO - 2019-07-02 14:50:14 --> URI Class Initialized
INFO - 2019-07-02 14:50:14 --> Router Class Initialized
INFO - 2019-07-02 14:50:14 --> Output Class Initialized
INFO - 2019-07-02 14:50:14 --> Security Class Initialized
DEBUG - 2019-07-02 14:50:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 14:50:14 --> Input Class Initialized
INFO - 2019-07-02 14:50:14 --> Language Class Initialized
INFO - 2019-07-02 14:50:14 --> Language Class Initialized
INFO - 2019-07-02 14:50:14 --> Config Class Initialized
INFO - 2019-07-02 14:50:14 --> Loader Class Initialized
DEBUG - 2019-07-02 14:50:14 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 14:50:14 --> Helper loaded: url_helper
INFO - 2019-07-02 14:50:14 --> Helper loaded: inflector_helper
INFO - 2019-07-02 14:50:14 --> Helper loaded: string_helper
INFO - 2019-07-02 14:50:14 --> Helper loaded: array_helper
INFO - 2019-07-02 14:50:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 14:50:14 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 14:50:14 --> Database Driver Class Initialized
INFO - 2019-07-02 14:50:14 --> Controller Class Initialized
INFO - 2019-07-02 20:50:14 --> Helper loaded: language_helper
INFO - 2019-07-02 20:50:14 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 20:50:14 --> Model Class Initialized
INFO - 2019-07-02 20:50:14 --> Model Class Initialized
INFO - 2019-07-02 20:50:14 --> Model Class Initialized
INFO - 2019-07-02 20:50:14 --> Model Class Initialized
INFO - 2019-07-02 20:50:14 --> Final output sent to browser
DEBUG - 2019-07-02 20:50:14 --> Total execution time: 0.3495
INFO - 2019-07-02 14:50:23 --> Config Class Initialized
INFO - 2019-07-02 14:50:23 --> Hooks Class Initialized
DEBUG - 2019-07-02 14:50:23 --> UTF-8 Support Enabled
INFO - 2019-07-02 14:50:23 --> Utf8 Class Initialized
INFO - 2019-07-02 14:50:23 --> URI Class Initialized
INFO - 2019-07-02 14:50:23 --> Router Class Initialized
INFO - 2019-07-02 14:50:23 --> Output Class Initialized
INFO - 2019-07-02 14:50:23 --> Security Class Initialized
DEBUG - 2019-07-02 14:50:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 14:50:23 --> Input Class Initialized
INFO - 2019-07-02 14:50:23 --> Language Class Initialized
INFO - 2019-07-02 14:50:23 --> Language Class Initialized
INFO - 2019-07-02 14:50:23 --> Config Class Initialized
INFO - 2019-07-02 14:50:23 --> Loader Class Initialized
DEBUG - 2019-07-02 14:50:23 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 14:50:23 --> Helper loaded: url_helper
INFO - 2019-07-02 14:50:23 --> Helper loaded: inflector_helper
INFO - 2019-07-02 14:50:23 --> Helper loaded: string_helper
INFO - 2019-07-02 14:50:23 --> Helper loaded: array_helper
INFO - 2019-07-02 14:50:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 14:50:23 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 14:50:23 --> Database Driver Class Initialized
INFO - 2019-07-02 14:50:23 --> Controller Class Initialized
INFO - 2019-07-02 20:50:23 --> Helper loaded: language_helper
INFO - 2019-07-02 20:50:23 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 20:50:23 --> Model Class Initialized
INFO - 2019-07-02 20:50:23 --> Model Class Initialized
INFO - 2019-07-02 20:50:23 --> Model Class Initialized
INFO - 2019-07-02 20:50:23 --> Model Class Initialized
INFO - 2019-07-02 20:50:23 --> Final output sent to browser
DEBUG - 2019-07-02 20:50:23 --> Total execution time: 0.3583
INFO - 2019-07-02 14:51:27 --> Config Class Initialized
INFO - 2019-07-02 14:51:27 --> Hooks Class Initialized
DEBUG - 2019-07-02 14:51:27 --> UTF-8 Support Enabled
INFO - 2019-07-02 14:51:27 --> Utf8 Class Initialized
INFO - 2019-07-02 14:51:27 --> URI Class Initialized
INFO - 2019-07-02 14:51:27 --> Router Class Initialized
INFO - 2019-07-02 14:51:27 --> Output Class Initialized
INFO - 2019-07-02 14:51:27 --> Security Class Initialized
DEBUG - 2019-07-02 14:51:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 14:51:27 --> Input Class Initialized
INFO - 2019-07-02 14:51:27 --> Language Class Initialized
INFO - 2019-07-02 14:51:27 --> Language Class Initialized
INFO - 2019-07-02 14:51:27 --> Config Class Initialized
INFO - 2019-07-02 14:51:27 --> Loader Class Initialized
DEBUG - 2019-07-02 14:51:27 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 14:51:27 --> Helper loaded: url_helper
INFO - 2019-07-02 14:51:27 --> Helper loaded: inflector_helper
INFO - 2019-07-02 14:51:27 --> Helper loaded: string_helper
INFO - 2019-07-02 14:51:27 --> Helper loaded: array_helper
INFO - 2019-07-02 14:51:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 14:51:27 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 14:51:27 --> Database Driver Class Initialized
INFO - 2019-07-02 14:51:27 --> Controller Class Initialized
INFO - 2019-07-02 20:51:27 --> Helper loaded: language_helper
INFO - 2019-07-02 20:51:27 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 20:51:27 --> Model Class Initialized
INFO - 2019-07-02 20:51:27 --> Model Class Initialized
INFO - 2019-07-02 20:51:27 --> Model Class Initialized
INFO - 2019-07-02 20:51:27 --> Model Class Initialized
INFO - 2019-07-02 20:51:27 --> Final output sent to browser
DEBUG - 2019-07-02 20:51:27 --> Total execution time: 0.3571
INFO - 2019-07-02 14:52:09 --> Config Class Initialized
INFO - 2019-07-02 14:52:09 --> Hooks Class Initialized
DEBUG - 2019-07-02 14:52:09 --> UTF-8 Support Enabled
INFO - 2019-07-02 14:52:09 --> Utf8 Class Initialized
INFO - 2019-07-02 14:52:09 --> URI Class Initialized
INFO - 2019-07-02 14:52:10 --> Router Class Initialized
INFO - 2019-07-02 14:52:10 --> Output Class Initialized
INFO - 2019-07-02 14:52:10 --> Security Class Initialized
DEBUG - 2019-07-02 14:52:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 14:52:10 --> Input Class Initialized
INFO - 2019-07-02 14:52:10 --> Language Class Initialized
INFO - 2019-07-02 14:52:10 --> Language Class Initialized
INFO - 2019-07-02 14:52:10 --> Config Class Initialized
INFO - 2019-07-02 14:52:10 --> Loader Class Initialized
DEBUG - 2019-07-02 14:52:10 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 14:52:10 --> Helper loaded: url_helper
INFO - 2019-07-02 14:52:10 --> Helper loaded: inflector_helper
INFO - 2019-07-02 14:52:10 --> Helper loaded: string_helper
INFO - 2019-07-02 14:52:10 --> Helper loaded: array_helper
INFO - 2019-07-02 14:52:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 14:52:10 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 14:52:10 --> Database Driver Class Initialized
INFO - 2019-07-02 14:52:10 --> Controller Class Initialized
INFO - 2019-07-02 20:52:10 --> Helper loaded: language_helper
INFO - 2019-07-02 20:52:10 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 20:52:10 --> Model Class Initialized
INFO - 2019-07-02 20:52:10 --> Model Class Initialized
INFO - 2019-07-02 20:52:10 --> Model Class Initialized
INFO - 2019-07-02 20:52:10 --> Model Class Initialized
INFO - 2019-07-02 20:52:10 --> Final output sent to browser
DEBUG - 2019-07-02 20:52:10 --> Total execution time: 0.3602
INFO - 2019-07-02 14:54:07 --> Config Class Initialized
INFO - 2019-07-02 14:54:07 --> Hooks Class Initialized
DEBUG - 2019-07-02 14:54:07 --> UTF-8 Support Enabled
INFO - 2019-07-02 14:54:07 --> Utf8 Class Initialized
INFO - 2019-07-02 14:54:07 --> URI Class Initialized
INFO - 2019-07-02 14:54:07 --> Router Class Initialized
INFO - 2019-07-02 14:54:07 --> Output Class Initialized
INFO - 2019-07-02 14:54:07 --> Security Class Initialized
DEBUG - 2019-07-02 14:54:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 14:54:07 --> Input Class Initialized
INFO - 2019-07-02 14:54:07 --> Language Class Initialized
INFO - 2019-07-02 14:54:07 --> Language Class Initialized
INFO - 2019-07-02 14:54:07 --> Config Class Initialized
INFO - 2019-07-02 14:54:07 --> Loader Class Initialized
DEBUG - 2019-07-02 14:54:07 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 14:54:07 --> Helper loaded: url_helper
INFO - 2019-07-02 14:54:07 --> Helper loaded: inflector_helper
INFO - 2019-07-02 14:54:07 --> Helper loaded: string_helper
INFO - 2019-07-02 14:54:07 --> Helper loaded: array_helper
INFO - 2019-07-02 14:54:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 14:54:07 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 14:54:07 --> Database Driver Class Initialized
INFO - 2019-07-02 14:54:07 --> Controller Class Initialized
INFO - 2019-07-02 20:54:07 --> Helper loaded: language_helper
INFO - 2019-07-02 20:54:07 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 20:54:07 --> Model Class Initialized
INFO - 2019-07-02 20:54:07 --> Model Class Initialized
INFO - 2019-07-02 20:54:07 --> Model Class Initialized
INFO - 2019-07-02 20:54:07 --> Model Class Initialized
INFO - 2019-07-02 20:54:08 --> Final output sent to browser
DEBUG - 2019-07-02 20:54:08 --> Total execution time: 0.3397
INFO - 2019-07-02 14:54:08 --> Config Class Initialized
INFO - 2019-07-02 14:54:08 --> Config Class Initialized
INFO - 2019-07-02 14:54:08 --> Hooks Class Initialized
INFO - 2019-07-02 14:54:08 --> Hooks Class Initialized
DEBUG - 2019-07-02 14:54:08 --> UTF-8 Support Enabled
DEBUG - 2019-07-02 14:54:08 --> UTF-8 Support Enabled
INFO - 2019-07-02 14:54:08 --> Utf8 Class Initialized
INFO - 2019-07-02 14:54:08 --> Utf8 Class Initialized
INFO - 2019-07-02 14:54:08 --> URI Class Initialized
INFO - 2019-07-02 14:54:08 --> URI Class Initialized
INFO - 2019-07-02 14:54:08 --> Router Class Initialized
INFO - 2019-07-02 14:54:08 --> Router Class Initialized
INFO - 2019-07-02 14:54:08 --> Output Class Initialized
INFO - 2019-07-02 14:54:08 --> Output Class Initialized
INFO - 2019-07-02 14:54:08 --> Security Class Initialized
INFO - 2019-07-02 14:54:08 --> Security Class Initialized
DEBUG - 2019-07-02 14:54:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-02 14:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 14:54:08 --> Input Class Initialized
INFO - 2019-07-02 14:54:08 --> Input Class Initialized
INFO - 2019-07-02 14:54:08 --> Language Class Initialized
INFO - 2019-07-02 14:54:08 --> Language Class Initialized
INFO - 2019-07-02 14:54:08 --> Language Class Initialized
INFO - 2019-07-02 14:54:08 --> Language Class Initialized
INFO - 2019-07-02 14:54:08 --> Config Class Initialized
INFO - 2019-07-02 14:54:08 --> Config Class Initialized
INFO - 2019-07-02 14:54:08 --> Loader Class Initialized
INFO - 2019-07-02 14:54:08 --> Loader Class Initialized
DEBUG - 2019-07-02 14:54:08 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-02 14:54:08 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 14:54:08 --> Helper loaded: url_helper
INFO - 2019-07-02 14:54:08 --> Helper loaded: url_helper
INFO - 2019-07-02 14:54:08 --> Helper loaded: inflector_helper
INFO - 2019-07-02 14:54:08 --> Helper loaded: inflector_helper
INFO - 2019-07-02 14:54:08 --> Helper loaded: string_helper
INFO - 2019-07-02 14:54:08 --> Helper loaded: string_helper
INFO - 2019-07-02 14:54:08 --> Helper loaded: array_helper
INFO - 2019-07-02 14:54:08 --> Helper loaded: array_helper
INFO - 2019-07-02 14:54:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 14:54:08 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 14:54:08 --> Database Driver Class Initialized
INFO - 2019-07-02 14:54:08 --> Controller Class Initialized
INFO - 2019-07-02 20:54:08 --> Helper loaded: language_helper
INFO - 2019-07-02 20:54:08 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 20:54:08 --> Model Class Initialized
INFO - 2019-07-02 20:54:08 --> Model Class Initialized
INFO - 2019-07-02 20:54:08 --> Model Class Initialized
INFO - 2019-07-02 20:54:08 --> Model Class Initialized
INFO - 2019-07-02 20:54:08 --> Model Class Initialized
INFO - 2019-07-02 20:54:08 --> Final output sent to browser
DEBUG - 2019-07-02 20:54:08 --> Total execution time: 0.3843
INFO - 2019-07-02 14:54:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 14:54:08 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 14:54:08 --> Database Driver Class Initialized
INFO - 2019-07-02 14:54:08 --> Controller Class Initialized
INFO - 2019-07-02 20:54:08 --> Helper loaded: language_helper
INFO - 2019-07-02 20:54:08 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 20:54:08 --> Model Class Initialized
INFO - 2019-07-02 20:54:08 --> Model Class Initialized
INFO - 2019-07-02 20:54:08 --> Model Class Initialized
INFO - 2019-07-02 20:54:08 --> Model Class Initialized
INFO - 2019-07-02 20:54:08 --> Final output sent to browser
DEBUG - 2019-07-02 20:54:08 --> Total execution time: 0.5205
INFO - 2019-07-02 14:54:16 --> Config Class Initialized
INFO - 2019-07-02 14:54:16 --> Hooks Class Initialized
DEBUG - 2019-07-02 14:54:16 --> UTF-8 Support Enabled
INFO - 2019-07-02 14:54:16 --> Utf8 Class Initialized
INFO - 2019-07-02 14:54:16 --> URI Class Initialized
INFO - 2019-07-02 14:54:16 --> Router Class Initialized
INFO - 2019-07-02 14:54:16 --> Output Class Initialized
INFO - 2019-07-02 14:54:16 --> Security Class Initialized
DEBUG - 2019-07-02 14:54:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 14:54:16 --> Input Class Initialized
INFO - 2019-07-02 14:54:16 --> Language Class Initialized
INFO - 2019-07-02 14:54:16 --> Language Class Initialized
INFO - 2019-07-02 14:54:16 --> Config Class Initialized
INFO - 2019-07-02 14:54:16 --> Loader Class Initialized
DEBUG - 2019-07-02 14:54:16 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 14:54:16 --> Helper loaded: url_helper
INFO - 2019-07-02 14:54:16 --> Helper loaded: inflector_helper
INFO - 2019-07-02 14:54:16 --> Helper loaded: string_helper
INFO - 2019-07-02 14:54:16 --> Helper loaded: array_helper
INFO - 2019-07-02 14:54:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 14:54:16 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 14:54:16 --> Database Driver Class Initialized
INFO - 2019-07-02 14:54:16 --> Controller Class Initialized
INFO - 2019-07-02 20:54:16 --> Helper loaded: language_helper
INFO - 2019-07-02 20:54:16 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 20:54:16 --> Model Class Initialized
INFO - 2019-07-02 20:54:16 --> Model Class Initialized
INFO - 2019-07-02 20:54:16 --> Model Class Initialized
INFO - 2019-07-02 20:54:16 --> Model Class Initialized
INFO - 2019-07-02 20:54:16 --> Model Class Initialized
INFO - 2019-07-02 20:54:16 --> Final output sent to browser
DEBUG - 2019-07-02 20:54:16 --> Total execution time: 0.3212
INFO - 2019-07-02 14:54:16 --> Config Class Initialized
INFO - 2019-07-02 14:54:16 --> Hooks Class Initialized
DEBUG - 2019-07-02 14:54:16 --> UTF-8 Support Enabled
INFO - 2019-07-02 14:54:16 --> Utf8 Class Initialized
INFO - 2019-07-02 14:54:16 --> URI Class Initialized
INFO - 2019-07-02 14:54:16 --> Router Class Initialized
INFO - 2019-07-02 14:54:16 --> Output Class Initialized
INFO - 2019-07-02 14:54:16 --> Security Class Initialized
DEBUG - 2019-07-02 14:54:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 14:54:16 --> Input Class Initialized
INFO - 2019-07-02 14:54:16 --> Language Class Initialized
INFO - 2019-07-02 14:54:16 --> Language Class Initialized
INFO - 2019-07-02 14:54:16 --> Config Class Initialized
INFO - 2019-07-02 14:54:16 --> Loader Class Initialized
DEBUG - 2019-07-02 14:54:17 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 14:54:17 --> Helper loaded: url_helper
INFO - 2019-07-02 14:54:17 --> Helper loaded: inflector_helper
INFO - 2019-07-02 14:54:17 --> Helper loaded: string_helper
INFO - 2019-07-02 14:54:17 --> Helper loaded: array_helper
INFO - 2019-07-02 14:54:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 14:54:17 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 14:54:17 --> Database Driver Class Initialized
INFO - 2019-07-02 14:54:17 --> Controller Class Initialized
INFO - 2019-07-02 20:54:17 --> Helper loaded: language_helper
INFO - 2019-07-02 20:54:17 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 20:54:17 --> Model Class Initialized
INFO - 2019-07-02 20:54:17 --> Model Class Initialized
INFO - 2019-07-02 20:54:17 --> Model Class Initialized
INFO - 2019-07-02 20:54:17 --> Model Class Initialized
INFO - 2019-07-02 20:54:17 --> Model Class Initialized
INFO - 2019-07-02 20:54:17 --> Final output sent to browser
DEBUG - 2019-07-02 20:54:17 --> Total execution time: 0.3303
INFO - 2019-07-02 14:54:18 --> Config Class Initialized
INFO - 2019-07-02 14:54:18 --> Hooks Class Initialized
DEBUG - 2019-07-02 14:54:18 --> UTF-8 Support Enabled
INFO - 2019-07-02 14:54:18 --> Utf8 Class Initialized
INFO - 2019-07-02 14:54:18 --> URI Class Initialized
INFO - 2019-07-02 14:54:18 --> Router Class Initialized
INFO - 2019-07-02 14:54:18 --> Output Class Initialized
INFO - 2019-07-02 14:54:18 --> Security Class Initialized
DEBUG - 2019-07-02 14:54:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 14:54:18 --> Input Class Initialized
INFO - 2019-07-02 14:54:19 --> Language Class Initialized
INFO - 2019-07-02 14:54:19 --> Language Class Initialized
INFO - 2019-07-02 14:54:19 --> Config Class Initialized
INFO - 2019-07-02 14:54:19 --> Loader Class Initialized
DEBUG - 2019-07-02 14:54:19 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 14:54:19 --> Helper loaded: url_helper
INFO - 2019-07-02 14:54:19 --> Helper loaded: inflector_helper
INFO - 2019-07-02 14:54:19 --> Helper loaded: string_helper
INFO - 2019-07-02 14:54:19 --> Helper loaded: array_helper
INFO - 2019-07-02 14:54:19 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 14:54:19 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 14:54:19 --> Database Driver Class Initialized
INFO - 2019-07-02 14:54:19 --> Controller Class Initialized
INFO - 2019-07-02 20:54:19 --> Helper loaded: language_helper
INFO - 2019-07-02 20:54:19 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 20:54:19 --> Model Class Initialized
INFO - 2019-07-02 20:54:19 --> Model Class Initialized
INFO - 2019-07-02 20:54:19 --> Model Class Initialized
INFO - 2019-07-02 20:54:19 --> Model Class Initialized
INFO - 2019-07-02 20:54:19 --> Model Class Initialized
INFO - 2019-07-02 20:54:19 --> Final output sent to browser
DEBUG - 2019-07-02 20:54:19 --> Total execution time: 0.3443
INFO - 2019-07-02 14:54:21 --> Config Class Initialized
INFO - 2019-07-02 14:54:21 --> Hooks Class Initialized
DEBUG - 2019-07-02 14:54:21 --> UTF-8 Support Enabled
INFO - 2019-07-02 14:54:21 --> Utf8 Class Initialized
INFO - 2019-07-02 14:54:21 --> URI Class Initialized
INFO - 2019-07-02 14:54:21 --> Router Class Initialized
INFO - 2019-07-02 14:54:21 --> Output Class Initialized
INFO - 2019-07-02 14:54:21 --> Security Class Initialized
DEBUG - 2019-07-02 14:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 14:54:21 --> Input Class Initialized
INFO - 2019-07-02 14:54:21 --> Language Class Initialized
INFO - 2019-07-02 14:54:21 --> Language Class Initialized
INFO - 2019-07-02 14:54:21 --> Config Class Initialized
INFO - 2019-07-02 14:54:21 --> Loader Class Initialized
DEBUG - 2019-07-02 14:54:21 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 14:54:21 --> Helper loaded: url_helper
INFO - 2019-07-02 14:54:21 --> Helper loaded: inflector_helper
INFO - 2019-07-02 14:54:21 --> Helper loaded: string_helper
INFO - 2019-07-02 14:54:21 --> Helper loaded: array_helper
INFO - 2019-07-02 14:54:21 --> Session: Class initialized using 'files' driver.
INFO - 2019-07-02 14:54:21 --> Controller Class Initialized
INFO - 2019-07-02 20:54:21 --> Helper loaded: language_helper
INFO - 2019-07-02 20:54:21 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 20:54:21 --> Final output sent to browser
DEBUG - 2019-07-02 20:54:22 --> Total execution time: 0.3008
INFO - 2019-07-02 14:57:07 --> Config Class Initialized
INFO - 2019-07-02 14:57:07 --> Hooks Class Initialized
DEBUG - 2019-07-02 14:57:07 --> UTF-8 Support Enabled
INFO - 2019-07-02 14:57:07 --> Utf8 Class Initialized
INFO - 2019-07-02 14:57:07 --> URI Class Initialized
INFO - 2019-07-02 14:57:07 --> Router Class Initialized
INFO - 2019-07-02 14:57:07 --> Output Class Initialized
INFO - 2019-07-02 14:57:07 --> Security Class Initialized
DEBUG - 2019-07-02 14:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 14:57:07 --> Input Class Initialized
INFO - 2019-07-02 14:57:07 --> Language Class Initialized
INFO - 2019-07-02 14:57:07 --> Language Class Initialized
INFO - 2019-07-02 14:57:07 --> Config Class Initialized
INFO - 2019-07-02 14:57:07 --> Loader Class Initialized
DEBUG - 2019-07-02 14:57:07 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 14:57:07 --> Helper loaded: url_helper
INFO - 2019-07-02 14:57:07 --> Helper loaded: inflector_helper
INFO - 2019-07-02 14:57:07 --> Helper loaded: string_helper
INFO - 2019-07-02 14:57:07 --> Helper loaded: array_helper
INFO - 2019-07-02 14:57:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 14:57:07 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 14:57:07 --> Database Driver Class Initialized
INFO - 2019-07-02 14:57:07 --> Controller Class Initialized
INFO - 2019-07-02 20:57:07 --> Helper loaded: language_helper
INFO - 2019-07-02 20:57:07 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 20:57:07 --> Model Class Initialized
INFO - 2019-07-02 20:57:07 --> Model Class Initialized
INFO - 2019-07-02 20:57:07 --> Model Class Initialized
INFO - 2019-07-02 20:57:07 --> Model Class Initialized
INFO - 2019-07-02 20:57:07 --> Model Class Initialized
INFO - 2019-07-02 20:57:07 --> Final output sent to browser
DEBUG - 2019-07-02 20:57:07 --> Total execution time: 0.3291
INFO - 2019-07-02 14:57:07 --> Config Class Initialized
INFO - 2019-07-02 14:57:07 --> Hooks Class Initialized
DEBUG - 2019-07-02 14:57:07 --> UTF-8 Support Enabled
INFO - 2019-07-02 14:57:08 --> Utf8 Class Initialized
INFO - 2019-07-02 14:57:08 --> URI Class Initialized
INFO - 2019-07-02 14:57:08 --> Router Class Initialized
INFO - 2019-07-02 14:57:08 --> Output Class Initialized
INFO - 2019-07-02 14:57:08 --> Security Class Initialized
DEBUG - 2019-07-02 14:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 14:57:08 --> Input Class Initialized
INFO - 2019-07-02 14:57:08 --> Language Class Initialized
INFO - 2019-07-02 14:57:08 --> Language Class Initialized
INFO - 2019-07-02 14:57:08 --> Config Class Initialized
INFO - 2019-07-02 14:57:08 --> Loader Class Initialized
DEBUG - 2019-07-02 14:57:08 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 14:57:08 --> Helper loaded: url_helper
INFO - 2019-07-02 14:57:08 --> Helper loaded: inflector_helper
INFO - 2019-07-02 14:57:08 --> Helper loaded: string_helper
INFO - 2019-07-02 14:57:08 --> Helper loaded: array_helper
INFO - 2019-07-02 14:57:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 14:57:08 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 14:57:08 --> Database Driver Class Initialized
INFO - 2019-07-02 14:57:08 --> Controller Class Initialized
INFO - 2019-07-02 20:57:08 --> Helper loaded: language_helper
INFO - 2019-07-02 20:57:08 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 20:57:08 --> Model Class Initialized
INFO - 2019-07-02 20:57:08 --> Model Class Initialized
INFO - 2019-07-02 20:57:08 --> Model Class Initialized
INFO - 2019-07-02 20:57:08 --> Model Class Initialized
INFO - 2019-07-02 20:57:08 --> Model Class Initialized
INFO - 2019-07-02 20:57:08 --> Final output sent to browser
DEBUG - 2019-07-02 20:57:08 --> Total execution time: 0.3325
INFO - 2019-07-02 14:57:20 --> Config Class Initialized
INFO - 2019-07-02 14:57:20 --> Hooks Class Initialized
DEBUG - 2019-07-02 14:57:20 --> UTF-8 Support Enabled
INFO - 2019-07-02 14:57:20 --> Utf8 Class Initialized
INFO - 2019-07-02 14:57:20 --> URI Class Initialized
INFO - 2019-07-02 14:57:20 --> Router Class Initialized
INFO - 2019-07-02 14:57:20 --> Output Class Initialized
INFO - 2019-07-02 14:57:20 --> Security Class Initialized
DEBUG - 2019-07-02 14:57:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 14:57:20 --> Input Class Initialized
INFO - 2019-07-02 14:57:20 --> Language Class Initialized
INFO - 2019-07-02 14:57:20 --> Language Class Initialized
INFO - 2019-07-02 14:57:20 --> Config Class Initialized
INFO - 2019-07-02 14:57:20 --> Loader Class Initialized
DEBUG - 2019-07-02 14:57:20 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 14:57:20 --> Helper loaded: url_helper
INFO - 2019-07-02 14:57:20 --> Helper loaded: inflector_helper
INFO - 2019-07-02 14:57:20 --> Helper loaded: string_helper
INFO - 2019-07-02 14:57:20 --> Helper loaded: array_helper
INFO - 2019-07-02 14:57:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 14:57:20 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 14:57:20 --> Database Driver Class Initialized
INFO - 2019-07-02 14:57:20 --> Controller Class Initialized
INFO - 2019-07-02 20:57:20 --> Helper loaded: language_helper
INFO - 2019-07-02 20:57:20 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 20:57:20 --> Model Class Initialized
INFO - 2019-07-02 20:57:20 --> Model Class Initialized
INFO - 2019-07-02 20:57:20 --> Model Class Initialized
INFO - 2019-07-02 20:57:20 --> Model Class Initialized
INFO - 2019-07-02 20:57:20 --> Model Class Initialized
INFO - 2019-07-02 20:57:20 --> Upload Class Initialized
INFO - 2019-07-02 20:57:20 --> Language file loaded: language/english/upload_lang.php
DEBUG - 2019-07-02 20:57:20 --> You did not select a file to upload.
INFO - 2019-07-02 20:57:20 --> Final output sent to browser
DEBUG - 2019-07-02 20:57:20 --> Total execution time: 0.3840
INFO - 2019-07-02 14:57:20 --> Config Class Initialized
INFO - 2019-07-02 14:57:20 --> Hooks Class Initialized
DEBUG - 2019-07-02 14:57:20 --> UTF-8 Support Enabled
INFO - 2019-07-02 14:57:20 --> Utf8 Class Initialized
INFO - 2019-07-02 14:57:20 --> URI Class Initialized
INFO - 2019-07-02 14:57:20 --> Router Class Initialized
INFO - 2019-07-02 14:57:20 --> Output Class Initialized
INFO - 2019-07-02 14:57:20 --> Security Class Initialized
DEBUG - 2019-07-02 14:57:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 14:57:20 --> Input Class Initialized
INFO - 2019-07-02 14:57:20 --> Language Class Initialized
INFO - 2019-07-02 14:57:20 --> Language Class Initialized
INFO - 2019-07-02 14:57:20 --> Config Class Initialized
INFO - 2019-07-02 14:57:20 --> Loader Class Initialized
DEBUG - 2019-07-02 14:57:20 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 14:57:20 --> Helper loaded: url_helper
INFO - 2019-07-02 14:57:20 --> Helper loaded: inflector_helper
INFO - 2019-07-02 14:57:20 --> Helper loaded: string_helper
INFO - 2019-07-02 14:57:20 --> Helper loaded: array_helper
INFO - 2019-07-02 14:57:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 14:57:20 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 14:57:20 --> Database Driver Class Initialized
INFO - 2019-07-02 14:57:20 --> Controller Class Initialized
INFO - 2019-07-02 20:57:20 --> Helper loaded: language_helper
INFO - 2019-07-02 20:57:20 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 20:57:20 --> Model Class Initialized
INFO - 2019-07-02 20:57:20 --> Model Class Initialized
INFO - 2019-07-02 20:57:20 --> Model Class Initialized
INFO - 2019-07-02 20:57:20 --> Model Class Initialized
INFO - 2019-07-02 20:57:20 --> Model Class Initialized
INFO - 2019-07-02 20:57:20 --> Final output sent to browser
DEBUG - 2019-07-02 20:57:20 --> Total execution time: 0.3086
INFO - 2019-07-02 14:57:20 --> Config Class Initialized
INFO - 2019-07-02 14:57:20 --> Hooks Class Initialized
DEBUG - 2019-07-02 14:57:20 --> UTF-8 Support Enabled
INFO - 2019-07-02 14:57:20 --> Utf8 Class Initialized
INFO - 2019-07-02 14:57:20 --> URI Class Initialized
INFO - 2019-07-02 14:57:20 --> Router Class Initialized
INFO - 2019-07-02 14:57:20 --> Output Class Initialized
INFO - 2019-07-02 14:57:20 --> Security Class Initialized
DEBUG - 2019-07-02 14:57:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 14:57:20 --> Input Class Initialized
INFO - 2019-07-02 14:57:20 --> Language Class Initialized
INFO - 2019-07-02 14:57:20 --> Language Class Initialized
INFO - 2019-07-02 14:57:20 --> Config Class Initialized
INFO - 2019-07-02 14:57:20 --> Loader Class Initialized
DEBUG - 2019-07-02 14:57:20 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 14:57:20 --> Helper loaded: url_helper
INFO - 2019-07-02 14:57:20 --> Helper loaded: inflector_helper
INFO - 2019-07-02 14:57:21 --> Helper loaded: string_helper
INFO - 2019-07-02 14:57:21 --> Helper loaded: array_helper
INFO - 2019-07-02 14:57:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 14:57:21 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 14:57:21 --> Database Driver Class Initialized
INFO - 2019-07-02 14:57:21 --> Controller Class Initialized
INFO - 2019-07-02 20:57:21 --> Helper loaded: language_helper
INFO - 2019-07-02 20:57:21 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 20:57:21 --> Model Class Initialized
INFO - 2019-07-02 20:57:21 --> Model Class Initialized
INFO - 2019-07-02 20:57:21 --> Model Class Initialized
INFO - 2019-07-02 20:57:21 --> Model Class Initialized
INFO - 2019-07-02 20:57:21 --> Model Class Initialized
INFO - 2019-07-02 20:57:21 --> Final output sent to browser
DEBUG - 2019-07-02 20:57:21 --> Total execution time: 0.3425
INFO - 2019-07-02 14:57:27 --> Config Class Initialized
INFO - 2019-07-02 14:57:27 --> Hooks Class Initialized
INFO - 2019-07-02 14:57:27 --> Config Class Initialized
DEBUG - 2019-07-02 14:57:27 --> UTF-8 Support Enabled
INFO - 2019-07-02 14:57:27 --> Hooks Class Initialized
INFO - 2019-07-02 14:57:27 --> Utf8 Class Initialized
DEBUG - 2019-07-02 14:57:27 --> UTF-8 Support Enabled
INFO - 2019-07-02 14:57:27 --> Utf8 Class Initialized
INFO - 2019-07-02 14:57:27 --> URI Class Initialized
INFO - 2019-07-02 14:57:27 --> URI Class Initialized
INFO - 2019-07-02 14:57:27 --> Router Class Initialized
INFO - 2019-07-02 14:57:27 --> Router Class Initialized
INFO - 2019-07-02 14:57:27 --> Output Class Initialized
INFO - 2019-07-02 14:57:27 --> Output Class Initialized
INFO - 2019-07-02 14:57:27 --> Security Class Initialized
INFO - 2019-07-02 14:57:27 --> Security Class Initialized
DEBUG - 2019-07-02 14:57:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-02 14:57:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 14:57:27 --> Input Class Initialized
INFO - 2019-07-02 14:57:27 --> Input Class Initialized
INFO - 2019-07-02 14:57:27 --> Language Class Initialized
INFO - 2019-07-02 14:57:27 --> Language Class Initialized
INFO - 2019-07-02 14:57:27 --> Language Class Initialized
INFO - 2019-07-02 14:57:27 --> Language Class Initialized
INFO - 2019-07-02 14:57:27 --> Config Class Initialized
INFO - 2019-07-02 14:57:27 --> Loader Class Initialized
INFO - 2019-07-02 14:57:27 --> Config Class Initialized
INFO - 2019-07-02 14:57:27 --> Loader Class Initialized
DEBUG - 2019-07-02 14:57:27 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-02 14:57:27 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 14:57:27 --> Helper loaded: url_helper
INFO - 2019-07-02 14:57:27 --> Helper loaded: url_helper
INFO - 2019-07-02 14:57:27 --> Helper loaded: inflector_helper
INFO - 2019-07-02 14:57:27 --> Helper loaded: inflector_helper
INFO - 2019-07-02 14:57:27 --> Helper loaded: string_helper
INFO - 2019-07-02 14:57:27 --> Helper loaded: string_helper
INFO - 2019-07-02 14:57:27 --> Helper loaded: array_helper
INFO - 2019-07-02 14:57:27 --> Helper loaded: array_helper
INFO - 2019-07-02 14:57:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 14:57:27 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 14:57:27 --> Database Driver Class Initialized
INFO - 2019-07-02 14:57:27 --> Controller Class Initialized
INFO - 2019-07-02 20:57:27 --> Helper loaded: language_helper
INFO - 2019-07-02 20:57:27 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 20:57:27 --> Model Class Initialized
INFO - 2019-07-02 20:57:27 --> Model Class Initialized
INFO - 2019-07-02 20:57:27 --> Model Class Initialized
INFO - 2019-07-02 20:57:27 --> Model Class Initialized
INFO - 2019-07-02 20:57:27 --> Model Class Initialized
INFO - 2019-07-02 20:57:27 --> Final output sent to browser
DEBUG - 2019-07-02 20:57:27 --> Total execution time: 0.4234
INFO - 2019-07-02 14:57:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 14:57:27 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 14:57:27 --> Database Driver Class Initialized
INFO - 2019-07-02 14:57:27 --> Controller Class Initialized
INFO - 2019-07-02 20:57:27 --> Helper loaded: language_helper
INFO - 2019-07-02 20:57:27 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 20:57:27 --> Model Class Initialized
INFO - 2019-07-02 20:57:27 --> Model Class Initialized
INFO - 2019-07-02 20:57:27 --> Model Class Initialized
INFO - 2019-07-02 20:57:27 --> Model Class Initialized
INFO - 2019-07-02 20:57:27 --> Final output sent to browser
DEBUG - 2019-07-02 20:57:27 --> Total execution time: 0.5372
INFO - 2019-07-02 14:58:01 --> Config Class Initialized
INFO - 2019-07-02 14:58:01 --> Hooks Class Initialized
DEBUG - 2019-07-02 14:58:01 --> UTF-8 Support Enabled
INFO - 2019-07-02 14:58:01 --> Utf8 Class Initialized
INFO - 2019-07-02 14:58:01 --> URI Class Initialized
INFO - 2019-07-02 14:58:01 --> Router Class Initialized
INFO - 2019-07-02 14:58:01 --> Output Class Initialized
INFO - 2019-07-02 14:58:01 --> Security Class Initialized
DEBUG - 2019-07-02 14:58:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 14:58:01 --> Input Class Initialized
INFO - 2019-07-02 14:58:01 --> Language Class Initialized
INFO - 2019-07-02 14:58:01 --> Language Class Initialized
INFO - 2019-07-02 14:58:01 --> Config Class Initialized
INFO - 2019-07-02 14:58:01 --> Loader Class Initialized
DEBUG - 2019-07-02 14:58:01 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 14:58:01 --> Helper loaded: url_helper
INFO - 2019-07-02 14:58:01 --> Helper loaded: inflector_helper
INFO - 2019-07-02 14:58:01 --> Helper loaded: string_helper
INFO - 2019-07-02 14:58:01 --> Helper loaded: array_helper
INFO - 2019-07-02 14:58:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 14:58:01 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 14:58:01 --> Database Driver Class Initialized
INFO - 2019-07-02 14:58:01 --> Controller Class Initialized
INFO - 2019-07-02 20:58:01 --> Helper loaded: language_helper
INFO - 2019-07-02 20:58:01 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 20:58:01 --> Model Class Initialized
INFO - 2019-07-02 20:58:01 --> Model Class Initialized
INFO - 2019-07-02 20:58:01 --> Model Class Initialized
INFO - 2019-07-02 20:58:01 --> Model Class Initialized
INFO - 2019-07-02 20:58:01 --> Final output sent to browser
DEBUG - 2019-07-02 20:58:01 --> Total execution time: 0.3697
INFO - 2019-07-02 14:58:01 --> Config Class Initialized
INFO - 2019-07-02 14:58:01 --> Hooks Class Initialized
DEBUG - 2019-07-02 14:58:01 --> UTF-8 Support Enabled
INFO - 2019-07-02 14:58:02 --> Utf8 Class Initialized
INFO - 2019-07-02 14:58:02 --> URI Class Initialized
INFO - 2019-07-02 14:58:02 --> Router Class Initialized
INFO - 2019-07-02 14:58:02 --> Output Class Initialized
INFO - 2019-07-02 14:58:02 --> Security Class Initialized
DEBUG - 2019-07-02 14:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 14:58:02 --> Input Class Initialized
INFO - 2019-07-02 14:58:02 --> Language Class Initialized
INFO - 2019-07-02 14:58:02 --> Language Class Initialized
INFO - 2019-07-02 14:58:02 --> Config Class Initialized
INFO - 2019-07-02 14:58:02 --> Loader Class Initialized
DEBUG - 2019-07-02 14:58:02 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 14:58:02 --> Helper loaded: url_helper
INFO - 2019-07-02 14:58:02 --> Helper loaded: inflector_helper
INFO - 2019-07-02 14:58:02 --> Helper loaded: string_helper
INFO - 2019-07-02 14:58:02 --> Helper loaded: array_helper
INFO - 2019-07-02 14:58:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 14:58:02 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 14:58:02 --> Database Driver Class Initialized
INFO - 2019-07-02 14:58:02 --> Controller Class Initialized
INFO - 2019-07-02 20:58:02 --> Helper loaded: language_helper
INFO - 2019-07-02 20:58:02 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 20:58:02 --> Model Class Initialized
INFO - 2019-07-02 20:58:02 --> Model Class Initialized
INFO - 2019-07-02 20:58:02 --> Model Class Initialized
INFO - 2019-07-02 20:58:02 --> Model Class Initialized
INFO - 2019-07-02 20:58:02 --> Model Class Initialized
INFO - 2019-07-02 20:58:02 --> Final output sent to browser
DEBUG - 2019-07-02 20:58:02 --> Total execution time: 0.3493
INFO - 2019-07-02 14:58:03 --> Config Class Initialized
INFO - 2019-07-02 14:58:03 --> Hooks Class Initialized
DEBUG - 2019-07-02 14:58:03 --> UTF-8 Support Enabled
INFO - 2019-07-02 14:58:03 --> Utf8 Class Initialized
INFO - 2019-07-02 14:58:03 --> URI Class Initialized
INFO - 2019-07-02 14:58:03 --> Router Class Initialized
INFO - 2019-07-02 14:58:03 --> Output Class Initialized
INFO - 2019-07-02 14:58:03 --> Security Class Initialized
DEBUG - 2019-07-02 14:58:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 14:58:03 --> Input Class Initialized
INFO - 2019-07-02 14:58:03 --> Language Class Initialized
INFO - 2019-07-02 14:58:03 --> Language Class Initialized
INFO - 2019-07-02 14:58:03 --> Config Class Initialized
INFO - 2019-07-02 14:58:03 --> Loader Class Initialized
DEBUG - 2019-07-02 14:58:03 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 14:58:03 --> Helper loaded: url_helper
INFO - 2019-07-02 14:58:03 --> Helper loaded: inflector_helper
INFO - 2019-07-02 14:58:03 --> Helper loaded: string_helper
INFO - 2019-07-02 14:58:03 --> Helper loaded: array_helper
INFO - 2019-07-02 14:58:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 14:58:03 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 14:58:03 --> Database Driver Class Initialized
INFO - 2019-07-02 14:58:03 --> Controller Class Initialized
INFO - 2019-07-02 20:58:03 --> Helper loaded: language_helper
INFO - 2019-07-02 20:58:03 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 20:58:03 --> Model Class Initialized
INFO - 2019-07-02 20:58:03 --> Model Class Initialized
INFO - 2019-07-02 20:58:03 --> Model Class Initialized
INFO - 2019-07-02 20:58:03 --> Model Class Initialized
INFO - 2019-07-02 20:58:03 --> Helper loaded: form_helper
INFO - 2019-07-02 20:58:03 --> Form Validation Class Initialized
DEBUG - 2019-07-02 20:58:03 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-02 20:58:03 --> Model Class Initialized
INFO - 2019-07-02 20:58:03 --> Model Class Initialized
INFO - 2019-07-02 20:58:03 --> Final output sent to browser
DEBUG - 2019-07-02 20:58:03 --> Total execution time: 0.4572
INFO - 2019-07-02 14:58:04 --> Config Class Initialized
INFO - 2019-07-02 14:58:04 --> Hooks Class Initialized
DEBUG - 2019-07-02 14:58:04 --> UTF-8 Support Enabled
INFO - 2019-07-02 14:58:04 --> Utf8 Class Initialized
INFO - 2019-07-02 14:58:04 --> URI Class Initialized
INFO - 2019-07-02 14:58:04 --> Router Class Initialized
INFO - 2019-07-02 14:58:04 --> Output Class Initialized
INFO - 2019-07-02 14:58:04 --> Security Class Initialized
DEBUG - 2019-07-02 14:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 14:58:04 --> Input Class Initialized
INFO - 2019-07-02 14:58:04 --> Language Class Initialized
INFO - 2019-07-02 14:58:05 --> Language Class Initialized
INFO - 2019-07-02 14:58:05 --> Config Class Initialized
INFO - 2019-07-02 14:58:05 --> Loader Class Initialized
DEBUG - 2019-07-02 14:58:05 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 14:58:05 --> Helper loaded: url_helper
INFO - 2019-07-02 14:58:05 --> Helper loaded: inflector_helper
INFO - 2019-07-02 14:58:05 --> Helper loaded: string_helper
INFO - 2019-07-02 14:58:05 --> Helper loaded: array_helper
INFO - 2019-07-02 14:58:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 14:58:05 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 14:58:05 --> Database Driver Class Initialized
INFO - 2019-07-02 14:58:05 --> Controller Class Initialized
INFO - 2019-07-02 20:58:05 --> Helper loaded: language_helper
INFO - 2019-07-02 20:58:05 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 20:58:05 --> Model Class Initialized
INFO - 2019-07-02 20:58:05 --> Model Class Initialized
INFO - 2019-07-02 20:58:05 --> Model Class Initialized
INFO - 2019-07-02 20:58:05 --> Model Class Initialized
INFO - 2019-07-02 20:58:05 --> Model Class Initialized
INFO - 2019-07-02 20:58:05 --> Final output sent to browser
DEBUG - 2019-07-02 20:58:05 --> Total execution time: 0.3472
INFO - 2019-07-02 14:58:07 --> Config Class Initialized
INFO - 2019-07-02 14:58:07 --> Hooks Class Initialized
DEBUG - 2019-07-02 14:58:07 --> UTF-8 Support Enabled
INFO - 2019-07-02 14:58:07 --> Utf8 Class Initialized
INFO - 2019-07-02 14:58:07 --> URI Class Initialized
INFO - 2019-07-02 14:58:07 --> Router Class Initialized
INFO - 2019-07-02 14:58:07 --> Output Class Initialized
INFO - 2019-07-02 14:58:07 --> Security Class Initialized
DEBUG - 2019-07-02 14:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 14:58:07 --> Input Class Initialized
INFO - 2019-07-02 14:58:07 --> Language Class Initialized
INFO - 2019-07-02 14:58:08 --> Language Class Initialized
INFO - 2019-07-02 14:58:08 --> Config Class Initialized
INFO - 2019-07-02 14:58:08 --> Loader Class Initialized
DEBUG - 2019-07-02 14:58:08 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 14:58:08 --> Helper loaded: url_helper
INFO - 2019-07-02 14:58:08 --> Helper loaded: inflector_helper
INFO - 2019-07-02 14:58:08 --> Helper loaded: string_helper
INFO - 2019-07-02 14:58:08 --> Helper loaded: array_helper
INFO - 2019-07-02 14:58:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 14:58:08 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 14:58:08 --> Database Driver Class Initialized
INFO - 2019-07-02 14:58:08 --> Controller Class Initialized
INFO - 2019-07-02 20:58:08 --> Helper loaded: language_helper
INFO - 2019-07-02 20:58:08 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 20:58:08 --> Model Class Initialized
INFO - 2019-07-02 20:58:08 --> Model Class Initialized
INFO - 2019-07-02 20:58:08 --> Model Class Initialized
INFO - 2019-07-02 20:58:08 --> Model Class Initialized
INFO - 2019-07-02 20:58:08 --> Helper loaded: form_helper
INFO - 2019-07-02 20:58:08 --> Form Validation Class Initialized
DEBUG - 2019-07-02 20:58:08 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-02 20:58:08 --> Model Class Initialized
INFO - 2019-07-02 20:58:08 --> Model Class Initialized
ERROR - 2019-07-02 20:58:08 --> Query error: Column 'resto_id' in where clause is ambiguous - Invalid query: SELECT `orders`.*, `order_details`.`qty`, `order_details`.`price`, `order_details`.`sub_total`, `order_details`.`status`, `order_details`.`product_id`, `order_details`.`created_at` AS `order_date`, `products`.`name`, CONCAT(`customers`.`firstname`, " ", `customers`.`lastname`) AS customer_fullname, `customers`.`address`, `customers`.`contact_number`, `customers`.`email`
FROM `orders`
LEFT JOIN `order_details` ON `order_details`.`order_id` = `orders`.`id`
LEFT JOIN `products` ON `products`.`id` = `order_details`.`product_id`
INNER JOIN `customers` as `customers` ON `customers`.`id` = `orders`.`customer_id`
WHERE `resto_id` = '2'
AND `customer_id` = '1'
AND `order_status` = 'pending'
INFO - 2019-07-02 20:58:08 --> Language file loaded: language/english/db_lang.php
INFO - 2019-07-02 14:58:08 --> Config Class Initialized
INFO - 2019-07-02 14:58:08 --> Hooks Class Initialized
DEBUG - 2019-07-02 14:58:08 --> UTF-8 Support Enabled
INFO - 2019-07-02 14:58:08 --> Utf8 Class Initialized
INFO - 2019-07-02 14:58:08 --> URI Class Initialized
INFO - 2019-07-02 14:58:08 --> Router Class Initialized
INFO - 2019-07-02 14:58:08 --> Output Class Initialized
INFO - 2019-07-02 14:58:08 --> Security Class Initialized
DEBUG - 2019-07-02 14:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 14:58:08 --> Input Class Initialized
INFO - 2019-07-02 14:58:08 --> Language Class Initialized
INFO - 2019-07-02 14:58:08 --> Language Class Initialized
INFO - 2019-07-02 14:58:08 --> Config Class Initialized
INFO - 2019-07-02 14:58:08 --> Loader Class Initialized
DEBUG - 2019-07-02 14:58:08 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 14:58:08 --> Helper loaded: url_helper
INFO - 2019-07-02 14:58:08 --> Helper loaded: inflector_helper
INFO - 2019-07-02 14:58:08 --> Helper loaded: string_helper
INFO - 2019-07-02 14:58:08 --> Helper loaded: array_helper
INFO - 2019-07-02 14:58:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 14:58:08 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 14:58:08 --> Database Driver Class Initialized
INFO - 2019-07-02 14:58:08 --> Controller Class Initialized
INFO - 2019-07-02 20:58:08 --> Helper loaded: language_helper
INFO - 2019-07-02 20:58:08 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 20:58:08 --> Model Class Initialized
INFO - 2019-07-02 20:58:08 --> Model Class Initialized
INFO - 2019-07-02 20:58:08 --> Model Class Initialized
INFO - 2019-07-02 20:58:08 --> Model Class Initialized
INFO - 2019-07-02 20:58:08 --> Helper loaded: form_helper
INFO - 2019-07-02 20:58:08 --> Form Validation Class Initialized
DEBUG - 2019-07-02 20:58:08 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-02 20:58:08 --> Model Class Initialized
INFO - 2019-07-02 20:58:08 --> Model Class Initialized
INFO - 2019-07-02 20:58:08 --> Final output sent to browser
DEBUG - 2019-07-02 20:58:08 --> Total execution time: 0.3639
INFO - 2019-07-02 14:58:12 --> Config Class Initialized
INFO - 2019-07-02 14:58:12 --> Hooks Class Initialized
DEBUG - 2019-07-02 14:58:12 --> UTF-8 Support Enabled
INFO - 2019-07-02 14:58:12 --> Utf8 Class Initialized
INFO - 2019-07-02 14:58:12 --> URI Class Initialized
INFO - 2019-07-02 14:58:12 --> Router Class Initialized
INFO - 2019-07-02 14:58:12 --> Output Class Initialized
INFO - 2019-07-02 14:58:12 --> Security Class Initialized
DEBUG - 2019-07-02 14:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 14:58:12 --> Input Class Initialized
INFO - 2019-07-02 14:58:12 --> Language Class Initialized
INFO - 2019-07-02 14:58:12 --> Language Class Initialized
INFO - 2019-07-02 14:58:12 --> Config Class Initialized
INFO - 2019-07-02 14:58:12 --> Loader Class Initialized
DEBUG - 2019-07-02 14:58:12 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 14:58:12 --> Helper loaded: url_helper
INFO - 2019-07-02 14:58:12 --> Helper loaded: inflector_helper
INFO - 2019-07-02 14:58:13 --> Helper loaded: string_helper
INFO - 2019-07-02 14:58:13 --> Helper loaded: array_helper
INFO - 2019-07-02 14:58:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 14:58:13 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 14:58:13 --> Database Driver Class Initialized
INFO - 2019-07-02 14:58:13 --> Controller Class Initialized
INFO - 2019-07-02 20:58:13 --> Helper loaded: language_helper
INFO - 2019-07-02 20:58:13 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 20:58:13 --> Model Class Initialized
INFO - 2019-07-02 20:58:13 --> Model Class Initialized
INFO - 2019-07-02 20:58:13 --> Model Class Initialized
INFO - 2019-07-02 20:58:13 --> Model Class Initialized
INFO - 2019-07-02 20:58:13 --> Helper loaded: form_helper
INFO - 2019-07-02 20:58:13 --> Form Validation Class Initialized
DEBUG - 2019-07-02 20:58:13 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-02 20:58:13 --> Model Class Initialized
INFO - 2019-07-02 20:58:13 --> Model Class Initialized
INFO - 2019-07-02 20:58:13 --> Final output sent to browser
DEBUG - 2019-07-02 20:58:13 --> Total execution time: 0.4651
INFO - 2019-07-02 14:58:15 --> Config Class Initialized
INFO - 2019-07-02 14:58:15 --> Hooks Class Initialized
DEBUG - 2019-07-02 14:58:15 --> UTF-8 Support Enabled
INFO - 2019-07-02 14:58:15 --> Utf8 Class Initialized
INFO - 2019-07-02 14:58:15 --> URI Class Initialized
INFO - 2019-07-02 14:58:15 --> Router Class Initialized
INFO - 2019-07-02 14:58:15 --> Output Class Initialized
INFO - 2019-07-02 14:58:15 --> Security Class Initialized
DEBUG - 2019-07-02 14:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 14:58:15 --> Input Class Initialized
INFO - 2019-07-02 14:58:15 --> Language Class Initialized
INFO - 2019-07-02 14:58:15 --> Language Class Initialized
INFO - 2019-07-02 14:58:15 --> Config Class Initialized
INFO - 2019-07-02 14:58:15 --> Loader Class Initialized
DEBUG - 2019-07-02 14:58:15 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 14:58:15 --> Helper loaded: url_helper
INFO - 2019-07-02 14:58:15 --> Helper loaded: inflector_helper
INFO - 2019-07-02 14:58:15 --> Helper loaded: string_helper
INFO - 2019-07-02 14:58:15 --> Helper loaded: array_helper
INFO - 2019-07-02 14:58:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 14:58:15 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 14:58:16 --> Database Driver Class Initialized
INFO - 2019-07-02 14:58:16 --> Controller Class Initialized
INFO - 2019-07-02 20:58:16 --> Helper loaded: language_helper
INFO - 2019-07-02 20:58:16 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 20:58:16 --> Model Class Initialized
INFO - 2019-07-02 20:58:16 --> Model Class Initialized
INFO - 2019-07-02 20:58:16 --> Model Class Initialized
INFO - 2019-07-02 20:58:16 --> Model Class Initialized
INFO - 2019-07-02 20:58:16 --> Model Class Initialized
INFO - 2019-07-02 20:58:16 --> Final output sent to browser
DEBUG - 2019-07-02 20:58:16 --> Total execution time: 0.3446
INFO - 2019-07-02 14:58:19 --> Config Class Initialized
INFO - 2019-07-02 14:58:19 --> Hooks Class Initialized
DEBUG - 2019-07-02 14:58:19 --> UTF-8 Support Enabled
INFO - 2019-07-02 14:58:19 --> Utf8 Class Initialized
INFO - 2019-07-02 14:58:19 --> URI Class Initialized
INFO - 2019-07-02 14:58:19 --> Router Class Initialized
INFO - 2019-07-02 14:58:19 --> Output Class Initialized
INFO - 2019-07-02 14:58:19 --> Security Class Initialized
DEBUG - 2019-07-02 14:58:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 14:58:19 --> Input Class Initialized
INFO - 2019-07-02 14:58:19 --> Language Class Initialized
INFO - 2019-07-02 14:58:19 --> Language Class Initialized
INFO - 2019-07-02 14:58:19 --> Config Class Initialized
INFO - 2019-07-02 14:58:19 --> Loader Class Initialized
DEBUG - 2019-07-02 14:58:19 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 14:58:19 --> Helper loaded: url_helper
INFO - 2019-07-02 14:58:19 --> Helper loaded: inflector_helper
INFO - 2019-07-02 14:58:19 --> Helper loaded: string_helper
INFO - 2019-07-02 14:58:19 --> Helper loaded: array_helper
INFO - 2019-07-02 14:58:19 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 14:58:19 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 14:58:19 --> Database Driver Class Initialized
INFO - 2019-07-02 14:58:19 --> Controller Class Initialized
INFO - 2019-07-02 20:58:19 --> Helper loaded: language_helper
INFO - 2019-07-02 20:58:19 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 20:58:19 --> Model Class Initialized
INFO - 2019-07-02 20:58:19 --> Model Class Initialized
INFO - 2019-07-02 20:58:19 --> Model Class Initialized
INFO - 2019-07-02 20:58:19 --> Model Class Initialized
INFO - 2019-07-02 20:58:19 --> Helper loaded: form_helper
INFO - 2019-07-02 20:58:19 --> Form Validation Class Initialized
DEBUG - 2019-07-02 20:58:19 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-02 20:58:19 --> Model Class Initialized
INFO - 2019-07-02 20:58:19 --> Model Class Initialized
ERROR - 2019-07-02 20:58:19 --> Query error: Column 'resto_id' in where clause is ambiguous - Invalid query: SELECT `orders`.*, `order_details`.`qty`, `order_details`.`price`, `order_details`.`sub_total`, `order_details`.`status`, `order_details`.`product_id`, `order_details`.`created_at` AS `order_date`, `products`.`name`, CONCAT(`customers`.`firstname`, " ", `customers`.`lastname`) AS customer_fullname, `customers`.`address`, `customers`.`contact_number`, `customers`.`email`
FROM `orders`
LEFT JOIN `order_details` ON `order_details`.`order_id` = `orders`.`id`
LEFT JOIN `products` ON `products`.`id` = `order_details`.`product_id`
INNER JOIN `customers` as `customers` ON `customers`.`id` = `orders`.`customer_id`
WHERE `resto_id` = '2'
AND `customer_id` = '1'
AND `order_status` = 'pending'
INFO - 2019-07-02 20:58:19 --> Language file loaded: language/english/db_lang.php
INFO - 2019-07-02 14:58:19 --> Config Class Initialized
INFO - 2019-07-02 14:58:19 --> Hooks Class Initialized
DEBUG - 2019-07-02 14:58:19 --> UTF-8 Support Enabled
INFO - 2019-07-02 14:58:19 --> Utf8 Class Initialized
INFO - 2019-07-02 14:58:19 --> URI Class Initialized
INFO - 2019-07-02 14:58:19 --> Router Class Initialized
INFO - 2019-07-02 14:58:19 --> Output Class Initialized
INFO - 2019-07-02 14:58:19 --> Security Class Initialized
DEBUG - 2019-07-02 14:58:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 14:58:19 --> Input Class Initialized
INFO - 2019-07-02 14:58:19 --> Language Class Initialized
INFO - 2019-07-02 14:58:19 --> Language Class Initialized
INFO - 2019-07-02 14:58:19 --> Config Class Initialized
INFO - 2019-07-02 14:58:19 --> Loader Class Initialized
DEBUG - 2019-07-02 14:58:19 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 14:58:19 --> Helper loaded: url_helper
INFO - 2019-07-02 14:58:19 --> Helper loaded: inflector_helper
INFO - 2019-07-02 14:58:19 --> Helper loaded: string_helper
INFO - 2019-07-02 14:58:19 --> Helper loaded: array_helper
INFO - 2019-07-02 14:58:19 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 14:58:19 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 14:58:19 --> Database Driver Class Initialized
INFO - 2019-07-02 14:58:19 --> Controller Class Initialized
INFO - 2019-07-02 20:58:19 --> Helper loaded: language_helper
INFO - 2019-07-02 20:58:19 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 20:58:19 --> Model Class Initialized
INFO - 2019-07-02 20:58:19 --> Model Class Initialized
INFO - 2019-07-02 20:58:19 --> Model Class Initialized
INFO - 2019-07-02 20:58:19 --> Model Class Initialized
INFO - 2019-07-02 20:58:19 --> Helper loaded: form_helper
INFO - 2019-07-02 20:58:19 --> Form Validation Class Initialized
DEBUG - 2019-07-02 20:58:19 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-02 20:58:19 --> Model Class Initialized
INFO - 2019-07-02 20:58:19 --> Model Class Initialized
INFO - 2019-07-02 20:58:19 --> Final output sent to browser
DEBUG - 2019-07-02 20:58:19 --> Total execution time: 0.3620
INFO - 2019-07-02 15:00:13 --> Config Class Initialized
INFO - 2019-07-02 15:00:13 --> Hooks Class Initialized
DEBUG - 2019-07-02 15:00:13 --> UTF-8 Support Enabled
INFO - 2019-07-02 15:00:13 --> Utf8 Class Initialized
INFO - 2019-07-02 15:00:13 --> URI Class Initialized
INFO - 2019-07-02 15:00:14 --> Router Class Initialized
INFO - 2019-07-02 15:00:14 --> Output Class Initialized
INFO - 2019-07-02 15:00:14 --> Security Class Initialized
DEBUG - 2019-07-02 15:00:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 15:00:14 --> Input Class Initialized
INFO - 2019-07-02 15:00:14 --> Language Class Initialized
INFO - 2019-07-02 15:00:14 --> Language Class Initialized
INFO - 2019-07-02 15:00:14 --> Config Class Initialized
INFO - 2019-07-02 15:00:14 --> Loader Class Initialized
DEBUG - 2019-07-02 15:00:14 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 15:00:14 --> Helper loaded: url_helper
INFO - 2019-07-02 15:00:14 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:00:14 --> Helper loaded: string_helper
INFO - 2019-07-02 15:00:14 --> Helper loaded: array_helper
INFO - 2019-07-02 15:00:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:00:14 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:00:14 --> Database Driver Class Initialized
INFO - 2019-07-02 15:00:14 --> Controller Class Initialized
INFO - 2019-07-02 21:00:14 --> Helper loaded: language_helper
INFO - 2019-07-02 21:00:14 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:00:14 --> Model Class Initialized
INFO - 2019-07-02 21:00:14 --> Model Class Initialized
INFO - 2019-07-02 21:00:14 --> Model Class Initialized
INFO - 2019-07-02 21:00:14 --> Model Class Initialized
INFO - 2019-07-02 21:00:14 --> Helper loaded: form_helper
INFO - 2019-07-02 21:00:14 --> Form Validation Class Initialized
DEBUG - 2019-07-02 21:00:14 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-02 21:00:14 --> Model Class Initialized
INFO - 2019-07-02 21:00:14 --> Model Class Initialized
ERROR - 2019-07-02 21:00:14 --> Severity: Notice --> Undefined index: resto_id C:\xampp\htdocs\crapi_admin\application\models\Order_model.php 69
ERROR - 2019-07-02 21:00:14 --> Query error: Unknown column 'order_details.order_status' in 'field list' - Invalid query: SELECT `orders`.*, `order_details`.`id` AS `order_details_id`, `order_details`.`qty`, `order_details`.`price`, `order_details`.`sub_total`, `order_details`.`order_status`, `order_details`.`product_id`, `order_details`.`created_at` AS `order_date`, `products`.`name`, CONCAT(`customers`.`firstname`, " ", `customers`.`lastname`) AS customer_fullname, `customers`.`address`, `customers`.`contact_number`, `customers`.`email`
FROM `orders`
LEFT JOIN `order_details` ON `order_details`.`order_id` = `orders`.`id`
LEFT JOIN `products` ON `products`.`id` = `order_details`.`product_id`
INNER JOIN `customers` as `customers` ON `customers`.`id` = `orders`.`customer_id`
WHERE `orders`.`resto_id` IS NULL
INFO - 2019-07-02 21:00:14 --> Language file loaded: language/english/db_lang.php
INFO - 2019-07-02 15:02:11 --> Config Class Initialized
INFO - 2019-07-02 15:02:11 --> Hooks Class Initialized
DEBUG - 2019-07-02 15:02:11 --> UTF-8 Support Enabled
INFO - 2019-07-02 15:02:11 --> Utf8 Class Initialized
INFO - 2019-07-02 15:02:11 --> URI Class Initialized
INFO - 2019-07-02 15:02:11 --> Router Class Initialized
INFO - 2019-07-02 15:02:11 --> Output Class Initialized
INFO - 2019-07-02 15:02:11 --> Security Class Initialized
DEBUG - 2019-07-02 15:02:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 15:02:11 --> Input Class Initialized
INFO - 2019-07-02 15:02:11 --> Language Class Initialized
INFO - 2019-07-02 15:02:11 --> Language Class Initialized
INFO - 2019-07-02 15:02:12 --> Config Class Initialized
INFO - 2019-07-02 15:02:12 --> Loader Class Initialized
DEBUG - 2019-07-02 15:02:12 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 15:02:12 --> Helper loaded: url_helper
INFO - 2019-07-02 15:02:12 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:02:12 --> Helper loaded: string_helper
INFO - 2019-07-02 15:02:12 --> Helper loaded: array_helper
INFO - 2019-07-02 15:02:12 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:02:12 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:02:12 --> Database Driver Class Initialized
INFO - 2019-07-02 15:02:12 --> Controller Class Initialized
INFO - 2019-07-02 21:02:12 --> Helper loaded: language_helper
INFO - 2019-07-02 21:02:12 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:02:12 --> Model Class Initialized
INFO - 2019-07-02 21:02:12 --> Model Class Initialized
INFO - 2019-07-02 21:02:12 --> Model Class Initialized
INFO - 2019-07-02 21:02:12 --> Model Class Initialized
INFO - 2019-07-02 21:02:12 --> Helper loaded: form_helper
INFO - 2019-07-02 21:02:12 --> Form Validation Class Initialized
DEBUG - 2019-07-02 21:02:12 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-02 21:02:12 --> Model Class Initialized
INFO - 2019-07-02 21:02:12 --> Model Class Initialized
ERROR - 2019-07-02 21:02:12 --> Severity: Notice --> Undefined index: resto_id C:\xampp\htdocs\crapi_admin\application\models\Order_model.php 69
ERROR - 2019-07-02 21:02:12 --> Query error: Unknown column 'order_details.order_status' in 'field list' - Invalid query: SELECT `orders`.*, `order_details`.`id` AS `order_details_id`, `order_details`.`qty`, `order_details`.`price`, `order_details`.`sub_total`, `order_details`.`order_status`, `order_details`.`product_id`, `order_details`.`created_at` AS `order_date`, `products`.`name`, CONCAT(`customers`.`firstname`, " ", `customers`.`lastname`) AS customer_fullname, `customers`.`address`, `customers`.`contact_number`, `customers`.`email`
FROM `orders`
LEFT JOIN `order_details` ON `order_details`.`order_id` = `orders`.`id`
LEFT JOIN `products` ON `products`.`id` = `order_details`.`product_id`
INNER JOIN `customers` as `customers` ON `customers`.`id` = `orders`.`customer_id`
WHERE `orders`.`resto_id` IS NULL
INFO - 2019-07-02 21:02:12 --> Language file loaded: language/english/db_lang.php
INFO - 2019-07-02 15:03:23 --> Config Class Initialized
INFO - 2019-07-02 15:03:23 --> Hooks Class Initialized
DEBUG - 2019-07-02 15:03:23 --> UTF-8 Support Enabled
INFO - 2019-07-02 15:03:23 --> Utf8 Class Initialized
INFO - 2019-07-02 15:03:23 --> URI Class Initialized
INFO - 2019-07-02 15:03:23 --> Router Class Initialized
INFO - 2019-07-02 15:03:23 --> Output Class Initialized
INFO - 2019-07-02 15:03:23 --> Security Class Initialized
DEBUG - 2019-07-02 15:03:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 15:03:23 --> Input Class Initialized
INFO - 2019-07-02 15:03:23 --> Language Class Initialized
INFO - 2019-07-02 15:03:23 --> Language Class Initialized
INFO - 2019-07-02 15:03:23 --> Config Class Initialized
INFO - 2019-07-02 15:03:24 --> Loader Class Initialized
DEBUG - 2019-07-02 15:03:24 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 15:03:24 --> Helper loaded: url_helper
INFO - 2019-07-02 15:03:24 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:03:24 --> Helper loaded: string_helper
INFO - 2019-07-02 15:03:24 --> Helper loaded: array_helper
INFO - 2019-07-02 15:03:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:03:24 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:03:24 --> Database Driver Class Initialized
INFO - 2019-07-02 15:03:24 --> Controller Class Initialized
INFO - 2019-07-02 21:03:24 --> Helper loaded: language_helper
INFO - 2019-07-02 21:03:24 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:03:24 --> Model Class Initialized
INFO - 2019-07-02 21:03:24 --> Model Class Initialized
INFO - 2019-07-02 21:03:24 --> Model Class Initialized
INFO - 2019-07-02 21:03:24 --> Model Class Initialized
INFO - 2019-07-02 21:03:24 --> Helper loaded: form_helper
INFO - 2019-07-02 21:03:24 --> Form Validation Class Initialized
DEBUG - 2019-07-02 21:03:24 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-02 21:03:24 --> Model Class Initialized
INFO - 2019-07-02 21:03:24 --> Model Class Initialized
INFO - 2019-07-02 15:03:42 --> Config Class Initialized
INFO - 2019-07-02 15:03:42 --> Hooks Class Initialized
DEBUG - 2019-07-02 15:03:42 --> UTF-8 Support Enabled
INFO - 2019-07-02 15:03:42 --> Utf8 Class Initialized
INFO - 2019-07-02 15:03:42 --> URI Class Initialized
INFO - 2019-07-02 15:03:42 --> Router Class Initialized
INFO - 2019-07-02 15:03:42 --> Output Class Initialized
INFO - 2019-07-02 15:03:42 --> Security Class Initialized
DEBUG - 2019-07-02 15:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 15:03:42 --> Input Class Initialized
INFO - 2019-07-02 15:03:42 --> Language Class Initialized
INFO - 2019-07-02 15:03:42 --> Language Class Initialized
INFO - 2019-07-02 15:03:42 --> Config Class Initialized
INFO - 2019-07-02 15:03:42 --> Loader Class Initialized
DEBUG - 2019-07-02 15:03:42 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 15:03:42 --> Helper loaded: url_helper
INFO - 2019-07-02 15:03:42 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:03:42 --> Helper loaded: string_helper
INFO - 2019-07-02 15:03:42 --> Helper loaded: array_helper
INFO - 2019-07-02 15:03:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:03:42 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:03:42 --> Database Driver Class Initialized
INFO - 2019-07-02 15:03:42 --> Controller Class Initialized
INFO - 2019-07-02 21:03:42 --> Helper loaded: language_helper
INFO - 2019-07-02 21:03:42 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:03:42 --> Model Class Initialized
INFO - 2019-07-02 21:03:42 --> Model Class Initialized
INFO - 2019-07-02 21:03:42 --> Model Class Initialized
INFO - 2019-07-02 21:03:42 --> Model Class Initialized
INFO - 2019-07-02 21:03:42 --> Helper loaded: form_helper
INFO - 2019-07-02 21:03:42 --> Form Validation Class Initialized
DEBUG - 2019-07-02 21:03:42 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-02 21:03:42 --> Model Class Initialized
INFO - 2019-07-02 21:03:42 --> Model Class Initialized
ERROR - 2019-07-02 21:03:43 --> Query error: Unknown column 'order_details.order_status' in 'field list' - Invalid query: SELECT `orders`.*, `order_details`.`id` AS `order_details_id`, `order_details`.`qty`, `order_details`.`price`, `order_details`.`sub_total`, `order_details`.`order_status`, `order_details`.`product_id`, `order_details`.`created_at` AS `order_date`, `products`.`name`, CONCAT(`customers`.`firstname`, " ", `customers`.`lastname`) AS customer_fullname, `customers`.`address`, `customers`.`contact_number`, `customers`.`email`
FROM `orders`
LEFT JOIN `order_details` ON `order_details`.`order_id` = `orders`.`id`
LEFT JOIN `products` ON `products`.`id` = `order_details`.`product_id`
INNER JOIN `customers` as `customers` ON `customers`.`id` = `orders`.`customer_id`
WHERE `orders`.`customer_id` = '1'
AND `orders`.`resto_id` = '2'
AND `orders`.`order_status` = 'pending'
INFO - 2019-07-02 21:03:43 --> Language file loaded: language/english/db_lang.php
INFO - 2019-07-02 15:05:03 --> Config Class Initialized
INFO - 2019-07-02 15:05:03 --> Hooks Class Initialized
DEBUG - 2019-07-02 15:05:03 --> UTF-8 Support Enabled
INFO - 2019-07-02 15:05:03 --> Utf8 Class Initialized
INFO - 2019-07-02 15:05:03 --> URI Class Initialized
INFO - 2019-07-02 15:05:03 --> Router Class Initialized
INFO - 2019-07-02 15:05:03 --> Output Class Initialized
INFO - 2019-07-02 15:05:03 --> Security Class Initialized
DEBUG - 2019-07-02 15:05:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 15:05:03 --> Input Class Initialized
INFO - 2019-07-02 15:05:03 --> Language Class Initialized
INFO - 2019-07-02 15:05:03 --> Language Class Initialized
INFO - 2019-07-02 15:05:03 --> Config Class Initialized
INFO - 2019-07-02 15:05:03 --> Loader Class Initialized
DEBUG - 2019-07-02 15:05:03 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 15:05:03 --> Helper loaded: url_helper
INFO - 2019-07-02 15:05:03 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:05:03 --> Helper loaded: string_helper
INFO - 2019-07-02 15:05:03 --> Helper loaded: array_helper
INFO - 2019-07-02 15:05:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:05:03 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:05:03 --> Database Driver Class Initialized
INFO - 2019-07-02 15:05:03 --> Controller Class Initialized
INFO - 2019-07-02 21:05:03 --> Helper loaded: language_helper
INFO - 2019-07-02 21:05:03 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:05:03 --> Model Class Initialized
INFO - 2019-07-02 21:05:03 --> Model Class Initialized
INFO - 2019-07-02 21:05:03 --> Model Class Initialized
INFO - 2019-07-02 21:05:03 --> Model Class Initialized
INFO - 2019-07-02 21:05:03 --> Helper loaded: form_helper
INFO - 2019-07-02 21:05:03 --> Form Validation Class Initialized
DEBUG - 2019-07-02 21:05:03 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-02 21:05:03 --> Model Class Initialized
INFO - 2019-07-02 21:05:03 --> Model Class Initialized
ERROR - 2019-07-02 21:05:03 --> Query error: Unknown column 'order_details.order_status' in 'field list' - Invalid query: SELECT `orders`.*, `order_details`.`id` AS `order_details_id`, `order_details`.`qty`, `order_details`.`price`, `order_details`.`sub_total`, `order_details`.`order_status`, `order_details`.`product_id`, `order_details`.`created_at` AS `order_date`, `products`.`name`, CONCAT(`customers`.`firstname`, " ", `customers`.`lastname`) AS customer_fullname, `customers`.`address`, `customers`.`contact_number`, `customers`.`email`
FROM `orders`
LEFT JOIN `order_details` ON `order_details`.`order_id` = `orders`.`id`
LEFT JOIN `products` ON `products`.`id` = `order_details`.`product_id`
INNER JOIN `customers` as `customers` ON `customers`.`id` = `orders`.`customer_id`
WHERE `orders`.`customer_id` = '1'
AND `orders`.`resto_id` = '2'
AND `orders`.`order_status` = 'pending'
INFO - 2019-07-02 21:05:03 --> Language file loaded: language/english/db_lang.php
INFO - 2019-07-02 15:06:35 --> Config Class Initialized
INFO - 2019-07-02 15:06:35 --> Hooks Class Initialized
DEBUG - 2019-07-02 15:06:35 --> UTF-8 Support Enabled
INFO - 2019-07-02 15:06:35 --> Utf8 Class Initialized
INFO - 2019-07-02 15:06:35 --> URI Class Initialized
INFO - 2019-07-02 15:06:35 --> Router Class Initialized
INFO - 2019-07-02 15:06:35 --> Output Class Initialized
INFO - 2019-07-02 15:06:35 --> Security Class Initialized
DEBUG - 2019-07-02 15:06:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 15:06:35 --> Input Class Initialized
INFO - 2019-07-02 15:06:35 --> Language Class Initialized
INFO - 2019-07-02 15:06:35 --> Language Class Initialized
INFO - 2019-07-02 15:06:35 --> Config Class Initialized
INFO - 2019-07-02 15:06:35 --> Loader Class Initialized
DEBUG - 2019-07-02 15:06:35 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 15:06:35 --> Helper loaded: url_helper
INFO - 2019-07-02 15:06:35 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:06:36 --> Helper loaded: string_helper
INFO - 2019-07-02 15:06:36 --> Helper loaded: array_helper
INFO - 2019-07-02 15:06:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:06:36 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:06:36 --> Database Driver Class Initialized
INFO - 2019-07-02 15:06:36 --> Controller Class Initialized
INFO - 2019-07-02 21:06:36 --> Helper loaded: language_helper
INFO - 2019-07-02 21:06:36 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:06:36 --> Model Class Initialized
INFO - 2019-07-02 21:06:36 --> Model Class Initialized
INFO - 2019-07-02 21:06:36 --> Model Class Initialized
INFO - 2019-07-02 21:06:36 --> Model Class Initialized
INFO - 2019-07-02 21:06:36 --> Helper loaded: form_helper
INFO - 2019-07-02 21:06:36 --> Form Validation Class Initialized
DEBUG - 2019-07-02 21:06:36 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-02 21:06:36 --> Model Class Initialized
INFO - 2019-07-02 21:06:36 --> Model Class Initialized
INFO - 2019-07-02 21:06:36 --> Final output sent to browser
DEBUG - 2019-07-02 21:06:36 --> Total execution time: 0.5310
INFO - 2019-07-02 15:06:40 --> Config Class Initialized
INFO - 2019-07-02 15:06:40 --> Hooks Class Initialized
DEBUG - 2019-07-02 15:06:40 --> UTF-8 Support Enabled
INFO - 2019-07-02 15:06:40 --> Utf8 Class Initialized
INFO - 2019-07-02 15:06:40 --> URI Class Initialized
INFO - 2019-07-02 15:06:40 --> Router Class Initialized
INFO - 2019-07-02 15:06:40 --> Output Class Initialized
INFO - 2019-07-02 15:06:40 --> Security Class Initialized
DEBUG - 2019-07-02 15:06:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 15:06:40 --> Input Class Initialized
INFO - 2019-07-02 15:06:40 --> Language Class Initialized
INFO - 2019-07-02 15:06:40 --> Language Class Initialized
INFO - 2019-07-02 15:06:40 --> Config Class Initialized
INFO - 2019-07-02 15:06:40 --> Loader Class Initialized
DEBUG - 2019-07-02 15:06:40 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 15:06:40 --> Helper loaded: url_helper
INFO - 2019-07-02 15:06:40 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:06:40 --> Helper loaded: string_helper
INFO - 2019-07-02 15:06:40 --> Helper loaded: array_helper
INFO - 2019-07-02 15:06:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:06:40 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:06:40 --> Database Driver Class Initialized
INFO - 2019-07-02 15:06:40 --> Controller Class Initialized
INFO - 2019-07-02 21:06:40 --> Helper loaded: language_helper
INFO - 2019-07-02 21:06:40 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:06:40 --> Model Class Initialized
INFO - 2019-07-02 21:06:40 --> Model Class Initialized
INFO - 2019-07-02 21:06:40 --> Model Class Initialized
INFO - 2019-07-02 21:06:40 --> Model Class Initialized
INFO - 2019-07-02 21:06:40 --> Model Class Initialized
INFO - 2019-07-02 21:06:40 --> Final output sent to browser
DEBUG - 2019-07-02 21:06:40 --> Total execution time: 0.3309
INFO - 2019-07-02 15:06:43 --> Config Class Initialized
INFO - 2019-07-02 15:06:43 --> Hooks Class Initialized
DEBUG - 2019-07-02 15:06:43 --> UTF-8 Support Enabled
INFO - 2019-07-02 15:06:43 --> Utf8 Class Initialized
INFO - 2019-07-02 15:06:43 --> URI Class Initialized
INFO - 2019-07-02 15:06:43 --> Router Class Initialized
INFO - 2019-07-02 15:06:43 --> Output Class Initialized
INFO - 2019-07-02 15:06:43 --> Security Class Initialized
DEBUG - 2019-07-02 15:06:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 15:06:43 --> Input Class Initialized
INFO - 2019-07-02 15:06:43 --> Language Class Initialized
INFO - 2019-07-02 15:06:43 --> Language Class Initialized
INFO - 2019-07-02 15:06:43 --> Config Class Initialized
INFO - 2019-07-02 15:06:43 --> Loader Class Initialized
DEBUG - 2019-07-02 15:06:43 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 15:06:43 --> Helper loaded: url_helper
INFO - 2019-07-02 15:06:43 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:06:43 --> Helper loaded: string_helper
INFO - 2019-07-02 15:06:43 --> Helper loaded: array_helper
INFO - 2019-07-02 15:06:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:06:43 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:06:43 --> Database Driver Class Initialized
INFO - 2019-07-02 15:06:43 --> Controller Class Initialized
INFO - 2019-07-02 21:06:43 --> Helper loaded: language_helper
INFO - 2019-07-02 21:06:43 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:06:43 --> Model Class Initialized
INFO - 2019-07-02 21:06:43 --> Model Class Initialized
INFO - 2019-07-02 21:06:43 --> Model Class Initialized
INFO - 2019-07-02 21:06:43 --> Model Class Initialized
INFO - 2019-07-02 21:06:43 --> Helper loaded: form_helper
INFO - 2019-07-02 21:06:43 --> Form Validation Class Initialized
DEBUG - 2019-07-02 21:06:43 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-02 21:06:43 --> Model Class Initialized
INFO - 2019-07-02 21:06:43 --> Model Class Initialized
ERROR - 2019-07-02 21:06:43 --> Query error: Column 'resto_id' in where clause is ambiguous - Invalid query: SELECT `orders`.*, `order_details`.`id` AS `order_details_id`, `order_details`.`qty`, `order_details`.`price`, `order_details`.`sub_total`, `order_details`.`order_status`, `order_details`.`product_id`, `order_details`.`created_at` AS `order_date`, `products`.`name`, CONCAT(`customers`.`firstname`, " ", `customers`.`lastname`) AS customer_fullname, `customers`.`address`, `customers`.`contact_number`, `customers`.`email`
FROM `orders`
LEFT JOIN `order_details` ON `order_details`.`order_id` = `orders`.`id`
LEFT JOIN `products` ON `products`.`id` = `order_details`.`product_id`
INNER JOIN `customers` as `customers` ON `customers`.`id` = `orders`.`customer_id`
WHERE `resto_id` = '2'
AND `customer_id` = '1'
AND `order_status` = 'pending'
INFO - 2019-07-02 21:06:43 --> Language file loaded: language/english/db_lang.php
INFO - 2019-07-02 15:06:43 --> Config Class Initialized
INFO - 2019-07-02 15:06:43 --> Hooks Class Initialized
DEBUG - 2019-07-02 15:06:43 --> UTF-8 Support Enabled
INFO - 2019-07-02 15:06:43 --> Utf8 Class Initialized
INFO - 2019-07-02 15:06:43 --> URI Class Initialized
INFO - 2019-07-02 15:06:43 --> Router Class Initialized
INFO - 2019-07-02 15:06:43 --> Output Class Initialized
INFO - 2019-07-02 15:06:43 --> Security Class Initialized
DEBUG - 2019-07-02 15:06:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 15:06:43 --> Input Class Initialized
INFO - 2019-07-02 15:06:43 --> Language Class Initialized
INFO - 2019-07-02 15:06:43 --> Language Class Initialized
INFO - 2019-07-02 15:06:43 --> Config Class Initialized
INFO - 2019-07-02 15:06:43 --> Loader Class Initialized
DEBUG - 2019-07-02 15:06:43 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 15:06:43 --> Helper loaded: url_helper
INFO - 2019-07-02 15:06:43 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:06:43 --> Helper loaded: string_helper
INFO - 2019-07-02 15:06:43 --> Helper loaded: array_helper
INFO - 2019-07-02 15:06:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:06:43 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:06:43 --> Database Driver Class Initialized
INFO - 2019-07-02 15:06:43 --> Controller Class Initialized
INFO - 2019-07-02 21:06:43 --> Helper loaded: language_helper
INFO - 2019-07-02 21:06:43 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:06:43 --> Model Class Initialized
INFO - 2019-07-02 21:06:43 --> Model Class Initialized
INFO - 2019-07-02 21:06:43 --> Model Class Initialized
INFO - 2019-07-02 21:06:43 --> Model Class Initialized
INFO - 2019-07-02 21:06:43 --> Helper loaded: form_helper
INFO - 2019-07-02 21:06:43 --> Form Validation Class Initialized
DEBUG - 2019-07-02 21:06:43 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-02 21:06:43 --> Model Class Initialized
INFO - 2019-07-02 21:06:43 --> Model Class Initialized
INFO - 2019-07-02 21:06:43 --> Final output sent to browser
DEBUG - 2019-07-02 21:06:43 --> Total execution time: 0.3703
INFO - 2019-07-02 15:08:06 --> Config Class Initialized
INFO - 2019-07-02 15:08:06 --> Hooks Class Initialized
DEBUG - 2019-07-02 15:08:06 --> UTF-8 Support Enabled
INFO - 2019-07-02 15:08:06 --> Utf8 Class Initialized
INFO - 2019-07-02 15:08:06 --> URI Class Initialized
INFO - 2019-07-02 15:08:06 --> Router Class Initialized
INFO - 2019-07-02 15:08:06 --> Output Class Initialized
INFO - 2019-07-02 15:08:06 --> Security Class Initialized
DEBUG - 2019-07-02 15:08:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 15:08:06 --> Input Class Initialized
INFO - 2019-07-02 15:08:06 --> Language Class Initialized
INFO - 2019-07-02 15:08:06 --> Language Class Initialized
INFO - 2019-07-02 15:08:06 --> Config Class Initialized
INFO - 2019-07-02 15:08:06 --> Loader Class Initialized
DEBUG - 2019-07-02 15:08:06 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 15:08:06 --> Helper loaded: url_helper
INFO - 2019-07-02 15:08:07 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:08:07 --> Helper loaded: string_helper
INFO - 2019-07-02 15:08:07 --> Helper loaded: array_helper
INFO - 2019-07-02 15:08:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:08:07 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:08:07 --> Database Driver Class Initialized
INFO - 2019-07-02 15:08:07 --> Controller Class Initialized
INFO - 2019-07-02 21:08:07 --> Helper loaded: language_helper
INFO - 2019-07-02 21:08:07 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:08:07 --> Model Class Initialized
INFO - 2019-07-02 21:08:07 --> Model Class Initialized
INFO - 2019-07-02 21:08:07 --> Model Class Initialized
INFO - 2019-07-02 21:08:07 --> Model Class Initialized
INFO - 2019-07-02 21:08:07 --> Helper loaded: form_helper
INFO - 2019-07-02 21:08:07 --> Form Validation Class Initialized
DEBUG - 2019-07-02 21:08:07 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-02 21:08:07 --> Model Class Initialized
INFO - 2019-07-02 21:08:07 --> Model Class Initialized
INFO - 2019-07-02 21:08:07 --> Final output sent to browser
DEBUG - 2019-07-02 21:08:07 --> Total execution time: 0.5045
INFO - 2019-07-02 15:08:07 --> Config Class Initialized
INFO - 2019-07-02 15:08:07 --> Hooks Class Initialized
DEBUG - 2019-07-02 15:08:07 --> UTF-8 Support Enabled
INFO - 2019-07-02 15:08:07 --> Utf8 Class Initialized
INFO - 2019-07-02 15:08:07 --> URI Class Initialized
INFO - 2019-07-02 15:08:07 --> Router Class Initialized
INFO - 2019-07-02 15:08:07 --> Output Class Initialized
INFO - 2019-07-02 15:08:07 --> Security Class Initialized
DEBUG - 2019-07-02 15:08:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 15:08:07 --> Input Class Initialized
INFO - 2019-07-02 15:08:07 --> Language Class Initialized
INFO - 2019-07-02 15:08:07 --> Language Class Initialized
INFO - 2019-07-02 15:08:07 --> Config Class Initialized
INFO - 2019-07-02 15:08:07 --> Loader Class Initialized
DEBUG - 2019-07-02 15:08:07 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 15:08:07 --> Helper loaded: url_helper
INFO - 2019-07-02 15:08:07 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:08:07 --> Helper loaded: string_helper
INFO - 2019-07-02 15:08:07 --> Helper loaded: array_helper
INFO - 2019-07-02 15:08:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:08:07 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:08:07 --> Database Driver Class Initialized
INFO - 2019-07-02 15:08:07 --> Controller Class Initialized
INFO - 2019-07-02 21:08:08 --> Helper loaded: language_helper
INFO - 2019-07-02 21:08:08 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:08:08 --> Model Class Initialized
INFO - 2019-07-02 21:08:08 --> Model Class Initialized
INFO - 2019-07-02 21:08:08 --> Model Class Initialized
INFO - 2019-07-02 21:08:08 --> Model Class Initialized
INFO - 2019-07-02 21:08:08 --> Model Class Initialized
INFO - 2019-07-02 21:08:08 --> Final output sent to browser
DEBUG - 2019-07-02 21:08:08 --> Total execution time: 0.3554
INFO - 2019-07-02 15:08:10 --> Config Class Initialized
INFO - 2019-07-02 15:08:10 --> Hooks Class Initialized
DEBUG - 2019-07-02 15:08:10 --> UTF-8 Support Enabled
INFO - 2019-07-02 15:08:10 --> Utf8 Class Initialized
INFO - 2019-07-02 15:08:10 --> URI Class Initialized
INFO - 2019-07-02 15:08:10 --> Router Class Initialized
INFO - 2019-07-02 15:08:10 --> Output Class Initialized
INFO - 2019-07-02 15:08:10 --> Security Class Initialized
DEBUG - 2019-07-02 15:08:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 15:08:10 --> Input Class Initialized
INFO - 2019-07-02 15:08:10 --> Language Class Initialized
INFO - 2019-07-02 15:08:10 --> Language Class Initialized
INFO - 2019-07-02 15:08:10 --> Config Class Initialized
INFO - 2019-07-02 15:08:10 --> Loader Class Initialized
DEBUG - 2019-07-02 15:08:10 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 15:08:10 --> Helper loaded: url_helper
INFO - 2019-07-02 15:08:10 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:08:10 --> Helper loaded: string_helper
INFO - 2019-07-02 15:08:10 --> Helper loaded: array_helper
INFO - 2019-07-02 15:08:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:08:10 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:08:10 --> Database Driver Class Initialized
INFO - 2019-07-02 15:08:10 --> Controller Class Initialized
INFO - 2019-07-02 21:08:10 --> Helper loaded: language_helper
INFO - 2019-07-02 21:08:10 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:08:10 --> Model Class Initialized
INFO - 2019-07-02 21:08:11 --> Model Class Initialized
INFO - 2019-07-02 21:08:11 --> Model Class Initialized
INFO - 2019-07-02 21:08:11 --> Model Class Initialized
INFO - 2019-07-02 21:08:11 --> Helper loaded: form_helper
INFO - 2019-07-02 21:08:11 --> Form Validation Class Initialized
DEBUG - 2019-07-02 21:08:11 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-02 21:08:11 --> Model Class Initialized
INFO - 2019-07-02 21:08:11 --> Model Class Initialized
ERROR - 2019-07-02 21:08:11 --> Query error: Column 'resto_id' in where clause is ambiguous - Invalid query: SELECT `orders`.*, `order_details`.`id` AS `order_details_id`, `order_details`.`qty`, `order_details`.`price`, `order_details`.`sub_total`, `order_details`.`order_status`, `order_details`.`product_id`, `order_details`.`created_at` AS `order_date`, `products`.`name`, CONCAT(`customers`.`firstname`, " ", `customers`.`lastname`) AS customer_fullname, `customers`.`address`, `customers`.`contact_number`, `customers`.`email`
FROM `orders`
LEFT JOIN `order_details` ON `order_details`.`order_id` = `orders`.`id`
LEFT JOIN `products` ON `products`.`id` = `order_details`.`product_id`
INNER JOIN `customers` as `customers` ON `customers`.`id` = `orders`.`customer_id`
WHERE `resto_id` = '2'
AND `customer_id` = '1'
AND `order_status` = 'pending'
INFO - 2019-07-02 21:08:11 --> Language file loaded: language/english/db_lang.php
INFO - 2019-07-02 15:08:11 --> Config Class Initialized
INFO - 2019-07-02 15:08:11 --> Hooks Class Initialized
DEBUG - 2019-07-02 15:08:11 --> UTF-8 Support Enabled
INFO - 2019-07-02 15:08:11 --> Utf8 Class Initialized
INFO - 2019-07-02 15:08:11 --> URI Class Initialized
INFO - 2019-07-02 15:08:11 --> Router Class Initialized
INFO - 2019-07-02 15:08:11 --> Output Class Initialized
INFO - 2019-07-02 15:08:11 --> Security Class Initialized
DEBUG - 2019-07-02 15:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 15:08:11 --> Input Class Initialized
INFO - 2019-07-02 15:08:11 --> Language Class Initialized
INFO - 2019-07-02 15:08:11 --> Language Class Initialized
INFO - 2019-07-02 15:08:11 --> Config Class Initialized
INFO - 2019-07-02 15:08:11 --> Loader Class Initialized
DEBUG - 2019-07-02 15:08:11 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 15:08:11 --> Helper loaded: url_helper
INFO - 2019-07-02 15:08:11 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:08:11 --> Helper loaded: string_helper
INFO - 2019-07-02 15:08:11 --> Helper loaded: array_helper
INFO - 2019-07-02 15:08:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:08:11 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:08:11 --> Database Driver Class Initialized
INFO - 2019-07-02 15:08:11 --> Controller Class Initialized
INFO - 2019-07-02 21:08:11 --> Helper loaded: language_helper
INFO - 2019-07-02 21:08:11 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:08:11 --> Model Class Initialized
INFO - 2019-07-02 21:08:11 --> Model Class Initialized
INFO - 2019-07-02 21:08:11 --> Model Class Initialized
INFO - 2019-07-02 21:08:11 --> Model Class Initialized
INFO - 2019-07-02 21:08:11 --> Helper loaded: form_helper
INFO - 2019-07-02 21:08:11 --> Form Validation Class Initialized
DEBUG - 2019-07-02 21:08:11 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-02 21:08:11 --> Model Class Initialized
INFO - 2019-07-02 21:08:11 --> Model Class Initialized
INFO - 2019-07-02 21:08:11 --> Final output sent to browser
DEBUG - 2019-07-02 21:08:11 --> Total execution time: 0.3862
INFO - 2019-07-02 15:09:01 --> Config Class Initialized
INFO - 2019-07-02 15:09:01 --> Hooks Class Initialized
DEBUG - 2019-07-02 15:09:01 --> UTF-8 Support Enabled
INFO - 2019-07-02 15:09:01 --> Utf8 Class Initialized
INFO - 2019-07-02 15:09:01 --> URI Class Initialized
INFO - 2019-07-02 15:09:01 --> Router Class Initialized
INFO - 2019-07-02 15:09:01 --> Output Class Initialized
INFO - 2019-07-02 15:09:01 --> Security Class Initialized
DEBUG - 2019-07-02 15:09:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 15:09:01 --> Input Class Initialized
INFO - 2019-07-02 15:09:01 --> Language Class Initialized
INFO - 2019-07-02 15:09:01 --> Language Class Initialized
INFO - 2019-07-02 15:09:01 --> Config Class Initialized
INFO - 2019-07-02 15:09:01 --> Loader Class Initialized
DEBUG - 2019-07-02 15:09:01 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 15:09:01 --> Helper loaded: url_helper
INFO - 2019-07-02 15:09:01 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:09:01 --> Helper loaded: string_helper
INFO - 2019-07-02 15:09:01 --> Helper loaded: array_helper
INFO - 2019-07-02 15:09:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:09:01 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:09:01 --> Database Driver Class Initialized
INFO - 2019-07-02 15:09:01 --> Controller Class Initialized
INFO - 2019-07-02 21:09:01 --> Helper loaded: language_helper
INFO - 2019-07-02 21:09:01 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:09:01 --> Model Class Initialized
INFO - 2019-07-02 21:09:01 --> Model Class Initialized
INFO - 2019-07-02 21:09:01 --> Model Class Initialized
INFO - 2019-07-02 21:09:01 --> Model Class Initialized
INFO - 2019-07-02 21:09:01 --> Helper loaded: form_helper
INFO - 2019-07-02 21:09:01 --> Form Validation Class Initialized
DEBUG - 2019-07-02 21:09:01 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-02 21:09:01 --> Model Class Initialized
INFO - 2019-07-02 21:09:01 --> Model Class Initialized
INFO - 2019-07-02 21:09:01 --> Final output sent to browser
DEBUG - 2019-07-02 21:09:01 --> Total execution time: 0.4790
INFO - 2019-07-02 15:09:03 --> Config Class Initialized
INFO - 2019-07-02 15:09:03 --> Hooks Class Initialized
DEBUG - 2019-07-02 15:09:03 --> UTF-8 Support Enabled
INFO - 2019-07-02 15:09:03 --> Utf8 Class Initialized
INFO - 2019-07-02 15:09:03 --> URI Class Initialized
INFO - 2019-07-02 15:09:03 --> Router Class Initialized
INFO - 2019-07-02 15:09:03 --> Output Class Initialized
INFO - 2019-07-02 15:09:03 --> Security Class Initialized
DEBUG - 2019-07-02 15:09:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 15:09:03 --> Input Class Initialized
INFO - 2019-07-02 15:09:03 --> Language Class Initialized
INFO - 2019-07-02 15:09:03 --> Language Class Initialized
INFO - 2019-07-02 15:09:03 --> Config Class Initialized
INFO - 2019-07-02 15:09:03 --> Loader Class Initialized
DEBUG - 2019-07-02 15:09:03 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 15:09:03 --> Helper loaded: url_helper
INFO - 2019-07-02 15:09:03 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:09:03 --> Helper loaded: string_helper
INFO - 2019-07-02 15:09:03 --> Helper loaded: array_helper
INFO - 2019-07-02 15:09:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:09:03 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:09:03 --> Database Driver Class Initialized
INFO - 2019-07-02 15:09:03 --> Controller Class Initialized
INFO - 2019-07-02 21:09:03 --> Helper loaded: language_helper
INFO - 2019-07-02 21:09:03 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:09:03 --> Model Class Initialized
INFO - 2019-07-02 21:09:03 --> Model Class Initialized
INFO - 2019-07-02 21:09:03 --> Model Class Initialized
INFO - 2019-07-02 21:09:03 --> Model Class Initialized
INFO - 2019-07-02 21:09:03 --> Model Class Initialized
INFO - 2019-07-02 21:09:03 --> Final output sent to browser
DEBUG - 2019-07-02 21:09:03 --> Total execution time: 0.3438
INFO - 2019-07-02 15:09:05 --> Config Class Initialized
INFO - 2019-07-02 15:09:05 --> Hooks Class Initialized
DEBUG - 2019-07-02 15:09:05 --> UTF-8 Support Enabled
INFO - 2019-07-02 15:09:05 --> Utf8 Class Initialized
INFO - 2019-07-02 15:09:05 --> URI Class Initialized
INFO - 2019-07-02 15:09:05 --> Router Class Initialized
INFO - 2019-07-02 15:09:05 --> Output Class Initialized
INFO - 2019-07-02 15:09:05 --> Security Class Initialized
DEBUG - 2019-07-02 15:09:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 15:09:06 --> Input Class Initialized
INFO - 2019-07-02 15:09:06 --> Language Class Initialized
INFO - 2019-07-02 15:09:06 --> Language Class Initialized
INFO - 2019-07-02 15:09:06 --> Config Class Initialized
INFO - 2019-07-02 15:09:06 --> Loader Class Initialized
DEBUG - 2019-07-02 15:09:06 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 15:09:06 --> Helper loaded: url_helper
INFO - 2019-07-02 15:09:06 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:09:06 --> Helper loaded: string_helper
INFO - 2019-07-02 15:09:06 --> Helper loaded: array_helper
INFO - 2019-07-02 15:09:06 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:09:06 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:09:06 --> Database Driver Class Initialized
INFO - 2019-07-02 15:09:06 --> Controller Class Initialized
INFO - 2019-07-02 21:09:06 --> Helper loaded: language_helper
INFO - 2019-07-02 21:09:06 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:09:06 --> Model Class Initialized
INFO - 2019-07-02 21:09:06 --> Model Class Initialized
INFO - 2019-07-02 21:09:06 --> Model Class Initialized
INFO - 2019-07-02 21:09:06 --> Model Class Initialized
INFO - 2019-07-02 21:09:06 --> Helper loaded: form_helper
INFO - 2019-07-02 21:09:06 --> Form Validation Class Initialized
DEBUG - 2019-07-02 21:09:06 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-02 21:09:06 --> Model Class Initialized
INFO - 2019-07-02 21:09:06 --> Model Class Initialized
ERROR - 2019-07-02 21:09:06 --> Query error: Unknown column 'orders.order_number' in 'field list' - Invalid query: INSERT INTO `orders` (`orders`.`customer_id`, `orders`.`resto_id`, `orders`.`order_number`, `created_at`, `updated_at`) VALUES ('1', '2', '11562072946', '2019-07-02 21:09:06', '2019-07-02 21:09:06')
INFO - 2019-07-02 21:09:06 --> Language file loaded: language/english/db_lang.php
INFO - 2019-07-02 15:09:06 --> Config Class Initialized
INFO - 2019-07-02 15:09:06 --> Hooks Class Initialized
DEBUG - 2019-07-02 15:09:06 --> UTF-8 Support Enabled
INFO - 2019-07-02 15:09:06 --> Utf8 Class Initialized
INFO - 2019-07-02 15:09:06 --> URI Class Initialized
INFO - 2019-07-02 15:09:06 --> Router Class Initialized
INFO - 2019-07-02 15:09:06 --> Output Class Initialized
INFO - 2019-07-02 15:09:06 --> Security Class Initialized
DEBUG - 2019-07-02 15:09:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 15:09:06 --> Input Class Initialized
INFO - 2019-07-02 15:09:06 --> Language Class Initialized
INFO - 2019-07-02 15:09:06 --> Language Class Initialized
INFO - 2019-07-02 15:09:06 --> Config Class Initialized
INFO - 2019-07-02 15:09:06 --> Loader Class Initialized
DEBUG - 2019-07-02 15:09:06 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 15:09:06 --> Helper loaded: url_helper
INFO - 2019-07-02 15:09:06 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:09:06 --> Helper loaded: string_helper
INFO - 2019-07-02 15:09:06 --> Helper loaded: array_helper
INFO - 2019-07-02 15:09:06 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:09:06 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:09:06 --> Database Driver Class Initialized
INFO - 2019-07-02 15:09:06 --> Controller Class Initialized
INFO - 2019-07-02 21:09:06 --> Helper loaded: language_helper
INFO - 2019-07-02 21:09:06 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:09:06 --> Model Class Initialized
INFO - 2019-07-02 21:09:06 --> Model Class Initialized
INFO - 2019-07-02 21:09:06 --> Model Class Initialized
INFO - 2019-07-02 21:09:06 --> Model Class Initialized
INFO - 2019-07-02 21:09:06 --> Helper loaded: form_helper
INFO - 2019-07-02 21:09:06 --> Form Validation Class Initialized
DEBUG - 2019-07-02 21:09:06 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-02 21:09:06 --> Model Class Initialized
INFO - 2019-07-02 21:09:06 --> Model Class Initialized
INFO - 2019-07-02 21:09:06 --> Final output sent to browser
DEBUG - 2019-07-02 21:09:06 --> Total execution time: 0.4163
INFO - 2019-07-02 15:09:59 --> Config Class Initialized
INFO - 2019-07-02 15:09:59 --> Hooks Class Initialized
DEBUG - 2019-07-02 15:09:59 --> UTF-8 Support Enabled
INFO - 2019-07-02 15:09:59 --> Utf8 Class Initialized
INFO - 2019-07-02 15:09:59 --> URI Class Initialized
INFO - 2019-07-02 15:09:59 --> Router Class Initialized
INFO - 2019-07-02 15:09:59 --> Output Class Initialized
INFO - 2019-07-02 15:09:59 --> Security Class Initialized
DEBUG - 2019-07-02 15:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 15:09:59 --> Input Class Initialized
INFO - 2019-07-02 15:09:59 --> Language Class Initialized
INFO - 2019-07-02 15:09:59 --> Language Class Initialized
INFO - 2019-07-02 15:09:59 --> Config Class Initialized
INFO - 2019-07-02 15:09:59 --> Loader Class Initialized
DEBUG - 2019-07-02 15:09:59 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 15:09:59 --> Helper loaded: url_helper
INFO - 2019-07-02 15:09:59 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:09:59 --> Helper loaded: string_helper
INFO - 2019-07-02 15:09:59 --> Helper loaded: array_helper
INFO - 2019-07-02 15:09:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:09:59 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:09:59 --> Database Driver Class Initialized
INFO - 2019-07-02 15:09:59 --> Controller Class Initialized
INFO - 2019-07-02 21:09:59 --> Helper loaded: language_helper
INFO - 2019-07-02 21:09:59 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:09:59 --> Model Class Initialized
INFO - 2019-07-02 21:09:59 --> Model Class Initialized
INFO - 2019-07-02 21:09:59 --> Model Class Initialized
INFO - 2019-07-02 21:09:59 --> Model Class Initialized
INFO - 2019-07-02 21:09:59 --> Helper loaded: form_helper
INFO - 2019-07-02 21:09:59 --> Form Validation Class Initialized
DEBUG - 2019-07-02 21:09:59 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-02 21:09:59 --> Model Class Initialized
INFO - 2019-07-02 21:09:59 --> Model Class Initialized
ERROR - 2019-07-02 21:09:59 --> Query error: Unknown column 'resto_id' in 'field list' - Invalid query: INSERT INTO `order_details` (`order_id`, `resto_id`, `product_id`, `qty`, `price`, `sub_total`, `description_request`, `created_at`, `updated_at`) VALUES (1, '2', '', '1', '30', 30, '', '2019-07-02 21:09:59', '2019-07-02 21:09:59')
INFO - 2019-07-02 21:09:59 --> Language file loaded: language/english/db_lang.php
INFO - 2019-07-02 15:09:59 --> Config Class Initialized
INFO - 2019-07-02 15:09:59 --> Hooks Class Initialized
DEBUG - 2019-07-02 15:09:59 --> UTF-8 Support Enabled
INFO - 2019-07-02 15:09:59 --> Utf8 Class Initialized
INFO - 2019-07-02 15:09:59 --> URI Class Initialized
INFO - 2019-07-02 15:09:59 --> Router Class Initialized
INFO - 2019-07-02 15:09:59 --> Output Class Initialized
INFO - 2019-07-02 15:09:59 --> Security Class Initialized
DEBUG - 2019-07-02 15:09:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 15:09:59 --> Input Class Initialized
INFO - 2019-07-02 15:09:59 --> Language Class Initialized
INFO - 2019-07-02 15:09:59 --> Language Class Initialized
INFO - 2019-07-02 15:09:59 --> Config Class Initialized
INFO - 2019-07-02 15:09:59 --> Loader Class Initialized
DEBUG - 2019-07-02 15:09:59 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 15:09:59 --> Helper loaded: url_helper
INFO - 2019-07-02 15:09:59 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:09:59 --> Helper loaded: string_helper
INFO - 2019-07-02 15:10:00 --> Helper loaded: array_helper
INFO - 2019-07-02 15:10:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:10:00 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:10:00 --> Database Driver Class Initialized
INFO - 2019-07-02 15:10:00 --> Controller Class Initialized
INFO - 2019-07-02 21:10:00 --> Helper loaded: language_helper
INFO - 2019-07-02 21:10:00 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:10:00 --> Model Class Initialized
INFO - 2019-07-02 21:10:00 --> Model Class Initialized
INFO - 2019-07-02 21:10:00 --> Model Class Initialized
INFO - 2019-07-02 21:10:00 --> Model Class Initialized
INFO - 2019-07-02 21:10:00 --> Helper loaded: form_helper
INFO - 2019-07-02 21:10:00 --> Form Validation Class Initialized
DEBUG - 2019-07-02 21:10:00 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-02 21:10:00 --> Model Class Initialized
INFO - 2019-07-02 21:10:00 --> Model Class Initialized
INFO - 2019-07-02 21:10:00 --> Final output sent to browser
DEBUG - 2019-07-02 21:10:00 --> Total execution time: 0.4039
INFO - 2019-07-02 15:12:08 --> Config Class Initialized
INFO - 2019-07-02 15:12:08 --> Hooks Class Initialized
DEBUG - 2019-07-02 15:12:08 --> UTF-8 Support Enabled
INFO - 2019-07-02 15:12:08 --> Utf8 Class Initialized
INFO - 2019-07-02 15:12:08 --> URI Class Initialized
INFO - 2019-07-02 15:12:08 --> Router Class Initialized
INFO - 2019-07-02 15:12:08 --> Output Class Initialized
INFO - 2019-07-02 15:12:08 --> Security Class Initialized
DEBUG - 2019-07-02 15:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 15:12:08 --> Input Class Initialized
INFO - 2019-07-02 15:12:08 --> Language Class Initialized
INFO - 2019-07-02 15:12:08 --> Language Class Initialized
INFO - 2019-07-02 15:12:08 --> Config Class Initialized
INFO - 2019-07-02 15:12:08 --> Loader Class Initialized
DEBUG - 2019-07-02 15:12:08 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 15:12:08 --> Helper loaded: url_helper
INFO - 2019-07-02 15:12:08 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:12:08 --> Helper loaded: string_helper
INFO - 2019-07-02 15:12:08 --> Helper loaded: array_helper
INFO - 2019-07-02 15:12:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:12:08 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:12:08 --> Database Driver Class Initialized
INFO - 2019-07-02 15:12:08 --> Controller Class Initialized
INFO - 2019-07-02 21:12:08 --> Helper loaded: language_helper
INFO - 2019-07-02 21:12:08 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:12:08 --> Model Class Initialized
INFO - 2019-07-02 21:12:09 --> Model Class Initialized
INFO - 2019-07-02 21:12:09 --> Model Class Initialized
INFO - 2019-07-02 21:12:09 --> Model Class Initialized
INFO - 2019-07-02 21:12:09 --> Helper loaded: form_helper
INFO - 2019-07-02 21:12:09 --> Form Validation Class Initialized
DEBUG - 2019-07-02 21:12:09 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-02 21:12:09 --> Model Class Initialized
INFO - 2019-07-02 21:12:09 --> Model Class Initialized
INFO - 2019-07-02 21:12:09 --> Final output sent to browser
DEBUG - 2019-07-02 21:12:09 --> Total execution time: 0.5137
INFO - 2019-07-02 15:12:13 --> Config Class Initialized
INFO - 2019-07-02 15:12:13 --> Hooks Class Initialized
DEBUG - 2019-07-02 15:12:13 --> UTF-8 Support Enabled
INFO - 2019-07-02 15:12:13 --> Utf8 Class Initialized
INFO - 2019-07-02 15:12:13 --> URI Class Initialized
INFO - 2019-07-02 15:12:13 --> Router Class Initialized
INFO - 2019-07-02 15:12:13 --> Output Class Initialized
INFO - 2019-07-02 15:12:13 --> Security Class Initialized
DEBUG - 2019-07-02 15:12:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 15:12:13 --> Input Class Initialized
INFO - 2019-07-02 15:12:13 --> Language Class Initialized
INFO - 2019-07-02 15:12:13 --> Language Class Initialized
INFO - 2019-07-02 15:12:13 --> Config Class Initialized
INFO - 2019-07-02 15:12:13 --> Loader Class Initialized
DEBUG - 2019-07-02 15:12:13 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 15:12:13 --> Helper loaded: url_helper
INFO - 2019-07-02 15:12:13 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:12:13 --> Helper loaded: string_helper
INFO - 2019-07-02 15:12:13 --> Helper loaded: array_helper
INFO - 2019-07-02 15:12:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:12:13 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:12:13 --> Database Driver Class Initialized
INFO - 2019-07-02 15:12:13 --> Controller Class Initialized
INFO - 2019-07-02 21:12:13 --> Helper loaded: language_helper
INFO - 2019-07-02 21:12:13 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:12:13 --> Model Class Initialized
INFO - 2019-07-02 21:12:13 --> Model Class Initialized
INFO - 2019-07-02 21:12:13 --> Model Class Initialized
INFO - 2019-07-02 21:12:13 --> Model Class Initialized
INFO - 2019-07-02 21:12:14 --> Helper loaded: form_helper
INFO - 2019-07-02 21:12:14 --> Form Validation Class Initialized
DEBUG - 2019-07-02 21:12:14 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-02 21:12:14 --> Model Class Initialized
INFO - 2019-07-02 21:12:14 --> Model Class Initialized
INFO - 2019-07-02 21:12:14 --> Final output sent to browser
DEBUG - 2019-07-02 21:12:14 --> Total execution time: 0.4028
INFO - 2019-07-02 15:12:14 --> Config Class Initialized
INFO - 2019-07-02 15:12:14 --> Hooks Class Initialized
DEBUG - 2019-07-02 15:12:14 --> UTF-8 Support Enabled
INFO - 2019-07-02 15:12:14 --> Utf8 Class Initialized
INFO - 2019-07-02 15:12:14 --> URI Class Initialized
INFO - 2019-07-02 15:12:14 --> Router Class Initialized
INFO - 2019-07-02 15:12:14 --> Output Class Initialized
INFO - 2019-07-02 15:12:14 --> Security Class Initialized
DEBUG - 2019-07-02 15:12:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 15:12:14 --> Input Class Initialized
INFO - 2019-07-02 15:12:14 --> Language Class Initialized
INFO - 2019-07-02 15:12:14 --> Language Class Initialized
INFO - 2019-07-02 15:12:14 --> Config Class Initialized
INFO - 2019-07-02 15:12:14 --> Loader Class Initialized
DEBUG - 2019-07-02 15:12:14 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 15:12:14 --> Helper loaded: url_helper
INFO - 2019-07-02 15:12:14 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:12:14 --> Helper loaded: string_helper
INFO - 2019-07-02 15:12:14 --> Helper loaded: array_helper
INFO - 2019-07-02 15:12:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:12:14 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:12:14 --> Database Driver Class Initialized
INFO - 2019-07-02 15:12:14 --> Controller Class Initialized
INFO - 2019-07-02 21:12:14 --> Helper loaded: language_helper
INFO - 2019-07-02 21:12:14 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:12:14 --> Model Class Initialized
INFO - 2019-07-02 21:12:14 --> Model Class Initialized
INFO - 2019-07-02 21:12:14 --> Model Class Initialized
INFO - 2019-07-02 21:12:14 --> Model Class Initialized
INFO - 2019-07-02 21:12:14 --> Helper loaded: form_helper
INFO - 2019-07-02 21:12:14 --> Form Validation Class Initialized
DEBUG - 2019-07-02 21:12:14 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-02 21:12:14 --> Model Class Initialized
INFO - 2019-07-02 21:12:14 --> Model Class Initialized
INFO - 2019-07-02 21:12:14 --> Final output sent to browser
DEBUG - 2019-07-02 21:12:14 --> Total execution time: 0.4001
INFO - 2019-07-02 15:12:18 --> Config Class Initialized
INFO - 2019-07-02 15:12:18 --> Hooks Class Initialized
DEBUG - 2019-07-02 15:12:18 --> UTF-8 Support Enabled
INFO - 2019-07-02 15:12:18 --> Utf8 Class Initialized
INFO - 2019-07-02 15:12:18 --> URI Class Initialized
INFO - 2019-07-02 15:12:18 --> Router Class Initialized
INFO - 2019-07-02 15:12:18 --> Output Class Initialized
INFO - 2019-07-02 15:12:18 --> Security Class Initialized
DEBUG - 2019-07-02 15:12:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 15:12:18 --> Input Class Initialized
INFO - 2019-07-02 15:12:18 --> Language Class Initialized
INFO - 2019-07-02 15:12:18 --> Language Class Initialized
INFO - 2019-07-02 15:12:18 --> Config Class Initialized
INFO - 2019-07-02 15:12:18 --> Loader Class Initialized
DEBUG - 2019-07-02 15:12:18 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 15:12:18 --> Helper loaded: url_helper
INFO - 2019-07-02 15:12:18 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:12:18 --> Helper loaded: string_helper
INFO - 2019-07-02 15:12:18 --> Helper loaded: array_helper
INFO - 2019-07-02 15:12:18 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:12:18 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:12:18 --> Database Driver Class Initialized
INFO - 2019-07-02 15:12:18 --> Controller Class Initialized
INFO - 2019-07-02 21:12:18 --> Helper loaded: language_helper
INFO - 2019-07-02 21:12:18 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:12:18 --> Model Class Initialized
INFO - 2019-07-02 21:12:18 --> Model Class Initialized
INFO - 2019-07-02 21:12:18 --> Model Class Initialized
INFO - 2019-07-02 21:12:18 --> Model Class Initialized
INFO - 2019-07-02 21:12:18 --> Helper loaded: form_helper
INFO - 2019-07-02 21:12:18 --> Form Validation Class Initialized
DEBUG - 2019-07-02 21:12:18 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-02 21:12:18 --> Model Class Initialized
INFO - 2019-07-02 21:12:18 --> Model Class Initialized
INFO - 2019-07-02 21:12:18 --> Final output sent to browser
DEBUG - 2019-07-02 21:12:18 --> Total execution time: 0.4986
INFO - 2019-07-02 15:12:42 --> Config Class Initialized
INFO - 2019-07-02 15:12:42 --> Hooks Class Initialized
DEBUG - 2019-07-02 15:12:42 --> UTF-8 Support Enabled
INFO - 2019-07-02 15:12:42 --> Utf8 Class Initialized
INFO - 2019-07-02 15:12:42 --> URI Class Initialized
INFO - 2019-07-02 15:12:42 --> Router Class Initialized
INFO - 2019-07-02 15:12:42 --> Output Class Initialized
INFO - 2019-07-02 15:12:42 --> Security Class Initialized
DEBUG - 2019-07-02 15:12:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 15:12:42 --> Input Class Initialized
INFO - 2019-07-02 15:12:42 --> Language Class Initialized
INFO - 2019-07-02 15:12:42 --> Language Class Initialized
INFO - 2019-07-02 15:12:42 --> Config Class Initialized
INFO - 2019-07-02 15:12:42 --> Loader Class Initialized
DEBUG - 2019-07-02 15:12:42 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 15:12:42 --> Helper loaded: url_helper
INFO - 2019-07-02 15:12:42 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:12:42 --> Helper loaded: string_helper
INFO - 2019-07-02 15:12:42 --> Helper loaded: array_helper
INFO - 2019-07-02 15:12:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:12:42 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:12:42 --> Database Driver Class Initialized
INFO - 2019-07-02 15:12:42 --> Controller Class Initialized
INFO - 2019-07-02 21:12:43 --> Helper loaded: language_helper
INFO - 2019-07-02 21:12:43 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:12:43 --> Model Class Initialized
INFO - 2019-07-02 21:12:43 --> Model Class Initialized
INFO - 2019-07-02 21:12:43 --> Model Class Initialized
INFO - 2019-07-02 21:12:43 --> Model Class Initialized
INFO - 2019-07-02 21:12:43 --> Helper loaded: form_helper
INFO - 2019-07-02 21:12:43 --> Form Validation Class Initialized
DEBUG - 2019-07-02 21:12:43 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-02 21:12:43 --> Model Class Initialized
INFO - 2019-07-02 21:12:43 --> Model Class Initialized
INFO - 2019-07-02 21:12:43 --> Final output sent to browser
DEBUG - 2019-07-02 21:12:43 --> Total execution time: 0.5381
INFO - 2019-07-02 15:12:44 --> Config Class Initialized
INFO - 2019-07-02 15:12:44 --> Hooks Class Initialized
DEBUG - 2019-07-02 15:12:44 --> UTF-8 Support Enabled
INFO - 2019-07-02 15:12:44 --> Utf8 Class Initialized
INFO - 2019-07-02 15:12:44 --> URI Class Initialized
INFO - 2019-07-02 15:12:44 --> Router Class Initialized
INFO - 2019-07-02 15:12:44 --> Output Class Initialized
INFO - 2019-07-02 15:12:44 --> Security Class Initialized
DEBUG - 2019-07-02 15:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 15:12:44 --> Input Class Initialized
INFO - 2019-07-02 15:12:44 --> Language Class Initialized
INFO - 2019-07-02 15:12:44 --> Language Class Initialized
INFO - 2019-07-02 15:12:44 --> Config Class Initialized
INFO - 2019-07-02 15:12:44 --> Loader Class Initialized
DEBUG - 2019-07-02 15:12:44 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 15:12:44 --> Helper loaded: url_helper
INFO - 2019-07-02 15:12:44 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:12:44 --> Helper loaded: string_helper
INFO - 2019-07-02 15:12:44 --> Helper loaded: array_helper
INFO - 2019-07-02 15:12:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:12:44 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:12:44 --> Database Driver Class Initialized
INFO - 2019-07-02 15:12:44 --> Controller Class Initialized
INFO - 2019-07-02 21:12:44 --> Helper loaded: language_helper
INFO - 2019-07-02 21:12:44 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:12:44 --> Model Class Initialized
INFO - 2019-07-02 21:12:44 --> Model Class Initialized
INFO - 2019-07-02 21:12:44 --> Model Class Initialized
INFO - 2019-07-02 21:12:44 --> Model Class Initialized
INFO - 2019-07-02 21:12:44 --> Model Class Initialized
INFO - 2019-07-02 21:12:44 --> Final output sent to browser
DEBUG - 2019-07-02 21:12:44 --> Total execution time: 0.3689
INFO - 2019-07-02 15:12:46 --> Config Class Initialized
INFO - 2019-07-02 15:12:46 --> Hooks Class Initialized
DEBUG - 2019-07-02 15:12:46 --> UTF-8 Support Enabled
INFO - 2019-07-02 15:12:46 --> Utf8 Class Initialized
INFO - 2019-07-02 15:12:46 --> URI Class Initialized
INFO - 2019-07-02 15:12:46 --> Router Class Initialized
INFO - 2019-07-02 15:12:46 --> Output Class Initialized
INFO - 2019-07-02 15:12:46 --> Security Class Initialized
DEBUG - 2019-07-02 15:12:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 15:12:46 --> Input Class Initialized
INFO - 2019-07-02 15:12:46 --> Language Class Initialized
INFO - 2019-07-02 15:12:46 --> Language Class Initialized
INFO - 2019-07-02 15:12:46 --> Config Class Initialized
INFO - 2019-07-02 15:12:46 --> Loader Class Initialized
DEBUG - 2019-07-02 15:12:46 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 15:12:46 --> Helper loaded: url_helper
INFO - 2019-07-02 15:12:46 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:12:46 --> Helper loaded: string_helper
INFO - 2019-07-02 15:12:46 --> Helper loaded: array_helper
INFO - 2019-07-02 15:12:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:12:46 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:12:46 --> Database Driver Class Initialized
INFO - 2019-07-02 15:12:47 --> Controller Class Initialized
INFO - 2019-07-02 21:12:47 --> Helper loaded: language_helper
INFO - 2019-07-02 21:12:47 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:12:47 --> Model Class Initialized
INFO - 2019-07-02 21:12:47 --> Model Class Initialized
INFO - 2019-07-02 21:12:47 --> Model Class Initialized
INFO - 2019-07-02 21:12:47 --> Model Class Initialized
INFO - 2019-07-02 21:12:47 --> Helper loaded: form_helper
INFO - 2019-07-02 21:12:47 --> Form Validation Class Initialized
DEBUG - 2019-07-02 21:12:47 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-02 21:12:47 --> Model Class Initialized
INFO - 2019-07-02 21:12:47 --> Model Class Initialized
INFO - 2019-07-02 21:12:47 --> Final output sent to browser
DEBUG - 2019-07-02 21:12:47 --> Total execution time: 0.4272
INFO - 2019-07-02 15:12:47 --> Config Class Initialized
INFO - 2019-07-02 15:12:47 --> Hooks Class Initialized
DEBUG - 2019-07-02 15:12:47 --> UTF-8 Support Enabled
INFO - 2019-07-02 15:12:47 --> Utf8 Class Initialized
INFO - 2019-07-02 15:12:47 --> URI Class Initialized
INFO - 2019-07-02 15:12:47 --> Router Class Initialized
INFO - 2019-07-02 15:12:47 --> Output Class Initialized
INFO - 2019-07-02 15:12:47 --> Security Class Initialized
DEBUG - 2019-07-02 15:12:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 15:12:47 --> Input Class Initialized
INFO - 2019-07-02 15:12:47 --> Language Class Initialized
INFO - 2019-07-02 15:12:47 --> Language Class Initialized
INFO - 2019-07-02 15:12:47 --> Config Class Initialized
INFO - 2019-07-02 15:12:47 --> Loader Class Initialized
DEBUG - 2019-07-02 15:12:47 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 15:12:47 --> Helper loaded: url_helper
INFO - 2019-07-02 15:12:47 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:12:47 --> Helper loaded: string_helper
INFO - 2019-07-02 15:12:47 --> Helper loaded: array_helper
INFO - 2019-07-02 15:12:47 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:12:47 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:12:47 --> Database Driver Class Initialized
INFO - 2019-07-02 15:12:47 --> Controller Class Initialized
INFO - 2019-07-02 21:12:47 --> Helper loaded: language_helper
INFO - 2019-07-02 21:12:47 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:12:47 --> Model Class Initialized
INFO - 2019-07-02 21:12:47 --> Model Class Initialized
INFO - 2019-07-02 21:12:47 --> Model Class Initialized
INFO - 2019-07-02 21:12:47 --> Model Class Initialized
INFO - 2019-07-02 21:12:47 --> Helper loaded: form_helper
INFO - 2019-07-02 21:12:47 --> Form Validation Class Initialized
DEBUG - 2019-07-02 21:12:47 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-02 21:12:47 --> Model Class Initialized
INFO - 2019-07-02 21:12:47 --> Model Class Initialized
INFO - 2019-07-02 21:12:47 --> Final output sent to browser
DEBUG - 2019-07-02 21:12:47 --> Total execution time: 0.4160
INFO - 2019-07-02 15:13:10 --> Config Class Initialized
INFO - 2019-07-02 15:13:10 --> Hooks Class Initialized
DEBUG - 2019-07-02 15:13:10 --> UTF-8 Support Enabled
INFO - 2019-07-02 15:13:10 --> Utf8 Class Initialized
INFO - 2019-07-02 15:13:10 --> URI Class Initialized
INFO - 2019-07-02 15:13:10 --> Router Class Initialized
INFO - 2019-07-02 15:13:10 --> Output Class Initialized
INFO - 2019-07-02 15:13:10 --> Security Class Initialized
DEBUG - 2019-07-02 15:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 15:13:10 --> Input Class Initialized
INFO - 2019-07-02 15:13:10 --> Language Class Initialized
INFO - 2019-07-02 15:13:10 --> Language Class Initialized
INFO - 2019-07-02 15:13:10 --> Config Class Initialized
INFO - 2019-07-02 15:13:10 --> Loader Class Initialized
DEBUG - 2019-07-02 15:13:10 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 15:13:10 --> Helper loaded: url_helper
INFO - 2019-07-02 15:13:10 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:13:10 --> Helper loaded: string_helper
INFO - 2019-07-02 15:13:10 --> Helper loaded: array_helper
INFO - 2019-07-02 15:13:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:13:10 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:13:11 --> Database Driver Class Initialized
INFO - 2019-07-02 15:13:11 --> Controller Class Initialized
INFO - 2019-07-02 21:13:11 --> Helper loaded: language_helper
INFO - 2019-07-02 21:13:11 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:13:11 --> Model Class Initialized
INFO - 2019-07-02 21:13:11 --> Model Class Initialized
INFO - 2019-07-02 21:13:11 --> Model Class Initialized
INFO - 2019-07-02 21:13:11 --> Model Class Initialized
INFO - 2019-07-02 21:13:11 --> Helper loaded: form_helper
INFO - 2019-07-02 21:13:11 --> Form Validation Class Initialized
DEBUG - 2019-07-02 21:13:11 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-02 21:13:11 --> Model Class Initialized
INFO - 2019-07-02 21:13:11 --> Model Class Initialized
INFO - 2019-07-02 21:13:11 --> Final output sent to browser
DEBUG - 2019-07-02 21:13:11 --> Total execution time: 0.4907
INFO - 2019-07-02 15:13:12 --> Config Class Initialized
INFO - 2019-07-02 15:13:12 --> Hooks Class Initialized
DEBUG - 2019-07-02 15:13:12 --> UTF-8 Support Enabled
INFO - 2019-07-02 15:13:12 --> Utf8 Class Initialized
INFO - 2019-07-02 15:13:12 --> URI Class Initialized
INFO - 2019-07-02 15:13:12 --> Router Class Initialized
INFO - 2019-07-02 15:13:12 --> Output Class Initialized
INFO - 2019-07-02 15:13:12 --> Security Class Initialized
DEBUG - 2019-07-02 15:13:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 15:13:12 --> Input Class Initialized
INFO - 2019-07-02 15:13:12 --> Language Class Initialized
INFO - 2019-07-02 15:13:12 --> Language Class Initialized
INFO - 2019-07-02 15:13:12 --> Config Class Initialized
INFO - 2019-07-02 15:13:12 --> Loader Class Initialized
DEBUG - 2019-07-02 15:13:12 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 15:13:12 --> Helper loaded: url_helper
INFO - 2019-07-02 15:13:12 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:13:12 --> Helper loaded: string_helper
INFO - 2019-07-02 15:13:12 --> Helper loaded: array_helper
INFO - 2019-07-02 15:13:12 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:13:12 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:13:12 --> Database Driver Class Initialized
INFO - 2019-07-02 15:13:12 --> Controller Class Initialized
INFO - 2019-07-02 21:13:12 --> Helper loaded: language_helper
INFO - 2019-07-02 21:13:12 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:13:12 --> Model Class Initialized
INFO - 2019-07-02 21:13:12 --> Model Class Initialized
INFO - 2019-07-02 21:13:12 --> Model Class Initialized
INFO - 2019-07-02 21:13:12 --> Model Class Initialized
INFO - 2019-07-02 21:13:12 --> Model Class Initialized
INFO - 2019-07-02 21:13:12 --> Final output sent to browser
DEBUG - 2019-07-02 21:13:12 --> Total execution time: 0.3731
INFO - 2019-07-02 15:13:17 --> Config Class Initialized
INFO - 2019-07-02 15:13:17 --> Hooks Class Initialized
DEBUG - 2019-07-02 15:13:17 --> UTF-8 Support Enabled
INFO - 2019-07-02 15:13:17 --> Utf8 Class Initialized
INFO - 2019-07-02 15:13:17 --> URI Class Initialized
INFO - 2019-07-02 15:13:17 --> Router Class Initialized
INFO - 2019-07-02 15:13:17 --> Output Class Initialized
INFO - 2019-07-02 15:13:17 --> Security Class Initialized
DEBUG - 2019-07-02 15:13:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 15:13:17 --> Input Class Initialized
INFO - 2019-07-02 15:13:17 --> Language Class Initialized
INFO - 2019-07-02 15:13:17 --> Language Class Initialized
INFO - 2019-07-02 15:13:17 --> Config Class Initialized
INFO - 2019-07-02 15:13:17 --> Loader Class Initialized
DEBUG - 2019-07-02 15:13:17 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 15:13:17 --> Helper loaded: url_helper
INFO - 2019-07-02 15:13:17 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:13:17 --> Helper loaded: string_helper
INFO - 2019-07-02 15:13:17 --> Helper loaded: array_helper
INFO - 2019-07-02 15:13:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:13:17 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:13:17 --> Database Driver Class Initialized
INFO - 2019-07-02 15:13:17 --> Controller Class Initialized
INFO - 2019-07-02 21:13:18 --> Helper loaded: language_helper
INFO - 2019-07-02 21:13:18 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:13:18 --> Model Class Initialized
INFO - 2019-07-02 21:13:18 --> Model Class Initialized
INFO - 2019-07-02 21:13:18 --> Model Class Initialized
INFO - 2019-07-02 21:13:18 --> Model Class Initialized
INFO - 2019-07-02 21:13:18 --> Model Class Initialized
INFO - 2019-07-02 21:13:18 --> Final output sent to browser
DEBUG - 2019-07-02 21:13:18 --> Total execution time: 0.3907
INFO - 2019-07-02 15:13:19 --> Config Class Initialized
INFO - 2019-07-02 15:13:19 --> Hooks Class Initialized
DEBUG - 2019-07-02 15:13:19 --> UTF-8 Support Enabled
INFO - 2019-07-02 15:13:19 --> Utf8 Class Initialized
INFO - 2019-07-02 15:13:19 --> URI Class Initialized
INFO - 2019-07-02 15:13:19 --> Router Class Initialized
INFO - 2019-07-02 15:13:19 --> Output Class Initialized
INFO - 2019-07-02 15:13:19 --> Security Class Initialized
DEBUG - 2019-07-02 15:13:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 15:13:19 --> Input Class Initialized
INFO - 2019-07-02 15:13:19 --> Language Class Initialized
INFO - 2019-07-02 15:13:20 --> Language Class Initialized
INFO - 2019-07-02 15:13:20 --> Config Class Initialized
INFO - 2019-07-02 15:13:20 --> Loader Class Initialized
DEBUG - 2019-07-02 15:13:20 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 15:13:20 --> Helper loaded: url_helper
INFO - 2019-07-02 15:13:20 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:13:20 --> Helper loaded: string_helper
INFO - 2019-07-02 15:13:20 --> Helper loaded: array_helper
INFO - 2019-07-02 15:13:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:13:20 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:13:20 --> Database Driver Class Initialized
INFO - 2019-07-02 15:13:20 --> Controller Class Initialized
INFO - 2019-07-02 21:13:20 --> Helper loaded: language_helper
INFO - 2019-07-02 21:13:20 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:13:20 --> Model Class Initialized
INFO - 2019-07-02 21:13:20 --> Model Class Initialized
INFO - 2019-07-02 21:13:20 --> Model Class Initialized
INFO - 2019-07-02 21:13:20 --> Model Class Initialized
INFO - 2019-07-02 21:13:20 --> Helper loaded: form_helper
INFO - 2019-07-02 21:13:20 --> Form Validation Class Initialized
DEBUG - 2019-07-02 21:13:20 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-02 21:13:20 --> Model Class Initialized
INFO - 2019-07-02 21:13:20 --> Model Class Initialized
INFO - 2019-07-02 21:13:20 --> Final output sent to browser
DEBUG - 2019-07-02 21:13:20 --> Total execution time: 0.5215
INFO - 2019-07-02 15:13:25 --> Config Class Initialized
INFO - 2019-07-02 15:13:25 --> Hooks Class Initialized
DEBUG - 2019-07-02 15:13:25 --> UTF-8 Support Enabled
INFO - 2019-07-02 15:13:25 --> Utf8 Class Initialized
INFO - 2019-07-02 15:13:25 --> URI Class Initialized
INFO - 2019-07-02 15:13:25 --> Router Class Initialized
INFO - 2019-07-02 15:13:25 --> Output Class Initialized
INFO - 2019-07-02 15:13:25 --> Security Class Initialized
DEBUG - 2019-07-02 15:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 15:13:25 --> Input Class Initialized
INFO - 2019-07-02 15:13:25 --> Language Class Initialized
INFO - 2019-07-02 15:13:25 --> Language Class Initialized
INFO - 2019-07-02 15:13:25 --> Config Class Initialized
INFO - 2019-07-02 15:13:25 --> Loader Class Initialized
DEBUG - 2019-07-02 15:13:25 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 15:13:25 --> Helper loaded: url_helper
INFO - 2019-07-02 15:13:25 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:13:25 --> Helper loaded: string_helper
INFO - 2019-07-02 15:13:25 --> Helper loaded: array_helper
INFO - 2019-07-02 15:13:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:13:25 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:13:25 --> Database Driver Class Initialized
INFO - 2019-07-02 15:13:25 --> Controller Class Initialized
INFO - 2019-07-02 21:13:25 --> Helper loaded: language_helper
INFO - 2019-07-02 21:13:25 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:13:25 --> Model Class Initialized
INFO - 2019-07-02 21:13:25 --> Model Class Initialized
INFO - 2019-07-02 21:13:25 --> Model Class Initialized
INFO - 2019-07-02 21:13:25 --> Model Class Initialized
INFO - 2019-07-02 21:13:25 --> Model Class Initialized
INFO - 2019-07-02 21:13:25 --> Final output sent to browser
DEBUG - 2019-07-02 21:13:25 --> Total execution time: 0.3934
INFO - 2019-07-02 15:13:35 --> Config Class Initialized
INFO - 2019-07-02 15:13:35 --> Hooks Class Initialized
DEBUG - 2019-07-02 15:13:35 --> UTF-8 Support Enabled
INFO - 2019-07-02 15:13:35 --> Utf8 Class Initialized
INFO - 2019-07-02 15:13:35 --> URI Class Initialized
INFO - 2019-07-02 15:13:35 --> Router Class Initialized
INFO - 2019-07-02 15:13:35 --> Output Class Initialized
INFO - 2019-07-02 15:13:35 --> Security Class Initialized
DEBUG - 2019-07-02 15:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 15:13:35 --> Input Class Initialized
INFO - 2019-07-02 15:13:35 --> Language Class Initialized
INFO - 2019-07-02 15:13:35 --> Language Class Initialized
INFO - 2019-07-02 15:13:35 --> Config Class Initialized
INFO - 2019-07-02 15:13:35 --> Loader Class Initialized
DEBUG - 2019-07-02 15:13:35 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 15:13:35 --> Helper loaded: url_helper
INFO - 2019-07-02 15:13:35 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:13:35 --> Helper loaded: string_helper
INFO - 2019-07-02 15:13:35 --> Helper loaded: array_helper
INFO - 2019-07-02 15:13:35 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:13:35 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:13:35 --> Database Driver Class Initialized
INFO - 2019-07-02 15:13:36 --> Controller Class Initialized
INFO - 2019-07-02 21:13:36 --> Helper loaded: language_helper
INFO - 2019-07-02 21:13:36 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:13:36 --> Model Class Initialized
INFO - 2019-07-02 21:13:36 --> Model Class Initialized
INFO - 2019-07-02 21:13:36 --> Model Class Initialized
INFO - 2019-07-02 21:13:36 --> Model Class Initialized
INFO - 2019-07-02 21:13:36 --> Helper loaded: form_helper
INFO - 2019-07-02 21:13:36 --> Form Validation Class Initialized
DEBUG - 2019-07-02 21:13:36 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-02 21:13:36 --> Model Class Initialized
INFO - 2019-07-02 21:13:36 --> Model Class Initialized
INFO - 2019-07-02 21:13:36 --> Final output sent to browser
DEBUG - 2019-07-02 21:13:36 --> Total execution time: 0.4945
INFO - 2019-07-02 15:14:44 --> Config Class Initialized
INFO - 2019-07-02 15:14:44 --> Hooks Class Initialized
DEBUG - 2019-07-02 15:14:44 --> UTF-8 Support Enabled
INFO - 2019-07-02 15:14:44 --> Utf8 Class Initialized
INFO - 2019-07-02 15:14:44 --> URI Class Initialized
INFO - 2019-07-02 15:14:44 --> Router Class Initialized
INFO - 2019-07-02 15:14:44 --> Output Class Initialized
INFO - 2019-07-02 15:14:44 --> Security Class Initialized
DEBUG - 2019-07-02 15:14:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 15:14:44 --> Input Class Initialized
INFO - 2019-07-02 15:14:44 --> Language Class Initialized
INFO - 2019-07-02 15:14:44 --> Language Class Initialized
INFO - 2019-07-02 15:14:45 --> Config Class Initialized
INFO - 2019-07-02 15:14:45 --> Loader Class Initialized
DEBUG - 2019-07-02 15:14:45 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 15:14:45 --> Helper loaded: url_helper
INFO - 2019-07-02 15:14:45 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:14:45 --> Helper loaded: string_helper
INFO - 2019-07-02 15:14:45 --> Helper loaded: array_helper
INFO - 2019-07-02 15:14:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:14:45 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:14:45 --> Database Driver Class Initialized
INFO - 2019-07-02 15:14:45 --> Controller Class Initialized
INFO - 2019-07-02 21:14:45 --> Helper loaded: language_helper
INFO - 2019-07-02 21:14:45 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:14:45 --> Model Class Initialized
INFO - 2019-07-02 21:14:45 --> Model Class Initialized
INFO - 2019-07-02 21:14:45 --> Model Class Initialized
INFO - 2019-07-02 21:14:45 --> Model Class Initialized
INFO - 2019-07-02 21:14:45 --> Helper loaded: form_helper
INFO - 2019-07-02 21:14:45 --> Form Validation Class Initialized
DEBUG - 2019-07-02 21:14:45 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-02 21:14:45 --> Model Class Initialized
INFO - 2019-07-02 21:14:45 --> Model Class Initialized
INFO - 2019-07-02 21:14:45 --> Final output sent to browser
DEBUG - 2019-07-02 21:14:45 --> Total execution time: 0.5305
INFO - 2019-07-02 15:18:06 --> Config Class Initialized
INFO - 2019-07-02 15:18:06 --> Hooks Class Initialized
DEBUG - 2019-07-02 15:18:06 --> UTF-8 Support Enabled
INFO - 2019-07-02 15:18:06 --> Utf8 Class Initialized
INFO - 2019-07-02 15:18:06 --> URI Class Initialized
INFO - 2019-07-02 15:18:06 --> Router Class Initialized
INFO - 2019-07-02 15:18:06 --> Output Class Initialized
INFO - 2019-07-02 15:18:06 --> Security Class Initialized
DEBUG - 2019-07-02 15:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 15:18:06 --> Input Class Initialized
INFO - 2019-07-02 15:18:06 --> Language Class Initialized
INFO - 2019-07-02 15:18:06 --> Language Class Initialized
INFO - 2019-07-02 15:18:06 --> Config Class Initialized
INFO - 2019-07-02 15:18:06 --> Loader Class Initialized
DEBUG - 2019-07-02 15:18:06 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 15:18:06 --> Helper loaded: url_helper
INFO - 2019-07-02 15:18:06 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:18:06 --> Helper loaded: string_helper
INFO - 2019-07-02 15:18:06 --> Helper loaded: array_helper
INFO - 2019-07-02 15:18:06 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:18:06 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:18:06 --> Database Driver Class Initialized
INFO - 2019-07-02 15:18:06 --> Controller Class Initialized
INFO - 2019-07-02 21:18:06 --> Helper loaded: language_helper
INFO - 2019-07-02 21:18:06 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:18:06 --> Model Class Initialized
INFO - 2019-07-02 21:18:06 --> Model Class Initialized
INFO - 2019-07-02 21:18:06 --> Model Class Initialized
INFO - 2019-07-02 21:18:06 --> Model Class Initialized
INFO - 2019-07-02 21:18:06 --> Helper loaded: form_helper
INFO - 2019-07-02 21:18:06 --> Form Validation Class Initialized
DEBUG - 2019-07-02 21:18:06 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-02 21:18:06 --> Model Class Initialized
INFO - 2019-07-02 21:18:06 --> Model Class Initialized
INFO - 2019-07-02 21:18:06 --> Final output sent to browser
DEBUG - 2019-07-02 21:18:06 --> Total execution time: 0.4400
INFO - 2019-07-02 15:18:16 --> Config Class Initialized
INFO - 2019-07-02 15:18:16 --> Hooks Class Initialized
DEBUG - 2019-07-02 15:18:16 --> UTF-8 Support Enabled
INFO - 2019-07-02 15:18:16 --> Utf8 Class Initialized
INFO - 2019-07-02 15:18:16 --> URI Class Initialized
INFO - 2019-07-02 15:18:16 --> Router Class Initialized
INFO - 2019-07-02 15:18:16 --> Output Class Initialized
INFO - 2019-07-02 15:18:16 --> Security Class Initialized
DEBUG - 2019-07-02 15:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 15:18:16 --> Input Class Initialized
INFO - 2019-07-02 15:18:16 --> Language Class Initialized
INFO - 2019-07-02 15:18:16 --> Language Class Initialized
INFO - 2019-07-02 15:18:16 --> Config Class Initialized
INFO - 2019-07-02 15:18:16 --> Loader Class Initialized
DEBUG - 2019-07-02 15:18:16 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 15:18:16 --> Helper loaded: url_helper
INFO - 2019-07-02 15:18:16 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:18:16 --> Helper loaded: string_helper
INFO - 2019-07-02 15:18:16 --> Helper loaded: array_helper
INFO - 2019-07-02 15:18:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:18:16 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:18:16 --> Database Driver Class Initialized
INFO - 2019-07-02 15:18:16 --> Controller Class Initialized
INFO - 2019-07-02 21:18:16 --> Helper loaded: language_helper
INFO - 2019-07-02 21:18:16 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:18:16 --> Model Class Initialized
INFO - 2019-07-02 21:18:16 --> Model Class Initialized
INFO - 2019-07-02 21:18:16 --> Model Class Initialized
INFO - 2019-07-02 21:18:16 --> Model Class Initialized
INFO - 2019-07-02 21:18:16 --> Final output sent to browser
DEBUG - 2019-07-02 21:18:16 --> Total execution time: 0.4077
INFO - 2019-07-02 15:18:16 --> Config Class Initialized
INFO - 2019-07-02 15:18:16 --> Hooks Class Initialized
INFO - 2019-07-02 15:18:16 --> Config Class Initialized
INFO - 2019-07-02 15:18:16 --> Hooks Class Initialized
DEBUG - 2019-07-02 15:18:16 --> UTF-8 Support Enabled
DEBUG - 2019-07-02 15:18:16 --> UTF-8 Support Enabled
INFO - 2019-07-02 15:18:16 --> Utf8 Class Initialized
INFO - 2019-07-02 15:18:16 --> Utf8 Class Initialized
INFO - 2019-07-02 15:18:16 --> URI Class Initialized
INFO - 2019-07-02 15:18:16 --> URI Class Initialized
INFO - 2019-07-02 15:18:16 --> Router Class Initialized
INFO - 2019-07-02 15:18:16 --> Router Class Initialized
INFO - 2019-07-02 15:18:16 --> Output Class Initialized
INFO - 2019-07-02 15:18:16 --> Output Class Initialized
INFO - 2019-07-02 15:18:16 --> Security Class Initialized
INFO - 2019-07-02 15:18:16 --> Security Class Initialized
DEBUG - 2019-07-02 15:18:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-02 15:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 15:18:16 --> Input Class Initialized
INFO - 2019-07-02 15:18:16 --> Input Class Initialized
INFO - 2019-07-02 15:18:16 --> Language Class Initialized
INFO - 2019-07-02 15:18:16 --> Language Class Initialized
INFO - 2019-07-02 15:18:16 --> Language Class Initialized
INFO - 2019-07-02 15:18:16 --> Language Class Initialized
INFO - 2019-07-02 15:18:16 --> Config Class Initialized
INFO - 2019-07-02 15:18:16 --> Config Class Initialized
INFO - 2019-07-02 15:18:16 --> Loader Class Initialized
INFO - 2019-07-02 15:18:16 --> Loader Class Initialized
DEBUG - 2019-07-02 15:18:16 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-02 15:18:16 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 15:18:16 --> Helper loaded: url_helper
INFO - 2019-07-02 15:18:16 --> Helper loaded: url_helper
INFO - 2019-07-02 15:18:16 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:18:17 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:18:17 --> Helper loaded: string_helper
INFO - 2019-07-02 15:18:17 --> Helper loaded: string_helper
INFO - 2019-07-02 15:18:17 --> Helper loaded: array_helper
INFO - 2019-07-02 15:18:17 --> Helper loaded: array_helper
INFO - 2019-07-02 15:18:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:18:17 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:18:17 --> Database Driver Class Initialized
INFO - 2019-07-02 15:18:17 --> Controller Class Initialized
INFO - 2019-07-02 21:18:17 --> Helper loaded: language_helper
INFO - 2019-07-02 21:18:17 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:18:17 --> Model Class Initialized
INFO - 2019-07-02 21:18:17 --> Model Class Initialized
INFO - 2019-07-02 21:18:17 --> Model Class Initialized
INFO - 2019-07-02 21:18:17 --> Model Class Initialized
INFO - 2019-07-02 21:18:17 --> Final output sent to browser
DEBUG - 2019-07-02 21:18:17 --> Total execution time: 0.4757
INFO - 2019-07-02 15:18:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:18:17 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:18:17 --> Database Driver Class Initialized
INFO - 2019-07-02 15:18:17 --> Controller Class Initialized
INFO - 2019-07-02 21:18:17 --> Helper loaded: language_helper
INFO - 2019-07-02 21:18:17 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:18:17 --> Model Class Initialized
INFO - 2019-07-02 21:18:17 --> Model Class Initialized
INFO - 2019-07-02 21:18:17 --> Model Class Initialized
INFO - 2019-07-02 21:18:17 --> Model Class Initialized
INFO - 2019-07-02 21:18:17 --> Model Class Initialized
INFO - 2019-07-02 21:18:17 --> Final output sent to browser
DEBUG - 2019-07-02 21:18:17 --> Total execution time: 0.6341
INFO - 2019-07-02 15:20:17 --> Config Class Initialized
INFO - 2019-07-02 15:20:17 --> Hooks Class Initialized
DEBUG - 2019-07-02 15:20:17 --> UTF-8 Support Enabled
INFO - 2019-07-02 15:20:17 --> Utf8 Class Initialized
INFO - 2019-07-02 15:20:18 --> URI Class Initialized
INFO - 2019-07-02 15:20:18 --> Router Class Initialized
INFO - 2019-07-02 15:20:18 --> Output Class Initialized
INFO - 2019-07-02 15:20:18 --> Security Class Initialized
DEBUG - 2019-07-02 15:20:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 15:20:18 --> Input Class Initialized
INFO - 2019-07-02 15:20:18 --> Language Class Initialized
INFO - 2019-07-02 15:20:18 --> Language Class Initialized
INFO - 2019-07-02 15:20:18 --> Config Class Initialized
INFO - 2019-07-02 15:20:18 --> Loader Class Initialized
DEBUG - 2019-07-02 15:20:18 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 15:20:18 --> Helper loaded: url_helper
INFO - 2019-07-02 15:20:18 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:20:18 --> Helper loaded: string_helper
INFO - 2019-07-02 15:20:18 --> Helper loaded: array_helper
INFO - 2019-07-02 15:20:18 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:20:18 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:20:18 --> Database Driver Class Initialized
INFO - 2019-07-02 15:20:18 --> Controller Class Initialized
INFO - 2019-07-02 21:20:18 --> Helper loaded: language_helper
INFO - 2019-07-02 21:20:18 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:20:18 --> Model Class Initialized
INFO - 2019-07-02 21:20:18 --> Model Class Initialized
INFO - 2019-07-02 21:20:18 --> Model Class Initialized
INFO - 2019-07-02 21:20:18 --> Model Class Initialized
INFO - 2019-07-02 21:20:18 --> Helper loaded: form_helper
INFO - 2019-07-02 21:20:18 --> Form Validation Class Initialized
DEBUG - 2019-07-02 21:20:18 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-02 21:20:18 --> Model Class Initialized
INFO - 2019-07-02 21:20:18 --> Model Class Initialized
INFO - 2019-07-02 21:20:18 --> Final output sent to browser
DEBUG - 2019-07-02 21:20:18 --> Total execution time: 0.5179
INFO - 2019-07-02 15:20:19 --> Config Class Initialized
INFO - 2019-07-02 15:20:19 --> Config Class Initialized
INFO - 2019-07-02 15:20:19 --> Hooks Class Initialized
INFO - 2019-07-02 15:20:19 --> Hooks Class Initialized
DEBUG - 2019-07-02 15:20:19 --> UTF-8 Support Enabled
DEBUG - 2019-07-02 15:20:19 --> UTF-8 Support Enabled
INFO - 2019-07-02 15:20:19 --> Utf8 Class Initialized
INFO - 2019-07-02 15:20:19 --> Utf8 Class Initialized
INFO - 2019-07-02 15:20:19 --> URI Class Initialized
INFO - 2019-07-02 15:20:19 --> URI Class Initialized
INFO - 2019-07-02 15:20:19 --> Router Class Initialized
INFO - 2019-07-02 15:20:19 --> Router Class Initialized
INFO - 2019-07-02 15:20:19 --> Output Class Initialized
INFO - 2019-07-02 15:20:19 --> Output Class Initialized
INFO - 2019-07-02 15:20:19 --> Security Class Initialized
INFO - 2019-07-02 15:20:19 --> Security Class Initialized
DEBUG - 2019-07-02 15:20:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-02 15:20:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 15:20:19 --> Input Class Initialized
INFO - 2019-07-02 15:20:19 --> Input Class Initialized
INFO - 2019-07-02 15:20:20 --> Language Class Initialized
INFO - 2019-07-02 15:20:20 --> Language Class Initialized
INFO - 2019-07-02 15:20:20 --> Language Class Initialized
INFO - 2019-07-02 15:20:20 --> Language Class Initialized
INFO - 2019-07-02 15:20:20 --> Config Class Initialized
INFO - 2019-07-02 15:20:20 --> Loader Class Initialized
INFO - 2019-07-02 15:20:20 --> Config Class Initialized
INFO - 2019-07-02 15:20:20 --> Loader Class Initialized
DEBUG - 2019-07-02 15:20:20 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-02 15:20:20 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 15:20:20 --> Helper loaded: url_helper
INFO - 2019-07-02 15:20:20 --> Helper loaded: url_helper
INFO - 2019-07-02 15:20:20 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:20:20 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:20:20 --> Helper loaded: string_helper
INFO - 2019-07-02 15:20:20 --> Helper loaded: string_helper
INFO - 2019-07-02 15:20:20 --> Helper loaded: array_helper
INFO - 2019-07-02 15:20:20 --> Helper loaded: array_helper
INFO - 2019-07-02 15:20:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:20:20 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:20:20 --> Database Driver Class Initialized
INFO - 2019-07-02 15:20:20 --> Controller Class Initialized
INFO - 2019-07-02 21:20:20 --> Helper loaded: language_helper
INFO - 2019-07-02 21:20:20 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:20:20 --> Model Class Initialized
INFO - 2019-07-02 21:20:20 --> Model Class Initialized
INFO - 2019-07-02 21:20:20 --> Model Class Initialized
INFO - 2019-07-02 21:20:20 --> Model Class Initialized
INFO - 2019-07-02 21:20:20 --> Model Class Initialized
INFO - 2019-07-02 21:20:20 --> Final output sent to browser
DEBUG - 2019-07-02 21:20:20 --> Total execution time: 0.5066
INFO - 2019-07-02 15:20:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:20:20 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:20:20 --> Database Driver Class Initialized
INFO - 2019-07-02 15:20:20 --> Controller Class Initialized
INFO - 2019-07-02 21:20:20 --> Helper loaded: language_helper
INFO - 2019-07-02 21:20:20 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:20:20 --> Model Class Initialized
INFO - 2019-07-02 21:20:20 --> Model Class Initialized
INFO - 2019-07-02 21:20:20 --> Model Class Initialized
INFO - 2019-07-02 21:20:20 --> Model Class Initialized
INFO - 2019-07-02 21:20:20 --> Final output sent to browser
DEBUG - 2019-07-02 21:20:20 --> Total execution time: 0.6464
INFO - 2019-07-02 15:21:01 --> Config Class Initialized
INFO - 2019-07-02 15:21:01 --> Config Class Initialized
INFO - 2019-07-02 15:21:01 --> Hooks Class Initialized
INFO - 2019-07-02 15:21:01 --> Hooks Class Initialized
DEBUG - 2019-07-02 15:21:01 --> UTF-8 Support Enabled
DEBUG - 2019-07-02 15:21:01 --> UTF-8 Support Enabled
INFO - 2019-07-02 15:21:01 --> Utf8 Class Initialized
INFO - 2019-07-02 15:21:01 --> Utf8 Class Initialized
INFO - 2019-07-02 15:21:01 --> URI Class Initialized
INFO - 2019-07-02 15:21:01 --> URI Class Initialized
INFO - 2019-07-02 15:21:01 --> Router Class Initialized
INFO - 2019-07-02 15:21:01 --> Router Class Initialized
INFO - 2019-07-02 15:21:01 --> Output Class Initialized
INFO - 2019-07-02 15:21:01 --> Output Class Initialized
INFO - 2019-07-02 15:21:01 --> Security Class Initialized
INFO - 2019-07-02 15:21:01 --> Security Class Initialized
DEBUG - 2019-07-02 15:21:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-02 15:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 15:21:02 --> Input Class Initialized
INFO - 2019-07-02 15:21:02 --> Input Class Initialized
INFO - 2019-07-02 15:21:02 --> Language Class Initialized
INFO - 2019-07-02 15:21:02 --> Language Class Initialized
INFO - 2019-07-02 15:21:02 --> Language Class Initialized
INFO - 2019-07-02 15:21:02 --> Language Class Initialized
INFO - 2019-07-02 15:21:02 --> Config Class Initialized
INFO - 2019-07-02 15:21:02 --> Loader Class Initialized
INFO - 2019-07-02 15:21:02 --> Config Class Initialized
INFO - 2019-07-02 15:21:02 --> Loader Class Initialized
DEBUG - 2019-07-02 15:21:02 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-02 15:21:02 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 15:21:02 --> Helper loaded: url_helper
INFO - 2019-07-02 15:21:02 --> Helper loaded: url_helper
INFO - 2019-07-02 15:21:02 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:21:02 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:21:02 --> Helper loaded: string_helper
INFO - 2019-07-02 15:21:02 --> Helper loaded: string_helper
INFO - 2019-07-02 15:21:02 --> Helper loaded: array_helper
INFO - 2019-07-02 15:21:02 --> Helper loaded: array_helper
INFO - 2019-07-02 15:21:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:21:02 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:21:02 --> Database Driver Class Initialized
INFO - 2019-07-02 15:21:02 --> Controller Class Initialized
INFO - 2019-07-02 21:21:02 --> Helper loaded: language_helper
INFO - 2019-07-02 21:21:02 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:21:02 --> Model Class Initialized
INFO - 2019-07-02 21:21:02 --> Model Class Initialized
INFO - 2019-07-02 21:21:02 --> Model Class Initialized
INFO - 2019-07-02 21:21:02 --> Model Class Initialized
INFO - 2019-07-02 21:21:02 --> Model Class Initialized
INFO - 2019-07-02 21:21:02 --> Final output sent to browser
DEBUG - 2019-07-02 21:21:02 --> Total execution time: 0.4934
INFO - 2019-07-02 15:21:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:21:02 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:21:02 --> Database Driver Class Initialized
INFO - 2019-07-02 15:21:02 --> Controller Class Initialized
INFO - 2019-07-02 21:21:02 --> Helper loaded: language_helper
INFO - 2019-07-02 21:21:02 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:21:02 --> Model Class Initialized
INFO - 2019-07-02 21:21:02 --> Model Class Initialized
INFO - 2019-07-02 21:21:02 --> Model Class Initialized
INFO - 2019-07-02 21:21:02 --> Model Class Initialized
INFO - 2019-07-02 21:21:02 --> Final output sent to browser
DEBUG - 2019-07-02 21:21:02 --> Total execution time: 0.6408
INFO - 2019-07-02 15:21:03 --> Config Class Initialized
INFO - 2019-07-02 15:21:03 --> Hooks Class Initialized
DEBUG - 2019-07-02 15:21:03 --> UTF-8 Support Enabled
INFO - 2019-07-02 15:21:03 --> Utf8 Class Initialized
INFO - 2019-07-02 15:21:03 --> URI Class Initialized
INFO - 2019-07-02 15:21:03 --> Router Class Initialized
INFO - 2019-07-02 15:21:03 --> Output Class Initialized
INFO - 2019-07-02 15:21:03 --> Security Class Initialized
DEBUG - 2019-07-02 15:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 15:21:03 --> Input Class Initialized
INFO - 2019-07-02 15:21:03 --> Language Class Initialized
INFO - 2019-07-02 15:21:03 --> Language Class Initialized
INFO - 2019-07-02 15:21:03 --> Config Class Initialized
INFO - 2019-07-02 15:21:03 --> Loader Class Initialized
DEBUG - 2019-07-02 15:21:03 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 15:21:03 --> Helper loaded: url_helper
INFO - 2019-07-02 15:21:03 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:21:03 --> Helper loaded: string_helper
INFO - 2019-07-02 15:21:03 --> Helper loaded: array_helper
INFO - 2019-07-02 15:21:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:21:03 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:21:03 --> Database Driver Class Initialized
INFO - 2019-07-02 15:21:03 --> Controller Class Initialized
INFO - 2019-07-02 21:21:03 --> Helper loaded: language_helper
INFO - 2019-07-02 21:21:03 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:21:03 --> Model Class Initialized
INFO - 2019-07-02 21:21:03 --> Model Class Initialized
INFO - 2019-07-02 21:21:03 --> Model Class Initialized
INFO - 2019-07-02 21:21:03 --> Model Class Initialized
INFO - 2019-07-02 21:21:03 --> Helper loaded: form_helper
INFO - 2019-07-02 21:21:03 --> Form Validation Class Initialized
DEBUG - 2019-07-02 21:21:03 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-02 21:21:03 --> Model Class Initialized
INFO - 2019-07-02 21:21:03 --> Model Class Initialized
INFO - 2019-07-02 21:21:03 --> Final output sent to browser
DEBUG - 2019-07-02 21:21:03 --> Total execution time: 0.5302
INFO - 2019-07-02 15:21:12 --> Config Class Initialized
INFO - 2019-07-02 15:21:12 --> Hooks Class Initialized
DEBUG - 2019-07-02 15:21:12 --> UTF-8 Support Enabled
INFO - 2019-07-02 15:21:12 --> Utf8 Class Initialized
INFO - 2019-07-02 15:21:12 --> URI Class Initialized
INFO - 2019-07-02 15:21:12 --> Router Class Initialized
INFO - 2019-07-02 15:21:12 --> Output Class Initialized
INFO - 2019-07-02 15:21:12 --> Security Class Initialized
DEBUG - 2019-07-02 15:21:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 15:21:12 --> Input Class Initialized
INFO - 2019-07-02 15:21:12 --> Config Class Initialized
INFO - 2019-07-02 15:21:12 --> Language Class Initialized
INFO - 2019-07-02 15:21:12 --> Hooks Class Initialized
DEBUG - 2019-07-02 15:21:12 --> UTF-8 Support Enabled
INFO - 2019-07-02 15:21:12 --> Language Class Initialized
INFO - 2019-07-02 15:21:12 --> Utf8 Class Initialized
INFO - 2019-07-02 15:21:12 --> Config Class Initialized
INFO - 2019-07-02 15:21:12 --> URI Class Initialized
INFO - 2019-07-02 15:21:12 --> Loader Class Initialized
DEBUG - 2019-07-02 15:21:12 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 15:21:12 --> Router Class Initialized
INFO - 2019-07-02 15:21:12 --> Helper loaded: url_helper
INFO - 2019-07-02 15:21:12 --> Output Class Initialized
INFO - 2019-07-02 15:21:12 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:21:12 --> Security Class Initialized
INFO - 2019-07-02 15:21:12 --> Helper loaded: string_helper
DEBUG - 2019-07-02 15:21:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 15:21:12 --> Helper loaded: array_helper
INFO - 2019-07-02 15:21:12 --> Input Class Initialized
INFO - 2019-07-02 15:21:12 --> Language Class Initialized
INFO - 2019-07-02 15:21:12 --> Session: Class initialized using 'files' driver.
INFO - 2019-07-02 15:21:12 --> Language Class Initialized
DEBUG - 2019-07-02 15:21:12 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:21:12 --> Config Class Initialized
INFO - 2019-07-02 15:21:12 --> Loader Class Initialized
INFO - 2019-07-02 15:21:12 --> Database Driver Class Initialized
DEBUG - 2019-07-02 15:21:12 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 15:21:12 --> Controller Class Initialized
INFO - 2019-07-02 15:21:12 --> Helper loaded: url_helper
INFO - 2019-07-02 21:21:12 --> Helper loaded: language_helper
INFO - 2019-07-02 15:21:12 --> Helper loaded: inflector_helper
INFO - 2019-07-02 21:21:12 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 15:21:12 --> Helper loaded: string_helper
INFO - 2019-07-02 21:21:12 --> Model Class Initialized
INFO - 2019-07-02 15:21:12 --> Helper loaded: array_helper
INFO - 2019-07-02 21:21:12 --> Model Class Initialized
INFO - 2019-07-02 21:21:12 --> Model Class Initialized
INFO - 2019-07-02 21:21:12 --> Model Class Initialized
INFO - 2019-07-02 21:21:12 --> Helper loaded: form_helper
INFO - 2019-07-02 21:21:12 --> Form Validation Class Initialized
DEBUG - 2019-07-02 21:21:12 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-02 21:21:12 --> Model Class Initialized
INFO - 2019-07-02 21:21:12 --> Model Class Initialized
INFO - 2019-07-02 21:21:12 --> Final output sent to browser
DEBUG - 2019-07-02 21:21:12 --> Total execution time: 0.8389
INFO - 2019-07-02 15:21:12 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:21:13 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:21:13 --> Database Driver Class Initialized
INFO - 2019-07-02 15:21:13 --> Controller Class Initialized
INFO - 2019-07-02 21:21:13 --> Helper loaded: language_helper
INFO - 2019-07-02 21:21:13 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:21:13 --> Model Class Initialized
INFO - 2019-07-02 21:21:13 --> Model Class Initialized
INFO - 2019-07-02 21:21:13 --> Model Class Initialized
INFO - 2019-07-02 21:21:13 --> Model Class Initialized
INFO - 2019-07-02 21:21:13 --> Helper loaded: form_helper
INFO - 2019-07-02 21:21:13 --> Form Validation Class Initialized
DEBUG - 2019-07-02 21:21:13 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-02 21:21:13 --> Model Class Initialized
INFO - 2019-07-02 21:21:13 --> Model Class Initialized
INFO - 2019-07-02 21:21:13 --> Final output sent to browser
DEBUG - 2019-07-02 21:21:13 --> Total execution time: 0.8019
INFO - 2019-07-02 15:21:13 --> Config Class Initialized
INFO - 2019-07-02 15:21:13 --> Config Class Initialized
INFO - 2019-07-02 15:21:13 --> Hooks Class Initialized
INFO - 2019-07-02 15:21:13 --> Hooks Class Initialized
DEBUG - 2019-07-02 15:21:14 --> UTF-8 Support Enabled
DEBUG - 2019-07-02 15:21:14 --> UTF-8 Support Enabled
INFO - 2019-07-02 15:21:14 --> Utf8 Class Initialized
INFO - 2019-07-02 15:21:14 --> Utf8 Class Initialized
INFO - 2019-07-02 15:21:14 --> URI Class Initialized
INFO - 2019-07-02 15:21:14 --> URI Class Initialized
INFO - 2019-07-02 15:21:14 --> Router Class Initialized
INFO - 2019-07-02 15:21:14 --> Router Class Initialized
INFO - 2019-07-02 15:21:14 --> Output Class Initialized
INFO - 2019-07-02 15:21:14 --> Output Class Initialized
INFO - 2019-07-02 15:21:14 --> Security Class Initialized
INFO - 2019-07-02 15:21:14 --> Security Class Initialized
DEBUG - 2019-07-02 15:21:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-02 15:21:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 15:21:14 --> Input Class Initialized
INFO - 2019-07-02 15:21:14 --> Input Class Initialized
INFO - 2019-07-02 15:21:14 --> Language Class Initialized
INFO - 2019-07-02 15:21:14 --> Language Class Initialized
INFO - 2019-07-02 15:21:14 --> Language Class Initialized
INFO - 2019-07-02 15:21:14 --> Language Class Initialized
INFO - 2019-07-02 15:21:14 --> Config Class Initialized
INFO - 2019-07-02 15:21:14 --> Config Class Initialized
INFO - 2019-07-02 15:21:14 --> Loader Class Initialized
INFO - 2019-07-02 15:21:14 --> Loader Class Initialized
DEBUG - 2019-07-02 15:21:14 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-02 15:21:14 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 15:21:14 --> Helper loaded: url_helper
INFO - 2019-07-02 15:21:14 --> Helper loaded: url_helper
INFO - 2019-07-02 15:21:14 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:21:14 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:21:14 --> Helper loaded: string_helper
INFO - 2019-07-02 15:21:14 --> Helper loaded: string_helper
INFO - 2019-07-02 15:21:14 --> Helper loaded: array_helper
INFO - 2019-07-02 15:21:14 --> Helper loaded: array_helper
INFO - 2019-07-02 15:21:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:21:14 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:21:14 --> Database Driver Class Initialized
INFO - 2019-07-02 15:21:14 --> Controller Class Initialized
INFO - 2019-07-02 21:21:14 --> Helper loaded: language_helper
INFO - 2019-07-02 21:21:14 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:21:14 --> Model Class Initialized
INFO - 2019-07-02 21:21:14 --> Model Class Initialized
INFO - 2019-07-02 21:21:14 --> Model Class Initialized
INFO - 2019-07-02 21:21:14 --> Model Class Initialized
INFO - 2019-07-02 21:21:14 --> Final output sent to browser
DEBUG - 2019-07-02 21:21:14 --> Total execution time: 0.4359
INFO - 2019-07-02 15:21:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:21:14 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:21:14 --> Database Driver Class Initialized
INFO - 2019-07-02 15:21:14 --> Controller Class Initialized
INFO - 2019-07-02 21:21:14 --> Helper loaded: language_helper
INFO - 2019-07-02 21:21:14 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:21:14 --> Model Class Initialized
INFO - 2019-07-02 21:21:14 --> Model Class Initialized
INFO - 2019-07-02 21:21:14 --> Model Class Initialized
INFO - 2019-07-02 21:21:14 --> Model Class Initialized
INFO - 2019-07-02 21:21:14 --> Model Class Initialized
INFO - 2019-07-02 21:21:14 --> Final output sent to browser
DEBUG - 2019-07-02 21:21:14 --> Total execution time: 0.6027
INFO - 2019-07-02 15:21:33 --> Config Class Initialized
INFO - 2019-07-02 15:21:33 --> Hooks Class Initialized
INFO - 2019-07-02 15:21:33 --> Config Class Initialized
INFO - 2019-07-02 15:21:33 --> Hooks Class Initialized
DEBUG - 2019-07-02 15:21:33 --> UTF-8 Support Enabled
DEBUG - 2019-07-02 15:21:33 --> UTF-8 Support Enabled
INFO - 2019-07-02 15:21:33 --> Utf8 Class Initialized
INFO - 2019-07-02 15:21:33 --> Utf8 Class Initialized
INFO - 2019-07-02 15:21:33 --> URI Class Initialized
INFO - 2019-07-02 15:21:33 --> URI Class Initialized
INFO - 2019-07-02 15:21:33 --> Router Class Initialized
INFO - 2019-07-02 15:21:33 --> Router Class Initialized
INFO - 2019-07-02 15:21:33 --> Output Class Initialized
INFO - 2019-07-02 15:21:33 --> Output Class Initialized
INFO - 2019-07-02 15:21:33 --> Security Class Initialized
INFO - 2019-07-02 15:21:33 --> Security Class Initialized
DEBUG - 2019-07-02 15:21:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 15:21:33 --> Input Class Initialized
DEBUG - 2019-07-02 15:21:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 15:21:33 --> Input Class Initialized
INFO - 2019-07-02 15:21:33 --> Language Class Initialized
INFO - 2019-07-02 15:21:33 --> Language Class Initialized
INFO - 2019-07-02 15:21:33 --> Language Class Initialized
INFO - 2019-07-02 15:21:33 --> Config Class Initialized
INFO - 2019-07-02 15:21:33 --> Language Class Initialized
INFO - 2019-07-02 15:21:33 --> Config Class Initialized
INFO - 2019-07-02 15:21:33 --> Loader Class Initialized
INFO - 2019-07-02 15:21:33 --> Loader Class Initialized
DEBUG - 2019-07-02 15:21:33 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 15:21:33 --> Helper loaded: url_helper
INFO - 2019-07-02 15:21:33 --> Helper loaded: inflector_helper
DEBUG - 2019-07-02 15:21:33 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 15:21:33 --> Helper loaded: url_helper
INFO - 2019-07-02 15:21:33 --> Helper loaded: string_helper
INFO - 2019-07-02 15:21:33 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:21:33 --> Helper loaded: array_helper
INFO - 2019-07-02 15:21:34 --> Helper loaded: string_helper
INFO - 2019-07-02 15:21:34 --> Session: Class initialized using 'files' driver.
INFO - 2019-07-02 15:21:34 --> Helper loaded: array_helper
DEBUG - 2019-07-02 15:21:34 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:21:34 --> Database Driver Class Initialized
INFO - 2019-07-02 15:21:34 --> Controller Class Initialized
INFO - 2019-07-02 21:21:34 --> Helper loaded: language_helper
INFO - 2019-07-02 21:21:34 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:21:34 --> Model Class Initialized
INFO - 2019-07-02 21:21:34 --> Model Class Initialized
INFO - 2019-07-02 21:21:34 --> Model Class Initialized
INFO - 2019-07-02 21:21:34 --> Model Class Initialized
INFO - 2019-07-02 21:21:34 --> Model Class Initialized
ERROR - 2019-07-02 21:21:34 --> Query error: Unknown column 'resto_id' in 'where clause' - Invalid query: SELECT restaurants.*, CONCAT(`owners`.`firstname`, " ", `owners`.`lastname`) AS owner_fullname FROM restaurants INNER JOIN owners AS owners ON owners.id = restaurants.owner_id   WHERE resto_id = "2" ORDER BY restaurants.id DESC 
INFO - 2019-07-02 21:21:34 --> Language file loaded: language/english/db_lang.php
INFO - 2019-07-02 15:21:34 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:21:34 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:21:34 --> Database Driver Class Initialized
INFO - 2019-07-02 15:21:34 --> Controller Class Initialized
INFO - 2019-07-02 21:21:34 --> Helper loaded: language_helper
INFO - 2019-07-02 21:21:34 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:21:34 --> Model Class Initialized
INFO - 2019-07-02 21:21:34 --> Model Class Initialized
INFO - 2019-07-02 21:21:34 --> Model Class Initialized
INFO - 2019-07-02 21:21:34 --> Model Class Initialized
INFO - 2019-07-02 21:21:34 --> Helper loaded: form_helper
INFO - 2019-07-02 21:21:34 --> Form Validation Class Initialized
DEBUG - 2019-07-02 21:21:34 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-02 21:21:34 --> Model Class Initialized
INFO - 2019-07-02 21:21:34 --> Model Class Initialized
INFO - 2019-07-02 21:21:34 --> Final output sent to browser
DEBUG - 2019-07-02 21:21:34 --> Total execution time: 0.9073
INFO - 2019-07-02 15:21:34 --> Config Class Initialized
INFO - 2019-07-02 15:21:34 --> Config Class Initialized
INFO - 2019-07-02 15:21:34 --> Hooks Class Initialized
INFO - 2019-07-02 15:21:34 --> Hooks Class Initialized
DEBUG - 2019-07-02 15:21:35 --> UTF-8 Support Enabled
DEBUG - 2019-07-02 15:21:35 --> UTF-8 Support Enabled
INFO - 2019-07-02 15:21:35 --> Utf8 Class Initialized
INFO - 2019-07-02 15:21:35 --> Utf8 Class Initialized
INFO - 2019-07-02 15:21:35 --> URI Class Initialized
INFO - 2019-07-02 15:21:35 --> URI Class Initialized
INFO - 2019-07-02 15:21:35 --> Router Class Initialized
INFO - 2019-07-02 15:21:35 --> Router Class Initialized
INFO - 2019-07-02 15:21:35 --> Output Class Initialized
INFO - 2019-07-02 15:21:35 --> Output Class Initialized
INFO - 2019-07-02 15:21:35 --> Security Class Initialized
INFO - 2019-07-02 15:21:35 --> Security Class Initialized
DEBUG - 2019-07-02 15:21:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-02 15:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 15:21:35 --> Input Class Initialized
INFO - 2019-07-02 15:21:35 --> Input Class Initialized
INFO - 2019-07-02 15:21:35 --> Language Class Initialized
INFO - 2019-07-02 15:21:35 --> Language Class Initialized
INFO - 2019-07-02 15:21:35 --> Language Class Initialized
INFO - 2019-07-02 15:21:35 --> Language Class Initialized
INFO - 2019-07-02 15:21:35 --> Config Class Initialized
INFO - 2019-07-02 15:21:35 --> Config Class Initialized
INFO - 2019-07-02 15:21:35 --> Loader Class Initialized
INFO - 2019-07-02 15:21:35 --> Loader Class Initialized
DEBUG - 2019-07-02 15:21:35 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-02 15:21:35 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 15:21:35 --> Helper loaded: url_helper
INFO - 2019-07-02 15:21:35 --> Helper loaded: url_helper
INFO - 2019-07-02 15:21:35 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:21:35 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:21:35 --> Helper loaded: string_helper
INFO - 2019-07-02 15:21:35 --> Helper loaded: string_helper
INFO - 2019-07-02 15:21:35 --> Helper loaded: array_helper
INFO - 2019-07-02 15:21:35 --> Helper loaded: array_helper
INFO - 2019-07-02 15:21:35 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:21:35 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:21:35 --> Database Driver Class Initialized
INFO - 2019-07-02 15:21:35 --> Controller Class Initialized
INFO - 2019-07-02 21:21:35 --> Helper loaded: language_helper
INFO - 2019-07-02 21:21:35 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:21:35 --> Model Class Initialized
INFO - 2019-07-02 21:21:35 --> Model Class Initialized
INFO - 2019-07-02 21:21:35 --> Model Class Initialized
INFO - 2019-07-02 21:21:35 --> Model Class Initialized
INFO - 2019-07-02 21:21:35 --> Model Class Initialized
INFO - 2019-07-02 21:21:35 --> Final output sent to browser
DEBUG - 2019-07-02 21:21:35 --> Total execution time: 0.5916
INFO - 2019-07-02 15:21:35 --> Config Class Initialized
INFO - 2019-07-02 15:21:35 --> Hooks Class Initialized
INFO - 2019-07-02 15:21:35 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:21:35 --> UTF-8 Support Enabled
INFO - 2019-07-02 15:21:35 --> Config Class Initialized
DEBUG - 2019-07-02 15:21:35 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:21:35 --> Utf8 Class Initialized
INFO - 2019-07-02 15:21:35 --> Hooks Class Initialized
INFO - 2019-07-02 15:21:35 --> URI Class Initialized
INFO - 2019-07-02 15:21:35 --> Database Driver Class Initialized
DEBUG - 2019-07-02 15:21:35 --> UTF-8 Support Enabled
INFO - 2019-07-02 15:21:35 --> Utf8 Class Initialized
INFO - 2019-07-02 15:21:35 --> Router Class Initialized
INFO - 2019-07-02 15:21:35 --> Controller Class Initialized
INFO - 2019-07-02 15:21:35 --> Output Class Initialized
INFO - 2019-07-02 21:21:35 --> Helper loaded: language_helper
INFO - 2019-07-02 15:21:35 --> URI Class Initialized
INFO - 2019-07-02 15:21:35 --> Security Class Initialized
INFO - 2019-07-02 21:21:35 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 15:21:35 --> Router Class Initialized
DEBUG - 2019-07-02 15:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 21:21:35 --> Model Class Initialized
INFO - 2019-07-02 15:21:35 --> Input Class Initialized
INFO - 2019-07-02 15:21:35 --> Output Class Initialized
INFO - 2019-07-02 21:21:35 --> Model Class Initialized
INFO - 2019-07-02 15:21:35 --> Security Class Initialized
INFO - 2019-07-02 15:21:35 --> Language Class Initialized
DEBUG - 2019-07-02 15:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 21:21:35 --> Model Class Initialized
INFO - 2019-07-02 15:21:35 --> Language Class Initialized
INFO - 2019-07-02 15:21:35 --> Input Class Initialized
INFO - 2019-07-02 15:21:35 --> Config Class Initialized
INFO - 2019-07-02 21:21:36 --> Model Class Initialized
INFO - 2019-07-02 15:21:36 --> Language Class Initialized
INFO - 2019-07-02 15:21:36 --> Loader Class Initialized
DEBUG - 2019-07-02 15:21:36 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 15:21:36 --> Language Class Initialized
INFO - 2019-07-02 21:21:36 --> Final output sent to browser
INFO - 2019-07-02 15:21:36 --> Helper loaded: url_helper
DEBUG - 2019-07-02 21:21:36 --> Total execution time: 1.0488
INFO - 2019-07-02 15:21:36 --> Config Class Initialized
INFO - 2019-07-02 15:21:36 --> Loader Class Initialized
INFO - 2019-07-02 15:21:36 --> Helper loaded: inflector_helper
DEBUG - 2019-07-02 15:21:36 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 15:21:36 --> Helper loaded: string_helper
INFO - 2019-07-02 15:21:36 --> Helper loaded: url_helper
INFO - 2019-07-02 15:21:36 --> Helper loaded: array_helper
INFO - 2019-07-02 15:21:36 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:21:36 --> Helper loaded: string_helper
INFO - 2019-07-02 15:21:36 --> Session: Class initialized using 'files' driver.
INFO - 2019-07-02 15:21:36 --> Helper loaded: array_helper
DEBUG - 2019-07-02 15:21:36 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:21:36 --> Database Driver Class Initialized
INFO - 2019-07-02 15:21:36 --> Controller Class Initialized
INFO - 2019-07-02 21:21:36 --> Helper loaded: language_helper
INFO - 2019-07-02 21:21:36 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:21:36 --> Model Class Initialized
INFO - 2019-07-02 21:21:36 --> Model Class Initialized
INFO - 2019-07-02 21:21:36 --> Model Class Initialized
INFO - 2019-07-02 21:21:36 --> Model Class Initialized
INFO - 2019-07-02 21:21:36 --> Helper loaded: form_helper
INFO - 2019-07-02 21:21:36 --> Form Validation Class Initialized
DEBUG - 2019-07-02 21:21:36 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-02 21:21:36 --> Model Class Initialized
INFO - 2019-07-02 21:21:36 --> Model Class Initialized
INFO - 2019-07-02 21:21:36 --> Final output sent to browser
DEBUG - 2019-07-02 21:21:36 --> Total execution time: 0.7579
INFO - 2019-07-02 15:21:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:21:36 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:21:36 --> Database Driver Class Initialized
INFO - 2019-07-02 15:21:36 --> Controller Class Initialized
INFO - 2019-07-02 21:21:36 --> Helper loaded: language_helper
INFO - 2019-07-02 21:21:36 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:21:36 --> Model Class Initialized
INFO - 2019-07-02 21:21:36 --> Model Class Initialized
INFO - 2019-07-02 21:21:36 --> Model Class Initialized
INFO - 2019-07-02 21:21:36 --> Model Class Initialized
INFO - 2019-07-02 21:21:36 --> Model Class Initialized
ERROR - 2019-07-02 21:21:36 --> Query error: Unknown column 'resto_id' in 'where clause' - Invalid query: SELECT restaurants.*, CONCAT(`owners`.`firstname`, " ", `owners`.`lastname`) AS owner_fullname FROM restaurants INNER JOIN owners AS owners ON owners.id = restaurants.owner_id   WHERE resto_id = "2" ORDER BY restaurants.id DESC 
INFO - 2019-07-02 21:21:36 --> Language file loaded: language/english/db_lang.php
INFO - 2019-07-02 15:22:05 --> Config Class Initialized
INFO - 2019-07-02 15:22:05 --> Hooks Class Initialized
INFO - 2019-07-02 15:22:05 --> Config Class Initialized
DEBUG - 2019-07-02 15:22:05 --> UTF-8 Support Enabled
INFO - 2019-07-02 15:22:05 --> Hooks Class Initialized
INFO - 2019-07-02 15:22:05 --> Utf8 Class Initialized
DEBUG - 2019-07-02 15:22:05 --> UTF-8 Support Enabled
INFO - 2019-07-02 15:22:05 --> URI Class Initialized
INFO - 2019-07-02 15:22:05 --> Utf8 Class Initialized
INFO - 2019-07-02 15:22:05 --> URI Class Initialized
INFO - 2019-07-02 15:22:05 --> Router Class Initialized
INFO - 2019-07-02 15:22:05 --> Router Class Initialized
INFO - 2019-07-02 15:22:05 --> Output Class Initialized
INFO - 2019-07-02 15:22:05 --> Output Class Initialized
INFO - 2019-07-02 15:22:05 --> Security Class Initialized
INFO - 2019-07-02 15:22:05 --> Security Class Initialized
DEBUG - 2019-07-02 15:22:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-02 15:22:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 15:22:05 --> Input Class Initialized
INFO - 2019-07-02 15:22:05 --> Input Class Initialized
INFO - 2019-07-02 15:22:05 --> Language Class Initialized
INFO - 2019-07-02 15:22:05 --> Language Class Initialized
INFO - 2019-07-02 15:22:05 --> Language Class Initialized
INFO - 2019-07-02 15:22:05 --> Language Class Initialized
INFO - 2019-07-02 15:22:05 --> Config Class Initialized
INFO - 2019-07-02 15:22:05 --> Config Class Initialized
INFO - 2019-07-02 15:22:05 --> Loader Class Initialized
INFO - 2019-07-02 15:22:05 --> Loader Class Initialized
DEBUG - 2019-07-02 15:22:05 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-02 15:22:05 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 15:22:05 --> Helper loaded: url_helper
INFO - 2019-07-02 15:22:05 --> Helper loaded: url_helper
INFO - 2019-07-02 15:22:05 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:22:05 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:22:05 --> Helper loaded: string_helper
INFO - 2019-07-02 15:22:05 --> Helper loaded: string_helper
INFO - 2019-07-02 15:22:05 --> Helper loaded: array_helper
INFO - 2019-07-02 15:22:05 --> Helper loaded: array_helper
INFO - 2019-07-02 15:22:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:22:05 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:22:05 --> Database Driver Class Initialized
INFO - 2019-07-02 15:22:05 --> Controller Class Initialized
INFO - 2019-07-02 21:22:05 --> Helper loaded: language_helper
INFO - 2019-07-02 21:22:05 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:22:05 --> Model Class Initialized
INFO - 2019-07-02 21:22:05 --> Model Class Initialized
INFO - 2019-07-02 21:22:05 --> Model Class Initialized
INFO - 2019-07-02 21:22:05 --> Model Class Initialized
INFO - 2019-07-02 21:22:05 --> Model Class Initialized
INFO - 2019-07-02 21:22:05 --> Final output sent to browser
DEBUG - 2019-07-02 21:22:05 --> Total execution time: 0.5089
INFO - 2019-07-02 15:22:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:22:05 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:22:05 --> Database Driver Class Initialized
INFO - 2019-07-02 15:22:05 --> Controller Class Initialized
INFO - 2019-07-02 21:22:05 --> Helper loaded: language_helper
INFO - 2019-07-02 21:22:05 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:22:05 --> Model Class Initialized
INFO - 2019-07-02 21:22:05 --> Model Class Initialized
INFO - 2019-07-02 21:22:05 --> Model Class Initialized
INFO - 2019-07-02 21:22:05 --> Model Class Initialized
INFO - 2019-07-02 21:22:05 --> Final output sent to browser
DEBUG - 2019-07-02 21:22:05 --> Total execution time: 0.6639
INFO - 2019-07-02 15:22:07 --> Config Class Initialized
INFO - 2019-07-02 15:22:07 --> Config Class Initialized
INFO - 2019-07-02 15:22:07 --> Hooks Class Initialized
INFO - 2019-07-02 15:22:07 --> Hooks Class Initialized
DEBUG - 2019-07-02 15:22:07 --> UTF-8 Support Enabled
DEBUG - 2019-07-02 15:22:07 --> UTF-8 Support Enabled
INFO - 2019-07-02 15:22:07 --> Utf8 Class Initialized
INFO - 2019-07-02 15:22:07 --> Utf8 Class Initialized
INFO - 2019-07-02 15:22:07 --> URI Class Initialized
INFO - 2019-07-02 15:22:07 --> URI Class Initialized
INFO - 2019-07-02 15:22:07 --> Router Class Initialized
INFO - 2019-07-02 15:22:07 --> Router Class Initialized
INFO - 2019-07-02 15:22:07 --> Output Class Initialized
INFO - 2019-07-02 15:22:07 --> Output Class Initialized
INFO - 2019-07-02 15:22:07 --> Security Class Initialized
INFO - 2019-07-02 15:22:07 --> Security Class Initialized
DEBUG - 2019-07-02 15:22:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-02 15:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 15:22:07 --> Input Class Initialized
INFO - 2019-07-02 15:22:07 --> Input Class Initialized
INFO - 2019-07-02 15:22:07 --> Language Class Initialized
INFO - 2019-07-02 15:22:07 --> Language Class Initialized
INFO - 2019-07-02 15:22:07 --> Language Class Initialized
INFO - 2019-07-02 15:22:07 --> Language Class Initialized
INFO - 2019-07-02 15:22:07 --> Config Class Initialized
INFO - 2019-07-02 15:22:07 --> Config Class Initialized
INFO - 2019-07-02 15:22:07 --> Loader Class Initialized
INFO - 2019-07-02 15:22:07 --> Loader Class Initialized
DEBUG - 2019-07-02 15:22:07 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-02 15:22:07 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 15:22:07 --> Helper loaded: url_helper
INFO - 2019-07-02 15:22:07 --> Helper loaded: url_helper
INFO - 2019-07-02 15:22:07 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:22:07 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:22:07 --> Helper loaded: string_helper
INFO - 2019-07-02 15:22:07 --> Helper loaded: string_helper
INFO - 2019-07-02 15:22:07 --> Helper loaded: array_helper
INFO - 2019-07-02 15:22:07 --> Helper loaded: array_helper
INFO - 2019-07-02 15:22:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:22:07 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:22:07 --> Database Driver Class Initialized
INFO - 2019-07-02 15:22:07 --> Controller Class Initialized
INFO - 2019-07-02 21:22:07 --> Helper loaded: language_helper
INFO - 2019-07-02 21:22:07 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:22:07 --> Model Class Initialized
INFO - 2019-07-02 21:22:07 --> Model Class Initialized
INFO - 2019-07-02 21:22:07 --> Model Class Initialized
INFO - 2019-07-02 21:22:07 --> Model Class Initialized
INFO - 2019-07-02 21:22:07 --> Model Class Initialized
INFO - 2019-07-02 21:22:07 --> Final output sent to browser
DEBUG - 2019-07-02 21:22:07 --> Total execution time: 0.4819
INFO - 2019-07-02 15:22:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:22:07 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:22:07 --> Database Driver Class Initialized
INFO - 2019-07-02 15:22:07 --> Controller Class Initialized
INFO - 2019-07-02 21:22:07 --> Helper loaded: language_helper
INFO - 2019-07-02 21:22:07 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:22:07 --> Model Class Initialized
INFO - 2019-07-02 21:22:07 --> Model Class Initialized
INFO - 2019-07-02 21:22:07 --> Model Class Initialized
INFO - 2019-07-02 21:22:07 --> Model Class Initialized
INFO - 2019-07-02 21:22:07 --> Helper loaded: form_helper
INFO - 2019-07-02 21:22:07 --> Form Validation Class Initialized
DEBUG - 2019-07-02 21:22:07 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-02 21:22:07 --> Model Class Initialized
INFO - 2019-07-02 21:22:07 --> Model Class Initialized
INFO - 2019-07-02 21:22:07 --> Final output sent to browser
DEBUG - 2019-07-02 21:22:07 --> Total execution time: 0.6882
INFO - 2019-07-02 15:22:11 --> Config Class Initialized
INFO - 2019-07-02 15:22:11 --> Config Class Initialized
INFO - 2019-07-02 15:22:11 --> Hooks Class Initialized
INFO - 2019-07-02 15:22:11 --> Hooks Class Initialized
DEBUG - 2019-07-02 15:22:11 --> UTF-8 Support Enabled
DEBUG - 2019-07-02 15:22:11 --> UTF-8 Support Enabled
INFO - 2019-07-02 15:22:11 --> Utf8 Class Initialized
INFO - 2019-07-02 15:22:11 --> Utf8 Class Initialized
INFO - 2019-07-02 15:22:11 --> URI Class Initialized
INFO - 2019-07-02 15:22:11 --> URI Class Initialized
INFO - 2019-07-02 15:22:11 --> Router Class Initialized
INFO - 2019-07-02 15:22:11 --> Router Class Initialized
INFO - 2019-07-02 15:22:11 --> Output Class Initialized
INFO - 2019-07-02 15:22:11 --> Output Class Initialized
INFO - 2019-07-02 15:22:11 --> Security Class Initialized
INFO - 2019-07-02 15:22:11 --> Security Class Initialized
DEBUG - 2019-07-02 15:22:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-02 15:22:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 15:22:11 --> Input Class Initialized
INFO - 2019-07-02 15:22:11 --> Input Class Initialized
INFO - 2019-07-02 15:22:11 --> Language Class Initialized
INFO - 2019-07-02 15:22:11 --> Language Class Initialized
INFO - 2019-07-02 15:22:11 --> Language Class Initialized
INFO - 2019-07-02 15:22:11 --> Language Class Initialized
INFO - 2019-07-02 15:22:11 --> Config Class Initialized
INFO - 2019-07-02 15:22:11 --> Loader Class Initialized
INFO - 2019-07-02 15:22:11 --> Config Class Initialized
INFO - 2019-07-02 15:22:11 --> Loader Class Initialized
DEBUG - 2019-07-02 15:22:11 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-02 15:22:11 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 15:22:11 --> Helper loaded: url_helper
INFO - 2019-07-02 15:22:11 --> Helper loaded: url_helper
INFO - 2019-07-02 15:22:11 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:22:11 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:22:11 --> Helper loaded: string_helper
INFO - 2019-07-02 15:22:11 --> Helper loaded: string_helper
INFO - 2019-07-02 15:22:11 --> Helper loaded: array_helper
INFO - 2019-07-02 15:22:11 --> Helper loaded: array_helper
INFO - 2019-07-02 15:22:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:22:11 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:22:11 --> Database Driver Class Initialized
INFO - 2019-07-02 15:22:11 --> Controller Class Initialized
INFO - 2019-07-02 21:22:11 --> Helper loaded: language_helper
INFO - 2019-07-02 21:22:11 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:22:11 --> Model Class Initialized
INFO - 2019-07-02 21:22:11 --> Model Class Initialized
INFO - 2019-07-02 21:22:11 --> Model Class Initialized
INFO - 2019-07-02 21:22:11 --> Model Class Initialized
INFO - 2019-07-02 21:22:11 --> Final output sent to browser
DEBUG - 2019-07-02 21:22:11 --> Total execution time: 0.5031
INFO - 2019-07-02 15:22:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:22:11 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:22:11 --> Database Driver Class Initialized
INFO - 2019-07-02 15:22:11 --> Controller Class Initialized
INFO - 2019-07-02 21:22:11 --> Helper loaded: language_helper
INFO - 2019-07-02 21:22:11 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:22:11 --> Model Class Initialized
INFO - 2019-07-02 21:22:11 --> Model Class Initialized
INFO - 2019-07-02 21:22:11 --> Model Class Initialized
INFO - 2019-07-02 21:22:11 --> Model Class Initialized
INFO - 2019-07-02 21:22:11 --> Model Class Initialized
INFO - 2019-07-02 21:22:11 --> Final output sent to browser
DEBUG - 2019-07-02 21:22:11 --> Total execution time: 0.6862
INFO - 2019-07-02 15:22:25 --> Config Class Initialized
INFO - 2019-07-02 15:22:25 --> Hooks Class Initialized
INFO - 2019-07-02 15:22:25 --> Config Class Initialized
INFO - 2019-07-02 15:22:25 --> Hooks Class Initialized
DEBUG - 2019-07-02 15:22:25 --> UTF-8 Support Enabled
DEBUG - 2019-07-02 15:22:25 --> UTF-8 Support Enabled
INFO - 2019-07-02 15:22:25 --> Utf8 Class Initialized
INFO - 2019-07-02 15:22:25 --> Utf8 Class Initialized
INFO - 2019-07-02 15:22:25 --> URI Class Initialized
INFO - 2019-07-02 15:22:25 --> URI Class Initialized
INFO - 2019-07-02 15:22:25 --> Router Class Initialized
INFO - 2019-07-02 15:22:25 --> Router Class Initialized
INFO - 2019-07-02 15:22:25 --> Output Class Initialized
INFO - 2019-07-02 15:22:25 --> Output Class Initialized
INFO - 2019-07-02 15:22:25 --> Security Class Initialized
INFO - 2019-07-02 15:22:25 --> Security Class Initialized
DEBUG - 2019-07-02 15:22:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-02 15:22:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 15:22:25 --> Input Class Initialized
INFO - 2019-07-02 15:22:25 --> Input Class Initialized
INFO - 2019-07-02 15:22:25 --> Language Class Initialized
INFO - 2019-07-02 15:22:25 --> Language Class Initialized
INFO - 2019-07-02 15:22:25 --> Language Class Initialized
INFO - 2019-07-02 15:22:25 --> Language Class Initialized
INFO - 2019-07-02 15:22:25 --> Config Class Initialized
INFO - 2019-07-02 15:22:25 --> Config Class Initialized
INFO - 2019-07-02 15:22:25 --> Loader Class Initialized
INFO - 2019-07-02 15:22:25 --> Loader Class Initialized
DEBUG - 2019-07-02 15:22:25 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-02 15:22:25 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 15:22:25 --> Helper loaded: url_helper
INFO - 2019-07-02 15:22:25 --> Helper loaded: url_helper
INFO - 2019-07-02 15:22:25 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:22:25 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:22:25 --> Helper loaded: string_helper
INFO - 2019-07-02 15:22:25 --> Helper loaded: string_helper
INFO - 2019-07-02 15:22:25 --> Helper loaded: array_helper
INFO - 2019-07-02 15:22:25 --> Helper loaded: array_helper
INFO - 2019-07-02 15:22:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:22:25 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:22:25 --> Database Driver Class Initialized
INFO - 2019-07-02 15:22:25 --> Controller Class Initialized
INFO - 2019-07-02 21:22:25 --> Helper loaded: language_helper
INFO - 2019-07-02 21:22:25 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:22:25 --> Model Class Initialized
INFO - 2019-07-02 21:22:25 --> Model Class Initialized
INFO - 2019-07-02 21:22:25 --> Model Class Initialized
INFO - 2019-07-02 21:22:25 --> Model Class Initialized
INFO - 2019-07-02 21:22:26 --> Helper loaded: form_helper
INFO - 2019-07-02 21:22:26 --> Form Validation Class Initialized
DEBUG - 2019-07-02 21:22:26 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-02 21:22:26 --> Model Class Initialized
INFO - 2019-07-02 21:22:26 --> Model Class Initialized
INFO - 2019-07-02 21:22:26 --> Final output sent to browser
DEBUG - 2019-07-02 21:22:26 --> Total execution time: 0.7106
INFO - 2019-07-02 15:22:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:22:26 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:22:26 --> Database Driver Class Initialized
INFO - 2019-07-02 15:22:26 --> Controller Class Initialized
INFO - 2019-07-02 21:22:26 --> Helper loaded: language_helper
INFO - 2019-07-02 21:22:26 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:22:26 --> Model Class Initialized
INFO - 2019-07-02 21:22:26 --> Model Class Initialized
INFO - 2019-07-02 21:22:26 --> Model Class Initialized
INFO - 2019-07-02 21:22:26 --> Model Class Initialized
INFO - 2019-07-02 21:22:26 --> Model Class Initialized
ERROR - 2019-07-02 21:22:26 --> Query error: Column 'id' in where clause is ambiguous - Invalid query: SELECT restaurants.*, CONCAT(`owners`.`firstname`, " ", `owners`.`lastname`) AS owner_fullname FROM restaurants INNER JOIN owners AS owners ON owners.id = restaurants.owner_id   WHERE id = "2" ORDER BY restaurants.id DESC 
INFO - 2019-07-02 21:22:26 --> Language file loaded: language/english/db_lang.php
INFO - 2019-07-02 15:22:40 --> Config Class Initialized
INFO - 2019-07-02 15:22:40 --> Config Class Initialized
INFO - 2019-07-02 15:22:40 --> Hooks Class Initialized
INFO - 2019-07-02 15:22:40 --> Hooks Class Initialized
DEBUG - 2019-07-02 15:22:40 --> UTF-8 Support Enabled
DEBUG - 2019-07-02 15:22:40 --> UTF-8 Support Enabled
INFO - 2019-07-02 15:22:40 --> Utf8 Class Initialized
INFO - 2019-07-02 15:22:40 --> Utf8 Class Initialized
INFO - 2019-07-02 15:22:41 --> URI Class Initialized
INFO - 2019-07-02 15:22:41 --> URI Class Initialized
INFO - 2019-07-02 15:22:41 --> Router Class Initialized
INFO - 2019-07-02 15:22:41 --> Router Class Initialized
INFO - 2019-07-02 15:22:41 --> Output Class Initialized
INFO - 2019-07-02 15:22:41 --> Output Class Initialized
INFO - 2019-07-02 15:22:41 --> Security Class Initialized
INFO - 2019-07-02 15:22:41 --> Security Class Initialized
DEBUG - 2019-07-02 15:22:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-02 15:22:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 15:22:41 --> Input Class Initialized
INFO - 2019-07-02 15:22:41 --> Input Class Initialized
INFO - 2019-07-02 15:22:41 --> Language Class Initialized
INFO - 2019-07-02 15:22:41 --> Language Class Initialized
INFO - 2019-07-02 15:22:41 --> Language Class Initialized
INFO - 2019-07-02 15:22:41 --> Language Class Initialized
INFO - 2019-07-02 15:22:41 --> Config Class Initialized
INFO - 2019-07-02 15:22:41 --> Config Class Initialized
INFO - 2019-07-02 15:22:41 --> Loader Class Initialized
INFO - 2019-07-02 15:22:41 --> Loader Class Initialized
DEBUG - 2019-07-02 15:22:41 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-02 15:22:41 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 15:22:41 --> Helper loaded: url_helper
INFO - 2019-07-02 15:22:41 --> Helper loaded: url_helper
INFO - 2019-07-02 15:22:41 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:22:41 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:22:41 --> Helper loaded: string_helper
INFO - 2019-07-02 15:22:41 --> Helper loaded: string_helper
INFO - 2019-07-02 15:22:41 --> Helper loaded: array_helper
INFO - 2019-07-02 15:22:41 --> Helper loaded: array_helper
INFO - 2019-07-02 15:22:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:22:41 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:22:41 --> Database Driver Class Initialized
INFO - 2019-07-02 15:22:41 --> Controller Class Initialized
INFO - 2019-07-02 21:22:41 --> Helper loaded: language_helper
INFO - 2019-07-02 21:22:41 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:22:41 --> Model Class Initialized
INFO - 2019-07-02 21:22:41 --> Model Class Initialized
INFO - 2019-07-02 21:22:41 --> Model Class Initialized
INFO - 2019-07-02 21:22:41 --> Model Class Initialized
INFO - 2019-07-02 21:22:41 --> Helper loaded: form_helper
INFO - 2019-07-02 21:22:41 --> Form Validation Class Initialized
DEBUG - 2019-07-02 21:22:41 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-02 21:22:41 --> Model Class Initialized
INFO - 2019-07-02 21:22:41 --> Model Class Initialized
INFO - 2019-07-02 21:22:41 --> Final output sent to browser
DEBUG - 2019-07-02 21:22:41 --> Total execution time: 0.6807
INFO - 2019-07-02 15:22:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:22:41 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:22:41 --> Database Driver Class Initialized
INFO - 2019-07-02 15:22:41 --> Controller Class Initialized
INFO - 2019-07-02 21:22:41 --> Helper loaded: language_helper
INFO - 2019-07-02 21:22:41 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:22:41 --> Model Class Initialized
INFO - 2019-07-02 21:22:41 --> Model Class Initialized
INFO - 2019-07-02 21:22:41 --> Model Class Initialized
INFO - 2019-07-02 21:22:41 --> Model Class Initialized
INFO - 2019-07-02 21:22:41 --> Model Class Initialized
INFO - 2019-07-02 21:22:41 --> Final output sent to browser
DEBUG - 2019-07-02 21:22:41 --> Total execution time: 0.8629
INFO - 2019-07-02 15:23:35 --> Config Class Initialized
INFO - 2019-07-02 15:23:35 --> Config Class Initialized
INFO - 2019-07-02 15:23:35 --> Hooks Class Initialized
INFO - 2019-07-02 15:23:35 --> Hooks Class Initialized
DEBUG - 2019-07-02 15:23:35 --> UTF-8 Support Enabled
DEBUG - 2019-07-02 15:23:35 --> UTF-8 Support Enabled
INFO - 2019-07-02 15:23:35 --> Utf8 Class Initialized
INFO - 2019-07-02 15:23:35 --> Utf8 Class Initialized
INFO - 2019-07-02 15:23:35 --> URI Class Initialized
INFO - 2019-07-02 15:23:35 --> URI Class Initialized
INFO - 2019-07-02 15:23:35 --> Router Class Initialized
INFO - 2019-07-02 15:23:35 --> Router Class Initialized
INFO - 2019-07-02 15:23:35 --> Output Class Initialized
INFO - 2019-07-02 15:23:35 --> Output Class Initialized
INFO - 2019-07-02 15:23:35 --> Security Class Initialized
INFO - 2019-07-02 15:23:35 --> Security Class Initialized
DEBUG - 2019-07-02 15:23:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-02 15:23:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 15:23:36 --> Input Class Initialized
INFO - 2019-07-02 15:23:36 --> Input Class Initialized
INFO - 2019-07-02 15:23:36 --> Language Class Initialized
INFO - 2019-07-02 15:23:36 --> Language Class Initialized
INFO - 2019-07-02 15:23:36 --> Language Class Initialized
INFO - 2019-07-02 15:23:36 --> Language Class Initialized
INFO - 2019-07-02 15:23:36 --> Config Class Initialized
INFO - 2019-07-02 15:23:36 --> Config Class Initialized
INFO - 2019-07-02 15:23:36 --> Loader Class Initialized
INFO - 2019-07-02 15:23:36 --> Loader Class Initialized
DEBUG - 2019-07-02 15:23:36 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-02 15:23:36 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 15:23:36 --> Helper loaded: url_helper
INFO - 2019-07-02 15:23:36 --> Helper loaded: url_helper
INFO - 2019-07-02 15:23:36 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:23:36 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:23:36 --> Helper loaded: string_helper
INFO - 2019-07-02 15:23:36 --> Helper loaded: string_helper
INFO - 2019-07-02 15:23:36 --> Helper loaded: array_helper
INFO - 2019-07-02 15:23:36 --> Helper loaded: array_helper
INFO - 2019-07-02 15:23:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:23:36 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:23:36 --> Database Driver Class Initialized
INFO - 2019-07-02 15:23:36 --> Controller Class Initialized
INFO - 2019-07-02 21:23:36 --> Helper loaded: language_helper
INFO - 2019-07-02 21:23:36 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:23:36 --> Model Class Initialized
INFO - 2019-07-02 21:23:36 --> Model Class Initialized
INFO - 2019-07-02 21:23:36 --> Model Class Initialized
INFO - 2019-07-02 21:23:36 --> Model Class Initialized
INFO - 2019-07-02 21:23:36 --> Helper loaded: form_helper
INFO - 2019-07-02 21:23:36 --> Form Validation Class Initialized
DEBUG - 2019-07-02 21:23:36 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-02 21:23:36 --> Model Class Initialized
INFO - 2019-07-02 21:23:36 --> Model Class Initialized
INFO - 2019-07-02 21:23:36 --> Final output sent to browser
DEBUG - 2019-07-02 21:23:36 --> Total execution time: 0.7040
INFO - 2019-07-02 15:23:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:23:36 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:23:36 --> Database Driver Class Initialized
INFO - 2019-07-02 15:23:36 --> Controller Class Initialized
INFO - 2019-07-02 21:23:36 --> Helper loaded: language_helper
INFO - 2019-07-02 21:23:36 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:23:36 --> Model Class Initialized
INFO - 2019-07-02 21:23:36 --> Model Class Initialized
INFO - 2019-07-02 21:23:36 --> Model Class Initialized
INFO - 2019-07-02 21:23:36 --> Model Class Initialized
INFO - 2019-07-02 21:23:36 --> Model Class Initialized
INFO - 2019-07-02 21:23:36 --> Final output sent to browser
DEBUG - 2019-07-02 21:23:36 --> Total execution time: 0.9419
INFO - 2019-07-02 15:25:24 --> Config Class Initialized
INFO - 2019-07-02 15:25:24 --> Config Class Initialized
INFO - 2019-07-02 15:25:24 --> Hooks Class Initialized
INFO - 2019-07-02 15:25:24 --> Hooks Class Initialized
DEBUG - 2019-07-02 15:25:24 --> UTF-8 Support Enabled
DEBUG - 2019-07-02 15:25:24 --> UTF-8 Support Enabled
INFO - 2019-07-02 15:25:24 --> Utf8 Class Initialized
INFO - 2019-07-02 15:25:24 --> Utf8 Class Initialized
INFO - 2019-07-02 15:25:24 --> URI Class Initialized
INFO - 2019-07-02 15:25:24 --> URI Class Initialized
INFO - 2019-07-02 15:25:24 --> Router Class Initialized
INFO - 2019-07-02 15:25:24 --> Router Class Initialized
INFO - 2019-07-02 15:25:24 --> Output Class Initialized
INFO - 2019-07-02 15:25:24 --> Output Class Initialized
INFO - 2019-07-02 15:25:24 --> Security Class Initialized
INFO - 2019-07-02 15:25:24 --> Security Class Initialized
DEBUG - 2019-07-02 15:25:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-02 15:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 15:25:24 --> Input Class Initialized
INFO - 2019-07-02 15:25:24 --> Input Class Initialized
INFO - 2019-07-02 15:25:24 --> Language Class Initialized
INFO - 2019-07-02 15:25:24 --> Language Class Initialized
INFO - 2019-07-02 15:25:24 --> Language Class Initialized
INFO - 2019-07-02 15:25:24 --> Language Class Initialized
INFO - 2019-07-02 15:25:24 --> Config Class Initialized
INFO - 2019-07-02 15:25:24 --> Config Class Initialized
INFO - 2019-07-02 15:25:24 --> Loader Class Initialized
INFO - 2019-07-02 15:25:24 --> Loader Class Initialized
DEBUG - 2019-07-02 15:25:24 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-02 15:25:24 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 15:25:24 --> Helper loaded: url_helper
INFO - 2019-07-02 15:25:24 --> Helper loaded: url_helper
INFO - 2019-07-02 15:25:24 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:25:24 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:25:24 --> Helper loaded: string_helper
INFO - 2019-07-02 15:25:24 --> Helper loaded: string_helper
INFO - 2019-07-02 15:25:24 --> Helper loaded: array_helper
INFO - 2019-07-02 15:25:24 --> Helper loaded: array_helper
INFO - 2019-07-02 15:25:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:25:24 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:25:24 --> Database Driver Class Initialized
INFO - 2019-07-02 15:25:24 --> Controller Class Initialized
INFO - 2019-07-02 21:25:24 --> Helper loaded: language_helper
INFO - 2019-07-02 21:25:24 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:25:24 --> Model Class Initialized
INFO - 2019-07-02 21:25:24 --> Model Class Initialized
INFO - 2019-07-02 21:25:24 --> Model Class Initialized
INFO - 2019-07-02 21:25:24 --> Model Class Initialized
INFO - 2019-07-02 21:25:24 --> Model Class Initialized
INFO - 2019-07-02 21:25:24 --> Final output sent to browser
DEBUG - 2019-07-02 21:25:24 --> Total execution time: 0.5967
INFO - 2019-07-02 15:25:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:25:24 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:25:24 --> Database Driver Class Initialized
INFO - 2019-07-02 15:25:24 --> Controller Class Initialized
INFO - 2019-07-02 21:25:24 --> Helper loaded: language_helper
INFO - 2019-07-02 21:25:25 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:25:25 --> Model Class Initialized
INFO - 2019-07-02 21:25:25 --> Model Class Initialized
INFO - 2019-07-02 21:25:25 --> Model Class Initialized
INFO - 2019-07-02 21:25:25 --> Model Class Initialized
INFO - 2019-07-02 21:25:25 --> Helper loaded: form_helper
INFO - 2019-07-02 21:25:25 --> Form Validation Class Initialized
DEBUG - 2019-07-02 21:25:25 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-02 21:25:25 --> Model Class Initialized
INFO - 2019-07-02 21:25:25 --> Model Class Initialized
INFO - 2019-07-02 21:25:25 --> Final output sent to browser
DEBUG - 2019-07-02 21:25:25 --> Total execution time: 0.8274
INFO - 2019-07-02 15:26:07 --> Config Class Initialized
INFO - 2019-07-02 15:26:07 --> Hooks Class Initialized
DEBUG - 2019-07-02 15:26:07 --> UTF-8 Support Enabled
INFO - 2019-07-02 15:26:07 --> Utf8 Class Initialized
INFO - 2019-07-02 15:26:07 --> URI Class Initialized
INFO - 2019-07-02 15:26:07 --> Router Class Initialized
INFO - 2019-07-02 15:26:07 --> Output Class Initialized
INFO - 2019-07-02 15:26:07 --> Security Class Initialized
DEBUG - 2019-07-02 15:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 15:26:07 --> Input Class Initialized
INFO - 2019-07-02 15:26:07 --> Language Class Initialized
INFO - 2019-07-02 15:26:07 --> Language Class Initialized
INFO - 2019-07-02 15:26:07 --> Config Class Initialized
INFO - 2019-07-02 15:26:07 --> Loader Class Initialized
DEBUG - 2019-07-02 15:26:07 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 15:26:07 --> Helper loaded: url_helper
INFO - 2019-07-02 15:26:07 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:26:07 --> Helper loaded: string_helper
INFO - 2019-07-02 15:26:07 --> Helper loaded: array_helper
INFO - 2019-07-02 15:26:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:26:07 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:26:07 --> Database Driver Class Initialized
INFO - 2019-07-02 15:26:07 --> Controller Class Initialized
INFO - 2019-07-02 21:26:07 --> Helper loaded: language_helper
INFO - 2019-07-02 21:26:07 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:26:08 --> Model Class Initialized
INFO - 2019-07-02 21:26:08 --> Model Class Initialized
INFO - 2019-07-02 21:26:08 --> Model Class Initialized
INFO - 2019-07-02 21:26:08 --> Model Class Initialized
INFO - 2019-07-02 21:26:08 --> Model Class Initialized
INFO - 2019-07-02 21:26:08 --> Final output sent to browser
DEBUG - 2019-07-02 21:26:08 --> Total execution time: 0.3945
INFO - 2019-07-02 15:26:14 --> Config Class Initialized
INFO - 2019-07-02 15:26:14 --> Hooks Class Initialized
DEBUG - 2019-07-02 15:26:14 --> UTF-8 Support Enabled
INFO - 2019-07-02 15:26:14 --> Utf8 Class Initialized
INFO - 2019-07-02 15:26:14 --> URI Class Initialized
INFO - 2019-07-02 15:26:14 --> Router Class Initialized
INFO - 2019-07-02 15:26:14 --> Output Class Initialized
INFO - 2019-07-02 15:26:14 --> Security Class Initialized
DEBUG - 2019-07-02 15:26:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 15:26:14 --> Input Class Initialized
INFO - 2019-07-02 15:26:14 --> Language Class Initialized
INFO - 2019-07-02 15:26:14 --> Language Class Initialized
INFO - 2019-07-02 15:26:14 --> Config Class Initialized
INFO - 2019-07-02 15:26:14 --> Loader Class Initialized
DEBUG - 2019-07-02 15:26:14 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 15:26:14 --> Helper loaded: url_helper
INFO - 2019-07-02 15:26:14 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:26:14 --> Helper loaded: string_helper
INFO - 2019-07-02 15:26:14 --> Helper loaded: array_helper
INFO - 2019-07-02 15:26:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:26:14 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:26:14 --> Database Driver Class Initialized
INFO - 2019-07-02 15:26:14 --> Controller Class Initialized
INFO - 2019-07-02 21:26:15 --> Helper loaded: language_helper
INFO - 2019-07-02 21:26:15 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:26:15 --> Model Class Initialized
INFO - 2019-07-02 21:26:15 --> Model Class Initialized
INFO - 2019-07-02 21:26:15 --> Model Class Initialized
INFO - 2019-07-02 21:26:15 --> Model Class Initialized
INFO - 2019-07-02 21:26:15 --> Helper loaded: form_helper
INFO - 2019-07-02 21:26:15 --> Form Validation Class Initialized
DEBUG - 2019-07-02 21:26:15 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-02 21:26:15 --> Model Class Initialized
INFO - 2019-07-02 21:26:15 --> Model Class Initialized
INFO - 2019-07-02 21:26:15 --> Final output sent to browser
DEBUG - 2019-07-02 21:26:15 --> Total execution time: 0.4825
INFO - 2019-07-02 15:26:15 --> Config Class Initialized
INFO - 2019-07-02 15:26:15 --> Hooks Class Initialized
DEBUG - 2019-07-02 15:26:15 --> UTF-8 Support Enabled
INFO - 2019-07-02 15:26:15 --> Utf8 Class Initialized
INFO - 2019-07-02 15:26:15 --> URI Class Initialized
INFO - 2019-07-02 15:26:15 --> Router Class Initialized
INFO - 2019-07-02 15:26:15 --> Output Class Initialized
INFO - 2019-07-02 15:26:15 --> Security Class Initialized
DEBUG - 2019-07-02 15:26:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 15:26:15 --> Input Class Initialized
INFO - 2019-07-02 15:26:15 --> Language Class Initialized
INFO - 2019-07-02 15:26:15 --> Language Class Initialized
INFO - 2019-07-02 15:26:15 --> Config Class Initialized
INFO - 2019-07-02 15:26:15 --> Loader Class Initialized
DEBUG - 2019-07-02 15:26:15 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 15:26:15 --> Helper loaded: url_helper
INFO - 2019-07-02 15:26:15 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:26:15 --> Helper loaded: string_helper
INFO - 2019-07-02 15:26:15 --> Helper loaded: array_helper
INFO - 2019-07-02 15:26:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:26:15 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:26:15 --> Database Driver Class Initialized
INFO - 2019-07-02 15:26:15 --> Controller Class Initialized
INFO - 2019-07-02 21:26:15 --> Helper loaded: language_helper
INFO - 2019-07-02 21:26:15 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:26:15 --> Model Class Initialized
INFO - 2019-07-02 21:26:15 --> Model Class Initialized
INFO - 2019-07-02 21:26:15 --> Model Class Initialized
INFO - 2019-07-02 21:26:15 --> Model Class Initialized
INFO - 2019-07-02 21:26:15 --> Helper loaded: form_helper
INFO - 2019-07-02 21:26:15 --> Form Validation Class Initialized
DEBUG - 2019-07-02 21:26:15 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-02 21:26:15 --> Model Class Initialized
INFO - 2019-07-02 21:26:15 --> Model Class Initialized
INFO - 2019-07-02 21:26:15 --> Final output sent to browser
DEBUG - 2019-07-02 21:26:15 --> Total execution time: 0.4678
INFO - 2019-07-02 15:30:50 --> Config Class Initialized
INFO - 2019-07-02 15:30:50 --> Config Class Initialized
INFO - 2019-07-02 15:30:50 --> Hooks Class Initialized
INFO - 2019-07-02 15:30:50 --> Hooks Class Initialized
DEBUG - 2019-07-02 15:30:50 --> UTF-8 Support Enabled
DEBUG - 2019-07-02 15:30:50 --> UTF-8 Support Enabled
INFO - 2019-07-02 15:30:50 --> Utf8 Class Initialized
INFO - 2019-07-02 15:30:50 --> Utf8 Class Initialized
INFO - 2019-07-02 15:30:50 --> URI Class Initialized
INFO - 2019-07-02 15:30:50 --> URI Class Initialized
INFO - 2019-07-02 15:30:50 --> Router Class Initialized
INFO - 2019-07-02 15:30:50 --> Router Class Initialized
INFO - 2019-07-02 15:30:50 --> Output Class Initialized
INFO - 2019-07-02 15:30:50 --> Security Class Initialized
INFO - 2019-07-02 15:30:50 --> Output Class Initialized
DEBUG - 2019-07-02 15:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 15:30:50 --> Security Class Initialized
INFO - 2019-07-02 15:30:50 --> Input Class Initialized
INFO - 2019-07-02 15:30:50 --> Language Class Initialized
DEBUG - 2019-07-02 15:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 15:30:50 --> Language Class Initialized
INFO - 2019-07-02 15:30:50 --> Input Class Initialized
INFO - 2019-07-02 15:30:50 --> Config Class Initialized
INFO - 2019-07-02 15:30:50 --> Language Class Initialized
INFO - 2019-07-02 15:30:50 --> Loader Class Initialized
DEBUG - 2019-07-02 15:30:50 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 15:30:50 --> Language Class Initialized
INFO - 2019-07-02 15:30:50 --> Helper loaded: url_helper
INFO - 2019-07-02 15:30:50 --> Config Class Initialized
INFO - 2019-07-02 15:30:50 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:30:50 --> Loader Class Initialized
INFO - 2019-07-02 15:30:50 --> Helper loaded: string_helper
DEBUG - 2019-07-02 15:30:50 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 15:30:50 --> Helper loaded: array_helper
INFO - 2019-07-02 15:30:50 --> Helper loaded: url_helper
INFO - 2019-07-02 15:30:50 --> Session: Class initialized using 'files' driver.
INFO - 2019-07-02 15:30:50 --> Helper loaded: inflector_helper
DEBUG - 2019-07-02 15:30:50 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:30:50 --> Helper loaded: string_helper
INFO - 2019-07-02 15:30:50 --> Database Driver Class Initialized
INFO - 2019-07-02 15:30:50 --> Helper loaded: array_helper
INFO - 2019-07-02 15:30:50 --> Controller Class Initialized
INFO - 2019-07-02 21:30:50 --> Helper loaded: language_helper
INFO - 2019-07-02 21:30:50 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:30:50 --> Model Class Initialized
INFO - 2019-07-02 21:30:50 --> Model Class Initialized
INFO - 2019-07-02 21:30:50 --> Model Class Initialized
INFO - 2019-07-02 21:30:50 --> Model Class Initialized
INFO - 2019-07-02 21:30:50 --> Model Class Initialized
INFO - 2019-07-02 21:30:50 --> Final output sent to browser
DEBUG - 2019-07-02 21:30:50 --> Total execution time: 0.6367
INFO - 2019-07-02 15:30:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:30:50 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:30:50 --> Database Driver Class Initialized
INFO - 2019-07-02 15:30:50 --> Controller Class Initialized
INFO - 2019-07-02 21:30:50 --> Helper loaded: language_helper
INFO - 2019-07-02 21:30:50 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:30:50 --> Model Class Initialized
INFO - 2019-07-02 21:30:50 --> Model Class Initialized
INFO - 2019-07-02 21:30:50 --> Model Class Initialized
INFO - 2019-07-02 21:30:50 --> Model Class Initialized
INFO - 2019-07-02 21:30:50 --> Helper loaded: form_helper
INFO - 2019-07-02 21:30:50 --> Form Validation Class Initialized
DEBUG - 2019-07-02 21:30:50 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-02 21:30:50 --> Model Class Initialized
INFO - 2019-07-02 21:30:50 --> Model Class Initialized
INFO - 2019-07-02 21:30:51 --> Final output sent to browser
DEBUG - 2019-07-02 21:30:51 --> Total execution time: 0.8830
INFO - 2019-07-02 15:30:52 --> Config Class Initialized
INFO - 2019-07-02 15:30:52 --> Hooks Class Initialized
DEBUG - 2019-07-02 15:30:52 --> UTF-8 Support Enabled
INFO - 2019-07-02 15:30:52 --> Utf8 Class Initialized
INFO - 2019-07-02 15:30:52 --> URI Class Initialized
INFO - 2019-07-02 15:30:52 --> Router Class Initialized
INFO - 2019-07-02 15:30:52 --> Output Class Initialized
INFO - 2019-07-02 15:30:52 --> Security Class Initialized
DEBUG - 2019-07-02 15:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 15:30:52 --> Input Class Initialized
INFO - 2019-07-02 15:30:52 --> Language Class Initialized
INFO - 2019-07-02 15:30:52 --> Language Class Initialized
INFO - 2019-07-02 15:30:52 --> Config Class Initialized
INFO - 2019-07-02 15:30:52 --> Loader Class Initialized
DEBUG - 2019-07-02 15:30:52 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 15:30:52 --> Helper loaded: url_helper
INFO - 2019-07-02 15:30:52 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:30:52 --> Helper loaded: string_helper
INFO - 2019-07-02 15:30:52 --> Helper loaded: array_helper
INFO - 2019-07-02 15:30:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:30:52 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:30:52 --> Database Driver Class Initialized
INFO - 2019-07-02 15:30:52 --> Controller Class Initialized
INFO - 2019-07-02 21:30:52 --> Helper loaded: language_helper
INFO - 2019-07-02 21:30:52 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:30:52 --> Model Class Initialized
INFO - 2019-07-02 21:30:52 --> Model Class Initialized
INFO - 2019-07-02 21:30:52 --> Model Class Initialized
INFO - 2019-07-02 21:30:52 --> Model Class Initialized
INFO - 2019-07-02 21:30:52 --> Model Class Initialized
INFO - 2019-07-02 21:30:52 --> Final output sent to browser
DEBUG - 2019-07-02 21:30:52 --> Total execution time: 0.4115
INFO - 2019-07-02 15:30:55 --> Config Class Initialized
INFO - 2019-07-02 15:30:55 --> Hooks Class Initialized
DEBUG - 2019-07-02 15:30:55 --> UTF-8 Support Enabled
INFO - 2019-07-02 15:30:55 --> Utf8 Class Initialized
INFO - 2019-07-02 15:30:55 --> URI Class Initialized
INFO - 2019-07-02 15:30:55 --> Router Class Initialized
INFO - 2019-07-02 15:30:55 --> Output Class Initialized
INFO - 2019-07-02 15:30:55 --> Security Class Initialized
DEBUG - 2019-07-02 15:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 15:30:55 --> Input Class Initialized
INFO - 2019-07-02 15:30:55 --> Language Class Initialized
INFO - 2019-07-02 15:30:55 --> Language Class Initialized
INFO - 2019-07-02 15:30:55 --> Config Class Initialized
INFO - 2019-07-02 15:30:55 --> Loader Class Initialized
DEBUG - 2019-07-02 15:30:55 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 15:30:55 --> Helper loaded: url_helper
INFO - 2019-07-02 15:30:55 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:30:55 --> Helper loaded: string_helper
INFO - 2019-07-02 15:30:55 --> Helper loaded: array_helper
INFO - 2019-07-02 15:30:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:30:55 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:30:55 --> Database Driver Class Initialized
INFO - 2019-07-02 15:30:55 --> Controller Class Initialized
INFO - 2019-07-02 21:30:55 --> Helper loaded: language_helper
INFO - 2019-07-02 21:30:55 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:30:55 --> Model Class Initialized
INFO - 2019-07-02 21:30:55 --> Model Class Initialized
INFO - 2019-07-02 21:30:55 --> Model Class Initialized
INFO - 2019-07-02 21:30:55 --> Model Class Initialized
INFO - 2019-07-02 21:30:55 --> Helper loaded: form_helper
INFO - 2019-07-02 21:30:55 --> Form Validation Class Initialized
DEBUG - 2019-07-02 21:30:55 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-02 21:30:55 --> Model Class Initialized
INFO - 2019-07-02 21:30:55 --> Model Class Initialized
INFO - 2019-07-02 21:30:55 --> Final output sent to browser
DEBUG - 2019-07-02 21:30:55 --> Total execution time: 0.4581
INFO - 2019-07-02 15:30:55 --> Config Class Initialized
INFO - 2019-07-02 15:30:55 --> Hooks Class Initialized
DEBUG - 2019-07-02 15:30:55 --> UTF-8 Support Enabled
INFO - 2019-07-02 15:30:55 --> Utf8 Class Initialized
INFO - 2019-07-02 15:30:55 --> URI Class Initialized
INFO - 2019-07-02 15:30:55 --> Router Class Initialized
INFO - 2019-07-02 15:30:55 --> Output Class Initialized
INFO - 2019-07-02 15:30:55 --> Security Class Initialized
DEBUG - 2019-07-02 15:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 15:30:55 --> Input Class Initialized
INFO - 2019-07-02 15:30:55 --> Language Class Initialized
INFO - 2019-07-02 15:30:55 --> Language Class Initialized
INFO - 2019-07-02 15:30:55 --> Config Class Initialized
INFO - 2019-07-02 15:30:55 --> Loader Class Initialized
DEBUG - 2019-07-02 15:30:55 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 15:30:55 --> Helper loaded: url_helper
INFO - 2019-07-02 15:30:56 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:30:56 --> Helper loaded: string_helper
INFO - 2019-07-02 15:30:56 --> Helper loaded: array_helper
INFO - 2019-07-02 15:30:56 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:30:56 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:30:56 --> Database Driver Class Initialized
INFO - 2019-07-02 15:30:56 --> Controller Class Initialized
INFO - 2019-07-02 21:30:56 --> Helper loaded: language_helper
INFO - 2019-07-02 21:30:56 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:30:56 --> Model Class Initialized
INFO - 2019-07-02 21:30:56 --> Model Class Initialized
INFO - 2019-07-02 21:30:56 --> Model Class Initialized
INFO - 2019-07-02 21:30:56 --> Model Class Initialized
INFO - 2019-07-02 21:30:56 --> Helper loaded: form_helper
INFO - 2019-07-02 21:30:56 --> Form Validation Class Initialized
DEBUG - 2019-07-02 21:30:56 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-02 21:30:56 --> Model Class Initialized
INFO - 2019-07-02 21:30:56 --> Model Class Initialized
INFO - 2019-07-02 21:30:56 --> Final output sent to browser
DEBUG - 2019-07-02 21:30:56 --> Total execution time: 0.4860
INFO - 2019-07-02 15:31:08 --> Config Class Initialized
INFO - 2019-07-02 15:31:08 --> Hooks Class Initialized
INFO - 2019-07-02 15:31:08 --> Config Class Initialized
DEBUG - 2019-07-02 15:31:08 --> UTF-8 Support Enabled
INFO - 2019-07-02 15:31:08 --> Hooks Class Initialized
INFO - 2019-07-02 15:31:08 --> Utf8 Class Initialized
DEBUG - 2019-07-02 15:31:08 --> UTF-8 Support Enabled
INFO - 2019-07-02 15:31:09 --> URI Class Initialized
INFO - 2019-07-02 15:31:09 --> Utf8 Class Initialized
INFO - 2019-07-02 15:31:09 --> URI Class Initialized
INFO - 2019-07-02 15:31:09 --> Router Class Initialized
INFO - 2019-07-02 15:31:09 --> Router Class Initialized
INFO - 2019-07-02 15:31:09 --> Output Class Initialized
INFO - 2019-07-02 15:31:09 --> Output Class Initialized
INFO - 2019-07-02 15:31:09 --> Security Class Initialized
INFO - 2019-07-02 15:31:09 --> Security Class Initialized
DEBUG - 2019-07-02 15:31:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-02 15:31:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 15:31:09 --> Input Class Initialized
INFO - 2019-07-02 15:31:09 --> Input Class Initialized
INFO - 2019-07-02 15:31:09 --> Language Class Initialized
INFO - 2019-07-02 15:31:09 --> Language Class Initialized
INFO - 2019-07-02 15:31:09 --> Language Class Initialized
INFO - 2019-07-02 15:31:09 --> Language Class Initialized
INFO - 2019-07-02 15:31:09 --> Config Class Initialized
INFO - 2019-07-02 15:31:09 --> Config Class Initialized
INFO - 2019-07-02 15:31:09 --> Loader Class Initialized
INFO - 2019-07-02 15:31:09 --> Loader Class Initialized
DEBUG - 2019-07-02 15:31:09 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-02 15:31:09 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 15:31:09 --> Helper loaded: url_helper
INFO - 2019-07-02 15:31:09 --> Helper loaded: url_helper
INFO - 2019-07-02 15:31:09 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:31:09 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:31:09 --> Helper loaded: string_helper
INFO - 2019-07-02 15:31:09 --> Helper loaded: string_helper
INFO - 2019-07-02 15:31:09 --> Helper loaded: array_helper
INFO - 2019-07-02 15:31:09 --> Helper loaded: array_helper
INFO - 2019-07-02 15:31:09 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:31:09 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:31:09 --> Database Driver Class Initialized
INFO - 2019-07-02 15:31:09 --> Controller Class Initialized
INFO - 2019-07-02 21:31:09 --> Helper loaded: language_helper
INFO - 2019-07-02 21:31:09 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:31:09 --> Model Class Initialized
INFO - 2019-07-02 21:31:09 --> Model Class Initialized
INFO - 2019-07-02 21:31:09 --> Model Class Initialized
INFO - 2019-07-02 21:31:09 --> Model Class Initialized
INFO - 2019-07-02 21:31:09 --> Model Class Initialized
INFO - 2019-07-02 21:31:09 --> Final output sent to browser
DEBUG - 2019-07-02 21:31:09 --> Total execution time: 0.6419
INFO - 2019-07-02 15:31:09 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:31:09 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:31:09 --> Database Driver Class Initialized
INFO - 2019-07-02 15:31:09 --> Controller Class Initialized
INFO - 2019-07-02 21:31:09 --> Helper loaded: language_helper
INFO - 2019-07-02 21:31:09 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:31:09 --> Model Class Initialized
INFO - 2019-07-02 21:31:09 --> Model Class Initialized
INFO - 2019-07-02 21:31:09 --> Model Class Initialized
INFO - 2019-07-02 21:31:09 --> Model Class Initialized
INFO - 2019-07-02 21:31:09 --> Helper loaded: form_helper
INFO - 2019-07-02 21:31:09 --> Form Validation Class Initialized
DEBUG - 2019-07-02 21:31:09 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-02 21:31:09 --> Model Class Initialized
INFO - 2019-07-02 21:31:09 --> Model Class Initialized
INFO - 2019-07-02 21:31:09 --> Final output sent to browser
DEBUG - 2019-07-02 21:31:09 --> Total execution time: 0.8668
INFO - 2019-07-02 15:31:45 --> Config Class Initialized
INFO - 2019-07-02 15:31:45 --> Hooks Class Initialized
DEBUG - 2019-07-02 15:31:45 --> UTF-8 Support Enabled
INFO - 2019-07-02 15:31:45 --> Utf8 Class Initialized
INFO - 2019-07-02 15:31:45 --> URI Class Initialized
INFO - 2019-07-02 15:31:45 --> Router Class Initialized
INFO - 2019-07-02 15:31:45 --> Output Class Initialized
INFO - 2019-07-02 15:31:45 --> Security Class Initialized
DEBUG - 2019-07-02 15:31:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 15:31:45 --> Input Class Initialized
INFO - 2019-07-02 15:31:45 --> Language Class Initialized
INFO - 2019-07-02 15:31:45 --> Language Class Initialized
INFO - 2019-07-02 15:31:45 --> Config Class Initialized
INFO - 2019-07-02 15:31:45 --> Loader Class Initialized
DEBUG - 2019-07-02 15:31:45 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 15:31:45 --> Helper loaded: url_helper
INFO - 2019-07-02 15:31:45 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:31:45 --> Helper loaded: string_helper
INFO - 2019-07-02 15:31:45 --> Helper loaded: array_helper
INFO - 2019-07-02 15:31:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:31:45 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:31:45 --> Database Driver Class Initialized
INFO - 2019-07-02 15:31:45 --> Controller Class Initialized
INFO - 2019-07-02 21:31:45 --> Helper loaded: language_helper
INFO - 2019-07-02 21:31:45 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:31:45 --> Model Class Initialized
INFO - 2019-07-02 21:31:45 --> Model Class Initialized
INFO - 2019-07-02 21:31:45 --> Model Class Initialized
INFO - 2019-07-02 21:31:45 --> Model Class Initialized
INFO - 2019-07-02 21:31:45 --> Model Class Initialized
INFO - 2019-07-02 21:31:45 --> Final output sent to browser
DEBUG - 2019-07-02 21:31:45 --> Total execution time: 0.4273
INFO - 2019-07-02 15:31:48 --> Config Class Initialized
INFO - 2019-07-02 15:31:48 --> Hooks Class Initialized
DEBUG - 2019-07-02 15:31:48 --> UTF-8 Support Enabled
INFO - 2019-07-02 15:31:48 --> Utf8 Class Initialized
INFO - 2019-07-02 15:31:48 --> URI Class Initialized
INFO - 2019-07-02 15:31:48 --> Router Class Initialized
INFO - 2019-07-02 15:31:48 --> Output Class Initialized
INFO - 2019-07-02 15:31:48 --> Security Class Initialized
DEBUG - 2019-07-02 15:31:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 15:31:48 --> Input Class Initialized
INFO - 2019-07-02 15:31:48 --> Language Class Initialized
INFO - 2019-07-02 15:31:48 --> Language Class Initialized
INFO - 2019-07-02 15:31:48 --> Config Class Initialized
INFO - 2019-07-02 15:31:48 --> Loader Class Initialized
DEBUG - 2019-07-02 15:31:48 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 15:31:48 --> Helper loaded: url_helper
INFO - 2019-07-02 15:31:48 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:31:48 --> Helper loaded: string_helper
INFO - 2019-07-02 15:31:48 --> Helper loaded: array_helper
INFO - 2019-07-02 15:31:48 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:31:48 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:31:48 --> Database Driver Class Initialized
INFO - 2019-07-02 15:31:48 --> Controller Class Initialized
INFO - 2019-07-02 21:31:48 --> Helper loaded: language_helper
INFO - 2019-07-02 21:31:48 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:31:48 --> Model Class Initialized
INFO - 2019-07-02 21:31:48 --> Model Class Initialized
INFO - 2019-07-02 21:31:48 --> Model Class Initialized
INFO - 2019-07-02 21:31:48 --> Model Class Initialized
INFO - 2019-07-02 21:31:48 --> Helper loaded: form_helper
INFO - 2019-07-02 21:31:48 --> Form Validation Class Initialized
DEBUG - 2019-07-02 21:31:48 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-02 21:31:48 --> Model Class Initialized
INFO - 2019-07-02 21:31:48 --> Model Class Initialized
INFO - 2019-07-02 21:31:48 --> Final output sent to browser
DEBUG - 2019-07-02 21:31:48 --> Total execution time: 0.4664
INFO - 2019-07-02 15:31:48 --> Config Class Initialized
INFO - 2019-07-02 15:31:48 --> Hooks Class Initialized
DEBUG - 2019-07-02 15:31:48 --> UTF-8 Support Enabled
INFO - 2019-07-02 15:31:48 --> Utf8 Class Initialized
INFO - 2019-07-02 15:31:48 --> URI Class Initialized
INFO - 2019-07-02 15:31:48 --> Router Class Initialized
INFO - 2019-07-02 15:31:48 --> Output Class Initialized
INFO - 2019-07-02 15:31:48 --> Security Class Initialized
DEBUG - 2019-07-02 15:31:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 15:31:48 --> Input Class Initialized
INFO - 2019-07-02 15:31:48 --> Language Class Initialized
INFO - 2019-07-02 15:31:48 --> Language Class Initialized
INFO - 2019-07-02 15:31:48 --> Config Class Initialized
INFO - 2019-07-02 15:31:48 --> Loader Class Initialized
DEBUG - 2019-07-02 15:31:48 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 15:31:48 --> Helper loaded: url_helper
INFO - 2019-07-02 15:31:48 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:31:48 --> Helper loaded: string_helper
INFO - 2019-07-02 15:31:48 --> Helper loaded: array_helper
INFO - 2019-07-02 15:31:48 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:31:49 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:31:49 --> Database Driver Class Initialized
INFO - 2019-07-02 15:31:49 --> Controller Class Initialized
INFO - 2019-07-02 21:31:49 --> Helper loaded: language_helper
INFO - 2019-07-02 21:31:49 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:31:49 --> Model Class Initialized
INFO - 2019-07-02 21:31:49 --> Model Class Initialized
INFO - 2019-07-02 21:31:49 --> Model Class Initialized
INFO - 2019-07-02 21:31:49 --> Model Class Initialized
INFO - 2019-07-02 21:31:49 --> Helper loaded: form_helper
INFO - 2019-07-02 21:31:49 --> Form Validation Class Initialized
DEBUG - 2019-07-02 21:31:49 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-02 21:31:49 --> Model Class Initialized
INFO - 2019-07-02 21:31:49 --> Model Class Initialized
INFO - 2019-07-02 21:31:49 --> Final output sent to browser
DEBUG - 2019-07-02 21:31:49 --> Total execution time: 0.4638
INFO - 2019-07-02 15:31:55 --> Config Class Initialized
INFO - 2019-07-02 15:31:55 --> Hooks Class Initialized
DEBUG - 2019-07-02 15:31:55 --> UTF-8 Support Enabled
INFO - 2019-07-02 15:31:55 --> Utf8 Class Initialized
INFO - 2019-07-02 15:31:55 --> URI Class Initialized
INFO - 2019-07-02 15:31:55 --> Router Class Initialized
INFO - 2019-07-02 15:31:55 --> Output Class Initialized
INFO - 2019-07-02 15:31:55 --> Security Class Initialized
DEBUG - 2019-07-02 15:31:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 15:31:55 --> Input Class Initialized
INFO - 2019-07-02 15:31:55 --> Language Class Initialized
INFO - 2019-07-02 15:31:55 --> Language Class Initialized
INFO - 2019-07-02 15:31:55 --> Config Class Initialized
INFO - 2019-07-02 15:31:55 --> Loader Class Initialized
DEBUG - 2019-07-02 15:31:55 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 15:31:55 --> Helper loaded: url_helper
INFO - 2019-07-02 15:31:55 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:31:55 --> Helper loaded: string_helper
INFO - 2019-07-02 15:31:55 --> Helper loaded: array_helper
INFO - 2019-07-02 15:31:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:31:55 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:31:55 --> Database Driver Class Initialized
INFO - 2019-07-02 15:31:55 --> Controller Class Initialized
INFO - 2019-07-02 21:31:55 --> Helper loaded: language_helper
INFO - 2019-07-02 21:31:55 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:31:55 --> Model Class Initialized
INFO - 2019-07-02 21:31:55 --> Model Class Initialized
INFO - 2019-07-02 21:31:55 --> Model Class Initialized
INFO - 2019-07-02 21:31:55 --> Model Class Initialized
INFO - 2019-07-02 21:31:55 --> Helper loaded: form_helper
INFO - 2019-07-02 21:31:55 --> Form Validation Class Initialized
DEBUG - 2019-07-02 21:31:55 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-02 21:31:55 --> Model Class Initialized
INFO - 2019-07-02 21:31:55 --> Model Class Initialized
INFO - 2019-07-02 21:31:55 --> Final output sent to browser
DEBUG - 2019-07-02 21:31:55 --> Total execution time: 0.4359
INFO - 2019-07-02 15:31:56 --> Config Class Initialized
INFO - 2019-07-02 15:31:56 --> Hooks Class Initialized
DEBUG - 2019-07-02 15:31:56 --> UTF-8 Support Enabled
INFO - 2019-07-02 15:31:56 --> Utf8 Class Initialized
INFO - 2019-07-02 15:31:56 --> URI Class Initialized
INFO - 2019-07-02 15:31:56 --> Router Class Initialized
INFO - 2019-07-02 15:31:56 --> Output Class Initialized
INFO - 2019-07-02 15:31:56 --> Security Class Initialized
DEBUG - 2019-07-02 15:31:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 15:31:56 --> Input Class Initialized
INFO - 2019-07-02 15:31:56 --> Language Class Initialized
INFO - 2019-07-02 15:31:56 --> Language Class Initialized
INFO - 2019-07-02 15:31:56 --> Config Class Initialized
INFO - 2019-07-02 15:31:56 --> Loader Class Initialized
DEBUG - 2019-07-02 15:31:56 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 15:31:56 --> Config Class Initialized
INFO - 2019-07-02 15:31:56 --> Hooks Class Initialized
INFO - 2019-07-02 15:31:56 --> Helper loaded: url_helper
INFO - 2019-07-02 15:31:56 --> Helper loaded: inflector_helper
DEBUG - 2019-07-02 15:31:56 --> UTF-8 Support Enabled
INFO - 2019-07-02 15:31:56 --> Helper loaded: string_helper
INFO - 2019-07-02 15:31:56 --> Utf8 Class Initialized
INFO - 2019-07-02 15:31:56 --> Helper loaded: array_helper
INFO - 2019-07-02 15:31:56 --> URI Class Initialized
INFO - 2019-07-02 15:31:56 --> Router Class Initialized
INFO - 2019-07-02 15:31:56 --> Session: Class initialized using 'files' driver.
INFO - 2019-07-02 15:31:56 --> Output Class Initialized
DEBUG - 2019-07-02 15:31:56 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:31:56 --> Security Class Initialized
INFO - 2019-07-02 15:31:56 --> Database Driver Class Initialized
DEBUG - 2019-07-02 15:31:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 15:31:56 --> Controller Class Initialized
INFO - 2019-07-02 15:31:56 --> Input Class Initialized
INFO - 2019-07-02 15:31:56 --> Config Class Initialized
INFO - 2019-07-02 15:31:56 --> Hooks Class Initialized
INFO - 2019-07-02 21:31:56 --> Helper loaded: language_helper
INFO - 2019-07-02 15:31:56 --> Language Class Initialized
DEBUG - 2019-07-02 15:31:56 --> UTF-8 Support Enabled
INFO - 2019-07-02 21:31:56 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 15:31:56 --> Language Class Initialized
INFO - 2019-07-02 15:31:56 --> Utf8 Class Initialized
INFO - 2019-07-02 15:31:56 --> Config Class Initialized
INFO - 2019-07-02 15:31:56 --> URI Class Initialized
INFO - 2019-07-02 15:31:56 --> Loader Class Initialized
INFO - 2019-07-02 21:31:56 --> Model Class Initialized
DEBUG - 2019-07-02 15:31:56 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 21:31:56 --> Model Class Initialized
INFO - 2019-07-02 15:31:56 --> Router Class Initialized
INFO - 2019-07-02 21:31:56 --> Model Class Initialized
INFO - 2019-07-02 15:31:56 --> Helper loaded: url_helper
INFO - 2019-07-02 15:31:56 --> Output Class Initialized
INFO - 2019-07-02 21:31:56 --> Model Class Initialized
INFO - 2019-07-02 15:31:56 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:31:56 --> Security Class Initialized
INFO - 2019-07-02 15:31:56 --> Config Class Initialized
INFO - 2019-07-02 21:31:56 --> Helper loaded: form_helper
INFO - 2019-07-02 15:31:56 --> Helper loaded: string_helper
INFO - 2019-07-02 15:31:56 --> Hooks Class Initialized
DEBUG - 2019-07-02 15:31:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 15:31:56 --> Helper loaded: array_helper
INFO - 2019-07-02 21:31:56 --> Form Validation Class Initialized
INFO - 2019-07-02 15:31:56 --> Input Class Initialized
DEBUG - 2019-07-02 15:31:56 --> UTF-8 Support Enabled
INFO - 2019-07-02 15:31:56 --> Language Class Initialized
INFO - 2019-07-02 15:31:56 --> Utf8 Class Initialized
DEBUG - 2019-07-02 21:31:56 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-02 15:31:56 --> URI Class Initialized
INFO - 2019-07-02 15:31:57 --> Language Class Initialized
INFO - 2019-07-02 21:31:57 --> Model Class Initialized
INFO - 2019-07-02 15:31:57 --> Router Class Initialized
INFO - 2019-07-02 15:31:57 --> Config Class Initialized
INFO - 2019-07-02 21:31:57 --> Model Class Initialized
INFO - 2019-07-02 15:31:57 --> Output Class Initialized
INFO - 2019-07-02 15:31:57 --> Loader Class Initialized
INFO - 2019-07-02 21:31:57 --> Final output sent to browser
INFO - 2019-07-02 15:31:57 --> Security Class Initialized
DEBUG - 2019-07-02 15:31:57 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-02 21:31:57 --> Total execution time: 0.6630
DEBUG - 2019-07-02 15:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 15:31:57 --> Helper loaded: url_helper
INFO - 2019-07-02 15:31:57 --> Input Class Initialized
INFO - 2019-07-02 15:31:57 --> Session: Class initialized using 'files' driver.
INFO - 2019-07-02 15:31:57 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:31:57 --> Language Class Initialized
DEBUG - 2019-07-02 15:31:57 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:31:57 --> Helper loaded: string_helper
INFO - 2019-07-02 15:31:57 --> Language Class Initialized
INFO - 2019-07-02 15:31:57 --> Database Driver Class Initialized
INFO - 2019-07-02 15:31:57 --> Helper loaded: array_helper
INFO - 2019-07-02 15:31:57 --> Config Class Initialized
INFO - 2019-07-02 15:31:57 --> Controller Class Initialized
INFO - 2019-07-02 15:31:57 --> Loader Class Initialized
DEBUG - 2019-07-02 15:31:57 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 21:31:57 --> Helper loaded: language_helper
INFO - 2019-07-02 15:31:57 --> Helper loaded: url_helper
INFO - 2019-07-02 21:31:57 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 15:31:57 --> Helper loaded: inflector_helper
INFO - 2019-07-02 21:31:57 --> Model Class Initialized
INFO - 2019-07-02 15:31:57 --> Helper loaded: string_helper
INFO - 2019-07-02 21:31:57 --> Model Class Initialized
INFO - 2019-07-02 15:31:57 --> Helper loaded: array_helper
INFO - 2019-07-02 21:31:57 --> Model Class Initialized
INFO - 2019-07-02 21:31:57 --> Model Class Initialized
INFO - 2019-07-02 21:31:57 --> Helper loaded: form_helper
INFO - 2019-07-02 21:31:57 --> Form Validation Class Initialized
DEBUG - 2019-07-02 21:31:57 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-02 21:31:57 --> Model Class Initialized
INFO - 2019-07-02 21:31:57 --> Model Class Initialized
INFO - 2019-07-02 21:31:57 --> Final output sent to browser
DEBUG - 2019-07-02 21:31:57 --> Total execution time: 0.7861
INFO - 2019-07-02 15:31:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:31:57 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:31:57 --> Database Driver Class Initialized
INFO - 2019-07-02 15:31:57 --> Controller Class Initialized
INFO - 2019-07-02 21:31:57 --> Helper loaded: language_helper
INFO - 2019-07-02 21:31:57 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:31:57 --> Model Class Initialized
INFO - 2019-07-02 21:31:57 --> Model Class Initialized
INFO - 2019-07-02 21:31:57 --> Model Class Initialized
INFO - 2019-07-02 21:31:57 --> Model Class Initialized
INFO - 2019-07-02 21:31:57 --> Helper loaded: form_helper
INFO - 2019-07-02 21:31:57 --> Form Validation Class Initialized
DEBUG - 2019-07-02 21:31:57 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-02 21:31:57 --> Model Class Initialized
INFO - 2019-07-02 21:31:57 --> Model Class Initialized
INFO - 2019-07-02 21:31:57 --> Final output sent to browser
DEBUG - 2019-07-02 21:31:57 --> Total execution time: 0.8448
INFO - 2019-07-02 15:31:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:31:57 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:31:57 --> Database Driver Class Initialized
INFO - 2019-07-02 15:31:57 --> Controller Class Initialized
INFO - 2019-07-02 21:31:57 --> Helper loaded: language_helper
INFO - 2019-07-02 21:31:57 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:31:57 --> Model Class Initialized
INFO - 2019-07-02 21:31:57 --> Model Class Initialized
INFO - 2019-07-02 21:31:57 --> Model Class Initialized
INFO - 2019-07-02 21:31:57 --> Model Class Initialized
INFO - 2019-07-02 21:31:57 --> Helper loaded: form_helper
INFO - 2019-07-02 21:31:57 --> Form Validation Class Initialized
DEBUG - 2019-07-02 21:31:57 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-02 21:31:57 --> Model Class Initialized
INFO - 2019-07-02 21:31:57 --> Model Class Initialized
INFO - 2019-07-02 21:31:57 --> Final output sent to browser
DEBUG - 2019-07-02 21:31:57 --> Total execution time: 0.9059
INFO - 2019-07-02 15:32:06 --> Config Class Initialized
INFO - 2019-07-02 15:32:06 --> Config Class Initialized
INFO - 2019-07-02 15:32:06 --> Hooks Class Initialized
INFO - 2019-07-02 15:32:06 --> Hooks Class Initialized
DEBUG - 2019-07-02 15:32:06 --> UTF-8 Support Enabled
DEBUG - 2019-07-02 15:32:06 --> UTF-8 Support Enabled
INFO - 2019-07-02 15:32:06 --> Utf8 Class Initialized
INFO - 2019-07-02 15:32:06 --> Utf8 Class Initialized
INFO - 2019-07-02 15:32:06 --> URI Class Initialized
INFO - 2019-07-02 15:32:06 --> URI Class Initialized
INFO - 2019-07-02 15:32:06 --> Router Class Initialized
INFO - 2019-07-02 15:32:06 --> Router Class Initialized
INFO - 2019-07-02 15:32:06 --> Output Class Initialized
INFO - 2019-07-02 15:32:06 --> Output Class Initialized
INFO - 2019-07-02 15:32:06 --> Security Class Initialized
INFO - 2019-07-02 15:32:06 --> Security Class Initialized
DEBUG - 2019-07-02 15:32:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-02 15:32:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 15:32:06 --> Input Class Initialized
INFO - 2019-07-02 15:32:06 --> Input Class Initialized
INFO - 2019-07-02 15:32:06 --> Language Class Initialized
INFO - 2019-07-02 15:32:06 --> Language Class Initialized
INFO - 2019-07-02 15:32:06 --> Language Class Initialized
INFO - 2019-07-02 15:32:06 --> Language Class Initialized
INFO - 2019-07-02 15:32:06 --> Config Class Initialized
INFO - 2019-07-02 15:32:06 --> Config Class Initialized
INFO - 2019-07-02 15:32:06 --> Loader Class Initialized
INFO - 2019-07-02 15:32:06 --> Loader Class Initialized
DEBUG - 2019-07-02 15:32:06 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-02 15:32:06 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 15:32:06 --> Helper loaded: url_helper
INFO - 2019-07-02 15:32:06 --> Helper loaded: url_helper
INFO - 2019-07-02 15:32:06 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:32:06 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:32:06 --> Helper loaded: string_helper
INFO - 2019-07-02 15:32:06 --> Helper loaded: string_helper
INFO - 2019-07-02 15:32:06 --> Helper loaded: array_helper
INFO - 2019-07-02 15:32:06 --> Helper loaded: array_helper
INFO - 2019-07-02 15:32:06 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:32:06 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:32:06 --> Database Driver Class Initialized
INFO - 2019-07-02 15:32:06 --> Controller Class Initialized
INFO - 2019-07-02 21:32:06 --> Helper loaded: language_helper
INFO - 2019-07-02 21:32:06 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:32:06 --> Model Class Initialized
INFO - 2019-07-02 21:32:07 --> Model Class Initialized
INFO - 2019-07-02 21:32:07 --> Model Class Initialized
INFO - 2019-07-02 21:32:07 --> Model Class Initialized
INFO - 2019-07-02 21:32:07 --> Helper loaded: form_helper
INFO - 2019-07-02 21:32:07 --> Form Validation Class Initialized
DEBUG - 2019-07-02 21:32:07 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-02 21:32:07 --> Model Class Initialized
INFO - 2019-07-02 21:32:07 --> Model Class Initialized
INFO - 2019-07-02 21:32:07 --> Final output sent to browser
DEBUG - 2019-07-02 21:32:07 --> Total execution time: 0.7579
INFO - 2019-07-02 15:32:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:32:07 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:32:07 --> Database Driver Class Initialized
INFO - 2019-07-02 15:32:07 --> Controller Class Initialized
INFO - 2019-07-02 21:32:07 --> Helper loaded: language_helper
INFO - 2019-07-02 21:32:07 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:32:07 --> Model Class Initialized
INFO - 2019-07-02 21:32:07 --> Model Class Initialized
INFO - 2019-07-02 21:32:07 --> Model Class Initialized
INFO - 2019-07-02 21:32:07 --> Model Class Initialized
INFO - 2019-07-02 21:32:07 --> Model Class Initialized
INFO - 2019-07-02 21:32:07 --> Final output sent to browser
DEBUG - 2019-07-02 21:32:07 --> Total execution time: 0.9643
INFO - 2019-07-02 15:33:23 --> Config Class Initialized
INFO - 2019-07-02 15:33:23 --> Config Class Initialized
INFO - 2019-07-02 15:33:23 --> Hooks Class Initialized
INFO - 2019-07-02 15:33:23 --> Hooks Class Initialized
DEBUG - 2019-07-02 15:33:23 --> UTF-8 Support Enabled
DEBUG - 2019-07-02 15:33:23 --> UTF-8 Support Enabled
INFO - 2019-07-02 15:33:23 --> Utf8 Class Initialized
INFO - 2019-07-02 15:33:23 --> Utf8 Class Initialized
INFO - 2019-07-02 15:33:23 --> URI Class Initialized
INFO - 2019-07-02 15:33:23 --> URI Class Initialized
INFO - 2019-07-02 15:33:23 --> Router Class Initialized
INFO - 2019-07-02 15:33:23 --> Router Class Initialized
INFO - 2019-07-02 15:33:23 --> Output Class Initialized
INFO - 2019-07-02 15:33:23 --> Output Class Initialized
INFO - 2019-07-02 15:33:23 --> Security Class Initialized
INFO - 2019-07-02 15:33:23 --> Security Class Initialized
DEBUG - 2019-07-02 15:33:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-02 15:33:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 15:33:23 --> Input Class Initialized
INFO - 2019-07-02 15:33:23 --> Input Class Initialized
INFO - 2019-07-02 15:33:23 --> Language Class Initialized
INFO - 2019-07-02 15:33:23 --> Language Class Initialized
INFO - 2019-07-02 15:33:23 --> Language Class Initialized
INFO - 2019-07-02 15:33:23 --> Language Class Initialized
INFO - 2019-07-02 15:33:23 --> Config Class Initialized
INFO - 2019-07-02 15:33:23 --> Config Class Initialized
INFO - 2019-07-02 15:33:23 --> Loader Class Initialized
INFO - 2019-07-02 15:33:23 --> Loader Class Initialized
DEBUG - 2019-07-02 15:33:23 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-02 15:33:23 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 15:33:23 --> Helper loaded: url_helper
INFO - 2019-07-02 15:33:23 --> Helper loaded: url_helper
INFO - 2019-07-02 15:33:23 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:33:23 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:33:23 --> Helper loaded: string_helper
INFO - 2019-07-02 15:33:23 --> Helper loaded: string_helper
INFO - 2019-07-02 15:33:23 --> Helper loaded: array_helper
INFO - 2019-07-02 15:33:23 --> Helper loaded: array_helper
INFO - 2019-07-02 15:33:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:33:23 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:33:23 --> Database Driver Class Initialized
INFO - 2019-07-02 15:33:23 --> Controller Class Initialized
INFO - 2019-07-02 21:33:23 --> Helper loaded: language_helper
INFO - 2019-07-02 21:33:23 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:33:23 --> Model Class Initialized
INFO - 2019-07-02 21:33:23 --> Model Class Initialized
INFO - 2019-07-02 21:33:23 --> Model Class Initialized
INFO - 2019-07-02 21:33:23 --> Model Class Initialized
INFO - 2019-07-02 21:33:23 --> Model Class Initialized
INFO - 2019-07-02 21:33:23 --> Final output sent to browser
DEBUG - 2019-07-02 21:33:23 --> Total execution time: 0.6087
INFO - 2019-07-02 15:33:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:33:23 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:33:23 --> Database Driver Class Initialized
INFO - 2019-07-02 15:33:23 --> Controller Class Initialized
INFO - 2019-07-02 21:33:23 --> Helper loaded: language_helper
INFO - 2019-07-02 21:33:23 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:33:23 --> Model Class Initialized
INFO - 2019-07-02 21:33:23 --> Model Class Initialized
INFO - 2019-07-02 21:33:23 --> Model Class Initialized
INFO - 2019-07-02 21:33:23 --> Model Class Initialized
INFO - 2019-07-02 21:33:23 --> Final output sent to browser
DEBUG - 2019-07-02 21:33:23 --> Total execution time: 0.7754
INFO - 2019-07-02 15:33:24 --> Config Class Initialized
INFO - 2019-07-02 15:33:24 --> Config Class Initialized
INFO - 2019-07-02 15:33:24 --> Hooks Class Initialized
INFO - 2019-07-02 15:33:24 --> Hooks Class Initialized
DEBUG - 2019-07-02 15:33:24 --> UTF-8 Support Enabled
DEBUG - 2019-07-02 15:33:24 --> UTF-8 Support Enabled
INFO - 2019-07-02 15:33:24 --> Utf8 Class Initialized
INFO - 2019-07-02 15:33:24 --> Utf8 Class Initialized
INFO - 2019-07-02 15:33:24 --> URI Class Initialized
INFO - 2019-07-02 15:33:24 --> URI Class Initialized
INFO - 2019-07-02 15:33:24 --> Router Class Initialized
INFO - 2019-07-02 15:33:24 --> Router Class Initialized
INFO - 2019-07-02 15:33:24 --> Output Class Initialized
INFO - 2019-07-02 15:33:24 --> Output Class Initialized
INFO - 2019-07-02 15:33:24 --> Security Class Initialized
INFO - 2019-07-02 15:33:24 --> Security Class Initialized
DEBUG - 2019-07-02 15:33:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-02 15:33:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 15:33:24 --> Input Class Initialized
INFO - 2019-07-02 15:33:24 --> Input Class Initialized
INFO - 2019-07-02 15:33:24 --> Language Class Initialized
INFO - 2019-07-02 15:33:24 --> Language Class Initialized
INFO - 2019-07-02 15:33:24 --> Language Class Initialized
INFO - 2019-07-02 15:33:24 --> Language Class Initialized
INFO - 2019-07-02 15:33:24 --> Config Class Initialized
INFO - 2019-07-02 15:33:24 --> Config Class Initialized
INFO - 2019-07-02 15:33:24 --> Loader Class Initialized
INFO - 2019-07-02 15:33:24 --> Loader Class Initialized
DEBUG - 2019-07-02 15:33:24 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-02 15:33:24 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 15:33:24 --> Helper loaded: url_helper
INFO - 2019-07-02 15:33:24 --> Helper loaded: url_helper
INFO - 2019-07-02 15:33:24 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:33:24 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:33:24 --> Helper loaded: string_helper
INFO - 2019-07-02 15:33:24 --> Helper loaded: string_helper
INFO - 2019-07-02 15:33:24 --> Helper loaded: array_helper
INFO - 2019-07-02 15:33:24 --> Helper loaded: array_helper
INFO - 2019-07-02 15:33:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:33:24 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:33:24 --> Database Driver Class Initialized
INFO - 2019-07-02 15:33:24 --> Controller Class Initialized
INFO - 2019-07-02 21:33:24 --> Helper loaded: language_helper
INFO - 2019-07-02 21:33:25 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:33:25 --> Model Class Initialized
INFO - 2019-07-02 21:33:25 --> Model Class Initialized
INFO - 2019-07-02 21:33:25 --> Model Class Initialized
INFO - 2019-07-02 21:33:25 --> Model Class Initialized
INFO - 2019-07-02 21:33:25 --> Model Class Initialized
INFO - 2019-07-02 21:33:25 --> Final output sent to browser
DEBUG - 2019-07-02 21:33:25 --> Total execution time: 0.6040
INFO - 2019-07-02 15:33:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:33:25 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:33:25 --> Database Driver Class Initialized
INFO - 2019-07-02 15:33:25 --> Controller Class Initialized
INFO - 2019-07-02 21:33:25 --> Helper loaded: language_helper
INFO - 2019-07-02 21:33:25 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:33:25 --> Model Class Initialized
INFO - 2019-07-02 21:33:25 --> Model Class Initialized
INFO - 2019-07-02 21:33:25 --> Model Class Initialized
INFO - 2019-07-02 21:33:25 --> Model Class Initialized
INFO - 2019-07-02 21:33:25 --> Helper loaded: form_helper
INFO - 2019-07-02 21:33:25 --> Form Validation Class Initialized
DEBUG - 2019-07-02 21:33:25 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-02 21:33:25 --> Model Class Initialized
INFO - 2019-07-02 21:33:25 --> Model Class Initialized
INFO - 2019-07-02 21:33:25 --> Final output sent to browser
DEBUG - 2019-07-02 21:33:25 --> Total execution time: 0.8496
INFO - 2019-07-02 15:35:32 --> Config Class Initialized
INFO - 2019-07-02 15:35:32 --> Config Class Initialized
INFO - 2019-07-02 15:35:32 --> Hooks Class Initialized
INFO - 2019-07-02 15:35:32 --> Hooks Class Initialized
DEBUG - 2019-07-02 15:35:32 --> UTF-8 Support Enabled
DEBUG - 2019-07-02 15:35:32 --> UTF-8 Support Enabled
INFO - 2019-07-02 15:35:32 --> Utf8 Class Initialized
INFO - 2019-07-02 15:35:32 --> Utf8 Class Initialized
INFO - 2019-07-02 15:35:32 --> URI Class Initialized
INFO - 2019-07-02 15:35:32 --> URI Class Initialized
INFO - 2019-07-02 15:35:32 --> Router Class Initialized
INFO - 2019-07-02 15:35:32 --> Router Class Initialized
INFO - 2019-07-02 15:35:32 --> Output Class Initialized
INFO - 2019-07-02 15:35:32 --> Output Class Initialized
INFO - 2019-07-02 15:35:32 --> Security Class Initialized
INFO - 2019-07-02 15:35:32 --> Security Class Initialized
DEBUG - 2019-07-02 15:35:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-02 15:35:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 15:35:32 --> Input Class Initialized
INFO - 2019-07-02 15:35:32 --> Input Class Initialized
INFO - 2019-07-02 15:35:32 --> Language Class Initialized
INFO - 2019-07-02 15:35:32 --> Language Class Initialized
INFO - 2019-07-02 15:35:32 --> Language Class Initialized
INFO - 2019-07-02 15:35:32 --> Language Class Initialized
INFO - 2019-07-02 15:35:32 --> Config Class Initialized
INFO - 2019-07-02 15:35:32 --> Loader Class Initialized
INFO - 2019-07-02 15:35:32 --> Config Class Initialized
INFO - 2019-07-02 15:35:32 --> Loader Class Initialized
DEBUG - 2019-07-02 15:35:32 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-02 15:35:32 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 15:35:32 --> Helper loaded: url_helper
INFO - 2019-07-02 15:35:32 --> Helper loaded: url_helper
INFO - 2019-07-02 15:35:32 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:35:32 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:35:32 --> Helper loaded: string_helper
INFO - 2019-07-02 15:35:32 --> Helper loaded: string_helper
INFO - 2019-07-02 15:35:32 --> Helper loaded: array_helper
INFO - 2019-07-02 15:35:32 --> Helper loaded: array_helper
INFO - 2019-07-02 15:35:32 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:35:32 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:35:32 --> Database Driver Class Initialized
INFO - 2019-07-02 15:35:32 --> Controller Class Initialized
INFO - 2019-07-02 21:35:32 --> Helper loaded: language_helper
INFO - 2019-07-02 21:35:32 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:35:32 --> Model Class Initialized
INFO - 2019-07-02 21:35:32 --> Model Class Initialized
INFO - 2019-07-02 21:35:32 --> Model Class Initialized
INFO - 2019-07-02 21:35:32 --> Model Class Initialized
INFO - 2019-07-02 21:35:32 --> Model Class Initialized
INFO - 2019-07-02 21:35:32 --> Final output sent to browser
DEBUG - 2019-07-02 21:35:32 --> Total execution time: 0.5547
INFO - 2019-07-02 15:35:32 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:35:32 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:35:32 --> Database Driver Class Initialized
INFO - 2019-07-02 15:35:32 --> Controller Class Initialized
INFO - 2019-07-02 21:35:32 --> Helper loaded: language_helper
INFO - 2019-07-02 21:35:32 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:35:32 --> Model Class Initialized
INFO - 2019-07-02 21:35:32 --> Model Class Initialized
INFO - 2019-07-02 21:35:32 --> Model Class Initialized
INFO - 2019-07-02 21:35:32 --> Model Class Initialized
INFO - 2019-07-02 21:35:32 --> Final output sent to browser
DEBUG - 2019-07-02 21:35:32 --> Total execution time: 0.7234
INFO - 2019-07-02 15:35:33 --> Config Class Initialized
INFO - 2019-07-02 15:35:33 --> Config Class Initialized
INFO - 2019-07-02 15:35:33 --> Hooks Class Initialized
INFO - 2019-07-02 15:35:33 --> Hooks Class Initialized
DEBUG - 2019-07-02 15:35:33 --> UTF-8 Support Enabled
DEBUG - 2019-07-02 15:35:33 --> UTF-8 Support Enabled
INFO - 2019-07-02 15:35:33 --> Utf8 Class Initialized
INFO - 2019-07-02 15:35:33 --> Utf8 Class Initialized
INFO - 2019-07-02 15:35:33 --> URI Class Initialized
INFO - 2019-07-02 15:35:33 --> URI Class Initialized
INFO - 2019-07-02 15:35:33 --> Router Class Initialized
INFO - 2019-07-02 15:35:33 --> Router Class Initialized
INFO - 2019-07-02 15:35:33 --> Output Class Initialized
INFO - 2019-07-02 15:35:33 --> Output Class Initialized
INFO - 2019-07-02 15:35:33 --> Security Class Initialized
INFO - 2019-07-02 15:35:33 --> Security Class Initialized
DEBUG - 2019-07-02 15:35:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-02 15:35:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 15:35:33 --> Input Class Initialized
INFO - 2019-07-02 15:35:33 --> Input Class Initialized
INFO - 2019-07-02 15:35:33 --> Language Class Initialized
INFO - 2019-07-02 15:35:33 --> Language Class Initialized
INFO - 2019-07-02 15:35:33 --> Language Class Initialized
INFO - 2019-07-02 15:35:33 --> Language Class Initialized
INFO - 2019-07-02 15:35:33 --> Config Class Initialized
INFO - 2019-07-02 15:35:33 --> Config Class Initialized
INFO - 2019-07-02 15:35:33 --> Loader Class Initialized
INFO - 2019-07-02 15:35:34 --> Loader Class Initialized
DEBUG - 2019-07-02 15:35:34 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-02 15:35:34 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 15:35:34 --> Helper loaded: url_helper
INFO - 2019-07-02 15:35:34 --> Helper loaded: url_helper
INFO - 2019-07-02 15:35:34 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:35:34 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:35:34 --> Helper loaded: string_helper
INFO - 2019-07-02 15:35:34 --> Helper loaded: string_helper
INFO - 2019-07-02 15:35:34 --> Helper loaded: array_helper
INFO - 2019-07-02 15:35:34 --> Helper loaded: array_helper
INFO - 2019-07-02 15:35:34 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:35:34 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:35:34 --> Database Driver Class Initialized
INFO - 2019-07-02 15:35:34 --> Controller Class Initialized
INFO - 2019-07-02 21:35:34 --> Helper loaded: language_helper
INFO - 2019-07-02 21:35:34 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:35:34 --> Model Class Initialized
INFO - 2019-07-02 21:35:34 --> Model Class Initialized
INFO - 2019-07-02 21:35:34 --> Model Class Initialized
INFO - 2019-07-02 21:35:34 --> Model Class Initialized
INFO - 2019-07-02 21:35:34 --> Model Class Initialized
INFO - 2019-07-02 21:35:34 --> Final output sent to browser
DEBUG - 2019-07-02 21:35:34 --> Total execution time: 0.7613
INFO - 2019-07-02 15:35:34 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:35:34 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:35:34 --> Database Driver Class Initialized
INFO - 2019-07-02 15:35:34 --> Controller Class Initialized
INFO - 2019-07-02 21:35:34 --> Helper loaded: language_helper
INFO - 2019-07-02 21:35:34 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:35:34 --> Model Class Initialized
INFO - 2019-07-02 21:35:34 --> Model Class Initialized
INFO - 2019-07-02 21:35:34 --> Model Class Initialized
INFO - 2019-07-02 21:35:34 --> Model Class Initialized
INFO - 2019-07-02 21:35:34 --> Helper loaded: form_helper
INFO - 2019-07-02 21:35:34 --> Form Validation Class Initialized
DEBUG - 2019-07-02 21:35:34 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-02 21:35:34 --> Model Class Initialized
INFO - 2019-07-02 21:35:34 --> Model Class Initialized
INFO - 2019-07-02 21:35:34 --> Final output sent to browser
DEBUG - 2019-07-02 21:35:34 --> Total execution time: 0.9932
INFO - 2019-07-02 15:36:11 --> Config Class Initialized
INFO - 2019-07-02 15:36:11 --> Config Class Initialized
INFO - 2019-07-02 15:36:11 --> Hooks Class Initialized
INFO - 2019-07-02 15:36:11 --> Hooks Class Initialized
DEBUG - 2019-07-02 15:36:11 --> UTF-8 Support Enabled
INFO - 2019-07-02 15:36:11 --> Utf8 Class Initialized
DEBUG - 2019-07-02 15:36:11 --> UTF-8 Support Enabled
INFO - 2019-07-02 15:36:11 --> URI Class Initialized
INFO - 2019-07-02 15:36:11 --> Utf8 Class Initialized
INFO - 2019-07-02 15:36:11 --> URI Class Initialized
INFO - 2019-07-02 15:36:11 --> Router Class Initialized
INFO - 2019-07-02 15:36:11 --> Router Class Initialized
INFO - 2019-07-02 15:36:11 --> Output Class Initialized
INFO - 2019-07-02 15:36:11 --> Output Class Initialized
INFO - 2019-07-02 15:36:11 --> Security Class Initialized
INFO - 2019-07-02 15:36:11 --> Security Class Initialized
DEBUG - 2019-07-02 15:36:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-02 15:36:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 15:36:11 --> Input Class Initialized
INFO - 2019-07-02 15:36:11 --> Input Class Initialized
INFO - 2019-07-02 15:36:11 --> Language Class Initialized
INFO - 2019-07-02 15:36:11 --> Language Class Initialized
INFO - 2019-07-02 15:36:11 --> Language Class Initialized
INFO - 2019-07-02 15:36:11 --> Language Class Initialized
INFO - 2019-07-02 15:36:11 --> Config Class Initialized
INFO - 2019-07-02 15:36:11 --> Config Class Initialized
INFO - 2019-07-02 15:36:11 --> Loader Class Initialized
INFO - 2019-07-02 15:36:11 --> Loader Class Initialized
DEBUG - 2019-07-02 15:36:11 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-02 15:36:11 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 15:36:11 --> Helper loaded: url_helper
INFO - 2019-07-02 15:36:11 --> Helper loaded: url_helper
INFO - 2019-07-02 15:36:11 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:36:11 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:36:11 --> Helper loaded: string_helper
INFO - 2019-07-02 15:36:11 --> Helper loaded: string_helper
INFO - 2019-07-02 15:36:11 --> Helper loaded: array_helper
INFO - 2019-07-02 15:36:11 --> Helper loaded: array_helper
INFO - 2019-07-02 15:36:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:36:11 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:36:11 --> Database Driver Class Initialized
INFO - 2019-07-02 15:36:11 --> Controller Class Initialized
INFO - 2019-07-02 21:36:11 --> Helper loaded: language_helper
INFO - 2019-07-02 21:36:11 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:36:11 --> Model Class Initialized
INFO - 2019-07-02 21:36:11 --> Model Class Initialized
INFO - 2019-07-02 21:36:11 --> Model Class Initialized
INFO - 2019-07-02 21:36:11 --> Model Class Initialized
INFO - 2019-07-02 21:36:11 --> Model Class Initialized
INFO - 2019-07-02 21:36:11 --> Final output sent to browser
DEBUG - 2019-07-02 21:36:11 --> Total execution time: 0.5870
INFO - 2019-07-02 15:36:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:36:11 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:36:11 --> Database Driver Class Initialized
INFO - 2019-07-02 15:36:11 --> Controller Class Initialized
INFO - 2019-07-02 21:36:11 --> Helper loaded: language_helper
INFO - 2019-07-02 21:36:11 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:36:11 --> Model Class Initialized
INFO - 2019-07-02 21:36:11 --> Model Class Initialized
INFO - 2019-07-02 21:36:11 --> Model Class Initialized
INFO - 2019-07-02 21:36:11 --> Model Class Initialized
INFO - 2019-07-02 21:36:11 --> Final output sent to browser
DEBUG - 2019-07-02 21:36:12 --> Total execution time: 0.7527
INFO - 2019-07-02 15:36:23 --> Config Class Initialized
INFO - 2019-07-02 15:36:23 --> Config Class Initialized
INFO - 2019-07-02 15:36:23 --> Hooks Class Initialized
INFO - 2019-07-02 15:36:23 --> Hooks Class Initialized
DEBUG - 2019-07-02 15:36:23 --> UTF-8 Support Enabled
DEBUG - 2019-07-02 15:36:23 --> UTF-8 Support Enabled
INFO - 2019-07-02 15:36:23 --> Utf8 Class Initialized
INFO - 2019-07-02 15:36:23 --> Utf8 Class Initialized
INFO - 2019-07-02 15:36:23 --> URI Class Initialized
INFO - 2019-07-02 15:36:23 --> URI Class Initialized
INFO - 2019-07-02 15:36:23 --> Router Class Initialized
INFO - 2019-07-02 15:36:23 --> Router Class Initialized
INFO - 2019-07-02 15:36:23 --> Output Class Initialized
INFO - 2019-07-02 15:36:23 --> Output Class Initialized
INFO - 2019-07-02 15:36:23 --> Security Class Initialized
INFO - 2019-07-02 15:36:23 --> Security Class Initialized
DEBUG - 2019-07-02 15:36:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-02 15:36:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 15:36:23 --> Input Class Initialized
INFO - 2019-07-02 15:36:23 --> Input Class Initialized
INFO - 2019-07-02 15:36:23 --> Language Class Initialized
INFO - 2019-07-02 15:36:23 --> Language Class Initialized
INFO - 2019-07-02 15:36:23 --> Language Class Initialized
INFO - 2019-07-02 15:36:23 --> Language Class Initialized
INFO - 2019-07-02 15:36:23 --> Config Class Initialized
INFO - 2019-07-02 15:36:23 --> Loader Class Initialized
INFO - 2019-07-02 15:36:23 --> Config Class Initialized
INFO - 2019-07-02 15:36:23 --> Loader Class Initialized
DEBUG - 2019-07-02 15:36:23 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-02 15:36:23 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 15:36:23 --> Helper loaded: url_helper
INFO - 2019-07-02 15:36:23 --> Helper loaded: url_helper
INFO - 2019-07-02 15:36:23 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:36:23 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:36:23 --> Helper loaded: string_helper
INFO - 2019-07-02 15:36:23 --> Helper loaded: string_helper
INFO - 2019-07-02 15:36:23 --> Helper loaded: array_helper
INFO - 2019-07-02 15:36:23 --> Helper loaded: array_helper
INFO - 2019-07-02 15:36:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:36:23 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:36:23 --> Database Driver Class Initialized
INFO - 2019-07-02 15:36:23 --> Controller Class Initialized
INFO - 2019-07-02 21:36:23 --> Helper loaded: language_helper
INFO - 2019-07-02 21:36:23 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:36:23 --> Model Class Initialized
INFO - 2019-07-02 21:36:23 --> Model Class Initialized
INFO - 2019-07-02 21:36:23 --> Model Class Initialized
INFO - 2019-07-02 21:36:23 --> Model Class Initialized
INFO - 2019-07-02 21:36:23 --> Final output sent to browser
DEBUG - 2019-07-02 21:36:23 --> Total execution time: 0.5611
INFO - 2019-07-02 15:36:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:36:23 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:36:23 --> Database Driver Class Initialized
INFO - 2019-07-02 15:36:23 --> Controller Class Initialized
INFO - 2019-07-02 21:36:23 --> Helper loaded: language_helper
INFO - 2019-07-02 21:36:23 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:36:23 --> Model Class Initialized
INFO - 2019-07-02 21:36:23 --> Model Class Initialized
INFO - 2019-07-02 21:36:23 --> Model Class Initialized
INFO - 2019-07-02 21:36:23 --> Model Class Initialized
INFO - 2019-07-02 21:36:24 --> Model Class Initialized
INFO - 2019-07-02 21:36:24 --> Final output sent to browser
DEBUG - 2019-07-02 21:36:24 --> Total execution time: 0.7561
INFO - 2019-07-02 15:36:24 --> Config Class Initialized
INFO - 2019-07-02 15:36:24 --> Config Class Initialized
INFO - 2019-07-02 15:36:24 --> Hooks Class Initialized
INFO - 2019-07-02 15:36:24 --> Hooks Class Initialized
DEBUG - 2019-07-02 15:36:24 --> UTF-8 Support Enabled
INFO - 2019-07-02 15:36:24 --> Utf8 Class Initialized
INFO - 2019-07-02 15:36:24 --> URI Class Initialized
DEBUG - 2019-07-02 15:36:24 --> UTF-8 Support Enabled
INFO - 2019-07-02 15:36:24 --> Utf8 Class Initialized
INFO - 2019-07-02 15:36:24 --> Router Class Initialized
INFO - 2019-07-02 15:36:24 --> URI Class Initialized
INFO - 2019-07-02 15:36:24 --> Output Class Initialized
INFO - 2019-07-02 15:36:24 --> Router Class Initialized
INFO - 2019-07-02 15:36:24 --> Security Class Initialized
INFO - 2019-07-02 15:36:24 --> Output Class Initialized
DEBUG - 2019-07-02 15:36:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 15:36:24 --> Security Class Initialized
INFO - 2019-07-02 15:36:24 --> Input Class Initialized
INFO - 2019-07-02 15:36:25 --> Language Class Initialized
DEBUG - 2019-07-02 15:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 15:36:25 --> Language Class Initialized
INFO - 2019-07-02 15:36:25 --> Input Class Initialized
INFO - 2019-07-02 15:36:25 --> Config Class Initialized
INFO - 2019-07-02 15:36:25 --> Language Class Initialized
INFO - 2019-07-02 15:36:25 --> Loader Class Initialized
DEBUG - 2019-07-02 15:36:25 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 15:36:25 --> Language Class Initialized
INFO - 2019-07-02 15:36:25 --> Helper loaded: url_helper
INFO - 2019-07-02 15:36:25 --> Config Class Initialized
INFO - 2019-07-02 15:36:25 --> Loader Class Initialized
INFO - 2019-07-02 15:36:25 --> Helper loaded: inflector_helper
DEBUG - 2019-07-02 15:36:25 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 15:36:25 --> Helper loaded: string_helper
INFO - 2019-07-02 15:36:25 --> Helper loaded: url_helper
INFO - 2019-07-02 15:36:25 --> Helper loaded: array_helper
INFO - 2019-07-02 15:36:25 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:36:25 --> Session: Class initialized using 'files' driver.
INFO - 2019-07-02 15:36:25 --> Helper loaded: string_helper
DEBUG - 2019-07-02 15:36:25 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:36:25 --> Helper loaded: array_helper
INFO - 2019-07-02 15:36:25 --> Database Driver Class Initialized
INFO - 2019-07-02 15:36:25 --> Controller Class Initialized
INFO - 2019-07-02 21:36:25 --> Helper loaded: language_helper
INFO - 2019-07-02 21:36:25 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:36:25 --> Model Class Initialized
INFO - 2019-07-02 21:36:25 --> Model Class Initialized
INFO - 2019-07-02 21:36:25 --> Model Class Initialized
INFO - 2019-07-02 21:36:25 --> Model Class Initialized
INFO - 2019-07-02 21:36:25 --> Helper loaded: form_helper
INFO - 2019-07-02 21:36:25 --> Form Validation Class Initialized
DEBUG - 2019-07-02 21:36:25 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-02 21:36:25 --> Model Class Initialized
INFO - 2019-07-02 21:36:25 --> Model Class Initialized
INFO - 2019-07-02 21:36:25 --> Final output sent to browser
DEBUG - 2019-07-02 21:36:25 --> Total execution time: 0.7288
INFO - 2019-07-02 15:36:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:36:25 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:36:25 --> Database Driver Class Initialized
INFO - 2019-07-02 15:36:25 --> Controller Class Initialized
INFO - 2019-07-02 21:36:25 --> Helper loaded: language_helper
INFO - 2019-07-02 21:36:25 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:36:25 --> Model Class Initialized
INFO - 2019-07-02 21:36:25 --> Model Class Initialized
INFO - 2019-07-02 21:36:25 --> Model Class Initialized
INFO - 2019-07-02 21:36:25 --> Model Class Initialized
INFO - 2019-07-02 21:36:25 --> Model Class Initialized
INFO - 2019-07-02 21:36:25 --> Final output sent to browser
DEBUG - 2019-07-02 21:36:25 --> Total execution time: 0.9232
INFO - 2019-07-02 15:36:30 --> Config Class Initialized
INFO - 2019-07-02 15:36:30 --> Hooks Class Initialized
INFO - 2019-07-02 15:36:30 --> Config Class Initialized
DEBUG - 2019-07-02 15:36:30 --> UTF-8 Support Enabled
INFO - 2019-07-02 15:36:30 --> Hooks Class Initialized
INFO - 2019-07-02 15:36:30 --> Utf8 Class Initialized
INFO - 2019-07-02 15:36:30 --> URI Class Initialized
DEBUG - 2019-07-02 15:36:30 --> UTF-8 Support Enabled
INFO - 2019-07-02 15:36:30 --> Router Class Initialized
INFO - 2019-07-02 15:36:30 --> Utf8 Class Initialized
INFO - 2019-07-02 15:36:30 --> URI Class Initialized
INFO - 2019-07-02 15:36:30 --> Router Class Initialized
INFO - 2019-07-02 15:36:30 --> Output Class Initialized
INFO - 2019-07-02 15:36:30 --> Output Class Initialized
INFO - 2019-07-02 15:36:30 --> Security Class Initialized
INFO - 2019-07-02 15:36:30 --> Security Class Initialized
DEBUG - 2019-07-02 15:36:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-02 15:36:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 15:36:30 --> Input Class Initialized
INFO - 2019-07-02 15:36:30 --> Input Class Initialized
INFO - 2019-07-02 15:36:30 --> Language Class Initialized
INFO - 2019-07-02 15:36:30 --> Language Class Initialized
INFO - 2019-07-02 15:36:30 --> Language Class Initialized
INFO - 2019-07-02 15:36:31 --> Language Class Initialized
INFO - 2019-07-02 15:36:31 --> Config Class Initialized
INFO - 2019-07-02 15:36:31 --> Config Class Initialized
INFO - 2019-07-02 15:36:31 --> Loader Class Initialized
INFO - 2019-07-02 15:36:31 --> Loader Class Initialized
DEBUG - 2019-07-02 15:36:31 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-02 15:36:31 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 15:36:31 --> Helper loaded: url_helper
INFO - 2019-07-02 15:36:31 --> Helper loaded: url_helper
INFO - 2019-07-02 15:36:31 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:36:31 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:36:31 --> Helper loaded: string_helper
INFO - 2019-07-02 15:36:31 --> Helper loaded: string_helper
INFO - 2019-07-02 15:36:31 --> Helper loaded: array_helper
INFO - 2019-07-02 15:36:31 --> Helper loaded: array_helper
INFO - 2019-07-02 15:36:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:36:31 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:36:31 --> Database Driver Class Initialized
INFO - 2019-07-02 15:36:31 --> Controller Class Initialized
INFO - 2019-07-02 21:36:31 --> Helper loaded: language_helper
INFO - 2019-07-02 21:36:31 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:36:31 --> Model Class Initialized
INFO - 2019-07-02 21:36:31 --> Model Class Initialized
INFO - 2019-07-02 21:36:31 --> Model Class Initialized
INFO - 2019-07-02 21:36:31 --> Model Class Initialized
INFO - 2019-07-02 21:36:31 --> Model Class Initialized
INFO - 2019-07-02 21:36:31 --> Final output sent to browser
DEBUG - 2019-07-02 21:36:31 --> Total execution time: 0.7347
INFO - 2019-07-02 15:36:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:36:31 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:36:31 --> Database Driver Class Initialized
INFO - 2019-07-02 15:36:31 --> Controller Class Initialized
INFO - 2019-07-02 21:36:31 --> Helper loaded: language_helper
INFO - 2019-07-02 21:36:31 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:36:31 --> Model Class Initialized
INFO - 2019-07-02 21:36:31 --> Model Class Initialized
INFO - 2019-07-02 21:36:31 --> Model Class Initialized
INFO - 2019-07-02 21:36:31 --> Model Class Initialized
INFO - 2019-07-02 21:36:31 --> Helper loaded: form_helper
INFO - 2019-07-02 21:36:31 --> Form Validation Class Initialized
DEBUG - 2019-07-02 21:36:31 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-02 21:36:31 --> Model Class Initialized
INFO - 2019-07-02 21:36:31 --> Model Class Initialized
INFO - 2019-07-02 21:36:31 --> Final output sent to browser
DEBUG - 2019-07-02 21:36:31 --> Total execution time: 1.0418
INFO - 2019-07-02 15:36:32 --> Config Class Initialized
INFO - 2019-07-02 15:36:32 --> Config Class Initialized
INFO - 2019-07-02 15:36:32 --> Hooks Class Initialized
INFO - 2019-07-02 15:36:32 --> Hooks Class Initialized
DEBUG - 2019-07-02 15:36:32 --> UTF-8 Support Enabled
DEBUG - 2019-07-02 15:36:32 --> UTF-8 Support Enabled
INFO - 2019-07-02 15:36:32 --> Utf8 Class Initialized
INFO - 2019-07-02 15:36:32 --> Utf8 Class Initialized
INFO - 2019-07-02 15:36:32 --> URI Class Initialized
INFO - 2019-07-02 15:36:32 --> URI Class Initialized
INFO - 2019-07-02 15:36:32 --> Router Class Initialized
INFO - 2019-07-02 15:36:32 --> Router Class Initialized
INFO - 2019-07-02 15:36:32 --> Output Class Initialized
INFO - 2019-07-02 15:36:32 --> Output Class Initialized
INFO - 2019-07-02 15:36:32 --> Security Class Initialized
INFO - 2019-07-02 15:36:32 --> Security Class Initialized
DEBUG - 2019-07-02 15:36:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-02 15:36:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 15:36:32 --> Input Class Initialized
INFO - 2019-07-02 15:36:32 --> Input Class Initialized
INFO - 2019-07-02 15:36:32 --> Language Class Initialized
INFO - 2019-07-02 15:36:32 --> Language Class Initialized
INFO - 2019-07-02 15:36:32 --> Language Class Initialized
INFO - 2019-07-02 15:36:32 --> Language Class Initialized
INFO - 2019-07-02 15:36:32 --> Config Class Initialized
INFO - 2019-07-02 15:36:32 --> Loader Class Initialized
INFO - 2019-07-02 15:36:32 --> Config Class Initialized
INFO - 2019-07-02 15:36:32 --> Loader Class Initialized
DEBUG - 2019-07-02 15:36:32 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-02 15:36:32 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 15:36:32 --> Helper loaded: url_helper
INFO - 2019-07-02 15:36:32 --> Helper loaded: url_helper
INFO - 2019-07-02 15:36:32 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:36:32 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:36:32 --> Helper loaded: string_helper
INFO - 2019-07-02 15:36:32 --> Helper loaded: array_helper
INFO - 2019-07-02 15:36:32 --> Helper loaded: string_helper
INFO - 2019-07-02 15:36:32 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:36:32 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:36:32 --> Helper loaded: array_helper
INFO - 2019-07-02 15:36:32 --> Database Driver Class Initialized
INFO - 2019-07-02 15:36:32 --> Controller Class Initialized
INFO - 2019-07-02 21:36:32 --> Helper loaded: language_helper
INFO - 2019-07-02 21:36:32 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:36:32 --> Model Class Initialized
INFO - 2019-07-02 21:36:32 --> Model Class Initialized
INFO - 2019-07-02 21:36:32 --> Model Class Initialized
INFO - 2019-07-02 21:36:33 --> Model Class Initialized
INFO - 2019-07-02 21:36:33 --> Model Class Initialized
INFO - 2019-07-02 21:36:33 --> Final output sent to browser
DEBUG - 2019-07-02 21:36:33 --> Total execution time: 0.7322
INFO - 2019-07-02 15:36:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:36:33 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:36:33 --> Database Driver Class Initialized
INFO - 2019-07-02 15:36:33 --> Controller Class Initialized
INFO - 2019-07-02 21:36:33 --> Helper loaded: language_helper
INFO - 2019-07-02 21:36:33 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:36:33 --> Model Class Initialized
INFO - 2019-07-02 21:36:33 --> Model Class Initialized
INFO - 2019-07-02 21:36:33 --> Model Class Initialized
INFO - 2019-07-02 21:36:33 --> Model Class Initialized
INFO - 2019-07-02 21:36:33 --> Final output sent to browser
DEBUG - 2019-07-02 21:36:33 --> Total execution time: 0.9518
INFO - 2019-07-02 15:38:50 --> Config Class Initialized
INFO - 2019-07-02 15:38:50 --> Config Class Initialized
INFO - 2019-07-02 15:38:50 --> Hooks Class Initialized
INFO - 2019-07-02 15:38:50 --> Hooks Class Initialized
DEBUG - 2019-07-02 15:38:50 --> UTF-8 Support Enabled
DEBUG - 2019-07-02 15:38:50 --> UTF-8 Support Enabled
INFO - 2019-07-02 15:38:50 --> Utf8 Class Initialized
INFO - 2019-07-02 15:38:50 --> Utf8 Class Initialized
INFO - 2019-07-02 15:38:50 --> URI Class Initialized
INFO - 2019-07-02 15:38:50 --> URI Class Initialized
INFO - 2019-07-02 15:38:50 --> Router Class Initialized
INFO - 2019-07-02 15:38:50 --> Router Class Initialized
INFO - 2019-07-02 15:38:50 --> Output Class Initialized
INFO - 2019-07-02 15:38:50 --> Output Class Initialized
INFO - 2019-07-02 15:38:50 --> Security Class Initialized
INFO - 2019-07-02 15:38:50 --> Security Class Initialized
DEBUG - 2019-07-02 15:38:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-02 15:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 15:38:50 --> Input Class Initialized
INFO - 2019-07-02 15:38:50 --> Input Class Initialized
INFO - 2019-07-02 15:38:50 --> Language Class Initialized
INFO - 2019-07-02 15:38:50 --> Language Class Initialized
INFO - 2019-07-02 15:38:50 --> Language Class Initialized
INFO - 2019-07-02 15:38:50 --> Language Class Initialized
INFO - 2019-07-02 15:38:50 --> Config Class Initialized
INFO - 2019-07-02 15:38:50 --> Loader Class Initialized
INFO - 2019-07-02 15:38:50 --> Config Class Initialized
INFO - 2019-07-02 15:38:50 --> Loader Class Initialized
DEBUG - 2019-07-02 15:38:50 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-02 15:38:50 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 15:38:50 --> Helper loaded: url_helper
INFO - 2019-07-02 15:38:50 --> Helper loaded: url_helper
INFO - 2019-07-02 15:38:50 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:38:50 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:38:50 --> Helper loaded: string_helper
INFO - 2019-07-02 15:38:50 --> Helper loaded: string_helper
INFO - 2019-07-02 15:38:50 --> Helper loaded: array_helper
INFO - 2019-07-02 15:38:50 --> Helper loaded: array_helper
INFO - 2019-07-02 15:38:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:38:50 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:38:50 --> Database Driver Class Initialized
INFO - 2019-07-02 15:38:50 --> Controller Class Initialized
INFO - 2019-07-02 21:38:50 --> Helper loaded: language_helper
INFO - 2019-07-02 21:38:50 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:38:50 --> Model Class Initialized
INFO - 2019-07-02 21:38:50 --> Model Class Initialized
INFO - 2019-07-02 21:38:50 --> Model Class Initialized
INFO - 2019-07-02 21:38:50 --> Model Class Initialized
INFO - 2019-07-02 21:38:50 --> Helper loaded: form_helper
INFO - 2019-07-02 21:38:50 --> Form Validation Class Initialized
DEBUG - 2019-07-02 21:38:50 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-02 21:38:50 --> Model Class Initialized
INFO - 2019-07-02 21:38:50 --> Model Class Initialized
INFO - 2019-07-02 21:38:50 --> Final output sent to browser
DEBUG - 2019-07-02 21:38:50 --> Total execution time: 0.6951
INFO - 2019-07-02 15:38:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:38:50 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:38:50 --> Database Driver Class Initialized
INFO - 2019-07-02 15:38:50 --> Controller Class Initialized
INFO - 2019-07-02 21:38:50 --> Helper loaded: language_helper
INFO - 2019-07-02 21:38:50 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:38:50 --> Model Class Initialized
INFO - 2019-07-02 21:38:50 --> Model Class Initialized
INFO - 2019-07-02 21:38:50 --> Model Class Initialized
INFO - 2019-07-02 21:38:50 --> Model Class Initialized
INFO - 2019-07-02 21:38:50 --> Model Class Initialized
INFO - 2019-07-02 21:38:50 --> Final output sent to browser
DEBUG - 2019-07-02 21:38:50 --> Total execution time: 0.8892
INFO - 2019-07-02 15:39:23 --> Config Class Initialized
INFO - 2019-07-02 15:39:23 --> Config Class Initialized
INFO - 2019-07-02 15:39:23 --> Hooks Class Initialized
INFO - 2019-07-02 15:39:23 --> Hooks Class Initialized
DEBUG - 2019-07-02 15:39:23 --> UTF-8 Support Enabled
DEBUG - 2019-07-02 15:39:23 --> UTF-8 Support Enabled
INFO - 2019-07-02 15:39:23 --> Utf8 Class Initialized
INFO - 2019-07-02 15:39:23 --> Utf8 Class Initialized
INFO - 2019-07-02 15:39:23 --> URI Class Initialized
INFO - 2019-07-02 15:39:23 --> URI Class Initialized
INFO - 2019-07-02 15:39:23 --> Router Class Initialized
INFO - 2019-07-02 15:39:23 --> Router Class Initialized
INFO - 2019-07-02 15:39:23 --> Output Class Initialized
INFO - 2019-07-02 15:39:23 --> Output Class Initialized
INFO - 2019-07-02 15:39:23 --> Security Class Initialized
INFO - 2019-07-02 15:39:23 --> Security Class Initialized
DEBUG - 2019-07-02 15:39:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-02 15:39:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 15:39:23 --> Input Class Initialized
INFO - 2019-07-02 15:39:23 --> Input Class Initialized
INFO - 2019-07-02 15:39:23 --> Language Class Initialized
INFO - 2019-07-02 15:39:23 --> Language Class Initialized
INFO - 2019-07-02 15:39:23 --> Language Class Initialized
INFO - 2019-07-02 15:39:23 --> Language Class Initialized
INFO - 2019-07-02 15:39:23 --> Config Class Initialized
INFO - 2019-07-02 15:39:23 --> Config Class Initialized
INFO - 2019-07-02 15:39:23 --> Loader Class Initialized
INFO - 2019-07-02 15:39:23 --> Loader Class Initialized
DEBUG - 2019-07-02 15:39:23 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-02 15:39:23 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 15:39:23 --> Helper loaded: url_helper
INFO - 2019-07-02 15:39:23 --> Helper loaded: url_helper
INFO - 2019-07-02 15:39:23 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:39:23 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:39:23 --> Helper loaded: string_helper
INFO - 2019-07-02 15:39:23 --> Helper loaded: string_helper
INFO - 2019-07-02 15:39:23 --> Helper loaded: array_helper
INFO - 2019-07-02 15:39:23 --> Helper loaded: array_helper
INFO - 2019-07-02 15:39:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:39:23 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:39:23 --> Database Driver Class Initialized
INFO - 2019-07-02 15:39:23 --> Controller Class Initialized
INFO - 2019-07-02 21:39:23 --> Helper loaded: language_helper
INFO - 2019-07-02 21:39:23 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:39:23 --> Model Class Initialized
INFO - 2019-07-02 21:39:23 --> Model Class Initialized
INFO - 2019-07-02 21:39:23 --> Model Class Initialized
INFO - 2019-07-02 21:39:23 --> Model Class Initialized
INFO - 2019-07-02 21:39:23 --> Model Class Initialized
INFO - 2019-07-02 21:39:24 --> Final output sent to browser
DEBUG - 2019-07-02 21:39:24 --> Total execution time: 0.6610
INFO - 2019-07-02 15:39:24 --> Config Class Initialized
INFO - 2019-07-02 15:39:24 --> Config Class Initialized
INFO - 2019-07-02 15:39:24 --> Hooks Class Initialized
INFO - 2019-07-02 15:39:24 --> Session: Class initialized using 'files' driver.
INFO - 2019-07-02 15:39:24 --> Hooks Class Initialized
DEBUG - 2019-07-02 15:39:24 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
DEBUG - 2019-07-02 15:39:24 --> UTF-8 Support Enabled
DEBUG - 2019-07-02 15:39:24 --> UTF-8 Support Enabled
INFO - 2019-07-02 15:39:24 --> Database Driver Class Initialized
INFO - 2019-07-02 15:39:24 --> Utf8 Class Initialized
INFO - 2019-07-02 15:39:24 --> Utf8 Class Initialized
INFO - 2019-07-02 15:39:24 --> Controller Class Initialized
INFO - 2019-07-02 15:39:24 --> URI Class Initialized
INFO - 2019-07-02 15:39:24 --> URI Class Initialized
INFO - 2019-07-02 21:39:24 --> Helper loaded: language_helper
INFO - 2019-07-02 15:39:24 --> Router Class Initialized
INFO - 2019-07-02 15:39:24 --> Router Class Initialized
INFO - 2019-07-02 21:39:24 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 15:39:24 --> Output Class Initialized
INFO - 2019-07-02 15:39:24 --> Output Class Initialized
INFO - 2019-07-02 21:39:24 --> Model Class Initialized
INFO - 2019-07-02 15:39:24 --> Security Class Initialized
INFO - 2019-07-02 15:39:24 --> Security Class Initialized
DEBUG - 2019-07-02 15:39:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 21:39:24 --> Model Class Initialized
DEBUG - 2019-07-02 15:39:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 15:39:24 --> Input Class Initialized
INFO - 2019-07-02 21:39:24 --> Model Class Initialized
INFO - 2019-07-02 15:39:24 --> Input Class Initialized
INFO - 2019-07-02 15:39:24 --> Language Class Initialized
INFO - 2019-07-02 21:39:24 --> Model Class Initialized
INFO - 2019-07-02 15:39:24 --> Language Class Initialized
INFO - 2019-07-02 15:39:24 --> Language Class Initialized
INFO - 2019-07-02 15:39:24 --> Language Class Initialized
INFO - 2019-07-02 21:39:24 --> Final output sent to browser
INFO - 2019-07-02 15:39:24 --> Config Class Initialized
DEBUG - 2019-07-02 21:39:24 --> Total execution time: 1.0201
INFO - 2019-07-02 15:39:24 --> Loader Class Initialized
INFO - 2019-07-02 15:39:24 --> Config Class Initialized
INFO - 2019-07-02 15:39:24 --> Loader Class Initialized
DEBUG - 2019-07-02 15:39:24 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-02 15:39:24 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 15:39:24 --> Helper loaded: url_helper
INFO - 2019-07-02 15:39:24 --> Helper loaded: url_helper
INFO - 2019-07-02 15:39:24 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:39:24 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:39:24 --> Helper loaded: string_helper
INFO - 2019-07-02 15:39:24 --> Helper loaded: string_helper
INFO - 2019-07-02 15:39:24 --> Helper loaded: array_helper
INFO - 2019-07-02 15:39:24 --> Helper loaded: array_helper
INFO - 2019-07-02 15:39:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:39:24 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:39:24 --> Database Driver Class Initialized
INFO - 2019-07-02 15:39:24 --> Controller Class Initialized
INFO - 2019-07-02 21:39:24 --> Helper loaded: language_helper
INFO - 2019-07-02 21:39:24 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:39:24 --> Model Class Initialized
INFO - 2019-07-02 21:39:24 --> Model Class Initialized
INFO - 2019-07-02 21:39:24 --> Model Class Initialized
INFO - 2019-07-02 21:39:24 --> Model Class Initialized
INFO - 2019-07-02 21:39:24 --> Model Class Initialized
INFO - 2019-07-02 21:39:24 --> Final output sent to browser
DEBUG - 2019-07-02 21:39:24 --> Total execution time: 0.6482
INFO - 2019-07-02 15:39:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:39:24 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:39:24 --> Database Driver Class Initialized
INFO - 2019-07-02 15:39:24 --> Controller Class Initialized
INFO - 2019-07-02 21:39:24 --> Helper loaded: language_helper
INFO - 2019-07-02 21:39:24 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:39:24 --> Model Class Initialized
INFO - 2019-07-02 21:39:24 --> Model Class Initialized
INFO - 2019-07-02 21:39:24 --> Model Class Initialized
INFO - 2019-07-02 21:39:24 --> Model Class Initialized
INFO - 2019-07-02 21:39:24 --> Helper loaded: form_helper
INFO - 2019-07-02 21:39:24 --> Form Validation Class Initialized
DEBUG - 2019-07-02 21:39:24 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-02 21:39:24 --> Model Class Initialized
INFO - 2019-07-02 21:39:24 --> Model Class Initialized
INFO - 2019-07-02 21:39:24 --> Final output sent to browser
DEBUG - 2019-07-02 21:39:24 --> Total execution time: 0.8870
INFO - 2019-07-02 15:39:33 --> Config Class Initialized
INFO - 2019-07-02 15:39:33 --> Config Class Initialized
INFO - 2019-07-02 15:39:33 --> Hooks Class Initialized
INFO - 2019-07-02 15:39:33 --> Hooks Class Initialized
DEBUG - 2019-07-02 15:39:33 --> UTF-8 Support Enabled
DEBUG - 2019-07-02 15:39:33 --> UTF-8 Support Enabled
INFO - 2019-07-02 15:39:33 --> Utf8 Class Initialized
INFO - 2019-07-02 15:39:33 --> Utf8 Class Initialized
INFO - 2019-07-02 15:39:33 --> URI Class Initialized
INFO - 2019-07-02 15:39:33 --> URI Class Initialized
INFO - 2019-07-02 15:39:33 --> Router Class Initialized
INFO - 2019-07-02 15:39:33 --> Router Class Initialized
INFO - 2019-07-02 15:39:33 --> Output Class Initialized
INFO - 2019-07-02 15:39:33 --> Output Class Initialized
INFO - 2019-07-02 15:39:33 --> Security Class Initialized
INFO - 2019-07-02 15:39:33 --> Security Class Initialized
DEBUG - 2019-07-02 15:39:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 15:39:33 --> Input Class Initialized
DEBUG - 2019-07-02 15:39:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 15:39:33 --> Input Class Initialized
INFO - 2019-07-02 15:39:33 --> Language Class Initialized
INFO - 2019-07-02 15:39:33 --> Language Class Initialized
INFO - 2019-07-02 15:39:33 --> Language Class Initialized
INFO - 2019-07-02 15:39:33 --> Language Class Initialized
INFO - 2019-07-02 15:39:33 --> Config Class Initialized
INFO - 2019-07-02 15:39:33 --> Config Class Initialized
INFO - 2019-07-02 15:39:33 --> Loader Class Initialized
INFO - 2019-07-02 15:39:33 --> Loader Class Initialized
DEBUG - 2019-07-02 15:39:33 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-02 15:39:33 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 15:39:33 --> Helper loaded: url_helper
INFO - 2019-07-02 15:39:33 --> Helper loaded: url_helper
INFO - 2019-07-02 15:39:33 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:39:33 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:39:33 --> Helper loaded: string_helper
INFO - 2019-07-02 15:39:33 --> Helper loaded: string_helper
INFO - 2019-07-02 15:39:33 --> Helper loaded: array_helper
INFO - 2019-07-02 15:39:33 --> Helper loaded: array_helper
INFO - 2019-07-02 15:39:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:39:33 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:39:33 --> Database Driver Class Initialized
INFO - 2019-07-02 15:39:33 --> Controller Class Initialized
INFO - 2019-07-02 21:39:33 --> Helper loaded: language_helper
INFO - 2019-07-02 21:39:33 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:39:33 --> Model Class Initialized
INFO - 2019-07-02 21:39:33 --> Model Class Initialized
INFO - 2019-07-02 21:39:33 --> Model Class Initialized
INFO - 2019-07-02 21:39:33 --> Model Class Initialized
INFO - 2019-07-02 21:39:33 --> Helper loaded: form_helper
INFO - 2019-07-02 21:39:34 --> Form Validation Class Initialized
DEBUG - 2019-07-02 21:39:34 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-02 21:39:34 --> Model Class Initialized
INFO - 2019-07-02 21:39:34 --> Model Class Initialized
INFO - 2019-07-02 21:39:34 --> Final output sent to browser
DEBUG - 2019-07-02 21:39:34 --> Total execution time: 0.7218
INFO - 2019-07-02 15:39:34 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:39:34 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:39:34 --> Database Driver Class Initialized
INFO - 2019-07-02 15:39:34 --> Controller Class Initialized
INFO - 2019-07-02 21:39:34 --> Helper loaded: language_helper
INFO - 2019-07-02 21:39:34 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:39:34 --> Model Class Initialized
INFO - 2019-07-02 21:39:34 --> Model Class Initialized
INFO - 2019-07-02 21:39:34 --> Model Class Initialized
INFO - 2019-07-02 21:39:34 --> Model Class Initialized
INFO - 2019-07-02 21:39:34 --> Model Class Initialized
INFO - 2019-07-02 21:39:34 --> Final output sent to browser
DEBUG - 2019-07-02 21:39:34 --> Total execution time: 0.9432
INFO - 2019-07-02 15:39:35 --> Config Class Initialized
INFO - 2019-07-02 15:39:35 --> Config Class Initialized
INFO - 2019-07-02 15:39:35 --> Hooks Class Initialized
INFO - 2019-07-02 15:39:35 --> Hooks Class Initialized
DEBUG - 2019-07-02 15:39:35 --> UTF-8 Support Enabled
DEBUG - 2019-07-02 15:39:35 --> UTF-8 Support Enabled
INFO - 2019-07-02 15:39:35 --> Utf8 Class Initialized
INFO - 2019-07-02 15:39:35 --> Utf8 Class Initialized
INFO - 2019-07-02 15:39:35 --> URI Class Initialized
INFO - 2019-07-02 15:39:35 --> URI Class Initialized
INFO - 2019-07-02 15:39:35 --> Router Class Initialized
INFO - 2019-07-02 15:39:35 --> Router Class Initialized
INFO - 2019-07-02 15:39:35 --> Output Class Initialized
INFO - 2019-07-02 15:39:35 --> Output Class Initialized
INFO - 2019-07-02 15:39:35 --> Security Class Initialized
INFO - 2019-07-02 15:39:35 --> Security Class Initialized
DEBUG - 2019-07-02 15:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 15:39:35 --> Input Class Initialized
DEBUG - 2019-07-02 15:39:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 15:39:35 --> Input Class Initialized
INFO - 2019-07-02 15:39:35 --> Language Class Initialized
INFO - 2019-07-02 15:39:35 --> Language Class Initialized
INFO - 2019-07-02 15:39:35 --> Language Class Initialized
INFO - 2019-07-02 15:39:35 --> Language Class Initialized
INFO - 2019-07-02 15:39:35 --> Config Class Initialized
INFO - 2019-07-02 15:39:35 --> Config Class Initialized
INFO - 2019-07-02 15:39:35 --> Loader Class Initialized
INFO - 2019-07-02 15:39:35 --> Loader Class Initialized
DEBUG - 2019-07-02 15:39:35 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-02 15:39:35 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 15:39:35 --> Helper loaded: url_helper
INFO - 2019-07-02 15:39:35 --> Helper loaded: url_helper
INFO - 2019-07-02 15:39:35 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:39:35 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:39:35 --> Helper loaded: string_helper
INFO - 2019-07-02 15:39:35 --> Helper loaded: string_helper
INFO - 2019-07-02 15:39:35 --> Helper loaded: array_helper
INFO - 2019-07-02 15:39:35 --> Helper loaded: array_helper
INFO - 2019-07-02 15:39:35 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:39:35 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:39:35 --> Database Driver Class Initialized
INFO - 2019-07-02 15:39:35 --> Controller Class Initialized
INFO - 2019-07-02 21:39:35 --> Helper loaded: language_helper
INFO - 2019-07-02 21:39:36 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:39:36 --> Model Class Initialized
INFO - 2019-07-02 21:39:36 --> Model Class Initialized
INFO - 2019-07-02 21:39:36 --> Model Class Initialized
INFO - 2019-07-02 21:39:36 --> Model Class Initialized
INFO - 2019-07-02 21:39:36 --> Model Class Initialized
INFO - 2019-07-02 21:39:36 --> Final output sent to browser
DEBUG - 2019-07-02 21:39:36 --> Total execution time: 0.7331
INFO - 2019-07-02 15:39:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:39:36 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:39:36 --> Database Driver Class Initialized
INFO - 2019-07-02 15:39:36 --> Controller Class Initialized
INFO - 2019-07-02 21:39:36 --> Helper loaded: language_helper
INFO - 2019-07-02 21:39:36 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:39:36 --> Model Class Initialized
INFO - 2019-07-02 21:39:36 --> Model Class Initialized
INFO - 2019-07-02 21:39:36 --> Model Class Initialized
INFO - 2019-07-02 21:39:36 --> Model Class Initialized
INFO - 2019-07-02 21:39:36 --> Final output sent to browser
DEBUG - 2019-07-02 21:39:36 --> Total execution time: 0.9130
INFO - 2019-07-02 15:39:56 --> Config Class Initialized
INFO - 2019-07-02 15:39:56 --> Config Class Initialized
INFO - 2019-07-02 15:39:56 --> Hooks Class Initialized
INFO - 2019-07-02 15:39:56 --> Hooks Class Initialized
DEBUG - 2019-07-02 15:39:56 --> UTF-8 Support Enabled
DEBUG - 2019-07-02 15:39:56 --> UTF-8 Support Enabled
INFO - 2019-07-02 15:39:56 --> Utf8 Class Initialized
INFO - 2019-07-02 15:39:56 --> Utf8 Class Initialized
INFO - 2019-07-02 15:39:56 --> URI Class Initialized
INFO - 2019-07-02 15:39:56 --> URI Class Initialized
INFO - 2019-07-02 15:39:56 --> Router Class Initialized
INFO - 2019-07-02 15:39:56 --> Output Class Initialized
INFO - 2019-07-02 15:39:56 --> Router Class Initialized
INFO - 2019-07-02 15:39:56 --> Security Class Initialized
INFO - 2019-07-02 15:39:56 --> Config Class Initialized
DEBUG - 2019-07-02 15:39:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 15:39:56 --> Config Class Initialized
INFO - 2019-07-02 15:39:56 --> Hooks Class Initialized
INFO - 2019-07-02 15:39:56 --> Output Class Initialized
INFO - 2019-07-02 15:39:56 --> Input Class Initialized
INFO - 2019-07-02 15:39:56 --> Hooks Class Initialized
INFO - 2019-07-02 15:39:56 --> Security Class Initialized
DEBUG - 2019-07-02 15:39:56 --> UTF-8 Support Enabled
INFO - 2019-07-02 15:39:56 --> Utf8 Class Initialized
INFO - 2019-07-02 15:39:56 --> Language Class Initialized
DEBUG - 2019-07-02 15:39:56 --> UTF-8 Support Enabled
DEBUG - 2019-07-02 15:39:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 15:39:56 --> Utf8 Class Initialized
INFO - 2019-07-02 15:39:56 --> Input Class Initialized
INFO - 2019-07-02 15:39:56 --> Language Class Initialized
INFO - 2019-07-02 15:39:56 --> URI Class Initialized
INFO - 2019-07-02 15:39:56 --> URI Class Initialized
INFO - 2019-07-02 15:39:56 --> Language Class Initialized
INFO - 2019-07-02 15:39:56 --> Config Class Initialized
INFO - 2019-07-02 15:39:56 --> Loader Class Initialized
INFO - 2019-07-02 15:39:56 --> Router Class Initialized
INFO - 2019-07-02 15:39:56 --> Language Class Initialized
INFO - 2019-07-02 15:39:56 --> Router Class Initialized
INFO - 2019-07-02 15:39:56 --> Output Class Initialized
DEBUG - 2019-07-02 15:39:56 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 15:39:56 --> Config Class Initialized
INFO - 2019-07-02 15:39:56 --> Loader Class Initialized
INFO - 2019-07-02 15:39:56 --> Output Class Initialized
INFO - 2019-07-02 15:39:56 --> Security Class Initialized
INFO - 2019-07-02 15:39:56 --> Helper loaded: url_helper
INFO - 2019-07-02 15:39:56 --> Security Class Initialized
DEBUG - 2019-07-02 15:39:56 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-02 15:39:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 15:39:56 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:39:56 --> Input Class Initialized
INFO - 2019-07-02 15:39:56 --> Helper loaded: url_helper
DEBUG - 2019-07-02 15:39:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 15:39:56 --> Input Class Initialized
INFO - 2019-07-02 15:39:56 --> Helper loaded: string_helper
INFO - 2019-07-02 15:39:56 --> Language Class Initialized
INFO - 2019-07-02 15:39:56 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:39:56 --> Language Class Initialized
INFO - 2019-07-02 15:39:56 --> Helper loaded: array_helper
INFO - 2019-07-02 15:39:56 --> Language Class Initialized
INFO - 2019-07-02 15:39:56 --> Helper loaded: string_helper
INFO - 2019-07-02 15:39:56 --> Config Class Initialized
INFO - 2019-07-02 15:39:56 --> Session: Class initialized using 'files' driver.
INFO - 2019-07-02 15:39:56 --> Language Class Initialized
INFO - 2019-07-02 15:39:56 --> Helper loaded: array_helper
INFO - 2019-07-02 15:39:56 --> Loader Class Initialized
INFO - 2019-07-02 15:39:56 --> Config Class Initialized
DEBUG - 2019-07-02 15:39:56 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:39:56 --> Loader Class Initialized
DEBUG - 2019-07-02 15:39:56 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 15:39:56 --> Database Driver Class Initialized
DEBUG - 2019-07-02 15:39:56 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 15:39:56 --> Helper loaded: url_helper
INFO - 2019-07-02 15:39:56 --> Helper loaded: url_helper
INFO - 2019-07-02 15:39:56 --> Controller Class Initialized
INFO - 2019-07-02 15:39:56 --> Helper loaded: inflector_helper
INFO - 2019-07-02 21:39:56 --> Helper loaded: language_helper
INFO - 2019-07-02 15:39:56 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:39:56 --> Helper loaded: string_helper
INFO - 2019-07-02 15:39:56 --> Helper loaded: string_helper
INFO - 2019-07-02 21:39:56 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 15:39:56 --> Helper loaded: array_helper
INFO - 2019-07-02 15:39:56 --> Helper loaded: array_helper
INFO - 2019-07-02 21:39:56 --> Model Class Initialized
INFO - 2019-07-02 15:39:56 --> Session: Class initialized using 'files' driver.
INFO - 2019-07-02 21:39:56 --> Model Class Initialized
DEBUG - 2019-07-02 15:39:57 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 21:39:57 --> Model Class Initialized
INFO - 2019-07-02 15:39:57 --> Database Driver Class Initialized
INFO - 2019-07-02 21:39:57 --> Model Class Initialized
INFO - 2019-07-02 15:39:57 --> Controller Class Initialized
INFO - 2019-07-02 21:39:57 --> Model Class Initialized
INFO - 2019-07-02 21:39:57 --> Helper loaded: language_helper
INFO - 2019-07-02 21:39:57 --> Final output sent to browser
INFO - 2019-07-02 21:39:57 --> Language file loaded: language/english/general_lang.php
DEBUG - 2019-07-02 21:39:57 --> Total execution time: 0.8951
INFO - 2019-07-02 15:39:57 --> Session: Class initialized using 'files' driver.
INFO - 2019-07-02 21:39:57 --> Model Class Initialized
DEBUG - 2019-07-02 15:39:57 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 21:39:57 --> Model Class Initialized
INFO - 2019-07-02 15:39:57 --> Database Driver Class Initialized
INFO - 2019-07-02 21:39:57 --> Model Class Initialized
INFO - 2019-07-02 15:39:57 --> Controller Class Initialized
INFO - 2019-07-02 21:39:57 --> Model Class Initialized
INFO - 2019-07-02 21:39:57 --> Helper loaded: language_helper
INFO - 2019-07-02 21:39:57 --> Model Class Initialized
INFO - 2019-07-02 21:39:57 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:39:57 --> Final output sent to browser
INFO - 2019-07-02 21:39:57 --> Model Class Initialized
DEBUG - 2019-07-02 21:39:57 --> Total execution time: 0.7542
INFO - 2019-07-02 15:39:57 --> Session: Class initialized using 'files' driver.
INFO - 2019-07-02 21:39:57 --> Model Class Initialized
DEBUG - 2019-07-02 15:39:57 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 21:39:57 --> Model Class Initialized
INFO - 2019-07-02 15:39:57 --> Database Driver Class Initialized
INFO - 2019-07-02 21:39:57 --> Model Class Initialized
INFO - 2019-07-02 15:39:57 --> Controller Class Initialized
INFO - 2019-07-02 21:39:57 --> Helper loaded: form_helper
INFO - 2019-07-02 21:39:57 --> Helper loaded: language_helper
INFO - 2019-07-02 21:39:57 --> Form Validation Class Initialized
INFO - 2019-07-02 21:39:57 --> Language file loaded: language/english/general_lang.php
DEBUG - 2019-07-02 21:39:57 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-02 21:39:57 --> Model Class Initialized
INFO - 2019-07-02 21:39:57 --> Model Class Initialized
INFO - 2019-07-02 21:39:57 --> Model Class Initialized
INFO - 2019-07-02 21:39:57 --> Model Class Initialized
INFO - 2019-07-02 21:39:57 --> Model Class Initialized
INFO - 2019-07-02 21:39:57 --> Final output sent to browser
INFO - 2019-07-02 21:39:57 --> Model Class Initialized
DEBUG - 2019-07-02 21:39:57 --> Total execution time: 1.3287
INFO - 2019-07-02 21:39:57 --> Final output sent to browser
DEBUG - 2019-07-02 21:39:57 --> Total execution time: 1.0476
INFO - 2019-07-02 15:40:50 --> Config Class Initialized
INFO - 2019-07-02 15:40:50 --> Hooks Class Initialized
INFO - 2019-07-02 15:40:50 --> Config Class Initialized
INFO - 2019-07-02 15:40:50 --> Hooks Class Initialized
DEBUG - 2019-07-02 15:40:50 --> UTF-8 Support Enabled
INFO - 2019-07-02 15:40:50 --> Utf8 Class Initialized
DEBUG - 2019-07-02 15:40:50 --> UTF-8 Support Enabled
INFO - 2019-07-02 15:40:50 --> Utf8 Class Initialized
INFO - 2019-07-02 15:40:50 --> URI Class Initialized
INFO - 2019-07-02 15:40:50 --> URI Class Initialized
INFO - 2019-07-02 15:40:50 --> Router Class Initialized
INFO - 2019-07-02 15:40:50 --> Router Class Initialized
INFO - 2019-07-02 15:40:51 --> Output Class Initialized
INFO - 2019-07-02 15:40:51 --> Output Class Initialized
INFO - 2019-07-02 15:40:51 --> Security Class Initialized
INFO - 2019-07-02 15:40:51 --> Security Class Initialized
DEBUG - 2019-07-02 15:40:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-02 15:40:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 15:40:51 --> Input Class Initialized
INFO - 2019-07-02 15:40:51 --> Input Class Initialized
INFO - 2019-07-02 15:40:51 --> Language Class Initialized
INFO - 2019-07-02 15:40:51 --> Language Class Initialized
INFO - 2019-07-02 15:40:51 --> Language Class Initialized
INFO - 2019-07-02 15:40:51 --> Language Class Initialized
INFO - 2019-07-02 15:40:51 --> Config Class Initialized
INFO - 2019-07-02 15:40:51 --> Loader Class Initialized
INFO - 2019-07-02 15:40:51 --> Config Class Initialized
DEBUG - 2019-07-02 15:40:51 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 15:40:51 --> Loader Class Initialized
DEBUG - 2019-07-02 15:40:51 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 15:40:51 --> Helper loaded: url_helper
INFO - 2019-07-02 15:40:51 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:40:51 --> Helper loaded: url_helper
INFO - 2019-07-02 15:40:51 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:40:51 --> Helper loaded: string_helper
INFO - 2019-07-02 15:40:51 --> Helper loaded: string_helper
INFO - 2019-07-02 15:40:51 --> Helper loaded: array_helper
INFO - 2019-07-02 15:40:51 --> Helper loaded: array_helper
INFO - 2019-07-02 15:40:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:40:51 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:40:51 --> Database Driver Class Initialized
INFO - 2019-07-02 15:40:51 --> Controller Class Initialized
INFO - 2019-07-02 21:40:51 --> Helper loaded: language_helper
INFO - 2019-07-02 21:40:51 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:40:51 --> Model Class Initialized
INFO - 2019-07-02 21:40:51 --> Model Class Initialized
INFO - 2019-07-02 21:40:51 --> Model Class Initialized
INFO - 2019-07-02 21:40:51 --> Model Class Initialized
INFO - 2019-07-02 21:40:51 --> Model Class Initialized
INFO - 2019-07-02 21:40:51 --> Final output sent to browser
DEBUG - 2019-07-02 21:40:51 --> Total execution time: 0.6573
INFO - 2019-07-02 15:40:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:40:51 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:40:51 --> Database Driver Class Initialized
INFO - 2019-07-02 15:40:51 --> Controller Class Initialized
INFO - 2019-07-02 21:40:51 --> Helper loaded: language_helper
INFO - 2019-07-02 21:40:51 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:40:51 --> Model Class Initialized
INFO - 2019-07-02 21:40:51 --> Model Class Initialized
INFO - 2019-07-02 21:40:51 --> Model Class Initialized
INFO - 2019-07-02 21:40:51 --> Model Class Initialized
INFO - 2019-07-02 21:40:51 --> Helper loaded: form_helper
INFO - 2019-07-02 21:40:51 --> Form Validation Class Initialized
DEBUG - 2019-07-02 21:40:51 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-02 21:40:51 --> Model Class Initialized
INFO - 2019-07-02 21:40:51 --> Model Class Initialized
INFO - 2019-07-02 21:40:51 --> Final output sent to browser
DEBUG - 2019-07-02 21:40:51 --> Total execution time: 0.9130
INFO - 2019-07-02 15:43:32 --> Config Class Initialized
INFO - 2019-07-02 15:43:32 --> Config Class Initialized
INFO - 2019-07-02 15:43:32 --> Hooks Class Initialized
INFO - 2019-07-02 15:43:32 --> Hooks Class Initialized
DEBUG - 2019-07-02 15:43:32 --> UTF-8 Support Enabled
DEBUG - 2019-07-02 15:43:32 --> UTF-8 Support Enabled
INFO - 2019-07-02 15:43:32 --> Utf8 Class Initialized
INFO - 2019-07-02 15:43:32 --> Utf8 Class Initialized
INFO - 2019-07-02 15:43:32 --> URI Class Initialized
INFO - 2019-07-02 15:43:32 --> URI Class Initialized
INFO - 2019-07-02 15:43:32 --> Router Class Initialized
INFO - 2019-07-02 15:43:32 --> Router Class Initialized
INFO - 2019-07-02 15:43:32 --> Output Class Initialized
INFO - 2019-07-02 15:43:33 --> Output Class Initialized
INFO - 2019-07-02 15:43:33 --> Security Class Initialized
INFO - 2019-07-02 15:43:33 --> Security Class Initialized
DEBUG - 2019-07-02 15:43:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-02 15:43:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-02 15:43:33 --> Input Class Initialized
INFO - 2019-07-02 15:43:33 --> Input Class Initialized
INFO - 2019-07-02 15:43:33 --> Language Class Initialized
INFO - 2019-07-02 15:43:33 --> Language Class Initialized
INFO - 2019-07-02 15:43:33 --> Language Class Initialized
INFO - 2019-07-02 15:43:33 --> Language Class Initialized
INFO - 2019-07-02 15:43:33 --> Config Class Initialized
INFO - 2019-07-02 15:43:33 --> Config Class Initialized
INFO - 2019-07-02 15:43:33 --> Loader Class Initialized
INFO - 2019-07-02 15:43:33 --> Loader Class Initialized
DEBUG - 2019-07-02 15:43:33 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-02 15:43:33 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-02 15:43:33 --> Helper loaded: url_helper
INFO - 2019-07-02 15:43:33 --> Helper loaded: url_helper
INFO - 2019-07-02 15:43:33 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:43:33 --> Helper loaded: inflector_helper
INFO - 2019-07-02 15:43:33 --> Helper loaded: string_helper
INFO - 2019-07-02 15:43:33 --> Helper loaded: string_helper
INFO - 2019-07-02 15:43:33 --> Helper loaded: array_helper
INFO - 2019-07-02 15:43:33 --> Helper loaded: array_helper
INFO - 2019-07-02 15:43:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:43:33 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:43:33 --> Database Driver Class Initialized
INFO - 2019-07-02 15:43:33 --> Controller Class Initialized
INFO - 2019-07-02 21:43:33 --> Helper loaded: language_helper
INFO - 2019-07-02 21:43:33 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:43:33 --> Model Class Initialized
INFO - 2019-07-02 21:43:33 --> Model Class Initialized
INFO - 2019-07-02 21:43:33 --> Model Class Initialized
INFO - 2019-07-02 21:43:33 --> Model Class Initialized
INFO - 2019-07-02 21:43:33 --> Helper loaded: form_helper
INFO - 2019-07-02 21:43:33 --> Form Validation Class Initialized
DEBUG - 2019-07-02 21:43:33 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-02 21:43:33 --> Model Class Initialized
INFO - 2019-07-02 21:43:33 --> Model Class Initialized
INFO - 2019-07-02 21:43:33 --> Final output sent to browser
DEBUG - 2019-07-02 21:43:33 --> Total execution time: 0.7414
INFO - 2019-07-02 15:43:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-02 15:43:33 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-02 15:43:33 --> Database Driver Class Initialized
INFO - 2019-07-02 15:43:33 --> Controller Class Initialized
INFO - 2019-07-02 21:43:33 --> Helper loaded: language_helper
INFO - 2019-07-02 21:43:33 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-02 21:43:33 --> Model Class Initialized
INFO - 2019-07-02 21:43:33 --> Model Class Initialized
INFO - 2019-07-02 21:43:33 --> Model Class Initialized
INFO - 2019-07-02 21:43:33 --> Model Class Initialized
INFO - 2019-07-02 21:43:33 --> Model Class Initialized
INFO - 2019-07-02 21:43:33 --> Final output sent to browser
DEBUG - 2019-07-02 21:43:33 --> Total execution time: 0.9426
