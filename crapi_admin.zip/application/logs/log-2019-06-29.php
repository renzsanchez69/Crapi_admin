<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-06-29 12:47:11 --> Config Class Initialized
INFO - 2019-06-29 12:47:11 --> Hooks Class Initialized
DEBUG - 2019-06-29 12:47:11 --> UTF-8 Support Enabled
INFO - 2019-06-29 12:47:11 --> Utf8 Class Initialized
INFO - 2019-06-29 12:47:11 --> URI Class Initialized
DEBUG - 2019-06-29 12:47:11 --> No URI present. Default controller set.
INFO - 2019-06-29 12:47:11 --> Router Class Initialized
INFO - 2019-06-29 12:47:11 --> Output Class Initialized
INFO - 2019-06-29 12:47:11 --> Security Class Initialized
DEBUG - 2019-06-29 12:47:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 12:47:11 --> Input Class Initialized
INFO - 2019-06-29 12:47:11 --> Language Class Initialized
INFO - 2019-06-29 12:47:14 --> Final output sent to browser
DEBUG - 2019-06-29 12:47:14 --> Total execution time: 2.6685
INFO - 2019-06-29 12:47:22 --> Config Class Initialized
INFO - 2019-06-29 12:47:22 --> Hooks Class Initialized
DEBUG - 2019-06-29 12:47:22 --> UTF-8 Support Enabled
INFO - 2019-06-29 12:47:22 --> Utf8 Class Initialized
INFO - 2019-06-29 12:47:22 --> URI Class Initialized
DEBUG - 2019-06-29 12:47:22 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/routes.php
INFO - 2019-06-29 12:47:22 --> Router Class Initialized
INFO - 2019-06-29 12:47:22 --> Output Class Initialized
INFO - 2019-06-29 12:47:22 --> Security Class Initialized
DEBUG - 2019-06-29 12:47:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 12:47:22 --> Input Class Initialized
INFO - 2019-06-29 12:47:22 --> Language Class Initialized
INFO - 2019-06-29 12:47:22 --> Language Class Initialized
INFO - 2019-06-29 12:47:22 --> Config Class Initialized
INFO - 2019-06-29 12:47:22 --> Loader Class Initialized
DEBUG - 2019-06-29 12:47:22 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/site.php
INFO - 2019-06-29 12:47:22 --> Helper loaded: url_helper
INFO - 2019-06-29 12:47:22 --> Helper loaded: inflector_helper
INFO - 2019-06-29 12:47:22 --> Helper loaded: string_helper
INFO - 2019-06-29 12:47:22 --> Helper loaded: array_helper
INFO - 2019-06-29 12:47:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 12:47:22 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/autoload.php
DEBUG - 2019-06-29 12:47:22 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/helpers/adminlte_helper.php
INFO - 2019-06-29 12:47:22 --> Database Driver Class Initialized
DEBUG - 2019-06-29 12:47:23 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/libraries/Crud.php
INFO - 2019-06-29 12:47:23 --> Helper loaded: form_helper
DEBUG - 2019-06-29 12:47:23 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-06-29 12:47:23 --> Form Validation Class Initialized
DEBUG - 2019-06-29 12:47:23 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-06-29 12:47:23 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-06-29 12:47:23 --> Pagination Class Initialized
INFO - 2019-06-29 12:47:23 --> Controller Class Initialized
INFO - 2019-06-29 18:47:23 --> Final output sent to browser
DEBUG - 2019-06-29 18:47:23 --> Total execution time: 1.2076
INFO - 2019-06-29 12:47:25 --> Config Class Initialized
INFO - 2019-06-29 12:47:25 --> Hooks Class Initialized
DEBUG - 2019-06-29 12:47:25 --> UTF-8 Support Enabled
INFO - 2019-06-29 12:47:25 --> Utf8 Class Initialized
INFO - 2019-06-29 12:47:25 --> URI Class Initialized
DEBUG - 2019-06-29 12:47:25 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/routes.php
INFO - 2019-06-29 12:47:25 --> Router Class Initialized
INFO - 2019-06-29 12:47:25 --> Output Class Initialized
INFO - 2019-06-29 12:47:25 --> Security Class Initialized
DEBUG - 2019-06-29 12:47:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 12:47:25 --> Input Class Initialized
INFO - 2019-06-29 12:47:25 --> Language Class Initialized
INFO - 2019-06-29 12:47:25 --> Language Class Initialized
INFO - 2019-06-29 12:47:25 --> Config Class Initialized
INFO - 2019-06-29 12:47:25 --> Loader Class Initialized
DEBUG - 2019-06-29 12:47:25 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/site.php
INFO - 2019-06-29 12:47:25 --> Helper loaded: url_helper
INFO - 2019-06-29 12:47:25 --> Helper loaded: inflector_helper
INFO - 2019-06-29 12:47:25 --> Helper loaded: string_helper
INFO - 2019-06-29 12:47:25 --> Helper loaded: array_helper
INFO - 2019-06-29 12:47:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 12:47:25 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/autoload.php
DEBUG - 2019-06-29 12:47:25 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/helpers/adminlte_helper.php
INFO - 2019-06-29 12:47:25 --> Database Driver Class Initialized
DEBUG - 2019-06-29 12:47:25 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/libraries/Crud.php
INFO - 2019-06-29 12:47:25 --> Helper loaded: form_helper
DEBUG - 2019-06-29 12:47:25 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-06-29 12:47:25 --> Form Validation Class Initialized
DEBUG - 2019-06-29 12:47:25 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-06-29 12:47:25 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-06-29 12:47:25 --> Pagination Class Initialized
INFO - 2019-06-29 12:47:25 --> Controller Class Initialized
INFO - 2019-06-29 18:47:25 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-06-29 18:47:25 --> Model Class Initialized
INFO - 2019-06-29 18:47:25 --> Model Class Initialized
INFO - 2019-06-29 12:47:25 --> Config Class Initialized
INFO - 2019-06-29 12:47:25 --> Hooks Class Initialized
DEBUG - 2019-06-29 12:47:26 --> UTF-8 Support Enabled
INFO - 2019-06-29 12:47:26 --> Utf8 Class Initialized
INFO - 2019-06-29 12:47:26 --> URI Class Initialized
DEBUG - 2019-06-29 12:47:26 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/routes.php
INFO - 2019-06-29 12:47:26 --> Router Class Initialized
INFO - 2019-06-29 12:47:26 --> Output Class Initialized
INFO - 2019-06-29 12:47:26 --> Security Class Initialized
DEBUG - 2019-06-29 12:47:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 12:47:26 --> Input Class Initialized
INFO - 2019-06-29 12:47:26 --> Language Class Initialized
INFO - 2019-06-29 12:47:26 --> Language Class Initialized
INFO - 2019-06-29 12:47:26 --> Config Class Initialized
INFO - 2019-06-29 12:47:26 --> Loader Class Initialized
DEBUG - 2019-06-29 12:47:26 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/site.php
INFO - 2019-06-29 12:47:26 --> Helper loaded: url_helper
INFO - 2019-06-29 12:47:26 --> Helper loaded: inflector_helper
INFO - 2019-06-29 12:47:26 --> Helper loaded: string_helper
INFO - 2019-06-29 12:47:26 --> Helper loaded: array_helper
INFO - 2019-06-29 12:47:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 12:47:26 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/autoload.php
DEBUG - 2019-06-29 12:47:26 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/helpers/adminlte_helper.php
INFO - 2019-06-29 12:47:26 --> Database Driver Class Initialized
DEBUG - 2019-06-29 12:47:26 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/libraries/Crud.php
INFO - 2019-06-29 12:47:26 --> Helper loaded: form_helper
DEBUG - 2019-06-29 12:47:26 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-06-29 12:47:26 --> Form Validation Class Initialized
DEBUG - 2019-06-29 12:47:26 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-06-29 12:47:26 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-06-29 12:47:26 --> Pagination Class Initialized
INFO - 2019-06-29 12:47:26 --> Controller Class Initialized
INFO - 2019-06-29 18:47:26 --> Final output sent to browser
DEBUG - 2019-06-29 18:47:26 --> Total execution time: 0.5591
INFO - 2019-06-29 12:47:28 --> Config Class Initialized
INFO - 2019-06-29 12:47:28 --> Hooks Class Initialized
DEBUG - 2019-06-29 12:47:28 --> UTF-8 Support Enabled
INFO - 2019-06-29 12:47:28 --> Utf8 Class Initialized
INFO - 2019-06-29 12:47:28 --> URI Class Initialized
DEBUG - 2019-06-29 12:47:28 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/routes.php
INFO - 2019-06-29 12:47:28 --> Router Class Initialized
INFO - 2019-06-29 12:47:28 --> Output Class Initialized
INFO - 2019-06-29 12:47:28 --> Security Class Initialized
DEBUG - 2019-06-29 12:47:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 12:47:28 --> Input Class Initialized
INFO - 2019-06-29 12:47:28 --> Language Class Initialized
INFO - 2019-06-29 12:47:28 --> Language Class Initialized
INFO - 2019-06-29 12:47:28 --> Config Class Initialized
INFO - 2019-06-29 12:47:28 --> Loader Class Initialized
DEBUG - 2019-06-29 12:47:28 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/site.php
INFO - 2019-06-29 12:47:28 --> Helper loaded: url_helper
INFO - 2019-06-29 12:47:28 --> Helper loaded: inflector_helper
INFO - 2019-06-29 12:47:28 --> Helper loaded: string_helper
INFO - 2019-06-29 12:47:28 --> Helper loaded: array_helper
INFO - 2019-06-29 12:47:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 12:47:28 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/autoload.php
DEBUG - 2019-06-29 12:47:28 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/helpers/adminlte_helper.php
INFO - 2019-06-29 12:47:28 --> Database Driver Class Initialized
DEBUG - 2019-06-29 12:47:28 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/libraries/Crud.php
INFO - 2019-06-29 12:47:28 --> Helper loaded: form_helper
DEBUG - 2019-06-29 12:47:28 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-06-29 12:47:28 --> Form Validation Class Initialized
DEBUG - 2019-06-29 12:47:28 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-06-29 12:47:28 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-06-29 12:47:28 --> Pagination Class Initialized
INFO - 2019-06-29 12:47:28 --> Controller Class Initialized
INFO - 2019-06-29 18:47:28 --> Model Class Initialized
INFO - 2019-06-29 18:47:28 --> Model Class Initialized
INFO - 2019-06-29 18:47:28 --> Final output sent to browser
DEBUG - 2019-06-29 18:47:29 --> Total execution time: 0.5223
INFO - 2019-06-29 12:47:30 --> Config Class Initialized
INFO - 2019-06-29 12:47:30 --> Hooks Class Initialized
DEBUG - 2019-06-29 12:47:30 --> UTF-8 Support Enabled
INFO - 2019-06-29 12:47:30 --> Utf8 Class Initialized
INFO - 2019-06-29 12:47:30 --> URI Class Initialized
DEBUG - 2019-06-29 12:47:30 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/routes.php
INFO - 2019-06-29 12:47:30 --> Router Class Initialized
INFO - 2019-06-29 12:47:30 --> Output Class Initialized
INFO - 2019-06-29 12:47:30 --> Security Class Initialized
DEBUG - 2019-06-29 12:47:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 12:47:30 --> Input Class Initialized
INFO - 2019-06-29 12:47:30 --> Language Class Initialized
INFO - 2019-06-29 12:47:30 --> Language Class Initialized
INFO - 2019-06-29 12:47:31 --> Config Class Initialized
INFO - 2019-06-29 12:47:31 --> Loader Class Initialized
DEBUG - 2019-06-29 12:47:31 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/site.php
INFO - 2019-06-29 12:47:31 --> Helper loaded: url_helper
INFO - 2019-06-29 12:47:31 --> Helper loaded: inflector_helper
INFO - 2019-06-29 12:47:31 --> Helper loaded: string_helper
INFO - 2019-06-29 12:47:31 --> Helper loaded: array_helper
INFO - 2019-06-29 12:47:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 12:47:31 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/autoload.php
DEBUG - 2019-06-29 12:47:31 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/helpers/adminlte_helper.php
INFO - 2019-06-29 12:47:31 --> Database Driver Class Initialized
DEBUG - 2019-06-29 12:47:31 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/libraries/Crud.php
INFO - 2019-06-29 12:47:31 --> Helper loaded: form_helper
DEBUG - 2019-06-29 12:47:31 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-06-29 12:47:31 --> Form Validation Class Initialized
DEBUG - 2019-06-29 12:47:31 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-06-29 12:47:31 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-06-29 12:47:31 --> Pagination Class Initialized
INFO - 2019-06-29 12:47:31 --> Controller Class Initialized
INFO - 2019-06-29 18:47:31 --> Model Class Initialized
INFO - 2019-06-29 18:47:31 --> Model Class Initialized
INFO - 2019-06-29 18:47:31 --> Model Class Initialized
INFO - 2019-06-29 18:47:31 --> Final output sent to browser
DEBUG - 2019-06-29 18:47:31 --> Total execution time: 0.5922
INFO - 2019-06-29 12:47:32 --> Config Class Initialized
INFO - 2019-06-29 12:47:32 --> Hooks Class Initialized
DEBUG - 2019-06-29 12:47:32 --> UTF-8 Support Enabled
INFO - 2019-06-29 12:47:32 --> Utf8 Class Initialized
INFO - 2019-06-29 12:47:32 --> URI Class Initialized
DEBUG - 2019-06-29 12:47:32 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/routes.php
INFO - 2019-06-29 12:47:32 --> Router Class Initialized
INFO - 2019-06-29 12:47:32 --> Output Class Initialized
INFO - 2019-06-29 12:47:32 --> Security Class Initialized
DEBUG - 2019-06-29 12:47:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 12:47:32 --> Input Class Initialized
INFO - 2019-06-29 12:47:32 --> Language Class Initialized
INFO - 2019-06-29 12:47:32 --> Language Class Initialized
INFO - 2019-06-29 12:47:32 --> Config Class Initialized
INFO - 2019-06-29 12:47:32 --> Loader Class Initialized
DEBUG - 2019-06-29 12:47:32 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/site.php
INFO - 2019-06-29 12:47:32 --> Helper loaded: url_helper
INFO - 2019-06-29 12:47:32 --> Helper loaded: inflector_helper
INFO - 2019-06-29 12:47:32 --> Helper loaded: string_helper
INFO - 2019-06-29 12:47:32 --> Helper loaded: array_helper
INFO - 2019-06-29 12:47:32 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 12:47:32 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/autoload.php
DEBUG - 2019-06-29 12:47:32 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/helpers/adminlte_helper.php
INFO - 2019-06-29 12:47:32 --> Database Driver Class Initialized
DEBUG - 2019-06-29 12:47:32 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/libraries/Crud.php
INFO - 2019-06-29 12:47:32 --> Helper loaded: form_helper
DEBUG - 2019-06-29 12:47:32 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-06-29 12:47:32 --> Form Validation Class Initialized
DEBUG - 2019-06-29 12:47:32 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-06-29 12:47:32 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-06-29 12:47:32 --> Pagination Class Initialized
INFO - 2019-06-29 12:47:32 --> Controller Class Initialized
INFO - 2019-06-29 18:47:32 --> Model Class Initialized
INFO - 2019-06-29 18:47:33 --> Model Class Initialized
INFO - 2019-06-29 18:47:33 --> Final output sent to browser
DEBUG - 2019-06-29 18:47:33 --> Total execution time: 0.4832
INFO - 2019-06-29 12:47:41 --> Config Class Initialized
INFO - 2019-06-29 12:47:41 --> Hooks Class Initialized
DEBUG - 2019-06-29 12:47:41 --> UTF-8 Support Enabled
INFO - 2019-06-29 12:47:41 --> Utf8 Class Initialized
INFO - 2019-06-29 12:47:41 --> URI Class Initialized
DEBUG - 2019-06-29 12:47:41 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/routes.php
INFO - 2019-06-29 12:47:41 --> Router Class Initialized
INFO - 2019-06-29 12:47:41 --> Output Class Initialized
INFO - 2019-06-29 12:47:41 --> Security Class Initialized
DEBUG - 2019-06-29 12:47:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 12:47:41 --> Input Class Initialized
INFO - 2019-06-29 12:47:42 --> Language Class Initialized
INFO - 2019-06-29 12:47:42 --> Language Class Initialized
INFO - 2019-06-29 12:47:42 --> Config Class Initialized
INFO - 2019-06-29 12:47:42 --> Loader Class Initialized
DEBUG - 2019-06-29 12:47:42 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/site.php
INFO - 2019-06-29 12:47:42 --> Helper loaded: url_helper
INFO - 2019-06-29 12:47:42 --> Helper loaded: inflector_helper
INFO - 2019-06-29 12:47:42 --> Helper loaded: string_helper
INFO - 2019-06-29 12:47:42 --> Helper loaded: array_helper
INFO - 2019-06-29 12:47:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 12:47:42 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/autoload.php
DEBUG - 2019-06-29 12:47:42 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/helpers/adminlte_helper.php
INFO - 2019-06-29 12:47:42 --> Database Driver Class Initialized
DEBUG - 2019-06-29 12:47:42 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/libraries/Crud.php
INFO - 2019-06-29 12:47:42 --> Helper loaded: form_helper
DEBUG - 2019-06-29 12:47:42 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-06-29 12:47:42 --> Form Validation Class Initialized
DEBUG - 2019-06-29 12:47:42 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-06-29 12:47:42 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-06-29 12:47:42 --> Pagination Class Initialized
INFO - 2019-06-29 12:47:42 --> Controller Class Initialized
INFO - 2019-06-29 18:47:42 --> Model Class Initialized
INFO - 2019-06-29 18:47:42 --> Model Class Initialized
INFO - 2019-06-29 18:47:42 --> Model Class Initialized
INFO - 2019-06-29 18:47:42 --> Final output sent to browser
DEBUG - 2019-06-29 18:47:42 --> Total execution time: 0.4300
INFO - 2019-06-29 12:47:44 --> Config Class Initialized
INFO - 2019-06-29 12:47:44 --> Hooks Class Initialized
DEBUG - 2019-06-29 12:47:44 --> UTF-8 Support Enabled
INFO - 2019-06-29 12:47:44 --> Utf8 Class Initialized
INFO - 2019-06-29 12:47:44 --> URI Class Initialized
DEBUG - 2019-06-29 12:47:44 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/routes.php
INFO - 2019-06-29 12:47:44 --> Router Class Initialized
INFO - 2019-06-29 12:47:45 --> Output Class Initialized
INFO - 2019-06-29 12:47:45 --> Security Class Initialized
DEBUG - 2019-06-29 12:47:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 12:47:45 --> Input Class Initialized
INFO - 2019-06-29 12:47:45 --> Language Class Initialized
INFO - 2019-06-29 12:47:45 --> Language Class Initialized
INFO - 2019-06-29 12:47:45 --> Config Class Initialized
INFO - 2019-06-29 12:47:45 --> Loader Class Initialized
DEBUG - 2019-06-29 12:47:45 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/site.php
INFO - 2019-06-29 12:47:45 --> Helper loaded: url_helper
INFO - 2019-06-29 12:47:45 --> Helper loaded: inflector_helper
INFO - 2019-06-29 12:47:45 --> Helper loaded: string_helper
INFO - 2019-06-29 12:47:45 --> Helper loaded: array_helper
INFO - 2019-06-29 12:47:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 12:47:45 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/autoload.php
DEBUG - 2019-06-29 12:47:45 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/helpers/adminlte_helper.php
INFO - 2019-06-29 12:47:45 --> Database Driver Class Initialized
DEBUG - 2019-06-29 12:47:45 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/libraries/Crud.php
INFO - 2019-06-29 12:47:45 --> Helper loaded: form_helper
DEBUG - 2019-06-29 12:47:45 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-06-29 12:47:45 --> Form Validation Class Initialized
DEBUG - 2019-06-29 12:47:45 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-06-29 12:47:45 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-06-29 12:47:45 --> Pagination Class Initialized
INFO - 2019-06-29 12:47:45 --> Controller Class Initialized
INFO - 2019-06-29 18:47:45 --> Model Class Initialized
INFO - 2019-06-29 18:47:45 --> Model Class Initialized
INFO - 2019-06-29 18:47:45 --> Model Class Initialized
INFO - 2019-06-29 18:47:45 --> Final output sent to browser
DEBUG - 2019-06-29 18:47:45 --> Total execution time: 0.3142
INFO - 2019-06-29 13:01:50 --> Config Class Initialized
INFO - 2019-06-29 13:01:50 --> Hooks Class Initialized
DEBUG - 2019-06-29 13:01:50 --> UTF-8 Support Enabled
INFO - 2019-06-29 13:01:50 --> Utf8 Class Initialized
INFO - 2019-06-29 13:01:50 --> URI Class Initialized
INFO - 2019-06-29 13:01:50 --> Router Class Initialized
INFO - 2019-06-29 13:01:50 --> Output Class Initialized
INFO - 2019-06-29 13:01:50 --> Security Class Initialized
DEBUG - 2019-06-29 13:01:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 13:01:50 --> Input Class Initialized
INFO - 2019-06-29 13:01:50 --> Language Class Initialized
INFO - 2019-06-29 13:01:50 --> Language Class Initialized
INFO - 2019-06-29 13:01:50 --> Config Class Initialized
INFO - 2019-06-29 13:01:50 --> Loader Class Initialized
DEBUG - 2019-06-29 13:01:50 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 13:01:50 --> Helper loaded: url_helper
INFO - 2019-06-29 13:01:50 --> Helper loaded: inflector_helper
INFO - 2019-06-29 13:01:50 --> Helper loaded: string_helper
INFO - 2019-06-29 13:01:50 --> Helper loaded: array_helper
INFO - 2019-06-29 13:01:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 13:01:50 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 13:01:50 --> Database Driver Class Initialized
INFO - 2019-06-29 13:01:50 --> Controller Class Initialized
INFO - 2019-06-29 19:01:50 --> Helper loaded: language_helper
INFO - 2019-06-29 19:01:50 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 19:01:50 --> Model Class Initialized
INFO - 2019-06-29 19:01:50 --> Model Class Initialized
INFO - 2019-06-29 19:01:50 --> Model Class Initialized
INFO - 2019-06-29 19:01:50 --> Model Class Initialized
INFO - 2019-06-29 19:01:50 --> Final output sent to browser
DEBUG - 2019-06-29 19:01:50 --> Total execution time: 0.3335
INFO - 2019-06-29 13:01:51 --> Config Class Initialized
INFO - 2019-06-29 13:01:51 --> Hooks Class Initialized
DEBUG - 2019-06-29 13:01:51 --> UTF-8 Support Enabled
INFO - 2019-06-29 13:01:51 --> Utf8 Class Initialized
INFO - 2019-06-29 13:01:51 --> URI Class Initialized
INFO - 2019-06-29 13:01:51 --> Router Class Initialized
INFO - 2019-06-29 13:01:51 --> Output Class Initialized
INFO - 2019-06-29 13:01:51 --> Security Class Initialized
DEBUG - 2019-06-29 13:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 13:01:51 --> Input Class Initialized
INFO - 2019-06-29 13:01:51 --> Language Class Initialized
INFO - 2019-06-29 13:01:51 --> Language Class Initialized
INFO - 2019-06-29 13:01:51 --> Config Class Initialized
INFO - 2019-06-29 13:01:51 --> Loader Class Initialized
DEBUG - 2019-06-29 13:01:51 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 13:01:51 --> Helper loaded: url_helper
INFO - 2019-06-29 13:01:51 --> Helper loaded: inflector_helper
INFO - 2019-06-29 13:01:51 --> Helper loaded: string_helper
INFO - 2019-06-29 13:01:51 --> Helper loaded: array_helper
INFO - 2019-06-29 13:01:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 13:01:51 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 13:01:51 --> Database Driver Class Initialized
INFO - 2019-06-29 13:01:51 --> Controller Class Initialized
INFO - 2019-06-29 19:01:51 --> Helper loaded: language_helper
INFO - 2019-06-29 19:01:51 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 19:01:51 --> Model Class Initialized
INFO - 2019-06-29 19:01:51 --> Model Class Initialized
INFO - 2019-06-29 19:01:51 --> Model Class Initialized
INFO - 2019-06-29 19:01:51 --> Model Class Initialized
INFO - 2019-06-29 19:01:51 --> Model Class Initialized
INFO - 2019-06-29 19:01:51 --> Final output sent to browser
DEBUG - 2019-06-29 19:01:51 --> Total execution time: 0.2589
INFO - 2019-06-29 13:01:54 --> Config Class Initialized
INFO - 2019-06-29 13:01:54 --> Hooks Class Initialized
DEBUG - 2019-06-29 13:01:54 --> UTF-8 Support Enabled
INFO - 2019-06-29 13:01:54 --> Utf8 Class Initialized
INFO - 2019-06-29 13:01:54 --> URI Class Initialized
INFO - 2019-06-29 13:01:54 --> Router Class Initialized
INFO - 2019-06-29 13:01:54 --> Output Class Initialized
INFO - 2019-06-29 13:01:54 --> Security Class Initialized
DEBUG - 2019-06-29 13:01:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 13:01:54 --> Input Class Initialized
INFO - 2019-06-29 13:01:54 --> Language Class Initialized
INFO - 2019-06-29 13:01:54 --> Language Class Initialized
INFO - 2019-06-29 13:01:54 --> Config Class Initialized
INFO - 2019-06-29 13:01:54 --> Loader Class Initialized
DEBUG - 2019-06-29 13:01:54 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 13:01:54 --> Helper loaded: url_helper
INFO - 2019-06-29 13:01:54 --> Helper loaded: inflector_helper
INFO - 2019-06-29 13:01:54 --> Helper loaded: string_helper
INFO - 2019-06-29 13:01:54 --> Helper loaded: array_helper
INFO - 2019-06-29 13:01:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 13:01:54 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 13:01:54 --> Database Driver Class Initialized
INFO - 2019-06-29 13:01:54 --> Controller Class Initialized
INFO - 2019-06-29 19:01:54 --> Helper loaded: language_helper
INFO - 2019-06-29 19:01:54 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 19:01:54 --> Model Class Initialized
INFO - 2019-06-29 19:01:54 --> Model Class Initialized
INFO - 2019-06-29 19:01:54 --> Model Class Initialized
INFO - 2019-06-29 19:01:54 --> Model Class Initialized
INFO - 2019-06-29 19:01:54 --> Helper loaded: form_helper
INFO - 2019-06-29 19:01:54 --> Form Validation Class Initialized
DEBUG - 2019-06-29 19:01:54 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-29 19:01:54 --> Model Class Initialized
INFO - 2019-06-29 19:01:54 --> Model Class Initialized
INFO - 2019-06-29 19:01:54 --> Final output sent to browser
DEBUG - 2019-06-29 19:01:54 --> Total execution time: 0.3066
INFO - 2019-06-29 13:01:58 --> Config Class Initialized
INFO - 2019-06-29 13:01:58 --> Hooks Class Initialized
DEBUG - 2019-06-29 13:01:58 --> UTF-8 Support Enabled
INFO - 2019-06-29 13:01:58 --> Utf8 Class Initialized
INFO - 2019-06-29 13:01:58 --> URI Class Initialized
INFO - 2019-06-29 13:01:58 --> Router Class Initialized
INFO - 2019-06-29 13:01:58 --> Output Class Initialized
INFO - 2019-06-29 13:01:58 --> Security Class Initialized
DEBUG - 2019-06-29 13:01:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 13:01:58 --> Input Class Initialized
INFO - 2019-06-29 13:01:58 --> Language Class Initialized
INFO - 2019-06-29 13:01:58 --> Language Class Initialized
INFO - 2019-06-29 13:01:58 --> Config Class Initialized
INFO - 2019-06-29 13:01:58 --> Loader Class Initialized
DEBUG - 2019-06-29 13:01:59 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 13:01:59 --> Helper loaded: url_helper
INFO - 2019-06-29 13:01:59 --> Helper loaded: inflector_helper
INFO - 2019-06-29 13:01:59 --> Helper loaded: string_helper
INFO - 2019-06-29 13:01:59 --> Helper loaded: array_helper
INFO - 2019-06-29 13:01:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 13:01:59 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 13:01:59 --> Database Driver Class Initialized
INFO - 2019-06-29 13:01:59 --> Controller Class Initialized
INFO - 2019-06-29 19:01:59 --> Helper loaded: language_helper
INFO - 2019-06-29 19:01:59 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 19:01:59 --> Model Class Initialized
INFO - 2019-06-29 19:01:59 --> Model Class Initialized
INFO - 2019-06-29 19:01:59 --> Model Class Initialized
INFO - 2019-06-29 19:01:59 --> Model Class Initialized
INFO - 2019-06-29 19:01:59 --> Model Class Initialized
INFO - 2019-06-29 19:01:59 --> Final output sent to browser
DEBUG - 2019-06-29 19:01:59 --> Total execution time: 0.2676
INFO - 2019-06-29 13:51:53 --> Config Class Initialized
INFO - 2019-06-29 13:51:53 --> Hooks Class Initialized
DEBUG - 2019-06-29 13:51:53 --> UTF-8 Support Enabled
INFO - 2019-06-29 13:51:53 --> Utf8 Class Initialized
INFO - 2019-06-29 13:51:53 --> URI Class Initialized
INFO - 2019-06-29 13:51:53 --> Router Class Initialized
INFO - 2019-06-29 13:51:53 --> Output Class Initialized
INFO - 2019-06-29 13:51:53 --> Security Class Initialized
DEBUG - 2019-06-29 13:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 13:51:53 --> Input Class Initialized
INFO - 2019-06-29 13:51:53 --> Language Class Initialized
INFO - 2019-06-29 13:51:53 --> Language Class Initialized
INFO - 2019-06-29 13:51:53 --> Config Class Initialized
INFO - 2019-06-29 13:51:53 --> Loader Class Initialized
DEBUG - 2019-06-29 13:51:53 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 13:51:53 --> Helper loaded: url_helper
INFO - 2019-06-29 13:51:53 --> Helper loaded: inflector_helper
INFO - 2019-06-29 13:51:53 --> Helper loaded: string_helper
INFO - 2019-06-29 13:51:54 --> Helper loaded: array_helper
INFO - 2019-06-29 13:51:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 13:51:54 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 13:51:54 --> Database Driver Class Initialized
INFO - 2019-06-29 13:51:54 --> Controller Class Initialized
INFO - 2019-06-29 19:51:54 --> Helper loaded: language_helper
INFO - 2019-06-29 19:51:54 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 19:51:54 --> Model Class Initialized
INFO - 2019-06-29 19:51:54 --> Model Class Initialized
INFO - 2019-06-29 19:51:54 --> Model Class Initialized
INFO - 2019-06-29 19:51:54 --> Model Class Initialized
INFO - 2019-06-29 19:51:54 --> Model Class Initialized
INFO - 2019-06-29 19:51:54 --> Final output sent to browser
DEBUG - 2019-06-29 19:51:54 --> Total execution time: 0.5635
INFO - 2019-06-29 13:51:57 --> Config Class Initialized
INFO - 2019-06-29 13:51:57 --> Hooks Class Initialized
DEBUG - 2019-06-29 13:51:57 --> UTF-8 Support Enabled
INFO - 2019-06-29 13:51:57 --> Utf8 Class Initialized
INFO - 2019-06-29 13:51:57 --> URI Class Initialized
INFO - 2019-06-29 13:51:57 --> Router Class Initialized
INFO - 2019-06-29 13:51:57 --> Output Class Initialized
INFO - 2019-06-29 13:51:57 --> Security Class Initialized
DEBUG - 2019-06-29 13:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 13:51:57 --> Input Class Initialized
INFO - 2019-06-29 13:51:57 --> Language Class Initialized
INFO - 2019-06-29 13:51:57 --> Language Class Initialized
INFO - 2019-06-29 13:51:57 --> Config Class Initialized
INFO - 2019-06-29 13:51:57 --> Loader Class Initialized
DEBUG - 2019-06-29 13:51:57 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 13:51:57 --> Helper loaded: url_helper
INFO - 2019-06-29 13:51:57 --> Helper loaded: inflector_helper
INFO - 2019-06-29 13:51:57 --> Helper loaded: string_helper
INFO - 2019-06-29 13:51:57 --> Helper loaded: array_helper
INFO - 2019-06-29 13:51:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 13:51:57 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 13:51:57 --> Database Driver Class Initialized
INFO - 2019-06-29 13:51:57 --> Controller Class Initialized
INFO - 2019-06-29 19:51:57 --> Helper loaded: language_helper
INFO - 2019-06-29 19:51:57 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 19:51:57 --> Model Class Initialized
INFO - 2019-06-29 19:51:57 --> Model Class Initialized
INFO - 2019-06-29 19:51:57 --> Model Class Initialized
INFO - 2019-06-29 19:51:57 --> Model Class Initialized
INFO - 2019-06-29 19:51:58 --> Helper loaded: form_helper
INFO - 2019-06-29 19:51:58 --> Form Validation Class Initialized
DEBUG - 2019-06-29 19:51:58 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-29 19:51:58 --> Model Class Initialized
INFO - 2019-06-29 19:51:58 --> Model Class Initialized
INFO - 2019-06-29 19:51:58 --> Final output sent to browser
DEBUG - 2019-06-29 19:51:58 --> Total execution time: 1.0017
INFO - 2019-06-29 13:52:06 --> Config Class Initialized
INFO - 2019-06-29 13:52:06 --> Hooks Class Initialized
DEBUG - 2019-06-29 13:52:06 --> UTF-8 Support Enabled
INFO - 2019-06-29 13:52:06 --> Utf8 Class Initialized
INFO - 2019-06-29 13:52:06 --> URI Class Initialized
INFO - 2019-06-29 13:52:06 --> Router Class Initialized
INFO - 2019-06-29 13:52:06 --> Output Class Initialized
INFO - 2019-06-29 13:52:06 --> Security Class Initialized
DEBUG - 2019-06-29 13:52:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 13:52:06 --> Input Class Initialized
INFO - 2019-06-29 13:52:06 --> Language Class Initialized
INFO - 2019-06-29 13:52:06 --> Language Class Initialized
INFO - 2019-06-29 13:52:06 --> Config Class Initialized
INFO - 2019-06-29 13:52:06 --> Loader Class Initialized
DEBUG - 2019-06-29 13:52:06 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 13:52:06 --> Helper loaded: url_helper
INFO - 2019-06-29 13:52:06 --> Helper loaded: inflector_helper
INFO - 2019-06-29 13:52:06 --> Helper loaded: string_helper
INFO - 2019-06-29 13:52:06 --> Helper loaded: array_helper
INFO - 2019-06-29 13:52:06 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 13:52:06 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 13:52:06 --> Database Driver Class Initialized
INFO - 2019-06-29 13:52:06 --> Controller Class Initialized
INFO - 2019-06-29 19:52:06 --> Helper loaded: language_helper
INFO - 2019-06-29 19:52:06 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 19:52:06 --> Model Class Initialized
INFO - 2019-06-29 19:52:06 --> Model Class Initialized
INFO - 2019-06-29 19:52:06 --> Model Class Initialized
INFO - 2019-06-29 19:52:06 --> Model Class Initialized
INFO - 2019-06-29 19:52:06 --> Model Class Initialized
INFO - 2019-06-29 19:52:06 --> Final output sent to browser
DEBUG - 2019-06-29 19:52:06 --> Total execution time: 0.6713
INFO - 2019-06-29 13:52:09 --> Config Class Initialized
INFO - 2019-06-29 13:52:09 --> Hooks Class Initialized
DEBUG - 2019-06-29 13:52:09 --> UTF-8 Support Enabled
INFO - 2019-06-29 13:52:09 --> Utf8 Class Initialized
INFO - 2019-06-29 13:52:09 --> URI Class Initialized
INFO - 2019-06-29 13:52:09 --> Router Class Initialized
INFO - 2019-06-29 13:52:09 --> Output Class Initialized
INFO - 2019-06-29 13:52:09 --> Security Class Initialized
DEBUG - 2019-06-29 13:52:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 13:52:09 --> Input Class Initialized
INFO - 2019-06-29 13:52:09 --> Language Class Initialized
INFO - 2019-06-29 13:52:09 --> Language Class Initialized
INFO - 2019-06-29 13:52:09 --> Config Class Initialized
INFO - 2019-06-29 13:52:09 --> Loader Class Initialized
DEBUG - 2019-06-29 13:52:09 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 13:52:09 --> Helper loaded: url_helper
INFO - 2019-06-29 13:52:09 --> Helper loaded: inflector_helper
INFO - 2019-06-29 13:52:09 --> Helper loaded: string_helper
INFO - 2019-06-29 13:52:09 --> Helper loaded: array_helper
INFO - 2019-06-29 13:52:09 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 13:52:09 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 13:52:09 --> Database Driver Class Initialized
INFO - 2019-06-29 13:52:09 --> Controller Class Initialized
INFO - 2019-06-29 19:52:09 --> Helper loaded: language_helper
INFO - 2019-06-29 19:52:09 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 19:52:09 --> Model Class Initialized
INFO - 2019-06-29 19:52:09 --> Model Class Initialized
INFO - 2019-06-29 19:52:09 --> Model Class Initialized
INFO - 2019-06-29 19:52:09 --> Model Class Initialized
INFO - 2019-06-29 19:52:09 --> Helper loaded: form_helper
INFO - 2019-06-29 19:52:09 --> Form Validation Class Initialized
DEBUG - 2019-06-29 19:52:09 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-29 19:52:09 --> Model Class Initialized
INFO - 2019-06-29 19:52:09 --> Model Class Initialized
INFO - 2019-06-29 19:52:09 --> Final output sent to browser
DEBUG - 2019-06-29 19:52:09 --> Total execution time: 0.7141
INFO - 2019-06-29 13:52:15 --> Config Class Initialized
INFO - 2019-06-29 13:52:15 --> Hooks Class Initialized
DEBUG - 2019-06-29 13:52:15 --> UTF-8 Support Enabled
INFO - 2019-06-29 13:52:15 --> Utf8 Class Initialized
INFO - 2019-06-29 13:52:15 --> URI Class Initialized
INFO - 2019-06-29 13:52:15 --> Router Class Initialized
INFO - 2019-06-29 13:52:15 --> Output Class Initialized
INFO - 2019-06-29 13:52:15 --> Security Class Initialized
DEBUG - 2019-06-29 13:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 13:52:15 --> Input Class Initialized
INFO - 2019-06-29 13:52:15 --> Language Class Initialized
INFO - 2019-06-29 13:52:15 --> Language Class Initialized
INFO - 2019-06-29 13:52:15 --> Config Class Initialized
INFO - 2019-06-29 13:52:15 --> Loader Class Initialized
DEBUG - 2019-06-29 13:52:15 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 13:52:15 --> Helper loaded: url_helper
INFO - 2019-06-29 13:52:15 --> Helper loaded: inflector_helper
INFO - 2019-06-29 13:52:15 --> Helper loaded: string_helper
INFO - 2019-06-29 13:52:15 --> Helper loaded: array_helper
INFO - 2019-06-29 13:52:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 13:52:15 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 13:52:15 --> Database Driver Class Initialized
INFO - 2019-06-29 13:52:15 --> Controller Class Initialized
INFO - 2019-06-29 19:52:15 --> Helper loaded: language_helper
INFO - 2019-06-29 19:52:15 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 19:52:15 --> Model Class Initialized
INFO - 2019-06-29 19:52:15 --> Model Class Initialized
INFO - 2019-06-29 19:52:15 --> Model Class Initialized
INFO - 2019-06-29 19:52:15 --> Model Class Initialized
INFO - 2019-06-29 19:52:15 --> Helper loaded: form_helper
INFO - 2019-06-29 19:52:15 --> Form Validation Class Initialized
DEBUG - 2019-06-29 19:52:15 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-29 19:52:15 --> Model Class Initialized
INFO - 2019-06-29 19:52:15 --> Model Class Initialized
INFO - 2019-06-29 19:52:15 --> Final output sent to browser
DEBUG - 2019-06-29 19:52:15 --> Total execution time: 0.3116
INFO - 2019-06-29 13:52:17 --> Config Class Initialized
INFO - 2019-06-29 13:52:17 --> Hooks Class Initialized
DEBUG - 2019-06-29 13:52:17 --> UTF-8 Support Enabled
INFO - 2019-06-29 13:52:17 --> Utf8 Class Initialized
INFO - 2019-06-29 13:52:17 --> URI Class Initialized
INFO - 2019-06-29 13:52:17 --> Router Class Initialized
INFO - 2019-06-29 13:52:17 --> Output Class Initialized
INFO - 2019-06-29 13:52:17 --> Security Class Initialized
DEBUG - 2019-06-29 13:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 13:52:17 --> Input Class Initialized
INFO - 2019-06-29 13:52:17 --> Language Class Initialized
INFO - 2019-06-29 13:52:17 --> Language Class Initialized
INFO - 2019-06-29 13:52:17 --> Config Class Initialized
INFO - 2019-06-29 13:52:17 --> Loader Class Initialized
DEBUG - 2019-06-29 13:52:17 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 13:52:17 --> Helper loaded: url_helper
INFO - 2019-06-29 13:52:18 --> Helper loaded: inflector_helper
INFO - 2019-06-29 13:52:18 --> Helper loaded: string_helper
INFO - 2019-06-29 13:52:18 --> Helper loaded: array_helper
INFO - 2019-06-29 13:52:18 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 13:52:18 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 13:52:18 --> Database Driver Class Initialized
INFO - 2019-06-29 13:52:18 --> Controller Class Initialized
INFO - 2019-06-29 19:52:18 --> Helper loaded: language_helper
INFO - 2019-06-29 19:52:18 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 19:52:18 --> Model Class Initialized
INFO - 2019-06-29 19:52:18 --> Model Class Initialized
INFO - 2019-06-29 19:52:18 --> Model Class Initialized
INFO - 2019-06-29 19:52:18 --> Model Class Initialized
INFO - 2019-06-29 19:52:18 --> Model Class Initialized
INFO - 2019-06-29 19:52:18 --> Final output sent to browser
DEBUG - 2019-06-29 19:52:18 --> Total execution time: 0.3912
INFO - 2019-06-29 13:52:23 --> Config Class Initialized
INFO - 2019-06-29 13:52:23 --> Hooks Class Initialized
DEBUG - 2019-06-29 13:52:23 --> UTF-8 Support Enabled
INFO - 2019-06-29 13:52:23 --> Utf8 Class Initialized
INFO - 2019-06-29 13:52:23 --> URI Class Initialized
INFO - 2019-06-29 13:52:23 --> Router Class Initialized
INFO - 2019-06-29 13:52:23 --> Output Class Initialized
INFO - 2019-06-29 13:52:23 --> Security Class Initialized
DEBUG - 2019-06-29 13:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 13:52:23 --> Input Class Initialized
INFO - 2019-06-29 13:52:23 --> Language Class Initialized
INFO - 2019-06-29 13:52:23 --> Language Class Initialized
INFO - 2019-06-29 13:52:23 --> Config Class Initialized
INFO - 2019-06-29 13:52:23 --> Loader Class Initialized
DEBUG - 2019-06-29 13:52:23 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 13:52:23 --> Helper loaded: url_helper
INFO - 2019-06-29 13:52:23 --> Helper loaded: inflector_helper
INFO - 2019-06-29 13:52:23 --> Helper loaded: string_helper
INFO - 2019-06-29 13:52:23 --> Helper loaded: array_helper
INFO - 2019-06-29 13:52:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 13:52:23 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 13:52:23 --> Database Driver Class Initialized
INFO - 2019-06-29 13:52:24 --> Controller Class Initialized
INFO - 2019-06-29 19:52:24 --> Helper loaded: language_helper
INFO - 2019-06-29 19:52:24 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 19:52:24 --> Model Class Initialized
INFO - 2019-06-29 19:52:24 --> Model Class Initialized
INFO - 2019-06-29 19:52:24 --> Model Class Initialized
INFO - 2019-06-29 19:52:24 --> Model Class Initialized
INFO - 2019-06-29 19:52:24 --> Helper loaded: form_helper
INFO - 2019-06-29 19:52:24 --> Form Validation Class Initialized
DEBUG - 2019-06-29 19:52:24 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-29 19:52:24 --> Model Class Initialized
INFO - 2019-06-29 19:52:24 --> Model Class Initialized
INFO - 2019-06-29 19:52:24 --> Final output sent to browser
DEBUG - 2019-06-29 19:52:24 --> Total execution time: 0.5791
INFO - 2019-06-29 13:52:32 --> Config Class Initialized
INFO - 2019-06-29 13:52:32 --> Hooks Class Initialized
DEBUG - 2019-06-29 13:52:32 --> UTF-8 Support Enabled
INFO - 2019-06-29 13:52:32 --> Utf8 Class Initialized
INFO - 2019-06-29 13:52:32 --> URI Class Initialized
INFO - 2019-06-29 13:52:32 --> Router Class Initialized
INFO - 2019-06-29 13:52:32 --> Output Class Initialized
INFO - 2019-06-29 13:52:32 --> Security Class Initialized
DEBUG - 2019-06-29 13:52:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 13:52:32 --> Input Class Initialized
INFO - 2019-06-29 13:52:32 --> Language Class Initialized
INFO - 2019-06-29 13:52:32 --> Language Class Initialized
INFO - 2019-06-29 13:52:32 --> Config Class Initialized
INFO - 2019-06-29 13:52:32 --> Loader Class Initialized
DEBUG - 2019-06-29 13:52:32 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 13:52:32 --> Helper loaded: url_helper
INFO - 2019-06-29 13:52:32 --> Helper loaded: inflector_helper
INFO - 2019-06-29 13:52:32 --> Helper loaded: string_helper
INFO - 2019-06-29 13:52:32 --> Helper loaded: array_helper
INFO - 2019-06-29 13:52:32 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 13:52:32 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 13:52:32 --> Database Driver Class Initialized
INFO - 2019-06-29 13:52:32 --> Controller Class Initialized
INFO - 2019-06-29 19:52:32 --> Helper loaded: language_helper
INFO - 2019-06-29 19:52:32 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 19:52:32 --> Model Class Initialized
INFO - 2019-06-29 19:52:32 --> Model Class Initialized
INFO - 2019-06-29 19:52:32 --> Model Class Initialized
INFO - 2019-06-29 19:52:32 --> Model Class Initialized
INFO - 2019-06-29 19:52:32 --> Helper loaded: form_helper
INFO - 2019-06-29 19:52:32 --> Form Validation Class Initialized
DEBUG - 2019-06-29 19:52:32 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-29 19:52:32 --> Model Class Initialized
INFO - 2019-06-29 19:52:32 --> Model Class Initialized
INFO - 2019-06-29 19:52:32 --> Final output sent to browser
DEBUG - 2019-06-29 19:52:32 --> Total execution time: 0.5942
INFO - 2019-06-29 13:52:40 --> Config Class Initialized
INFO - 2019-06-29 13:52:40 --> Hooks Class Initialized
DEBUG - 2019-06-29 13:52:40 --> UTF-8 Support Enabled
INFO - 2019-06-29 13:52:40 --> Utf8 Class Initialized
INFO - 2019-06-29 13:52:40 --> URI Class Initialized
INFO - 2019-06-29 13:52:40 --> Router Class Initialized
INFO - 2019-06-29 13:52:40 --> Output Class Initialized
INFO - 2019-06-29 13:52:40 --> Security Class Initialized
DEBUG - 2019-06-29 13:52:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 13:52:40 --> Input Class Initialized
INFO - 2019-06-29 13:52:40 --> Language Class Initialized
INFO - 2019-06-29 13:52:40 --> Language Class Initialized
INFO - 2019-06-29 13:52:40 --> Config Class Initialized
INFO - 2019-06-29 13:52:40 --> Loader Class Initialized
DEBUG - 2019-06-29 13:52:40 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 13:52:40 --> Helper loaded: url_helper
INFO - 2019-06-29 13:52:40 --> Helper loaded: inflector_helper
INFO - 2019-06-29 13:52:40 --> Helper loaded: string_helper
INFO - 2019-06-29 13:52:40 --> Helper loaded: array_helper
INFO - 2019-06-29 13:52:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 13:52:40 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 13:52:40 --> Database Driver Class Initialized
INFO - 2019-06-29 13:52:40 --> Controller Class Initialized
INFO - 2019-06-29 19:52:40 --> Helper loaded: language_helper
INFO - 2019-06-29 19:52:40 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 19:52:40 --> Model Class Initialized
INFO - 2019-06-29 19:52:40 --> Model Class Initialized
INFO - 2019-06-29 19:52:40 --> Model Class Initialized
INFO - 2019-06-29 19:52:40 --> Model Class Initialized
INFO - 2019-06-29 19:52:40 --> Helper loaded: form_helper
INFO - 2019-06-29 19:52:40 --> Form Validation Class Initialized
DEBUG - 2019-06-29 19:52:40 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-29 19:52:41 --> Model Class Initialized
INFO - 2019-06-29 19:52:41 --> Model Class Initialized
INFO - 2019-06-29 19:52:41 --> Final output sent to browser
DEBUG - 2019-06-29 19:52:41 --> Total execution time: 0.4980
INFO - 2019-06-29 14:08:26 --> Config Class Initialized
INFO - 2019-06-29 14:08:26 --> Hooks Class Initialized
DEBUG - 2019-06-29 14:08:26 --> UTF-8 Support Enabled
INFO - 2019-06-29 14:08:26 --> Utf8 Class Initialized
INFO - 2019-06-29 14:08:26 --> URI Class Initialized
INFO - 2019-06-29 14:08:26 --> Router Class Initialized
INFO - 2019-06-29 14:08:26 --> Output Class Initialized
INFO - 2019-06-29 14:08:26 --> Security Class Initialized
DEBUG - 2019-06-29 14:08:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 14:08:26 --> Input Class Initialized
INFO - 2019-06-29 14:08:26 --> Language Class Initialized
INFO - 2019-06-29 14:08:26 --> Language Class Initialized
INFO - 2019-06-29 14:08:26 --> Config Class Initialized
INFO - 2019-06-29 14:08:26 --> Loader Class Initialized
DEBUG - 2019-06-29 14:08:26 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 14:08:27 --> Helper loaded: url_helper
INFO - 2019-06-29 14:08:27 --> Helper loaded: inflector_helper
INFO - 2019-06-29 14:08:27 --> Helper loaded: string_helper
INFO - 2019-06-29 14:08:27 --> Helper loaded: array_helper
INFO - 2019-06-29 14:08:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 14:08:27 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 14:08:27 --> Database Driver Class Initialized
INFO - 2019-06-29 14:08:27 --> Controller Class Initialized
INFO - 2019-06-29 20:08:27 --> Helper loaded: language_helper
INFO - 2019-06-29 20:08:27 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 20:08:27 --> Model Class Initialized
INFO - 2019-06-29 20:08:27 --> Model Class Initialized
INFO - 2019-06-29 20:08:27 --> Model Class Initialized
INFO - 2019-06-29 20:08:27 --> Model Class Initialized
INFO - 2019-06-29 20:08:27 --> Helper loaded: form_helper
INFO - 2019-06-29 20:08:27 --> Form Validation Class Initialized
DEBUG - 2019-06-29 20:08:27 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-29 20:08:27 --> Model Class Initialized
INFO - 2019-06-29 20:08:27 --> Model Class Initialized
INFO - 2019-06-29 20:08:27 --> Final output sent to browser
DEBUG - 2019-06-29 20:08:27 --> Total execution time: 0.7039
INFO - 2019-06-29 14:08:28 --> Config Class Initialized
INFO - 2019-06-29 14:08:28 --> Hooks Class Initialized
DEBUG - 2019-06-29 14:08:28 --> UTF-8 Support Enabled
INFO - 2019-06-29 14:08:28 --> Utf8 Class Initialized
INFO - 2019-06-29 14:08:28 --> URI Class Initialized
INFO - 2019-06-29 14:08:28 --> Router Class Initialized
INFO - 2019-06-29 14:08:28 --> Output Class Initialized
INFO - 2019-06-29 14:08:28 --> Security Class Initialized
DEBUG - 2019-06-29 14:08:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 14:08:28 --> Input Class Initialized
INFO - 2019-06-29 14:08:28 --> Language Class Initialized
INFO - 2019-06-29 14:08:28 --> Language Class Initialized
INFO - 2019-06-29 14:08:28 --> Config Class Initialized
INFO - 2019-06-29 14:08:28 --> Loader Class Initialized
DEBUG - 2019-06-29 14:08:28 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 14:08:28 --> Helper loaded: url_helper
INFO - 2019-06-29 14:08:28 --> Helper loaded: inflector_helper
INFO - 2019-06-29 14:08:28 --> Helper loaded: string_helper
INFO - 2019-06-29 14:08:28 --> Helper loaded: array_helper
INFO - 2019-06-29 14:08:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 14:08:28 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 14:08:28 --> Database Driver Class Initialized
INFO - 2019-06-29 14:08:29 --> Controller Class Initialized
INFO - 2019-06-29 20:08:29 --> Helper loaded: language_helper
INFO - 2019-06-29 20:08:29 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 20:08:29 --> Model Class Initialized
INFO - 2019-06-29 20:08:29 --> Model Class Initialized
INFO - 2019-06-29 20:08:29 --> Model Class Initialized
INFO - 2019-06-29 20:08:29 --> Model Class Initialized
INFO - 2019-06-29 20:08:29 --> Helper loaded: form_helper
INFO - 2019-06-29 20:08:29 --> Form Validation Class Initialized
DEBUG - 2019-06-29 20:08:29 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-29 20:08:29 --> Model Class Initialized
INFO - 2019-06-29 20:08:29 --> Model Class Initialized
INFO - 2019-06-29 20:08:29 --> Final output sent to browser
DEBUG - 2019-06-29 20:08:29 --> Total execution time: 1.0262
INFO - 2019-06-29 15:11:48 --> Config Class Initialized
INFO - 2019-06-29 15:11:48 --> Hooks Class Initialized
DEBUG - 2019-06-29 15:11:48 --> UTF-8 Support Enabled
INFO - 2019-06-29 15:11:48 --> Utf8 Class Initialized
INFO - 2019-06-29 15:11:48 --> URI Class Initialized
INFO - 2019-06-29 15:11:48 --> Router Class Initialized
INFO - 2019-06-29 15:11:48 --> Output Class Initialized
INFO - 2019-06-29 15:11:48 --> Security Class Initialized
DEBUG - 2019-06-29 15:11:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 15:11:48 --> Input Class Initialized
INFO - 2019-06-29 15:11:48 --> Language Class Initialized
INFO - 2019-06-29 15:11:48 --> Language Class Initialized
INFO - 2019-06-29 15:11:48 --> Config Class Initialized
INFO - 2019-06-29 15:11:48 --> Loader Class Initialized
DEBUG - 2019-06-29 15:11:48 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 15:11:48 --> Helper loaded: url_helper
INFO - 2019-06-29 15:11:48 --> Helper loaded: inflector_helper
INFO - 2019-06-29 15:11:48 --> Helper loaded: string_helper
INFO - 2019-06-29 15:11:48 --> Helper loaded: array_helper
INFO - 2019-06-29 15:11:48 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 15:11:48 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 15:11:48 --> Database Driver Class Initialized
INFO - 2019-06-29 15:11:48 --> Controller Class Initialized
INFO - 2019-06-29 21:11:48 --> Helper loaded: language_helper
INFO - 2019-06-29 21:11:48 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 21:11:48 --> Model Class Initialized
INFO - 2019-06-29 21:11:48 --> Model Class Initialized
INFO - 2019-06-29 21:11:48 --> Model Class Initialized
INFO - 2019-06-29 21:11:48 --> Model Class Initialized
INFO - 2019-06-29 21:11:48 --> Final output sent to browser
DEBUG - 2019-06-29 21:11:48 --> Total execution time: 0.3103
INFO - 2019-06-29 15:11:49 --> Config Class Initialized
INFO - 2019-06-29 15:11:49 --> Hooks Class Initialized
DEBUG - 2019-06-29 15:11:49 --> UTF-8 Support Enabled
INFO - 2019-06-29 15:11:49 --> Utf8 Class Initialized
INFO - 2019-06-29 15:11:49 --> URI Class Initialized
INFO - 2019-06-29 15:11:49 --> Router Class Initialized
INFO - 2019-06-29 15:11:49 --> Output Class Initialized
INFO - 2019-06-29 15:11:49 --> Security Class Initialized
DEBUG - 2019-06-29 15:11:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 15:11:49 --> Input Class Initialized
INFO - 2019-06-29 15:11:49 --> Language Class Initialized
INFO - 2019-06-29 15:11:49 --> Language Class Initialized
INFO - 2019-06-29 15:11:49 --> Config Class Initialized
INFO - 2019-06-29 15:11:49 --> Loader Class Initialized
DEBUG - 2019-06-29 15:11:49 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 15:11:49 --> Helper loaded: url_helper
INFO - 2019-06-29 15:11:49 --> Helper loaded: inflector_helper
INFO - 2019-06-29 15:11:49 --> Helper loaded: string_helper
INFO - 2019-06-29 15:11:49 --> Helper loaded: array_helper
INFO - 2019-06-29 15:11:49 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 15:11:49 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 15:11:49 --> Database Driver Class Initialized
INFO - 2019-06-29 15:11:49 --> Controller Class Initialized
INFO - 2019-06-29 21:11:49 --> Helper loaded: language_helper
INFO - 2019-06-29 21:11:49 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 21:11:49 --> Model Class Initialized
INFO - 2019-06-29 21:11:49 --> Model Class Initialized
INFO - 2019-06-29 21:11:49 --> Model Class Initialized
INFO - 2019-06-29 21:11:49 --> Model Class Initialized
INFO - 2019-06-29 21:11:49 --> Model Class Initialized
INFO - 2019-06-29 21:11:49 --> Final output sent to browser
DEBUG - 2019-06-29 21:11:49 --> Total execution time: 0.2779
INFO - 2019-06-29 15:16:46 --> Config Class Initialized
INFO - 2019-06-29 15:16:46 --> Hooks Class Initialized
DEBUG - 2019-06-29 15:16:46 --> UTF-8 Support Enabled
INFO - 2019-06-29 15:16:46 --> Utf8 Class Initialized
INFO - 2019-06-29 15:16:46 --> URI Class Initialized
INFO - 2019-06-29 15:16:46 --> Router Class Initialized
INFO - 2019-06-29 15:16:46 --> Output Class Initialized
INFO - 2019-06-29 15:16:46 --> Security Class Initialized
DEBUG - 2019-06-29 15:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 15:16:46 --> Input Class Initialized
INFO - 2019-06-29 15:16:46 --> Language Class Initialized
INFO - 2019-06-29 15:16:46 --> Language Class Initialized
INFO - 2019-06-29 15:16:46 --> Config Class Initialized
INFO - 2019-06-29 15:16:46 --> Loader Class Initialized
DEBUG - 2019-06-29 15:16:46 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 15:16:46 --> Helper loaded: url_helper
INFO - 2019-06-29 15:16:46 --> Helper loaded: inflector_helper
INFO - 2019-06-29 15:16:46 --> Helper loaded: string_helper
INFO - 2019-06-29 15:16:46 --> Helper loaded: array_helper
INFO - 2019-06-29 15:16:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 15:16:46 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 15:16:46 --> Database Driver Class Initialized
INFO - 2019-06-29 15:16:46 --> Controller Class Initialized
INFO - 2019-06-29 21:16:46 --> Helper loaded: language_helper
INFO - 2019-06-29 21:16:46 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 21:16:46 --> Model Class Initialized
INFO - 2019-06-29 21:16:46 --> Model Class Initialized
INFO - 2019-06-29 21:16:46 --> Model Class Initialized
INFO - 2019-06-29 15:16:46 --> Config Class Initialized
INFO - 2019-06-29 21:16:46 --> Model Class Initialized
INFO - 2019-06-29 15:16:46 --> Hooks Class Initialized
DEBUG - 2019-06-29 15:16:46 --> UTF-8 Support Enabled
INFO - 2019-06-29 21:16:46 --> Model Class Initialized
INFO - 2019-06-29 15:16:46 --> Utf8 Class Initialized
INFO - 2019-06-29 15:16:46 --> URI Class Initialized
INFO - 2019-06-29 21:16:46 --> Final output sent to browser
INFO - 2019-06-29 15:16:46 --> Router Class Initialized
DEBUG - 2019-06-29 21:16:46 --> Total execution time: 0.4275
INFO - 2019-06-29 15:16:46 --> Output Class Initialized
INFO - 2019-06-29 15:16:46 --> Security Class Initialized
DEBUG - 2019-06-29 15:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 15:16:46 --> Input Class Initialized
INFO - 2019-06-29 15:16:46 --> Language Class Initialized
INFO - 2019-06-29 15:16:46 --> Language Class Initialized
INFO - 2019-06-29 15:16:46 --> Config Class Initialized
INFO - 2019-06-29 15:16:46 --> Loader Class Initialized
DEBUG - 2019-06-29 15:16:46 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 15:16:46 --> Helper loaded: url_helper
INFO - 2019-06-29 15:16:46 --> Helper loaded: inflector_helper
INFO - 2019-06-29 15:16:46 --> Helper loaded: string_helper
INFO - 2019-06-29 15:16:46 --> Helper loaded: array_helper
INFO - 2019-06-29 15:16:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 15:16:46 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 15:16:46 --> Database Driver Class Initialized
INFO - 2019-06-29 15:16:46 --> Controller Class Initialized
INFO - 2019-06-29 21:16:46 --> Helper loaded: language_helper
INFO - 2019-06-29 21:16:46 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 21:16:46 --> Model Class Initialized
INFO - 2019-06-29 21:16:46 --> Model Class Initialized
INFO - 2019-06-29 21:16:46 --> Model Class Initialized
INFO - 2019-06-29 21:16:46 --> Model Class Initialized
INFO - 2019-06-29 21:16:46 --> Model Class Initialized
INFO - 2019-06-29 21:16:46 --> Final output sent to browser
DEBUG - 2019-06-29 21:16:46 --> Total execution time: 0.3210
INFO - 2019-06-29 15:16:50 --> Config Class Initialized
INFO - 2019-06-29 15:16:50 --> Hooks Class Initialized
DEBUG - 2019-06-29 15:16:50 --> UTF-8 Support Enabled
INFO - 2019-06-29 15:16:50 --> Utf8 Class Initialized
INFO - 2019-06-29 15:16:50 --> URI Class Initialized
INFO - 2019-06-29 15:16:50 --> Router Class Initialized
INFO - 2019-06-29 15:16:50 --> Output Class Initialized
INFO - 2019-06-29 15:16:50 --> Security Class Initialized
DEBUG - 2019-06-29 15:16:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 15:16:50 --> Input Class Initialized
INFO - 2019-06-29 15:16:50 --> Language Class Initialized
INFO - 2019-06-29 15:16:50 --> Language Class Initialized
INFO - 2019-06-29 15:16:50 --> Config Class Initialized
INFO - 2019-06-29 15:16:50 --> Loader Class Initialized
DEBUG - 2019-06-29 15:16:50 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 15:16:50 --> Helper loaded: url_helper
INFO - 2019-06-29 15:16:50 --> Helper loaded: inflector_helper
INFO - 2019-06-29 15:16:50 --> Helper loaded: string_helper
INFO - 2019-06-29 15:16:50 --> Helper loaded: array_helper
INFO - 2019-06-29 15:16:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 15:16:50 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 15:16:50 --> Database Driver Class Initialized
INFO - 2019-06-29 15:16:50 --> Controller Class Initialized
INFO - 2019-06-29 21:16:50 --> Helper loaded: language_helper
INFO - 2019-06-29 21:16:50 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 21:16:50 --> Model Class Initialized
INFO - 2019-06-29 21:16:50 --> Model Class Initialized
INFO - 2019-06-29 21:16:50 --> Model Class Initialized
INFO - 2019-06-29 21:16:50 --> Model Class Initialized
INFO - 2019-06-29 21:16:50 --> Helper loaded: form_helper
INFO - 2019-06-29 21:16:50 --> Form Validation Class Initialized
DEBUG - 2019-06-29 21:16:50 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-29 21:16:50 --> Model Class Initialized
INFO - 2019-06-29 21:16:50 --> Model Class Initialized
INFO - 2019-06-29 21:16:51 --> Final output sent to browser
DEBUG - 2019-06-29 21:16:51 --> Total execution time: 0.2808
INFO - 2019-06-29 15:27:28 --> Config Class Initialized
INFO - 2019-06-29 15:27:28 --> Hooks Class Initialized
DEBUG - 2019-06-29 15:27:28 --> UTF-8 Support Enabled
INFO - 2019-06-29 15:27:28 --> Utf8 Class Initialized
INFO - 2019-06-29 15:27:28 --> URI Class Initialized
INFO - 2019-06-29 15:27:28 --> Router Class Initialized
INFO - 2019-06-29 15:27:28 --> Output Class Initialized
INFO - 2019-06-29 15:27:28 --> Security Class Initialized
DEBUG - 2019-06-29 15:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 15:27:28 --> Input Class Initialized
INFO - 2019-06-29 15:27:28 --> Language Class Initialized
INFO - 2019-06-29 15:27:28 --> Language Class Initialized
INFO - 2019-06-29 15:27:28 --> Config Class Initialized
INFO - 2019-06-29 15:27:28 --> Loader Class Initialized
DEBUG - 2019-06-29 15:27:28 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 15:27:28 --> Helper loaded: url_helper
INFO - 2019-06-29 15:27:28 --> Helper loaded: inflector_helper
INFO - 2019-06-29 15:27:28 --> Helper loaded: string_helper
INFO - 2019-06-29 15:27:28 --> Helper loaded: array_helper
INFO - 2019-06-29 15:27:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 15:27:28 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 15:27:28 --> Database Driver Class Initialized
INFO - 2019-06-29 15:27:28 --> Controller Class Initialized
INFO - 2019-06-29 21:27:28 --> Helper loaded: language_helper
INFO - 2019-06-29 21:27:28 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 21:27:28 --> Model Class Initialized
INFO - 2019-06-29 21:27:28 --> Model Class Initialized
INFO - 2019-06-29 21:27:28 --> Model Class Initialized
INFO - 2019-06-29 21:27:28 --> Model Class Initialized
INFO - 2019-06-29 21:27:28 --> Helper loaded: form_helper
INFO - 2019-06-29 21:27:28 --> Form Validation Class Initialized
DEBUG - 2019-06-29 21:27:28 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-29 21:27:28 --> Model Class Initialized
INFO - 2019-06-29 21:27:28 --> Model Class Initialized
INFO - 2019-06-29 21:27:28 --> Final output sent to browser
DEBUG - 2019-06-29 21:27:28 --> Total execution time: 0.5448
INFO - 2019-06-29 15:30:37 --> Config Class Initialized
INFO - 2019-06-29 15:30:37 --> Hooks Class Initialized
DEBUG - 2019-06-29 15:30:37 --> UTF-8 Support Enabled
INFO - 2019-06-29 15:30:37 --> Utf8 Class Initialized
INFO - 2019-06-29 15:30:37 --> URI Class Initialized
INFO - 2019-06-29 15:30:37 --> Router Class Initialized
INFO - 2019-06-29 15:30:37 --> Output Class Initialized
INFO - 2019-06-29 15:30:37 --> Security Class Initialized
DEBUG - 2019-06-29 15:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 15:30:37 --> Input Class Initialized
INFO - 2019-06-29 15:30:37 --> Language Class Initialized
INFO - 2019-06-29 15:30:37 --> Language Class Initialized
INFO - 2019-06-29 15:30:37 --> Config Class Initialized
INFO - 2019-06-29 15:30:37 --> Loader Class Initialized
DEBUG - 2019-06-29 15:30:37 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 15:30:37 --> Helper loaded: url_helper
INFO - 2019-06-29 15:30:37 --> Helper loaded: inflector_helper
INFO - 2019-06-29 15:30:37 --> Helper loaded: string_helper
INFO - 2019-06-29 15:30:37 --> Helper loaded: array_helper
INFO - 2019-06-29 15:30:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 15:30:37 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 15:30:37 --> Database Driver Class Initialized
INFO - 2019-06-29 15:30:37 --> Controller Class Initialized
INFO - 2019-06-29 21:30:37 --> Helper loaded: language_helper
INFO - 2019-06-29 21:30:37 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 21:30:37 --> Model Class Initialized
INFO - 2019-06-29 21:30:37 --> Model Class Initialized
INFO - 2019-06-29 21:30:37 --> Model Class Initialized
INFO - 2019-06-29 21:30:37 --> Model Class Initialized
INFO - 2019-06-29 21:30:37 --> Helper loaded: form_helper
INFO - 2019-06-29 21:30:37 --> Form Validation Class Initialized
DEBUG - 2019-06-29 21:30:37 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-29 21:30:37 --> Model Class Initialized
INFO - 2019-06-29 21:30:37 --> Model Class Initialized
INFO - 2019-06-29 21:30:37 --> Final output sent to browser
DEBUG - 2019-06-29 21:30:37 --> Total execution time: 0.6032
INFO - 2019-06-29 15:31:08 --> Config Class Initialized
INFO - 2019-06-29 15:31:08 --> Hooks Class Initialized
DEBUG - 2019-06-29 15:31:08 --> UTF-8 Support Enabled
INFO - 2019-06-29 15:31:08 --> Utf8 Class Initialized
INFO - 2019-06-29 15:31:08 --> URI Class Initialized
INFO - 2019-06-29 15:31:08 --> Router Class Initialized
INFO - 2019-06-29 15:31:08 --> Output Class Initialized
INFO - 2019-06-29 15:31:08 --> Security Class Initialized
DEBUG - 2019-06-29 15:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 15:31:08 --> Input Class Initialized
INFO - 2019-06-29 15:31:08 --> Language Class Initialized
INFO - 2019-06-29 15:31:08 --> Language Class Initialized
INFO - 2019-06-29 15:31:08 --> Config Class Initialized
INFO - 2019-06-29 15:31:08 --> Loader Class Initialized
DEBUG - 2019-06-29 15:31:08 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 15:31:08 --> Helper loaded: url_helper
INFO - 2019-06-29 15:31:08 --> Helper loaded: inflector_helper
INFO - 2019-06-29 15:31:08 --> Helper loaded: string_helper
INFO - 2019-06-29 15:31:08 --> Helper loaded: array_helper
INFO - 2019-06-29 15:31:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 15:31:08 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 15:31:08 --> Database Driver Class Initialized
INFO - 2019-06-29 15:31:08 --> Controller Class Initialized
INFO - 2019-06-29 21:31:08 --> Helper loaded: language_helper
INFO - 2019-06-29 21:31:08 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 21:31:08 --> Model Class Initialized
INFO - 2019-06-29 21:31:08 --> Model Class Initialized
INFO - 2019-06-29 21:31:08 --> Model Class Initialized
INFO - 2019-06-29 21:31:08 --> Model Class Initialized
INFO - 2019-06-29 21:31:08 --> Helper loaded: form_helper
INFO - 2019-06-29 21:31:08 --> Form Validation Class Initialized
DEBUG - 2019-06-29 21:31:08 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-29 21:31:08 --> Model Class Initialized
INFO - 2019-06-29 21:31:09 --> Model Class Initialized
INFO - 2019-06-29 21:31:09 --> Final output sent to browser
DEBUG - 2019-06-29 21:31:09 --> Total execution time: 0.6792
INFO - 2019-06-29 15:31:28 --> Config Class Initialized
INFO - 2019-06-29 15:31:28 --> Hooks Class Initialized
DEBUG - 2019-06-29 15:31:28 --> UTF-8 Support Enabled
INFO - 2019-06-29 15:31:28 --> Utf8 Class Initialized
INFO - 2019-06-29 15:31:28 --> URI Class Initialized
INFO - 2019-06-29 15:31:28 --> Router Class Initialized
INFO - 2019-06-29 15:31:28 --> Output Class Initialized
INFO - 2019-06-29 15:31:28 --> Security Class Initialized
DEBUG - 2019-06-29 15:31:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 15:31:28 --> Input Class Initialized
INFO - 2019-06-29 15:31:28 --> Language Class Initialized
INFO - 2019-06-29 15:31:28 --> Language Class Initialized
INFO - 2019-06-29 15:31:28 --> Config Class Initialized
INFO - 2019-06-29 15:31:28 --> Loader Class Initialized
DEBUG - 2019-06-29 15:31:28 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 15:31:28 --> Helper loaded: url_helper
INFO - 2019-06-29 15:31:28 --> Helper loaded: inflector_helper
INFO - 2019-06-29 15:31:28 --> Helper loaded: string_helper
INFO - 2019-06-29 15:31:28 --> Helper loaded: array_helper
INFO - 2019-06-29 15:31:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 15:31:28 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 15:31:28 --> Database Driver Class Initialized
INFO - 2019-06-29 15:31:28 --> Controller Class Initialized
INFO - 2019-06-29 21:31:28 --> Helper loaded: language_helper
INFO - 2019-06-29 21:31:28 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 21:31:28 --> Model Class Initialized
INFO - 2019-06-29 21:31:28 --> Model Class Initialized
INFO - 2019-06-29 21:31:28 --> Model Class Initialized
INFO - 2019-06-29 21:31:28 --> Model Class Initialized
INFO - 2019-06-29 21:31:28 --> Helper loaded: form_helper
INFO - 2019-06-29 21:31:28 --> Form Validation Class Initialized
DEBUG - 2019-06-29 21:31:28 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-29 21:31:28 --> Model Class Initialized
INFO - 2019-06-29 21:31:28 --> Model Class Initialized
INFO - 2019-06-29 21:31:29 --> Final output sent to browser
DEBUG - 2019-06-29 21:31:29 --> Total execution time: 0.5908
INFO - 2019-06-29 15:33:42 --> Config Class Initialized
INFO - 2019-06-29 15:33:42 --> Hooks Class Initialized
DEBUG - 2019-06-29 15:33:42 --> UTF-8 Support Enabled
INFO - 2019-06-29 15:33:42 --> Utf8 Class Initialized
INFO - 2019-06-29 15:33:42 --> URI Class Initialized
INFO - 2019-06-29 15:33:42 --> Router Class Initialized
INFO - 2019-06-29 15:33:42 --> Output Class Initialized
INFO - 2019-06-29 15:33:42 --> Security Class Initialized
DEBUG - 2019-06-29 15:33:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 15:33:42 --> Input Class Initialized
INFO - 2019-06-29 15:33:42 --> Language Class Initialized
INFO - 2019-06-29 15:33:42 --> Language Class Initialized
INFO - 2019-06-29 15:33:42 --> Config Class Initialized
INFO - 2019-06-29 15:33:42 --> Loader Class Initialized
DEBUG - 2019-06-29 15:33:42 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 15:33:42 --> Helper loaded: url_helper
INFO - 2019-06-29 15:33:42 --> Helper loaded: inflector_helper
INFO - 2019-06-29 15:33:42 --> Helper loaded: string_helper
INFO - 2019-06-29 15:33:42 --> Helper loaded: array_helper
INFO - 2019-06-29 15:33:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 15:33:42 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 15:33:42 --> Database Driver Class Initialized
INFO - 2019-06-29 15:33:42 --> Controller Class Initialized
INFO - 2019-06-29 21:33:42 --> Helper loaded: language_helper
INFO - 2019-06-29 21:33:42 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 21:33:42 --> Model Class Initialized
INFO - 2019-06-29 21:33:42 --> Model Class Initialized
INFO - 2019-06-29 21:33:42 --> Model Class Initialized
INFO - 2019-06-29 21:33:42 --> Model Class Initialized
INFO - 2019-06-29 21:33:42 --> Model Class Initialized
INFO - 2019-06-29 21:33:42 --> Final output sent to browser
DEBUG - 2019-06-29 21:33:42 --> Total execution time: 0.3653
INFO - 2019-06-29 15:33:47 --> Config Class Initialized
INFO - 2019-06-29 15:33:47 --> Hooks Class Initialized
DEBUG - 2019-06-29 15:33:47 --> UTF-8 Support Enabled
INFO - 2019-06-29 15:33:47 --> Utf8 Class Initialized
INFO - 2019-06-29 15:33:47 --> URI Class Initialized
INFO - 2019-06-29 15:33:47 --> Router Class Initialized
INFO - 2019-06-29 15:33:47 --> Output Class Initialized
INFO - 2019-06-29 15:33:47 --> Security Class Initialized
DEBUG - 2019-06-29 15:33:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 15:33:47 --> Input Class Initialized
INFO - 2019-06-29 15:33:47 --> Language Class Initialized
INFO - 2019-06-29 15:33:47 --> Language Class Initialized
INFO - 2019-06-29 15:33:47 --> Config Class Initialized
INFO - 2019-06-29 15:33:47 --> Loader Class Initialized
DEBUG - 2019-06-29 15:33:47 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 15:33:47 --> Helper loaded: url_helper
INFO - 2019-06-29 15:33:47 --> Helper loaded: inflector_helper
INFO - 2019-06-29 15:33:47 --> Helper loaded: string_helper
INFO - 2019-06-29 15:33:47 --> Helper loaded: array_helper
INFO - 2019-06-29 15:33:47 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 15:33:47 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 15:33:47 --> Database Driver Class Initialized
INFO - 2019-06-29 15:33:47 --> Controller Class Initialized
INFO - 2019-06-29 21:33:47 --> Helper loaded: language_helper
INFO - 2019-06-29 21:33:47 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 21:33:47 --> Model Class Initialized
INFO - 2019-06-29 21:33:47 --> Model Class Initialized
INFO - 2019-06-29 21:33:47 --> Model Class Initialized
INFO - 2019-06-29 21:33:47 --> Model Class Initialized
INFO - 2019-06-29 21:33:47 --> Helper loaded: form_helper
INFO - 2019-06-29 21:33:47 --> Form Validation Class Initialized
DEBUG - 2019-06-29 21:33:47 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-29 21:33:47 --> Model Class Initialized
INFO - 2019-06-29 21:33:47 --> Model Class Initialized
INFO - 2019-06-29 21:33:47 --> Final output sent to browser
DEBUG - 2019-06-29 21:33:47 --> Total execution time: 0.2926
INFO - 2019-06-29 15:36:44 --> Config Class Initialized
INFO - 2019-06-29 15:36:44 --> Hooks Class Initialized
DEBUG - 2019-06-29 15:36:44 --> UTF-8 Support Enabled
INFO - 2019-06-29 15:36:44 --> Utf8 Class Initialized
INFO - 2019-06-29 15:36:44 --> URI Class Initialized
INFO - 2019-06-29 15:36:44 --> Router Class Initialized
INFO - 2019-06-29 15:36:44 --> Output Class Initialized
INFO - 2019-06-29 15:36:44 --> Security Class Initialized
DEBUG - 2019-06-29 15:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 15:36:44 --> Input Class Initialized
INFO - 2019-06-29 15:36:44 --> Language Class Initialized
INFO - 2019-06-29 15:36:44 --> Language Class Initialized
INFO - 2019-06-29 15:36:44 --> Config Class Initialized
INFO - 2019-06-29 15:36:44 --> Loader Class Initialized
DEBUG - 2019-06-29 15:36:44 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 15:36:44 --> Helper loaded: url_helper
INFO - 2019-06-29 15:36:44 --> Helper loaded: inflector_helper
INFO - 2019-06-29 15:36:44 --> Helper loaded: string_helper
INFO - 2019-06-29 15:36:44 --> Helper loaded: array_helper
INFO - 2019-06-29 15:36:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 15:36:44 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 15:36:44 --> Database Driver Class Initialized
INFO - 2019-06-29 15:36:44 --> Controller Class Initialized
INFO - 2019-06-29 21:36:44 --> Helper loaded: language_helper
INFO - 2019-06-29 21:36:44 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 21:36:44 --> Model Class Initialized
INFO - 2019-06-29 21:36:44 --> Model Class Initialized
INFO - 2019-06-29 21:36:44 --> Model Class Initialized
INFO - 2019-06-29 21:36:44 --> Model Class Initialized
INFO - 2019-06-29 21:36:44 --> Helper loaded: form_helper
INFO - 2019-06-29 21:36:44 --> Form Validation Class Initialized
DEBUG - 2019-06-29 21:36:44 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-29 21:36:45 --> Model Class Initialized
INFO - 2019-06-29 21:36:45 --> Model Class Initialized
INFO - 2019-06-29 21:36:45 --> Final output sent to browser
DEBUG - 2019-06-29 21:36:45 --> Total execution time: 1.0254
INFO - 2019-06-29 15:41:27 --> Config Class Initialized
INFO - 2019-06-29 15:41:27 --> Hooks Class Initialized
DEBUG - 2019-06-29 15:41:27 --> UTF-8 Support Enabled
INFO - 2019-06-29 15:41:27 --> Utf8 Class Initialized
INFO - 2019-06-29 15:41:27 --> URI Class Initialized
INFO - 2019-06-29 15:41:27 --> Router Class Initialized
INFO - 2019-06-29 15:41:27 --> Output Class Initialized
INFO - 2019-06-29 15:41:27 --> Security Class Initialized
DEBUG - 2019-06-29 15:41:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 15:41:27 --> Input Class Initialized
INFO - 2019-06-29 15:41:27 --> Language Class Initialized
INFO - 2019-06-29 15:41:27 --> Language Class Initialized
INFO - 2019-06-29 15:41:27 --> Config Class Initialized
INFO - 2019-06-29 15:41:27 --> Loader Class Initialized
DEBUG - 2019-06-29 15:41:27 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 15:41:27 --> Helper loaded: url_helper
INFO - 2019-06-29 15:41:27 --> Helper loaded: inflector_helper
INFO - 2019-06-29 15:41:27 --> Helper loaded: string_helper
INFO - 2019-06-29 15:41:27 --> Helper loaded: array_helper
INFO - 2019-06-29 15:41:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 15:41:27 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 15:41:27 --> Database Driver Class Initialized
INFO - 2019-06-29 15:41:27 --> Controller Class Initialized
INFO - 2019-06-29 21:41:27 --> Helper loaded: language_helper
INFO - 2019-06-29 21:41:27 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 21:41:27 --> Model Class Initialized
INFO - 2019-06-29 21:41:27 --> Model Class Initialized
INFO - 2019-06-29 21:41:27 --> Model Class Initialized
INFO - 2019-06-29 21:41:27 --> Model Class Initialized
INFO - 2019-06-29 21:41:27 --> Helper loaded: form_helper
INFO - 2019-06-29 21:41:27 --> Form Validation Class Initialized
DEBUG - 2019-06-29 21:41:27 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-29 21:41:27 --> Model Class Initialized
INFO - 2019-06-29 21:41:27 --> Model Class Initialized
INFO - 2019-06-29 21:41:27 --> Final output sent to browser
DEBUG - 2019-06-29 21:41:27 --> Total execution time: 0.6302
INFO - 2019-06-29 15:41:28 --> Config Class Initialized
INFO - 2019-06-29 15:41:28 --> Hooks Class Initialized
DEBUG - 2019-06-29 15:41:28 --> UTF-8 Support Enabled
INFO - 2019-06-29 15:41:28 --> Utf8 Class Initialized
INFO - 2019-06-29 15:41:28 --> URI Class Initialized
INFO - 2019-06-29 15:41:28 --> Router Class Initialized
INFO - 2019-06-29 15:41:28 --> Output Class Initialized
INFO - 2019-06-29 15:41:28 --> Security Class Initialized
DEBUG - 2019-06-29 15:41:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 15:41:28 --> Input Class Initialized
INFO - 2019-06-29 15:41:28 --> Language Class Initialized
INFO - 2019-06-29 15:41:28 --> Language Class Initialized
INFO - 2019-06-29 15:41:28 --> Config Class Initialized
INFO - 2019-06-29 15:41:28 --> Loader Class Initialized
DEBUG - 2019-06-29 15:41:28 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 15:41:28 --> Helper loaded: url_helper
INFO - 2019-06-29 15:41:28 --> Helper loaded: inflector_helper
INFO - 2019-06-29 15:41:28 --> Helper loaded: string_helper
INFO - 2019-06-29 15:41:28 --> Helper loaded: array_helper
INFO - 2019-06-29 15:41:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 15:41:29 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 15:41:29 --> Database Driver Class Initialized
INFO - 2019-06-29 15:41:29 --> Controller Class Initialized
INFO - 2019-06-29 21:41:29 --> Helper loaded: language_helper
INFO - 2019-06-29 21:41:29 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 21:41:29 --> Model Class Initialized
INFO - 2019-06-29 21:41:29 --> Model Class Initialized
INFO - 2019-06-29 21:41:29 --> Model Class Initialized
INFO - 2019-06-29 21:41:29 --> Model Class Initialized
INFO - 2019-06-29 21:41:29 --> Model Class Initialized
INFO - 2019-06-29 21:41:29 --> Final output sent to browser
DEBUG - 2019-06-29 21:41:29 --> Total execution time: 0.7910
INFO - 2019-06-29 15:41:40 --> Config Class Initialized
INFO - 2019-06-29 15:41:40 --> Hooks Class Initialized
DEBUG - 2019-06-29 15:41:40 --> UTF-8 Support Enabled
INFO - 2019-06-29 15:41:40 --> Utf8 Class Initialized
INFO - 2019-06-29 15:41:40 --> URI Class Initialized
INFO - 2019-06-29 15:41:40 --> Router Class Initialized
INFO - 2019-06-29 15:41:40 --> Output Class Initialized
INFO - 2019-06-29 15:41:40 --> Security Class Initialized
DEBUG - 2019-06-29 15:41:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 15:41:40 --> Input Class Initialized
INFO - 2019-06-29 15:41:40 --> Language Class Initialized
INFO - 2019-06-29 15:41:40 --> Language Class Initialized
INFO - 2019-06-29 15:41:40 --> Config Class Initialized
INFO - 2019-06-29 15:41:40 --> Loader Class Initialized
DEBUG - 2019-06-29 15:41:40 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 15:41:40 --> Helper loaded: url_helper
INFO - 2019-06-29 15:41:40 --> Helper loaded: inflector_helper
INFO - 2019-06-29 15:41:40 --> Helper loaded: string_helper
INFO - 2019-06-29 15:41:40 --> Helper loaded: array_helper
INFO - 2019-06-29 15:41:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 15:41:40 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 15:41:40 --> Database Driver Class Initialized
INFO - 2019-06-29 15:41:40 --> Controller Class Initialized
INFO - 2019-06-29 21:41:40 --> Helper loaded: language_helper
INFO - 2019-06-29 21:41:40 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 21:41:40 --> Model Class Initialized
INFO - 2019-06-29 21:41:40 --> Model Class Initialized
INFO - 2019-06-29 21:41:40 --> Model Class Initialized
INFO - 2019-06-29 21:41:40 --> Model Class Initialized
INFO - 2019-06-29 21:41:40 --> Helper loaded: form_helper
INFO - 2019-06-29 21:41:40 --> Form Validation Class Initialized
DEBUG - 2019-06-29 21:41:40 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-29 21:41:40 --> Model Class Initialized
INFO - 2019-06-29 21:41:40 --> Model Class Initialized
INFO - 2019-06-29 21:41:40 --> Final output sent to browser
DEBUG - 2019-06-29 21:41:40 --> Total execution time: 0.5347
INFO - 2019-06-29 15:44:17 --> Config Class Initialized
INFO - 2019-06-29 15:44:17 --> Hooks Class Initialized
DEBUG - 2019-06-29 15:44:17 --> UTF-8 Support Enabled
INFO - 2019-06-29 15:44:17 --> Utf8 Class Initialized
INFO - 2019-06-29 15:44:17 --> URI Class Initialized
INFO - 2019-06-29 15:44:17 --> Router Class Initialized
INFO - 2019-06-29 15:44:17 --> Output Class Initialized
INFO - 2019-06-29 15:44:17 --> Security Class Initialized
DEBUG - 2019-06-29 15:44:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 15:44:17 --> Input Class Initialized
INFO - 2019-06-29 15:44:17 --> Language Class Initialized
INFO - 2019-06-29 15:44:17 --> Language Class Initialized
INFO - 2019-06-29 15:44:17 --> Config Class Initialized
INFO - 2019-06-29 15:44:17 --> Loader Class Initialized
DEBUG - 2019-06-29 15:44:18 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 15:44:18 --> Helper loaded: url_helper
INFO - 2019-06-29 15:44:18 --> Helper loaded: inflector_helper
INFO - 2019-06-29 15:44:18 --> Helper loaded: string_helper
INFO - 2019-06-29 15:44:18 --> Helper loaded: array_helper
INFO - 2019-06-29 15:44:18 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 15:44:18 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 15:44:18 --> Database Driver Class Initialized
INFO - 2019-06-29 15:44:18 --> Controller Class Initialized
INFO - 2019-06-29 21:44:18 --> Helper loaded: language_helper
INFO - 2019-06-29 21:44:18 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 21:44:18 --> Model Class Initialized
INFO - 2019-06-29 21:44:18 --> Model Class Initialized
INFO - 2019-06-29 21:44:18 --> Model Class Initialized
INFO - 2019-06-29 21:44:18 --> Model Class Initialized
INFO - 2019-06-29 21:44:18 --> Helper loaded: form_helper
INFO - 2019-06-29 21:44:18 --> Form Validation Class Initialized
DEBUG - 2019-06-29 21:44:18 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-29 21:44:18 --> Model Class Initialized
INFO - 2019-06-29 21:44:18 --> Model Class Initialized
INFO - 2019-06-29 21:44:18 --> Final output sent to browser
DEBUG - 2019-06-29 21:44:18 --> Total execution time: 0.5052
INFO - 2019-06-29 15:45:05 --> Config Class Initialized
INFO - 2019-06-29 15:45:05 --> Hooks Class Initialized
DEBUG - 2019-06-29 15:45:05 --> UTF-8 Support Enabled
INFO - 2019-06-29 15:45:05 --> Utf8 Class Initialized
INFO - 2019-06-29 15:45:05 --> URI Class Initialized
INFO - 2019-06-29 15:45:05 --> Router Class Initialized
INFO - 2019-06-29 15:45:05 --> Output Class Initialized
INFO - 2019-06-29 15:45:05 --> Security Class Initialized
DEBUG - 2019-06-29 15:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 15:45:05 --> Input Class Initialized
INFO - 2019-06-29 15:45:05 --> Language Class Initialized
INFO - 2019-06-29 15:45:05 --> Language Class Initialized
INFO - 2019-06-29 15:45:05 --> Config Class Initialized
INFO - 2019-06-29 15:45:05 --> Loader Class Initialized
DEBUG - 2019-06-29 15:45:05 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 15:45:05 --> Helper loaded: url_helper
INFO - 2019-06-29 15:45:05 --> Helper loaded: inflector_helper
INFO - 2019-06-29 15:45:05 --> Helper loaded: string_helper
INFO - 2019-06-29 15:45:05 --> Helper loaded: array_helper
INFO - 2019-06-29 15:45:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 15:45:05 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 15:45:05 --> Database Driver Class Initialized
INFO - 2019-06-29 15:45:05 --> Controller Class Initialized
INFO - 2019-06-29 21:45:05 --> Helper loaded: language_helper
INFO - 2019-06-29 21:45:05 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 21:45:05 --> Model Class Initialized
INFO - 2019-06-29 21:45:05 --> Model Class Initialized
INFO - 2019-06-29 21:45:05 --> Model Class Initialized
INFO - 2019-06-29 21:45:05 --> Model Class Initialized
INFO - 2019-06-29 21:45:05 --> Helper loaded: form_helper
INFO - 2019-06-29 21:45:05 --> Form Validation Class Initialized
DEBUG - 2019-06-29 21:45:06 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-29 21:45:06 --> Model Class Initialized
INFO - 2019-06-29 21:45:06 --> Model Class Initialized
INFO - 2019-06-29 21:45:06 --> Final output sent to browser
DEBUG - 2019-06-29 21:45:06 --> Total execution time: 0.2989
INFO - 2019-06-29 15:45:06 --> Config Class Initialized
INFO - 2019-06-29 15:45:06 --> Hooks Class Initialized
DEBUG - 2019-06-29 15:45:07 --> UTF-8 Support Enabled
INFO - 2019-06-29 15:45:07 --> Utf8 Class Initialized
INFO - 2019-06-29 15:45:07 --> URI Class Initialized
INFO - 2019-06-29 15:45:07 --> Router Class Initialized
INFO - 2019-06-29 15:45:07 --> Output Class Initialized
INFO - 2019-06-29 15:45:07 --> Security Class Initialized
DEBUG - 2019-06-29 15:45:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 15:45:07 --> Input Class Initialized
INFO - 2019-06-29 15:45:07 --> Language Class Initialized
INFO - 2019-06-29 15:45:07 --> Language Class Initialized
INFO - 2019-06-29 15:45:07 --> Config Class Initialized
INFO - 2019-06-29 15:45:07 --> Loader Class Initialized
DEBUG - 2019-06-29 15:45:07 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 15:45:07 --> Helper loaded: url_helper
INFO - 2019-06-29 15:45:07 --> Helper loaded: inflector_helper
INFO - 2019-06-29 15:45:07 --> Helper loaded: string_helper
INFO - 2019-06-29 15:45:07 --> Helper loaded: array_helper
INFO - 2019-06-29 15:45:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 15:45:07 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 15:45:07 --> Database Driver Class Initialized
INFO - 2019-06-29 15:45:07 --> Controller Class Initialized
INFO - 2019-06-29 21:45:07 --> Helper loaded: language_helper
INFO - 2019-06-29 21:45:07 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 21:45:07 --> Model Class Initialized
INFO - 2019-06-29 21:45:07 --> Model Class Initialized
INFO - 2019-06-29 21:45:07 --> Model Class Initialized
INFO - 2019-06-29 21:45:07 --> Model Class Initialized
INFO - 2019-06-29 21:45:07 --> Model Class Initialized
INFO - 2019-06-29 21:45:07 --> Final output sent to browser
DEBUG - 2019-06-29 21:45:07 --> Total execution time: 0.4931
INFO - 2019-06-29 15:48:27 --> Config Class Initialized
INFO - 2019-06-29 15:48:27 --> Hooks Class Initialized
DEBUG - 2019-06-29 15:48:27 --> UTF-8 Support Enabled
INFO - 2019-06-29 15:48:27 --> Utf8 Class Initialized
INFO - 2019-06-29 15:48:27 --> URI Class Initialized
INFO - 2019-06-29 15:48:27 --> Router Class Initialized
INFO - 2019-06-29 15:48:27 --> Output Class Initialized
INFO - 2019-06-29 15:48:27 --> Security Class Initialized
DEBUG - 2019-06-29 15:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 15:48:27 --> Input Class Initialized
INFO - 2019-06-29 15:48:27 --> Language Class Initialized
INFO - 2019-06-29 15:48:27 --> Language Class Initialized
INFO - 2019-06-29 15:48:27 --> Config Class Initialized
INFO - 2019-06-29 15:48:27 --> Loader Class Initialized
DEBUG - 2019-06-29 15:48:27 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 15:48:27 --> Helper loaded: url_helper
INFO - 2019-06-29 15:48:27 --> Helper loaded: inflector_helper
INFO - 2019-06-29 15:48:27 --> Helper loaded: string_helper
INFO - 2019-06-29 15:48:27 --> Helper loaded: array_helper
INFO - 2019-06-29 15:48:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 15:48:27 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 15:48:27 --> Database Driver Class Initialized
INFO - 2019-06-29 15:48:27 --> Controller Class Initialized
INFO - 2019-06-29 21:48:27 --> Helper loaded: language_helper
INFO - 2019-06-29 21:48:27 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 21:48:27 --> Model Class Initialized
INFO - 2019-06-29 21:48:27 --> Model Class Initialized
INFO - 2019-06-29 21:48:27 --> Model Class Initialized
INFO - 2019-06-29 21:48:27 --> Model Class Initialized
INFO - 2019-06-29 21:48:27 --> Helper loaded: form_helper
INFO - 2019-06-29 21:48:27 --> Form Validation Class Initialized
DEBUG - 2019-06-29 21:48:27 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-29 21:48:27 --> Model Class Initialized
INFO - 2019-06-29 21:48:27 --> Model Class Initialized
INFO - 2019-06-29 21:48:27 --> Final output sent to browser
DEBUG - 2019-06-29 21:48:27 --> Total execution time: 0.7603
INFO - 2019-06-29 15:48:45 --> Config Class Initialized
INFO - 2019-06-29 15:48:45 --> Hooks Class Initialized
DEBUG - 2019-06-29 15:48:46 --> UTF-8 Support Enabled
INFO - 2019-06-29 15:48:46 --> Utf8 Class Initialized
INFO - 2019-06-29 15:48:46 --> URI Class Initialized
INFO - 2019-06-29 15:48:46 --> Router Class Initialized
INFO - 2019-06-29 15:48:46 --> Output Class Initialized
INFO - 2019-06-29 15:48:46 --> Security Class Initialized
DEBUG - 2019-06-29 15:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 15:48:46 --> Input Class Initialized
INFO - 2019-06-29 15:48:46 --> Language Class Initialized
INFO - 2019-06-29 15:48:46 --> Language Class Initialized
INFO - 2019-06-29 15:48:46 --> Config Class Initialized
INFO - 2019-06-29 15:48:46 --> Loader Class Initialized
DEBUG - 2019-06-29 15:48:46 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 15:48:46 --> Helper loaded: url_helper
INFO - 2019-06-29 15:48:46 --> Helper loaded: inflector_helper
INFO - 2019-06-29 15:48:46 --> Helper loaded: string_helper
INFO - 2019-06-29 15:48:46 --> Helper loaded: array_helper
INFO - 2019-06-29 15:48:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 15:48:46 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 15:48:46 --> Database Driver Class Initialized
INFO - 2019-06-29 15:48:46 --> Controller Class Initialized
INFO - 2019-06-29 21:48:46 --> Helper loaded: language_helper
INFO - 2019-06-29 21:48:46 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 21:48:46 --> Model Class Initialized
INFO - 2019-06-29 21:48:46 --> Model Class Initialized
INFO - 2019-06-29 21:48:46 --> Model Class Initialized
INFO - 2019-06-29 21:48:46 --> Model Class Initialized
INFO - 2019-06-29 21:48:46 --> Model Class Initialized
INFO - 2019-06-29 21:48:46 --> Final output sent to browser
DEBUG - 2019-06-29 21:48:46 --> Total execution time: 0.2300
INFO - 2019-06-29 15:49:24 --> Config Class Initialized
INFO - 2019-06-29 15:49:24 --> Hooks Class Initialized
DEBUG - 2019-06-29 15:49:24 --> UTF-8 Support Enabled
INFO - 2019-06-29 15:49:24 --> Utf8 Class Initialized
INFO - 2019-06-29 15:49:24 --> URI Class Initialized
INFO - 2019-06-29 15:49:24 --> Router Class Initialized
INFO - 2019-06-29 15:49:24 --> Output Class Initialized
INFO - 2019-06-29 15:49:24 --> Security Class Initialized
DEBUG - 2019-06-29 15:49:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 15:49:24 --> Input Class Initialized
INFO - 2019-06-29 15:49:24 --> Language Class Initialized
INFO - 2019-06-29 15:49:24 --> Language Class Initialized
INFO - 2019-06-29 15:49:24 --> Config Class Initialized
INFO - 2019-06-29 15:49:24 --> Loader Class Initialized
DEBUG - 2019-06-29 15:49:24 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 15:49:24 --> Helper loaded: url_helper
INFO - 2019-06-29 15:49:24 --> Helper loaded: inflector_helper
INFO - 2019-06-29 15:49:24 --> Helper loaded: string_helper
INFO - 2019-06-29 15:49:25 --> Helper loaded: array_helper
INFO - 2019-06-29 15:49:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 15:49:25 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 15:49:25 --> Database Driver Class Initialized
INFO - 2019-06-29 15:49:25 --> Controller Class Initialized
INFO - 2019-06-29 21:49:25 --> Helper loaded: language_helper
INFO - 2019-06-29 21:49:25 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 21:49:25 --> Model Class Initialized
INFO - 2019-06-29 21:49:25 --> Model Class Initialized
INFO - 2019-06-29 21:49:25 --> Model Class Initialized
INFO - 2019-06-29 21:49:25 --> Model Class Initialized
INFO - 2019-06-29 21:49:25 --> Helper loaded: form_helper
INFO - 2019-06-29 21:49:25 --> Form Validation Class Initialized
DEBUG - 2019-06-29 21:49:25 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-29 21:49:25 --> Model Class Initialized
INFO - 2019-06-29 21:49:25 --> Model Class Initialized
INFO - 2019-06-29 21:49:25 --> Final output sent to browser
DEBUG - 2019-06-29 21:49:25 --> Total execution time: 1.0080
INFO - 2019-06-29 15:49:25 --> Config Class Initialized
INFO - 2019-06-29 15:49:25 --> Hooks Class Initialized
DEBUG - 2019-06-29 15:49:25 --> UTF-8 Support Enabled
INFO - 2019-06-29 15:49:25 --> Utf8 Class Initialized
INFO - 2019-06-29 15:49:25 --> URI Class Initialized
INFO - 2019-06-29 15:49:25 --> Router Class Initialized
INFO - 2019-06-29 15:49:25 --> Output Class Initialized
INFO - 2019-06-29 15:49:25 --> Security Class Initialized
DEBUG - 2019-06-29 15:49:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 15:49:25 --> Input Class Initialized
INFO - 2019-06-29 15:49:25 --> Language Class Initialized
INFO - 2019-06-29 15:49:25 --> Language Class Initialized
INFO - 2019-06-29 15:49:25 --> Config Class Initialized
INFO - 2019-06-29 15:49:25 --> Loader Class Initialized
DEBUG - 2019-06-29 15:49:25 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 15:49:25 --> Helper loaded: url_helper
INFO - 2019-06-29 15:49:25 --> Helper loaded: inflector_helper
INFO - 2019-06-29 15:49:25 --> Helper loaded: string_helper
INFO - 2019-06-29 15:49:25 --> Helper loaded: array_helper
INFO - 2019-06-29 15:49:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 15:49:26 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 15:49:26 --> Database Driver Class Initialized
INFO - 2019-06-29 15:49:26 --> Controller Class Initialized
INFO - 2019-06-29 21:49:26 --> Helper loaded: language_helper
INFO - 2019-06-29 21:49:26 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 21:49:26 --> Model Class Initialized
INFO - 2019-06-29 21:49:26 --> Model Class Initialized
INFO - 2019-06-29 21:49:26 --> Model Class Initialized
INFO - 2019-06-29 21:49:26 --> Model Class Initialized
INFO - 2019-06-29 21:49:26 --> Helper loaded: form_helper
INFO - 2019-06-29 21:49:26 --> Form Validation Class Initialized
DEBUG - 2019-06-29 21:49:26 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-29 21:49:26 --> Model Class Initialized
INFO - 2019-06-29 21:49:26 --> Model Class Initialized
INFO - 2019-06-29 21:49:26 --> Final output sent to browser
DEBUG - 2019-06-29 21:49:26 --> Total execution time: 0.7268
INFO - 2019-06-29 15:49:27 --> Config Class Initialized
INFO - 2019-06-29 15:49:27 --> Hooks Class Initialized
DEBUG - 2019-06-29 15:49:27 --> UTF-8 Support Enabled
INFO - 2019-06-29 15:49:27 --> Utf8 Class Initialized
INFO - 2019-06-29 15:49:27 --> URI Class Initialized
INFO - 2019-06-29 15:49:27 --> Router Class Initialized
INFO - 2019-06-29 15:49:27 --> Output Class Initialized
INFO - 2019-06-29 15:49:27 --> Security Class Initialized
DEBUG - 2019-06-29 15:49:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 15:49:27 --> Input Class Initialized
INFO - 2019-06-29 15:49:27 --> Language Class Initialized
INFO - 2019-06-29 15:49:27 --> Language Class Initialized
INFO - 2019-06-29 15:49:27 --> Config Class Initialized
INFO - 2019-06-29 15:49:27 --> Loader Class Initialized
DEBUG - 2019-06-29 15:49:27 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 15:49:27 --> Helper loaded: url_helper
INFO - 2019-06-29 15:49:27 --> Helper loaded: inflector_helper
INFO - 2019-06-29 15:49:27 --> Helper loaded: string_helper
INFO - 2019-06-29 15:49:27 --> Helper loaded: array_helper
INFO - 2019-06-29 15:49:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 15:49:28 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 15:49:28 --> Database Driver Class Initialized
INFO - 2019-06-29 15:49:28 --> Controller Class Initialized
INFO - 2019-06-29 21:49:28 --> Helper loaded: language_helper
INFO - 2019-06-29 21:49:28 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 21:49:28 --> Model Class Initialized
INFO - 2019-06-29 21:49:28 --> Model Class Initialized
INFO - 2019-06-29 21:49:28 --> Model Class Initialized
INFO - 2019-06-29 21:49:28 --> Model Class Initialized
INFO - 2019-06-29 21:49:28 --> Model Class Initialized
INFO - 2019-06-29 21:49:28 --> Final output sent to browser
DEBUG - 2019-06-29 21:49:28 --> Total execution time: 0.6111
INFO - 2019-06-29 15:49:48 --> Config Class Initialized
INFO - 2019-06-29 15:49:48 --> Hooks Class Initialized
DEBUG - 2019-06-29 15:49:48 --> UTF-8 Support Enabled
INFO - 2019-06-29 15:49:48 --> Utf8 Class Initialized
INFO - 2019-06-29 15:49:48 --> URI Class Initialized
INFO - 2019-06-29 15:49:48 --> Router Class Initialized
INFO - 2019-06-29 15:49:48 --> Output Class Initialized
INFO - 2019-06-29 15:49:48 --> Security Class Initialized
DEBUG - 2019-06-29 15:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 15:49:48 --> Input Class Initialized
INFO - 2019-06-29 15:49:48 --> Language Class Initialized
INFO - 2019-06-29 15:49:48 --> Language Class Initialized
INFO - 2019-06-29 15:49:48 --> Config Class Initialized
INFO - 2019-06-29 15:49:48 --> Loader Class Initialized
DEBUG - 2019-06-29 15:49:48 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 15:49:48 --> Helper loaded: url_helper
INFO - 2019-06-29 15:49:48 --> Helper loaded: inflector_helper
INFO - 2019-06-29 15:49:48 --> Helper loaded: string_helper
INFO - 2019-06-29 15:49:48 --> Helper loaded: array_helper
INFO - 2019-06-29 15:49:48 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 15:49:48 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 15:49:48 --> Database Driver Class Initialized
INFO - 2019-06-29 15:49:48 --> Controller Class Initialized
INFO - 2019-06-29 21:49:48 --> Helper loaded: language_helper
INFO - 2019-06-29 21:49:48 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 21:49:48 --> Model Class Initialized
INFO - 2019-06-29 21:49:48 --> Model Class Initialized
INFO - 2019-06-29 21:49:48 --> Model Class Initialized
INFO - 2019-06-29 21:49:48 --> Model Class Initialized
INFO - 2019-06-29 21:49:48 --> Helper loaded: form_helper
INFO - 2019-06-29 21:49:48 --> Form Validation Class Initialized
DEBUG - 2019-06-29 21:49:48 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-29 21:49:48 --> Model Class Initialized
INFO - 2019-06-29 21:49:48 --> Model Class Initialized
INFO - 2019-06-29 21:49:48 --> Final output sent to browser
DEBUG - 2019-06-29 21:49:49 --> Total execution time: 0.4211
INFO - 2019-06-29 15:49:58 --> Config Class Initialized
INFO - 2019-06-29 15:49:58 --> Hooks Class Initialized
DEBUG - 2019-06-29 15:49:58 --> UTF-8 Support Enabled
INFO - 2019-06-29 15:49:58 --> Utf8 Class Initialized
INFO - 2019-06-29 15:49:58 --> URI Class Initialized
INFO - 2019-06-29 15:49:58 --> Router Class Initialized
INFO - 2019-06-29 15:49:58 --> Output Class Initialized
INFO - 2019-06-29 15:49:58 --> Security Class Initialized
DEBUG - 2019-06-29 15:49:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 15:49:58 --> Input Class Initialized
INFO - 2019-06-29 15:49:58 --> Language Class Initialized
INFO - 2019-06-29 15:49:58 --> Language Class Initialized
INFO - 2019-06-29 15:49:58 --> Config Class Initialized
INFO - 2019-06-29 15:49:58 --> Loader Class Initialized
DEBUG - 2019-06-29 15:49:58 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 15:49:58 --> Helper loaded: url_helper
INFO - 2019-06-29 15:49:58 --> Helper loaded: inflector_helper
INFO - 2019-06-29 15:49:58 --> Helper loaded: string_helper
INFO - 2019-06-29 15:49:58 --> Helper loaded: array_helper
INFO - 2019-06-29 15:49:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 15:49:58 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 15:49:58 --> Database Driver Class Initialized
INFO - 2019-06-29 15:49:58 --> Controller Class Initialized
INFO - 2019-06-29 21:49:58 --> Helper loaded: language_helper
INFO - 2019-06-29 21:49:58 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 21:49:58 --> Model Class Initialized
INFO - 2019-06-29 21:49:58 --> Model Class Initialized
INFO - 2019-06-29 21:49:58 --> Model Class Initialized
INFO - 2019-06-29 21:49:58 --> Model Class Initialized
INFO - 2019-06-29 21:49:58 --> Helper loaded: form_helper
INFO - 2019-06-29 21:49:58 --> Form Validation Class Initialized
DEBUG - 2019-06-29 21:49:58 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-29 21:49:58 --> Model Class Initialized
INFO - 2019-06-29 21:49:58 --> Model Class Initialized
INFO - 2019-06-29 21:49:58 --> Final output sent to browser
DEBUG - 2019-06-29 21:49:58 --> Total execution time: 0.7243
INFO - 2019-06-29 15:54:28 --> Config Class Initialized
INFO - 2019-06-29 15:54:28 --> Hooks Class Initialized
DEBUG - 2019-06-29 15:54:28 --> UTF-8 Support Enabled
INFO - 2019-06-29 15:54:28 --> Utf8 Class Initialized
INFO - 2019-06-29 15:54:28 --> URI Class Initialized
INFO - 2019-06-29 15:54:28 --> Router Class Initialized
INFO - 2019-06-29 15:54:28 --> Output Class Initialized
INFO - 2019-06-29 15:54:28 --> Security Class Initialized
DEBUG - 2019-06-29 15:54:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 15:54:28 --> Input Class Initialized
INFO - 2019-06-29 15:54:28 --> Language Class Initialized
INFO - 2019-06-29 15:54:28 --> Language Class Initialized
INFO - 2019-06-29 15:54:28 --> Config Class Initialized
INFO - 2019-06-29 15:54:28 --> Loader Class Initialized
DEBUG - 2019-06-29 15:54:28 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 15:54:28 --> Helper loaded: url_helper
INFO - 2019-06-29 15:54:28 --> Helper loaded: inflector_helper
INFO - 2019-06-29 15:54:28 --> Helper loaded: string_helper
INFO - 2019-06-29 15:54:28 --> Helper loaded: array_helper
INFO - 2019-06-29 15:54:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 15:54:28 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 15:54:28 --> Database Driver Class Initialized
INFO - 2019-06-29 15:54:28 --> Controller Class Initialized
INFO - 2019-06-29 21:54:28 --> Helper loaded: language_helper
INFO - 2019-06-29 21:54:28 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 21:54:28 --> Model Class Initialized
INFO - 2019-06-29 21:54:28 --> Model Class Initialized
INFO - 2019-06-29 21:54:28 --> Model Class Initialized
INFO - 2019-06-29 21:54:28 --> Model Class Initialized
INFO - 2019-06-29 21:54:28 --> Final output sent to browser
DEBUG - 2019-06-29 21:54:28 --> Total execution time: 0.4246
INFO - 2019-06-29 15:54:34 --> Config Class Initialized
INFO - 2019-06-29 15:54:34 --> Hooks Class Initialized
DEBUG - 2019-06-29 15:54:34 --> UTF-8 Support Enabled
INFO - 2019-06-29 15:54:34 --> Utf8 Class Initialized
INFO - 2019-06-29 15:54:34 --> URI Class Initialized
INFO - 2019-06-29 15:54:34 --> Router Class Initialized
INFO - 2019-06-29 15:54:34 --> Output Class Initialized
INFO - 2019-06-29 15:54:34 --> Security Class Initialized
DEBUG - 2019-06-29 15:54:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 15:54:34 --> Input Class Initialized
INFO - 2019-06-29 15:54:34 --> Language Class Initialized
INFO - 2019-06-29 15:54:34 --> Language Class Initialized
INFO - 2019-06-29 15:54:34 --> Config Class Initialized
INFO - 2019-06-29 15:54:34 --> Loader Class Initialized
DEBUG - 2019-06-29 15:54:34 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 15:54:34 --> Helper loaded: url_helper
INFO - 2019-06-29 15:54:34 --> Helper loaded: inflector_helper
INFO - 2019-06-29 15:54:34 --> Helper loaded: string_helper
INFO - 2019-06-29 15:54:34 --> Helper loaded: array_helper
INFO - 2019-06-29 15:54:35 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 15:54:35 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 15:54:35 --> Database Driver Class Initialized
INFO - 2019-06-29 15:54:35 --> Controller Class Initialized
INFO - 2019-06-29 21:54:35 --> Helper loaded: language_helper
INFO - 2019-06-29 21:54:35 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 21:54:35 --> Model Class Initialized
INFO - 2019-06-29 21:54:35 --> Model Class Initialized
INFO - 2019-06-29 21:54:35 --> Model Class Initialized
INFO - 2019-06-29 21:54:35 --> Model Class Initialized
INFO - 2019-06-29 21:54:35 --> Final output sent to browser
DEBUG - 2019-06-29 21:54:35 --> Total execution time: 0.3442
INFO - 2019-06-29 15:54:48 --> Config Class Initialized
INFO - 2019-06-29 15:54:48 --> Hooks Class Initialized
DEBUG - 2019-06-29 15:54:48 --> UTF-8 Support Enabled
INFO - 2019-06-29 15:54:48 --> Utf8 Class Initialized
INFO - 2019-06-29 15:54:48 --> URI Class Initialized
DEBUG - 2019-06-29 15:54:48 --> No URI present. Default controller set.
INFO - 2019-06-29 15:54:48 --> Router Class Initialized
INFO - 2019-06-29 15:54:48 --> Output Class Initialized
INFO - 2019-06-29 15:54:48 --> Security Class Initialized
DEBUG - 2019-06-29 15:54:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 15:54:48 --> Input Class Initialized
INFO - 2019-06-29 15:54:48 --> Language Class Initialized
INFO - 2019-06-29 15:54:49 --> Final output sent to browser
DEBUG - 2019-06-29 15:54:49 --> Total execution time: 1.6249
INFO - 2019-06-29 15:54:55 --> Config Class Initialized
INFO - 2019-06-29 15:54:55 --> Hooks Class Initialized
DEBUG - 2019-06-29 15:54:55 --> UTF-8 Support Enabled
INFO - 2019-06-29 15:54:55 --> Utf8 Class Initialized
INFO - 2019-06-29 15:54:55 --> URI Class Initialized
DEBUG - 2019-06-29 15:54:55 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/routes.php
INFO - 2019-06-29 15:54:55 --> Router Class Initialized
INFO - 2019-06-29 15:54:55 --> Output Class Initialized
INFO - 2019-06-29 15:54:55 --> Security Class Initialized
DEBUG - 2019-06-29 15:54:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 15:54:55 --> Input Class Initialized
INFO - 2019-06-29 15:54:55 --> Language Class Initialized
INFO - 2019-06-29 15:54:55 --> Language Class Initialized
INFO - 2019-06-29 15:54:55 --> Config Class Initialized
INFO - 2019-06-29 15:54:55 --> Loader Class Initialized
DEBUG - 2019-06-29 15:54:55 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/site.php
INFO - 2019-06-29 15:54:55 --> Helper loaded: url_helper
INFO - 2019-06-29 15:54:55 --> Helper loaded: inflector_helper
INFO - 2019-06-29 15:54:55 --> Helper loaded: string_helper
INFO - 2019-06-29 15:54:55 --> Helper loaded: array_helper
INFO - 2019-06-29 15:54:56 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 15:54:56 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/autoload.php
DEBUG - 2019-06-29 15:54:56 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/helpers/adminlte_helper.php
INFO - 2019-06-29 15:54:56 --> Database Driver Class Initialized
DEBUG - 2019-06-29 15:54:56 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/libraries/Crud.php
INFO - 2019-06-29 15:54:56 --> Helper loaded: form_helper
DEBUG - 2019-06-29 15:54:56 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-06-29 15:54:56 --> Form Validation Class Initialized
DEBUG - 2019-06-29 15:54:56 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-06-29 15:54:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-06-29 15:54:56 --> Pagination Class Initialized
INFO - 2019-06-29 15:54:56 --> Controller Class Initialized
INFO - 2019-06-29 21:54:56 --> Final output sent to browser
DEBUG - 2019-06-29 21:54:56 --> Total execution time: 0.6245
INFO - 2019-06-29 15:54:57 --> Config Class Initialized
INFO - 2019-06-29 15:54:57 --> Hooks Class Initialized
DEBUG - 2019-06-29 15:54:57 --> UTF-8 Support Enabled
INFO - 2019-06-29 15:54:57 --> Utf8 Class Initialized
INFO - 2019-06-29 15:54:57 --> URI Class Initialized
DEBUG - 2019-06-29 15:54:57 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/routes.php
INFO - 2019-06-29 15:54:57 --> Router Class Initialized
INFO - 2019-06-29 15:54:57 --> Output Class Initialized
INFO - 2019-06-29 15:54:57 --> Security Class Initialized
DEBUG - 2019-06-29 15:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 15:54:57 --> Input Class Initialized
INFO - 2019-06-29 15:54:57 --> Language Class Initialized
INFO - 2019-06-29 15:54:57 --> Language Class Initialized
INFO - 2019-06-29 15:54:57 --> Config Class Initialized
INFO - 2019-06-29 15:54:57 --> Loader Class Initialized
DEBUG - 2019-06-29 15:54:57 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/site.php
INFO - 2019-06-29 15:54:57 --> Helper loaded: url_helper
INFO - 2019-06-29 15:54:58 --> Helper loaded: inflector_helper
INFO - 2019-06-29 15:54:58 --> Helper loaded: string_helper
INFO - 2019-06-29 15:54:58 --> Helper loaded: array_helper
INFO - 2019-06-29 15:54:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 15:54:58 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/autoload.php
DEBUG - 2019-06-29 15:54:58 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/helpers/adminlte_helper.php
INFO - 2019-06-29 15:54:58 --> Database Driver Class Initialized
DEBUG - 2019-06-29 15:54:58 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/libraries/Crud.php
INFO - 2019-06-29 15:54:58 --> Helper loaded: form_helper
DEBUG - 2019-06-29 15:54:58 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-06-29 15:54:58 --> Form Validation Class Initialized
DEBUG - 2019-06-29 15:54:58 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-06-29 15:54:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-06-29 15:54:58 --> Pagination Class Initialized
INFO - 2019-06-29 15:54:58 --> Controller Class Initialized
INFO - 2019-06-29 21:54:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-06-29 21:54:58 --> Model Class Initialized
INFO - 2019-06-29 21:54:58 --> Model Class Initialized
INFO - 2019-06-29 15:54:58 --> Config Class Initialized
INFO - 2019-06-29 15:54:58 --> Hooks Class Initialized
DEBUG - 2019-06-29 15:54:58 --> UTF-8 Support Enabled
INFO - 2019-06-29 15:54:58 --> Utf8 Class Initialized
INFO - 2019-06-29 15:54:58 --> URI Class Initialized
DEBUG - 2019-06-29 15:54:58 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/routes.php
INFO - 2019-06-29 15:54:58 --> Router Class Initialized
INFO - 2019-06-29 15:54:58 --> Output Class Initialized
INFO - 2019-06-29 15:54:58 --> Security Class Initialized
DEBUG - 2019-06-29 15:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 15:54:58 --> Input Class Initialized
INFO - 2019-06-29 15:54:58 --> Language Class Initialized
INFO - 2019-06-29 15:54:58 --> Language Class Initialized
INFO - 2019-06-29 15:54:58 --> Config Class Initialized
INFO - 2019-06-29 15:54:58 --> Loader Class Initialized
DEBUG - 2019-06-29 15:54:58 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/site.php
INFO - 2019-06-29 15:54:58 --> Helper loaded: url_helper
INFO - 2019-06-29 15:54:58 --> Helper loaded: inflector_helper
INFO - 2019-06-29 15:54:58 --> Helper loaded: string_helper
INFO - 2019-06-29 15:54:58 --> Helper loaded: array_helper
INFO - 2019-06-29 15:54:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 15:54:58 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/autoload.php
DEBUG - 2019-06-29 15:54:58 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/helpers/adminlte_helper.php
INFO - 2019-06-29 15:54:58 --> Database Driver Class Initialized
DEBUG - 2019-06-29 15:54:58 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/libraries/Crud.php
INFO - 2019-06-29 15:54:58 --> Helper loaded: form_helper
DEBUG - 2019-06-29 15:54:58 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-06-29 15:54:58 --> Form Validation Class Initialized
DEBUG - 2019-06-29 15:54:58 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-06-29 15:54:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-06-29 15:54:58 --> Pagination Class Initialized
INFO - 2019-06-29 15:54:58 --> Controller Class Initialized
INFO - 2019-06-29 21:54:58 --> Final output sent to browser
DEBUG - 2019-06-29 21:54:58 --> Total execution time: 0.4867
INFO - 2019-06-29 15:55:00 --> Config Class Initialized
INFO - 2019-06-29 15:55:00 --> Hooks Class Initialized
DEBUG - 2019-06-29 15:55:00 --> UTF-8 Support Enabled
INFO - 2019-06-29 15:55:00 --> Utf8 Class Initialized
INFO - 2019-06-29 15:55:00 --> URI Class Initialized
DEBUG - 2019-06-29 15:55:00 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/routes.php
INFO - 2019-06-29 15:55:00 --> Router Class Initialized
INFO - 2019-06-29 15:55:00 --> Output Class Initialized
INFO - 2019-06-29 15:55:00 --> Security Class Initialized
DEBUG - 2019-06-29 15:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 15:55:00 --> Input Class Initialized
INFO - 2019-06-29 15:55:00 --> Language Class Initialized
INFO - 2019-06-29 15:55:00 --> Language Class Initialized
INFO - 2019-06-29 15:55:00 --> Config Class Initialized
INFO - 2019-06-29 15:55:00 --> Loader Class Initialized
DEBUG - 2019-06-29 15:55:00 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/site.php
INFO - 2019-06-29 15:55:00 --> Helper loaded: url_helper
INFO - 2019-06-29 15:55:00 --> Helper loaded: inflector_helper
INFO - 2019-06-29 15:55:00 --> Helper loaded: string_helper
INFO - 2019-06-29 15:55:00 --> Helper loaded: array_helper
INFO - 2019-06-29 15:55:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 15:55:01 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/autoload.php
DEBUG - 2019-06-29 15:55:01 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/helpers/adminlte_helper.php
INFO - 2019-06-29 15:55:01 --> Database Driver Class Initialized
DEBUG - 2019-06-29 15:55:01 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/libraries/Crud.php
INFO - 2019-06-29 15:55:01 --> Helper loaded: form_helper
DEBUG - 2019-06-29 15:55:01 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-06-29 15:55:01 --> Form Validation Class Initialized
DEBUG - 2019-06-29 15:55:01 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-06-29 15:55:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-06-29 15:55:01 --> Pagination Class Initialized
INFO - 2019-06-29 15:55:01 --> Controller Class Initialized
INFO - 2019-06-29 21:55:01 --> Model Class Initialized
INFO - 2019-06-29 21:55:01 --> Model Class Initialized
INFO - 2019-06-29 21:55:01 --> Model Class Initialized
INFO - 2019-06-29 21:55:01 --> Final output sent to browser
DEBUG - 2019-06-29 21:55:01 --> Total execution time: 0.5769
INFO - 2019-06-29 15:55:01 --> Config Class Initialized
INFO - 2019-06-29 15:55:01 --> Hooks Class Initialized
DEBUG - 2019-06-29 15:55:01 --> UTF-8 Support Enabled
INFO - 2019-06-29 15:55:01 --> Utf8 Class Initialized
INFO - 2019-06-29 15:55:02 --> URI Class Initialized
DEBUG - 2019-06-29 15:55:02 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/routes.php
INFO - 2019-06-29 15:55:02 --> Router Class Initialized
INFO - 2019-06-29 15:55:02 --> Output Class Initialized
INFO - 2019-06-29 15:55:02 --> Security Class Initialized
DEBUG - 2019-06-29 15:55:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 15:55:02 --> Input Class Initialized
INFO - 2019-06-29 15:55:02 --> Language Class Initialized
INFO - 2019-06-29 15:55:02 --> Language Class Initialized
INFO - 2019-06-29 15:55:02 --> Config Class Initialized
INFO - 2019-06-29 15:55:02 --> Loader Class Initialized
DEBUG - 2019-06-29 15:55:02 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/site.php
INFO - 2019-06-29 15:55:02 --> Helper loaded: url_helper
INFO - 2019-06-29 15:55:02 --> Helper loaded: inflector_helper
INFO - 2019-06-29 15:55:02 --> Helper loaded: string_helper
INFO - 2019-06-29 15:55:02 --> Helper loaded: array_helper
INFO - 2019-06-29 15:55:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 15:55:02 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/autoload.php
DEBUG - 2019-06-29 15:55:02 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/helpers/adminlte_helper.php
INFO - 2019-06-29 15:55:02 --> Database Driver Class Initialized
DEBUG - 2019-06-29 15:55:02 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/libraries/Crud.php
INFO - 2019-06-29 15:55:02 --> Helper loaded: form_helper
DEBUG - 2019-06-29 15:55:02 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-06-29 15:55:02 --> Form Validation Class Initialized
DEBUG - 2019-06-29 15:55:02 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-06-29 15:55:02 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-06-29 15:55:02 --> Pagination Class Initialized
INFO - 2019-06-29 15:55:02 --> Controller Class Initialized
INFO - 2019-06-29 21:55:02 --> Model Class Initialized
INFO - 2019-06-29 21:55:02 --> Model Class Initialized
INFO - 2019-06-29 21:55:02 --> Final output sent to browser
DEBUG - 2019-06-29 21:55:02 --> Total execution time: 0.6330
INFO - 2019-06-29 15:55:04 --> Config Class Initialized
INFO - 2019-06-29 15:55:04 --> Hooks Class Initialized
DEBUG - 2019-06-29 15:55:04 --> UTF-8 Support Enabled
INFO - 2019-06-29 15:55:04 --> Utf8 Class Initialized
INFO - 2019-06-29 15:55:04 --> URI Class Initialized
DEBUG - 2019-06-29 15:55:04 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/routes.php
INFO - 2019-06-29 15:55:04 --> Router Class Initialized
INFO - 2019-06-29 15:55:04 --> Output Class Initialized
INFO - 2019-06-29 15:55:04 --> Security Class Initialized
DEBUG - 2019-06-29 15:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 15:55:05 --> Input Class Initialized
INFO - 2019-06-29 15:55:05 --> Language Class Initialized
INFO - 2019-06-29 15:55:05 --> Language Class Initialized
INFO - 2019-06-29 15:55:05 --> Config Class Initialized
INFO - 2019-06-29 15:55:05 --> Loader Class Initialized
DEBUG - 2019-06-29 15:55:05 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/site.php
INFO - 2019-06-29 15:55:05 --> Helper loaded: url_helper
INFO - 2019-06-29 15:55:05 --> Helper loaded: inflector_helper
INFO - 2019-06-29 15:55:05 --> Helper loaded: string_helper
INFO - 2019-06-29 15:55:05 --> Helper loaded: array_helper
INFO - 2019-06-29 15:55:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 15:55:05 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/autoload.php
DEBUG - 2019-06-29 15:55:05 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/helpers/adminlte_helper.php
INFO - 2019-06-29 15:55:05 --> Database Driver Class Initialized
DEBUG - 2019-06-29 15:55:05 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/libraries/Crud.php
INFO - 2019-06-29 15:55:05 --> Helper loaded: form_helper
DEBUG - 2019-06-29 15:55:05 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-06-29 15:55:05 --> Form Validation Class Initialized
DEBUG - 2019-06-29 15:55:05 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-06-29 15:55:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-06-29 15:55:05 --> Pagination Class Initialized
INFO - 2019-06-29 15:55:05 --> Controller Class Initialized
INFO - 2019-06-29 21:55:05 --> Model Class Initialized
INFO - 2019-06-29 21:55:05 --> Model Class Initialized
INFO - 2019-06-29 21:55:05 --> Model Class Initialized
INFO - 2019-06-29 21:55:05 --> Final output sent to browser
DEBUG - 2019-06-29 21:55:05 --> Total execution time: 0.4575
INFO - 2019-06-29 15:55:06 --> Config Class Initialized
INFO - 2019-06-29 15:55:06 --> Hooks Class Initialized
DEBUG - 2019-06-29 15:55:06 --> UTF-8 Support Enabled
INFO - 2019-06-29 15:55:06 --> Utf8 Class Initialized
INFO - 2019-06-29 15:55:06 --> URI Class Initialized
DEBUG - 2019-06-29 15:55:06 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/routes.php
INFO - 2019-06-29 15:55:06 --> Router Class Initialized
INFO - 2019-06-29 15:55:06 --> Output Class Initialized
INFO - 2019-06-29 15:55:06 --> Security Class Initialized
DEBUG - 2019-06-29 15:55:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 15:55:06 --> Input Class Initialized
INFO - 2019-06-29 15:55:06 --> Language Class Initialized
INFO - 2019-06-29 15:55:06 --> Language Class Initialized
INFO - 2019-06-29 15:55:06 --> Config Class Initialized
INFO - 2019-06-29 15:55:06 --> Loader Class Initialized
DEBUG - 2019-06-29 15:55:06 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/site.php
INFO - 2019-06-29 15:55:06 --> Helper loaded: url_helper
INFO - 2019-06-29 15:55:06 --> Helper loaded: inflector_helper
INFO - 2019-06-29 15:55:06 --> Helper loaded: string_helper
INFO - 2019-06-29 15:55:06 --> Helper loaded: array_helper
INFO - 2019-06-29 15:55:06 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 15:55:06 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/autoload.php
DEBUG - 2019-06-29 15:55:06 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/helpers/adminlte_helper.php
INFO - 2019-06-29 15:55:06 --> Database Driver Class Initialized
DEBUG - 2019-06-29 15:55:06 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/libraries/Crud.php
INFO - 2019-06-29 15:55:06 --> Helper loaded: form_helper
DEBUG - 2019-06-29 15:55:06 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-06-29 15:55:06 --> Form Validation Class Initialized
DEBUG - 2019-06-29 15:55:06 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-06-29 15:55:06 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-06-29 15:55:06 --> Pagination Class Initialized
INFO - 2019-06-29 15:55:06 --> Controller Class Initialized
INFO - 2019-06-29 21:55:07 --> Model Class Initialized
INFO - 2019-06-29 21:55:07 --> Model Class Initialized
INFO - 2019-06-29 21:55:07 --> Model Class Initialized
INFO - 2019-06-29 21:55:07 --> Final output sent to browser
DEBUG - 2019-06-29 21:55:07 --> Total execution time: 0.4976
INFO - 2019-06-29 15:55:07 --> Config Class Initialized
INFO - 2019-06-29 15:55:07 --> Hooks Class Initialized
DEBUG - 2019-06-29 15:55:07 --> UTF-8 Support Enabled
INFO - 2019-06-29 15:55:07 --> Utf8 Class Initialized
INFO - 2019-06-29 15:55:07 --> URI Class Initialized
DEBUG - 2019-06-29 15:55:07 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/routes.php
INFO - 2019-06-29 15:55:07 --> Router Class Initialized
INFO - 2019-06-29 15:55:07 --> Output Class Initialized
INFO - 2019-06-29 15:55:07 --> Security Class Initialized
DEBUG - 2019-06-29 15:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 15:55:07 --> Input Class Initialized
INFO - 2019-06-29 15:55:07 --> Language Class Initialized
INFO - 2019-06-29 15:55:07 --> Language Class Initialized
INFO - 2019-06-29 15:55:07 --> Config Class Initialized
INFO - 2019-06-29 15:55:07 --> Loader Class Initialized
DEBUG - 2019-06-29 15:55:07 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/site.php
INFO - 2019-06-29 15:55:07 --> Helper loaded: url_helper
INFO - 2019-06-29 15:55:07 --> Helper loaded: inflector_helper
INFO - 2019-06-29 15:55:07 --> Helper loaded: string_helper
INFO - 2019-06-29 15:55:07 --> Helper loaded: array_helper
INFO - 2019-06-29 15:55:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 15:55:07 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/autoload.php
DEBUG - 2019-06-29 15:55:07 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/helpers/adminlte_helper.php
INFO - 2019-06-29 15:55:07 --> Database Driver Class Initialized
DEBUG - 2019-06-29 15:55:07 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/libraries/Crud.php
INFO - 2019-06-29 15:55:07 --> Helper loaded: form_helper
DEBUG - 2019-06-29 15:55:07 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-06-29 15:55:07 --> Form Validation Class Initialized
DEBUG - 2019-06-29 15:55:07 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-06-29 15:55:07 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-06-29 15:55:07 --> Pagination Class Initialized
INFO - 2019-06-29 15:55:07 --> Controller Class Initialized
INFO - 2019-06-29 21:55:07 --> Model Class Initialized
INFO - 2019-06-29 21:55:08 --> Model Class Initialized
INFO - 2019-06-29 21:55:08 --> Model Class Initialized
INFO - 2019-06-29 21:55:08 --> Final output sent to browser
DEBUG - 2019-06-29 21:55:08 --> Total execution time: 0.4470
INFO - 2019-06-29 15:55:10 --> Config Class Initialized
INFO - 2019-06-29 15:55:10 --> Hooks Class Initialized
DEBUG - 2019-06-29 15:55:10 --> UTF-8 Support Enabled
INFO - 2019-06-29 15:55:10 --> Utf8 Class Initialized
INFO - 2019-06-29 15:55:10 --> URI Class Initialized
DEBUG - 2019-06-29 15:55:10 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/routes.php
INFO - 2019-06-29 15:55:10 --> Router Class Initialized
INFO - 2019-06-29 15:55:10 --> Output Class Initialized
INFO - 2019-06-29 15:55:10 --> Security Class Initialized
DEBUG - 2019-06-29 15:55:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 15:55:10 --> Input Class Initialized
INFO - 2019-06-29 15:55:10 --> Language Class Initialized
INFO - 2019-06-29 15:55:10 --> Language Class Initialized
INFO - 2019-06-29 15:55:10 --> Config Class Initialized
INFO - 2019-06-29 15:55:10 --> Loader Class Initialized
DEBUG - 2019-06-29 15:55:10 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/site.php
INFO - 2019-06-29 15:55:10 --> Helper loaded: url_helper
INFO - 2019-06-29 15:55:10 --> Helper loaded: inflector_helper
INFO - 2019-06-29 15:55:10 --> Helper loaded: string_helper
INFO - 2019-06-29 15:55:10 --> Helper loaded: array_helper
INFO - 2019-06-29 15:55:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 15:55:10 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/autoload.php
DEBUG - 2019-06-29 15:55:10 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/helpers/adminlte_helper.php
INFO - 2019-06-29 15:55:10 --> Database Driver Class Initialized
DEBUG - 2019-06-29 15:55:10 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/libraries/Crud.php
INFO - 2019-06-29 15:55:10 --> Helper loaded: form_helper
DEBUG - 2019-06-29 15:55:10 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-06-29 15:55:10 --> Form Validation Class Initialized
DEBUG - 2019-06-29 15:55:10 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-06-29 15:55:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-06-29 15:55:10 --> Pagination Class Initialized
INFO - 2019-06-29 15:55:10 --> Controller Class Initialized
INFO - 2019-06-29 21:55:10 --> Model Class Initialized
INFO - 2019-06-29 21:55:10 --> Model Class Initialized
INFO - 2019-06-29 21:55:10 --> Final output sent to browser
DEBUG - 2019-06-29 21:55:10 --> Total execution time: 0.4387
INFO - 2019-06-29 15:55:15 --> Config Class Initialized
INFO - 2019-06-29 15:55:15 --> Hooks Class Initialized
DEBUG - 2019-06-29 15:55:15 --> UTF-8 Support Enabled
INFO - 2019-06-29 15:55:15 --> Utf8 Class Initialized
INFO - 2019-06-29 15:55:15 --> URI Class Initialized
DEBUG - 2019-06-29 15:55:15 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/routes.php
INFO - 2019-06-29 15:55:15 --> Router Class Initialized
INFO - 2019-06-29 15:55:15 --> Output Class Initialized
INFO - 2019-06-29 15:55:15 --> Security Class Initialized
DEBUG - 2019-06-29 15:55:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 15:55:15 --> Input Class Initialized
INFO - 2019-06-29 15:55:15 --> Language Class Initialized
INFO - 2019-06-29 15:55:15 --> Language Class Initialized
INFO - 2019-06-29 15:55:15 --> Config Class Initialized
INFO - 2019-06-29 15:55:15 --> Loader Class Initialized
DEBUG - 2019-06-29 15:55:15 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/site.php
INFO - 2019-06-29 15:55:15 --> Helper loaded: url_helper
INFO - 2019-06-29 15:55:15 --> Helper loaded: inflector_helper
INFO - 2019-06-29 15:55:15 --> Helper loaded: string_helper
INFO - 2019-06-29 15:55:15 --> Helper loaded: array_helper
INFO - 2019-06-29 15:55:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 15:55:15 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/autoload.php
DEBUG - 2019-06-29 15:55:15 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/helpers/adminlte_helper.php
INFO - 2019-06-29 15:55:15 --> Database Driver Class Initialized
DEBUG - 2019-06-29 15:55:15 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/libraries/Crud.php
INFO - 2019-06-29 15:55:15 --> Helper loaded: form_helper
DEBUG - 2019-06-29 15:55:15 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-06-29 15:55:15 --> Form Validation Class Initialized
DEBUG - 2019-06-29 15:55:15 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-06-29 15:55:15 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-06-29 15:55:15 --> Pagination Class Initialized
INFO - 2019-06-29 15:55:15 --> Controller Class Initialized
INFO - 2019-06-29 21:55:15 --> Model Class Initialized
INFO - 2019-06-29 21:55:15 --> Model Class Initialized
INFO - 2019-06-29 21:55:16 --> Final output sent to browser
DEBUG - 2019-06-29 21:55:16 --> Total execution time: 0.3951
INFO - 2019-06-29 15:55:29 --> Config Class Initialized
INFO - 2019-06-29 15:55:29 --> Hooks Class Initialized
DEBUG - 2019-06-29 15:55:29 --> UTF-8 Support Enabled
INFO - 2019-06-29 15:55:29 --> Utf8 Class Initialized
INFO - 2019-06-29 15:55:29 --> URI Class Initialized
DEBUG - 2019-06-29 15:55:29 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/routes.php
INFO - 2019-06-29 15:55:29 --> Router Class Initialized
INFO - 2019-06-29 15:55:29 --> Output Class Initialized
INFO - 2019-06-29 15:55:29 --> Security Class Initialized
DEBUG - 2019-06-29 15:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 15:55:29 --> Input Class Initialized
INFO - 2019-06-29 15:55:29 --> Language Class Initialized
INFO - 2019-06-29 15:55:29 --> Language Class Initialized
INFO - 2019-06-29 15:55:29 --> Config Class Initialized
INFO - 2019-06-29 15:55:29 --> Loader Class Initialized
DEBUG - 2019-06-29 15:55:29 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/site.php
INFO - 2019-06-29 15:55:29 --> Helper loaded: url_helper
INFO - 2019-06-29 15:55:30 --> Helper loaded: inflector_helper
INFO - 2019-06-29 15:55:30 --> Helper loaded: string_helper
INFO - 2019-06-29 15:55:30 --> Helper loaded: array_helper
INFO - 2019-06-29 15:55:30 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 15:55:30 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/autoload.php
DEBUG - 2019-06-29 15:55:30 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/helpers/adminlte_helper.php
INFO - 2019-06-29 15:55:30 --> Database Driver Class Initialized
DEBUG - 2019-06-29 15:55:30 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/libraries/Crud.php
INFO - 2019-06-29 15:55:30 --> Helper loaded: form_helper
DEBUG - 2019-06-29 15:55:30 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-06-29 15:55:30 --> Form Validation Class Initialized
DEBUG - 2019-06-29 15:55:30 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-06-29 15:55:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-06-29 15:55:30 --> Pagination Class Initialized
INFO - 2019-06-29 15:55:30 --> Controller Class Initialized
INFO - 2019-06-29 21:55:30 --> Model Class Initialized
INFO - 2019-06-29 21:55:30 --> Model Class Initialized
INFO - 2019-06-29 15:55:30 --> Config Class Initialized
INFO - 2019-06-29 15:55:30 --> Hooks Class Initialized
DEBUG - 2019-06-29 15:55:30 --> UTF-8 Support Enabled
INFO - 2019-06-29 15:55:30 --> Utf8 Class Initialized
INFO - 2019-06-29 15:55:30 --> URI Class Initialized
DEBUG - 2019-06-29 15:55:30 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/routes.php
INFO - 2019-06-29 15:55:30 --> Router Class Initialized
INFO - 2019-06-29 15:55:30 --> Output Class Initialized
INFO - 2019-06-29 15:55:30 --> Security Class Initialized
DEBUG - 2019-06-29 15:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 15:55:30 --> Input Class Initialized
INFO - 2019-06-29 15:55:30 --> Language Class Initialized
INFO - 2019-06-29 15:55:30 --> Language Class Initialized
INFO - 2019-06-29 15:55:30 --> Config Class Initialized
INFO - 2019-06-29 15:55:30 --> Loader Class Initialized
DEBUG - 2019-06-29 15:55:30 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/site.php
INFO - 2019-06-29 15:55:30 --> Helper loaded: url_helper
INFO - 2019-06-29 15:55:30 --> Helper loaded: inflector_helper
INFO - 2019-06-29 15:55:30 --> Helper loaded: string_helper
INFO - 2019-06-29 15:55:30 --> Helper loaded: array_helper
INFO - 2019-06-29 15:55:30 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 15:55:30 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/autoload.php
DEBUG - 2019-06-29 15:55:30 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/helpers/adminlte_helper.php
INFO - 2019-06-29 15:55:30 --> Database Driver Class Initialized
DEBUG - 2019-06-29 15:55:30 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/libraries/Crud.php
INFO - 2019-06-29 15:55:30 --> Helper loaded: form_helper
DEBUG - 2019-06-29 15:55:30 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-06-29 15:55:30 --> Form Validation Class Initialized
DEBUG - 2019-06-29 15:55:30 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-06-29 15:55:30 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-06-29 15:55:30 --> Pagination Class Initialized
INFO - 2019-06-29 15:55:30 --> Controller Class Initialized
INFO - 2019-06-29 21:55:30 --> Model Class Initialized
INFO - 2019-06-29 21:55:30 --> Model Class Initialized
INFO - 2019-06-29 21:55:30 --> Final output sent to browser
DEBUG - 2019-06-29 21:55:30 --> Total execution time: 0.5748
INFO - 2019-06-29 15:55:36 --> Config Class Initialized
INFO - 2019-06-29 15:55:36 --> Hooks Class Initialized
DEBUG - 2019-06-29 15:55:36 --> UTF-8 Support Enabled
INFO - 2019-06-29 15:55:36 --> Utf8 Class Initialized
INFO - 2019-06-29 15:55:36 --> URI Class Initialized
INFO - 2019-06-29 15:55:36 --> Router Class Initialized
INFO - 2019-06-29 15:55:36 --> Output Class Initialized
INFO - 2019-06-29 15:55:36 --> Security Class Initialized
DEBUG - 2019-06-29 15:55:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 15:55:36 --> Input Class Initialized
INFO - 2019-06-29 15:55:36 --> Language Class Initialized
INFO - 2019-06-29 15:55:36 --> Language Class Initialized
INFO - 2019-06-29 15:55:36 --> Config Class Initialized
INFO - 2019-06-29 15:55:36 --> Loader Class Initialized
DEBUG - 2019-06-29 15:55:36 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 15:55:36 --> Helper loaded: url_helper
INFO - 2019-06-29 15:55:36 --> Helper loaded: inflector_helper
INFO - 2019-06-29 15:55:36 --> Helper loaded: string_helper
INFO - 2019-06-29 15:55:36 --> Helper loaded: array_helper
INFO - 2019-06-29 15:55:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 15:55:36 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 15:55:36 --> Database Driver Class Initialized
INFO - 2019-06-29 15:55:36 --> Controller Class Initialized
INFO - 2019-06-29 21:55:36 --> Helper loaded: language_helper
INFO - 2019-06-29 21:55:36 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 21:55:36 --> Model Class Initialized
INFO - 2019-06-29 21:55:36 --> Model Class Initialized
INFO - 2019-06-29 21:55:36 --> Model Class Initialized
INFO - 2019-06-29 21:55:36 --> Model Class Initialized
INFO - 2019-06-29 21:55:36 --> Final output sent to browser
DEBUG - 2019-06-29 21:55:36 --> Total execution time: 0.4814
INFO - 2019-06-29 15:55:37 --> Config Class Initialized
INFO - 2019-06-29 15:55:37 --> Hooks Class Initialized
DEBUG - 2019-06-29 15:55:37 --> UTF-8 Support Enabled
INFO - 2019-06-29 15:55:37 --> Utf8 Class Initialized
INFO - 2019-06-29 15:55:37 --> URI Class Initialized
INFO - 2019-06-29 15:55:37 --> Router Class Initialized
INFO - 2019-06-29 15:55:37 --> Output Class Initialized
INFO - 2019-06-29 15:55:37 --> Security Class Initialized
DEBUG - 2019-06-29 15:55:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 15:55:37 --> Input Class Initialized
INFO - 2019-06-29 15:55:37 --> Language Class Initialized
INFO - 2019-06-29 15:55:37 --> Language Class Initialized
INFO - 2019-06-29 15:55:37 --> Config Class Initialized
INFO - 2019-06-29 15:55:37 --> Loader Class Initialized
DEBUG - 2019-06-29 15:55:37 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 15:55:37 --> Helper loaded: url_helper
INFO - 2019-06-29 15:55:37 --> Helper loaded: inflector_helper
INFO - 2019-06-29 15:55:37 --> Helper loaded: string_helper
INFO - 2019-06-29 15:55:37 --> Helper loaded: array_helper
INFO - 2019-06-29 15:55:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 15:55:37 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 15:55:37 --> Database Driver Class Initialized
INFO - 2019-06-29 15:55:37 --> Controller Class Initialized
INFO - 2019-06-29 21:55:37 --> Helper loaded: language_helper
INFO - 2019-06-29 21:55:37 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 21:55:37 --> Model Class Initialized
INFO - 2019-06-29 21:55:37 --> Model Class Initialized
INFO - 2019-06-29 21:55:37 --> Model Class Initialized
INFO - 2019-06-29 21:55:37 --> Model Class Initialized
INFO - 2019-06-29 21:55:37 --> Model Class Initialized
INFO - 2019-06-29 21:55:37 --> Final output sent to browser
DEBUG - 2019-06-29 21:55:37 --> Total execution time: 0.5902
INFO - 2019-06-29 15:55:42 --> Config Class Initialized
INFO - 2019-06-29 15:55:42 --> Hooks Class Initialized
DEBUG - 2019-06-29 15:55:42 --> UTF-8 Support Enabled
INFO - 2019-06-29 15:55:42 --> Utf8 Class Initialized
INFO - 2019-06-29 15:55:42 --> URI Class Initialized
INFO - 2019-06-29 15:55:42 --> Router Class Initialized
INFO - 2019-06-29 15:55:42 --> Output Class Initialized
INFO - 2019-06-29 15:55:42 --> Security Class Initialized
DEBUG - 2019-06-29 15:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 15:55:42 --> Input Class Initialized
INFO - 2019-06-29 15:55:42 --> Language Class Initialized
INFO - 2019-06-29 15:55:42 --> Language Class Initialized
INFO - 2019-06-29 15:55:42 --> Config Class Initialized
INFO - 2019-06-29 15:55:42 --> Loader Class Initialized
DEBUG - 2019-06-29 15:55:42 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 15:55:42 --> Helper loaded: url_helper
INFO - 2019-06-29 15:55:42 --> Helper loaded: inflector_helper
INFO - 2019-06-29 15:55:42 --> Helper loaded: string_helper
INFO - 2019-06-29 15:55:42 --> Helper loaded: array_helper
INFO - 2019-06-29 15:55:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 15:55:42 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 15:55:42 --> Database Driver Class Initialized
INFO - 2019-06-29 15:55:42 --> Controller Class Initialized
INFO - 2019-06-29 21:55:42 --> Helper loaded: language_helper
INFO - 2019-06-29 21:55:42 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 21:55:42 --> Model Class Initialized
INFO - 2019-06-29 21:55:42 --> Model Class Initialized
INFO - 2019-06-29 21:55:42 --> Model Class Initialized
INFO - 2019-06-29 21:55:42 --> Model Class Initialized
INFO - 2019-06-29 21:55:42 --> Helper loaded: form_helper
INFO - 2019-06-29 21:55:42 --> Form Validation Class Initialized
DEBUG - 2019-06-29 21:55:42 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-29 21:55:42 --> Model Class Initialized
INFO - 2019-06-29 21:55:42 --> Model Class Initialized
INFO - 2019-06-29 21:55:42 --> Final output sent to browser
DEBUG - 2019-06-29 21:55:42 --> Total execution time: 0.5549
INFO - 2019-06-29 15:55:43 --> Config Class Initialized
INFO - 2019-06-29 15:55:43 --> Hooks Class Initialized
DEBUG - 2019-06-29 15:55:43 --> UTF-8 Support Enabled
INFO - 2019-06-29 15:55:43 --> Utf8 Class Initialized
INFO - 2019-06-29 15:55:43 --> URI Class Initialized
INFO - 2019-06-29 15:55:43 --> Router Class Initialized
INFO - 2019-06-29 15:55:43 --> Output Class Initialized
INFO - 2019-06-29 15:55:43 --> Security Class Initialized
DEBUG - 2019-06-29 15:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 15:55:43 --> Input Class Initialized
INFO - 2019-06-29 15:55:43 --> Language Class Initialized
INFO - 2019-06-29 15:55:43 --> Language Class Initialized
INFO - 2019-06-29 15:55:43 --> Config Class Initialized
INFO - 2019-06-29 15:55:43 --> Loader Class Initialized
DEBUG - 2019-06-29 15:55:43 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 15:55:43 --> Helper loaded: url_helper
INFO - 2019-06-29 15:55:43 --> Helper loaded: inflector_helper
INFO - 2019-06-29 15:55:43 --> Helper loaded: string_helper
INFO - 2019-06-29 15:55:43 --> Helper loaded: array_helper
INFO - 2019-06-29 15:55:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 15:55:43 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 15:55:43 --> Database Driver Class Initialized
INFO - 2019-06-29 15:55:43 --> Controller Class Initialized
INFO - 2019-06-29 21:55:43 --> Helper loaded: language_helper
INFO - 2019-06-29 21:55:43 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 21:55:43 --> Model Class Initialized
INFO - 2019-06-29 21:55:43 --> Model Class Initialized
INFO - 2019-06-29 21:55:43 --> Model Class Initialized
INFO - 2019-06-29 21:55:43 --> Model Class Initialized
INFO - 2019-06-29 21:55:43 --> Model Class Initialized
ERROR - 2019-06-29 21:55:43 --> Query error: Unknown column 'resto_id' in 'where clause' - Invalid query: SELECT * FROM products WHERE resto_id = "8" ORDER BY products.id DESC
INFO - 2019-06-29 21:55:43 --> Language file loaded: language/english/db_lang.php
INFO - 2019-06-29 15:56:43 --> Config Class Initialized
INFO - 2019-06-29 15:56:43 --> Hooks Class Initialized
DEBUG - 2019-06-29 15:56:43 --> UTF-8 Support Enabled
INFO - 2019-06-29 15:56:43 --> Utf8 Class Initialized
INFO - 2019-06-29 15:56:43 --> URI Class Initialized
INFO - 2019-06-29 15:56:43 --> Router Class Initialized
INFO - 2019-06-29 15:56:43 --> Output Class Initialized
INFO - 2019-06-29 15:56:43 --> Security Class Initialized
DEBUG - 2019-06-29 15:56:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 15:56:43 --> Input Class Initialized
INFO - 2019-06-29 15:56:44 --> Language Class Initialized
INFO - 2019-06-29 15:56:44 --> Language Class Initialized
INFO - 2019-06-29 15:56:44 --> Config Class Initialized
INFO - 2019-06-29 15:56:44 --> Loader Class Initialized
DEBUG - 2019-06-29 15:56:44 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 15:56:44 --> Helper loaded: url_helper
INFO - 2019-06-29 15:56:44 --> Helper loaded: inflector_helper
INFO - 2019-06-29 15:56:44 --> Helper loaded: string_helper
INFO - 2019-06-29 15:56:44 --> Helper loaded: array_helper
INFO - 2019-06-29 15:56:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 15:56:44 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 15:56:44 --> Database Driver Class Initialized
INFO - 2019-06-29 15:56:44 --> Controller Class Initialized
INFO - 2019-06-29 21:56:44 --> Helper loaded: language_helper
INFO - 2019-06-29 21:56:44 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 21:56:44 --> Model Class Initialized
INFO - 2019-06-29 21:56:44 --> Model Class Initialized
INFO - 2019-06-29 21:56:44 --> Model Class Initialized
INFO - 2019-06-29 21:56:44 --> Model Class Initialized
INFO - 2019-06-29 21:56:44 --> Helper loaded: form_helper
INFO - 2019-06-29 21:56:44 --> Form Validation Class Initialized
DEBUG - 2019-06-29 21:56:44 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-29 21:56:44 --> Model Class Initialized
INFO - 2019-06-29 21:56:44 --> Model Class Initialized
INFO - 2019-06-29 21:56:44 --> Final output sent to browser
DEBUG - 2019-06-29 21:56:44 --> Total execution time: 0.5373
INFO - 2019-06-29 15:56:45 --> Config Class Initialized
INFO - 2019-06-29 15:56:45 --> Hooks Class Initialized
DEBUG - 2019-06-29 15:56:45 --> UTF-8 Support Enabled
INFO - 2019-06-29 15:56:45 --> Utf8 Class Initialized
INFO - 2019-06-29 15:56:45 --> URI Class Initialized
INFO - 2019-06-29 15:56:45 --> Router Class Initialized
INFO - 2019-06-29 15:56:45 --> Output Class Initialized
INFO - 2019-06-29 15:56:45 --> Security Class Initialized
DEBUG - 2019-06-29 15:56:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 15:56:45 --> Input Class Initialized
INFO - 2019-06-29 15:56:45 --> Language Class Initialized
INFO - 2019-06-29 15:56:45 --> Language Class Initialized
INFO - 2019-06-29 15:56:45 --> Config Class Initialized
INFO - 2019-06-29 15:56:45 --> Loader Class Initialized
DEBUG - 2019-06-29 15:56:45 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 15:56:45 --> Helper loaded: url_helper
INFO - 2019-06-29 15:56:45 --> Helper loaded: inflector_helper
INFO - 2019-06-29 15:56:45 --> Helper loaded: string_helper
INFO - 2019-06-29 15:56:45 --> Helper loaded: array_helper
INFO - 2019-06-29 15:56:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 15:56:45 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 15:56:45 --> Database Driver Class Initialized
INFO - 2019-06-29 15:56:45 --> Controller Class Initialized
INFO - 2019-06-29 21:56:45 --> Helper loaded: language_helper
INFO - 2019-06-29 21:56:45 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 21:56:45 --> Model Class Initialized
INFO - 2019-06-29 21:56:45 --> Model Class Initialized
INFO - 2019-06-29 21:56:45 --> Model Class Initialized
INFO - 2019-06-29 21:56:45 --> Model Class Initialized
INFO - 2019-06-29 21:56:45 --> Model Class Initialized
INFO - 2019-06-29 21:56:45 --> Final output sent to browser
DEBUG - 2019-06-29 21:56:45 --> Total execution time: 0.3161
INFO - 2019-06-29 15:58:14 --> Config Class Initialized
INFO - 2019-06-29 15:58:14 --> Hooks Class Initialized
DEBUG - 2019-06-29 15:58:14 --> UTF-8 Support Enabled
INFO - 2019-06-29 15:58:14 --> Utf8 Class Initialized
INFO - 2019-06-29 15:58:14 --> URI Class Initialized
INFO - 2019-06-29 15:58:14 --> Router Class Initialized
INFO - 2019-06-29 15:58:14 --> Output Class Initialized
INFO - 2019-06-29 15:58:14 --> Security Class Initialized
DEBUG - 2019-06-29 15:58:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 15:58:14 --> Input Class Initialized
INFO - 2019-06-29 15:58:14 --> Language Class Initialized
INFO - 2019-06-29 15:58:14 --> Language Class Initialized
INFO - 2019-06-29 15:58:14 --> Config Class Initialized
INFO - 2019-06-29 15:58:14 --> Loader Class Initialized
DEBUG - 2019-06-29 15:58:15 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 15:58:15 --> Helper loaded: url_helper
INFO - 2019-06-29 15:58:15 --> Helper loaded: inflector_helper
INFO - 2019-06-29 15:58:15 --> Helper loaded: string_helper
INFO - 2019-06-29 15:58:15 --> Helper loaded: array_helper
INFO - 2019-06-29 15:58:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 15:58:15 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 15:58:15 --> Database Driver Class Initialized
INFO - 2019-06-29 15:58:15 --> Controller Class Initialized
INFO - 2019-06-29 21:58:15 --> Helper loaded: language_helper
INFO - 2019-06-29 21:58:15 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 21:58:15 --> Model Class Initialized
INFO - 2019-06-29 21:58:15 --> Model Class Initialized
INFO - 2019-06-29 21:58:15 --> Model Class Initialized
INFO - 2019-06-29 21:58:15 --> Model Class Initialized
INFO - 2019-06-29 21:58:15 --> Helper loaded: form_helper
INFO - 2019-06-29 21:58:15 --> Form Validation Class Initialized
DEBUG - 2019-06-29 21:58:15 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-29 21:58:15 --> Model Class Initialized
INFO - 2019-06-29 21:58:15 --> Model Class Initialized
INFO - 2019-06-29 21:58:15 --> Final output sent to browser
DEBUG - 2019-06-29 21:58:15 --> Total execution time: 0.3768
INFO - 2019-06-29 15:58:15 --> Config Class Initialized
INFO - 2019-06-29 15:58:15 --> Hooks Class Initialized
DEBUG - 2019-06-29 15:58:15 --> UTF-8 Support Enabled
INFO - 2019-06-29 15:58:15 --> Utf8 Class Initialized
INFO - 2019-06-29 15:58:15 --> URI Class Initialized
INFO - 2019-06-29 15:58:15 --> Router Class Initialized
INFO - 2019-06-29 15:58:15 --> Output Class Initialized
INFO - 2019-06-29 15:58:15 --> Security Class Initialized
DEBUG - 2019-06-29 15:58:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 15:58:15 --> Input Class Initialized
INFO - 2019-06-29 15:58:15 --> Language Class Initialized
INFO - 2019-06-29 15:58:15 --> Language Class Initialized
INFO - 2019-06-29 15:58:15 --> Config Class Initialized
INFO - 2019-06-29 15:58:15 --> Loader Class Initialized
DEBUG - 2019-06-29 15:58:15 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 15:58:15 --> Helper loaded: url_helper
INFO - 2019-06-29 15:58:15 --> Helper loaded: inflector_helper
INFO - 2019-06-29 15:58:15 --> Helper loaded: string_helper
INFO - 2019-06-29 15:58:15 --> Helper loaded: array_helper
INFO - 2019-06-29 15:58:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 15:58:15 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 15:58:15 --> Database Driver Class Initialized
INFO - 2019-06-29 15:58:15 --> Controller Class Initialized
INFO - 2019-06-29 21:58:15 --> Helper loaded: language_helper
INFO - 2019-06-29 21:58:15 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 21:58:15 --> Model Class Initialized
INFO - 2019-06-29 21:58:15 --> Model Class Initialized
INFO - 2019-06-29 21:58:15 --> Model Class Initialized
INFO - 2019-06-29 21:58:15 --> Model Class Initialized
INFO - 2019-06-29 21:58:15 --> Model Class Initialized
INFO - 2019-06-29 21:58:15 --> Final output sent to browser
DEBUG - 2019-06-29 21:58:15 --> Total execution time: 0.2698
INFO - 2019-06-29 15:58:21 --> Config Class Initialized
INFO - 2019-06-29 15:58:21 --> Hooks Class Initialized
DEBUG - 2019-06-29 15:58:22 --> UTF-8 Support Enabled
INFO - 2019-06-29 15:58:22 --> Utf8 Class Initialized
INFO - 2019-06-29 15:58:22 --> URI Class Initialized
INFO - 2019-06-29 15:58:22 --> Router Class Initialized
INFO - 2019-06-29 15:58:22 --> Output Class Initialized
INFO - 2019-06-29 15:58:22 --> Security Class Initialized
DEBUG - 2019-06-29 15:58:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 15:58:22 --> Input Class Initialized
INFO - 2019-06-29 15:58:22 --> Language Class Initialized
INFO - 2019-06-29 15:58:22 --> Language Class Initialized
INFO - 2019-06-29 15:58:22 --> Config Class Initialized
INFO - 2019-06-29 15:58:22 --> Loader Class Initialized
DEBUG - 2019-06-29 15:58:22 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 15:58:22 --> Helper loaded: url_helper
INFO - 2019-06-29 15:58:22 --> Helper loaded: inflector_helper
INFO - 2019-06-29 15:58:22 --> Helper loaded: string_helper
INFO - 2019-06-29 15:58:22 --> Helper loaded: array_helper
INFO - 2019-06-29 15:58:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 15:58:22 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 15:58:22 --> Database Driver Class Initialized
INFO - 2019-06-29 15:58:22 --> Controller Class Initialized
INFO - 2019-06-29 21:58:22 --> Helper loaded: language_helper
INFO - 2019-06-29 21:58:22 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 21:58:22 --> Model Class Initialized
INFO - 2019-06-29 21:58:22 --> Model Class Initialized
INFO - 2019-06-29 21:58:22 --> Model Class Initialized
INFO - 2019-06-29 21:58:22 --> Model Class Initialized
INFO - 2019-06-29 21:58:22 --> Model Class Initialized
ERROR - 2019-06-29 21:58:22 --> Query error: Unknown table 'crapi.menus' - Invalid query: SELECT menus.* FROM products WHERE name LIKE "%h%" ORDER BY products.id DESC
INFO - 2019-06-29 21:58:22 --> Language file loaded: language/english/db_lang.php
INFO - 2019-06-29 15:59:09 --> Config Class Initialized
INFO - 2019-06-29 15:59:09 --> Hooks Class Initialized
DEBUG - 2019-06-29 15:59:09 --> UTF-8 Support Enabled
INFO - 2019-06-29 15:59:09 --> Utf8 Class Initialized
INFO - 2019-06-29 15:59:09 --> URI Class Initialized
INFO - 2019-06-29 15:59:09 --> Router Class Initialized
INFO - 2019-06-29 15:59:09 --> Output Class Initialized
INFO - 2019-06-29 15:59:09 --> Security Class Initialized
DEBUG - 2019-06-29 15:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 15:59:09 --> Input Class Initialized
INFO - 2019-06-29 15:59:09 --> Language Class Initialized
INFO - 2019-06-29 15:59:09 --> Language Class Initialized
INFO - 2019-06-29 15:59:09 --> Config Class Initialized
INFO - 2019-06-29 15:59:09 --> Loader Class Initialized
DEBUG - 2019-06-29 15:59:09 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 15:59:09 --> Helper loaded: url_helper
INFO - 2019-06-29 15:59:09 --> Helper loaded: inflector_helper
INFO - 2019-06-29 15:59:09 --> Helper loaded: string_helper
INFO - 2019-06-29 15:59:09 --> Helper loaded: array_helper
INFO - 2019-06-29 15:59:09 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 15:59:09 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 15:59:09 --> Database Driver Class Initialized
INFO - 2019-06-29 15:59:09 --> Controller Class Initialized
INFO - 2019-06-29 21:59:09 --> Helper loaded: language_helper
INFO - 2019-06-29 21:59:09 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 21:59:09 --> Model Class Initialized
INFO - 2019-06-29 21:59:09 --> Model Class Initialized
INFO - 2019-06-29 21:59:09 --> Model Class Initialized
INFO - 2019-06-29 21:59:09 --> Model Class Initialized
INFO - 2019-06-29 21:59:09 --> Helper loaded: form_helper
INFO - 2019-06-29 21:59:09 --> Form Validation Class Initialized
INFO - 2019-06-29 15:59:09 --> Config Class Initialized
DEBUG - 2019-06-29 21:59:09 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-29 15:59:09 --> Hooks Class Initialized
DEBUG - 2019-06-29 15:59:09 --> UTF-8 Support Enabled
INFO - 2019-06-29 15:59:09 --> Utf8 Class Initialized
INFO - 2019-06-29 21:59:09 --> Model Class Initialized
INFO - 2019-06-29 15:59:09 --> URI Class Initialized
INFO - 2019-06-29 21:59:09 --> Model Class Initialized
INFO - 2019-06-29 21:59:09 --> Final output sent to browser
INFO - 2019-06-29 15:59:10 --> Router Class Initialized
DEBUG - 2019-06-29 21:59:10 --> Total execution time: 0.8955
INFO - 2019-06-29 15:59:10 --> Output Class Initialized
INFO - 2019-06-29 15:59:10 --> Security Class Initialized
DEBUG - 2019-06-29 15:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 15:59:10 --> Input Class Initialized
INFO - 2019-06-29 15:59:10 --> Language Class Initialized
INFO - 2019-06-29 15:59:10 --> Language Class Initialized
INFO - 2019-06-29 15:59:10 --> Config Class Initialized
INFO - 2019-06-29 15:59:10 --> Loader Class Initialized
DEBUG - 2019-06-29 15:59:10 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 15:59:10 --> Helper loaded: url_helper
INFO - 2019-06-29 15:59:10 --> Helper loaded: inflector_helper
INFO - 2019-06-29 15:59:10 --> Helper loaded: string_helper
INFO - 2019-06-29 15:59:10 --> Helper loaded: array_helper
INFO - 2019-06-29 15:59:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 15:59:10 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 15:59:10 --> Database Driver Class Initialized
INFO - 2019-06-29 15:59:10 --> Controller Class Initialized
INFO - 2019-06-29 21:59:10 --> Helper loaded: language_helper
INFO - 2019-06-29 21:59:10 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 21:59:10 --> Model Class Initialized
INFO - 2019-06-29 21:59:10 --> Model Class Initialized
INFO - 2019-06-29 21:59:10 --> Model Class Initialized
INFO - 2019-06-29 21:59:10 --> Model Class Initialized
INFO - 2019-06-29 21:59:10 --> Helper loaded: form_helper
INFO - 2019-06-29 21:59:10 --> Form Validation Class Initialized
DEBUG - 2019-06-29 21:59:10 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-29 21:59:10 --> Model Class Initialized
INFO - 2019-06-29 21:59:10 --> Model Class Initialized
INFO - 2019-06-29 21:59:10 --> Final output sent to browser
DEBUG - 2019-06-29 21:59:10 --> Total execution time: 0.7792
INFO - 2019-06-29 15:59:11 --> Config Class Initialized
INFO - 2019-06-29 15:59:11 --> Hooks Class Initialized
DEBUG - 2019-06-29 15:59:11 --> UTF-8 Support Enabled
INFO - 2019-06-29 15:59:11 --> Utf8 Class Initialized
INFO - 2019-06-29 15:59:11 --> URI Class Initialized
INFO - 2019-06-29 15:59:11 --> Router Class Initialized
INFO - 2019-06-29 15:59:11 --> Output Class Initialized
INFO - 2019-06-29 15:59:11 --> Security Class Initialized
DEBUG - 2019-06-29 15:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 15:59:11 --> Input Class Initialized
INFO - 2019-06-29 15:59:11 --> Language Class Initialized
INFO - 2019-06-29 15:59:11 --> Language Class Initialized
INFO - 2019-06-29 15:59:11 --> Config Class Initialized
INFO - 2019-06-29 15:59:11 --> Loader Class Initialized
DEBUG - 2019-06-29 15:59:11 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 15:59:11 --> Helper loaded: url_helper
INFO - 2019-06-29 15:59:11 --> Helper loaded: inflector_helper
INFO - 2019-06-29 15:59:11 --> Helper loaded: string_helper
INFO - 2019-06-29 15:59:11 --> Helper loaded: array_helper
INFO - 2019-06-29 15:59:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 15:59:11 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 15:59:11 --> Database Driver Class Initialized
INFO - 2019-06-29 15:59:11 --> Controller Class Initialized
INFO - 2019-06-29 21:59:11 --> Helper loaded: language_helper
INFO - 2019-06-29 21:59:11 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 21:59:11 --> Model Class Initialized
INFO - 2019-06-29 21:59:11 --> Model Class Initialized
INFO - 2019-06-29 21:59:11 --> Model Class Initialized
INFO - 2019-06-29 21:59:11 --> Model Class Initialized
INFO - 2019-06-29 21:59:11 --> Model Class Initialized
INFO - 2019-06-29 21:59:11 --> Final output sent to browser
DEBUG - 2019-06-29 21:59:11 --> Total execution time: 0.4181
INFO - 2019-06-29 15:59:16 --> Config Class Initialized
INFO - 2019-06-29 15:59:16 --> Hooks Class Initialized
DEBUG - 2019-06-29 15:59:16 --> UTF-8 Support Enabled
INFO - 2019-06-29 15:59:16 --> Utf8 Class Initialized
INFO - 2019-06-29 15:59:16 --> URI Class Initialized
INFO - 2019-06-29 15:59:16 --> Router Class Initialized
INFO - 2019-06-29 15:59:16 --> Output Class Initialized
INFO - 2019-06-29 15:59:16 --> Security Class Initialized
DEBUG - 2019-06-29 15:59:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 15:59:16 --> Input Class Initialized
INFO - 2019-06-29 15:59:16 --> Language Class Initialized
INFO - 2019-06-29 15:59:16 --> Language Class Initialized
INFO - 2019-06-29 15:59:16 --> Config Class Initialized
INFO - 2019-06-29 15:59:16 --> Loader Class Initialized
DEBUG - 2019-06-29 15:59:16 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 15:59:16 --> Helper loaded: url_helper
INFO - 2019-06-29 15:59:16 --> Helper loaded: inflector_helper
INFO - 2019-06-29 15:59:16 --> Helper loaded: string_helper
INFO - 2019-06-29 15:59:16 --> Helper loaded: array_helper
INFO - 2019-06-29 15:59:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 15:59:16 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 15:59:16 --> Database Driver Class Initialized
INFO - 2019-06-29 15:59:16 --> Controller Class Initialized
INFO - 2019-06-29 21:59:16 --> Helper loaded: language_helper
INFO - 2019-06-29 21:59:16 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 21:59:16 --> Model Class Initialized
INFO - 2019-06-29 21:59:16 --> Model Class Initialized
INFO - 2019-06-29 21:59:16 --> Model Class Initialized
INFO - 2019-06-29 21:59:16 --> Model Class Initialized
INFO - 2019-06-29 21:59:16 --> Model Class Initialized
ERROR - 2019-06-29 21:59:16 --> Query error: Unknown table 'crapi.menus' - Invalid query: SELECT menus.* FROM products WHERE name LIKE "%h%" ORDER BY products.id DESC
INFO - 2019-06-29 21:59:16 --> Language file loaded: language/english/db_lang.php
INFO - 2019-06-29 16:03:39 --> Config Class Initialized
INFO - 2019-06-29 16:03:39 --> Hooks Class Initialized
DEBUG - 2019-06-29 16:03:39 --> UTF-8 Support Enabled
INFO - 2019-06-29 16:03:39 --> Utf8 Class Initialized
INFO - 2019-06-29 16:03:39 --> URI Class Initialized
INFO - 2019-06-29 16:03:39 --> Router Class Initialized
INFO - 2019-06-29 16:03:39 --> Output Class Initialized
INFO - 2019-06-29 16:03:39 --> Security Class Initialized
DEBUG - 2019-06-29 16:03:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 16:03:39 --> Input Class Initialized
INFO - 2019-06-29 16:03:39 --> Language Class Initialized
INFO - 2019-06-29 16:03:39 --> Language Class Initialized
INFO - 2019-06-29 16:03:39 --> Config Class Initialized
INFO - 2019-06-29 16:03:39 --> Loader Class Initialized
DEBUG - 2019-06-29 16:03:39 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 16:03:39 --> Helper loaded: url_helper
INFO - 2019-06-29 16:03:39 --> Helper loaded: inflector_helper
INFO - 2019-06-29 16:03:39 --> Helper loaded: string_helper
INFO - 2019-06-29 16:03:39 --> Helper loaded: array_helper
INFO - 2019-06-29 16:03:39 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 16:03:39 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 16:03:39 --> Database Driver Class Initialized
INFO - 2019-06-29 16:03:39 --> Controller Class Initialized
INFO - 2019-06-29 22:03:39 --> Helper loaded: language_helper
INFO - 2019-06-29 22:03:39 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 22:03:39 --> Model Class Initialized
INFO - 2019-06-29 22:03:39 --> Model Class Initialized
INFO - 2019-06-29 22:03:39 --> Model Class Initialized
INFO - 2019-06-29 22:03:39 --> Model Class Initialized
INFO - 2019-06-29 22:03:39 --> Helper loaded: form_helper
INFO - 2019-06-29 22:03:39 --> Form Validation Class Initialized
DEBUG - 2019-06-29 22:03:39 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-29 22:03:39 --> Model Class Initialized
INFO - 2019-06-29 22:03:39 --> Model Class Initialized
INFO - 2019-06-29 22:03:40 --> Final output sent to browser
DEBUG - 2019-06-29 22:03:40 --> Total execution time: 0.5717
INFO - 2019-06-29 16:03:40 --> Config Class Initialized
INFO - 2019-06-29 16:03:40 --> Hooks Class Initialized
DEBUG - 2019-06-29 16:03:40 --> UTF-8 Support Enabled
INFO - 2019-06-29 16:03:40 --> Utf8 Class Initialized
INFO - 2019-06-29 16:03:40 --> URI Class Initialized
INFO - 2019-06-29 16:03:40 --> Router Class Initialized
INFO - 2019-06-29 16:03:40 --> Output Class Initialized
INFO - 2019-06-29 16:03:40 --> Security Class Initialized
DEBUG - 2019-06-29 16:03:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 16:03:40 --> Input Class Initialized
INFO - 2019-06-29 16:03:40 --> Language Class Initialized
INFO - 2019-06-29 16:03:40 --> Language Class Initialized
INFO - 2019-06-29 16:03:40 --> Config Class Initialized
INFO - 2019-06-29 16:03:40 --> Loader Class Initialized
DEBUG - 2019-06-29 16:03:40 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 16:03:40 --> Helper loaded: url_helper
INFO - 2019-06-29 16:03:40 --> Helper loaded: inflector_helper
INFO - 2019-06-29 16:03:40 --> Helper loaded: string_helper
INFO - 2019-06-29 16:03:40 --> Helper loaded: array_helper
INFO - 2019-06-29 16:03:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 16:03:40 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 16:03:40 --> Database Driver Class Initialized
INFO - 2019-06-29 16:03:40 --> Controller Class Initialized
INFO - 2019-06-29 22:03:40 --> Helper loaded: language_helper
INFO - 2019-06-29 22:03:40 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 22:03:40 --> Model Class Initialized
INFO - 2019-06-29 22:03:40 --> Model Class Initialized
INFO - 2019-06-29 22:03:40 --> Model Class Initialized
INFO - 2019-06-29 22:03:40 --> Model Class Initialized
INFO - 2019-06-29 22:03:40 --> Model Class Initialized
INFO - 2019-06-29 22:03:40 --> Final output sent to browser
DEBUG - 2019-06-29 22:03:40 --> Total execution time: 0.4005
INFO - 2019-06-29 16:03:44 --> Config Class Initialized
INFO - 2019-06-29 16:03:44 --> Hooks Class Initialized
DEBUG - 2019-06-29 16:03:44 --> UTF-8 Support Enabled
INFO - 2019-06-29 16:03:44 --> Utf8 Class Initialized
INFO - 2019-06-29 16:03:44 --> URI Class Initialized
INFO - 2019-06-29 16:03:44 --> Router Class Initialized
INFO - 2019-06-29 16:03:44 --> Output Class Initialized
INFO - 2019-06-29 16:03:44 --> Security Class Initialized
DEBUG - 2019-06-29 16:03:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 16:03:44 --> Input Class Initialized
INFO - 2019-06-29 16:03:44 --> Language Class Initialized
INFO - 2019-06-29 16:03:44 --> Language Class Initialized
INFO - 2019-06-29 16:03:44 --> Config Class Initialized
INFO - 2019-06-29 16:03:44 --> Loader Class Initialized
DEBUG - 2019-06-29 16:03:44 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 16:03:44 --> Helper loaded: url_helper
INFO - 2019-06-29 16:03:44 --> Helper loaded: inflector_helper
INFO - 2019-06-29 16:03:44 --> Helper loaded: string_helper
INFO - 2019-06-29 16:03:44 --> Helper loaded: array_helper
INFO - 2019-06-29 16:03:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 16:03:44 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 16:03:44 --> Database Driver Class Initialized
INFO - 2019-06-29 16:03:44 --> Controller Class Initialized
INFO - 2019-06-29 22:03:44 --> Helper loaded: language_helper
INFO - 2019-06-29 22:03:44 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 22:03:44 --> Model Class Initialized
INFO - 2019-06-29 22:03:44 --> Model Class Initialized
INFO - 2019-06-29 22:03:44 --> Model Class Initialized
INFO - 2019-06-29 22:03:44 --> Model Class Initialized
INFO - 2019-06-29 22:03:44 --> Model Class Initialized
ERROR - 2019-06-29 22:03:44 --> Query error: Unknown table 'crapi.menus' - Invalid query: SELECT menus.* FROM products WHERE name LIKE "%h%" ORDER BY products.id DESC
INFO - 2019-06-29 22:03:44 --> Language file loaded: language/english/db_lang.php
INFO - 2019-06-29 16:04:07 --> Config Class Initialized
INFO - 2019-06-29 16:04:07 --> Hooks Class Initialized
DEBUG - 2019-06-29 16:04:07 --> UTF-8 Support Enabled
INFO - 2019-06-29 16:04:07 --> Utf8 Class Initialized
INFO - 2019-06-29 16:04:07 --> URI Class Initialized
INFO - 2019-06-29 16:04:07 --> Router Class Initialized
INFO - 2019-06-29 16:04:07 --> Output Class Initialized
INFO - 2019-06-29 16:04:07 --> Security Class Initialized
DEBUG - 2019-06-29 16:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 16:04:07 --> Input Class Initialized
INFO - 2019-06-29 16:04:07 --> Language Class Initialized
INFO - 2019-06-29 16:04:07 --> Language Class Initialized
INFO - 2019-06-29 16:04:07 --> Config Class Initialized
INFO - 2019-06-29 16:04:07 --> Loader Class Initialized
DEBUG - 2019-06-29 16:04:07 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 16:04:07 --> Helper loaded: url_helper
INFO - 2019-06-29 16:04:07 --> Helper loaded: inflector_helper
INFO - 2019-06-29 16:04:07 --> Helper loaded: string_helper
INFO - 2019-06-29 16:04:07 --> Helper loaded: array_helper
INFO - 2019-06-29 16:04:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 16:04:07 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 16:04:07 --> Database Driver Class Initialized
INFO - 2019-06-29 16:04:07 --> Controller Class Initialized
INFO - 2019-06-29 22:04:07 --> Helper loaded: language_helper
INFO - 2019-06-29 22:04:07 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 22:04:07 --> Model Class Initialized
INFO - 2019-06-29 22:04:07 --> Model Class Initialized
INFO - 2019-06-29 22:04:07 --> Model Class Initialized
INFO - 2019-06-29 22:04:07 --> Model Class Initialized
INFO - 2019-06-29 22:04:07 --> Model Class Initialized
ERROR - 2019-06-29 22:04:07 --> Query error: Unknown table 'crapi.menus' - Invalid query: SELECT menus.* FROM products WHERE name LIKE "%Test menu%" ORDER BY products.id DESC
INFO - 2019-06-29 22:04:08 --> Language file loaded: language/english/db_lang.php
INFO - 2019-06-29 16:05:36 --> Config Class Initialized
INFO - 2019-06-29 16:05:36 --> Hooks Class Initialized
DEBUG - 2019-06-29 16:05:36 --> UTF-8 Support Enabled
INFO - 2019-06-29 16:05:36 --> Utf8 Class Initialized
INFO - 2019-06-29 16:05:36 --> URI Class Initialized
INFO - 2019-06-29 16:05:36 --> Router Class Initialized
INFO - 2019-06-29 16:05:36 --> Output Class Initialized
INFO - 2019-06-29 16:05:36 --> Security Class Initialized
DEBUG - 2019-06-29 16:05:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 16:05:37 --> Input Class Initialized
INFO - 2019-06-29 16:05:37 --> Language Class Initialized
INFO - 2019-06-29 16:05:37 --> Language Class Initialized
INFO - 2019-06-29 16:05:37 --> Config Class Initialized
INFO - 2019-06-29 16:05:37 --> Loader Class Initialized
DEBUG - 2019-06-29 16:05:37 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 16:05:37 --> Helper loaded: url_helper
INFO - 2019-06-29 16:05:37 --> Helper loaded: inflector_helper
INFO - 2019-06-29 16:05:37 --> Helper loaded: string_helper
INFO - 2019-06-29 16:05:37 --> Helper loaded: array_helper
INFO - 2019-06-29 16:05:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 16:05:37 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 16:05:37 --> Database Driver Class Initialized
INFO - 2019-06-29 16:05:37 --> Controller Class Initialized
INFO - 2019-06-29 22:05:37 --> Helper loaded: language_helper
INFO - 2019-06-29 22:05:37 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 16:05:37 --> Config Class Initialized
INFO - 2019-06-29 22:05:37 --> Model Class Initialized
INFO - 2019-06-29 16:05:37 --> Hooks Class Initialized
INFO - 2019-06-29 22:05:37 --> Model Class Initialized
DEBUG - 2019-06-29 16:05:37 --> UTF-8 Support Enabled
INFO - 2019-06-29 22:05:37 --> Model Class Initialized
INFO - 2019-06-29 16:05:37 --> Utf8 Class Initialized
INFO - 2019-06-29 22:05:37 --> Model Class Initialized
INFO - 2019-06-29 16:05:37 --> URI Class Initialized
INFO - 2019-06-29 22:05:37 --> Helper loaded: form_helper
INFO - 2019-06-29 16:05:37 --> Router Class Initialized
INFO - 2019-06-29 22:05:37 --> Form Validation Class Initialized
INFO - 2019-06-29 16:05:37 --> Output Class Initialized
DEBUG - 2019-06-29 22:05:37 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-29 16:05:37 --> Security Class Initialized
INFO - 2019-06-29 22:05:37 --> Model Class Initialized
DEBUG - 2019-06-29 16:05:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 22:05:37 --> Model Class Initialized
INFO - 2019-06-29 16:05:37 --> Input Class Initialized
INFO - 2019-06-29 22:05:37 --> Final output sent to browser
DEBUG - 2019-06-29 22:05:37 --> Total execution time: 0.7625
INFO - 2019-06-29 16:05:37 --> Language Class Initialized
INFO - 2019-06-29 16:05:37 --> Language Class Initialized
INFO - 2019-06-29 16:05:37 --> Config Class Initialized
INFO - 2019-06-29 16:05:37 --> Loader Class Initialized
DEBUG - 2019-06-29 16:05:37 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 16:05:37 --> Helper loaded: url_helper
INFO - 2019-06-29 16:05:37 --> Helper loaded: inflector_helper
INFO - 2019-06-29 16:05:37 --> Helper loaded: string_helper
INFO - 2019-06-29 16:05:37 --> Helper loaded: array_helper
INFO - 2019-06-29 16:05:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 16:05:37 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 16:05:37 --> Database Driver Class Initialized
INFO - 2019-06-29 16:05:37 --> Controller Class Initialized
INFO - 2019-06-29 22:05:37 --> Helper loaded: language_helper
INFO - 2019-06-29 22:05:37 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 22:05:37 --> Model Class Initialized
INFO - 2019-06-29 22:05:37 --> Model Class Initialized
INFO - 2019-06-29 22:05:37 --> Model Class Initialized
INFO - 2019-06-29 22:05:37 --> Model Class Initialized
INFO - 2019-06-29 22:05:37 --> Model Class Initialized
INFO - 2019-06-29 22:05:37 --> Final output sent to browser
DEBUG - 2019-06-29 22:05:38 --> Total execution time: 0.6902
INFO - 2019-06-29 16:05:51 --> Config Class Initialized
INFO - 2019-06-29 16:05:51 --> Hooks Class Initialized
DEBUG - 2019-06-29 16:05:51 --> UTF-8 Support Enabled
INFO - 2019-06-29 16:05:51 --> Utf8 Class Initialized
INFO - 2019-06-29 16:05:51 --> URI Class Initialized
INFO - 2019-06-29 16:05:51 --> Router Class Initialized
INFO - 2019-06-29 16:05:51 --> Output Class Initialized
INFO - 2019-06-29 16:05:51 --> Security Class Initialized
DEBUG - 2019-06-29 16:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 16:05:51 --> Input Class Initialized
INFO - 2019-06-29 16:05:51 --> Language Class Initialized
INFO - 2019-06-29 16:05:51 --> Language Class Initialized
INFO - 2019-06-29 16:05:51 --> Config Class Initialized
INFO - 2019-06-29 16:05:51 --> Loader Class Initialized
DEBUG - 2019-06-29 16:05:51 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 16:05:51 --> Helper loaded: url_helper
INFO - 2019-06-29 16:05:51 --> Helper loaded: inflector_helper
INFO - 2019-06-29 16:05:51 --> Helper loaded: string_helper
INFO - 2019-06-29 16:05:51 --> Helper loaded: array_helper
INFO - 2019-06-29 16:05:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 16:05:51 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 16:05:51 --> Database Driver Class Initialized
INFO - 2019-06-29 16:05:51 --> Controller Class Initialized
INFO - 2019-06-29 22:05:51 --> Helper loaded: language_helper
INFO - 2019-06-29 22:05:51 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 22:05:51 --> Model Class Initialized
INFO - 2019-06-29 22:05:51 --> Model Class Initialized
INFO - 2019-06-29 22:05:51 --> Model Class Initialized
INFO - 2019-06-29 22:05:51 --> Model Class Initialized
INFO - 2019-06-29 22:05:51 --> Helper loaded: form_helper
INFO - 2019-06-29 22:05:51 --> Form Validation Class Initialized
DEBUG - 2019-06-29 22:05:51 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-29 22:05:51 --> Model Class Initialized
INFO - 2019-06-29 22:05:51 --> Model Class Initialized
INFO - 2019-06-29 22:05:51 --> Final output sent to browser
DEBUG - 2019-06-29 22:05:51 --> Total execution time: 0.4632
INFO - 2019-06-29 16:07:45 --> Config Class Initialized
INFO - 2019-06-29 16:07:45 --> Hooks Class Initialized
DEBUG - 2019-06-29 16:07:45 --> UTF-8 Support Enabled
INFO - 2019-06-29 16:07:45 --> Utf8 Class Initialized
INFO - 2019-06-29 16:07:45 --> URI Class Initialized
INFO - 2019-06-29 16:07:45 --> Router Class Initialized
INFO - 2019-06-29 16:07:45 --> Output Class Initialized
INFO - 2019-06-29 16:07:45 --> Security Class Initialized
DEBUG - 2019-06-29 16:07:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 16:07:45 --> Input Class Initialized
INFO - 2019-06-29 16:07:45 --> Language Class Initialized
INFO - 2019-06-29 16:07:45 --> Language Class Initialized
INFO - 2019-06-29 16:07:45 --> Config Class Initialized
INFO - 2019-06-29 16:07:45 --> Loader Class Initialized
DEBUG - 2019-06-29 16:07:45 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 16:07:45 --> Helper loaded: url_helper
INFO - 2019-06-29 16:07:45 --> Helper loaded: inflector_helper
INFO - 2019-06-29 16:07:45 --> Helper loaded: string_helper
INFO - 2019-06-29 16:07:45 --> Helper loaded: array_helper
INFO - 2019-06-29 16:07:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 16:07:45 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 16:07:45 --> Database Driver Class Initialized
INFO - 2019-06-29 16:07:45 --> Controller Class Initialized
INFO - 2019-06-29 22:07:45 --> Helper loaded: language_helper
INFO - 2019-06-29 22:07:45 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 22:07:45 --> Model Class Initialized
INFO - 2019-06-29 22:07:45 --> Model Class Initialized
INFO - 2019-06-29 22:07:45 --> Model Class Initialized
INFO - 2019-06-29 22:07:45 --> Model Class Initialized
INFO - 2019-06-29 22:07:45 --> Helper loaded: form_helper
INFO - 2019-06-29 22:07:45 --> Form Validation Class Initialized
DEBUG - 2019-06-29 22:07:45 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-29 22:07:45 --> Model Class Initialized
INFO - 2019-06-29 22:07:45 --> Model Class Initialized
INFO - 2019-06-29 22:07:45 --> Final output sent to browser
DEBUG - 2019-06-29 22:07:45 --> Total execution time: 0.4609
INFO - 2019-06-29 16:07:50 --> Config Class Initialized
INFO - 2019-06-29 16:07:50 --> Hooks Class Initialized
DEBUG - 2019-06-29 16:07:50 --> UTF-8 Support Enabled
INFO - 2019-06-29 16:07:50 --> Utf8 Class Initialized
INFO - 2019-06-29 16:07:50 --> URI Class Initialized
INFO - 2019-06-29 16:07:50 --> Router Class Initialized
INFO - 2019-06-29 16:07:50 --> Output Class Initialized
INFO - 2019-06-29 16:07:50 --> Security Class Initialized
DEBUG - 2019-06-29 16:07:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 16:07:50 --> Input Class Initialized
INFO - 2019-06-29 16:07:50 --> Language Class Initialized
INFO - 2019-06-29 16:07:50 --> Language Class Initialized
INFO - 2019-06-29 16:07:50 --> Config Class Initialized
INFO - 2019-06-29 16:07:50 --> Loader Class Initialized
DEBUG - 2019-06-29 16:07:50 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 16:07:50 --> Helper loaded: url_helper
INFO - 2019-06-29 16:07:50 --> Helper loaded: inflector_helper
INFO - 2019-06-29 16:07:50 --> Helper loaded: string_helper
INFO - 2019-06-29 16:07:50 --> Helper loaded: array_helper
INFO - 2019-06-29 16:07:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 16:07:50 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 16:07:50 --> Database Driver Class Initialized
INFO - 2019-06-29 16:07:50 --> Controller Class Initialized
INFO - 2019-06-29 22:07:50 --> Helper loaded: language_helper
INFO - 2019-06-29 22:07:50 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 22:07:50 --> Model Class Initialized
INFO - 2019-06-29 22:07:50 --> Model Class Initialized
INFO - 2019-06-29 22:07:50 --> Model Class Initialized
INFO - 2019-06-29 22:07:50 --> Model Class Initialized
INFO - 2019-06-29 22:07:50 --> Model Class Initialized
ERROR - 2019-06-29 22:07:50 --> Query error: Unknown column 'resto_id' in 'where clause' - Invalid query: SELECT * FROM products WHERE resto_id = "8" ORDER BY products.id DESC
INFO - 2019-06-29 22:07:50 --> Language file loaded: language/english/db_lang.php
INFO - 2019-06-29 16:08:04 --> Config Class Initialized
INFO - 2019-06-29 16:08:04 --> Hooks Class Initialized
DEBUG - 2019-06-29 16:08:04 --> UTF-8 Support Enabled
INFO - 2019-06-29 16:08:04 --> Utf8 Class Initialized
INFO - 2019-06-29 16:08:04 --> URI Class Initialized
INFO - 2019-06-29 16:08:04 --> Router Class Initialized
INFO - 2019-06-29 16:08:04 --> Output Class Initialized
INFO - 2019-06-29 16:08:04 --> Security Class Initialized
DEBUG - 2019-06-29 16:08:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 16:08:04 --> Input Class Initialized
INFO - 2019-06-29 16:08:04 --> Language Class Initialized
INFO - 2019-06-29 16:08:04 --> Language Class Initialized
INFO - 2019-06-29 16:08:04 --> Config Class Initialized
INFO - 2019-06-29 16:08:04 --> Loader Class Initialized
DEBUG - 2019-06-29 16:08:04 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 16:08:04 --> Helper loaded: url_helper
INFO - 2019-06-29 16:08:04 --> Helper loaded: inflector_helper
INFO - 2019-06-29 16:08:04 --> Helper loaded: string_helper
INFO - 2019-06-29 16:08:04 --> Helper loaded: array_helper
INFO - 2019-06-29 16:08:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 16:08:04 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 16:08:04 --> Database Driver Class Initialized
INFO - 2019-06-29 16:08:04 --> Controller Class Initialized
INFO - 2019-06-29 22:08:04 --> Helper loaded: language_helper
INFO - 2019-06-29 22:08:04 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 22:08:04 --> Model Class Initialized
INFO - 2019-06-29 22:08:04 --> Model Class Initialized
INFO - 2019-06-29 22:08:04 --> Model Class Initialized
INFO - 2019-06-29 22:08:04 --> Model Class Initialized
INFO - 2019-06-29 22:08:04 --> Final output sent to browser
DEBUG - 2019-06-29 22:08:04 --> Total execution time: 0.5318
INFO - 2019-06-29 16:08:05 --> Config Class Initialized
INFO - 2019-06-29 16:08:05 --> Hooks Class Initialized
DEBUG - 2019-06-29 16:08:05 --> UTF-8 Support Enabled
INFO - 2019-06-29 16:08:05 --> Utf8 Class Initialized
INFO - 2019-06-29 16:08:05 --> URI Class Initialized
INFO - 2019-06-29 16:08:05 --> Router Class Initialized
INFO - 2019-06-29 16:08:05 --> Output Class Initialized
INFO - 2019-06-29 16:08:05 --> Security Class Initialized
DEBUG - 2019-06-29 16:08:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 16:08:05 --> Input Class Initialized
INFO - 2019-06-29 16:08:05 --> Language Class Initialized
INFO - 2019-06-29 16:08:05 --> Language Class Initialized
INFO - 2019-06-29 16:08:05 --> Config Class Initialized
INFO - 2019-06-29 16:08:05 --> Loader Class Initialized
DEBUG - 2019-06-29 16:08:05 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 16:08:05 --> Helper loaded: url_helper
INFO - 2019-06-29 16:08:05 --> Helper loaded: inflector_helper
INFO - 2019-06-29 16:08:05 --> Helper loaded: string_helper
INFO - 2019-06-29 16:08:05 --> Helper loaded: array_helper
INFO - 2019-06-29 16:08:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 16:08:05 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 16:08:05 --> Database Driver Class Initialized
INFO - 2019-06-29 16:08:05 --> Controller Class Initialized
INFO - 2019-06-29 22:08:05 --> Helper loaded: language_helper
INFO - 2019-06-29 22:08:05 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 22:08:05 --> Model Class Initialized
INFO - 2019-06-29 22:08:05 --> Model Class Initialized
INFO - 2019-06-29 22:08:05 --> Model Class Initialized
INFO - 2019-06-29 22:08:05 --> Model Class Initialized
INFO - 2019-06-29 22:08:05 --> Model Class Initialized
INFO - 2019-06-29 22:08:05 --> Final output sent to browser
DEBUG - 2019-06-29 22:08:05 --> Total execution time: 0.5358
INFO - 2019-06-29 16:08:08 --> Config Class Initialized
INFO - 2019-06-29 16:08:08 --> Hooks Class Initialized
DEBUG - 2019-06-29 16:08:08 --> UTF-8 Support Enabled
INFO - 2019-06-29 16:08:08 --> Utf8 Class Initialized
INFO - 2019-06-29 16:08:08 --> URI Class Initialized
INFO - 2019-06-29 16:08:08 --> Router Class Initialized
INFO - 2019-06-29 16:08:08 --> Output Class Initialized
INFO - 2019-06-29 16:08:08 --> Security Class Initialized
DEBUG - 2019-06-29 16:08:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 16:08:09 --> Input Class Initialized
INFO - 2019-06-29 16:08:09 --> Language Class Initialized
INFO - 2019-06-29 16:08:09 --> Language Class Initialized
INFO - 2019-06-29 16:08:09 --> Config Class Initialized
INFO - 2019-06-29 16:08:09 --> Loader Class Initialized
DEBUG - 2019-06-29 16:08:09 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 16:08:09 --> Helper loaded: url_helper
INFO - 2019-06-29 16:08:09 --> Helper loaded: inflector_helper
INFO - 2019-06-29 16:08:09 --> Helper loaded: string_helper
INFO - 2019-06-29 16:08:09 --> Helper loaded: array_helper
INFO - 2019-06-29 16:08:09 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 16:08:09 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 16:08:09 --> Database Driver Class Initialized
INFO - 2019-06-29 16:08:09 --> Controller Class Initialized
INFO - 2019-06-29 22:08:09 --> Helper loaded: language_helper
INFO - 2019-06-29 22:08:09 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 22:08:09 --> Model Class Initialized
INFO - 2019-06-29 22:08:09 --> Model Class Initialized
INFO - 2019-06-29 22:08:09 --> Model Class Initialized
INFO - 2019-06-29 22:08:09 --> Model Class Initialized
INFO - 2019-06-29 22:08:09 --> Helper loaded: form_helper
INFO - 2019-06-29 22:08:09 --> Form Validation Class Initialized
DEBUG - 2019-06-29 22:08:09 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-29 22:08:09 --> Model Class Initialized
INFO - 2019-06-29 22:08:09 --> Model Class Initialized
INFO - 2019-06-29 22:08:09 --> Final output sent to browser
DEBUG - 2019-06-29 22:08:09 --> Total execution time: 0.7883
INFO - 2019-06-29 16:08:12 --> Config Class Initialized
INFO - 2019-06-29 16:08:12 --> Hooks Class Initialized
DEBUG - 2019-06-29 16:08:12 --> UTF-8 Support Enabled
INFO - 2019-06-29 16:08:12 --> Utf8 Class Initialized
INFO - 2019-06-29 16:08:12 --> URI Class Initialized
INFO - 2019-06-29 16:08:12 --> Router Class Initialized
INFO - 2019-06-29 16:08:12 --> Output Class Initialized
INFO - 2019-06-29 16:08:12 --> Security Class Initialized
DEBUG - 2019-06-29 16:08:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 16:08:12 --> Input Class Initialized
INFO - 2019-06-29 16:08:12 --> Language Class Initialized
INFO - 2019-06-29 16:08:12 --> Language Class Initialized
INFO - 2019-06-29 16:08:12 --> Config Class Initialized
INFO - 2019-06-29 16:08:12 --> Loader Class Initialized
DEBUG - 2019-06-29 16:08:12 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 16:08:12 --> Helper loaded: url_helper
INFO - 2019-06-29 16:08:12 --> Helper loaded: inflector_helper
INFO - 2019-06-29 16:08:12 --> Helper loaded: string_helper
INFO - 2019-06-29 16:08:12 --> Helper loaded: array_helper
INFO - 2019-06-29 16:08:12 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 16:08:12 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 16:08:12 --> Database Driver Class Initialized
INFO - 2019-06-29 16:08:12 --> Controller Class Initialized
INFO - 2019-06-29 22:08:12 --> Helper loaded: language_helper
INFO - 2019-06-29 22:08:12 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 22:08:12 --> Model Class Initialized
INFO - 2019-06-29 22:08:12 --> Model Class Initialized
INFO - 2019-06-29 22:08:12 --> Model Class Initialized
INFO - 2019-06-29 22:08:13 --> Model Class Initialized
INFO - 2019-06-29 22:08:13 --> Helper loaded: form_helper
INFO - 2019-06-29 22:08:13 --> Form Validation Class Initialized
DEBUG - 2019-06-29 22:08:13 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-29 22:08:13 --> Model Class Initialized
INFO - 2019-06-29 22:08:13 --> Model Class Initialized
INFO - 2019-06-29 22:08:13 --> Final output sent to browser
DEBUG - 2019-06-29 22:08:13 --> Total execution time: 0.4385
INFO - 2019-06-29 16:08:17 --> Config Class Initialized
INFO - 2019-06-29 16:08:17 --> Hooks Class Initialized
DEBUG - 2019-06-29 16:08:17 --> UTF-8 Support Enabled
INFO - 2019-06-29 16:08:17 --> Utf8 Class Initialized
INFO - 2019-06-29 16:08:17 --> URI Class Initialized
INFO - 2019-06-29 16:08:17 --> Router Class Initialized
INFO - 2019-06-29 16:08:17 --> Output Class Initialized
INFO - 2019-06-29 16:08:17 --> Security Class Initialized
DEBUG - 2019-06-29 16:08:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 16:08:17 --> Input Class Initialized
INFO - 2019-06-29 16:08:17 --> Language Class Initialized
INFO - 2019-06-29 16:08:17 --> Language Class Initialized
INFO - 2019-06-29 16:08:17 --> Config Class Initialized
INFO - 2019-06-29 16:08:17 --> Loader Class Initialized
DEBUG - 2019-06-29 16:08:17 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 16:08:17 --> Helper loaded: url_helper
INFO - 2019-06-29 16:08:17 --> Helper loaded: inflector_helper
INFO - 2019-06-29 16:08:17 --> Helper loaded: string_helper
INFO - 2019-06-29 16:08:17 --> Helper loaded: array_helper
INFO - 2019-06-29 16:08:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 16:08:17 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 16:08:17 --> Database Driver Class Initialized
INFO - 2019-06-29 16:08:17 --> Controller Class Initialized
INFO - 2019-06-29 22:08:17 --> Helper loaded: language_helper
INFO - 2019-06-29 22:08:17 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 22:08:17 --> Model Class Initialized
INFO - 2019-06-29 22:08:17 --> Model Class Initialized
INFO - 2019-06-29 22:08:17 --> Model Class Initialized
INFO - 2019-06-29 22:08:17 --> Model Class Initialized
INFO - 2019-06-29 22:08:17 --> Helper loaded: form_helper
INFO - 2019-06-29 22:08:17 --> Form Validation Class Initialized
DEBUG - 2019-06-29 22:08:17 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-29 22:08:17 --> Model Class Initialized
INFO - 2019-06-29 22:08:17 --> Model Class Initialized
INFO - 2019-06-29 22:08:17 --> Final output sent to browser
DEBUG - 2019-06-29 22:08:17 --> Total execution time: 0.4423
INFO - 2019-06-29 16:08:19 --> Config Class Initialized
INFO - 2019-06-29 16:08:19 --> Hooks Class Initialized
DEBUG - 2019-06-29 16:08:19 --> UTF-8 Support Enabled
INFO - 2019-06-29 16:08:19 --> Utf8 Class Initialized
INFO - 2019-06-29 16:08:19 --> URI Class Initialized
INFO - 2019-06-29 16:08:19 --> Router Class Initialized
INFO - 2019-06-29 16:08:19 --> Output Class Initialized
INFO - 2019-06-29 16:08:19 --> Security Class Initialized
DEBUG - 2019-06-29 16:08:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 16:08:19 --> Input Class Initialized
INFO - 2019-06-29 16:08:19 --> Language Class Initialized
INFO - 2019-06-29 16:08:19 --> Language Class Initialized
INFO - 2019-06-29 16:08:19 --> Config Class Initialized
INFO - 2019-06-29 16:08:19 --> Loader Class Initialized
DEBUG - 2019-06-29 16:08:19 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 16:08:19 --> Helper loaded: url_helper
INFO - 2019-06-29 16:08:19 --> Helper loaded: inflector_helper
INFO - 2019-06-29 16:08:19 --> Helper loaded: string_helper
INFO - 2019-06-29 16:08:19 --> Helper loaded: array_helper
INFO - 2019-06-29 16:08:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 16:08:20 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 16:08:20 --> Database Driver Class Initialized
INFO - 2019-06-29 16:08:20 --> Controller Class Initialized
INFO - 2019-06-29 22:08:20 --> Helper loaded: language_helper
INFO - 2019-06-29 22:08:20 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 22:08:20 --> Model Class Initialized
INFO - 2019-06-29 22:08:20 --> Model Class Initialized
INFO - 2019-06-29 22:08:20 --> Model Class Initialized
INFO - 2019-06-29 22:08:20 --> Model Class Initialized
INFO - 2019-06-29 22:08:20 --> Model Class Initialized
ERROR - 2019-06-29 22:08:20 --> Query error: Unknown column 'resto_id' in 'where clause' - Invalid query: SELECT * FROM products WHERE resto_id = "1" ORDER BY products.id DESC
INFO - 2019-06-29 22:08:20 --> Language file loaded: language/english/db_lang.php
INFO - 2019-06-29 16:11:28 --> Config Class Initialized
INFO - 2019-06-29 16:11:28 --> Hooks Class Initialized
DEBUG - 2019-06-29 16:11:28 --> UTF-8 Support Enabled
INFO - 2019-06-29 16:11:28 --> Utf8 Class Initialized
INFO - 2019-06-29 16:11:28 --> URI Class Initialized
INFO - 2019-06-29 16:11:28 --> Router Class Initialized
INFO - 2019-06-29 16:11:28 --> Output Class Initialized
INFO - 2019-06-29 16:11:28 --> Security Class Initialized
DEBUG - 2019-06-29 16:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 16:11:29 --> Input Class Initialized
INFO - 2019-06-29 16:11:29 --> Language Class Initialized
INFO - 2019-06-29 16:11:29 --> Language Class Initialized
INFO - 2019-06-29 16:11:29 --> Config Class Initialized
INFO - 2019-06-29 16:11:29 --> Loader Class Initialized
DEBUG - 2019-06-29 16:11:29 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 16:11:29 --> Helper loaded: url_helper
INFO - 2019-06-29 16:11:29 --> Helper loaded: inflector_helper
INFO - 2019-06-29 16:11:29 --> Helper loaded: string_helper
INFO - 2019-06-29 16:11:29 --> Helper loaded: array_helper
INFO - 2019-06-29 16:11:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 16:11:29 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 16:11:29 --> Database Driver Class Initialized
INFO - 2019-06-29 16:11:29 --> Controller Class Initialized
INFO - 2019-06-29 22:11:29 --> Helper loaded: language_helper
INFO - 2019-06-29 22:11:29 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 22:11:29 --> Model Class Initialized
INFO - 2019-06-29 22:11:29 --> Model Class Initialized
INFO - 2019-06-29 22:11:29 --> Model Class Initialized
INFO - 2019-06-29 22:11:29 --> Model Class Initialized
INFO - 2019-06-29 22:11:29 --> Helper loaded: form_helper
INFO - 2019-06-29 22:11:29 --> Form Validation Class Initialized
DEBUG - 2019-06-29 22:11:29 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-29 22:11:29 --> Model Class Initialized
INFO - 2019-06-29 22:11:29 --> Model Class Initialized
INFO - 2019-06-29 22:11:29 --> Final output sent to browser
INFO - 2019-06-29 16:11:29 --> Config Class Initialized
DEBUG - 2019-06-29 22:11:29 --> Total execution time: 1.0250
INFO - 2019-06-29 16:11:29 --> Hooks Class Initialized
DEBUG - 2019-06-29 16:11:29 --> UTF-8 Support Enabled
INFO - 2019-06-29 16:11:29 --> Utf8 Class Initialized
INFO - 2019-06-29 16:11:29 --> URI Class Initialized
INFO - 2019-06-29 16:11:29 --> Router Class Initialized
INFO - 2019-06-29 16:11:29 --> Output Class Initialized
INFO - 2019-06-29 16:11:29 --> Security Class Initialized
DEBUG - 2019-06-29 16:11:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 16:11:30 --> Input Class Initialized
INFO - 2019-06-29 16:11:30 --> Language Class Initialized
INFO - 2019-06-29 16:11:30 --> Language Class Initialized
INFO - 2019-06-29 16:11:30 --> Config Class Initialized
INFO - 2019-06-29 16:11:30 --> Loader Class Initialized
DEBUG - 2019-06-29 16:11:30 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 16:11:30 --> Helper loaded: url_helper
INFO - 2019-06-29 16:11:30 --> Helper loaded: inflector_helper
INFO - 2019-06-29 16:11:30 --> Helper loaded: string_helper
INFO - 2019-06-29 16:11:30 --> Helper loaded: array_helper
INFO - 2019-06-29 16:11:30 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 16:11:30 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 16:11:30 --> Database Driver Class Initialized
INFO - 2019-06-29 16:11:30 --> Controller Class Initialized
INFO - 2019-06-29 22:11:30 --> Helper loaded: language_helper
INFO - 2019-06-29 22:11:30 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 22:11:30 --> Model Class Initialized
INFO - 2019-06-29 22:11:30 --> Model Class Initialized
INFO - 2019-06-29 22:11:30 --> Model Class Initialized
INFO - 2019-06-29 22:11:30 --> Model Class Initialized
INFO - 2019-06-29 22:11:30 --> Model Class Initialized
INFO - 2019-06-29 22:11:30 --> Final output sent to browser
DEBUG - 2019-06-29 22:11:30 --> Total execution time: 0.6877
INFO - 2019-06-29 16:11:41 --> Config Class Initialized
INFO - 2019-06-29 16:11:41 --> Hooks Class Initialized
DEBUG - 2019-06-29 16:11:41 --> UTF-8 Support Enabled
INFO - 2019-06-29 16:11:41 --> Utf8 Class Initialized
INFO - 2019-06-29 16:11:41 --> URI Class Initialized
INFO - 2019-06-29 16:11:41 --> Router Class Initialized
INFO - 2019-06-29 16:11:41 --> Output Class Initialized
INFO - 2019-06-29 16:11:41 --> Security Class Initialized
DEBUG - 2019-06-29 16:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 16:11:41 --> Input Class Initialized
INFO - 2019-06-29 16:11:41 --> Language Class Initialized
INFO - 2019-06-29 16:11:41 --> Language Class Initialized
INFO - 2019-06-29 16:11:41 --> Config Class Initialized
INFO - 2019-06-29 16:11:41 --> Loader Class Initialized
DEBUG - 2019-06-29 16:11:41 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 16:11:41 --> Helper loaded: url_helper
INFO - 2019-06-29 16:11:41 --> Helper loaded: inflector_helper
INFO - 2019-06-29 16:11:41 --> Helper loaded: string_helper
INFO - 2019-06-29 16:11:41 --> Helper loaded: array_helper
INFO - 2019-06-29 16:11:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 16:11:41 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 16:11:41 --> Database Driver Class Initialized
INFO - 2019-06-29 16:11:41 --> Controller Class Initialized
INFO - 2019-06-29 22:11:41 --> Helper loaded: language_helper
INFO - 2019-06-29 22:11:41 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 22:11:41 --> Model Class Initialized
INFO - 2019-06-29 22:11:41 --> Model Class Initialized
INFO - 2019-06-29 22:11:41 --> Model Class Initialized
INFO - 2019-06-29 22:11:41 --> Model Class Initialized
INFO - 2019-06-29 22:11:41 --> Helper loaded: form_helper
INFO - 2019-06-29 22:11:41 --> Form Validation Class Initialized
DEBUG - 2019-06-29 22:11:41 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-29 22:11:41 --> Model Class Initialized
INFO - 2019-06-29 22:11:41 --> Model Class Initialized
INFO - 2019-06-29 22:11:41 --> Final output sent to browser
DEBUG - 2019-06-29 22:11:41 --> Total execution time: 0.5269
INFO - 2019-06-29 16:12:28 --> Config Class Initialized
INFO - 2019-06-29 16:12:28 --> Hooks Class Initialized
DEBUG - 2019-06-29 16:12:29 --> UTF-8 Support Enabled
INFO - 2019-06-29 16:12:29 --> Utf8 Class Initialized
INFO - 2019-06-29 16:12:29 --> URI Class Initialized
INFO - 2019-06-29 16:12:29 --> Router Class Initialized
INFO - 2019-06-29 16:12:29 --> Output Class Initialized
INFO - 2019-06-29 16:12:29 --> Security Class Initialized
DEBUG - 2019-06-29 16:12:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 16:12:29 --> Input Class Initialized
INFO - 2019-06-29 16:12:29 --> Language Class Initialized
INFO - 2019-06-29 16:12:29 --> Language Class Initialized
INFO - 2019-06-29 16:12:29 --> Config Class Initialized
INFO - 2019-06-29 16:12:29 --> Loader Class Initialized
DEBUG - 2019-06-29 16:12:29 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 16:12:29 --> Helper loaded: url_helper
INFO - 2019-06-29 16:12:29 --> Helper loaded: inflector_helper
INFO - 2019-06-29 16:12:29 --> Helper loaded: string_helper
INFO - 2019-06-29 16:12:29 --> Helper loaded: array_helper
INFO - 2019-06-29 16:12:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 16:12:29 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 16:12:29 --> Database Driver Class Initialized
INFO - 2019-06-29 16:12:29 --> Controller Class Initialized
INFO - 2019-06-29 22:12:29 --> Helper loaded: language_helper
INFO - 2019-06-29 22:12:29 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 22:12:29 --> Model Class Initialized
INFO - 2019-06-29 22:12:29 --> Model Class Initialized
INFO - 2019-06-29 22:12:29 --> Model Class Initialized
INFO - 2019-06-29 22:12:29 --> Model Class Initialized
INFO - 2019-06-29 22:12:29 --> Helper loaded: form_helper
INFO - 2019-06-29 22:12:29 --> Form Validation Class Initialized
DEBUG - 2019-06-29 22:12:29 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-29 22:12:29 --> Model Class Initialized
INFO - 2019-06-29 22:12:29 --> Model Class Initialized
INFO - 2019-06-29 22:12:29 --> Final output sent to browser
DEBUG - 2019-06-29 22:12:29 --> Total execution time: 0.5875
INFO - 2019-06-29 16:12:51 --> Config Class Initialized
INFO - 2019-06-29 16:12:51 --> Hooks Class Initialized
DEBUG - 2019-06-29 16:12:51 --> UTF-8 Support Enabled
INFO - 2019-06-29 16:12:51 --> Utf8 Class Initialized
INFO - 2019-06-29 16:12:51 --> URI Class Initialized
INFO - 2019-06-29 16:12:51 --> Router Class Initialized
INFO - 2019-06-29 16:12:51 --> Output Class Initialized
INFO - 2019-06-29 16:12:51 --> Security Class Initialized
DEBUG - 2019-06-29 16:12:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 16:12:51 --> Input Class Initialized
INFO - 2019-06-29 16:12:51 --> Language Class Initialized
INFO - 2019-06-29 16:12:51 --> Language Class Initialized
INFO - 2019-06-29 16:12:51 --> Config Class Initialized
INFO - 2019-06-29 16:12:51 --> Loader Class Initialized
DEBUG - 2019-06-29 16:12:51 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 16:12:51 --> Helper loaded: url_helper
INFO - 2019-06-29 16:12:51 --> Helper loaded: inflector_helper
INFO - 2019-06-29 16:12:51 --> Helper loaded: string_helper
INFO - 2019-06-29 16:12:51 --> Helper loaded: array_helper
INFO - 2019-06-29 16:12:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 16:12:51 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 16:12:51 --> Database Driver Class Initialized
INFO - 2019-06-29 16:12:51 --> Controller Class Initialized
INFO - 2019-06-29 22:12:51 --> Helper loaded: language_helper
INFO - 2019-06-29 22:12:51 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 22:12:51 --> Model Class Initialized
INFO - 2019-06-29 22:12:51 --> Model Class Initialized
INFO - 2019-06-29 22:12:51 --> Model Class Initialized
INFO - 2019-06-29 22:12:51 --> Model Class Initialized
INFO - 2019-06-29 22:12:51 --> Helper loaded: form_helper
INFO - 2019-06-29 22:12:51 --> Form Validation Class Initialized
DEBUG - 2019-06-29 22:12:51 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-29 22:12:51 --> Model Class Initialized
INFO - 2019-06-29 22:12:51 --> Model Class Initialized
INFO - 2019-06-29 22:12:51 --> Final output sent to browser
DEBUG - 2019-06-29 22:12:51 --> Total execution time: 0.5359
INFO - 2019-06-29 16:13:01 --> Config Class Initialized
INFO - 2019-06-29 16:13:01 --> Hooks Class Initialized
DEBUG - 2019-06-29 16:13:01 --> UTF-8 Support Enabled
INFO - 2019-06-29 16:13:01 --> Utf8 Class Initialized
INFO - 2019-06-29 16:13:01 --> URI Class Initialized
INFO - 2019-06-29 16:13:01 --> Router Class Initialized
INFO - 2019-06-29 16:13:01 --> Output Class Initialized
INFO - 2019-06-29 16:13:01 --> Security Class Initialized
DEBUG - 2019-06-29 16:13:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 16:13:01 --> Input Class Initialized
INFO - 2019-06-29 16:13:01 --> Language Class Initialized
INFO - 2019-06-29 16:13:01 --> Language Class Initialized
INFO - 2019-06-29 16:13:01 --> Config Class Initialized
INFO - 2019-06-29 16:13:01 --> Loader Class Initialized
DEBUG - 2019-06-29 16:13:01 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 16:13:01 --> Helper loaded: url_helper
INFO - 2019-06-29 16:13:01 --> Helper loaded: inflector_helper
INFO - 2019-06-29 16:13:01 --> Helper loaded: string_helper
INFO - 2019-06-29 16:13:01 --> Helper loaded: array_helper
INFO - 2019-06-29 16:13:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 16:13:01 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 16:13:01 --> Database Driver Class Initialized
INFO - 2019-06-29 16:13:01 --> Controller Class Initialized
INFO - 2019-06-29 22:13:01 --> Helper loaded: language_helper
INFO - 2019-06-29 22:13:01 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 22:13:01 --> Model Class Initialized
INFO - 2019-06-29 22:13:01 --> Model Class Initialized
INFO - 2019-06-29 22:13:01 --> Model Class Initialized
INFO - 2019-06-29 22:13:01 --> Model Class Initialized
INFO - 2019-06-29 22:13:01 --> Helper loaded: form_helper
INFO - 2019-06-29 22:13:02 --> Form Validation Class Initialized
DEBUG - 2019-06-29 22:13:02 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-29 22:13:02 --> Model Class Initialized
INFO - 2019-06-29 22:13:02 --> Model Class Initialized
INFO - 2019-06-29 22:13:02 --> Final output sent to browser
DEBUG - 2019-06-29 22:13:02 --> Total execution time: 0.6811
INFO - 2019-06-29 16:14:22 --> Config Class Initialized
INFO - 2019-06-29 16:14:22 --> Hooks Class Initialized
DEBUG - 2019-06-29 16:14:22 --> UTF-8 Support Enabled
INFO - 2019-06-29 16:14:22 --> Utf8 Class Initialized
INFO - 2019-06-29 16:14:22 --> URI Class Initialized
INFO - 2019-06-29 16:14:22 --> Router Class Initialized
INFO - 2019-06-29 16:14:22 --> Output Class Initialized
INFO - 2019-06-29 16:14:22 --> Security Class Initialized
DEBUG - 2019-06-29 16:14:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 16:14:22 --> Input Class Initialized
INFO - 2019-06-29 16:14:22 --> Language Class Initialized
INFO - 2019-06-29 16:14:22 --> Language Class Initialized
INFO - 2019-06-29 16:14:22 --> Config Class Initialized
INFO - 2019-06-29 16:14:22 --> Loader Class Initialized
DEBUG - 2019-06-29 16:14:22 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 16:14:22 --> Helper loaded: url_helper
INFO - 2019-06-29 16:14:22 --> Helper loaded: inflector_helper
INFO - 2019-06-29 16:14:22 --> Helper loaded: string_helper
INFO - 2019-06-29 16:14:22 --> Helper loaded: array_helper
INFO - 2019-06-29 16:14:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 16:14:23 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 16:14:23 --> Database Driver Class Initialized
INFO - 2019-06-29 16:14:23 --> Controller Class Initialized
INFO - 2019-06-29 22:14:23 --> Helper loaded: language_helper
INFO - 2019-06-29 22:14:23 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 22:14:23 --> Model Class Initialized
INFO - 2019-06-29 22:14:23 --> Model Class Initialized
INFO - 2019-06-29 22:14:23 --> Model Class Initialized
INFO - 2019-06-29 22:14:23 --> Model Class Initialized
INFO - 2019-06-29 22:14:23 --> Helper loaded: form_helper
INFO - 2019-06-29 22:14:23 --> Form Validation Class Initialized
DEBUG - 2019-06-29 22:14:23 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-29 22:14:23 --> Model Class Initialized
INFO - 2019-06-29 22:14:23 --> Model Class Initialized
INFO - 2019-06-29 22:14:23 --> Final output sent to browser
DEBUG - 2019-06-29 22:14:23 --> Total execution time: 0.9981
INFO - 2019-06-29 16:14:23 --> Config Class Initialized
INFO - 2019-06-29 16:14:23 --> Hooks Class Initialized
DEBUG - 2019-06-29 16:14:23 --> UTF-8 Support Enabled
INFO - 2019-06-29 16:14:23 --> Utf8 Class Initialized
INFO - 2019-06-29 16:14:23 --> URI Class Initialized
INFO - 2019-06-29 16:14:23 --> Router Class Initialized
INFO - 2019-06-29 16:14:23 --> Output Class Initialized
INFO - 2019-06-29 16:14:23 --> Security Class Initialized
DEBUG - 2019-06-29 16:14:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 16:14:23 --> Input Class Initialized
INFO - 2019-06-29 16:14:23 --> Language Class Initialized
INFO - 2019-06-29 16:14:23 --> Language Class Initialized
INFO - 2019-06-29 16:14:23 --> Config Class Initialized
INFO - 2019-06-29 16:14:23 --> Loader Class Initialized
DEBUG - 2019-06-29 16:14:23 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 16:14:24 --> Helper loaded: url_helper
INFO - 2019-06-29 16:14:24 --> Helper loaded: inflector_helper
INFO - 2019-06-29 16:14:24 --> Helper loaded: string_helper
INFO - 2019-06-29 16:14:24 --> Helper loaded: array_helper
INFO - 2019-06-29 16:14:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 16:14:24 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 16:14:24 --> Database Driver Class Initialized
INFO - 2019-06-29 16:14:24 --> Controller Class Initialized
INFO - 2019-06-29 22:14:24 --> Helper loaded: language_helper
INFO - 2019-06-29 22:14:24 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 22:14:24 --> Model Class Initialized
INFO - 2019-06-29 22:14:24 --> Model Class Initialized
INFO - 2019-06-29 22:14:24 --> Model Class Initialized
INFO - 2019-06-29 22:14:24 --> Model Class Initialized
INFO - 2019-06-29 22:14:24 --> Helper loaded: form_helper
INFO - 2019-06-29 22:14:24 --> Form Validation Class Initialized
DEBUG - 2019-06-29 22:14:24 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-29 22:14:24 --> Model Class Initialized
INFO - 2019-06-29 22:14:24 --> Model Class Initialized
INFO - 2019-06-29 22:14:24 --> Final output sent to browser
DEBUG - 2019-06-29 22:14:24 --> Total execution time: 0.7108
INFO - 2019-06-29 16:14:31 --> Config Class Initialized
INFO - 2019-06-29 16:14:31 --> Hooks Class Initialized
DEBUG - 2019-06-29 16:14:31 --> UTF-8 Support Enabled
INFO - 2019-06-29 16:14:31 --> Utf8 Class Initialized
INFO - 2019-06-29 16:14:31 --> URI Class Initialized
INFO - 2019-06-29 16:14:31 --> Router Class Initialized
INFO - 2019-06-29 16:14:31 --> Output Class Initialized
INFO - 2019-06-29 16:14:31 --> Security Class Initialized
DEBUG - 2019-06-29 16:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 16:14:31 --> Input Class Initialized
INFO - 2019-06-29 16:14:31 --> Language Class Initialized
INFO - 2019-06-29 16:14:31 --> Language Class Initialized
INFO - 2019-06-29 16:14:31 --> Config Class Initialized
INFO - 2019-06-29 16:14:31 --> Loader Class Initialized
DEBUG - 2019-06-29 16:14:31 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 16:14:31 --> Helper loaded: url_helper
INFO - 2019-06-29 16:14:31 --> Helper loaded: inflector_helper
INFO - 2019-06-29 16:14:31 --> Helper loaded: string_helper
INFO - 2019-06-29 16:14:31 --> Helper loaded: array_helper
INFO - 2019-06-29 16:14:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 16:14:31 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 16:14:32 --> Database Driver Class Initialized
INFO - 2019-06-29 16:14:32 --> Controller Class Initialized
INFO - 2019-06-29 22:14:32 --> Helper loaded: language_helper
INFO - 2019-06-29 22:14:32 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 22:14:32 --> Model Class Initialized
INFO - 2019-06-29 22:14:32 --> Model Class Initialized
INFO - 2019-06-29 22:14:32 --> Model Class Initialized
INFO - 2019-06-29 22:14:32 --> Model Class Initialized
INFO - 2019-06-29 22:14:32 --> Helper loaded: form_helper
INFO - 2019-06-29 22:14:32 --> Form Validation Class Initialized
DEBUG - 2019-06-29 22:14:32 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-29 22:14:32 --> Model Class Initialized
INFO - 2019-06-29 22:14:32 --> Model Class Initialized
INFO - 2019-06-29 22:14:32 --> Final output sent to browser
DEBUG - 2019-06-29 22:14:32 --> Total execution time: 0.7484
INFO - 2019-06-29 16:14:32 --> Config Class Initialized
INFO - 2019-06-29 16:14:32 --> Hooks Class Initialized
DEBUG - 2019-06-29 16:14:32 --> UTF-8 Support Enabled
INFO - 2019-06-29 16:14:32 --> Utf8 Class Initialized
INFO - 2019-06-29 16:14:32 --> URI Class Initialized
INFO - 2019-06-29 16:14:32 --> Router Class Initialized
INFO - 2019-06-29 16:14:32 --> Output Class Initialized
INFO - 2019-06-29 16:14:32 --> Security Class Initialized
DEBUG - 2019-06-29 16:14:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 16:14:32 --> Input Class Initialized
INFO - 2019-06-29 16:14:32 --> Language Class Initialized
INFO - 2019-06-29 16:14:32 --> Language Class Initialized
INFO - 2019-06-29 16:14:32 --> Config Class Initialized
INFO - 2019-06-29 16:14:32 --> Loader Class Initialized
DEBUG - 2019-06-29 16:14:32 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 16:14:32 --> Helper loaded: url_helper
INFO - 2019-06-29 16:14:32 --> Helper loaded: inflector_helper
INFO - 2019-06-29 16:14:32 --> Helper loaded: string_helper
INFO - 2019-06-29 16:14:32 --> Helper loaded: array_helper
INFO - 2019-06-29 16:14:32 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 16:14:32 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 16:14:32 --> Database Driver Class Initialized
INFO - 2019-06-29 16:14:32 --> Controller Class Initialized
INFO - 2019-06-29 22:14:32 --> Helper loaded: language_helper
INFO - 2019-06-29 22:14:32 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 22:14:32 --> Model Class Initialized
INFO - 2019-06-29 22:14:32 --> Model Class Initialized
INFO - 2019-06-29 22:14:32 --> Model Class Initialized
INFO - 2019-06-29 22:14:32 --> Model Class Initialized
INFO - 2019-06-29 22:14:32 --> Model Class Initialized
INFO - 2019-06-29 22:14:32 --> Final output sent to browser
DEBUG - 2019-06-29 22:14:32 --> Total execution time: 0.6095
INFO - 2019-06-29 16:14:39 --> Config Class Initialized
INFO - 2019-06-29 16:14:39 --> Hooks Class Initialized
DEBUG - 2019-06-29 16:14:39 --> UTF-8 Support Enabled
INFO - 2019-06-29 16:14:39 --> Utf8 Class Initialized
INFO - 2019-06-29 16:14:39 --> URI Class Initialized
INFO - 2019-06-29 16:14:39 --> Router Class Initialized
INFO - 2019-06-29 16:14:39 --> Output Class Initialized
INFO - 2019-06-29 16:14:39 --> Security Class Initialized
DEBUG - 2019-06-29 16:14:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 16:14:39 --> Input Class Initialized
INFO - 2019-06-29 16:14:39 --> Language Class Initialized
INFO - 2019-06-29 16:14:39 --> Language Class Initialized
INFO - 2019-06-29 16:14:39 --> Config Class Initialized
INFO - 2019-06-29 16:14:39 --> Loader Class Initialized
DEBUG - 2019-06-29 16:14:39 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 16:14:39 --> Helper loaded: url_helper
INFO - 2019-06-29 16:14:39 --> Helper loaded: inflector_helper
INFO - 2019-06-29 16:14:39 --> Helper loaded: string_helper
INFO - 2019-06-29 16:14:39 --> Helper loaded: array_helper
INFO - 2019-06-29 16:14:39 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 16:14:39 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 16:14:39 --> Database Driver Class Initialized
INFO - 2019-06-29 16:14:39 --> Controller Class Initialized
INFO - 2019-06-29 22:14:39 --> Helper loaded: language_helper
INFO - 2019-06-29 22:14:39 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 22:14:39 --> Model Class Initialized
INFO - 2019-06-29 22:14:39 --> Model Class Initialized
INFO - 2019-06-29 22:14:39 --> Model Class Initialized
INFO - 2019-06-29 22:14:39 --> Model Class Initialized
INFO - 2019-06-29 22:14:39 --> Helper loaded: form_helper
INFO - 2019-06-29 22:14:39 --> Form Validation Class Initialized
DEBUG - 2019-06-29 22:14:39 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-29 22:14:39 --> Model Class Initialized
INFO - 2019-06-29 22:14:39 --> Model Class Initialized
INFO - 2019-06-29 22:14:40 --> Final output sent to browser
DEBUG - 2019-06-29 22:14:40 --> Total execution time: 0.7573
INFO - 2019-06-29 16:15:00 --> Config Class Initialized
INFO - 2019-06-29 16:15:00 --> Hooks Class Initialized
DEBUG - 2019-06-29 16:15:00 --> UTF-8 Support Enabled
INFO - 2019-06-29 16:15:00 --> Utf8 Class Initialized
INFO - 2019-06-29 16:15:00 --> URI Class Initialized
INFO - 2019-06-29 16:15:00 --> Router Class Initialized
INFO - 2019-06-29 16:15:00 --> Output Class Initialized
INFO - 2019-06-29 16:15:00 --> Security Class Initialized
DEBUG - 2019-06-29 16:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 16:15:00 --> Input Class Initialized
INFO - 2019-06-29 16:15:01 --> Language Class Initialized
INFO - 2019-06-29 16:15:01 --> Language Class Initialized
INFO - 2019-06-29 16:15:01 --> Config Class Initialized
INFO - 2019-06-29 16:15:01 --> Loader Class Initialized
DEBUG - 2019-06-29 16:15:01 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 16:15:01 --> Helper loaded: url_helper
INFO - 2019-06-29 16:15:01 --> Helper loaded: inflector_helper
INFO - 2019-06-29 16:15:01 --> Helper loaded: string_helper
INFO - 2019-06-29 16:15:01 --> Helper loaded: array_helper
INFO - 2019-06-29 16:15:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 16:15:01 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 16:15:01 --> Database Driver Class Initialized
INFO - 2019-06-29 16:15:01 --> Controller Class Initialized
INFO - 2019-06-29 22:15:01 --> Helper loaded: language_helper
INFO - 2019-06-29 22:15:01 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 22:15:01 --> Model Class Initialized
INFO - 2019-06-29 22:15:01 --> Model Class Initialized
INFO - 2019-06-29 22:15:01 --> Model Class Initialized
INFO - 2019-06-29 22:15:01 --> Model Class Initialized
INFO - 2019-06-29 22:15:01 --> Helper loaded: form_helper
INFO - 2019-06-29 22:15:01 --> Form Validation Class Initialized
DEBUG - 2019-06-29 22:15:01 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-29 22:15:01 --> Model Class Initialized
INFO - 2019-06-29 22:15:01 --> Model Class Initialized
INFO - 2019-06-29 22:15:01 --> Final output sent to browser
DEBUG - 2019-06-29 22:15:01 --> Total execution time: 0.9062
INFO - 2019-06-29 16:15:03 --> Config Class Initialized
INFO - 2019-06-29 16:15:03 --> Hooks Class Initialized
DEBUG - 2019-06-29 16:15:03 --> UTF-8 Support Enabled
INFO - 2019-06-29 16:15:03 --> Utf8 Class Initialized
INFO - 2019-06-29 16:15:03 --> URI Class Initialized
INFO - 2019-06-29 16:15:03 --> Router Class Initialized
INFO - 2019-06-29 16:15:03 --> Output Class Initialized
INFO - 2019-06-29 16:15:03 --> Security Class Initialized
DEBUG - 2019-06-29 16:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 16:15:03 --> Input Class Initialized
INFO - 2019-06-29 16:15:04 --> Language Class Initialized
INFO - 2019-06-29 16:15:04 --> Language Class Initialized
INFO - 2019-06-29 16:15:04 --> Config Class Initialized
INFO - 2019-06-29 16:15:04 --> Loader Class Initialized
DEBUG - 2019-06-29 16:15:04 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 16:15:04 --> Helper loaded: url_helper
INFO - 2019-06-29 16:15:04 --> Helper loaded: inflector_helper
INFO - 2019-06-29 16:15:04 --> Helper loaded: string_helper
INFO - 2019-06-29 16:15:04 --> Helper loaded: array_helper
INFO - 2019-06-29 16:15:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 16:15:04 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 16:15:04 --> Database Driver Class Initialized
INFO - 2019-06-29 16:15:04 --> Controller Class Initialized
INFO - 2019-06-29 22:15:04 --> Helper loaded: language_helper
INFO - 2019-06-29 22:15:04 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 22:15:04 --> Model Class Initialized
INFO - 2019-06-29 22:15:04 --> Model Class Initialized
INFO - 2019-06-29 22:15:04 --> Model Class Initialized
INFO - 2019-06-29 22:15:04 --> Model Class Initialized
INFO - 2019-06-29 22:15:04 --> Helper loaded: form_helper
INFO - 2019-06-29 22:15:04 --> Form Validation Class Initialized
DEBUG - 2019-06-29 22:15:04 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-29 22:15:04 --> Model Class Initialized
INFO - 2019-06-29 22:15:04 --> Model Class Initialized
INFO - 2019-06-29 22:15:04 --> Final output sent to browser
DEBUG - 2019-06-29 22:15:04 --> Total execution time: 0.7370
INFO - 2019-06-29 16:15:43 --> Config Class Initialized
INFO - 2019-06-29 16:15:43 --> Hooks Class Initialized
DEBUG - 2019-06-29 16:15:43 --> UTF-8 Support Enabled
INFO - 2019-06-29 16:15:43 --> Utf8 Class Initialized
INFO - 2019-06-29 16:15:43 --> URI Class Initialized
INFO - 2019-06-29 16:15:43 --> Router Class Initialized
INFO - 2019-06-29 16:15:43 --> Output Class Initialized
INFO - 2019-06-29 16:15:43 --> Security Class Initialized
DEBUG - 2019-06-29 16:15:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 16:15:43 --> Input Class Initialized
INFO - 2019-06-29 16:15:43 --> Language Class Initialized
INFO - 2019-06-29 16:15:43 --> Language Class Initialized
INFO - 2019-06-29 16:15:43 --> Config Class Initialized
INFO - 2019-06-29 16:15:43 --> Loader Class Initialized
DEBUG - 2019-06-29 16:15:43 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 16:15:43 --> Helper loaded: url_helper
INFO - 2019-06-29 16:15:43 --> Helper loaded: inflector_helper
INFO - 2019-06-29 16:15:43 --> Helper loaded: string_helper
INFO - 2019-06-29 16:15:43 --> Helper loaded: array_helper
INFO - 2019-06-29 16:15:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 16:15:43 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 16:15:43 --> Database Driver Class Initialized
INFO - 2019-06-29 16:15:43 --> Controller Class Initialized
INFO - 2019-06-29 22:15:43 --> Helper loaded: language_helper
INFO - 2019-06-29 22:15:43 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 22:15:43 --> Model Class Initialized
INFO - 2019-06-29 22:15:43 --> Model Class Initialized
INFO - 2019-06-29 22:15:43 --> Model Class Initialized
INFO - 2019-06-29 22:15:43 --> Model Class Initialized
INFO - 2019-06-29 22:15:43 --> Helper loaded: form_helper
INFO - 2019-06-29 22:15:43 --> Form Validation Class Initialized
DEBUG - 2019-06-29 22:15:43 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-29 22:15:43 --> Model Class Initialized
INFO - 2019-06-29 22:15:43 --> Model Class Initialized
INFO - 2019-06-29 22:15:43 --> Final output sent to browser
DEBUG - 2019-06-29 22:15:43 --> Total execution time: 0.6689
INFO - 2019-06-29 16:15:52 --> Config Class Initialized
INFO - 2019-06-29 16:15:52 --> Hooks Class Initialized
DEBUG - 2019-06-29 16:15:52 --> UTF-8 Support Enabled
INFO - 2019-06-29 16:15:52 --> Utf8 Class Initialized
INFO - 2019-06-29 16:15:52 --> URI Class Initialized
INFO - 2019-06-29 16:15:52 --> Router Class Initialized
INFO - 2019-06-29 16:15:52 --> Output Class Initialized
INFO - 2019-06-29 16:15:52 --> Security Class Initialized
DEBUG - 2019-06-29 16:15:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 16:15:52 --> Input Class Initialized
INFO - 2019-06-29 16:15:52 --> Language Class Initialized
INFO - 2019-06-29 16:15:52 --> Language Class Initialized
INFO - 2019-06-29 16:15:52 --> Config Class Initialized
INFO - 2019-06-29 16:15:52 --> Loader Class Initialized
DEBUG - 2019-06-29 16:15:52 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 16:15:52 --> Helper loaded: url_helper
INFO - 2019-06-29 16:15:52 --> Helper loaded: inflector_helper
INFO - 2019-06-29 16:15:52 --> Helper loaded: string_helper
INFO - 2019-06-29 16:15:52 --> Helper loaded: array_helper
INFO - 2019-06-29 16:15:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 16:15:52 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 16:15:52 --> Database Driver Class Initialized
INFO - 2019-06-29 16:15:52 --> Controller Class Initialized
INFO - 2019-06-29 22:15:52 --> Helper loaded: language_helper
INFO - 2019-06-29 22:15:52 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 22:15:52 --> Model Class Initialized
INFO - 2019-06-29 22:15:52 --> Model Class Initialized
INFO - 2019-06-29 22:15:52 --> Model Class Initialized
INFO - 2019-06-29 22:15:52 --> Model Class Initialized
INFO - 2019-06-29 22:15:52 --> Helper loaded: form_helper
INFO - 2019-06-29 22:15:52 --> Form Validation Class Initialized
DEBUG - 2019-06-29 22:15:52 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-29 22:15:53 --> Model Class Initialized
INFO - 2019-06-29 22:15:53 --> Model Class Initialized
INFO - 2019-06-29 22:15:53 --> Final output sent to browser
DEBUG - 2019-06-29 22:15:53 --> Total execution time: 0.8913
INFO - 2019-06-29 16:15:54 --> Config Class Initialized
INFO - 2019-06-29 16:15:54 --> Hooks Class Initialized
DEBUG - 2019-06-29 16:15:54 --> UTF-8 Support Enabled
INFO - 2019-06-29 16:15:54 --> Utf8 Class Initialized
INFO - 2019-06-29 16:15:54 --> URI Class Initialized
INFO - 2019-06-29 16:15:54 --> Router Class Initialized
INFO - 2019-06-29 16:15:54 --> Output Class Initialized
INFO - 2019-06-29 16:15:54 --> Security Class Initialized
DEBUG - 2019-06-29 16:15:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 16:15:54 --> Input Class Initialized
INFO - 2019-06-29 16:15:54 --> Language Class Initialized
INFO - 2019-06-29 16:15:54 --> Language Class Initialized
INFO - 2019-06-29 16:15:54 --> Config Class Initialized
INFO - 2019-06-29 16:15:54 --> Loader Class Initialized
DEBUG - 2019-06-29 16:15:54 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 16:15:54 --> Helper loaded: url_helper
INFO - 2019-06-29 16:15:54 --> Helper loaded: inflector_helper
INFO - 2019-06-29 16:15:54 --> Helper loaded: string_helper
INFO - 2019-06-29 16:15:54 --> Helper loaded: array_helper
INFO - 2019-06-29 16:15:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 16:15:54 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 16:15:54 --> Database Driver Class Initialized
INFO - 2019-06-29 16:15:54 --> Controller Class Initialized
INFO - 2019-06-29 22:15:54 --> Helper loaded: language_helper
INFO - 2019-06-29 22:15:54 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 22:15:54 --> Model Class Initialized
INFO - 2019-06-29 22:15:54 --> Model Class Initialized
INFO - 2019-06-29 22:15:54 --> Model Class Initialized
INFO - 2019-06-29 22:15:54 --> Model Class Initialized
INFO - 2019-06-29 22:15:54 --> Model Class Initialized
INFO - 2019-06-29 22:15:54 --> Final output sent to browser
DEBUG - 2019-06-29 22:15:54 --> Total execution time: 0.5987
INFO - 2019-06-29 16:15:55 --> Config Class Initialized
INFO - 2019-06-29 16:15:55 --> Hooks Class Initialized
DEBUG - 2019-06-29 16:15:55 --> UTF-8 Support Enabled
INFO - 2019-06-29 16:15:55 --> Utf8 Class Initialized
INFO - 2019-06-29 16:15:55 --> URI Class Initialized
INFO - 2019-06-29 16:15:55 --> Router Class Initialized
INFO - 2019-06-29 16:15:55 --> Output Class Initialized
INFO - 2019-06-29 16:15:55 --> Security Class Initialized
DEBUG - 2019-06-29 16:15:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 16:15:55 --> Input Class Initialized
INFO - 2019-06-29 16:15:55 --> Language Class Initialized
INFO - 2019-06-29 16:15:55 --> Language Class Initialized
INFO - 2019-06-29 16:15:55 --> Config Class Initialized
INFO - 2019-06-29 16:15:55 --> Loader Class Initialized
DEBUG - 2019-06-29 16:15:55 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 16:15:55 --> Helper loaded: url_helper
INFO - 2019-06-29 16:15:55 --> Helper loaded: inflector_helper
INFO - 2019-06-29 16:15:55 --> Helper loaded: string_helper
INFO - 2019-06-29 16:15:55 --> Helper loaded: array_helper
INFO - 2019-06-29 16:15:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 16:15:55 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 16:15:55 --> Database Driver Class Initialized
INFO - 2019-06-29 16:15:55 --> Controller Class Initialized
INFO - 2019-06-29 22:15:55 --> Helper loaded: language_helper
INFO - 2019-06-29 22:15:55 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 22:15:55 --> Model Class Initialized
INFO - 2019-06-29 22:15:55 --> Model Class Initialized
INFO - 2019-06-29 22:15:55 --> Model Class Initialized
INFO - 2019-06-29 22:15:55 --> Model Class Initialized
INFO - 2019-06-29 22:15:56 --> Helper loaded: form_helper
INFO - 2019-06-29 22:15:56 --> Form Validation Class Initialized
DEBUG - 2019-06-29 22:15:56 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-29 22:15:56 --> Model Class Initialized
INFO - 2019-06-29 22:15:56 --> Model Class Initialized
INFO - 2019-06-29 22:15:56 --> Final output sent to browser
DEBUG - 2019-06-29 22:15:56 --> Total execution time: 0.7458
INFO - 2019-06-29 16:15:56 --> Config Class Initialized
INFO - 2019-06-29 16:15:56 --> Hooks Class Initialized
DEBUG - 2019-06-29 16:15:56 --> UTF-8 Support Enabled
INFO - 2019-06-29 16:15:56 --> Utf8 Class Initialized
INFO - 2019-06-29 16:15:57 --> URI Class Initialized
INFO - 2019-06-29 16:15:57 --> Router Class Initialized
INFO - 2019-06-29 16:15:57 --> Output Class Initialized
INFO - 2019-06-29 16:15:57 --> Security Class Initialized
DEBUG - 2019-06-29 16:15:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 16:15:57 --> Input Class Initialized
INFO - 2019-06-29 16:15:57 --> Language Class Initialized
INFO - 2019-06-29 16:15:57 --> Language Class Initialized
INFO - 2019-06-29 16:15:57 --> Config Class Initialized
INFO - 2019-06-29 16:15:57 --> Loader Class Initialized
DEBUG - 2019-06-29 16:15:57 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 16:15:57 --> Helper loaded: url_helper
INFO - 2019-06-29 16:15:57 --> Helper loaded: inflector_helper
INFO - 2019-06-29 16:15:57 --> Helper loaded: string_helper
INFO - 2019-06-29 16:15:57 --> Helper loaded: array_helper
INFO - 2019-06-29 16:15:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 16:15:57 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 16:15:57 --> Database Driver Class Initialized
INFO - 2019-06-29 16:15:57 --> Controller Class Initialized
INFO - 2019-06-29 22:15:57 --> Helper loaded: language_helper
INFO - 2019-06-29 22:15:57 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 22:15:57 --> Model Class Initialized
INFO - 2019-06-29 22:15:57 --> Model Class Initialized
INFO - 2019-06-29 22:15:57 --> Model Class Initialized
INFO - 2019-06-29 22:15:57 --> Model Class Initialized
INFO - 2019-06-29 22:15:57 --> Model Class Initialized
INFO - 2019-06-29 22:15:57 --> Final output sent to browser
DEBUG - 2019-06-29 22:15:57 --> Total execution time: 1.0038
INFO - 2019-06-29 16:16:04 --> Config Class Initialized
INFO - 2019-06-29 16:16:04 --> Hooks Class Initialized
DEBUG - 2019-06-29 16:16:04 --> UTF-8 Support Enabled
INFO - 2019-06-29 16:16:04 --> Utf8 Class Initialized
INFO - 2019-06-29 16:16:04 --> URI Class Initialized
INFO - 2019-06-29 16:16:04 --> Router Class Initialized
INFO - 2019-06-29 16:16:04 --> Output Class Initialized
INFO - 2019-06-29 16:16:04 --> Security Class Initialized
DEBUG - 2019-06-29 16:16:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 16:16:04 --> Input Class Initialized
INFO - 2019-06-29 16:16:04 --> Language Class Initialized
INFO - 2019-06-29 16:16:04 --> Language Class Initialized
INFO - 2019-06-29 16:16:04 --> Config Class Initialized
INFO - 2019-06-29 16:16:04 --> Loader Class Initialized
DEBUG - 2019-06-29 16:16:04 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 16:16:04 --> Helper loaded: url_helper
INFO - 2019-06-29 16:16:04 --> Helper loaded: inflector_helper
INFO - 2019-06-29 16:16:04 --> Helper loaded: string_helper
INFO - 2019-06-29 16:16:04 --> Helper loaded: array_helper
INFO - 2019-06-29 16:16:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 16:16:04 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 16:16:04 --> Database Driver Class Initialized
INFO - 2019-06-29 16:16:04 --> Controller Class Initialized
INFO - 2019-06-29 22:16:04 --> Helper loaded: language_helper
INFO - 2019-06-29 22:16:04 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 22:16:04 --> Model Class Initialized
INFO - 2019-06-29 22:16:04 --> Model Class Initialized
INFO - 2019-06-29 22:16:04 --> Model Class Initialized
INFO - 2019-06-29 22:16:04 --> Model Class Initialized
INFO - 2019-06-29 22:16:04 --> Helper loaded: form_helper
INFO - 2019-06-29 22:16:04 --> Form Validation Class Initialized
DEBUG - 2019-06-29 22:16:04 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-29 22:16:04 --> Model Class Initialized
INFO - 2019-06-29 22:16:04 --> Model Class Initialized
INFO - 2019-06-29 22:16:04 --> Final output sent to browser
DEBUG - 2019-06-29 22:16:04 --> Total execution time: 0.5816
INFO - 2019-06-29 16:16:30 --> Config Class Initialized
INFO - 2019-06-29 16:16:30 --> Hooks Class Initialized
DEBUG - 2019-06-29 16:16:30 --> UTF-8 Support Enabled
INFO - 2019-06-29 16:16:30 --> Utf8 Class Initialized
INFO - 2019-06-29 16:16:30 --> URI Class Initialized
INFO - 2019-06-29 16:16:30 --> Router Class Initialized
INFO - 2019-06-29 16:16:30 --> Output Class Initialized
INFO - 2019-06-29 16:16:30 --> Security Class Initialized
DEBUG - 2019-06-29 16:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 16:16:30 --> Input Class Initialized
INFO - 2019-06-29 16:16:30 --> Language Class Initialized
INFO - 2019-06-29 16:16:30 --> Language Class Initialized
INFO - 2019-06-29 16:16:30 --> Config Class Initialized
INFO - 2019-06-29 16:16:30 --> Loader Class Initialized
DEBUG - 2019-06-29 16:16:30 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 16:16:30 --> Helper loaded: url_helper
INFO - 2019-06-29 16:16:30 --> Helper loaded: inflector_helper
INFO - 2019-06-29 16:16:30 --> Helper loaded: string_helper
INFO - 2019-06-29 16:16:30 --> Helper loaded: array_helper
INFO - 2019-06-29 16:16:30 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 16:16:30 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 16:16:30 --> Database Driver Class Initialized
INFO - 2019-06-29 16:16:30 --> Controller Class Initialized
INFO - 2019-06-29 22:16:31 --> Helper loaded: language_helper
INFO - 2019-06-29 22:16:31 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 22:16:31 --> Model Class Initialized
INFO - 2019-06-29 22:16:31 --> Model Class Initialized
INFO - 2019-06-29 22:16:31 --> Model Class Initialized
INFO - 2019-06-29 22:16:31 --> Model Class Initialized
INFO - 2019-06-29 22:16:31 --> Helper loaded: form_helper
INFO - 2019-06-29 22:16:31 --> Form Validation Class Initialized
DEBUG - 2019-06-29 22:16:31 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-29 22:16:31 --> Model Class Initialized
INFO - 2019-06-29 22:16:31 --> Model Class Initialized
INFO - 2019-06-29 22:16:31 --> Final output sent to browser
DEBUG - 2019-06-29 22:16:31 --> Total execution time: 1.3295
INFO - 2019-06-29 16:16:32 --> Config Class Initialized
INFO - 2019-06-29 16:16:32 --> Hooks Class Initialized
DEBUG - 2019-06-29 16:16:32 --> UTF-8 Support Enabled
INFO - 2019-06-29 16:16:32 --> Utf8 Class Initialized
INFO - 2019-06-29 16:16:32 --> URI Class Initialized
INFO - 2019-06-29 16:16:32 --> Router Class Initialized
INFO - 2019-06-29 16:16:32 --> Output Class Initialized
INFO - 2019-06-29 16:16:32 --> Security Class Initialized
DEBUG - 2019-06-29 16:16:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 16:16:32 --> Input Class Initialized
INFO - 2019-06-29 16:16:32 --> Language Class Initialized
INFO - 2019-06-29 16:16:32 --> Language Class Initialized
INFO - 2019-06-29 16:16:32 --> Config Class Initialized
INFO - 2019-06-29 16:16:32 --> Loader Class Initialized
DEBUG - 2019-06-29 16:16:32 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 16:16:32 --> Helper loaded: url_helper
INFO - 2019-06-29 16:16:32 --> Helper loaded: inflector_helper
INFO - 2019-06-29 16:16:32 --> Helper loaded: string_helper
INFO - 2019-06-29 16:16:32 --> Helper loaded: array_helper
INFO - 2019-06-29 16:16:32 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 16:16:32 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 16:16:32 --> Database Driver Class Initialized
INFO - 2019-06-29 16:16:32 --> Controller Class Initialized
INFO - 2019-06-29 22:16:32 --> Helper loaded: language_helper
INFO - 2019-06-29 22:16:32 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 22:16:32 --> Model Class Initialized
INFO - 2019-06-29 22:16:32 --> Model Class Initialized
INFO - 2019-06-29 22:16:33 --> Model Class Initialized
INFO - 2019-06-29 22:16:33 --> Model Class Initialized
INFO - 2019-06-29 22:16:33 --> Helper loaded: form_helper
INFO - 2019-06-29 22:16:33 --> Form Validation Class Initialized
DEBUG - 2019-06-29 22:16:33 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-29 22:16:33 --> Model Class Initialized
INFO - 2019-06-29 22:16:33 --> Model Class Initialized
INFO - 2019-06-29 22:16:33 --> Final output sent to browser
DEBUG - 2019-06-29 22:16:33 --> Total execution time: 0.7138
INFO - 2019-06-29 16:17:03 --> Config Class Initialized
INFO - 2019-06-29 16:17:03 --> Hooks Class Initialized
DEBUG - 2019-06-29 16:17:03 --> UTF-8 Support Enabled
INFO - 2019-06-29 16:17:03 --> Utf8 Class Initialized
INFO - 2019-06-29 16:17:03 --> URI Class Initialized
INFO - 2019-06-29 16:17:03 --> Router Class Initialized
INFO - 2019-06-29 16:17:03 --> Output Class Initialized
INFO - 2019-06-29 16:17:03 --> Security Class Initialized
DEBUG - 2019-06-29 16:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 16:17:03 --> Input Class Initialized
INFO - 2019-06-29 16:17:03 --> Language Class Initialized
INFO - 2019-06-29 16:17:03 --> Language Class Initialized
INFO - 2019-06-29 16:17:03 --> Config Class Initialized
INFO - 2019-06-29 16:17:03 --> Loader Class Initialized
DEBUG - 2019-06-29 16:17:03 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 16:17:03 --> Helper loaded: url_helper
INFO - 2019-06-29 16:17:03 --> Helper loaded: inflector_helper
INFO - 2019-06-29 16:17:03 --> Helper loaded: string_helper
INFO - 2019-06-29 16:17:03 --> Helper loaded: array_helper
INFO - 2019-06-29 16:17:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 16:17:03 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 16:17:03 --> Database Driver Class Initialized
INFO - 2019-06-29 16:17:03 --> Controller Class Initialized
INFO - 2019-06-29 22:17:03 --> Helper loaded: language_helper
INFO - 2019-06-29 22:17:03 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 22:17:03 --> Model Class Initialized
INFO - 2019-06-29 22:17:03 --> Model Class Initialized
INFO - 2019-06-29 22:17:03 --> Model Class Initialized
INFO - 2019-06-29 22:17:03 --> Model Class Initialized
INFO - 2019-06-29 22:17:03 --> Helper loaded: form_helper
INFO - 2019-06-29 22:17:03 --> Form Validation Class Initialized
DEBUG - 2019-06-29 22:17:03 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-29 22:17:03 --> Model Class Initialized
INFO - 2019-06-29 22:17:03 --> Model Class Initialized
INFO - 2019-06-29 22:17:03 --> Final output sent to browser
DEBUG - 2019-06-29 22:17:03 --> Total execution time: 0.5816
INFO - 2019-06-29 16:17:05 --> Config Class Initialized
INFO - 2019-06-29 16:17:05 --> Hooks Class Initialized
DEBUG - 2019-06-29 16:17:05 --> UTF-8 Support Enabled
INFO - 2019-06-29 16:17:05 --> Utf8 Class Initialized
INFO - 2019-06-29 16:17:05 --> URI Class Initialized
INFO - 2019-06-29 16:17:05 --> Router Class Initialized
INFO - 2019-06-29 16:17:05 --> Output Class Initialized
INFO - 2019-06-29 16:17:05 --> Security Class Initialized
DEBUG - 2019-06-29 16:17:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 16:17:05 --> Input Class Initialized
INFO - 2019-06-29 16:17:05 --> Language Class Initialized
INFO - 2019-06-29 16:17:05 --> Language Class Initialized
INFO - 2019-06-29 16:17:05 --> Config Class Initialized
INFO - 2019-06-29 16:17:05 --> Loader Class Initialized
DEBUG - 2019-06-29 16:17:05 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 16:17:05 --> Helper loaded: url_helper
INFO - 2019-06-29 16:17:05 --> Helper loaded: inflector_helper
INFO - 2019-06-29 16:17:05 --> Helper loaded: string_helper
INFO - 2019-06-29 16:17:05 --> Helper loaded: array_helper
INFO - 2019-06-29 16:17:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 16:17:05 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 16:17:05 --> Database Driver Class Initialized
INFO - 2019-06-29 16:17:05 --> Controller Class Initialized
INFO - 2019-06-29 22:17:05 --> Helper loaded: language_helper
INFO - 2019-06-29 22:17:05 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 22:17:06 --> Model Class Initialized
INFO - 2019-06-29 22:17:06 --> Model Class Initialized
INFO - 2019-06-29 22:17:06 --> Model Class Initialized
INFO - 2019-06-29 22:17:06 --> Model Class Initialized
INFO - 2019-06-29 22:17:06 --> Model Class Initialized
INFO - 2019-06-29 22:17:06 --> Final output sent to browser
DEBUG - 2019-06-29 22:17:06 --> Total execution time: 0.5283
INFO - 2019-06-29 16:17:18 --> Config Class Initialized
INFO - 2019-06-29 16:17:18 --> Hooks Class Initialized
DEBUG - 2019-06-29 16:17:18 --> UTF-8 Support Enabled
INFO - 2019-06-29 16:17:18 --> Utf8 Class Initialized
INFO - 2019-06-29 16:17:18 --> URI Class Initialized
INFO - 2019-06-29 16:17:18 --> Router Class Initialized
INFO - 2019-06-29 16:17:18 --> Output Class Initialized
INFO - 2019-06-29 16:17:18 --> Security Class Initialized
DEBUG - 2019-06-29 16:17:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 16:17:18 --> Input Class Initialized
INFO - 2019-06-29 16:17:18 --> Language Class Initialized
INFO - 2019-06-29 16:17:18 --> Language Class Initialized
INFO - 2019-06-29 16:17:18 --> Config Class Initialized
INFO - 2019-06-29 16:17:18 --> Loader Class Initialized
DEBUG - 2019-06-29 16:17:18 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 16:17:18 --> Helper loaded: url_helper
INFO - 2019-06-29 16:17:18 --> Helper loaded: inflector_helper
INFO - 2019-06-29 16:17:18 --> Helper loaded: string_helper
INFO - 2019-06-29 16:17:18 --> Helper loaded: array_helper
INFO - 2019-06-29 16:17:18 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 16:17:18 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 16:17:18 --> Database Driver Class Initialized
INFO - 2019-06-29 16:17:18 --> Controller Class Initialized
INFO - 2019-06-29 22:17:18 --> Helper loaded: language_helper
INFO - 2019-06-29 22:17:18 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 22:17:18 --> Model Class Initialized
INFO - 2019-06-29 22:17:18 --> Model Class Initialized
INFO - 2019-06-29 22:17:18 --> Model Class Initialized
INFO - 2019-06-29 22:17:18 --> Model Class Initialized
INFO - 2019-06-29 22:17:18 --> Helper loaded: form_helper
INFO - 2019-06-29 22:17:18 --> Form Validation Class Initialized
DEBUG - 2019-06-29 22:17:18 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-29 22:17:18 --> Model Class Initialized
INFO - 2019-06-29 22:17:18 --> Model Class Initialized
INFO - 2019-06-29 22:17:18 --> Final output sent to browser
DEBUG - 2019-06-29 22:17:18 --> Total execution time: 0.6272
INFO - 2019-06-29 16:18:47 --> Config Class Initialized
INFO - 2019-06-29 16:18:47 --> Hooks Class Initialized
DEBUG - 2019-06-29 16:18:47 --> UTF-8 Support Enabled
INFO - 2019-06-29 16:18:47 --> Utf8 Class Initialized
INFO - 2019-06-29 16:18:47 --> URI Class Initialized
INFO - 2019-06-29 16:18:47 --> Router Class Initialized
INFO - 2019-06-29 16:18:47 --> Output Class Initialized
INFO - 2019-06-29 16:18:47 --> Security Class Initialized
DEBUG - 2019-06-29 16:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 16:18:47 --> Input Class Initialized
INFO - 2019-06-29 16:18:47 --> Language Class Initialized
INFO - 2019-06-29 16:18:47 --> Language Class Initialized
INFO - 2019-06-29 16:18:47 --> Config Class Initialized
INFO - 2019-06-29 16:18:47 --> Loader Class Initialized
DEBUG - 2019-06-29 16:18:47 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 16:18:47 --> Helper loaded: url_helper
INFO - 2019-06-29 16:18:47 --> Helper loaded: inflector_helper
INFO - 2019-06-29 16:18:47 --> Helper loaded: string_helper
INFO - 2019-06-29 16:18:47 --> Helper loaded: array_helper
INFO - 2019-06-29 16:18:47 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 16:18:47 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 16:18:47 --> Database Driver Class Initialized
INFO - 2019-06-29 16:18:47 --> Controller Class Initialized
INFO - 2019-06-29 22:18:47 --> Helper loaded: language_helper
INFO - 2019-06-29 22:18:47 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 22:18:48 --> Model Class Initialized
INFO - 2019-06-29 22:18:48 --> Model Class Initialized
INFO - 2019-06-29 22:18:48 --> Model Class Initialized
INFO - 2019-06-29 22:18:48 --> Model Class Initialized
INFO - 2019-06-29 22:18:48 --> Helper loaded: form_helper
INFO - 2019-06-29 22:18:48 --> Form Validation Class Initialized
DEBUG - 2019-06-29 22:18:48 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-29 22:18:48 --> Model Class Initialized
INFO - 2019-06-29 22:18:48 --> Model Class Initialized
INFO - 2019-06-29 22:18:48 --> Final output sent to browser
DEBUG - 2019-06-29 22:18:48 --> Total execution time: 0.3830
INFO - 2019-06-29 16:18:48 --> Config Class Initialized
INFO - 2019-06-29 16:18:48 --> Hooks Class Initialized
DEBUG - 2019-06-29 16:18:48 --> UTF-8 Support Enabled
INFO - 2019-06-29 16:18:48 --> Utf8 Class Initialized
INFO - 2019-06-29 16:18:48 --> URI Class Initialized
INFO - 2019-06-29 16:18:48 --> Router Class Initialized
INFO - 2019-06-29 16:18:48 --> Output Class Initialized
INFO - 2019-06-29 16:18:48 --> Security Class Initialized
DEBUG - 2019-06-29 16:18:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 16:18:48 --> Input Class Initialized
INFO - 2019-06-29 16:18:48 --> Language Class Initialized
INFO - 2019-06-29 16:18:48 --> Language Class Initialized
INFO - 2019-06-29 16:18:48 --> Config Class Initialized
INFO - 2019-06-29 16:18:48 --> Loader Class Initialized
DEBUG - 2019-06-29 16:18:48 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 16:18:48 --> Helper loaded: url_helper
INFO - 2019-06-29 16:18:48 --> Helper loaded: inflector_helper
INFO - 2019-06-29 16:18:48 --> Helper loaded: string_helper
INFO - 2019-06-29 16:18:48 --> Helper loaded: array_helper
INFO - 2019-06-29 16:18:48 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 16:18:48 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 16:18:48 --> Database Driver Class Initialized
INFO - 2019-06-29 16:18:48 --> Controller Class Initialized
INFO - 2019-06-29 22:18:48 --> Helper loaded: language_helper
INFO - 2019-06-29 22:18:48 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 22:18:48 --> Model Class Initialized
INFO - 2019-06-29 22:18:48 --> Model Class Initialized
INFO - 2019-06-29 22:18:48 --> Model Class Initialized
INFO - 2019-06-29 22:18:48 --> Model Class Initialized
INFO - 2019-06-29 22:18:48 --> Model Class Initialized
INFO - 2019-06-29 22:18:48 --> Final output sent to browser
DEBUG - 2019-06-29 22:18:48 --> Total execution time: 0.4687
INFO - 2019-06-29 16:18:54 --> Config Class Initialized
INFO - 2019-06-29 16:18:54 --> Hooks Class Initialized
DEBUG - 2019-06-29 16:18:54 --> UTF-8 Support Enabled
INFO - 2019-06-29 16:18:54 --> Utf8 Class Initialized
INFO - 2019-06-29 16:18:54 --> URI Class Initialized
INFO - 2019-06-29 16:18:54 --> Router Class Initialized
INFO - 2019-06-29 16:18:54 --> Output Class Initialized
INFO - 2019-06-29 16:18:54 --> Security Class Initialized
DEBUG - 2019-06-29 16:18:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 16:18:54 --> Input Class Initialized
INFO - 2019-06-29 16:18:54 --> Language Class Initialized
INFO - 2019-06-29 16:18:54 --> Language Class Initialized
INFO - 2019-06-29 16:18:54 --> Config Class Initialized
INFO - 2019-06-29 16:18:54 --> Loader Class Initialized
DEBUG - 2019-06-29 16:18:54 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 16:18:54 --> Helper loaded: url_helper
INFO - 2019-06-29 16:18:54 --> Helper loaded: inflector_helper
INFO - 2019-06-29 16:18:54 --> Helper loaded: string_helper
INFO - 2019-06-29 16:18:54 --> Helper loaded: array_helper
INFO - 2019-06-29 16:18:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 16:18:54 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 16:18:54 --> Database Driver Class Initialized
INFO - 2019-06-29 16:18:54 --> Controller Class Initialized
INFO - 2019-06-29 22:18:54 --> Helper loaded: language_helper
INFO - 2019-06-29 22:18:54 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 22:18:54 --> Model Class Initialized
INFO - 2019-06-29 22:18:54 --> Model Class Initialized
INFO - 2019-06-29 22:18:54 --> Model Class Initialized
INFO - 2019-06-29 22:18:54 --> Model Class Initialized
INFO - 2019-06-29 22:18:54 --> Helper loaded: form_helper
INFO - 2019-06-29 22:18:54 --> Form Validation Class Initialized
DEBUG - 2019-06-29 22:18:54 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-29 22:18:54 --> Model Class Initialized
INFO - 2019-06-29 22:18:54 --> Model Class Initialized
INFO - 2019-06-29 22:18:54 --> Final output sent to browser
DEBUG - 2019-06-29 22:18:54 --> Total execution time: 0.6140
INFO - 2019-06-29 16:23:31 --> Config Class Initialized
INFO - 2019-06-29 16:23:31 --> Hooks Class Initialized
DEBUG - 2019-06-29 16:23:31 --> UTF-8 Support Enabled
INFO - 2019-06-29 16:23:31 --> Utf8 Class Initialized
INFO - 2019-06-29 16:23:31 --> URI Class Initialized
INFO - 2019-06-29 16:23:32 --> Router Class Initialized
INFO - 2019-06-29 16:23:32 --> Output Class Initialized
INFO - 2019-06-29 16:23:32 --> Security Class Initialized
DEBUG - 2019-06-29 16:23:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 16:23:32 --> Input Class Initialized
INFO - 2019-06-29 16:23:32 --> Language Class Initialized
INFO - 2019-06-29 16:23:32 --> Language Class Initialized
INFO - 2019-06-29 16:23:32 --> Config Class Initialized
INFO - 2019-06-29 16:23:32 --> Loader Class Initialized
DEBUG - 2019-06-29 16:23:32 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 16:23:32 --> Helper loaded: url_helper
INFO - 2019-06-29 16:23:32 --> Helper loaded: inflector_helper
INFO - 2019-06-29 16:23:32 --> Helper loaded: string_helper
INFO - 2019-06-29 16:23:32 --> Helper loaded: array_helper
INFO - 2019-06-29 16:23:32 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 16:23:32 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 16:23:32 --> Database Driver Class Initialized
INFO - 2019-06-29 16:23:32 --> Controller Class Initialized
INFO - 2019-06-29 22:23:32 --> Helper loaded: language_helper
INFO - 2019-06-29 22:23:32 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 22:23:32 --> Model Class Initialized
INFO - 2019-06-29 22:23:32 --> Model Class Initialized
INFO - 2019-06-29 22:23:32 --> Model Class Initialized
INFO - 2019-06-29 22:23:32 --> Model Class Initialized
INFO - 2019-06-29 22:23:32 --> Helper loaded: form_helper
INFO - 2019-06-29 22:23:32 --> Form Validation Class Initialized
DEBUG - 2019-06-29 22:23:32 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-29 22:23:32 --> Model Class Initialized
INFO - 2019-06-29 22:23:32 --> Model Class Initialized
INFO - 2019-06-29 22:23:32 --> Final output sent to browser
DEBUG - 2019-06-29 22:23:32 --> Total execution time: 0.7031
INFO - 2019-06-29 16:30:53 --> Config Class Initialized
INFO - 2019-06-29 16:30:53 --> Hooks Class Initialized
DEBUG - 2019-06-29 16:30:53 --> UTF-8 Support Enabled
INFO - 2019-06-29 16:30:54 --> Utf8 Class Initialized
INFO - 2019-06-29 16:30:54 --> URI Class Initialized
INFO - 2019-06-29 16:30:54 --> Router Class Initialized
INFO - 2019-06-29 16:30:54 --> Output Class Initialized
INFO - 2019-06-29 16:30:54 --> Security Class Initialized
DEBUG - 2019-06-29 16:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 16:30:54 --> Input Class Initialized
INFO - 2019-06-29 16:30:54 --> Language Class Initialized
INFO - 2019-06-29 16:30:54 --> Language Class Initialized
INFO - 2019-06-29 16:30:54 --> Config Class Initialized
INFO - 2019-06-29 16:30:54 --> Loader Class Initialized
DEBUG - 2019-06-29 16:30:54 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 16:30:54 --> Helper loaded: url_helper
INFO - 2019-06-29 16:30:54 --> Helper loaded: inflector_helper
INFO - 2019-06-29 16:30:54 --> Helper loaded: string_helper
INFO - 2019-06-29 16:30:54 --> Helper loaded: array_helper
INFO - 2019-06-29 16:30:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 16:30:54 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 16:30:54 --> Database Driver Class Initialized
INFO - 2019-06-29 16:30:54 --> Controller Class Initialized
INFO - 2019-06-29 22:30:54 --> Helper loaded: language_helper
INFO - 2019-06-29 22:30:54 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 22:30:54 --> Model Class Initialized
INFO - 2019-06-29 22:30:54 --> Model Class Initialized
INFO - 2019-06-29 22:30:54 --> Model Class Initialized
INFO - 2019-06-29 22:30:54 --> Model Class Initialized
INFO - 2019-06-29 22:30:54 --> Helper loaded: form_helper
INFO - 2019-06-29 22:30:54 --> Form Validation Class Initialized
DEBUG - 2019-06-29 22:30:54 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-29 22:30:54 --> Model Class Initialized
INFO - 2019-06-29 22:30:54 --> Model Class Initialized
INFO - 2019-06-29 22:30:54 --> Final output sent to browser
DEBUG - 2019-06-29 22:30:54 --> Total execution time: 0.4816
INFO - 2019-06-29 16:30:55 --> Config Class Initialized
INFO - 2019-06-29 16:30:55 --> Hooks Class Initialized
DEBUG - 2019-06-29 16:30:55 --> UTF-8 Support Enabled
INFO - 2019-06-29 16:30:55 --> Utf8 Class Initialized
INFO - 2019-06-29 16:30:56 --> URI Class Initialized
INFO - 2019-06-29 16:30:56 --> Router Class Initialized
INFO - 2019-06-29 16:30:56 --> Output Class Initialized
INFO - 2019-06-29 16:30:56 --> Security Class Initialized
DEBUG - 2019-06-29 16:30:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 16:30:56 --> Input Class Initialized
INFO - 2019-06-29 16:30:56 --> Language Class Initialized
INFO - 2019-06-29 16:30:56 --> Language Class Initialized
INFO - 2019-06-29 16:30:56 --> Config Class Initialized
INFO - 2019-06-29 16:30:56 --> Loader Class Initialized
DEBUG - 2019-06-29 16:30:56 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 16:30:56 --> Helper loaded: url_helper
INFO - 2019-06-29 16:30:56 --> Helper loaded: inflector_helper
INFO - 2019-06-29 16:30:56 --> Helper loaded: string_helper
INFO - 2019-06-29 16:30:56 --> Helper loaded: array_helper
INFO - 2019-06-29 16:30:56 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 16:30:56 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 16:30:56 --> Database Driver Class Initialized
INFO - 2019-06-29 16:30:56 --> Controller Class Initialized
INFO - 2019-06-29 22:30:56 --> Helper loaded: language_helper
INFO - 2019-06-29 22:30:56 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 22:30:56 --> Model Class Initialized
INFO - 2019-06-29 22:30:56 --> Model Class Initialized
INFO - 2019-06-29 22:30:56 --> Model Class Initialized
INFO - 2019-06-29 22:30:56 --> Model Class Initialized
INFO - 2019-06-29 22:30:56 --> Helper loaded: form_helper
INFO - 2019-06-29 22:30:56 --> Form Validation Class Initialized
DEBUG - 2019-06-29 22:30:56 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-29 22:30:56 --> Model Class Initialized
INFO - 2019-06-29 22:30:56 --> Model Class Initialized
INFO - 2019-06-29 22:30:56 --> Final output sent to browser
DEBUG - 2019-06-29 22:30:56 --> Total execution time: 0.6969
INFO - 2019-06-29 16:31:48 --> Config Class Initialized
INFO - 2019-06-29 16:31:48 --> Hooks Class Initialized
DEBUG - 2019-06-29 16:31:48 --> UTF-8 Support Enabled
INFO - 2019-06-29 16:31:48 --> Utf8 Class Initialized
INFO - 2019-06-29 16:31:48 --> URI Class Initialized
INFO - 2019-06-29 16:31:48 --> Router Class Initialized
INFO - 2019-06-29 16:31:48 --> Output Class Initialized
INFO - 2019-06-29 16:31:48 --> Security Class Initialized
DEBUG - 2019-06-29 16:31:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 16:31:48 --> Input Class Initialized
INFO - 2019-06-29 16:31:48 --> Language Class Initialized
INFO - 2019-06-29 16:31:48 --> Language Class Initialized
INFO - 2019-06-29 16:31:48 --> Config Class Initialized
INFO - 2019-06-29 16:31:49 --> Loader Class Initialized
DEBUG - 2019-06-29 16:31:49 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 16:31:49 --> Helper loaded: url_helper
INFO - 2019-06-29 16:31:49 --> Helper loaded: inflector_helper
INFO - 2019-06-29 16:31:49 --> Helper loaded: string_helper
INFO - 2019-06-29 16:31:49 --> Helper loaded: array_helper
INFO - 2019-06-29 16:31:49 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 16:31:49 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 16:31:49 --> Database Driver Class Initialized
INFO - 2019-06-29 16:31:49 --> Controller Class Initialized
INFO - 2019-06-29 22:31:49 --> Helper loaded: language_helper
INFO - 2019-06-29 22:31:49 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 22:31:49 --> Model Class Initialized
INFO - 2019-06-29 22:31:49 --> Model Class Initialized
INFO - 2019-06-29 22:31:49 --> Model Class Initialized
INFO - 2019-06-29 22:31:49 --> Model Class Initialized
INFO - 2019-06-29 22:31:49 --> Model Class Initialized
INFO - 2019-06-29 22:31:49 --> Final output sent to browser
DEBUG - 2019-06-29 22:31:49 --> Total execution time: 1.2649
INFO - 2019-06-29 16:31:56 --> Config Class Initialized
INFO - 2019-06-29 16:31:56 --> Hooks Class Initialized
DEBUG - 2019-06-29 16:31:56 --> UTF-8 Support Enabled
INFO - 2019-06-29 16:31:56 --> Utf8 Class Initialized
INFO - 2019-06-29 16:31:56 --> URI Class Initialized
INFO - 2019-06-29 16:31:56 --> Router Class Initialized
INFO - 2019-06-29 16:31:56 --> Output Class Initialized
INFO - 2019-06-29 16:31:56 --> Security Class Initialized
DEBUG - 2019-06-29 16:31:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 16:31:56 --> Input Class Initialized
INFO - 2019-06-29 16:31:56 --> Language Class Initialized
INFO - 2019-06-29 16:31:56 --> Language Class Initialized
INFO - 2019-06-29 16:31:56 --> Config Class Initialized
INFO - 2019-06-29 16:31:56 --> Loader Class Initialized
DEBUG - 2019-06-29 16:31:56 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 16:31:57 --> Helper loaded: url_helper
INFO - 2019-06-29 16:31:57 --> Helper loaded: inflector_helper
INFO - 2019-06-29 16:31:57 --> Helper loaded: string_helper
INFO - 2019-06-29 16:31:57 --> Helper loaded: array_helper
INFO - 2019-06-29 16:31:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 16:31:57 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 16:31:57 --> Database Driver Class Initialized
INFO - 2019-06-29 16:31:57 --> Controller Class Initialized
INFO - 2019-06-29 22:31:57 --> Helper loaded: language_helper
INFO - 2019-06-29 22:31:57 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 22:31:57 --> Model Class Initialized
INFO - 2019-06-29 22:31:57 --> Model Class Initialized
INFO - 2019-06-29 22:31:57 --> Model Class Initialized
INFO - 2019-06-29 22:31:57 --> Model Class Initialized
INFO - 2019-06-29 22:31:57 --> Helper loaded: form_helper
INFO - 2019-06-29 22:31:57 --> Form Validation Class Initialized
DEBUG - 2019-06-29 22:31:57 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-29 22:31:57 --> Model Class Initialized
INFO - 2019-06-29 22:31:57 --> Model Class Initialized
INFO - 2019-06-29 22:31:57 --> Final output sent to browser
DEBUG - 2019-06-29 22:31:57 --> Total execution time: 0.9599
INFO - 2019-06-29 16:32:49 --> Config Class Initialized
INFO - 2019-06-29 16:32:49 --> Hooks Class Initialized
DEBUG - 2019-06-29 16:32:49 --> UTF-8 Support Enabled
INFO - 2019-06-29 16:32:49 --> Utf8 Class Initialized
INFO - 2019-06-29 16:32:49 --> URI Class Initialized
INFO - 2019-06-29 16:32:50 --> Router Class Initialized
INFO - 2019-06-29 16:32:50 --> Output Class Initialized
INFO - 2019-06-29 16:32:50 --> Security Class Initialized
DEBUG - 2019-06-29 16:32:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 16:32:50 --> Input Class Initialized
INFO - 2019-06-29 16:32:50 --> Language Class Initialized
INFO - 2019-06-29 16:32:50 --> Language Class Initialized
INFO - 2019-06-29 16:32:50 --> Config Class Initialized
INFO - 2019-06-29 16:32:50 --> Loader Class Initialized
DEBUG - 2019-06-29 16:32:50 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 16:32:50 --> Helper loaded: url_helper
INFO - 2019-06-29 16:32:50 --> Helper loaded: inflector_helper
INFO - 2019-06-29 16:32:50 --> Helper loaded: string_helper
INFO - 2019-06-29 16:32:50 --> Helper loaded: array_helper
INFO - 2019-06-29 16:32:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 16:32:50 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 16:32:50 --> Database Driver Class Initialized
INFO - 2019-06-29 16:32:50 --> Controller Class Initialized
INFO - 2019-06-29 22:32:50 --> Helper loaded: language_helper
INFO - 2019-06-29 22:32:50 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 22:32:50 --> Model Class Initialized
INFO - 2019-06-29 22:32:50 --> Model Class Initialized
INFO - 2019-06-29 22:32:50 --> Model Class Initialized
INFO - 2019-06-29 22:32:50 --> Model Class Initialized
INFO - 2019-06-29 22:32:50 --> Helper loaded: form_helper
INFO - 2019-06-29 22:32:50 --> Form Validation Class Initialized
DEBUG - 2019-06-29 22:32:50 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-29 22:32:50 --> Model Class Initialized
INFO - 2019-06-29 22:32:50 --> Model Class Initialized
INFO - 2019-06-29 22:32:50 --> Final output sent to browser
DEBUG - 2019-06-29 22:32:50 --> Total execution time: 0.4693
INFO - 2019-06-29 16:34:02 --> Config Class Initialized
INFO - 2019-06-29 16:34:02 --> Hooks Class Initialized
DEBUG - 2019-06-29 16:34:02 --> UTF-8 Support Enabled
INFO - 2019-06-29 16:34:02 --> Utf8 Class Initialized
INFO - 2019-06-29 16:34:02 --> URI Class Initialized
INFO - 2019-06-29 16:34:02 --> Router Class Initialized
INFO - 2019-06-29 16:34:02 --> Output Class Initialized
INFO - 2019-06-29 16:34:02 --> Security Class Initialized
DEBUG - 2019-06-29 16:34:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 16:34:02 --> Input Class Initialized
INFO - 2019-06-29 16:34:02 --> Language Class Initialized
INFO - 2019-06-29 16:34:02 --> Language Class Initialized
INFO - 2019-06-29 16:34:02 --> Config Class Initialized
INFO - 2019-06-29 16:34:02 --> Loader Class Initialized
DEBUG - 2019-06-29 16:34:02 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 16:34:02 --> Helper loaded: url_helper
INFO - 2019-06-29 16:34:02 --> Helper loaded: inflector_helper
INFO - 2019-06-29 16:34:02 --> Helper loaded: string_helper
INFO - 2019-06-29 16:34:02 --> Helper loaded: array_helper
INFO - 2019-06-29 16:34:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 16:34:02 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 16:34:02 --> Database Driver Class Initialized
INFO - 2019-06-29 16:34:02 --> Controller Class Initialized
INFO - 2019-06-29 22:34:02 --> Helper loaded: language_helper
INFO - 2019-06-29 22:34:02 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 22:34:02 --> Model Class Initialized
INFO - 2019-06-29 22:34:02 --> Model Class Initialized
INFO - 2019-06-29 22:34:02 --> Model Class Initialized
INFO - 2019-06-29 22:34:02 --> Model Class Initialized
INFO - 2019-06-29 22:34:02 --> Helper loaded: form_helper
INFO - 2019-06-29 22:34:02 --> Form Validation Class Initialized
DEBUG - 2019-06-29 22:34:02 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-06-29 22:34:02 --> Model Class Initialized
INFO - 2019-06-29 22:34:02 --> Model Class Initialized
INFO - 2019-06-29 22:34:02 --> Final output sent to browser
DEBUG - 2019-06-29 22:34:02 --> Total execution time: 0.4189
INFO - 2019-06-29 16:34:09 --> Config Class Initialized
INFO - 2019-06-29 16:34:09 --> Hooks Class Initialized
DEBUG - 2019-06-29 16:34:09 --> UTF-8 Support Enabled
INFO - 2019-06-29 16:34:09 --> Utf8 Class Initialized
INFO - 2019-06-29 16:34:09 --> URI Class Initialized
INFO - 2019-06-29 16:34:09 --> Router Class Initialized
INFO - 2019-06-29 16:34:09 --> Output Class Initialized
INFO - 2019-06-29 16:34:09 --> Security Class Initialized
DEBUG - 2019-06-29 16:34:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 16:34:09 --> Input Class Initialized
INFO - 2019-06-29 16:34:09 --> Language Class Initialized
INFO - 2019-06-29 16:34:09 --> Language Class Initialized
INFO - 2019-06-29 16:34:09 --> Config Class Initialized
INFO - 2019-06-29 16:34:09 --> Loader Class Initialized
DEBUG - 2019-06-29 16:34:09 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 16:34:09 --> Helper loaded: url_helper
INFO - 2019-06-29 16:34:09 --> Helper loaded: inflector_helper
INFO - 2019-06-29 16:34:09 --> Helper loaded: string_helper
INFO - 2019-06-29 16:34:09 --> Helper loaded: array_helper
INFO - 2019-06-29 16:34:09 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 16:34:09 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 16:34:09 --> Database Driver Class Initialized
INFO - 2019-06-29 16:34:09 --> Controller Class Initialized
INFO - 2019-06-29 22:34:09 --> Helper loaded: language_helper
INFO - 2019-06-29 22:34:09 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 22:34:09 --> Model Class Initialized
INFO - 2019-06-29 22:34:09 --> Model Class Initialized
INFO - 2019-06-29 22:34:09 --> Model Class Initialized
INFO - 2019-06-29 22:34:09 --> Model Class Initialized
INFO - 2019-06-29 22:34:09 --> Final output sent to browser
DEBUG - 2019-06-29 22:34:09 --> Total execution time: 0.3867
INFO - 2019-06-29 16:34:09 --> Config Class Initialized
INFO - 2019-06-29 16:34:09 --> Hooks Class Initialized
DEBUG - 2019-06-29 16:34:09 --> UTF-8 Support Enabled
INFO - 2019-06-29 16:34:09 --> Utf8 Class Initialized
INFO - 2019-06-29 16:34:09 --> URI Class Initialized
INFO - 2019-06-29 16:34:09 --> Router Class Initialized
INFO - 2019-06-29 16:34:09 --> Output Class Initialized
INFO - 2019-06-29 16:34:09 --> Security Class Initialized
DEBUG - 2019-06-29 16:34:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 16:34:09 --> Input Class Initialized
INFO - 2019-06-29 16:34:09 --> Language Class Initialized
INFO - 2019-06-29 16:34:09 --> Language Class Initialized
INFO - 2019-06-29 16:34:09 --> Config Class Initialized
INFO - 2019-06-29 16:34:09 --> Loader Class Initialized
DEBUG - 2019-06-29 16:34:09 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 16:34:09 --> Helper loaded: url_helper
INFO - 2019-06-29 16:34:09 --> Helper loaded: inflector_helper
INFO - 2019-06-29 16:34:09 --> Helper loaded: string_helper
INFO - 2019-06-29 16:34:09 --> Helper loaded: array_helper
INFO - 2019-06-29 16:34:09 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 16:34:09 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 16:34:09 --> Database Driver Class Initialized
INFO - 2019-06-29 16:34:09 --> Controller Class Initialized
INFO - 2019-06-29 22:34:09 --> Helper loaded: language_helper
INFO - 2019-06-29 22:34:09 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 22:34:09 --> Model Class Initialized
INFO - 2019-06-29 22:34:09 --> Model Class Initialized
INFO - 2019-06-29 22:34:09 --> Model Class Initialized
INFO - 2019-06-29 22:34:09 --> Model Class Initialized
INFO - 2019-06-29 22:34:10 --> Model Class Initialized
INFO - 2019-06-29 22:34:10 --> Final output sent to browser
DEBUG - 2019-06-29 22:34:10 --> Total execution time: 0.3547
INFO - 2019-06-29 16:34:49 --> Config Class Initialized
INFO - 2019-06-29 16:34:49 --> Hooks Class Initialized
DEBUG - 2019-06-29 16:34:49 --> UTF-8 Support Enabled
INFO - 2019-06-29 16:34:49 --> Utf8 Class Initialized
INFO - 2019-06-29 16:34:49 --> URI Class Initialized
INFO - 2019-06-29 16:34:49 --> Router Class Initialized
INFO - 2019-06-29 16:34:49 --> Output Class Initialized
INFO - 2019-06-29 16:34:49 --> Security Class Initialized
DEBUG - 2019-06-29 16:34:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 16:34:49 --> Input Class Initialized
INFO - 2019-06-29 16:34:49 --> Language Class Initialized
INFO - 2019-06-29 16:34:49 --> Language Class Initialized
INFO - 2019-06-29 16:34:49 --> Config Class Initialized
INFO - 2019-06-29 16:34:49 --> Loader Class Initialized
DEBUG - 2019-06-29 16:34:49 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 16:34:49 --> Helper loaded: url_helper
INFO - 2019-06-29 16:34:49 --> Helper loaded: inflector_helper
INFO - 2019-06-29 16:34:49 --> Helper loaded: string_helper
INFO - 2019-06-29 16:34:49 --> Helper loaded: array_helper
INFO - 2019-06-29 16:34:49 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 16:34:49 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 16:34:49 --> Database Driver Class Initialized
INFO - 2019-06-29 16:34:50 --> Controller Class Initialized
INFO - 2019-06-29 22:34:50 --> Helper loaded: language_helper
INFO - 2019-06-29 22:34:50 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 22:34:50 --> Model Class Initialized
INFO - 2019-06-29 22:34:50 --> Model Class Initialized
INFO - 2019-06-29 22:34:50 --> Model Class Initialized
INFO - 2019-06-29 22:34:50 --> Model Class Initialized
INFO - 2019-06-29 22:34:50 --> Final output sent to browser
DEBUG - 2019-06-29 22:34:50 --> Total execution time: 0.4876
INFO - 2019-06-29 16:34:53 --> Config Class Initialized
INFO - 2019-06-29 16:34:53 --> Hooks Class Initialized
DEBUG - 2019-06-29 16:34:53 --> UTF-8 Support Enabled
INFO - 2019-06-29 16:34:53 --> Utf8 Class Initialized
INFO - 2019-06-29 16:34:53 --> URI Class Initialized
INFO - 2019-06-29 16:34:53 --> Router Class Initialized
INFO - 2019-06-29 16:34:53 --> Output Class Initialized
INFO - 2019-06-29 16:34:53 --> Security Class Initialized
DEBUG - 2019-06-29 16:34:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 16:34:53 --> Input Class Initialized
INFO - 2019-06-29 16:34:53 --> Language Class Initialized
INFO - 2019-06-29 16:34:53 --> Language Class Initialized
INFO - 2019-06-29 16:34:53 --> Config Class Initialized
INFO - 2019-06-29 16:34:53 --> Loader Class Initialized
DEBUG - 2019-06-29 16:34:53 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 16:34:53 --> Helper loaded: url_helper
INFO - 2019-06-29 16:34:53 --> Helper loaded: inflector_helper
INFO - 2019-06-29 16:34:53 --> Helper loaded: string_helper
INFO - 2019-06-29 16:34:53 --> Helper loaded: array_helper
INFO - 2019-06-29 16:34:53 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 16:34:53 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 16:34:53 --> Database Driver Class Initialized
INFO - 2019-06-29 16:34:53 --> Controller Class Initialized
INFO - 2019-06-29 22:34:53 --> Helper loaded: language_helper
INFO - 2019-06-29 22:34:53 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 22:34:53 --> Model Class Initialized
INFO - 2019-06-29 22:34:53 --> Model Class Initialized
INFO - 2019-06-29 22:34:53 --> Model Class Initialized
INFO - 2019-06-29 22:34:53 --> Model Class Initialized
INFO - 2019-06-29 22:34:53 --> Final output sent to browser
DEBUG - 2019-06-29 22:34:53 --> Total execution time: 0.4115
INFO - 2019-06-29 16:35:10 --> Config Class Initialized
INFO - 2019-06-29 16:35:10 --> Hooks Class Initialized
DEBUG - 2019-06-29 16:35:10 --> UTF-8 Support Enabled
INFO - 2019-06-29 16:35:10 --> Utf8 Class Initialized
INFO - 2019-06-29 16:35:10 --> URI Class Initialized
INFO - 2019-06-29 16:35:10 --> Router Class Initialized
INFO - 2019-06-29 16:35:10 --> Output Class Initialized
INFO - 2019-06-29 16:35:10 --> Security Class Initialized
DEBUG - 2019-06-29 16:35:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 16:35:10 --> Input Class Initialized
INFO - 2019-06-29 16:35:10 --> Language Class Initialized
INFO - 2019-06-29 16:35:10 --> Language Class Initialized
INFO - 2019-06-29 16:35:10 --> Config Class Initialized
INFO - 2019-06-29 16:35:10 --> Loader Class Initialized
DEBUG - 2019-06-29 16:35:10 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 16:35:10 --> Helper loaded: url_helper
INFO - 2019-06-29 16:35:10 --> Helper loaded: inflector_helper
INFO - 2019-06-29 16:35:10 --> Helper loaded: string_helper
INFO - 2019-06-29 16:35:10 --> Helper loaded: array_helper
INFO - 2019-06-29 16:35:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 16:35:10 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 16:35:10 --> Database Driver Class Initialized
INFO - 2019-06-29 16:35:10 --> Controller Class Initialized
INFO - 2019-06-29 22:35:10 --> Helper loaded: language_helper
INFO - 2019-06-29 22:35:10 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 22:35:10 --> Model Class Initialized
INFO - 2019-06-29 22:35:10 --> Model Class Initialized
INFO - 2019-06-29 22:35:11 --> Model Class Initialized
INFO - 2019-06-29 22:35:11 --> Model Class Initialized
INFO - 2019-06-29 22:35:11 --> Final output sent to browser
DEBUG - 2019-06-29 22:35:11 --> Total execution time: 0.4234
INFO - 2019-06-29 16:35:11 --> Config Class Initialized
INFO - 2019-06-29 16:35:11 --> Hooks Class Initialized
DEBUG - 2019-06-29 16:35:11 --> UTF-8 Support Enabled
INFO - 2019-06-29 16:35:11 --> Utf8 Class Initialized
INFO - 2019-06-29 16:35:11 --> URI Class Initialized
INFO - 2019-06-29 16:35:11 --> Router Class Initialized
INFO - 2019-06-29 16:35:11 --> Output Class Initialized
INFO - 2019-06-29 16:35:11 --> Security Class Initialized
DEBUG - 2019-06-29 16:35:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 16:35:11 --> Input Class Initialized
INFO - 2019-06-29 16:35:11 --> Language Class Initialized
INFO - 2019-06-29 16:35:11 --> Language Class Initialized
INFO - 2019-06-29 16:35:11 --> Config Class Initialized
INFO - 2019-06-29 16:35:11 --> Loader Class Initialized
DEBUG - 2019-06-29 16:35:11 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 16:35:11 --> Helper loaded: url_helper
INFO - 2019-06-29 16:35:11 --> Helper loaded: inflector_helper
INFO - 2019-06-29 16:35:11 --> Helper loaded: string_helper
INFO - 2019-06-29 16:35:11 --> Helper loaded: array_helper
INFO - 2019-06-29 16:35:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 16:35:11 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 16:35:11 --> Database Driver Class Initialized
INFO - 2019-06-29 16:35:11 --> Controller Class Initialized
INFO - 2019-06-29 22:35:11 --> Helper loaded: language_helper
INFO - 2019-06-29 22:35:11 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 22:35:11 --> Model Class Initialized
INFO - 2019-06-29 22:35:11 --> Model Class Initialized
INFO - 2019-06-29 22:35:11 --> Model Class Initialized
INFO - 2019-06-29 22:35:11 --> Model Class Initialized
INFO - 2019-06-29 22:35:11 --> Model Class Initialized
INFO - 2019-06-29 22:35:11 --> Final output sent to browser
DEBUG - 2019-06-29 22:35:11 --> Total execution time: 0.4596
INFO - 2019-06-29 16:35:16 --> Config Class Initialized
INFO - 2019-06-29 16:35:16 --> Hooks Class Initialized
DEBUG - 2019-06-29 16:35:16 --> UTF-8 Support Enabled
INFO - 2019-06-29 16:35:16 --> Utf8 Class Initialized
INFO - 2019-06-29 16:35:16 --> URI Class Initialized
INFO - 2019-06-29 16:35:16 --> Router Class Initialized
INFO - 2019-06-29 16:35:16 --> Output Class Initialized
INFO - 2019-06-29 16:35:16 --> Security Class Initialized
DEBUG - 2019-06-29 16:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 16:35:16 --> Input Class Initialized
INFO - 2019-06-29 16:35:16 --> Language Class Initialized
INFO - 2019-06-29 16:35:16 --> Language Class Initialized
INFO - 2019-06-29 16:35:16 --> Config Class Initialized
INFO - 2019-06-29 16:35:16 --> Loader Class Initialized
DEBUG - 2019-06-29 16:35:16 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 16:35:16 --> Helper loaded: url_helper
INFO - 2019-06-29 16:35:16 --> Helper loaded: inflector_helper
INFO - 2019-06-29 16:35:16 --> Helper loaded: string_helper
INFO - 2019-06-29 16:35:16 --> Helper loaded: array_helper
INFO - 2019-06-29 16:35:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 16:35:16 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 16:35:16 --> Database Driver Class Initialized
INFO - 2019-06-29 16:35:16 --> Controller Class Initialized
INFO - 2019-06-29 22:35:16 --> Helper loaded: language_helper
INFO - 2019-06-29 22:35:16 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 22:35:16 --> Model Class Initialized
INFO - 2019-06-29 22:35:16 --> Model Class Initialized
INFO - 2019-06-29 22:35:16 --> Model Class Initialized
INFO - 2019-06-29 22:35:16 --> Model Class Initialized
INFO - 2019-06-29 22:35:16 --> Model Class Initialized
INFO - 2019-06-29 22:35:16 --> Final output sent to browser
DEBUG - 2019-06-29 22:35:16 --> Total execution time: 0.4684
INFO - 2019-06-29 16:35:18 --> Config Class Initialized
INFO - 2019-06-29 16:35:18 --> Hooks Class Initialized
DEBUG - 2019-06-29 16:35:18 --> UTF-8 Support Enabled
INFO - 2019-06-29 16:35:18 --> Utf8 Class Initialized
INFO - 2019-06-29 16:35:18 --> URI Class Initialized
INFO - 2019-06-29 16:35:18 --> Router Class Initialized
INFO - 2019-06-29 16:35:18 --> Output Class Initialized
INFO - 2019-06-29 16:35:18 --> Security Class Initialized
DEBUG - 2019-06-29 16:35:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 16:35:18 --> Input Class Initialized
INFO - 2019-06-29 16:35:18 --> Language Class Initialized
INFO - 2019-06-29 16:35:18 --> Language Class Initialized
INFO - 2019-06-29 16:35:18 --> Config Class Initialized
INFO - 2019-06-29 16:35:18 --> Loader Class Initialized
DEBUG - 2019-06-29 16:35:18 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 16:35:18 --> Helper loaded: url_helper
INFO - 2019-06-29 16:35:18 --> Helper loaded: inflector_helper
INFO - 2019-06-29 16:35:18 --> Helper loaded: string_helper
INFO - 2019-06-29 16:35:18 --> Helper loaded: array_helper
INFO - 2019-06-29 16:35:18 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 16:35:18 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 16:35:18 --> Database Driver Class Initialized
INFO - 2019-06-29 16:35:18 --> Controller Class Initialized
INFO - 2019-06-29 22:35:18 --> Helper loaded: language_helper
INFO - 2019-06-29 22:35:18 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 22:35:18 --> Model Class Initialized
INFO - 2019-06-29 22:35:18 --> Model Class Initialized
INFO - 2019-06-29 22:35:18 --> Model Class Initialized
INFO - 2019-06-29 22:35:18 --> Model Class Initialized
INFO - 2019-06-29 22:35:18 --> Final output sent to browser
DEBUG - 2019-06-29 22:35:18 --> Total execution time: 0.3834
INFO - 2019-06-29 16:45:28 --> Config Class Initialized
INFO - 2019-06-29 16:45:28 --> Hooks Class Initialized
DEBUG - 2019-06-29 16:45:28 --> UTF-8 Support Enabled
INFO - 2019-06-29 16:45:28 --> Utf8 Class Initialized
INFO - 2019-06-29 16:45:28 --> URI Class Initialized
INFO - 2019-06-29 16:45:28 --> Router Class Initialized
INFO - 2019-06-29 16:45:28 --> Output Class Initialized
INFO - 2019-06-29 16:45:28 --> Security Class Initialized
DEBUG - 2019-06-29 16:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 16:45:28 --> Input Class Initialized
INFO - 2019-06-29 16:45:28 --> Language Class Initialized
INFO - 2019-06-29 16:45:28 --> Language Class Initialized
INFO - 2019-06-29 16:45:28 --> Config Class Initialized
INFO - 2019-06-29 16:45:28 --> Loader Class Initialized
DEBUG - 2019-06-29 16:45:28 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 16:45:28 --> Helper loaded: url_helper
INFO - 2019-06-29 16:45:28 --> Helper loaded: inflector_helper
INFO - 2019-06-29 16:45:28 --> Helper loaded: string_helper
INFO - 2019-06-29 16:45:28 --> Helper loaded: array_helper
INFO - 2019-06-29 16:45:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 16:45:28 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 16:45:28 --> Database Driver Class Initialized
INFO - 2019-06-29 16:45:28 --> Controller Class Initialized
INFO - 2019-06-29 22:45:28 --> Helper loaded: language_helper
INFO - 2019-06-29 22:45:28 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 22:45:28 --> Model Class Initialized
INFO - 2019-06-29 22:45:28 --> Model Class Initialized
INFO - 2019-06-29 22:45:28 --> Model Class Initialized
INFO - 2019-06-29 22:45:28 --> Model Class Initialized
INFO - 2019-06-29 22:45:28 --> Final output sent to browser
DEBUG - 2019-06-29 22:45:28 --> Total execution time: 0.3527
INFO - 2019-06-29 16:45:29 --> Config Class Initialized
INFO - 2019-06-29 16:45:29 --> Hooks Class Initialized
DEBUG - 2019-06-29 16:45:29 --> UTF-8 Support Enabled
INFO - 2019-06-29 16:45:29 --> Utf8 Class Initialized
INFO - 2019-06-29 16:45:29 --> URI Class Initialized
INFO - 2019-06-29 16:45:29 --> Router Class Initialized
INFO - 2019-06-29 16:45:29 --> Output Class Initialized
INFO - 2019-06-29 16:45:29 --> Security Class Initialized
DEBUG - 2019-06-29 16:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 16:45:29 --> Input Class Initialized
INFO - 2019-06-29 16:45:29 --> Language Class Initialized
INFO - 2019-06-29 16:45:29 --> Language Class Initialized
INFO - 2019-06-29 16:45:29 --> Config Class Initialized
INFO - 2019-06-29 16:45:29 --> Loader Class Initialized
DEBUG - 2019-06-29 16:45:29 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 16:45:29 --> Helper loaded: url_helper
INFO - 2019-06-29 16:45:29 --> Helper loaded: inflector_helper
INFO - 2019-06-29 16:45:29 --> Helper loaded: string_helper
INFO - 2019-06-29 16:45:29 --> Helper loaded: array_helper
INFO - 2019-06-29 16:45:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 16:45:29 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 16:45:29 --> Database Driver Class Initialized
INFO - 2019-06-29 16:45:29 --> Controller Class Initialized
INFO - 2019-06-29 22:45:29 --> Helper loaded: language_helper
INFO - 2019-06-29 22:45:29 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 22:45:29 --> Model Class Initialized
INFO - 2019-06-29 22:45:29 --> Model Class Initialized
INFO - 2019-06-29 22:45:29 --> Model Class Initialized
INFO - 2019-06-29 22:45:29 --> Model Class Initialized
INFO - 2019-06-29 22:45:29 --> Model Class Initialized
INFO - 2019-06-29 22:45:29 --> Final output sent to browser
DEBUG - 2019-06-29 22:45:29 --> Total execution time: 0.3701
INFO - 2019-06-29 16:45:32 --> Config Class Initialized
INFO - 2019-06-29 16:45:32 --> Hooks Class Initialized
DEBUG - 2019-06-29 16:45:32 --> UTF-8 Support Enabled
INFO - 2019-06-29 16:45:32 --> Utf8 Class Initialized
INFO - 2019-06-29 16:45:32 --> URI Class Initialized
INFO - 2019-06-29 16:45:32 --> Router Class Initialized
INFO - 2019-06-29 16:45:32 --> Output Class Initialized
INFO - 2019-06-29 16:45:32 --> Security Class Initialized
DEBUG - 2019-06-29 16:45:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 16:45:32 --> Input Class Initialized
INFO - 2019-06-29 16:45:32 --> Language Class Initialized
INFO - 2019-06-29 16:45:32 --> Language Class Initialized
INFO - 2019-06-29 16:45:32 --> Config Class Initialized
INFO - 2019-06-29 16:45:32 --> Loader Class Initialized
DEBUG - 2019-06-29 16:45:32 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 16:45:32 --> Helper loaded: url_helper
INFO - 2019-06-29 16:45:32 --> Helper loaded: inflector_helper
INFO - 2019-06-29 16:45:32 --> Helper loaded: string_helper
INFO - 2019-06-29 16:45:32 --> Helper loaded: array_helper
INFO - 2019-06-29 16:45:32 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 16:45:32 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 16:45:32 --> Database Driver Class Initialized
INFO - 2019-06-29 16:45:32 --> Controller Class Initialized
INFO - 2019-06-29 22:45:32 --> Helper loaded: language_helper
INFO - 2019-06-29 22:45:32 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 22:45:32 --> Model Class Initialized
INFO - 2019-06-29 22:45:32 --> Model Class Initialized
INFO - 2019-06-29 22:45:32 --> Model Class Initialized
INFO - 2019-06-29 22:45:32 --> Model Class Initialized
INFO - 2019-06-29 22:45:32 --> Final output sent to browser
DEBUG - 2019-06-29 22:45:32 --> Total execution time: 0.4535
INFO - 2019-06-29 16:45:35 --> Config Class Initialized
INFO - 2019-06-29 16:45:35 --> Hooks Class Initialized
DEBUG - 2019-06-29 16:45:35 --> UTF-8 Support Enabled
INFO - 2019-06-29 16:45:35 --> Utf8 Class Initialized
INFO - 2019-06-29 16:45:35 --> URI Class Initialized
INFO - 2019-06-29 16:45:35 --> Router Class Initialized
INFO - 2019-06-29 16:45:35 --> Output Class Initialized
INFO - 2019-06-29 16:45:35 --> Security Class Initialized
DEBUG - 2019-06-29 16:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 16:45:35 --> Input Class Initialized
INFO - 2019-06-29 16:45:35 --> Language Class Initialized
INFO - 2019-06-29 16:45:35 --> Language Class Initialized
INFO - 2019-06-29 16:45:35 --> Config Class Initialized
INFO - 2019-06-29 16:45:35 --> Loader Class Initialized
DEBUG - 2019-06-29 16:45:35 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 16:45:35 --> Helper loaded: url_helper
INFO - 2019-06-29 16:45:35 --> Helper loaded: inflector_helper
INFO - 2019-06-29 16:45:35 --> Helper loaded: string_helper
INFO - 2019-06-29 16:45:35 --> Helper loaded: array_helper
INFO - 2019-06-29 16:45:35 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 16:45:35 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 16:45:35 --> Database Driver Class Initialized
INFO - 2019-06-29 16:45:35 --> Controller Class Initialized
INFO - 2019-06-29 22:45:35 --> Helper loaded: language_helper
INFO - 2019-06-29 22:45:35 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 22:45:35 --> Model Class Initialized
INFO - 2019-06-29 22:45:35 --> Model Class Initialized
INFO - 2019-06-29 22:45:35 --> Model Class Initialized
INFO - 2019-06-29 22:45:35 --> Model Class Initialized
INFO - 2019-06-29 22:45:35 --> Final output sent to browser
DEBUG - 2019-06-29 22:45:35 --> Total execution time: 0.3453
INFO - 2019-06-29 16:45:48 --> Config Class Initialized
INFO - 2019-06-29 16:45:48 --> Hooks Class Initialized
DEBUG - 2019-06-29 16:45:48 --> UTF-8 Support Enabled
INFO - 2019-06-29 16:45:48 --> Utf8 Class Initialized
INFO - 2019-06-29 16:45:48 --> URI Class Initialized
INFO - 2019-06-29 16:45:48 --> Router Class Initialized
INFO - 2019-06-29 16:45:48 --> Output Class Initialized
INFO - 2019-06-29 16:45:48 --> Security Class Initialized
DEBUG - 2019-06-29 16:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 16:45:48 --> Input Class Initialized
INFO - 2019-06-29 16:45:48 --> Language Class Initialized
INFO - 2019-06-29 16:45:48 --> Language Class Initialized
INFO - 2019-06-29 16:45:48 --> Config Class Initialized
INFO - 2019-06-29 16:45:49 --> Loader Class Initialized
DEBUG - 2019-06-29 16:45:49 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 16:45:49 --> Helper loaded: url_helper
INFO - 2019-06-29 16:45:49 --> Helper loaded: inflector_helper
INFO - 2019-06-29 16:45:49 --> Helper loaded: string_helper
INFO - 2019-06-29 16:45:49 --> Helper loaded: array_helper
INFO - 2019-06-29 16:45:49 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 16:45:49 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 16:45:49 --> Database Driver Class Initialized
INFO - 2019-06-29 16:45:49 --> Controller Class Initialized
INFO - 2019-06-29 22:45:49 --> Helper loaded: language_helper
INFO - 2019-06-29 22:45:49 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 22:45:49 --> Model Class Initialized
INFO - 2019-06-29 22:45:49 --> Model Class Initialized
INFO - 2019-06-29 22:45:49 --> Model Class Initialized
INFO - 2019-06-29 22:45:49 --> Model Class Initialized
INFO - 2019-06-29 22:45:49 --> Final output sent to browser
DEBUG - 2019-06-29 22:45:49 --> Total execution time: 0.3789
INFO - 2019-06-29 16:45:49 --> Config Class Initialized
INFO - 2019-06-29 16:45:49 --> Hooks Class Initialized
DEBUG - 2019-06-29 16:45:49 --> UTF-8 Support Enabled
INFO - 2019-06-29 16:45:49 --> Utf8 Class Initialized
INFO - 2019-06-29 16:45:49 --> URI Class Initialized
INFO - 2019-06-29 16:45:49 --> Router Class Initialized
INFO - 2019-06-29 16:45:49 --> Output Class Initialized
INFO - 2019-06-29 16:45:49 --> Security Class Initialized
DEBUG - 2019-06-29 16:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 16:45:49 --> Input Class Initialized
INFO - 2019-06-29 16:45:49 --> Language Class Initialized
INFO - 2019-06-29 16:45:49 --> Language Class Initialized
INFO - 2019-06-29 16:45:49 --> Config Class Initialized
INFO - 2019-06-29 16:45:49 --> Loader Class Initialized
DEBUG - 2019-06-29 16:45:49 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 16:45:49 --> Helper loaded: url_helper
INFO - 2019-06-29 16:45:49 --> Helper loaded: inflector_helper
INFO - 2019-06-29 16:45:49 --> Helper loaded: string_helper
INFO - 2019-06-29 16:45:49 --> Helper loaded: array_helper
INFO - 2019-06-29 16:45:49 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 16:45:49 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 16:45:49 --> Database Driver Class Initialized
INFO - 2019-06-29 16:45:49 --> Controller Class Initialized
INFO - 2019-06-29 22:45:49 --> Helper loaded: language_helper
INFO - 2019-06-29 22:45:49 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 22:45:49 --> Model Class Initialized
INFO - 2019-06-29 22:45:49 --> Model Class Initialized
INFO - 2019-06-29 22:45:49 --> Model Class Initialized
INFO - 2019-06-29 22:45:49 --> Model Class Initialized
INFO - 2019-06-29 22:45:49 --> Model Class Initialized
INFO - 2019-06-29 22:45:49 --> Final output sent to browser
DEBUG - 2019-06-29 22:45:49 --> Total execution time: 0.3740
INFO - 2019-06-29 16:45:53 --> Config Class Initialized
INFO - 2019-06-29 16:45:53 --> Hooks Class Initialized
DEBUG - 2019-06-29 16:45:53 --> UTF-8 Support Enabled
INFO - 2019-06-29 16:45:53 --> Utf8 Class Initialized
INFO - 2019-06-29 16:45:53 --> URI Class Initialized
INFO - 2019-06-29 16:45:53 --> Router Class Initialized
INFO - 2019-06-29 16:45:53 --> Output Class Initialized
INFO - 2019-06-29 16:45:53 --> Security Class Initialized
DEBUG - 2019-06-29 16:45:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 16:45:53 --> Input Class Initialized
INFO - 2019-06-29 16:45:53 --> Language Class Initialized
INFO - 2019-06-29 16:45:53 --> Language Class Initialized
INFO - 2019-06-29 16:45:53 --> Config Class Initialized
INFO - 2019-06-29 16:45:53 --> Loader Class Initialized
DEBUG - 2019-06-29 16:45:53 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 16:45:53 --> Helper loaded: url_helper
INFO - 2019-06-29 16:45:53 --> Helper loaded: inflector_helper
INFO - 2019-06-29 16:45:53 --> Helper loaded: string_helper
INFO - 2019-06-29 16:45:53 --> Helper loaded: array_helper
INFO - 2019-06-29 16:45:53 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 16:45:53 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 16:45:53 --> Database Driver Class Initialized
INFO - 2019-06-29 16:45:54 --> Controller Class Initialized
INFO - 2019-06-29 22:45:54 --> Helper loaded: language_helper
INFO - 2019-06-29 22:45:54 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 22:45:54 --> Model Class Initialized
INFO - 2019-06-29 22:45:54 --> Model Class Initialized
INFO - 2019-06-29 22:45:54 --> Model Class Initialized
INFO - 2019-06-29 22:45:54 --> Model Class Initialized
INFO - 2019-06-29 22:45:54 --> Final output sent to browser
DEBUG - 2019-06-29 22:45:54 --> Total execution time: 0.4082
INFO - 2019-06-29 16:45:55 --> Config Class Initialized
INFO - 2019-06-29 16:45:55 --> Hooks Class Initialized
DEBUG - 2019-06-29 16:45:55 --> UTF-8 Support Enabled
INFO - 2019-06-29 16:45:55 --> Utf8 Class Initialized
INFO - 2019-06-29 16:45:55 --> URI Class Initialized
INFO - 2019-06-29 16:45:55 --> Router Class Initialized
INFO - 2019-06-29 16:45:55 --> Output Class Initialized
INFO - 2019-06-29 16:45:55 --> Security Class Initialized
DEBUG - 2019-06-29 16:45:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 16:45:55 --> Input Class Initialized
INFO - 2019-06-29 16:45:55 --> Language Class Initialized
INFO - 2019-06-29 16:45:55 --> Language Class Initialized
INFO - 2019-06-29 16:45:55 --> Config Class Initialized
INFO - 2019-06-29 16:45:55 --> Loader Class Initialized
DEBUG - 2019-06-29 16:45:55 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 16:45:55 --> Helper loaded: url_helper
INFO - 2019-06-29 16:45:55 --> Helper loaded: inflector_helper
INFO - 2019-06-29 16:45:55 --> Helper loaded: string_helper
INFO - 2019-06-29 16:45:55 --> Helper loaded: array_helper
INFO - 2019-06-29 16:45:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 16:45:55 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 16:45:55 --> Database Driver Class Initialized
INFO - 2019-06-29 16:45:55 --> Controller Class Initialized
INFO - 2019-06-29 22:45:55 --> Helper loaded: language_helper
INFO - 2019-06-29 22:45:55 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 22:45:55 --> Model Class Initialized
INFO - 2019-06-29 22:45:55 --> Model Class Initialized
INFO - 2019-06-29 22:45:55 --> Model Class Initialized
INFO - 2019-06-29 22:45:55 --> Model Class Initialized
INFO - 2019-06-29 22:45:55 --> Final output sent to browser
DEBUG - 2019-06-29 22:45:55 --> Total execution time: 0.3928
INFO - 2019-06-29 16:45:56 --> Config Class Initialized
INFO - 2019-06-29 16:45:56 --> Hooks Class Initialized
DEBUG - 2019-06-29 16:45:56 --> UTF-8 Support Enabled
INFO - 2019-06-29 16:45:56 --> Utf8 Class Initialized
INFO - 2019-06-29 16:45:56 --> URI Class Initialized
INFO - 2019-06-29 16:45:56 --> Router Class Initialized
INFO - 2019-06-29 16:45:56 --> Output Class Initialized
INFO - 2019-06-29 16:45:56 --> Security Class Initialized
DEBUG - 2019-06-29 16:45:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 16:45:56 --> Input Class Initialized
INFO - 2019-06-29 16:45:56 --> Language Class Initialized
INFO - 2019-06-29 16:45:56 --> Language Class Initialized
INFO - 2019-06-29 16:45:56 --> Config Class Initialized
INFO - 2019-06-29 16:45:56 --> Loader Class Initialized
DEBUG - 2019-06-29 16:45:56 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 16:45:56 --> Helper loaded: url_helper
INFO - 2019-06-29 16:45:56 --> Helper loaded: inflector_helper
INFO - 2019-06-29 16:45:56 --> Helper loaded: string_helper
INFO - 2019-06-29 16:45:56 --> Helper loaded: array_helper
INFO - 2019-06-29 16:45:56 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 16:45:56 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 16:45:56 --> Database Driver Class Initialized
INFO - 2019-06-29 16:45:56 --> Controller Class Initialized
INFO - 2019-06-29 22:45:56 --> Helper loaded: language_helper
INFO - 2019-06-29 22:45:56 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 22:45:56 --> Model Class Initialized
INFO - 2019-06-29 22:45:56 --> Model Class Initialized
INFO - 2019-06-29 22:45:56 --> Model Class Initialized
INFO - 2019-06-29 22:45:56 --> Model Class Initialized
INFO - 2019-06-29 22:45:56 --> Final output sent to browser
DEBUG - 2019-06-29 22:45:56 --> Total execution time: 0.3815
INFO - 2019-06-29 16:45:57 --> Config Class Initialized
INFO - 2019-06-29 16:45:57 --> Hooks Class Initialized
DEBUG - 2019-06-29 16:45:57 --> UTF-8 Support Enabled
INFO - 2019-06-29 16:45:57 --> Utf8 Class Initialized
INFO - 2019-06-29 16:45:57 --> URI Class Initialized
INFO - 2019-06-29 16:45:57 --> Router Class Initialized
INFO - 2019-06-29 16:45:57 --> Output Class Initialized
INFO - 2019-06-29 16:45:57 --> Security Class Initialized
DEBUG - 2019-06-29 16:45:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 16:45:57 --> Input Class Initialized
INFO - 2019-06-29 16:45:57 --> Language Class Initialized
INFO - 2019-06-29 16:45:57 --> Language Class Initialized
INFO - 2019-06-29 16:45:58 --> Config Class Initialized
INFO - 2019-06-29 16:45:58 --> Loader Class Initialized
DEBUG - 2019-06-29 16:45:58 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 16:45:58 --> Helper loaded: url_helper
INFO - 2019-06-29 16:45:58 --> Helper loaded: inflector_helper
INFO - 2019-06-29 16:45:58 --> Helper loaded: string_helper
INFO - 2019-06-29 16:45:58 --> Helper loaded: array_helper
INFO - 2019-06-29 16:45:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 16:45:58 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 16:45:58 --> Database Driver Class Initialized
INFO - 2019-06-29 16:45:58 --> Controller Class Initialized
INFO - 2019-06-29 22:45:58 --> Helper loaded: language_helper
INFO - 2019-06-29 22:45:58 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 22:45:58 --> Model Class Initialized
INFO - 2019-06-29 22:45:58 --> Model Class Initialized
INFO - 2019-06-29 22:45:58 --> Model Class Initialized
INFO - 2019-06-29 22:45:58 --> Model Class Initialized
INFO - 2019-06-29 22:45:58 --> Final output sent to browser
DEBUG - 2019-06-29 22:45:58 --> Total execution time: 0.4141
INFO - 2019-06-29 16:45:58 --> Config Class Initialized
INFO - 2019-06-29 16:45:58 --> Hooks Class Initialized
DEBUG - 2019-06-29 16:45:58 --> UTF-8 Support Enabled
INFO - 2019-06-29 16:45:58 --> Utf8 Class Initialized
INFO - 2019-06-29 16:45:58 --> URI Class Initialized
INFO - 2019-06-29 16:45:58 --> Router Class Initialized
INFO - 2019-06-29 16:45:58 --> Output Class Initialized
INFO - 2019-06-29 16:45:58 --> Security Class Initialized
DEBUG - 2019-06-29 16:45:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 16:45:58 --> Input Class Initialized
INFO - 2019-06-29 16:45:58 --> Language Class Initialized
INFO - 2019-06-29 16:45:58 --> Language Class Initialized
INFO - 2019-06-29 16:45:58 --> Config Class Initialized
INFO - 2019-06-29 16:45:58 --> Loader Class Initialized
DEBUG - 2019-06-29 16:45:58 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 16:45:58 --> Helper loaded: url_helper
INFO - 2019-06-29 16:45:58 --> Helper loaded: inflector_helper
INFO - 2019-06-29 16:45:58 --> Helper loaded: string_helper
INFO - 2019-06-29 16:45:58 --> Helper loaded: array_helper
INFO - 2019-06-29 16:45:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 16:45:58 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 16:45:58 --> Database Driver Class Initialized
INFO - 2019-06-29 16:45:58 --> Controller Class Initialized
INFO - 2019-06-29 22:45:58 --> Helper loaded: language_helper
INFO - 2019-06-29 22:45:58 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 22:45:58 --> Model Class Initialized
INFO - 2019-06-29 22:45:58 --> Model Class Initialized
INFO - 2019-06-29 22:45:58 --> Model Class Initialized
INFO - 2019-06-29 22:45:58 --> Model Class Initialized
INFO - 2019-06-29 22:45:58 --> Final output sent to browser
DEBUG - 2019-06-29 22:45:58 --> Total execution time: 0.3842
INFO - 2019-06-29 16:45:59 --> Config Class Initialized
INFO - 2019-06-29 16:45:59 --> Hooks Class Initialized
DEBUG - 2019-06-29 16:46:00 --> UTF-8 Support Enabled
INFO - 2019-06-29 16:46:00 --> Utf8 Class Initialized
INFO - 2019-06-29 16:46:00 --> URI Class Initialized
INFO - 2019-06-29 16:46:00 --> Router Class Initialized
INFO - 2019-06-29 16:46:00 --> Output Class Initialized
INFO - 2019-06-29 16:46:00 --> Security Class Initialized
DEBUG - 2019-06-29 16:46:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 16:46:00 --> Input Class Initialized
INFO - 2019-06-29 16:46:00 --> Language Class Initialized
INFO - 2019-06-29 16:46:00 --> Language Class Initialized
INFO - 2019-06-29 16:46:00 --> Config Class Initialized
INFO - 2019-06-29 16:46:00 --> Loader Class Initialized
DEBUG - 2019-06-29 16:46:00 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 16:46:00 --> Helper loaded: url_helper
INFO - 2019-06-29 16:46:00 --> Helper loaded: inflector_helper
INFO - 2019-06-29 16:46:00 --> Helper loaded: string_helper
INFO - 2019-06-29 16:46:00 --> Helper loaded: array_helper
INFO - 2019-06-29 16:46:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 16:46:00 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 16:46:00 --> Database Driver Class Initialized
INFO - 2019-06-29 16:46:00 --> Controller Class Initialized
INFO - 2019-06-29 22:46:00 --> Helper loaded: language_helper
INFO - 2019-06-29 22:46:00 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 22:46:00 --> Model Class Initialized
INFO - 2019-06-29 22:46:00 --> Model Class Initialized
INFO - 2019-06-29 22:46:00 --> Model Class Initialized
INFO - 2019-06-29 22:46:00 --> Model Class Initialized
INFO - 2019-06-29 22:46:00 --> Final output sent to browser
DEBUG - 2019-06-29 22:46:00 --> Total execution time: 0.6333
INFO - 2019-06-29 16:46:01 --> Config Class Initialized
INFO - 2019-06-29 16:46:01 --> Hooks Class Initialized
DEBUG - 2019-06-29 16:46:01 --> UTF-8 Support Enabled
INFO - 2019-06-29 16:46:01 --> Utf8 Class Initialized
INFO - 2019-06-29 16:46:01 --> URI Class Initialized
INFO - 2019-06-29 16:46:01 --> Router Class Initialized
INFO - 2019-06-29 16:46:01 --> Output Class Initialized
INFO - 2019-06-29 16:46:02 --> Security Class Initialized
DEBUG - 2019-06-29 16:46:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 16:46:02 --> Input Class Initialized
INFO - 2019-06-29 16:46:02 --> Language Class Initialized
INFO - 2019-06-29 16:46:02 --> Language Class Initialized
INFO - 2019-06-29 16:46:02 --> Config Class Initialized
INFO - 2019-06-29 16:46:02 --> Loader Class Initialized
DEBUG - 2019-06-29 16:46:02 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 16:46:02 --> Helper loaded: url_helper
INFO - 2019-06-29 16:46:02 --> Helper loaded: inflector_helper
INFO - 2019-06-29 16:46:02 --> Helper loaded: string_helper
INFO - 2019-06-29 16:46:02 --> Helper loaded: array_helper
INFO - 2019-06-29 16:46:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 16:46:02 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 16:46:02 --> Database Driver Class Initialized
INFO - 2019-06-29 16:46:02 --> Controller Class Initialized
INFO - 2019-06-29 22:46:02 --> Helper loaded: language_helper
INFO - 2019-06-29 22:46:02 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 22:46:02 --> Model Class Initialized
INFO - 2019-06-29 22:46:02 --> Model Class Initialized
INFO - 2019-06-29 22:46:02 --> Model Class Initialized
INFO - 2019-06-29 22:46:02 --> Model Class Initialized
INFO - 2019-06-29 22:46:02 --> Final output sent to browser
DEBUG - 2019-06-29 22:46:02 --> Total execution time: 0.5338
INFO - 2019-06-29 16:46:12 --> Config Class Initialized
INFO - 2019-06-29 16:46:12 --> Hooks Class Initialized
DEBUG - 2019-06-29 16:46:12 --> UTF-8 Support Enabled
INFO - 2019-06-29 16:46:12 --> Utf8 Class Initialized
INFO - 2019-06-29 16:46:12 --> URI Class Initialized
INFO - 2019-06-29 16:46:12 --> Router Class Initialized
INFO - 2019-06-29 16:46:12 --> Output Class Initialized
INFO - 2019-06-29 16:46:12 --> Security Class Initialized
DEBUG - 2019-06-29 16:46:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 16:46:12 --> Input Class Initialized
INFO - 2019-06-29 16:46:12 --> Language Class Initialized
INFO - 2019-06-29 16:46:12 --> Language Class Initialized
INFO - 2019-06-29 16:46:12 --> Config Class Initialized
INFO - 2019-06-29 16:46:12 --> Loader Class Initialized
DEBUG - 2019-06-29 16:46:12 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 16:46:12 --> Helper loaded: url_helper
INFO - 2019-06-29 16:46:12 --> Helper loaded: inflector_helper
INFO - 2019-06-29 16:46:12 --> Helper loaded: string_helper
INFO - 2019-06-29 16:46:12 --> Helper loaded: array_helper
INFO - 2019-06-29 16:46:12 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 16:46:12 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 16:46:12 --> Database Driver Class Initialized
INFO - 2019-06-29 16:46:12 --> Controller Class Initialized
INFO - 2019-06-29 22:46:12 --> Helper loaded: language_helper
INFO - 2019-06-29 22:46:12 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 22:46:12 --> Model Class Initialized
INFO - 2019-06-29 22:46:12 --> Model Class Initialized
INFO - 2019-06-29 22:46:12 --> Model Class Initialized
INFO - 2019-06-29 22:46:12 --> Model Class Initialized
INFO - 2019-06-29 22:46:12 --> Final output sent to browser
DEBUG - 2019-06-29 22:46:12 --> Total execution time: 0.3418
INFO - 2019-06-29 16:52:58 --> Config Class Initialized
INFO - 2019-06-29 16:52:58 --> Hooks Class Initialized
DEBUG - 2019-06-29 16:52:58 --> UTF-8 Support Enabled
INFO - 2019-06-29 16:52:58 --> Utf8 Class Initialized
INFO - 2019-06-29 16:52:58 --> URI Class Initialized
INFO - 2019-06-29 16:52:58 --> Router Class Initialized
INFO - 2019-06-29 16:52:58 --> Output Class Initialized
INFO - 2019-06-29 16:52:58 --> Security Class Initialized
DEBUG - 2019-06-29 16:52:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 16:52:58 --> Input Class Initialized
INFO - 2019-06-29 16:52:58 --> Language Class Initialized
INFO - 2019-06-29 16:52:58 --> Language Class Initialized
INFO - 2019-06-29 16:52:58 --> Config Class Initialized
INFO - 2019-06-29 16:52:58 --> Loader Class Initialized
DEBUG - 2019-06-29 16:52:58 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 16:52:58 --> Helper loaded: url_helper
INFO - 2019-06-29 16:52:58 --> Helper loaded: inflector_helper
INFO - 2019-06-29 16:52:58 --> Helper loaded: string_helper
INFO - 2019-06-29 16:52:58 --> Helper loaded: array_helper
INFO - 2019-06-29 16:52:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 16:52:58 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 16:52:58 --> Database Driver Class Initialized
INFO - 2019-06-29 16:52:58 --> Controller Class Initialized
INFO - 2019-06-29 22:52:58 --> Helper loaded: language_helper
INFO - 2019-06-29 22:52:58 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 22:52:58 --> Model Class Initialized
INFO - 2019-06-29 22:52:58 --> Model Class Initialized
INFO - 2019-06-29 22:52:58 --> Model Class Initialized
INFO - 2019-06-29 22:52:58 --> Model Class Initialized
INFO - 2019-06-29 22:52:58 --> Final output sent to browser
DEBUG - 2019-06-29 22:52:58 --> Total execution time: 0.4492
INFO - 2019-06-29 16:53:28 --> Config Class Initialized
INFO - 2019-06-29 16:53:28 --> Hooks Class Initialized
DEBUG - 2019-06-29 16:53:28 --> UTF-8 Support Enabled
INFO - 2019-06-29 16:53:28 --> Utf8 Class Initialized
INFO - 2019-06-29 16:53:28 --> URI Class Initialized
INFO - 2019-06-29 16:53:28 --> Router Class Initialized
INFO - 2019-06-29 16:53:28 --> Output Class Initialized
INFO - 2019-06-29 16:53:28 --> Security Class Initialized
DEBUG - 2019-06-29 16:53:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 16:53:28 --> Input Class Initialized
INFO - 2019-06-29 16:53:28 --> Language Class Initialized
INFO - 2019-06-29 16:53:28 --> Language Class Initialized
INFO - 2019-06-29 16:53:28 --> Config Class Initialized
INFO - 2019-06-29 16:53:28 --> Loader Class Initialized
DEBUG - 2019-06-29 16:53:28 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 16:53:28 --> Helper loaded: url_helper
INFO - 2019-06-29 16:53:28 --> Helper loaded: inflector_helper
INFO - 2019-06-29 16:53:28 --> Helper loaded: string_helper
INFO - 2019-06-29 16:53:28 --> Helper loaded: array_helper
INFO - 2019-06-29 16:53:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 16:53:28 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 16:53:28 --> Database Driver Class Initialized
INFO - 2019-06-29 16:53:28 --> Controller Class Initialized
INFO - 2019-06-29 22:53:28 --> Helper loaded: language_helper
INFO - 2019-06-29 22:53:28 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 22:53:28 --> Model Class Initialized
INFO - 2019-06-29 22:53:28 --> Model Class Initialized
INFO - 2019-06-29 22:53:28 --> Model Class Initialized
INFO - 2019-06-29 22:53:28 --> Model Class Initialized
INFO - 2019-06-29 22:53:28 --> Final output sent to browser
DEBUG - 2019-06-29 22:53:28 --> Total execution time: 0.3927
INFO - 2019-06-29 16:53:33 --> Config Class Initialized
INFO - 2019-06-29 16:53:33 --> Hooks Class Initialized
DEBUG - 2019-06-29 16:53:33 --> UTF-8 Support Enabled
INFO - 2019-06-29 16:53:33 --> Utf8 Class Initialized
INFO - 2019-06-29 16:53:33 --> URI Class Initialized
INFO - 2019-06-29 16:53:33 --> Router Class Initialized
INFO - 2019-06-29 16:53:33 --> Output Class Initialized
INFO - 2019-06-29 16:53:33 --> Security Class Initialized
DEBUG - 2019-06-29 16:53:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 16:53:33 --> Input Class Initialized
INFO - 2019-06-29 16:53:33 --> Language Class Initialized
INFO - 2019-06-29 16:53:33 --> Language Class Initialized
INFO - 2019-06-29 16:53:33 --> Config Class Initialized
INFO - 2019-06-29 16:53:33 --> Loader Class Initialized
DEBUG - 2019-06-29 16:53:33 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 16:53:33 --> Helper loaded: url_helper
INFO - 2019-06-29 16:53:33 --> Helper loaded: inflector_helper
INFO - 2019-06-29 16:53:33 --> Helper loaded: string_helper
INFO - 2019-06-29 16:53:33 --> Helper loaded: array_helper
INFO - 2019-06-29 16:53:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 16:53:33 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 16:53:33 --> Database Driver Class Initialized
INFO - 2019-06-29 16:53:33 --> Controller Class Initialized
INFO - 2019-06-29 22:53:33 --> Helper loaded: language_helper
INFO - 2019-06-29 22:53:33 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 22:53:33 --> Model Class Initialized
INFO - 2019-06-29 22:53:33 --> Model Class Initialized
INFO - 2019-06-29 22:53:33 --> Model Class Initialized
INFO - 2019-06-29 22:53:33 --> Model Class Initialized
INFO - 2019-06-29 22:53:33 --> Final output sent to browser
DEBUG - 2019-06-29 22:53:33 --> Total execution time: 0.4460
INFO - 2019-06-29 16:54:00 --> Config Class Initialized
INFO - 2019-06-29 16:54:00 --> Hooks Class Initialized
DEBUG - 2019-06-29 16:54:00 --> UTF-8 Support Enabled
INFO - 2019-06-29 16:54:00 --> Utf8 Class Initialized
INFO - 2019-06-29 16:54:00 --> URI Class Initialized
INFO - 2019-06-29 16:54:00 --> Router Class Initialized
INFO - 2019-06-29 16:54:00 --> Output Class Initialized
INFO - 2019-06-29 16:54:00 --> Security Class Initialized
DEBUG - 2019-06-29 16:54:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 16:54:00 --> Input Class Initialized
INFO - 2019-06-29 16:54:00 --> Language Class Initialized
INFO - 2019-06-29 16:54:00 --> Language Class Initialized
INFO - 2019-06-29 16:54:00 --> Config Class Initialized
INFO - 2019-06-29 16:54:00 --> Loader Class Initialized
DEBUG - 2019-06-29 16:54:00 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 16:54:00 --> Helper loaded: url_helper
INFO - 2019-06-29 16:54:00 --> Helper loaded: inflector_helper
INFO - 2019-06-29 16:54:00 --> Helper loaded: string_helper
INFO - 2019-06-29 16:54:00 --> Helper loaded: array_helper
INFO - 2019-06-29 16:54:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 16:54:00 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 16:54:00 --> Database Driver Class Initialized
INFO - 2019-06-29 16:54:00 --> Controller Class Initialized
INFO - 2019-06-29 22:54:00 --> Helper loaded: language_helper
INFO - 2019-06-29 22:54:00 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 22:54:00 --> Model Class Initialized
INFO - 2019-06-29 22:54:00 --> Model Class Initialized
INFO - 2019-06-29 22:54:00 --> Model Class Initialized
INFO - 2019-06-29 22:54:00 --> Model Class Initialized
INFO - 2019-06-29 22:54:00 --> Final output sent to browser
DEBUG - 2019-06-29 22:54:00 --> Total execution time: 0.3916
INFO - 2019-06-29 16:54:00 --> Config Class Initialized
INFO - 2019-06-29 16:54:00 --> Hooks Class Initialized
DEBUG - 2019-06-29 16:54:00 --> UTF-8 Support Enabled
INFO - 2019-06-29 16:54:00 --> Utf8 Class Initialized
INFO - 2019-06-29 16:54:01 --> URI Class Initialized
INFO - 2019-06-29 16:54:01 --> Router Class Initialized
INFO - 2019-06-29 16:54:01 --> Output Class Initialized
INFO - 2019-06-29 16:54:01 --> Security Class Initialized
DEBUG - 2019-06-29 16:54:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 16:54:01 --> Input Class Initialized
INFO - 2019-06-29 16:54:01 --> Language Class Initialized
INFO - 2019-06-29 16:54:01 --> Language Class Initialized
INFO - 2019-06-29 16:54:01 --> Config Class Initialized
INFO - 2019-06-29 16:54:01 --> Loader Class Initialized
DEBUG - 2019-06-29 16:54:01 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 16:54:01 --> Helper loaded: url_helper
INFO - 2019-06-29 16:54:01 --> Helper loaded: inflector_helper
INFO - 2019-06-29 16:54:01 --> Helper loaded: string_helper
INFO - 2019-06-29 16:54:01 --> Helper loaded: array_helper
INFO - 2019-06-29 16:54:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 16:54:01 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 16:54:01 --> Database Driver Class Initialized
INFO - 2019-06-29 16:54:01 --> Controller Class Initialized
INFO - 2019-06-29 22:54:01 --> Helper loaded: language_helper
INFO - 2019-06-29 22:54:01 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 22:54:01 --> Model Class Initialized
INFO - 2019-06-29 22:54:01 --> Model Class Initialized
INFO - 2019-06-29 22:54:01 --> Model Class Initialized
INFO - 2019-06-29 22:54:01 --> Model Class Initialized
INFO - 2019-06-29 22:54:01 --> Model Class Initialized
INFO - 2019-06-29 22:54:01 --> Final output sent to browser
DEBUG - 2019-06-29 22:54:01 --> Total execution time: 0.4370
INFO - 2019-06-29 16:54:13 --> Config Class Initialized
INFO - 2019-06-29 16:54:13 --> Hooks Class Initialized
DEBUG - 2019-06-29 16:54:13 --> UTF-8 Support Enabled
INFO - 2019-06-29 16:54:13 --> Utf8 Class Initialized
INFO - 2019-06-29 16:54:13 --> URI Class Initialized
INFO - 2019-06-29 16:54:13 --> Router Class Initialized
INFO - 2019-06-29 16:54:13 --> Output Class Initialized
INFO - 2019-06-29 16:54:13 --> Security Class Initialized
DEBUG - 2019-06-29 16:54:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 16:54:13 --> Input Class Initialized
INFO - 2019-06-29 16:54:13 --> Language Class Initialized
INFO - 2019-06-29 16:54:13 --> Language Class Initialized
INFO - 2019-06-29 16:54:13 --> Config Class Initialized
INFO - 2019-06-29 16:54:13 --> Loader Class Initialized
DEBUG - 2019-06-29 16:54:13 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 16:54:13 --> Helper loaded: url_helper
INFO - 2019-06-29 16:54:13 --> Helper loaded: inflector_helper
INFO - 2019-06-29 16:54:13 --> Helper loaded: string_helper
INFO - 2019-06-29 16:54:13 --> Helper loaded: array_helper
INFO - 2019-06-29 16:54:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 16:54:13 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 16:54:13 --> Database Driver Class Initialized
INFO - 2019-06-29 16:54:13 --> Controller Class Initialized
INFO - 2019-06-29 22:54:13 --> Helper loaded: language_helper
INFO - 2019-06-29 22:54:14 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 22:54:14 --> Model Class Initialized
INFO - 2019-06-29 22:54:14 --> Model Class Initialized
INFO - 2019-06-29 22:54:14 --> Model Class Initialized
INFO - 2019-06-29 22:54:14 --> Model Class Initialized
INFO - 2019-06-29 22:54:14 --> Final output sent to browser
DEBUG - 2019-06-29 22:54:14 --> Total execution time: 0.3824
INFO - 2019-06-29 16:55:20 --> Config Class Initialized
INFO - 2019-06-29 16:55:20 --> Hooks Class Initialized
DEBUG - 2019-06-29 16:55:20 --> UTF-8 Support Enabled
INFO - 2019-06-29 16:55:20 --> Utf8 Class Initialized
INFO - 2019-06-29 16:55:20 --> URI Class Initialized
INFO - 2019-06-29 16:55:20 --> Router Class Initialized
INFO - 2019-06-29 16:55:20 --> Output Class Initialized
INFO - 2019-06-29 16:55:20 --> Security Class Initialized
DEBUG - 2019-06-29 16:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 16:55:20 --> Input Class Initialized
INFO - 2019-06-29 16:55:20 --> Language Class Initialized
INFO - 2019-06-29 16:55:20 --> Language Class Initialized
INFO - 2019-06-29 16:55:20 --> Config Class Initialized
INFO - 2019-06-29 16:55:20 --> Loader Class Initialized
DEBUG - 2019-06-29 16:55:20 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 16:55:20 --> Helper loaded: url_helper
INFO - 2019-06-29 16:55:21 --> Helper loaded: inflector_helper
INFO - 2019-06-29 16:55:21 --> Helper loaded: string_helper
INFO - 2019-06-29 16:55:21 --> Helper loaded: array_helper
INFO - 2019-06-29 16:55:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 16:55:21 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 16:55:21 --> Database Driver Class Initialized
INFO - 2019-06-29 16:55:21 --> Controller Class Initialized
INFO - 2019-06-29 22:55:21 --> Helper loaded: language_helper
INFO - 2019-06-29 22:55:21 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 22:55:21 --> Model Class Initialized
INFO - 2019-06-29 22:55:21 --> Model Class Initialized
INFO - 2019-06-29 22:55:21 --> Model Class Initialized
INFO - 2019-06-29 22:55:21 --> Model Class Initialized
INFO - 2019-06-29 22:55:21 --> Final output sent to browser
DEBUG - 2019-06-29 22:55:21 --> Total execution time: 0.5184
INFO - 2019-06-29 16:55:21 --> Config Class Initialized
INFO - 2019-06-29 16:55:21 --> Hooks Class Initialized
DEBUG - 2019-06-29 16:55:21 --> UTF-8 Support Enabled
INFO - 2019-06-29 16:55:21 --> Utf8 Class Initialized
INFO - 2019-06-29 16:55:21 --> URI Class Initialized
INFO - 2019-06-29 16:55:21 --> Router Class Initialized
INFO - 2019-06-29 16:55:21 --> Output Class Initialized
INFO - 2019-06-29 16:55:21 --> Security Class Initialized
DEBUG - 2019-06-29 16:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 16:55:21 --> Input Class Initialized
INFO - 2019-06-29 16:55:21 --> Language Class Initialized
INFO - 2019-06-29 16:55:21 --> Language Class Initialized
INFO - 2019-06-29 16:55:21 --> Config Class Initialized
INFO - 2019-06-29 16:55:21 --> Loader Class Initialized
DEBUG - 2019-06-29 16:55:21 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 16:55:21 --> Helper loaded: url_helper
INFO - 2019-06-29 16:55:21 --> Helper loaded: inflector_helper
INFO - 2019-06-29 16:55:21 --> Helper loaded: string_helper
INFO - 2019-06-29 16:55:21 --> Helper loaded: array_helper
INFO - 2019-06-29 16:55:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 16:55:21 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 16:55:21 --> Database Driver Class Initialized
INFO - 2019-06-29 16:55:21 --> Controller Class Initialized
INFO - 2019-06-29 22:55:21 --> Helper loaded: language_helper
INFO - 2019-06-29 22:55:21 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 22:55:21 --> Model Class Initialized
INFO - 2019-06-29 22:55:21 --> Model Class Initialized
INFO - 2019-06-29 22:55:21 --> Model Class Initialized
INFO - 2019-06-29 22:55:21 --> Model Class Initialized
INFO - 2019-06-29 22:55:21 --> Model Class Initialized
INFO - 2019-06-29 22:55:21 --> Final output sent to browser
DEBUG - 2019-06-29 22:55:21 --> Total execution time: 0.4036
INFO - 2019-06-29 16:55:23 --> Config Class Initialized
INFO - 2019-06-29 16:55:23 --> Hooks Class Initialized
DEBUG - 2019-06-29 16:55:23 --> UTF-8 Support Enabled
INFO - 2019-06-29 16:55:23 --> Utf8 Class Initialized
INFO - 2019-06-29 16:55:23 --> URI Class Initialized
INFO - 2019-06-29 16:55:23 --> Router Class Initialized
INFO - 2019-06-29 16:55:23 --> Output Class Initialized
INFO - 2019-06-29 16:55:23 --> Security Class Initialized
DEBUG - 2019-06-29 16:55:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 16:55:23 --> Input Class Initialized
INFO - 2019-06-29 16:55:23 --> Language Class Initialized
INFO - 2019-06-29 16:55:23 --> Language Class Initialized
INFO - 2019-06-29 16:55:23 --> Config Class Initialized
INFO - 2019-06-29 16:55:23 --> Loader Class Initialized
DEBUG - 2019-06-29 16:55:23 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 16:55:23 --> Helper loaded: url_helper
INFO - 2019-06-29 16:55:23 --> Helper loaded: inflector_helper
INFO - 2019-06-29 16:55:23 --> Helper loaded: string_helper
INFO - 2019-06-29 16:55:23 --> Helper loaded: array_helper
INFO - 2019-06-29 16:55:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 16:55:23 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 16:55:23 --> Database Driver Class Initialized
INFO - 2019-06-29 16:55:23 --> Controller Class Initialized
INFO - 2019-06-29 22:55:23 --> Helper loaded: language_helper
INFO - 2019-06-29 22:55:23 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 22:55:23 --> Model Class Initialized
INFO - 2019-06-29 22:55:23 --> Model Class Initialized
INFO - 2019-06-29 22:55:23 --> Model Class Initialized
INFO - 2019-06-29 22:55:23 --> Model Class Initialized
INFO - 2019-06-29 22:55:23 --> Final output sent to browser
DEBUG - 2019-06-29 22:55:23 --> Total execution time: 0.4108
INFO - 2019-06-29 16:55:26 --> Config Class Initialized
INFO - 2019-06-29 16:55:26 --> Hooks Class Initialized
DEBUG - 2019-06-29 16:55:26 --> UTF-8 Support Enabled
INFO - 2019-06-29 16:55:26 --> Utf8 Class Initialized
INFO - 2019-06-29 16:55:26 --> URI Class Initialized
INFO - 2019-06-29 16:55:26 --> Router Class Initialized
INFO - 2019-06-29 16:55:26 --> Output Class Initialized
INFO - 2019-06-29 16:55:26 --> Security Class Initialized
DEBUG - 2019-06-29 16:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 16:55:26 --> Input Class Initialized
INFO - 2019-06-29 16:55:26 --> Language Class Initialized
INFO - 2019-06-29 16:55:26 --> Language Class Initialized
INFO - 2019-06-29 16:55:26 --> Config Class Initialized
INFO - 2019-06-29 16:55:26 --> Loader Class Initialized
DEBUG - 2019-06-29 16:55:26 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 16:55:26 --> Helper loaded: url_helper
INFO - 2019-06-29 16:55:26 --> Helper loaded: inflector_helper
INFO - 2019-06-29 16:55:26 --> Helper loaded: string_helper
INFO - 2019-06-29 16:55:26 --> Helper loaded: array_helper
INFO - 2019-06-29 16:55:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 16:55:26 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 16:55:26 --> Database Driver Class Initialized
INFO - 2019-06-29 16:55:26 --> Controller Class Initialized
INFO - 2019-06-29 22:55:26 --> Helper loaded: language_helper
INFO - 2019-06-29 22:55:26 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 22:55:26 --> Model Class Initialized
INFO - 2019-06-29 22:55:26 --> Model Class Initialized
INFO - 2019-06-29 22:55:26 --> Model Class Initialized
INFO - 2019-06-29 22:55:26 --> Model Class Initialized
INFO - 2019-06-29 22:55:26 --> Final output sent to browser
DEBUG - 2019-06-29 22:55:26 --> Total execution time: 0.4457
INFO - 2019-06-29 16:55:34 --> Config Class Initialized
INFO - 2019-06-29 16:55:34 --> Hooks Class Initialized
DEBUG - 2019-06-29 16:55:34 --> UTF-8 Support Enabled
INFO - 2019-06-29 16:55:34 --> Utf8 Class Initialized
INFO - 2019-06-29 16:55:34 --> URI Class Initialized
INFO - 2019-06-29 16:55:34 --> Router Class Initialized
INFO - 2019-06-29 16:55:34 --> Output Class Initialized
INFO - 2019-06-29 16:55:34 --> Security Class Initialized
DEBUG - 2019-06-29 16:55:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 16:55:34 --> Input Class Initialized
INFO - 2019-06-29 16:55:34 --> Language Class Initialized
INFO - 2019-06-29 16:55:34 --> Language Class Initialized
INFO - 2019-06-29 16:55:34 --> Config Class Initialized
INFO - 2019-06-29 16:55:34 --> Loader Class Initialized
DEBUG - 2019-06-29 16:55:34 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 16:55:34 --> Helper loaded: url_helper
INFO - 2019-06-29 16:55:34 --> Helper loaded: inflector_helper
INFO - 2019-06-29 16:55:34 --> Helper loaded: string_helper
INFO - 2019-06-29 16:55:34 --> Helper loaded: array_helper
INFO - 2019-06-29 16:55:34 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 16:55:34 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 16:55:34 --> Database Driver Class Initialized
INFO - 2019-06-29 16:55:35 --> Controller Class Initialized
INFO - 2019-06-29 22:55:35 --> Helper loaded: language_helper
INFO - 2019-06-29 22:55:35 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 22:55:35 --> Model Class Initialized
INFO - 2019-06-29 22:55:35 --> Model Class Initialized
INFO - 2019-06-29 22:55:35 --> Model Class Initialized
INFO - 2019-06-29 22:55:35 --> Model Class Initialized
INFO - 2019-06-29 22:55:35 --> Final output sent to browser
DEBUG - 2019-06-29 22:55:35 --> Total execution time: 0.3842
INFO - 2019-06-29 16:55:35 --> Config Class Initialized
INFO - 2019-06-29 16:55:35 --> Hooks Class Initialized
DEBUG - 2019-06-29 16:55:35 --> UTF-8 Support Enabled
INFO - 2019-06-29 16:55:35 --> Utf8 Class Initialized
INFO - 2019-06-29 16:55:35 --> URI Class Initialized
INFO - 2019-06-29 16:55:35 --> Router Class Initialized
INFO - 2019-06-29 16:55:35 --> Output Class Initialized
INFO - 2019-06-29 16:55:35 --> Security Class Initialized
DEBUG - 2019-06-29 16:55:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-06-29 16:55:35 --> Input Class Initialized
INFO - 2019-06-29 16:55:35 --> Language Class Initialized
INFO - 2019-06-29 16:55:35 --> Language Class Initialized
INFO - 2019-06-29 16:55:35 --> Config Class Initialized
INFO - 2019-06-29 16:55:35 --> Loader Class Initialized
DEBUG - 2019-06-29 16:55:36 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-06-29 16:55:36 --> Helper loaded: url_helper
INFO - 2019-06-29 16:55:36 --> Helper loaded: inflector_helper
INFO - 2019-06-29 16:55:36 --> Helper loaded: string_helper
INFO - 2019-06-29 16:55:36 --> Helper loaded: array_helper
INFO - 2019-06-29 16:55:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-06-29 16:55:36 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-06-29 16:55:36 --> Database Driver Class Initialized
INFO - 2019-06-29 16:55:36 --> Controller Class Initialized
INFO - 2019-06-29 22:55:36 --> Helper loaded: language_helper
INFO - 2019-06-29 22:55:36 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-29 22:55:36 --> Model Class Initialized
INFO - 2019-06-29 22:55:36 --> Model Class Initialized
INFO - 2019-06-29 22:55:36 --> Model Class Initialized
INFO - 2019-06-29 22:55:36 --> Model Class Initialized
INFO - 2019-06-29 22:55:36 --> Final output sent to browser
DEBUG - 2019-06-29 22:55:36 --> Total execution time: 0.3350
