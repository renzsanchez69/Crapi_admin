<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-07-03 15:03:58 --> Config Class Initialized
INFO - 2019-07-03 15:03:58 --> Hooks Class Initialized
DEBUG - 2019-07-03 15:03:58 --> UTF-8 Support Enabled
INFO - 2019-07-03 15:03:58 --> Utf8 Class Initialized
INFO - 2019-07-03 15:03:58 --> URI Class Initialized
INFO - 2019-07-03 15:03:58 --> Router Class Initialized
INFO - 2019-07-03 15:03:58 --> Output Class Initialized
INFO - 2019-07-03 15:03:58 --> Security Class Initialized
DEBUG - 2019-07-03 15:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 15:03:58 --> Input Class Initialized
INFO - 2019-07-03 15:03:58 --> Language Class Initialized
INFO - 2019-07-03 15:03:58 --> Language Class Initialized
INFO - 2019-07-03 15:03:58 --> Config Class Initialized
INFO - 2019-07-03 15:03:58 --> Loader Class Initialized
DEBUG - 2019-07-03 15:03:58 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 15:03:58 --> Helper loaded: url_helper
INFO - 2019-07-03 15:03:58 --> Helper loaded: inflector_helper
INFO - 2019-07-03 15:03:58 --> Helper loaded: string_helper
INFO - 2019-07-03 15:03:58 --> Helper loaded: array_helper
INFO - 2019-07-03 15:03:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 15:03:58 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 15:03:58 --> Database Driver Class Initialized
INFO - 2019-07-03 15:03:59 --> Controller Class Initialized
INFO - 2019-07-03 21:03:59 --> Helper loaded: language_helper
INFO - 2019-07-03 21:03:59 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 21:03:59 --> Model Class Initialized
INFO - 2019-07-03 21:03:59 --> Model Class Initialized
INFO - 2019-07-03 21:03:59 --> Model Class Initialized
INFO - 2019-07-03 21:03:59 --> Model Class Initialized
INFO - 2019-07-03 21:03:59 --> Final output sent to browser
DEBUG - 2019-07-03 21:03:59 --> Total execution time: 0.9785
INFO - 2019-07-03 15:03:59 --> Config Class Initialized
INFO - 2019-07-03 15:03:59 --> Config Class Initialized
INFO - 2019-07-03 15:03:59 --> Hooks Class Initialized
INFO - 2019-07-03 15:03:59 --> Hooks Class Initialized
DEBUG - 2019-07-03 15:03:59 --> UTF-8 Support Enabled
DEBUG - 2019-07-03 15:03:59 --> UTF-8 Support Enabled
INFO - 2019-07-03 15:03:59 --> Utf8 Class Initialized
INFO - 2019-07-03 15:03:59 --> Utf8 Class Initialized
INFO - 2019-07-03 15:03:59 --> URI Class Initialized
INFO - 2019-07-03 15:03:59 --> URI Class Initialized
INFO - 2019-07-03 15:03:59 --> Router Class Initialized
INFO - 2019-07-03 15:03:59 --> Router Class Initialized
INFO - 2019-07-03 15:03:59 --> Output Class Initialized
INFO - 2019-07-03 15:03:59 --> Output Class Initialized
INFO - 2019-07-03 15:03:59 --> Security Class Initialized
INFO - 2019-07-03 15:03:59 --> Security Class Initialized
DEBUG - 2019-07-03 15:03:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-03 15:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 15:03:59 --> Input Class Initialized
INFO - 2019-07-03 15:03:59 --> Input Class Initialized
INFO - 2019-07-03 15:03:59 --> Language Class Initialized
INFO - 2019-07-03 15:03:59 --> Language Class Initialized
INFO - 2019-07-03 15:03:59 --> Language Class Initialized
INFO - 2019-07-03 15:03:59 --> Language Class Initialized
INFO - 2019-07-03 15:03:59 --> Config Class Initialized
INFO - 2019-07-03 15:03:59 --> Loader Class Initialized
INFO - 2019-07-03 15:03:59 --> Config Class Initialized
INFO - 2019-07-03 15:03:59 --> Loader Class Initialized
DEBUG - 2019-07-03 15:03:59 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-03 15:03:59 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 15:03:59 --> Helper loaded: url_helper
INFO - 2019-07-03 15:03:59 --> Helper loaded: url_helper
INFO - 2019-07-03 15:03:59 --> Helper loaded: inflector_helper
INFO - 2019-07-03 15:03:59 --> Helper loaded: inflector_helper
INFO - 2019-07-03 15:03:59 --> Helper loaded: string_helper
INFO - 2019-07-03 15:03:59 --> Helper loaded: string_helper
INFO - 2019-07-03 15:03:59 --> Helper loaded: array_helper
INFO - 2019-07-03 15:03:59 --> Helper loaded: array_helper
INFO - 2019-07-03 15:03:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 15:03:59 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 15:03:59 --> Database Driver Class Initialized
INFO - 2019-07-03 15:03:59 --> Controller Class Initialized
INFO - 2019-07-03 21:03:59 --> Helper loaded: language_helper
INFO - 2019-07-03 21:03:59 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 21:03:59 --> Model Class Initialized
INFO - 2019-07-03 21:03:59 --> Model Class Initialized
INFO - 2019-07-03 21:03:59 --> Model Class Initialized
INFO - 2019-07-03 21:03:59 --> Model Class Initialized
INFO - 2019-07-03 21:03:59 --> Model Class Initialized
INFO - 2019-07-03 21:03:59 --> Final output sent to browser
DEBUG - 2019-07-03 21:03:59 --> Total execution time: 0.3527
INFO - 2019-07-03 15:03:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 15:03:59 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 15:03:59 --> Database Driver Class Initialized
INFO - 2019-07-03 15:04:00 --> Controller Class Initialized
INFO - 2019-07-03 21:04:00 --> Helper loaded: language_helper
INFO - 2019-07-03 21:04:00 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 21:04:00 --> Model Class Initialized
INFO - 2019-07-03 21:04:00 --> Model Class Initialized
INFO - 2019-07-03 21:04:00 --> Model Class Initialized
INFO - 2019-07-03 21:04:00 --> Model Class Initialized
INFO - 2019-07-03 21:04:00 --> Final output sent to browser
DEBUG - 2019-07-03 21:04:00 --> Total execution time: 0.4643
INFO - 2019-07-03 15:04:04 --> Config Class Initialized
INFO - 2019-07-03 15:04:04 --> Hooks Class Initialized
DEBUG - 2019-07-03 15:04:04 --> UTF-8 Support Enabled
INFO - 2019-07-03 15:04:04 --> Utf8 Class Initialized
INFO - 2019-07-03 15:04:04 --> URI Class Initialized
INFO - 2019-07-03 15:04:04 --> Router Class Initialized
INFO - 2019-07-03 15:04:04 --> Output Class Initialized
INFO - 2019-07-03 15:04:04 --> Security Class Initialized
DEBUG - 2019-07-03 15:04:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 15:04:04 --> Input Class Initialized
INFO - 2019-07-03 15:04:04 --> Language Class Initialized
INFO - 2019-07-03 15:04:04 --> Language Class Initialized
INFO - 2019-07-03 15:04:04 --> Config Class Initialized
INFO - 2019-07-03 15:04:04 --> Loader Class Initialized
DEBUG - 2019-07-03 15:04:04 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 15:04:04 --> Helper loaded: url_helper
INFO - 2019-07-03 15:04:04 --> Helper loaded: inflector_helper
INFO - 2019-07-03 15:04:04 --> Helper loaded: string_helper
INFO - 2019-07-03 15:04:04 --> Helper loaded: array_helper
INFO - 2019-07-03 15:04:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 15:04:04 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 15:04:04 --> Database Driver Class Initialized
INFO - 2019-07-03 15:04:04 --> Controller Class Initialized
INFO - 2019-07-03 21:04:04 --> Helper loaded: language_helper
INFO - 2019-07-03 21:04:04 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 21:04:04 --> Model Class Initialized
INFO - 2019-07-03 21:04:04 --> Model Class Initialized
INFO - 2019-07-03 21:04:04 --> Model Class Initialized
INFO - 2019-07-03 21:04:04 --> Model Class Initialized
INFO - 2019-07-03 21:04:04 --> Model Class Initialized
INFO - 2019-07-03 21:04:04 --> Final output sent to browser
DEBUG - 2019-07-03 21:04:04 --> Total execution time: 0.2540
INFO - 2019-07-03 15:04:04 --> Config Class Initialized
INFO - 2019-07-03 15:04:04 --> Hooks Class Initialized
DEBUG - 2019-07-03 15:04:04 --> UTF-8 Support Enabled
INFO - 2019-07-03 15:04:04 --> Utf8 Class Initialized
INFO - 2019-07-03 15:04:04 --> URI Class Initialized
INFO - 2019-07-03 15:04:04 --> Router Class Initialized
INFO - 2019-07-03 15:04:04 --> Output Class Initialized
INFO - 2019-07-03 15:04:04 --> Security Class Initialized
DEBUG - 2019-07-03 15:04:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 15:04:04 --> Input Class Initialized
INFO - 2019-07-03 15:04:04 --> Language Class Initialized
INFO - 2019-07-03 15:04:04 --> Language Class Initialized
INFO - 2019-07-03 15:04:04 --> Config Class Initialized
INFO - 2019-07-03 15:04:04 --> Loader Class Initialized
DEBUG - 2019-07-03 15:04:04 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 15:04:04 --> Helper loaded: url_helper
INFO - 2019-07-03 15:04:04 --> Helper loaded: inflector_helper
INFO - 2019-07-03 15:04:04 --> Helper loaded: string_helper
INFO - 2019-07-03 15:04:04 --> Helper loaded: array_helper
INFO - 2019-07-03 15:04:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 15:04:04 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 15:04:04 --> Database Driver Class Initialized
INFO - 2019-07-03 15:04:04 --> Controller Class Initialized
INFO - 2019-07-03 21:04:04 --> Helper loaded: language_helper
INFO - 2019-07-03 21:04:04 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 21:04:04 --> Model Class Initialized
INFO - 2019-07-03 21:04:04 --> Model Class Initialized
INFO - 2019-07-03 21:04:04 --> Model Class Initialized
INFO - 2019-07-03 21:04:04 --> Model Class Initialized
INFO - 2019-07-03 21:04:04 --> Model Class Initialized
INFO - 2019-07-03 21:04:04 --> Final output sent to browser
DEBUG - 2019-07-03 21:04:04 --> Total execution time: 0.2624
INFO - 2019-07-03 15:04:14 --> Config Class Initialized
INFO - 2019-07-03 15:04:14 --> Hooks Class Initialized
DEBUG - 2019-07-03 15:04:14 --> UTF-8 Support Enabled
INFO - 2019-07-03 15:04:14 --> Utf8 Class Initialized
INFO - 2019-07-03 15:04:14 --> URI Class Initialized
INFO - 2019-07-03 15:04:14 --> Router Class Initialized
INFO - 2019-07-03 15:04:14 --> Output Class Initialized
INFO - 2019-07-03 15:04:14 --> Security Class Initialized
DEBUG - 2019-07-03 15:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 15:04:14 --> Input Class Initialized
INFO - 2019-07-03 15:04:14 --> Language Class Initialized
INFO - 2019-07-03 15:04:14 --> Language Class Initialized
INFO - 2019-07-03 15:04:14 --> Config Class Initialized
INFO - 2019-07-03 15:04:14 --> Loader Class Initialized
DEBUG - 2019-07-03 15:04:14 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 15:04:14 --> Helper loaded: url_helper
INFO - 2019-07-03 15:04:14 --> Helper loaded: inflector_helper
INFO - 2019-07-03 15:04:14 --> Helper loaded: string_helper
INFO - 2019-07-03 15:04:14 --> Helper loaded: array_helper
INFO - 2019-07-03 15:04:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 15:04:14 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 15:04:14 --> Database Driver Class Initialized
INFO - 2019-07-03 15:04:14 --> Controller Class Initialized
INFO - 2019-07-03 21:04:14 --> Helper loaded: language_helper
INFO - 2019-07-03 21:04:14 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 21:04:14 --> Model Class Initialized
INFO - 2019-07-03 21:04:14 --> Model Class Initialized
INFO - 2019-07-03 21:04:14 --> Model Class Initialized
INFO - 2019-07-03 21:04:14 --> Model Class Initialized
INFO - 2019-07-03 21:04:14 --> Model Class Initialized
INFO - 2019-07-03 21:04:14 --> Final output sent to browser
DEBUG - 2019-07-03 21:04:14 --> Total execution time: 0.2498
INFO - 2019-07-03 15:04:14 --> Config Class Initialized
INFO - 2019-07-03 15:04:14 --> Hooks Class Initialized
DEBUG - 2019-07-03 15:04:14 --> UTF-8 Support Enabled
INFO - 2019-07-03 15:04:14 --> Utf8 Class Initialized
INFO - 2019-07-03 15:04:14 --> URI Class Initialized
INFO - 2019-07-03 15:04:14 --> Router Class Initialized
INFO - 2019-07-03 15:04:14 --> Output Class Initialized
INFO - 2019-07-03 15:04:14 --> Security Class Initialized
DEBUG - 2019-07-03 15:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 15:04:14 --> Input Class Initialized
INFO - 2019-07-03 15:04:14 --> Language Class Initialized
INFO - 2019-07-03 15:04:14 --> Language Class Initialized
INFO - 2019-07-03 15:04:14 --> Config Class Initialized
INFO - 2019-07-03 15:04:14 --> Loader Class Initialized
DEBUG - 2019-07-03 15:04:14 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 15:04:14 --> Helper loaded: url_helper
INFO - 2019-07-03 15:04:14 --> Helper loaded: inflector_helper
INFO - 2019-07-03 15:04:14 --> Helper loaded: string_helper
INFO - 2019-07-03 15:04:14 --> Helper loaded: array_helper
INFO - 2019-07-03 15:04:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 15:04:14 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 15:04:14 --> Database Driver Class Initialized
INFO - 2019-07-03 15:04:14 --> Controller Class Initialized
INFO - 2019-07-03 21:04:14 --> Helper loaded: language_helper
INFO - 2019-07-03 21:04:14 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 21:04:14 --> Model Class Initialized
INFO - 2019-07-03 21:04:14 --> Model Class Initialized
INFO - 2019-07-03 21:04:14 --> Model Class Initialized
INFO - 2019-07-03 21:04:14 --> Model Class Initialized
INFO - 2019-07-03 21:04:14 --> Model Class Initialized
INFO - 2019-07-03 21:04:14 --> Final output sent to browser
DEBUG - 2019-07-03 21:04:14 --> Total execution time: 0.2567
INFO - 2019-07-03 15:05:20 --> Config Class Initialized
INFO - 2019-07-03 15:05:20 --> Hooks Class Initialized
DEBUG - 2019-07-03 15:05:20 --> UTF-8 Support Enabled
INFO - 2019-07-03 15:05:20 --> Utf8 Class Initialized
INFO - 2019-07-03 15:05:20 --> URI Class Initialized
INFO - 2019-07-03 15:05:20 --> Router Class Initialized
INFO - 2019-07-03 15:05:20 --> Output Class Initialized
INFO - 2019-07-03 15:05:20 --> Security Class Initialized
DEBUG - 2019-07-03 15:05:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 15:05:20 --> Input Class Initialized
INFO - 2019-07-03 15:05:20 --> Language Class Initialized
INFO - 2019-07-03 15:05:20 --> Language Class Initialized
INFO - 2019-07-03 15:05:20 --> Config Class Initialized
INFO - 2019-07-03 15:05:20 --> Loader Class Initialized
DEBUG - 2019-07-03 15:05:20 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 15:05:20 --> Helper loaded: url_helper
INFO - 2019-07-03 15:05:20 --> Helper loaded: inflector_helper
INFO - 2019-07-03 15:05:20 --> Helper loaded: string_helper
INFO - 2019-07-03 15:05:20 --> Helper loaded: array_helper
INFO - 2019-07-03 15:05:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 15:05:20 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 15:05:21 --> Database Driver Class Initialized
INFO - 2019-07-03 15:05:21 --> Controller Class Initialized
INFO - 2019-07-03 21:05:21 --> Helper loaded: language_helper
INFO - 2019-07-03 21:05:21 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 21:05:21 --> Model Class Initialized
INFO - 2019-07-03 21:05:21 --> Model Class Initialized
INFO - 2019-07-03 21:05:21 --> Model Class Initialized
INFO - 2019-07-03 21:05:21 --> Model Class Initialized
INFO - 2019-07-03 21:05:21 --> Model Class Initialized
INFO - 2019-07-03 21:05:21 --> Final output sent to browser
DEBUG - 2019-07-03 21:05:21 --> Total execution time: 0.2557
INFO - 2019-07-03 15:05:21 --> Config Class Initialized
INFO - 2019-07-03 15:05:21 --> Hooks Class Initialized
DEBUG - 2019-07-03 15:05:21 --> UTF-8 Support Enabled
INFO - 2019-07-03 15:05:21 --> Utf8 Class Initialized
INFO - 2019-07-03 15:05:21 --> URI Class Initialized
INFO - 2019-07-03 15:05:21 --> Router Class Initialized
INFO - 2019-07-03 15:05:21 --> Output Class Initialized
INFO - 2019-07-03 15:05:21 --> Security Class Initialized
DEBUG - 2019-07-03 15:05:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 15:05:21 --> Input Class Initialized
INFO - 2019-07-03 15:05:21 --> Language Class Initialized
INFO - 2019-07-03 15:05:21 --> Language Class Initialized
INFO - 2019-07-03 15:05:21 --> Config Class Initialized
INFO - 2019-07-03 15:05:21 --> Loader Class Initialized
DEBUG - 2019-07-03 15:05:21 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 15:05:21 --> Helper loaded: url_helper
INFO - 2019-07-03 15:05:21 --> Helper loaded: inflector_helper
INFO - 2019-07-03 15:05:21 --> Helper loaded: string_helper
INFO - 2019-07-03 15:05:21 --> Helper loaded: array_helper
INFO - 2019-07-03 15:05:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 15:05:21 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 15:05:21 --> Database Driver Class Initialized
INFO - 2019-07-03 15:05:21 --> Controller Class Initialized
INFO - 2019-07-03 21:05:21 --> Helper loaded: language_helper
INFO - 2019-07-03 21:05:21 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 21:05:21 --> Model Class Initialized
INFO - 2019-07-03 21:05:21 --> Model Class Initialized
INFO - 2019-07-03 21:05:21 --> Model Class Initialized
INFO - 2019-07-03 21:05:21 --> Model Class Initialized
INFO - 2019-07-03 21:05:21 --> Model Class Initialized
INFO - 2019-07-03 21:05:21 --> Final output sent to browser
DEBUG - 2019-07-03 21:05:21 --> Total execution time: 0.2721
INFO - 2019-07-03 15:06:46 --> Config Class Initialized
INFO - 2019-07-03 15:06:46 --> Hooks Class Initialized
INFO - 2019-07-03 15:06:46 --> Config Class Initialized
DEBUG - 2019-07-03 15:06:46 --> UTF-8 Support Enabled
INFO - 2019-07-03 15:06:46 --> Hooks Class Initialized
INFO - 2019-07-03 15:06:46 --> Utf8 Class Initialized
DEBUG - 2019-07-03 15:06:46 --> UTF-8 Support Enabled
INFO - 2019-07-03 15:06:46 --> URI Class Initialized
INFO - 2019-07-03 15:06:46 --> Utf8 Class Initialized
INFO - 2019-07-03 15:06:46 --> URI Class Initialized
INFO - 2019-07-03 15:06:46 --> Router Class Initialized
INFO - 2019-07-03 15:06:46 --> Router Class Initialized
INFO - 2019-07-03 15:06:46 --> Output Class Initialized
INFO - 2019-07-03 15:06:46 --> Output Class Initialized
INFO - 2019-07-03 15:06:46 --> Security Class Initialized
INFO - 2019-07-03 15:06:46 --> Security Class Initialized
DEBUG - 2019-07-03 15:06:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 15:06:46 --> Input Class Initialized
DEBUG - 2019-07-03 15:06:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 15:06:46 --> Language Class Initialized
INFO - 2019-07-03 15:06:46 --> Input Class Initialized
INFO - 2019-07-03 15:06:46 --> Language Class Initialized
INFO - 2019-07-03 15:06:46 --> Language Class Initialized
INFO - 2019-07-03 15:06:46 --> Language Class Initialized
INFO - 2019-07-03 15:06:46 --> Config Class Initialized
INFO - 2019-07-03 15:06:46 --> Loader Class Initialized
INFO - 2019-07-03 15:06:46 --> Config Class Initialized
INFO - 2019-07-03 15:06:46 --> Loader Class Initialized
DEBUG - 2019-07-03 15:06:46 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-03 15:06:46 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 15:06:46 --> Helper loaded: url_helper
INFO - 2019-07-03 15:06:46 --> Helper loaded: url_helper
INFO - 2019-07-03 15:06:46 --> Helper loaded: inflector_helper
INFO - 2019-07-03 15:06:46 --> Helper loaded: inflector_helper
INFO - 2019-07-03 15:06:46 --> Helper loaded: string_helper
INFO - 2019-07-03 15:06:46 --> Helper loaded: string_helper
INFO - 2019-07-03 15:06:46 --> Helper loaded: array_helper
INFO - 2019-07-03 15:06:46 --> Helper loaded: array_helper
INFO - 2019-07-03 15:06:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 15:06:46 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 15:06:46 --> Database Driver Class Initialized
INFO - 2019-07-03 15:06:46 --> Controller Class Initialized
INFO - 2019-07-03 21:06:46 --> Helper loaded: language_helper
INFO - 2019-07-03 21:06:47 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 21:06:47 --> Model Class Initialized
INFO - 2019-07-03 21:06:47 --> Model Class Initialized
INFO - 2019-07-03 21:06:47 --> Model Class Initialized
INFO - 2019-07-03 21:06:47 --> Model Class Initialized
INFO - 2019-07-03 21:06:47 --> Model Class Initialized
INFO - 2019-07-03 21:06:47 --> Final output sent to browser
DEBUG - 2019-07-03 21:06:47 --> Total execution time: 0.3108
INFO - 2019-07-03 15:06:47 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 15:06:47 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 15:06:47 --> Database Driver Class Initialized
INFO - 2019-07-03 15:06:47 --> Controller Class Initialized
INFO - 2019-07-03 21:06:47 --> Helper loaded: language_helper
INFO - 2019-07-03 21:06:47 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 21:06:47 --> Model Class Initialized
INFO - 2019-07-03 21:06:47 --> Model Class Initialized
INFO - 2019-07-03 21:06:47 --> Model Class Initialized
INFO - 2019-07-03 21:06:47 --> Model Class Initialized
INFO - 2019-07-03 21:06:47 --> Final output sent to browser
DEBUG - 2019-07-03 21:06:47 --> Total execution time: 0.3953
INFO - 2019-07-03 15:06:50 --> Config Class Initialized
INFO - 2019-07-03 15:06:50 --> Hooks Class Initialized
DEBUG - 2019-07-03 15:06:50 --> UTF-8 Support Enabled
INFO - 2019-07-03 15:06:50 --> Utf8 Class Initialized
INFO - 2019-07-03 15:06:50 --> URI Class Initialized
INFO - 2019-07-03 15:06:50 --> Router Class Initialized
INFO - 2019-07-03 15:06:50 --> Output Class Initialized
INFO - 2019-07-03 15:06:50 --> Security Class Initialized
DEBUG - 2019-07-03 15:06:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 15:06:50 --> Input Class Initialized
INFO - 2019-07-03 15:06:50 --> Language Class Initialized
INFO - 2019-07-03 15:06:50 --> Language Class Initialized
INFO - 2019-07-03 15:06:50 --> Config Class Initialized
INFO - 2019-07-03 15:06:50 --> Loader Class Initialized
DEBUG - 2019-07-03 15:06:50 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 15:06:50 --> Helper loaded: url_helper
INFO - 2019-07-03 15:06:50 --> Helper loaded: inflector_helper
INFO - 2019-07-03 15:06:50 --> Helper loaded: string_helper
INFO - 2019-07-03 15:06:50 --> Helper loaded: array_helper
INFO - 2019-07-03 15:06:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 15:06:50 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 15:06:50 --> Database Driver Class Initialized
INFO - 2019-07-03 15:06:50 --> Controller Class Initialized
INFO - 2019-07-03 21:06:50 --> Helper loaded: language_helper
INFO - 2019-07-03 21:06:50 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 21:06:50 --> Model Class Initialized
INFO - 2019-07-03 21:06:50 --> Model Class Initialized
INFO - 2019-07-03 21:06:50 --> Model Class Initialized
INFO - 2019-07-03 21:06:50 --> Model Class Initialized
INFO - 2019-07-03 21:06:50 --> Final output sent to browser
DEBUG - 2019-07-03 21:06:50 --> Total execution time: 0.2464
INFO - 2019-07-03 15:08:37 --> Config Class Initialized
INFO - 2019-07-03 15:08:37 --> Config Class Initialized
INFO - 2019-07-03 15:08:37 --> Hooks Class Initialized
INFO - 2019-07-03 15:08:37 --> Hooks Class Initialized
DEBUG - 2019-07-03 15:08:37 --> UTF-8 Support Enabled
DEBUG - 2019-07-03 15:08:37 --> UTF-8 Support Enabled
INFO - 2019-07-03 15:08:37 --> Utf8 Class Initialized
INFO - 2019-07-03 15:08:37 --> Utf8 Class Initialized
INFO - 2019-07-03 15:08:37 --> URI Class Initialized
INFO - 2019-07-03 15:08:37 --> URI Class Initialized
INFO - 2019-07-03 15:08:37 --> Router Class Initialized
INFO - 2019-07-03 15:08:37 --> Router Class Initialized
INFO - 2019-07-03 15:08:37 --> Output Class Initialized
INFO - 2019-07-03 15:08:37 --> Output Class Initialized
INFO - 2019-07-03 15:08:37 --> Security Class Initialized
INFO - 2019-07-03 15:08:37 --> Security Class Initialized
DEBUG - 2019-07-03 15:08:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-03 15:08:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 15:08:37 --> Input Class Initialized
INFO - 2019-07-03 15:08:37 --> Input Class Initialized
INFO - 2019-07-03 15:08:37 --> Language Class Initialized
INFO - 2019-07-03 15:08:37 --> Language Class Initialized
INFO - 2019-07-03 15:08:37 --> Language Class Initialized
INFO - 2019-07-03 15:08:37 --> Language Class Initialized
INFO - 2019-07-03 15:08:37 --> Config Class Initialized
INFO - 2019-07-03 15:08:37 --> Config Class Initialized
INFO - 2019-07-03 15:08:37 --> Loader Class Initialized
INFO - 2019-07-03 15:08:37 --> Loader Class Initialized
DEBUG - 2019-07-03 15:08:37 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-03 15:08:37 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 15:08:37 --> Helper loaded: url_helper
INFO - 2019-07-03 15:08:37 --> Helper loaded: url_helper
INFO - 2019-07-03 15:08:37 --> Helper loaded: inflector_helper
INFO - 2019-07-03 15:08:37 --> Helper loaded: inflector_helper
INFO - 2019-07-03 15:08:38 --> Helper loaded: string_helper
INFO - 2019-07-03 15:08:38 --> Helper loaded: string_helper
INFO - 2019-07-03 15:08:38 --> Helper loaded: array_helper
INFO - 2019-07-03 15:08:38 --> Helper loaded: array_helper
INFO - 2019-07-03 15:08:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 15:08:38 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 15:08:38 --> Database Driver Class Initialized
INFO - 2019-07-03 15:08:38 --> Controller Class Initialized
INFO - 2019-07-03 21:08:38 --> Helper loaded: language_helper
INFO - 2019-07-03 21:08:38 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 21:08:38 --> Model Class Initialized
INFO - 2019-07-03 21:08:38 --> Model Class Initialized
INFO - 2019-07-03 21:08:38 --> Model Class Initialized
INFO - 2019-07-03 21:08:38 --> Model Class Initialized
INFO - 2019-07-03 21:08:38 --> Model Class Initialized
INFO - 2019-07-03 21:08:38 --> Final output sent to browser
DEBUG - 2019-07-03 21:08:38 --> Total execution time: 0.3372
INFO - 2019-07-03 15:08:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 15:08:38 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 15:08:38 --> Database Driver Class Initialized
INFO - 2019-07-03 15:08:38 --> Controller Class Initialized
INFO - 2019-07-03 21:08:38 --> Helper loaded: language_helper
INFO - 2019-07-03 21:08:38 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 21:08:38 --> Model Class Initialized
INFO - 2019-07-03 21:08:38 --> Model Class Initialized
INFO - 2019-07-03 21:08:38 --> Model Class Initialized
INFO - 2019-07-03 21:08:38 --> Model Class Initialized
INFO - 2019-07-03 21:08:38 --> Final output sent to browser
DEBUG - 2019-07-03 21:08:38 --> Total execution time: 0.4423
INFO - 2019-07-03 15:08:40 --> Config Class Initialized
INFO - 2019-07-03 15:08:40 --> Hooks Class Initialized
INFO - 2019-07-03 15:08:40 --> Config Class Initialized
INFO - 2019-07-03 15:08:40 --> Hooks Class Initialized
DEBUG - 2019-07-03 15:08:40 --> UTF-8 Support Enabled
INFO - 2019-07-03 15:08:40 --> Utf8 Class Initialized
DEBUG - 2019-07-03 15:08:40 --> UTF-8 Support Enabled
INFO - 2019-07-03 15:08:40 --> URI Class Initialized
INFO - 2019-07-03 15:08:40 --> Utf8 Class Initialized
INFO - 2019-07-03 15:08:40 --> URI Class Initialized
INFO - 2019-07-03 15:08:40 --> Router Class Initialized
INFO - 2019-07-03 15:08:40 --> Router Class Initialized
INFO - 2019-07-03 15:08:40 --> Output Class Initialized
INFO - 2019-07-03 15:08:40 --> Output Class Initialized
INFO - 2019-07-03 15:08:40 --> Security Class Initialized
INFO - 2019-07-03 15:08:40 --> Security Class Initialized
DEBUG - 2019-07-03 15:08:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-03 15:08:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 15:08:40 --> Input Class Initialized
INFO - 2019-07-03 15:08:40 --> Input Class Initialized
INFO - 2019-07-03 15:08:40 --> Language Class Initialized
INFO - 2019-07-03 15:08:41 --> Language Class Initialized
INFO - 2019-07-03 15:08:41 --> Language Class Initialized
INFO - 2019-07-03 15:08:41 --> Language Class Initialized
INFO - 2019-07-03 15:08:41 --> Config Class Initialized
INFO - 2019-07-03 15:08:41 --> Loader Class Initialized
INFO - 2019-07-03 15:08:41 --> Config Class Initialized
INFO - 2019-07-03 15:08:41 --> Loader Class Initialized
DEBUG - 2019-07-03 15:08:41 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-03 15:08:41 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 15:08:41 --> Helper loaded: url_helper
INFO - 2019-07-03 15:08:41 --> Helper loaded: url_helper
INFO - 2019-07-03 15:08:41 --> Helper loaded: inflector_helper
INFO - 2019-07-03 15:08:41 --> Helper loaded: inflector_helper
INFO - 2019-07-03 15:08:41 --> Helper loaded: string_helper
INFO - 2019-07-03 15:08:41 --> Helper loaded: string_helper
INFO - 2019-07-03 15:08:41 --> Helper loaded: array_helper
INFO - 2019-07-03 15:08:41 --> Helper loaded: array_helper
INFO - 2019-07-03 15:08:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 15:08:41 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 15:08:41 --> Database Driver Class Initialized
INFO - 2019-07-03 15:08:41 --> Controller Class Initialized
INFO - 2019-07-03 21:08:41 --> Helper loaded: language_helper
INFO - 2019-07-03 21:08:41 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 21:08:41 --> Model Class Initialized
INFO - 2019-07-03 21:08:41 --> Model Class Initialized
INFO - 2019-07-03 21:08:41 --> Model Class Initialized
INFO - 2019-07-03 21:08:41 --> Model Class Initialized
INFO - 2019-07-03 21:08:41 --> Model Class Initialized
INFO - 2019-07-03 21:08:41 --> Final output sent to browser
DEBUG - 2019-07-03 21:08:41 --> Total execution time: 0.3416
INFO - 2019-07-03 15:08:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 15:08:41 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 15:08:41 --> Database Driver Class Initialized
INFO - 2019-07-03 15:08:41 --> Controller Class Initialized
INFO - 2019-07-03 21:08:41 --> Helper loaded: language_helper
INFO - 2019-07-03 21:08:41 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 21:08:41 --> Model Class Initialized
INFO - 2019-07-03 21:08:41 --> Model Class Initialized
INFO - 2019-07-03 21:08:41 --> Model Class Initialized
INFO - 2019-07-03 21:08:41 --> Model Class Initialized
INFO - 2019-07-03 21:08:41 --> Final output sent to browser
DEBUG - 2019-07-03 21:08:41 --> Total execution time: 0.4439
INFO - 2019-07-03 15:08:41 --> Config Class Initialized
INFO - 2019-07-03 15:08:41 --> Hooks Class Initialized
DEBUG - 2019-07-03 15:08:41 --> UTF-8 Support Enabled
INFO - 2019-07-03 15:08:41 --> Utf8 Class Initialized
INFO - 2019-07-03 15:08:41 --> URI Class Initialized
INFO - 2019-07-03 15:08:41 --> Router Class Initialized
INFO - 2019-07-03 15:08:41 --> Output Class Initialized
INFO - 2019-07-03 15:08:41 --> Security Class Initialized
DEBUG - 2019-07-03 15:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 15:08:41 --> Input Class Initialized
INFO - 2019-07-03 15:08:41 --> Language Class Initialized
INFO - 2019-07-03 15:08:41 --> Language Class Initialized
INFO - 2019-07-03 15:08:41 --> Config Class Initialized
INFO - 2019-07-03 15:08:41 --> Loader Class Initialized
DEBUG - 2019-07-03 15:08:41 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 15:08:41 --> Helper loaded: url_helper
INFO - 2019-07-03 15:08:41 --> Helper loaded: inflector_helper
INFO - 2019-07-03 15:08:41 --> Helper loaded: string_helper
INFO - 2019-07-03 15:08:41 --> Helper loaded: array_helper
INFO - 2019-07-03 15:08:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 15:08:41 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 15:08:41 --> Database Driver Class Initialized
INFO - 2019-07-03 15:08:42 --> Controller Class Initialized
INFO - 2019-07-03 21:08:42 --> Helper loaded: language_helper
INFO - 2019-07-03 21:08:42 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 21:08:42 --> Model Class Initialized
INFO - 2019-07-03 21:08:42 --> Model Class Initialized
INFO - 2019-07-03 21:08:42 --> Model Class Initialized
INFO - 2019-07-03 21:08:42 --> Model Class Initialized
INFO - 2019-07-03 21:08:42 --> Final output sent to browser
DEBUG - 2019-07-03 21:08:42 --> Total execution time: 0.2617
INFO - 2019-07-03 15:09:54 --> Config Class Initialized
INFO - 2019-07-03 15:09:54 --> Hooks Class Initialized
DEBUG - 2019-07-03 15:09:54 --> UTF-8 Support Enabled
INFO - 2019-07-03 15:09:54 --> Utf8 Class Initialized
INFO - 2019-07-03 15:09:54 --> URI Class Initialized
INFO - 2019-07-03 15:09:54 --> Router Class Initialized
INFO - 2019-07-03 15:09:54 --> Output Class Initialized
INFO - 2019-07-03 15:09:54 --> Security Class Initialized
DEBUG - 2019-07-03 15:09:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 15:09:54 --> Input Class Initialized
INFO - 2019-07-03 15:09:54 --> Language Class Initialized
INFO - 2019-07-03 15:09:54 --> Language Class Initialized
INFO - 2019-07-03 15:09:54 --> Config Class Initialized
INFO - 2019-07-03 15:09:54 --> Loader Class Initialized
DEBUG - 2019-07-03 15:09:54 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 15:09:54 --> Helper loaded: url_helper
INFO - 2019-07-03 15:09:54 --> Helper loaded: inflector_helper
INFO - 2019-07-03 15:09:54 --> Helper loaded: string_helper
INFO - 2019-07-03 15:09:54 --> Helper loaded: array_helper
INFO - 2019-07-03 15:09:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 15:09:54 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 15:09:54 --> Database Driver Class Initialized
INFO - 2019-07-03 15:09:54 --> Controller Class Initialized
INFO - 2019-07-03 21:09:54 --> Helper loaded: language_helper
INFO - 2019-07-03 21:09:54 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 21:09:54 --> Model Class Initialized
INFO - 2019-07-03 21:09:54 --> Model Class Initialized
INFO - 2019-07-03 21:09:54 --> Model Class Initialized
INFO - 2019-07-03 21:09:54 --> Model Class Initialized
INFO - 2019-07-03 21:09:54 --> Final output sent to browser
DEBUG - 2019-07-03 21:09:54 --> Total execution time: 0.2601
INFO - 2019-07-03 15:10:20 --> Config Class Initialized
INFO - 2019-07-03 15:10:20 --> Config Class Initialized
INFO - 2019-07-03 15:10:20 --> Hooks Class Initialized
INFO - 2019-07-03 15:10:20 --> Hooks Class Initialized
DEBUG - 2019-07-03 15:10:20 --> UTF-8 Support Enabled
DEBUG - 2019-07-03 15:10:20 --> UTF-8 Support Enabled
INFO - 2019-07-03 15:10:20 --> Utf8 Class Initialized
INFO - 2019-07-03 15:10:20 --> Utf8 Class Initialized
INFO - 2019-07-03 15:10:20 --> URI Class Initialized
INFO - 2019-07-03 15:10:20 --> URI Class Initialized
INFO - 2019-07-03 15:10:20 --> Router Class Initialized
INFO - 2019-07-03 15:10:20 --> Router Class Initialized
INFO - 2019-07-03 15:10:20 --> Output Class Initialized
INFO - 2019-07-03 15:10:20 --> Output Class Initialized
INFO - 2019-07-03 15:10:20 --> Security Class Initialized
INFO - 2019-07-03 15:10:20 --> Security Class Initialized
DEBUG - 2019-07-03 15:10:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 15:10:20 --> Input Class Initialized
INFO - 2019-07-03 15:10:20 --> Language Class Initialized
DEBUG - 2019-07-03 15:10:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 15:10:20 --> Language Class Initialized
INFO - 2019-07-03 15:10:20 --> Input Class Initialized
INFO - 2019-07-03 15:10:20 --> Config Class Initialized
INFO - 2019-07-03 15:10:20 --> Language Class Initialized
INFO - 2019-07-03 15:10:20 --> Loader Class Initialized
DEBUG - 2019-07-03 15:10:20 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 15:10:20 --> Language Class Initialized
INFO - 2019-07-03 15:10:20 --> Helper loaded: url_helper
INFO - 2019-07-03 15:10:20 --> Config Class Initialized
INFO - 2019-07-03 15:10:20 --> Loader Class Initialized
INFO - 2019-07-03 15:10:20 --> Helper loaded: inflector_helper
DEBUG - 2019-07-03 15:10:20 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 15:10:20 --> Helper loaded: string_helper
INFO - 2019-07-03 15:10:20 --> Helper loaded: url_helper
INFO - 2019-07-03 15:10:20 --> Helper loaded: array_helper
INFO - 2019-07-03 15:10:20 --> Helper loaded: inflector_helper
INFO - 2019-07-03 15:10:20 --> Session: Class initialized using 'files' driver.
INFO - 2019-07-03 15:10:20 --> Helper loaded: string_helper
DEBUG - 2019-07-03 15:10:20 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 15:10:20 --> Helper loaded: array_helper
INFO - 2019-07-03 15:10:20 --> Database Driver Class Initialized
INFO - 2019-07-03 15:10:20 --> Controller Class Initialized
INFO - 2019-07-03 21:10:20 --> Helper loaded: language_helper
INFO - 2019-07-03 21:10:20 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 21:10:20 --> Model Class Initialized
INFO - 2019-07-03 21:10:20 --> Model Class Initialized
INFO - 2019-07-03 21:10:20 --> Model Class Initialized
INFO - 2019-07-03 21:10:20 --> Model Class Initialized
INFO - 2019-07-03 21:10:20 --> Model Class Initialized
INFO - 2019-07-03 21:10:20 --> Final output sent to browser
DEBUG - 2019-07-03 21:10:20 --> Total execution time: 0.3884
INFO - 2019-07-03 15:10:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 15:10:20 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 15:10:20 --> Database Driver Class Initialized
INFO - 2019-07-03 15:10:20 --> Controller Class Initialized
INFO - 2019-07-03 21:10:20 --> Helper loaded: language_helper
INFO - 2019-07-03 21:10:20 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 21:10:20 --> Model Class Initialized
INFO - 2019-07-03 21:10:20 --> Model Class Initialized
INFO - 2019-07-03 21:10:20 --> Model Class Initialized
INFO - 2019-07-03 21:10:20 --> Model Class Initialized
INFO - 2019-07-03 21:10:20 --> Final output sent to browser
DEBUG - 2019-07-03 21:10:20 --> Total execution time: 0.4717
INFO - 2019-07-03 15:10:56 --> Config Class Initialized
INFO - 2019-07-03 15:10:56 --> Hooks Class Initialized
INFO - 2019-07-03 15:10:56 --> Config Class Initialized
DEBUG - 2019-07-03 15:10:56 --> UTF-8 Support Enabled
INFO - 2019-07-03 15:10:56 --> Hooks Class Initialized
INFO - 2019-07-03 15:10:56 --> Utf8 Class Initialized
DEBUG - 2019-07-03 15:10:56 --> UTF-8 Support Enabled
INFO - 2019-07-03 15:10:56 --> URI Class Initialized
INFO - 2019-07-03 15:10:56 --> Utf8 Class Initialized
INFO - 2019-07-03 15:10:56 --> URI Class Initialized
INFO - 2019-07-03 15:10:56 --> Router Class Initialized
INFO - 2019-07-03 15:10:56 --> Router Class Initialized
INFO - 2019-07-03 15:10:56 --> Output Class Initialized
INFO - 2019-07-03 15:10:56 --> Output Class Initialized
INFO - 2019-07-03 15:10:56 --> Security Class Initialized
INFO - 2019-07-03 15:10:56 --> Security Class Initialized
DEBUG - 2019-07-03 15:10:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 15:10:56 --> Input Class Initialized
DEBUG - 2019-07-03 15:10:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 15:10:56 --> Input Class Initialized
INFO - 2019-07-03 15:10:56 --> Language Class Initialized
INFO - 2019-07-03 15:10:56 --> Language Class Initialized
INFO - 2019-07-03 15:10:56 --> Language Class Initialized
INFO - 2019-07-03 15:10:56 --> Config Class Initialized
INFO - 2019-07-03 15:10:56 --> Loader Class Initialized
DEBUG - 2019-07-03 15:10:56 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 15:10:56 --> Language Class Initialized
INFO - 2019-07-03 15:10:56 --> Helper loaded: url_helper
INFO - 2019-07-03 15:10:56 --> Config Class Initialized
INFO - 2019-07-03 15:10:56 --> Loader Class Initialized
INFO - 2019-07-03 15:10:56 --> Helper loaded: inflector_helper
DEBUG - 2019-07-03 15:10:56 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 15:10:56 --> Config Class Initialized
INFO - 2019-07-03 15:10:56 --> Helper loaded: string_helper
INFO - 2019-07-03 15:10:56 --> Config Class Initialized
INFO - 2019-07-03 15:10:56 --> Helper loaded: url_helper
INFO - 2019-07-03 15:10:56 --> Hooks Class Initialized
INFO - 2019-07-03 15:10:56 --> Hooks Class Initialized
INFO - 2019-07-03 15:10:56 --> Helper loaded: array_helper
DEBUG - 2019-07-03 15:10:56 --> UTF-8 Support Enabled
INFO - 2019-07-03 15:10:56 --> Helper loaded: inflector_helper
INFO - 2019-07-03 15:10:56 --> Utf8 Class Initialized
DEBUG - 2019-07-03 15:10:56 --> UTF-8 Support Enabled
INFO - 2019-07-03 15:10:56 --> Utf8 Class Initialized
INFO - 2019-07-03 15:10:56 --> Helper loaded: string_helper
INFO - 2019-07-03 15:10:56 --> Session: Class initialized using 'files' driver.
INFO - 2019-07-03 15:10:56 --> URI Class Initialized
INFO - 2019-07-03 15:10:56 --> URI Class Initialized
INFO - 2019-07-03 15:10:56 --> Helper loaded: array_helper
DEBUG - 2019-07-03 15:10:56 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 15:10:56 --> Router Class Initialized
INFO - 2019-07-03 15:10:56 --> Router Class Initialized
INFO - 2019-07-03 15:10:56 --> Database Driver Class Initialized
INFO - 2019-07-03 15:10:56 --> Output Class Initialized
INFO - 2019-07-03 15:10:56 --> Output Class Initialized
INFO - 2019-07-03 15:10:56 --> Controller Class Initialized
INFO - 2019-07-03 15:10:56 --> Security Class Initialized
INFO - 2019-07-03 21:10:56 --> Helper loaded: language_helper
INFO - 2019-07-03 15:10:56 --> Security Class Initialized
DEBUG - 2019-07-03 15:10:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 21:10:56 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 15:10:56 --> Input Class Initialized
DEBUG - 2019-07-03 15:10:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 15:10:56 --> Input Class Initialized
INFO - 2019-07-03 21:10:56 --> Model Class Initialized
INFO - 2019-07-03 15:10:56 --> Language Class Initialized
INFO - 2019-07-03 15:10:56 --> Language Class Initialized
INFO - 2019-07-03 15:10:56 --> Language Class Initialized
INFO - 2019-07-03 21:10:56 --> Model Class Initialized
INFO - 2019-07-03 15:10:56 --> Language Class Initialized
INFO - 2019-07-03 15:10:56 --> Config Class Initialized
INFO - 2019-07-03 21:10:56 --> Model Class Initialized
INFO - 2019-07-03 15:10:56 --> Loader Class Initialized
INFO - 2019-07-03 15:10:56 --> Config Class Initialized
INFO - 2019-07-03 15:10:56 --> Loader Class Initialized
INFO - 2019-07-03 21:10:56 --> Model Class Initialized
DEBUG - 2019-07-03 15:10:56 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-03 15:10:56 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 21:10:56 --> Final output sent to browser
INFO - 2019-07-03 15:10:56 --> Helper loaded: url_helper
INFO - 2019-07-03 15:10:56 --> Helper loaded: url_helper
DEBUG - 2019-07-03 21:10:56 --> Total execution time: 0.5388
INFO - 2019-07-03 15:10:56 --> Helper loaded: inflector_helper
INFO - 2019-07-03 15:10:56 --> Session: Class initialized using 'files' driver.
INFO - 2019-07-03 15:10:56 --> Helper loaded: inflector_helper
INFO - 2019-07-03 15:10:56 --> Helper loaded: string_helper
DEBUG - 2019-07-03 15:10:56 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 15:10:56 --> Helper loaded: string_helper
INFO - 2019-07-03 15:10:56 --> Helper loaded: array_helper
INFO - 2019-07-03 15:10:56 --> Database Driver Class Initialized
INFO - 2019-07-03 15:10:56 --> Helper loaded: array_helper
INFO - 2019-07-03 15:10:56 --> Controller Class Initialized
INFO - 2019-07-03 21:10:56 --> Helper loaded: language_helper
INFO - 2019-07-03 21:10:56 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 21:10:56 --> Model Class Initialized
INFO - 2019-07-03 21:10:56 --> Model Class Initialized
INFO - 2019-07-03 21:10:56 --> Model Class Initialized
INFO - 2019-07-03 21:10:56 --> Model Class Initialized
INFO - 2019-07-03 21:10:56 --> Model Class Initialized
INFO - 2019-07-03 21:10:56 --> Final output sent to browser
DEBUG - 2019-07-03 21:10:56 --> Total execution time: 0.7096
INFO - 2019-07-03 15:10:56 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 15:10:56 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 15:10:56 --> Database Driver Class Initialized
INFO - 2019-07-03 15:10:56 --> Controller Class Initialized
INFO - 2019-07-03 21:10:56 --> Helper loaded: language_helper
INFO - 2019-07-03 21:10:56 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 21:10:56 --> Model Class Initialized
INFO - 2019-07-03 21:10:56 --> Model Class Initialized
INFO - 2019-07-03 21:10:56 --> Model Class Initialized
INFO - 2019-07-03 21:10:56 --> Model Class Initialized
INFO - 2019-07-03 21:10:56 --> Model Class Initialized
INFO - 2019-07-03 21:10:56 --> Final output sent to browser
DEBUG - 2019-07-03 21:10:56 --> Total execution time: 0.4825
INFO - 2019-07-03 15:10:56 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 15:10:56 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 15:10:56 --> Database Driver Class Initialized
INFO - 2019-07-03 15:10:56 --> Controller Class Initialized
INFO - 2019-07-03 21:10:56 --> Helper loaded: language_helper
INFO - 2019-07-03 21:10:56 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 21:10:56 --> Model Class Initialized
INFO - 2019-07-03 21:10:56 --> Model Class Initialized
INFO - 2019-07-03 21:10:56 --> Model Class Initialized
INFO - 2019-07-03 21:10:57 --> Model Class Initialized
INFO - 2019-07-03 21:10:57 --> Final output sent to browser
DEBUG - 2019-07-03 21:10:57 --> Total execution time: 0.5792
INFO - 2019-07-03 15:11:08 --> Config Class Initialized
INFO - 2019-07-03 15:11:08 --> Hooks Class Initialized
DEBUG - 2019-07-03 15:11:08 --> UTF-8 Support Enabled
INFO - 2019-07-03 15:11:08 --> Utf8 Class Initialized
INFO - 2019-07-03 15:11:08 --> URI Class Initialized
INFO - 2019-07-03 15:11:08 --> Config Class Initialized
INFO - 2019-07-03 15:11:08 --> Router Class Initialized
INFO - 2019-07-03 15:11:08 --> Hooks Class Initialized
INFO - 2019-07-03 15:11:08 --> Output Class Initialized
INFO - 2019-07-03 15:11:08 --> Security Class Initialized
DEBUG - 2019-07-03 15:11:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 15:11:08 --> Input Class Initialized
INFO - 2019-07-03 15:11:08 --> Language Class Initialized
DEBUG - 2019-07-03 15:11:08 --> UTF-8 Support Enabled
INFO - 2019-07-03 15:11:08 --> Language Class Initialized
INFO - 2019-07-03 15:11:08 --> Utf8 Class Initialized
INFO - 2019-07-03 15:11:08 --> Config Class Initialized
INFO - 2019-07-03 15:11:08 --> URI Class Initialized
INFO - 2019-07-03 15:11:08 --> Loader Class Initialized
DEBUG - 2019-07-03 15:11:08 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 15:11:08 --> Router Class Initialized
INFO - 2019-07-03 15:11:08 --> Helper loaded: url_helper
INFO - 2019-07-03 15:11:08 --> Output Class Initialized
INFO - 2019-07-03 15:11:08 --> Helper loaded: inflector_helper
INFO - 2019-07-03 15:11:08 --> Security Class Initialized
INFO - 2019-07-03 15:11:08 --> Helper loaded: string_helper
DEBUG - 2019-07-03 15:11:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 15:11:08 --> Helper loaded: array_helper
INFO - 2019-07-03 15:11:08 --> Input Class Initialized
INFO - 2019-07-03 15:11:08 --> Language Class Initialized
INFO - 2019-07-03 15:11:08 --> Session: Class initialized using 'files' driver.
INFO - 2019-07-03 15:11:08 --> Language Class Initialized
DEBUG - 2019-07-03 15:11:08 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 15:11:08 --> Config Class Initialized
INFO - 2019-07-03 15:11:08 --> Loader Class Initialized
INFO - 2019-07-03 15:11:08 --> Database Driver Class Initialized
DEBUG - 2019-07-03 15:11:08 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 15:11:08 --> Controller Class Initialized
INFO - 2019-07-03 15:11:08 --> Helper loaded: url_helper
INFO - 2019-07-03 21:11:08 --> Helper loaded: language_helper
INFO - 2019-07-03 15:11:08 --> Helper loaded: inflector_helper
INFO - 2019-07-03 21:11:08 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 15:11:08 --> Helper loaded: string_helper
INFO - 2019-07-03 21:11:08 --> Model Class Initialized
INFO - 2019-07-03 15:11:08 --> Helper loaded: array_helper
INFO - 2019-07-03 21:11:08 --> Model Class Initialized
INFO - 2019-07-03 21:11:08 --> Model Class Initialized
INFO - 2019-07-03 21:11:08 --> Model Class Initialized
INFO - 2019-07-03 21:11:08 --> Model Class Initialized
INFO - 2019-07-03 21:11:08 --> Final output sent to browser
DEBUG - 2019-07-03 21:11:08 --> Total execution time: 0.3713
INFO - 2019-07-03 15:11:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 15:11:08 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 15:11:08 --> Database Driver Class Initialized
INFO - 2019-07-03 15:11:08 --> Controller Class Initialized
INFO - 2019-07-03 21:11:08 --> Helper loaded: language_helper
INFO - 2019-07-03 21:11:08 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 21:11:08 --> Model Class Initialized
INFO - 2019-07-03 21:11:08 --> Model Class Initialized
INFO - 2019-07-03 21:11:08 --> Model Class Initialized
INFO - 2019-07-03 21:11:08 --> Model Class Initialized
INFO - 2019-07-03 21:11:08 --> Final output sent to browser
DEBUG - 2019-07-03 21:11:08 --> Total execution time: 0.4718
INFO - 2019-07-03 15:11:11 --> Config Class Initialized
INFO - 2019-07-03 15:11:11 --> Config Class Initialized
INFO - 2019-07-03 15:11:11 --> Hooks Class Initialized
INFO - 2019-07-03 15:11:11 --> Hooks Class Initialized
DEBUG - 2019-07-03 15:11:11 --> UTF-8 Support Enabled
INFO - 2019-07-03 15:11:11 --> Utf8 Class Initialized
DEBUG - 2019-07-03 15:11:11 --> UTF-8 Support Enabled
INFO - 2019-07-03 15:11:11 --> Utf8 Class Initialized
INFO - 2019-07-03 15:11:11 --> URI Class Initialized
INFO - 2019-07-03 15:11:11 --> URI Class Initialized
INFO - 2019-07-03 15:11:11 --> Router Class Initialized
INFO - 2019-07-03 15:11:11 --> Router Class Initialized
INFO - 2019-07-03 15:11:11 --> Output Class Initialized
INFO - 2019-07-03 15:11:11 --> Output Class Initialized
INFO - 2019-07-03 15:11:11 --> Security Class Initialized
INFO - 2019-07-03 15:11:11 --> Security Class Initialized
DEBUG - 2019-07-03 15:11:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-03 15:11:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 15:11:11 --> Input Class Initialized
INFO - 2019-07-03 15:11:11 --> Input Class Initialized
INFO - 2019-07-03 15:11:11 --> Language Class Initialized
INFO - 2019-07-03 15:11:11 --> Language Class Initialized
INFO - 2019-07-03 15:11:11 --> Language Class Initialized
INFO - 2019-07-03 15:11:11 --> Config Class Initialized
INFO - 2019-07-03 15:11:11 --> Language Class Initialized
INFO - 2019-07-03 15:11:11 --> Config Class Initialized
INFO - 2019-07-03 15:11:11 --> Loader Class Initialized
INFO - 2019-07-03 15:11:11 --> Loader Class Initialized
DEBUG - 2019-07-03 15:11:11 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-03 15:11:11 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 15:11:11 --> Helper loaded: url_helper
INFO - 2019-07-03 15:11:11 --> Helper loaded: url_helper
INFO - 2019-07-03 15:11:11 --> Helper loaded: inflector_helper
INFO - 2019-07-03 15:11:11 --> Helper loaded: inflector_helper
INFO - 2019-07-03 15:11:11 --> Helper loaded: string_helper
INFO - 2019-07-03 15:11:11 --> Helper loaded: string_helper
INFO - 2019-07-03 15:11:11 --> Helper loaded: array_helper
INFO - 2019-07-03 15:11:11 --> Helper loaded: array_helper
INFO - 2019-07-03 15:11:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 15:11:11 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 15:11:11 --> Database Driver Class Initialized
INFO - 2019-07-03 15:11:11 --> Controller Class Initialized
INFO - 2019-07-03 21:11:11 --> Helper loaded: language_helper
INFO - 2019-07-03 21:11:11 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 21:11:11 --> Model Class Initialized
INFO - 2019-07-03 21:11:11 --> Model Class Initialized
INFO - 2019-07-03 21:11:11 --> Model Class Initialized
INFO - 2019-07-03 21:11:11 --> Model Class Initialized
INFO - 2019-07-03 21:11:11 --> Model Class Initialized
INFO - 2019-07-03 21:11:11 --> Final output sent to browser
DEBUG - 2019-07-03 21:11:11 --> Total execution time: 0.3848
INFO - 2019-07-03 15:11:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 15:11:11 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 15:11:11 --> Database Driver Class Initialized
INFO - 2019-07-03 15:11:11 --> Controller Class Initialized
INFO - 2019-07-03 21:11:11 --> Helper loaded: language_helper
INFO - 2019-07-03 21:11:11 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 21:11:11 --> Model Class Initialized
INFO - 2019-07-03 21:11:11 --> Model Class Initialized
INFO - 2019-07-03 21:11:11 --> Model Class Initialized
INFO - 2019-07-03 21:11:11 --> Model Class Initialized
INFO - 2019-07-03 21:11:11 --> Final output sent to browser
DEBUG - 2019-07-03 21:11:11 --> Total execution time: 0.4859
INFO - 2019-07-03 15:11:16 --> Config Class Initialized
INFO - 2019-07-03 15:11:16 --> Hooks Class Initialized
DEBUG - 2019-07-03 15:11:16 --> UTF-8 Support Enabled
INFO - 2019-07-03 15:11:16 --> Utf8 Class Initialized
INFO - 2019-07-03 15:11:16 --> URI Class Initialized
INFO - 2019-07-03 15:11:16 --> Router Class Initialized
INFO - 2019-07-03 15:11:16 --> Output Class Initialized
INFO - 2019-07-03 15:11:16 --> Security Class Initialized
DEBUG - 2019-07-03 15:11:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 15:11:16 --> Input Class Initialized
INFO - 2019-07-03 15:11:16 --> Language Class Initialized
INFO - 2019-07-03 15:11:16 --> Language Class Initialized
INFO - 2019-07-03 15:11:16 --> Config Class Initialized
INFO - 2019-07-03 15:11:16 --> Loader Class Initialized
DEBUG - 2019-07-03 15:11:16 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 15:11:16 --> Helper loaded: url_helper
INFO - 2019-07-03 15:11:16 --> Helper loaded: inflector_helper
INFO - 2019-07-03 15:11:16 --> Helper loaded: string_helper
INFO - 2019-07-03 15:11:16 --> Helper loaded: array_helper
INFO - 2019-07-03 15:11:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 15:11:16 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 15:11:16 --> Database Driver Class Initialized
INFO - 2019-07-03 15:11:17 --> Controller Class Initialized
INFO - 2019-07-03 21:11:17 --> Helper loaded: language_helper
INFO - 2019-07-03 21:11:17 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 21:11:17 --> Model Class Initialized
INFO - 2019-07-03 21:11:17 --> Model Class Initialized
INFO - 2019-07-03 21:11:17 --> Model Class Initialized
INFO - 2019-07-03 21:11:17 --> Model Class Initialized
INFO - 2019-07-03 21:11:17 --> Final output sent to browser
DEBUG - 2019-07-03 21:11:17 --> Total execution time: 0.2764
INFO - 2019-07-03 15:11:32 --> Config Class Initialized
INFO - 2019-07-03 15:11:32 --> Hooks Class Initialized
INFO - 2019-07-03 15:11:32 --> Config Class Initialized
DEBUG - 2019-07-03 15:11:32 --> UTF-8 Support Enabled
INFO - 2019-07-03 15:11:32 --> Hooks Class Initialized
INFO - 2019-07-03 15:11:32 --> Utf8 Class Initialized
DEBUG - 2019-07-03 15:11:32 --> UTF-8 Support Enabled
INFO - 2019-07-03 15:11:32 --> URI Class Initialized
INFO - 2019-07-03 15:11:32 --> Utf8 Class Initialized
INFO - 2019-07-03 15:11:32 --> URI Class Initialized
INFO - 2019-07-03 15:11:32 --> Router Class Initialized
INFO - 2019-07-03 15:11:32 --> Router Class Initialized
INFO - 2019-07-03 15:11:32 --> Output Class Initialized
INFO - 2019-07-03 15:11:32 --> Output Class Initialized
INFO - 2019-07-03 15:11:32 --> Security Class Initialized
INFO - 2019-07-03 15:11:32 --> Security Class Initialized
DEBUG - 2019-07-03 15:11:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-03 15:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 15:11:32 --> Input Class Initialized
INFO - 2019-07-03 15:11:32 --> Input Class Initialized
INFO - 2019-07-03 15:11:32 --> Language Class Initialized
INFO - 2019-07-03 15:11:32 --> Language Class Initialized
INFO - 2019-07-03 15:11:32 --> Language Class Initialized
INFO - 2019-07-03 15:11:32 --> Language Class Initialized
INFO - 2019-07-03 15:11:32 --> Config Class Initialized
INFO - 2019-07-03 15:11:32 --> Config Class Initialized
INFO - 2019-07-03 15:11:32 --> Loader Class Initialized
INFO - 2019-07-03 15:11:32 --> Loader Class Initialized
DEBUG - 2019-07-03 15:11:32 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-03 15:11:32 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 15:11:32 --> Helper loaded: url_helper
INFO - 2019-07-03 15:11:32 --> Helper loaded: url_helper
INFO - 2019-07-03 15:11:32 --> Helper loaded: inflector_helper
INFO - 2019-07-03 15:11:32 --> Helper loaded: inflector_helper
INFO - 2019-07-03 15:11:32 --> Helper loaded: string_helper
INFO - 2019-07-03 15:11:32 --> Helper loaded: string_helper
INFO - 2019-07-03 15:11:32 --> Helper loaded: array_helper
INFO - 2019-07-03 15:11:32 --> Helper loaded: array_helper
INFO - 2019-07-03 15:11:32 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 15:11:32 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 15:11:32 --> Database Driver Class Initialized
INFO - 2019-07-03 15:11:32 --> Controller Class Initialized
INFO - 2019-07-03 21:11:32 --> Helper loaded: language_helper
INFO - 2019-07-03 21:11:32 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 21:11:32 --> Model Class Initialized
INFO - 2019-07-03 21:11:32 --> Model Class Initialized
INFO - 2019-07-03 21:11:32 --> Model Class Initialized
INFO - 2019-07-03 21:11:32 --> Model Class Initialized
INFO - 2019-07-03 21:11:32 --> Model Class Initialized
INFO - 2019-07-03 21:11:32 --> Final output sent to browser
DEBUG - 2019-07-03 21:11:32 --> Total execution time: 0.3976
INFO - 2019-07-03 15:11:32 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 15:11:32 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 15:11:32 --> Database Driver Class Initialized
INFO - 2019-07-03 15:11:32 --> Controller Class Initialized
INFO - 2019-07-03 21:11:32 --> Helper loaded: language_helper
INFO - 2019-07-03 21:11:32 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 21:11:32 --> Model Class Initialized
INFO - 2019-07-03 21:11:32 --> Model Class Initialized
INFO - 2019-07-03 21:11:32 --> Model Class Initialized
INFO - 2019-07-03 21:11:32 --> Model Class Initialized
INFO - 2019-07-03 21:11:32 --> Final output sent to browser
DEBUG - 2019-07-03 21:11:32 --> Total execution time: 0.5006
INFO - 2019-07-03 15:11:35 --> Config Class Initialized
INFO - 2019-07-03 15:11:35 --> Config Class Initialized
INFO - 2019-07-03 15:11:35 --> Hooks Class Initialized
INFO - 2019-07-03 15:11:35 --> Hooks Class Initialized
DEBUG - 2019-07-03 15:11:35 --> UTF-8 Support Enabled
DEBUG - 2019-07-03 15:11:35 --> UTF-8 Support Enabled
INFO - 2019-07-03 15:11:35 --> Utf8 Class Initialized
INFO - 2019-07-03 15:11:35 --> Utf8 Class Initialized
INFO - 2019-07-03 15:11:35 --> URI Class Initialized
INFO - 2019-07-03 15:11:35 --> URI Class Initialized
INFO - 2019-07-03 15:11:35 --> Router Class Initialized
INFO - 2019-07-03 15:11:35 --> Router Class Initialized
INFO - 2019-07-03 15:11:35 --> Output Class Initialized
INFO - 2019-07-03 15:11:35 --> Output Class Initialized
INFO - 2019-07-03 15:11:35 --> Security Class Initialized
INFO - 2019-07-03 15:11:35 --> Security Class Initialized
DEBUG - 2019-07-03 15:11:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-03 15:11:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 15:11:35 --> Input Class Initialized
INFO - 2019-07-03 15:11:35 --> Input Class Initialized
INFO - 2019-07-03 15:11:35 --> Language Class Initialized
INFO - 2019-07-03 15:11:35 --> Language Class Initialized
INFO - 2019-07-03 15:11:35 --> Language Class Initialized
INFO - 2019-07-03 15:11:35 --> Language Class Initialized
INFO - 2019-07-03 15:11:35 --> Config Class Initialized
INFO - 2019-07-03 15:11:35 --> Config Class Initialized
INFO - 2019-07-03 15:11:35 --> Loader Class Initialized
INFO - 2019-07-03 15:11:35 --> Loader Class Initialized
DEBUG - 2019-07-03 15:11:35 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-03 15:11:35 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 15:11:35 --> Helper loaded: url_helper
INFO - 2019-07-03 15:11:35 --> Helper loaded: url_helper
INFO - 2019-07-03 15:11:35 --> Helper loaded: inflector_helper
INFO - 2019-07-03 15:11:35 --> Helper loaded: inflector_helper
INFO - 2019-07-03 15:11:35 --> Helper loaded: string_helper
INFO - 2019-07-03 15:11:35 --> Helper loaded: string_helper
INFO - 2019-07-03 15:11:35 --> Helper loaded: array_helper
INFO - 2019-07-03 15:11:35 --> Helper loaded: array_helper
INFO - 2019-07-03 15:11:35 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 15:11:35 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 15:11:35 --> Database Driver Class Initialized
INFO - 2019-07-03 15:11:35 --> Controller Class Initialized
INFO - 2019-07-03 21:11:35 --> Helper loaded: language_helper
INFO - 2019-07-03 21:11:35 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 21:11:35 --> Model Class Initialized
INFO - 2019-07-03 21:11:35 --> Model Class Initialized
INFO - 2019-07-03 21:11:35 --> Model Class Initialized
INFO - 2019-07-03 21:11:35 --> Model Class Initialized
INFO - 2019-07-03 21:11:35 --> Final output sent to browser
DEBUG - 2019-07-03 21:11:35 --> Total execution time: 0.3284
INFO - 2019-07-03 15:11:35 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 15:11:35 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 15:11:35 --> Database Driver Class Initialized
INFO - 2019-07-03 15:11:35 --> Controller Class Initialized
INFO - 2019-07-03 21:11:35 --> Helper loaded: language_helper
INFO - 2019-07-03 21:11:35 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 21:11:35 --> Model Class Initialized
INFO - 2019-07-03 21:11:35 --> Model Class Initialized
INFO - 2019-07-03 21:11:35 --> Model Class Initialized
INFO - 2019-07-03 21:11:35 --> Model Class Initialized
INFO - 2019-07-03 21:11:35 --> Model Class Initialized
INFO - 2019-07-03 21:11:35 --> Final output sent to browser
DEBUG - 2019-07-03 21:11:35 --> Total execution time: 0.4811
INFO - 2019-07-03 15:11:37 --> Config Class Initialized
INFO - 2019-07-03 15:11:37 --> Hooks Class Initialized
DEBUG - 2019-07-03 15:11:37 --> UTF-8 Support Enabled
INFO - 2019-07-03 15:11:37 --> Utf8 Class Initialized
INFO - 2019-07-03 15:11:37 --> URI Class Initialized
INFO - 2019-07-03 15:11:37 --> Router Class Initialized
INFO - 2019-07-03 15:11:37 --> Output Class Initialized
INFO - 2019-07-03 15:11:37 --> Security Class Initialized
DEBUG - 2019-07-03 15:11:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 15:11:37 --> Input Class Initialized
INFO - 2019-07-03 15:11:37 --> Language Class Initialized
INFO - 2019-07-03 15:11:37 --> Language Class Initialized
INFO - 2019-07-03 15:11:37 --> Config Class Initialized
INFO - 2019-07-03 15:11:37 --> Loader Class Initialized
DEBUG - 2019-07-03 15:11:37 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 15:11:37 --> Helper loaded: url_helper
INFO - 2019-07-03 15:11:37 --> Helper loaded: inflector_helper
INFO - 2019-07-03 15:11:37 --> Helper loaded: string_helper
INFO - 2019-07-03 15:11:37 --> Helper loaded: array_helper
INFO - 2019-07-03 15:11:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 15:11:37 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 15:11:37 --> Database Driver Class Initialized
INFO - 2019-07-03 15:11:37 --> Controller Class Initialized
INFO - 2019-07-03 21:11:37 --> Helper loaded: language_helper
INFO - 2019-07-03 21:11:37 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 21:11:37 --> Model Class Initialized
INFO - 2019-07-03 21:11:37 --> Model Class Initialized
INFO - 2019-07-03 21:11:37 --> Model Class Initialized
INFO - 2019-07-03 21:11:37 --> Model Class Initialized
INFO - 2019-07-03 21:11:37 --> Final output sent to browser
DEBUG - 2019-07-03 21:11:37 --> Total execution time: 0.2793
INFO - 2019-07-03 15:11:44 --> Config Class Initialized
INFO - 2019-07-03 15:11:44 --> Hooks Class Initialized
DEBUG - 2019-07-03 15:11:44 --> UTF-8 Support Enabled
INFO - 2019-07-03 15:11:44 --> Utf8 Class Initialized
INFO - 2019-07-03 15:11:44 --> URI Class Initialized
INFO - 2019-07-03 15:11:44 --> Router Class Initialized
INFO - 2019-07-03 15:11:44 --> Output Class Initialized
INFO - 2019-07-03 15:11:44 --> Security Class Initialized
DEBUG - 2019-07-03 15:11:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 15:11:44 --> Input Class Initialized
INFO - 2019-07-03 15:11:44 --> Language Class Initialized
INFO - 2019-07-03 15:11:44 --> Language Class Initialized
INFO - 2019-07-03 15:11:44 --> Config Class Initialized
INFO - 2019-07-03 15:11:44 --> Loader Class Initialized
DEBUG - 2019-07-03 15:11:44 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 15:11:44 --> Helper loaded: url_helper
INFO - 2019-07-03 15:11:44 --> Helper loaded: inflector_helper
INFO - 2019-07-03 15:11:44 --> Helper loaded: string_helper
INFO - 2019-07-03 15:11:44 --> Helper loaded: array_helper
INFO - 2019-07-03 15:11:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 15:11:44 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 15:11:44 --> Database Driver Class Initialized
INFO - 2019-07-03 15:11:45 --> Controller Class Initialized
INFO - 2019-07-03 21:11:45 --> Helper loaded: language_helper
INFO - 2019-07-03 21:11:45 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 21:11:45 --> Model Class Initialized
INFO - 2019-07-03 21:11:45 --> Model Class Initialized
INFO - 2019-07-03 21:11:45 --> Model Class Initialized
INFO - 2019-07-03 21:11:45 --> Model Class Initialized
INFO - 2019-07-03 21:11:45 --> Final output sent to browser
DEBUG - 2019-07-03 21:11:45 --> Total execution time: 0.2840
INFO - 2019-07-03 15:14:31 --> Config Class Initialized
INFO - 2019-07-03 15:14:31 --> Hooks Class Initialized
DEBUG - 2019-07-03 15:14:31 --> UTF-8 Support Enabled
INFO - 2019-07-03 15:14:31 --> Utf8 Class Initialized
INFO - 2019-07-03 15:14:31 --> URI Class Initialized
INFO - 2019-07-03 15:14:31 --> Router Class Initialized
INFO - 2019-07-03 15:14:31 --> Output Class Initialized
INFO - 2019-07-03 15:14:31 --> Security Class Initialized
DEBUG - 2019-07-03 15:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 15:14:31 --> Input Class Initialized
INFO - 2019-07-03 15:14:31 --> Language Class Initialized
INFO - 2019-07-03 15:14:31 --> Language Class Initialized
INFO - 2019-07-03 15:14:31 --> Config Class Initialized
INFO - 2019-07-03 15:14:31 --> Loader Class Initialized
DEBUG - 2019-07-03 15:14:31 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 15:14:31 --> Helper loaded: url_helper
INFO - 2019-07-03 15:14:31 --> Helper loaded: inflector_helper
INFO - 2019-07-03 15:14:31 --> Helper loaded: string_helper
INFO - 2019-07-03 15:14:31 --> Helper loaded: array_helper
INFO - 2019-07-03 15:14:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 15:14:31 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 15:14:31 --> Database Driver Class Initialized
INFO - 2019-07-03 15:14:31 --> Controller Class Initialized
INFO - 2019-07-03 21:14:31 --> Helper loaded: language_helper
INFO - 2019-07-03 21:14:31 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 21:14:31 --> Model Class Initialized
INFO - 2019-07-03 21:14:31 --> Model Class Initialized
INFO - 2019-07-03 21:14:31 --> Model Class Initialized
INFO - 2019-07-03 21:14:31 --> Model Class Initialized
INFO - 2019-07-03 21:14:31 --> Final output sent to browser
DEBUG - 2019-07-03 21:14:31 --> Total execution time: 0.2959
INFO - 2019-07-03 15:14:32 --> Config Class Initialized
INFO - 2019-07-03 15:14:32 --> Hooks Class Initialized
DEBUG - 2019-07-03 15:14:32 --> UTF-8 Support Enabled
INFO - 2019-07-03 15:14:32 --> Utf8 Class Initialized
INFO - 2019-07-03 15:14:32 --> URI Class Initialized
INFO - 2019-07-03 15:14:32 --> Router Class Initialized
INFO - 2019-07-03 15:14:32 --> Output Class Initialized
INFO - 2019-07-03 15:14:32 --> Security Class Initialized
DEBUG - 2019-07-03 15:14:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 15:14:32 --> Input Class Initialized
INFO - 2019-07-03 15:14:32 --> Language Class Initialized
INFO - 2019-07-03 15:14:32 --> Language Class Initialized
INFO - 2019-07-03 15:14:32 --> Config Class Initialized
INFO - 2019-07-03 15:14:32 --> Loader Class Initialized
DEBUG - 2019-07-03 15:14:32 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 15:14:32 --> Helper loaded: url_helper
INFO - 2019-07-03 15:14:32 --> Helper loaded: inflector_helper
INFO - 2019-07-03 15:14:32 --> Helper loaded: string_helper
INFO - 2019-07-03 15:14:32 --> Helper loaded: array_helper
INFO - 2019-07-03 15:14:32 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 15:14:32 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 15:14:32 --> Database Driver Class Initialized
INFO - 2019-07-03 15:14:32 --> Controller Class Initialized
INFO - 2019-07-03 21:14:32 --> Helper loaded: language_helper
INFO - 2019-07-03 21:14:32 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 21:14:32 --> Model Class Initialized
INFO - 2019-07-03 21:14:32 --> Model Class Initialized
INFO - 2019-07-03 21:14:32 --> Model Class Initialized
INFO - 2019-07-03 21:14:32 --> Model Class Initialized
INFO - 2019-07-03 21:14:32 --> Final output sent to browser
DEBUG - 2019-07-03 21:14:32 --> Total execution time: 0.2810
INFO - 2019-07-03 15:14:35 --> Config Class Initialized
INFO - 2019-07-03 15:14:35 --> Hooks Class Initialized
INFO - 2019-07-03 15:14:35 --> Config Class Initialized
DEBUG - 2019-07-03 15:14:35 --> UTF-8 Support Enabled
INFO - 2019-07-03 15:14:35 --> Hooks Class Initialized
INFO - 2019-07-03 15:14:35 --> Utf8 Class Initialized
DEBUG - 2019-07-03 15:14:35 --> UTF-8 Support Enabled
INFO - 2019-07-03 15:14:35 --> URI Class Initialized
INFO - 2019-07-03 15:14:35 --> Utf8 Class Initialized
INFO - 2019-07-03 15:14:35 --> URI Class Initialized
INFO - 2019-07-03 15:14:35 --> Router Class Initialized
INFO - 2019-07-03 15:14:35 --> Router Class Initialized
INFO - 2019-07-03 15:14:35 --> Output Class Initialized
INFO - 2019-07-03 15:14:35 --> Output Class Initialized
INFO - 2019-07-03 15:14:35 --> Security Class Initialized
INFO - 2019-07-03 15:14:35 --> Security Class Initialized
DEBUG - 2019-07-03 15:14:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-03 15:14:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 15:14:35 --> Input Class Initialized
INFO - 2019-07-03 15:14:35 --> Input Class Initialized
INFO - 2019-07-03 15:14:35 --> Language Class Initialized
INFO - 2019-07-03 15:14:35 --> Language Class Initialized
INFO - 2019-07-03 15:14:35 --> Language Class Initialized
INFO - 2019-07-03 15:14:35 --> Language Class Initialized
INFO - 2019-07-03 15:14:35 --> Config Class Initialized
INFO - 2019-07-03 15:14:35 --> Config Class Initialized
INFO - 2019-07-03 15:14:35 --> Loader Class Initialized
INFO - 2019-07-03 15:14:35 --> Loader Class Initialized
DEBUG - 2019-07-03 15:14:35 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-03 15:14:35 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 15:14:35 --> Helper loaded: url_helper
INFO - 2019-07-03 15:14:35 --> Helper loaded: url_helper
INFO - 2019-07-03 15:14:35 --> Helper loaded: inflector_helper
INFO - 2019-07-03 15:14:35 --> Helper loaded: inflector_helper
INFO - 2019-07-03 15:14:35 --> Helper loaded: string_helper
INFO - 2019-07-03 15:14:35 --> Helper loaded: string_helper
INFO - 2019-07-03 15:14:35 --> Helper loaded: array_helper
INFO - 2019-07-03 15:14:35 --> Helper loaded: array_helper
INFO - 2019-07-03 15:14:35 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 15:14:35 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 15:14:35 --> Database Driver Class Initialized
INFO - 2019-07-03 15:14:35 --> Controller Class Initialized
INFO - 2019-07-03 21:14:35 --> Helper loaded: language_helper
INFO - 2019-07-03 21:14:35 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 21:14:35 --> Model Class Initialized
INFO - 2019-07-03 21:14:35 --> Model Class Initialized
INFO - 2019-07-03 21:14:35 --> Model Class Initialized
INFO - 2019-07-03 21:14:35 --> Model Class Initialized
INFO - 2019-07-03 21:14:35 --> Model Class Initialized
INFO - 2019-07-03 21:14:35 --> Final output sent to browser
DEBUG - 2019-07-03 21:14:35 --> Total execution time: 0.3948
INFO - 2019-07-03 15:14:35 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 15:14:35 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 15:14:35 --> Database Driver Class Initialized
INFO - 2019-07-03 15:14:35 --> Controller Class Initialized
INFO - 2019-07-03 21:14:35 --> Helper loaded: language_helper
INFO - 2019-07-03 21:14:35 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 21:14:35 --> Model Class Initialized
INFO - 2019-07-03 21:14:35 --> Model Class Initialized
INFO - 2019-07-03 21:14:35 --> Model Class Initialized
INFO - 2019-07-03 21:14:35 --> Model Class Initialized
INFO - 2019-07-03 21:14:35 --> Final output sent to browser
DEBUG - 2019-07-03 21:14:35 --> Total execution time: 0.5061
INFO - 2019-07-03 15:15:46 --> Config Class Initialized
INFO - 2019-07-03 15:15:46 --> Hooks Class Initialized
INFO - 2019-07-03 15:15:46 --> Config Class Initialized
INFO - 2019-07-03 15:15:46 --> Hooks Class Initialized
DEBUG - 2019-07-03 15:15:46 --> UTF-8 Support Enabled
INFO - 2019-07-03 15:15:46 --> Utf8 Class Initialized
DEBUG - 2019-07-03 15:15:46 --> UTF-8 Support Enabled
INFO - 2019-07-03 15:15:46 --> URI Class Initialized
INFO - 2019-07-03 15:15:46 --> Utf8 Class Initialized
INFO - 2019-07-03 15:15:46 --> URI Class Initialized
INFO - 2019-07-03 15:15:46 --> Router Class Initialized
INFO - 2019-07-03 15:15:46 --> Router Class Initialized
INFO - 2019-07-03 15:15:46 --> Output Class Initialized
INFO - 2019-07-03 15:15:46 --> Output Class Initialized
INFO - 2019-07-03 15:15:46 --> Security Class Initialized
INFO - 2019-07-03 15:15:46 --> Security Class Initialized
DEBUG - 2019-07-03 15:15:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-03 15:15:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 15:15:46 --> Input Class Initialized
INFO - 2019-07-03 15:15:46 --> Input Class Initialized
INFO - 2019-07-03 15:15:46 --> Language Class Initialized
INFO - 2019-07-03 15:15:46 --> Language Class Initialized
INFO - 2019-07-03 15:15:46 --> Language Class Initialized
INFO - 2019-07-03 15:15:46 --> Language Class Initialized
INFO - 2019-07-03 15:15:46 --> Config Class Initialized
INFO - 2019-07-03 15:15:46 --> Config Class Initialized
INFO - 2019-07-03 15:15:46 --> Loader Class Initialized
INFO - 2019-07-03 15:15:46 --> Loader Class Initialized
DEBUG - 2019-07-03 15:15:46 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-03 15:15:46 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 15:15:46 --> Helper loaded: url_helper
INFO - 2019-07-03 15:15:46 --> Helper loaded: url_helper
INFO - 2019-07-03 15:15:46 --> Helper loaded: inflector_helper
INFO - 2019-07-03 15:15:46 --> Helper loaded: inflector_helper
INFO - 2019-07-03 15:15:46 --> Helper loaded: string_helper
INFO - 2019-07-03 15:15:46 --> Helper loaded: string_helper
INFO - 2019-07-03 15:15:46 --> Helper loaded: array_helper
INFO - 2019-07-03 15:15:46 --> Helper loaded: array_helper
INFO - 2019-07-03 15:15:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 15:15:46 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 15:15:46 --> Database Driver Class Initialized
INFO - 2019-07-03 15:15:47 --> Controller Class Initialized
INFO - 2019-07-03 21:15:47 --> Helper loaded: language_helper
INFO - 2019-07-03 21:15:47 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 21:15:47 --> Model Class Initialized
INFO - 2019-07-03 21:15:47 --> Model Class Initialized
INFO - 2019-07-03 21:15:47 --> Model Class Initialized
INFO - 2019-07-03 21:15:47 --> Model Class Initialized
INFO - 2019-07-03 21:15:47 --> Model Class Initialized
INFO - 2019-07-03 21:15:47 --> Final output sent to browser
DEBUG - 2019-07-03 21:15:47 --> Total execution time: 0.3853
INFO - 2019-07-03 15:15:47 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 15:15:47 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 15:15:47 --> Database Driver Class Initialized
INFO - 2019-07-03 15:15:47 --> Controller Class Initialized
INFO - 2019-07-03 21:15:47 --> Helper loaded: language_helper
INFO - 2019-07-03 21:15:47 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 21:15:47 --> Model Class Initialized
INFO - 2019-07-03 21:15:47 --> Model Class Initialized
INFO - 2019-07-03 21:15:47 --> Model Class Initialized
INFO - 2019-07-03 21:15:47 --> Model Class Initialized
INFO - 2019-07-03 21:15:47 --> Final output sent to browser
DEBUG - 2019-07-03 21:15:47 --> Total execution time: 0.4870
INFO - 2019-07-03 15:15:49 --> Config Class Initialized
INFO - 2019-07-03 15:15:49 --> Config Class Initialized
INFO - 2019-07-03 15:15:49 --> Hooks Class Initialized
INFO - 2019-07-03 15:15:49 --> Hooks Class Initialized
DEBUG - 2019-07-03 15:15:49 --> UTF-8 Support Enabled
DEBUG - 2019-07-03 15:15:49 --> UTF-8 Support Enabled
INFO - 2019-07-03 15:15:49 --> Utf8 Class Initialized
INFO - 2019-07-03 15:15:49 --> Utf8 Class Initialized
INFO - 2019-07-03 15:15:49 --> URI Class Initialized
INFO - 2019-07-03 15:15:49 --> URI Class Initialized
INFO - 2019-07-03 15:15:49 --> Router Class Initialized
INFO - 2019-07-03 15:15:49 --> Router Class Initialized
INFO - 2019-07-03 15:15:49 --> Output Class Initialized
INFO - 2019-07-03 15:15:49 --> Output Class Initialized
INFO - 2019-07-03 15:15:49 --> Security Class Initialized
INFO - 2019-07-03 15:15:49 --> Security Class Initialized
DEBUG - 2019-07-03 15:15:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-03 15:15:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 15:15:49 --> Input Class Initialized
INFO - 2019-07-03 15:15:49 --> Input Class Initialized
INFO - 2019-07-03 15:15:49 --> Language Class Initialized
INFO - 2019-07-03 15:15:49 --> Language Class Initialized
INFO - 2019-07-03 15:15:49 --> Language Class Initialized
INFO - 2019-07-03 15:15:49 --> Language Class Initialized
INFO - 2019-07-03 15:15:49 --> Config Class Initialized
INFO - 2019-07-03 15:15:49 --> Loader Class Initialized
INFO - 2019-07-03 15:15:49 --> Config Class Initialized
INFO - 2019-07-03 15:15:49 --> Loader Class Initialized
DEBUG - 2019-07-03 15:15:49 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-03 15:15:49 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 15:15:49 --> Helper loaded: url_helper
INFO - 2019-07-03 15:15:50 --> Helper loaded: url_helper
INFO - 2019-07-03 15:15:50 --> Helper loaded: inflector_helper
INFO - 2019-07-03 15:15:50 --> Helper loaded: inflector_helper
INFO - 2019-07-03 15:15:50 --> Helper loaded: string_helper
INFO - 2019-07-03 15:15:50 --> Helper loaded: string_helper
INFO - 2019-07-03 15:15:50 --> Helper loaded: array_helper
INFO - 2019-07-03 15:15:50 --> Helper loaded: array_helper
INFO - 2019-07-03 15:15:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 15:15:50 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 15:15:50 --> Database Driver Class Initialized
INFO - 2019-07-03 15:15:50 --> Controller Class Initialized
INFO - 2019-07-03 21:15:50 --> Helper loaded: language_helper
INFO - 2019-07-03 21:15:50 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 21:15:50 --> Model Class Initialized
INFO - 2019-07-03 21:15:50 --> Model Class Initialized
INFO - 2019-07-03 21:15:50 --> Model Class Initialized
INFO - 2019-07-03 21:15:50 --> Model Class Initialized
INFO - 2019-07-03 21:15:50 --> Model Class Initialized
INFO - 2019-07-03 21:15:50 --> Final output sent to browser
DEBUG - 2019-07-03 21:15:50 --> Total execution time: 0.3672
INFO - 2019-07-03 15:15:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 15:15:50 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 15:15:50 --> Database Driver Class Initialized
INFO - 2019-07-03 15:15:50 --> Controller Class Initialized
INFO - 2019-07-03 21:15:50 --> Helper loaded: language_helper
INFO - 2019-07-03 21:15:50 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 21:15:50 --> Model Class Initialized
INFO - 2019-07-03 21:15:50 --> Model Class Initialized
INFO - 2019-07-03 21:15:50 --> Model Class Initialized
INFO - 2019-07-03 21:15:50 --> Model Class Initialized
INFO - 2019-07-03 21:15:50 --> Final output sent to browser
DEBUG - 2019-07-03 21:15:50 --> Total execution time: 0.4784
INFO - 2019-07-03 15:16:58 --> Config Class Initialized
INFO - 2019-07-03 15:16:58 --> Config Class Initialized
INFO - 2019-07-03 15:16:58 --> Hooks Class Initialized
INFO - 2019-07-03 15:16:58 --> Hooks Class Initialized
DEBUG - 2019-07-03 15:16:58 --> UTF-8 Support Enabled
DEBUG - 2019-07-03 15:16:58 --> UTF-8 Support Enabled
INFO - 2019-07-03 15:16:58 --> Utf8 Class Initialized
INFO - 2019-07-03 15:16:58 --> Utf8 Class Initialized
INFO - 2019-07-03 15:16:58 --> URI Class Initialized
INFO - 2019-07-03 15:16:58 --> URI Class Initialized
INFO - 2019-07-03 15:16:58 --> Router Class Initialized
INFO - 2019-07-03 15:16:58 --> Router Class Initialized
INFO - 2019-07-03 15:16:59 --> Output Class Initialized
INFO - 2019-07-03 15:16:59 --> Output Class Initialized
INFO - 2019-07-03 15:16:59 --> Security Class Initialized
INFO - 2019-07-03 15:16:59 --> Security Class Initialized
DEBUG - 2019-07-03 15:16:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-03 15:16:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 15:16:59 --> Input Class Initialized
INFO - 2019-07-03 15:16:59 --> Input Class Initialized
INFO - 2019-07-03 15:16:59 --> Language Class Initialized
INFO - 2019-07-03 15:16:59 --> Language Class Initialized
INFO - 2019-07-03 15:16:59 --> Language Class Initialized
INFO - 2019-07-03 15:16:59 --> Language Class Initialized
INFO - 2019-07-03 15:16:59 --> Config Class Initialized
INFO - 2019-07-03 15:16:59 --> Config Class Initialized
INFO - 2019-07-03 15:16:59 --> Loader Class Initialized
INFO - 2019-07-03 15:16:59 --> Hooks Class Initialized
INFO - 2019-07-03 15:16:59 --> Config Class Initialized
INFO - 2019-07-03 15:16:59 --> Loader Class Initialized
INFO - 2019-07-03 15:16:59 --> Config Class Initialized
DEBUG - 2019-07-03 15:16:59 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-03 15:16:59 --> UTF-8 Support Enabled
INFO - 2019-07-03 15:16:59 --> Hooks Class Initialized
DEBUG - 2019-07-03 15:16:59 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 15:16:59 --> Utf8 Class Initialized
DEBUG - 2019-07-03 15:16:59 --> UTF-8 Support Enabled
INFO - 2019-07-03 15:16:59 --> Helper loaded: url_helper
INFO - 2019-07-03 15:16:59 --> URI Class Initialized
INFO - 2019-07-03 15:16:59 --> Helper loaded: url_helper
INFO - 2019-07-03 15:16:59 --> Utf8 Class Initialized
INFO - 2019-07-03 15:16:59 --> Helper loaded: inflector_helper
INFO - 2019-07-03 15:16:59 --> Helper loaded: inflector_helper
INFO - 2019-07-03 15:16:59 --> Router Class Initialized
INFO - 2019-07-03 15:16:59 --> URI Class Initialized
INFO - 2019-07-03 15:16:59 --> Helper loaded: string_helper
INFO - 2019-07-03 15:16:59 --> Router Class Initialized
INFO - 2019-07-03 15:16:59 --> Output Class Initialized
INFO - 2019-07-03 15:16:59 --> Helper loaded: string_helper
INFO - 2019-07-03 15:16:59 --> Helper loaded: array_helper
INFO - 2019-07-03 15:16:59 --> Helper loaded: array_helper
INFO - 2019-07-03 15:16:59 --> Security Class Initialized
INFO - 2019-07-03 15:16:59 --> Output Class Initialized
INFO - 2019-07-03 15:16:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 15:16:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 15:16:59 --> Security Class Initialized
DEBUG - 2019-07-03 15:16:59 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 15:16:59 --> Input Class Initialized
DEBUG - 2019-07-03 15:16:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 15:16:59 --> Database Driver Class Initialized
INFO - 2019-07-03 15:16:59 --> Language Class Initialized
INFO - 2019-07-03 15:16:59 --> Input Class Initialized
INFO - 2019-07-03 15:16:59 --> Language Class Initialized
INFO - 2019-07-03 15:16:59 --> Controller Class Initialized
INFO - 2019-07-03 15:16:59 --> Language Class Initialized
INFO - 2019-07-03 15:16:59 --> Language Class Initialized
INFO - 2019-07-03 15:16:59 --> Config Class Initialized
INFO - 2019-07-03 21:16:59 --> Helper loaded: language_helper
INFO - 2019-07-03 15:16:59 --> Config Class Initialized
INFO - 2019-07-03 15:16:59 --> Loader Class Initialized
INFO - 2019-07-03 15:16:59 --> Loader Class Initialized
INFO - 2019-07-03 21:16:59 --> Language file loaded: language/english/general_lang.php
DEBUG - 2019-07-03 15:16:59 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-03 15:16:59 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 21:16:59 --> Model Class Initialized
INFO - 2019-07-03 15:16:59 --> Helper loaded: url_helper
INFO - 2019-07-03 15:16:59 --> Helper loaded: url_helper
INFO - 2019-07-03 15:16:59 --> Helper loaded: inflector_helper
INFO - 2019-07-03 21:16:59 --> Model Class Initialized
INFO - 2019-07-03 15:16:59 --> Helper loaded: inflector_helper
INFO - 2019-07-03 15:16:59 --> Helper loaded: string_helper
INFO - 2019-07-03 21:16:59 --> Model Class Initialized
INFO - 2019-07-03 15:16:59 --> Helper loaded: string_helper
INFO - 2019-07-03 15:16:59 --> Helper loaded: array_helper
INFO - 2019-07-03 15:16:59 --> Helper loaded: array_helper
INFO - 2019-07-03 21:16:59 --> Model Class Initialized
INFO - 2019-07-03 21:16:59 --> Model Class Initialized
INFO - 2019-07-03 21:16:59 --> Final output sent to browser
DEBUG - 2019-07-03 21:16:59 --> Total execution time: 0.5601
INFO - 2019-07-03 15:16:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 15:16:59 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 15:16:59 --> Database Driver Class Initialized
INFO - 2019-07-03 15:16:59 --> Controller Class Initialized
INFO - 2019-07-03 21:16:59 --> Helper loaded: language_helper
INFO - 2019-07-03 21:16:59 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 21:16:59 --> Model Class Initialized
INFO - 2019-07-03 21:16:59 --> Model Class Initialized
INFO - 2019-07-03 21:16:59 --> Model Class Initialized
INFO - 2019-07-03 21:16:59 --> Model Class Initialized
INFO - 2019-07-03 21:16:59 --> Final output sent to browser
DEBUG - 2019-07-03 21:16:59 --> Total execution time: 0.6558
INFO - 2019-07-03 15:16:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 15:16:59 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 15:16:59 --> Database Driver Class Initialized
INFO - 2019-07-03 15:16:59 --> Controller Class Initialized
INFO - 2019-07-03 21:16:59 --> Helper loaded: language_helper
INFO - 2019-07-03 21:16:59 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 21:16:59 --> Model Class Initialized
INFO - 2019-07-03 21:16:59 --> Model Class Initialized
INFO - 2019-07-03 21:16:59 --> Model Class Initialized
INFO - 2019-07-03 21:16:59 --> Model Class Initialized
INFO - 2019-07-03 21:16:59 --> Model Class Initialized
INFO - 2019-07-03 21:16:59 --> Final output sent to browser
DEBUG - 2019-07-03 21:16:59 --> Total execution time: 0.5342
INFO - 2019-07-03 15:16:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 15:16:59 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 15:16:59 --> Database Driver Class Initialized
INFO - 2019-07-03 15:16:59 --> Controller Class Initialized
INFO - 2019-07-03 21:16:59 --> Helper loaded: language_helper
INFO - 2019-07-03 21:16:59 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 21:16:59 --> Model Class Initialized
INFO - 2019-07-03 21:16:59 --> Model Class Initialized
INFO - 2019-07-03 21:16:59 --> Model Class Initialized
INFO - 2019-07-03 21:16:59 --> Model Class Initialized
INFO - 2019-07-03 21:16:59 --> Final output sent to browser
DEBUG - 2019-07-03 21:16:59 --> Total execution time: 0.6372
INFO - 2019-07-03 15:24:40 --> Config Class Initialized
INFO - 2019-07-03 15:24:40 --> Hooks Class Initialized
INFO - 2019-07-03 15:24:40 --> Config Class Initialized
DEBUG - 2019-07-03 15:24:40 --> UTF-8 Support Enabled
INFO - 2019-07-03 15:24:40 --> Hooks Class Initialized
INFO - 2019-07-03 15:24:40 --> Utf8 Class Initialized
DEBUG - 2019-07-03 15:24:40 --> UTF-8 Support Enabled
INFO - 2019-07-03 15:24:40 --> URI Class Initialized
INFO - 2019-07-03 15:24:40 --> Utf8 Class Initialized
INFO - 2019-07-03 15:24:40 --> URI Class Initialized
INFO - 2019-07-03 15:24:40 --> Router Class Initialized
INFO - 2019-07-03 15:24:40 --> Router Class Initialized
INFO - 2019-07-03 15:24:40 --> Output Class Initialized
INFO - 2019-07-03 15:24:40 --> Output Class Initialized
INFO - 2019-07-03 15:24:40 --> Security Class Initialized
INFO - 2019-07-03 15:24:40 --> Security Class Initialized
DEBUG - 2019-07-03 15:24:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-03 15:24:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 15:24:40 --> Input Class Initialized
INFO - 2019-07-03 15:24:40 --> Input Class Initialized
INFO - 2019-07-03 15:24:40 --> Language Class Initialized
INFO - 2019-07-03 15:24:40 --> Language Class Initialized
INFO - 2019-07-03 15:24:40 --> Language Class Initialized
INFO - 2019-07-03 15:24:40 --> Language Class Initialized
INFO - 2019-07-03 15:24:40 --> Config Class Initialized
INFO - 2019-07-03 15:24:40 --> Config Class Initialized
INFO - 2019-07-03 15:24:40 --> Loader Class Initialized
INFO - 2019-07-03 15:24:40 --> Loader Class Initialized
DEBUG - 2019-07-03 15:24:40 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-03 15:24:40 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 15:24:40 --> Helper loaded: url_helper
INFO - 2019-07-03 15:24:40 --> Helper loaded: url_helper
INFO - 2019-07-03 15:24:40 --> Helper loaded: inflector_helper
INFO - 2019-07-03 15:24:40 --> Helper loaded: inflector_helper
INFO - 2019-07-03 15:24:40 --> Helper loaded: string_helper
INFO - 2019-07-03 15:24:40 --> Helper loaded: string_helper
INFO - 2019-07-03 15:24:40 --> Helper loaded: array_helper
INFO - 2019-07-03 15:24:40 --> Helper loaded: array_helper
INFO - 2019-07-03 15:24:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 15:24:40 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 15:24:40 --> Database Driver Class Initialized
INFO - 2019-07-03 15:24:40 --> Controller Class Initialized
INFO - 2019-07-03 21:24:40 --> Helper loaded: language_helper
INFO - 2019-07-03 21:24:40 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 21:24:40 --> Model Class Initialized
INFO - 2019-07-03 21:24:40 --> Model Class Initialized
INFO - 2019-07-03 21:24:40 --> Model Class Initialized
INFO - 2019-07-03 21:24:40 --> Model Class Initialized
INFO - 2019-07-03 21:24:40 --> Model Class Initialized
INFO - 2019-07-03 21:24:40 --> Final output sent to browser
DEBUG - 2019-07-03 21:24:40 --> Total execution time: 0.3924
INFO - 2019-07-03 15:24:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 15:24:40 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 15:24:40 --> Database Driver Class Initialized
INFO - 2019-07-03 15:24:40 --> Controller Class Initialized
INFO - 2019-07-03 21:24:40 --> Helper loaded: language_helper
INFO - 2019-07-03 21:24:40 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 21:24:41 --> Model Class Initialized
INFO - 2019-07-03 21:24:41 --> Model Class Initialized
INFO - 2019-07-03 21:24:41 --> Model Class Initialized
INFO - 2019-07-03 21:24:41 --> Model Class Initialized
INFO - 2019-07-03 21:24:41 --> Final output sent to browser
DEBUG - 2019-07-03 21:24:41 --> Total execution time: 0.4980
INFO - 2019-07-03 15:24:43 --> Config Class Initialized
INFO - 2019-07-03 15:24:43 --> Config Class Initialized
INFO - 2019-07-03 15:24:43 --> Hooks Class Initialized
INFO - 2019-07-03 15:24:43 --> Hooks Class Initialized
DEBUG - 2019-07-03 15:24:43 --> UTF-8 Support Enabled
DEBUG - 2019-07-03 15:24:43 --> UTF-8 Support Enabled
INFO - 2019-07-03 15:24:43 --> Utf8 Class Initialized
INFO - 2019-07-03 15:24:43 --> Utf8 Class Initialized
INFO - 2019-07-03 15:24:43 --> URI Class Initialized
INFO - 2019-07-03 15:24:43 --> URI Class Initialized
INFO - 2019-07-03 15:24:43 --> Router Class Initialized
INFO - 2019-07-03 15:24:43 --> Router Class Initialized
INFO - 2019-07-03 15:24:43 --> Output Class Initialized
INFO - 2019-07-03 15:24:43 --> Output Class Initialized
INFO - 2019-07-03 15:24:43 --> Security Class Initialized
INFO - 2019-07-03 15:24:43 --> Security Class Initialized
DEBUG - 2019-07-03 15:24:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-03 15:24:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 15:24:43 --> Input Class Initialized
INFO - 2019-07-03 15:24:43 --> Input Class Initialized
INFO - 2019-07-03 15:24:43 --> Language Class Initialized
INFO - 2019-07-03 15:24:43 --> Language Class Initialized
INFO - 2019-07-03 15:24:43 --> Language Class Initialized
INFO - 2019-07-03 15:24:43 --> Language Class Initialized
INFO - 2019-07-03 15:24:43 --> Config Class Initialized
INFO - 2019-07-03 15:24:43 --> Config Class Initialized
INFO - 2019-07-03 15:24:43 --> Loader Class Initialized
INFO - 2019-07-03 15:24:43 --> Loader Class Initialized
DEBUG - 2019-07-03 15:24:43 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-03 15:24:43 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 15:24:43 --> Helper loaded: url_helper
INFO - 2019-07-03 15:24:43 --> Helper loaded: url_helper
INFO - 2019-07-03 15:24:43 --> Helper loaded: inflector_helper
INFO - 2019-07-03 15:24:43 --> Helper loaded: inflector_helper
INFO - 2019-07-03 15:24:43 --> Helper loaded: string_helper
INFO - 2019-07-03 15:24:43 --> Helper loaded: string_helper
INFO - 2019-07-03 15:24:43 --> Helper loaded: array_helper
INFO - 2019-07-03 15:24:43 --> Helper loaded: array_helper
INFO - 2019-07-03 15:24:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 15:24:43 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 15:24:43 --> Database Driver Class Initialized
INFO - 2019-07-03 15:24:43 --> Controller Class Initialized
INFO - 2019-07-03 21:24:43 --> Helper loaded: language_helper
INFO - 2019-07-03 21:24:43 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 21:24:43 --> Model Class Initialized
INFO - 2019-07-03 21:24:43 --> Model Class Initialized
INFO - 2019-07-03 21:24:43 --> Model Class Initialized
INFO - 2019-07-03 21:24:43 --> Model Class Initialized
INFO - 2019-07-03 21:24:43 --> Model Class Initialized
INFO - 2019-07-03 21:24:43 --> Final output sent to browser
DEBUG - 2019-07-03 21:24:43 --> Total execution time: 0.3812
INFO - 2019-07-03 15:24:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 15:24:44 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 15:24:44 --> Database Driver Class Initialized
INFO - 2019-07-03 15:24:44 --> Controller Class Initialized
INFO - 2019-07-03 21:24:44 --> Helper loaded: language_helper
INFO - 2019-07-03 21:24:44 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 21:24:44 --> Model Class Initialized
INFO - 2019-07-03 21:24:44 --> Model Class Initialized
INFO - 2019-07-03 21:24:44 --> Model Class Initialized
INFO - 2019-07-03 21:24:44 --> Model Class Initialized
INFO - 2019-07-03 21:24:44 --> Final output sent to browser
DEBUG - 2019-07-03 21:24:44 --> Total execution time: 0.4875
INFO - 2019-07-03 15:24:52 --> Config Class Initialized
INFO - 2019-07-03 15:24:52 --> Hooks Class Initialized
DEBUG - 2019-07-03 15:24:52 --> UTF-8 Support Enabled
INFO - 2019-07-03 15:24:52 --> Utf8 Class Initialized
INFO - 2019-07-03 15:24:52 --> URI Class Initialized
INFO - 2019-07-03 15:24:52 --> Router Class Initialized
INFO - 2019-07-03 15:24:52 --> Output Class Initialized
INFO - 2019-07-03 15:24:52 --> Security Class Initialized
DEBUG - 2019-07-03 15:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 15:24:52 --> Input Class Initialized
INFO - 2019-07-03 15:24:52 --> Language Class Initialized
INFO - 2019-07-03 15:24:52 --> Language Class Initialized
INFO - 2019-07-03 15:24:52 --> Config Class Initialized
INFO - 2019-07-03 15:24:52 --> Loader Class Initialized
DEBUG - 2019-07-03 15:24:52 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 15:24:52 --> Helper loaded: url_helper
INFO - 2019-07-03 15:24:52 --> Helper loaded: inflector_helper
INFO - 2019-07-03 15:24:52 --> Helper loaded: string_helper
INFO - 2019-07-03 15:24:52 --> Helper loaded: array_helper
INFO - 2019-07-03 15:24:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 15:24:52 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 15:24:52 --> Database Driver Class Initialized
INFO - 2019-07-03 15:24:52 --> Controller Class Initialized
INFO - 2019-07-03 21:24:52 --> Helper loaded: language_helper
INFO - 2019-07-03 21:24:52 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 21:24:52 --> Model Class Initialized
INFO - 2019-07-03 21:24:52 --> Model Class Initialized
INFO - 2019-07-03 21:24:52 --> Model Class Initialized
INFO - 2019-07-03 21:24:52 --> Model Class Initialized
INFO - 2019-07-03 21:24:52 --> Model Class Initialized
INFO - 2019-07-03 21:24:52 --> Final output sent to browser
DEBUG - 2019-07-03 21:24:52 --> Total execution time: 0.2882
INFO - 2019-07-03 15:24:52 --> Config Class Initialized
INFO - 2019-07-03 15:24:52 --> Hooks Class Initialized
DEBUG - 2019-07-03 15:24:52 --> UTF-8 Support Enabled
INFO - 2019-07-03 15:24:52 --> Utf8 Class Initialized
INFO - 2019-07-03 15:24:52 --> URI Class Initialized
INFO - 2019-07-03 15:24:52 --> Router Class Initialized
INFO - 2019-07-03 15:24:52 --> Output Class Initialized
INFO - 2019-07-03 15:24:52 --> Security Class Initialized
DEBUG - 2019-07-03 15:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 15:24:52 --> Input Class Initialized
INFO - 2019-07-03 15:24:52 --> Language Class Initialized
INFO - 2019-07-03 15:24:52 --> Language Class Initialized
INFO - 2019-07-03 15:24:52 --> Config Class Initialized
INFO - 2019-07-03 15:24:52 --> Loader Class Initialized
DEBUG - 2019-07-03 15:24:52 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 15:24:52 --> Helper loaded: url_helper
INFO - 2019-07-03 15:24:52 --> Helper loaded: inflector_helper
INFO - 2019-07-03 15:24:52 --> Helper loaded: string_helper
INFO - 2019-07-03 15:24:52 --> Helper loaded: array_helper
INFO - 2019-07-03 15:24:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 15:24:52 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 15:24:52 --> Database Driver Class Initialized
INFO - 2019-07-03 15:24:52 --> Controller Class Initialized
INFO - 2019-07-03 21:24:52 --> Helper loaded: language_helper
INFO - 2019-07-03 21:24:52 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 21:24:52 --> Model Class Initialized
INFO - 2019-07-03 21:24:52 --> Model Class Initialized
INFO - 2019-07-03 21:24:52 --> Model Class Initialized
INFO - 2019-07-03 21:24:52 --> Model Class Initialized
INFO - 2019-07-03 21:24:52 --> Model Class Initialized
INFO - 2019-07-03 21:24:52 --> Final output sent to browser
DEBUG - 2019-07-03 21:24:52 --> Total execution time: 0.2986
INFO - 2019-07-03 15:25:13 --> Config Class Initialized
INFO - 2019-07-03 15:25:13 --> Config Class Initialized
INFO - 2019-07-03 15:25:13 --> Hooks Class Initialized
INFO - 2019-07-03 15:25:13 --> Hooks Class Initialized
DEBUG - 2019-07-03 15:25:13 --> UTF-8 Support Enabled
DEBUG - 2019-07-03 15:25:13 --> UTF-8 Support Enabled
INFO - 2019-07-03 15:25:13 --> Utf8 Class Initialized
INFO - 2019-07-03 15:25:13 --> Utf8 Class Initialized
INFO - 2019-07-03 15:25:13 --> URI Class Initialized
INFO - 2019-07-03 15:25:13 --> URI Class Initialized
INFO - 2019-07-03 15:25:13 --> Router Class Initialized
INFO - 2019-07-03 15:25:13 --> Router Class Initialized
INFO - 2019-07-03 15:25:13 --> Output Class Initialized
INFO - 2019-07-03 15:25:13 --> Output Class Initialized
INFO - 2019-07-03 15:25:13 --> Security Class Initialized
INFO - 2019-07-03 15:25:13 --> Security Class Initialized
DEBUG - 2019-07-03 15:25:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-03 15:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 15:25:13 --> Input Class Initialized
INFO - 2019-07-03 15:25:13 --> Input Class Initialized
INFO - 2019-07-03 15:25:13 --> Language Class Initialized
INFO - 2019-07-03 15:25:13 --> Language Class Initialized
INFO - 2019-07-03 15:25:13 --> Language Class Initialized
INFO - 2019-07-03 15:25:13 --> Language Class Initialized
INFO - 2019-07-03 15:25:13 --> Config Class Initialized
INFO - 2019-07-03 15:25:13 --> Config Class Initialized
INFO - 2019-07-03 15:25:13 --> Loader Class Initialized
INFO - 2019-07-03 15:25:13 --> Loader Class Initialized
DEBUG - 2019-07-03 15:25:13 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-03 15:25:13 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 15:25:13 --> Helper loaded: url_helper
INFO - 2019-07-03 15:25:13 --> Helper loaded: url_helper
INFO - 2019-07-03 15:25:13 --> Helper loaded: inflector_helper
INFO - 2019-07-03 15:25:13 --> Helper loaded: inflector_helper
INFO - 2019-07-03 15:25:13 --> Helper loaded: string_helper
INFO - 2019-07-03 15:25:13 --> Helper loaded: string_helper
INFO - 2019-07-03 15:25:13 --> Helper loaded: array_helper
INFO - 2019-07-03 15:25:13 --> Helper loaded: array_helper
INFO - 2019-07-03 15:25:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 15:25:13 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 15:25:13 --> Database Driver Class Initialized
INFO - 2019-07-03 15:25:13 --> Controller Class Initialized
INFO - 2019-07-03 21:25:13 --> Helper loaded: language_helper
INFO - 2019-07-03 21:25:13 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 21:25:13 --> Model Class Initialized
INFO - 2019-07-03 21:25:13 --> Model Class Initialized
INFO - 2019-07-03 21:25:13 --> Model Class Initialized
INFO - 2019-07-03 21:25:13 --> Model Class Initialized
INFO - 2019-07-03 21:25:13 --> Final output sent to browser
DEBUG - 2019-07-03 21:25:13 --> Total execution time: 0.3242
INFO - 2019-07-03 15:25:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 15:25:13 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 15:25:13 --> Database Driver Class Initialized
INFO - 2019-07-03 15:25:13 --> Controller Class Initialized
INFO - 2019-07-03 21:25:13 --> Helper loaded: language_helper
INFO - 2019-07-03 21:25:13 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 21:25:13 --> Model Class Initialized
INFO - 2019-07-03 21:25:13 --> Model Class Initialized
INFO - 2019-07-03 21:25:14 --> Model Class Initialized
INFO - 2019-07-03 21:25:14 --> Model Class Initialized
INFO - 2019-07-03 21:25:14 --> Model Class Initialized
INFO - 2019-07-03 21:25:14 --> Final output sent to browser
DEBUG - 2019-07-03 21:25:14 --> Total execution time: 0.4728
INFO - 2019-07-03 15:25:19 --> Config Class Initialized
INFO - 2019-07-03 15:25:19 --> Config Class Initialized
INFO - 2019-07-03 15:25:19 --> Hooks Class Initialized
INFO - 2019-07-03 15:25:19 --> Hooks Class Initialized
DEBUG - 2019-07-03 15:25:19 --> UTF-8 Support Enabled
DEBUG - 2019-07-03 15:25:19 --> UTF-8 Support Enabled
INFO - 2019-07-03 15:25:19 --> Utf8 Class Initialized
INFO - 2019-07-03 15:25:19 --> Utf8 Class Initialized
INFO - 2019-07-03 15:25:19 --> URI Class Initialized
INFO - 2019-07-03 15:25:19 --> URI Class Initialized
INFO - 2019-07-03 15:25:19 --> Router Class Initialized
INFO - 2019-07-03 15:25:19 --> Router Class Initialized
INFO - 2019-07-03 15:25:19 --> Output Class Initialized
INFO - 2019-07-03 15:25:19 --> Output Class Initialized
INFO - 2019-07-03 15:25:19 --> Security Class Initialized
INFO - 2019-07-03 15:25:19 --> Security Class Initialized
DEBUG - 2019-07-03 15:25:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-03 15:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 15:25:19 --> Input Class Initialized
INFO - 2019-07-03 15:25:19 --> Input Class Initialized
INFO - 2019-07-03 15:25:19 --> Language Class Initialized
INFO - 2019-07-03 15:25:19 --> Language Class Initialized
INFO - 2019-07-03 15:25:19 --> Language Class Initialized
INFO - 2019-07-03 15:25:19 --> Language Class Initialized
INFO - 2019-07-03 15:25:19 --> Config Class Initialized
INFO - 2019-07-03 15:25:19 --> Loader Class Initialized
INFO - 2019-07-03 15:25:19 --> Config Class Initialized
INFO - 2019-07-03 15:25:19 --> Loader Class Initialized
DEBUG - 2019-07-03 15:25:19 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-03 15:25:19 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 15:25:20 --> Helper loaded: url_helper
INFO - 2019-07-03 15:25:20 --> Helper loaded: url_helper
INFO - 2019-07-03 15:25:20 --> Helper loaded: inflector_helper
INFO - 2019-07-03 15:25:20 --> Helper loaded: inflector_helper
INFO - 2019-07-03 15:25:20 --> Helper loaded: string_helper
INFO - 2019-07-03 15:25:20 --> Helper loaded: string_helper
INFO - 2019-07-03 15:25:20 --> Helper loaded: array_helper
INFO - 2019-07-03 15:25:20 --> Helper loaded: array_helper
INFO - 2019-07-03 15:25:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 15:25:20 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 15:25:20 --> Database Driver Class Initialized
INFO - 2019-07-03 15:25:20 --> Controller Class Initialized
INFO - 2019-07-03 21:25:20 --> Helper loaded: language_helper
INFO - 2019-07-03 21:25:20 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 21:25:20 --> Model Class Initialized
INFO - 2019-07-03 21:25:20 --> Model Class Initialized
INFO - 2019-07-03 21:25:20 --> Model Class Initialized
INFO - 2019-07-03 21:25:20 --> Model Class Initialized
INFO - 2019-07-03 21:25:20 --> Model Class Initialized
INFO - 2019-07-03 21:25:20 --> Final output sent to browser
DEBUG - 2019-07-03 21:25:20 --> Total execution time: 0.4426
INFO - 2019-07-03 15:25:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 15:25:20 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 15:25:20 --> Database Driver Class Initialized
INFO - 2019-07-03 15:25:20 --> Controller Class Initialized
INFO - 2019-07-03 21:25:20 --> Helper loaded: language_helper
INFO - 2019-07-03 21:25:20 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 21:25:20 --> Model Class Initialized
INFO - 2019-07-03 21:25:20 --> Model Class Initialized
INFO - 2019-07-03 21:25:20 --> Model Class Initialized
INFO - 2019-07-03 21:25:20 --> Model Class Initialized
INFO - 2019-07-03 21:25:20 --> Final output sent to browser
DEBUG - 2019-07-03 21:25:20 --> Total execution time: 0.5777
INFO - 2019-07-03 15:25:22 --> Config Class Initialized
INFO - 2019-07-03 15:25:22 --> Hooks Class Initialized
DEBUG - 2019-07-03 15:25:22 --> UTF-8 Support Enabled
INFO - 2019-07-03 15:25:22 --> Utf8 Class Initialized
INFO - 2019-07-03 15:25:22 --> URI Class Initialized
INFO - 2019-07-03 15:25:22 --> Router Class Initialized
INFO - 2019-07-03 15:25:22 --> Output Class Initialized
INFO - 2019-07-03 15:25:22 --> Security Class Initialized
DEBUG - 2019-07-03 15:25:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 15:25:22 --> Input Class Initialized
INFO - 2019-07-03 15:25:22 --> Language Class Initialized
INFO - 2019-07-03 15:25:22 --> Language Class Initialized
INFO - 2019-07-03 15:25:22 --> Config Class Initialized
INFO - 2019-07-03 15:25:22 --> Loader Class Initialized
DEBUG - 2019-07-03 15:25:22 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 15:25:22 --> Helper loaded: url_helper
INFO - 2019-07-03 15:25:22 --> Helper loaded: inflector_helper
INFO - 2019-07-03 15:25:22 --> Helper loaded: string_helper
INFO - 2019-07-03 15:25:22 --> Helper loaded: array_helper
INFO - 2019-07-03 15:25:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 15:25:22 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 15:25:22 --> Database Driver Class Initialized
INFO - 2019-07-03 15:25:22 --> Controller Class Initialized
INFO - 2019-07-03 21:25:22 --> Helper loaded: language_helper
INFO - 2019-07-03 21:25:22 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 21:25:22 --> Model Class Initialized
INFO - 2019-07-03 21:25:22 --> Model Class Initialized
INFO - 2019-07-03 21:25:22 --> Model Class Initialized
INFO - 2019-07-03 21:25:22 --> Model Class Initialized
INFO - 2019-07-03 21:25:22 --> Model Class Initialized
INFO - 2019-07-03 21:25:22 --> Final output sent to browser
DEBUG - 2019-07-03 21:25:22 --> Total execution time: 0.3087
INFO - 2019-07-03 15:25:22 --> Config Class Initialized
INFO - 2019-07-03 15:25:22 --> Hooks Class Initialized
DEBUG - 2019-07-03 15:25:22 --> UTF-8 Support Enabled
INFO - 2019-07-03 15:25:22 --> Utf8 Class Initialized
INFO - 2019-07-03 15:25:22 --> URI Class Initialized
INFO - 2019-07-03 15:25:22 --> Router Class Initialized
INFO - 2019-07-03 15:25:22 --> Output Class Initialized
INFO - 2019-07-03 15:25:22 --> Security Class Initialized
DEBUG - 2019-07-03 15:25:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 15:25:22 --> Input Class Initialized
INFO - 2019-07-03 15:25:22 --> Language Class Initialized
INFO - 2019-07-03 15:25:22 --> Language Class Initialized
INFO - 2019-07-03 15:25:22 --> Config Class Initialized
INFO - 2019-07-03 15:25:22 --> Loader Class Initialized
DEBUG - 2019-07-03 15:25:22 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 15:25:22 --> Helper loaded: url_helper
INFO - 2019-07-03 15:25:22 --> Helper loaded: inflector_helper
INFO - 2019-07-03 15:25:22 --> Helper loaded: string_helper
INFO - 2019-07-03 15:25:22 --> Helper loaded: array_helper
INFO - 2019-07-03 15:25:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 15:25:22 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 15:25:22 --> Database Driver Class Initialized
INFO - 2019-07-03 15:25:22 --> Controller Class Initialized
INFO - 2019-07-03 21:25:23 --> Helper loaded: language_helper
INFO - 2019-07-03 21:25:23 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 21:25:23 --> Model Class Initialized
INFO - 2019-07-03 21:25:23 --> Model Class Initialized
INFO - 2019-07-03 21:25:23 --> Model Class Initialized
INFO - 2019-07-03 21:25:23 --> Model Class Initialized
INFO - 2019-07-03 21:25:23 --> Model Class Initialized
INFO - 2019-07-03 21:25:23 --> Final output sent to browser
DEBUG - 2019-07-03 21:25:23 --> Total execution time: 0.3031
INFO - 2019-07-03 15:26:09 --> Config Class Initialized
INFO - 2019-07-03 15:26:09 --> Hooks Class Initialized
DEBUG - 2019-07-03 15:26:09 --> UTF-8 Support Enabled
INFO - 2019-07-03 15:26:09 --> Utf8 Class Initialized
INFO - 2019-07-03 15:26:09 --> URI Class Initialized
INFO - 2019-07-03 15:26:09 --> Router Class Initialized
INFO - 2019-07-03 15:26:09 --> Output Class Initialized
INFO - 2019-07-03 15:26:09 --> Security Class Initialized
DEBUG - 2019-07-03 15:26:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 15:26:09 --> Input Class Initialized
INFO - 2019-07-03 15:26:09 --> Language Class Initialized
INFO - 2019-07-03 15:26:09 --> Language Class Initialized
INFO - 2019-07-03 15:26:09 --> Config Class Initialized
INFO - 2019-07-03 15:26:09 --> Loader Class Initialized
DEBUG - 2019-07-03 15:26:09 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 15:26:09 --> Helper loaded: url_helper
INFO - 2019-07-03 15:26:09 --> Helper loaded: inflector_helper
INFO - 2019-07-03 15:26:09 --> Helper loaded: string_helper
INFO - 2019-07-03 15:26:09 --> Helper loaded: array_helper
INFO - 2019-07-03 15:26:09 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 15:26:09 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 15:26:09 --> Database Driver Class Initialized
INFO - 2019-07-03 15:26:09 --> Controller Class Initialized
INFO - 2019-07-03 21:26:09 --> Helper loaded: language_helper
INFO - 2019-07-03 21:26:09 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 21:26:09 --> Model Class Initialized
INFO - 2019-07-03 21:26:09 --> Model Class Initialized
INFO - 2019-07-03 21:26:09 --> Model Class Initialized
INFO - 2019-07-03 21:26:09 --> Model Class Initialized
INFO - 2019-07-03 21:26:09 --> Model Class Initialized
INFO - 2019-07-03 21:26:10 --> Final output sent to browser
DEBUG - 2019-07-03 21:26:10 --> Total execution time: 0.3045
INFO - 2019-07-03 15:26:10 --> Config Class Initialized
INFO - 2019-07-03 15:26:10 --> Hooks Class Initialized
DEBUG - 2019-07-03 15:26:10 --> UTF-8 Support Enabled
INFO - 2019-07-03 15:26:10 --> Utf8 Class Initialized
INFO - 2019-07-03 15:26:10 --> URI Class Initialized
INFO - 2019-07-03 15:26:10 --> Router Class Initialized
INFO - 2019-07-03 15:26:10 --> Output Class Initialized
INFO - 2019-07-03 15:26:10 --> Security Class Initialized
DEBUG - 2019-07-03 15:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 15:26:10 --> Input Class Initialized
INFO - 2019-07-03 15:26:10 --> Language Class Initialized
INFO - 2019-07-03 15:26:10 --> Language Class Initialized
INFO - 2019-07-03 15:26:10 --> Config Class Initialized
INFO - 2019-07-03 15:26:10 --> Loader Class Initialized
DEBUG - 2019-07-03 15:26:10 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 15:26:10 --> Helper loaded: url_helper
INFO - 2019-07-03 15:26:10 --> Helper loaded: inflector_helper
INFO - 2019-07-03 15:26:10 --> Helper loaded: string_helper
INFO - 2019-07-03 15:26:10 --> Helper loaded: array_helper
INFO - 2019-07-03 15:26:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 15:26:10 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 15:26:10 --> Database Driver Class Initialized
INFO - 2019-07-03 15:26:10 --> Controller Class Initialized
INFO - 2019-07-03 21:26:10 --> Helper loaded: language_helper
INFO - 2019-07-03 21:26:10 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 21:26:10 --> Model Class Initialized
INFO - 2019-07-03 21:26:10 --> Model Class Initialized
INFO - 2019-07-03 21:26:10 --> Model Class Initialized
INFO - 2019-07-03 21:26:10 --> Model Class Initialized
INFO - 2019-07-03 21:26:10 --> Model Class Initialized
INFO - 2019-07-03 21:26:10 --> Final output sent to browser
DEBUG - 2019-07-03 21:26:10 --> Total execution time: 0.3080
INFO - 2019-07-03 15:26:12 --> Config Class Initialized
INFO - 2019-07-03 15:26:12 --> Hooks Class Initialized
DEBUG - 2019-07-03 15:26:12 --> UTF-8 Support Enabled
INFO - 2019-07-03 15:26:12 --> Utf8 Class Initialized
INFO - 2019-07-03 15:26:12 --> URI Class Initialized
INFO - 2019-07-03 15:26:12 --> Router Class Initialized
INFO - 2019-07-03 15:26:12 --> Output Class Initialized
INFO - 2019-07-03 15:26:12 --> Security Class Initialized
DEBUG - 2019-07-03 15:26:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 15:26:12 --> Input Class Initialized
INFO - 2019-07-03 15:26:12 --> Language Class Initialized
INFO - 2019-07-03 15:26:12 --> Language Class Initialized
INFO - 2019-07-03 15:26:12 --> Config Class Initialized
INFO - 2019-07-03 15:26:12 --> Loader Class Initialized
DEBUG - 2019-07-03 15:26:12 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 15:26:12 --> Helper loaded: url_helper
INFO - 2019-07-03 15:26:12 --> Helper loaded: inflector_helper
INFO - 2019-07-03 15:26:12 --> Helper loaded: string_helper
INFO - 2019-07-03 15:26:12 --> Helper loaded: array_helper
INFO - 2019-07-03 15:26:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 15:26:13 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 15:26:13 --> Database Driver Class Initialized
INFO - 2019-07-03 15:26:13 --> Controller Class Initialized
INFO - 2019-07-03 21:26:13 --> Helper loaded: language_helper
INFO - 2019-07-03 21:26:13 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 21:26:13 --> Model Class Initialized
INFO - 2019-07-03 21:26:13 --> Model Class Initialized
INFO - 2019-07-03 21:26:13 --> Model Class Initialized
INFO - 2019-07-03 21:26:13 --> Model Class Initialized
INFO - 2019-07-03 21:26:13 --> Model Class Initialized
INFO - 2019-07-03 21:26:13 --> Final output sent to browser
DEBUG - 2019-07-03 21:26:13 --> Total execution time: 0.2884
INFO - 2019-07-03 15:26:13 --> Config Class Initialized
INFO - 2019-07-03 15:26:13 --> Hooks Class Initialized
DEBUG - 2019-07-03 15:26:13 --> UTF-8 Support Enabled
INFO - 2019-07-03 15:26:13 --> Utf8 Class Initialized
INFO - 2019-07-03 15:26:13 --> URI Class Initialized
INFO - 2019-07-03 15:26:13 --> Router Class Initialized
INFO - 2019-07-03 15:26:13 --> Output Class Initialized
INFO - 2019-07-03 15:26:13 --> Security Class Initialized
DEBUG - 2019-07-03 15:26:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 15:26:13 --> Input Class Initialized
INFO - 2019-07-03 15:26:13 --> Language Class Initialized
INFO - 2019-07-03 15:26:13 --> Language Class Initialized
INFO - 2019-07-03 15:26:13 --> Config Class Initialized
INFO - 2019-07-03 15:26:13 --> Loader Class Initialized
DEBUG - 2019-07-03 15:26:13 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 15:26:13 --> Helper loaded: url_helper
INFO - 2019-07-03 15:26:13 --> Helper loaded: inflector_helper
INFO - 2019-07-03 15:26:13 --> Helper loaded: string_helper
INFO - 2019-07-03 15:26:13 --> Helper loaded: array_helper
INFO - 2019-07-03 15:26:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 15:26:13 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 15:26:13 --> Database Driver Class Initialized
INFO - 2019-07-03 15:26:13 --> Controller Class Initialized
INFO - 2019-07-03 21:26:13 --> Helper loaded: language_helper
INFO - 2019-07-03 21:26:13 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 21:26:13 --> Model Class Initialized
INFO - 2019-07-03 21:26:13 --> Model Class Initialized
INFO - 2019-07-03 21:26:13 --> Model Class Initialized
INFO - 2019-07-03 21:26:13 --> Model Class Initialized
INFO - 2019-07-03 21:26:13 --> Model Class Initialized
INFO - 2019-07-03 21:26:13 --> Final output sent to browser
DEBUG - 2019-07-03 21:26:13 --> Total execution time: 0.3322
INFO - 2019-07-03 15:26:27 --> Config Class Initialized
INFO - 2019-07-03 15:26:27 --> Hooks Class Initialized
DEBUG - 2019-07-03 15:26:27 --> UTF-8 Support Enabled
INFO - 2019-07-03 15:26:27 --> Utf8 Class Initialized
INFO - 2019-07-03 15:26:27 --> URI Class Initialized
INFO - 2019-07-03 15:26:27 --> Router Class Initialized
INFO - 2019-07-03 15:26:28 --> Output Class Initialized
INFO - 2019-07-03 15:26:28 --> Security Class Initialized
DEBUG - 2019-07-03 15:26:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 15:26:28 --> Input Class Initialized
INFO - 2019-07-03 15:26:28 --> Language Class Initialized
INFO - 2019-07-03 15:26:28 --> Language Class Initialized
INFO - 2019-07-03 15:26:28 --> Config Class Initialized
INFO - 2019-07-03 15:26:28 --> Loader Class Initialized
DEBUG - 2019-07-03 15:26:28 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 15:26:28 --> Helper loaded: url_helper
INFO - 2019-07-03 15:26:28 --> Helper loaded: inflector_helper
INFO - 2019-07-03 15:26:28 --> Helper loaded: string_helper
INFO - 2019-07-03 15:26:28 --> Helper loaded: array_helper
INFO - 2019-07-03 15:26:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 15:26:28 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 15:26:28 --> Database Driver Class Initialized
INFO - 2019-07-03 15:26:28 --> Controller Class Initialized
INFO - 2019-07-03 21:26:28 --> Helper loaded: language_helper
INFO - 2019-07-03 21:26:28 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 21:26:28 --> Model Class Initialized
INFO - 2019-07-03 21:26:28 --> Model Class Initialized
INFO - 2019-07-03 21:26:28 --> Model Class Initialized
INFO - 2019-07-03 21:26:28 --> Model Class Initialized
INFO - 2019-07-03 21:26:28 --> Model Class Initialized
INFO - 2019-07-03 21:26:28 --> Final output sent to browser
DEBUG - 2019-07-03 21:26:28 --> Total execution time: 0.3707
INFO - 2019-07-03 15:26:28 --> Config Class Initialized
INFO - 2019-07-03 15:26:28 --> Hooks Class Initialized
DEBUG - 2019-07-03 15:26:28 --> UTF-8 Support Enabled
INFO - 2019-07-03 15:26:28 --> Utf8 Class Initialized
INFO - 2019-07-03 15:26:28 --> URI Class Initialized
INFO - 2019-07-03 15:26:28 --> Router Class Initialized
INFO - 2019-07-03 15:26:28 --> Output Class Initialized
INFO - 2019-07-03 15:26:28 --> Security Class Initialized
DEBUG - 2019-07-03 15:26:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 15:26:28 --> Input Class Initialized
INFO - 2019-07-03 15:26:28 --> Language Class Initialized
INFO - 2019-07-03 15:26:28 --> Language Class Initialized
INFO - 2019-07-03 15:26:28 --> Config Class Initialized
INFO - 2019-07-03 15:26:28 --> Loader Class Initialized
DEBUG - 2019-07-03 15:26:28 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 15:26:28 --> Helper loaded: url_helper
INFO - 2019-07-03 15:26:28 --> Helper loaded: inflector_helper
INFO - 2019-07-03 15:26:28 --> Helper loaded: string_helper
INFO - 2019-07-03 15:26:28 --> Helper loaded: array_helper
INFO - 2019-07-03 15:26:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 15:26:28 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 15:26:28 --> Database Driver Class Initialized
INFO - 2019-07-03 15:26:28 --> Controller Class Initialized
INFO - 2019-07-03 21:26:28 --> Helper loaded: language_helper
INFO - 2019-07-03 21:26:28 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 21:26:28 --> Model Class Initialized
INFO - 2019-07-03 21:26:28 --> Model Class Initialized
INFO - 2019-07-03 21:26:28 --> Model Class Initialized
INFO - 2019-07-03 21:26:28 --> Model Class Initialized
INFO - 2019-07-03 21:26:28 --> Model Class Initialized
INFO - 2019-07-03 21:26:28 --> Final output sent to browser
DEBUG - 2019-07-03 21:26:28 --> Total execution time: 0.3171
INFO - 2019-07-03 15:26:28 --> Config Class Initialized
INFO - 2019-07-03 15:26:28 --> Hooks Class Initialized
DEBUG - 2019-07-03 15:26:28 --> UTF-8 Support Enabled
INFO - 2019-07-03 15:26:28 --> Utf8 Class Initialized
INFO - 2019-07-03 15:26:28 --> URI Class Initialized
INFO - 2019-07-03 15:26:28 --> Router Class Initialized
INFO - 2019-07-03 15:26:28 --> Output Class Initialized
INFO - 2019-07-03 15:26:28 --> Security Class Initialized
DEBUG - 2019-07-03 15:26:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 15:26:28 --> Input Class Initialized
INFO - 2019-07-03 15:26:28 --> Language Class Initialized
INFO - 2019-07-03 15:26:28 --> Language Class Initialized
INFO - 2019-07-03 15:26:28 --> Config Class Initialized
INFO - 2019-07-03 15:26:28 --> Loader Class Initialized
DEBUG - 2019-07-03 15:26:28 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 15:26:28 --> Helper loaded: url_helper
INFO - 2019-07-03 15:26:28 --> Helper loaded: inflector_helper
INFO - 2019-07-03 15:26:28 --> Helper loaded: string_helper
INFO - 2019-07-03 15:26:28 --> Helper loaded: array_helper
INFO - 2019-07-03 15:26:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 15:26:28 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 15:26:28 --> Database Driver Class Initialized
INFO - 2019-07-03 15:26:28 --> Controller Class Initialized
INFO - 2019-07-03 21:26:29 --> Helper loaded: language_helper
INFO - 2019-07-03 21:26:29 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 21:26:29 --> Model Class Initialized
INFO - 2019-07-03 21:26:29 --> Model Class Initialized
INFO - 2019-07-03 21:26:29 --> Model Class Initialized
INFO - 2019-07-03 21:26:29 --> Model Class Initialized
INFO - 2019-07-03 21:26:29 --> Model Class Initialized
INFO - 2019-07-03 21:26:29 --> Final output sent to browser
DEBUG - 2019-07-03 21:26:29 --> Total execution time: 0.3295
INFO - 2019-07-03 15:26:31 --> Config Class Initialized
INFO - 2019-07-03 15:26:31 --> Config Class Initialized
INFO - 2019-07-03 15:26:31 --> Hooks Class Initialized
INFO - 2019-07-03 15:26:31 --> Hooks Class Initialized
DEBUG - 2019-07-03 15:26:31 --> UTF-8 Support Enabled
DEBUG - 2019-07-03 15:26:31 --> UTF-8 Support Enabled
INFO - 2019-07-03 15:26:31 --> Utf8 Class Initialized
INFO - 2019-07-03 15:26:31 --> Utf8 Class Initialized
INFO - 2019-07-03 15:26:31 --> URI Class Initialized
INFO - 2019-07-03 15:26:31 --> URI Class Initialized
INFO - 2019-07-03 15:26:31 --> Router Class Initialized
INFO - 2019-07-03 15:26:31 --> Router Class Initialized
INFO - 2019-07-03 15:26:31 --> Output Class Initialized
INFO - 2019-07-03 15:26:31 --> Output Class Initialized
INFO - 2019-07-03 15:26:31 --> Security Class Initialized
INFO - 2019-07-03 15:26:31 --> Security Class Initialized
DEBUG - 2019-07-03 15:26:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-03 15:26:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 15:26:31 --> Input Class Initialized
INFO - 2019-07-03 15:26:31 --> Input Class Initialized
INFO - 2019-07-03 15:26:31 --> Language Class Initialized
INFO - 2019-07-03 15:26:31 --> Language Class Initialized
INFO - 2019-07-03 15:26:31 --> Language Class Initialized
INFO - 2019-07-03 15:26:31 --> Language Class Initialized
INFO - 2019-07-03 15:26:31 --> Config Class Initialized
INFO - 2019-07-03 15:26:31 --> Loader Class Initialized
INFO - 2019-07-03 15:26:31 --> Config Class Initialized
INFO - 2019-07-03 15:26:31 --> Loader Class Initialized
DEBUG - 2019-07-03 15:26:31 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-03 15:26:31 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 15:26:31 --> Helper loaded: url_helper
INFO - 2019-07-03 15:26:31 --> Helper loaded: url_helper
INFO - 2019-07-03 15:26:31 --> Helper loaded: inflector_helper
INFO - 2019-07-03 15:26:31 --> Helper loaded: inflector_helper
INFO - 2019-07-03 15:26:31 --> Helper loaded: string_helper
INFO - 2019-07-03 15:26:31 --> Helper loaded: string_helper
INFO - 2019-07-03 15:26:31 --> Helper loaded: array_helper
INFO - 2019-07-03 15:26:31 --> Helper loaded: array_helper
INFO - 2019-07-03 15:26:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 15:26:31 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 15:26:31 --> Database Driver Class Initialized
INFO - 2019-07-03 15:26:31 --> Controller Class Initialized
INFO - 2019-07-03 21:26:31 --> Helper loaded: language_helper
INFO - 2019-07-03 21:26:31 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 21:26:31 --> Model Class Initialized
INFO - 2019-07-03 21:26:31 --> Model Class Initialized
INFO - 2019-07-03 21:26:31 --> Model Class Initialized
INFO - 2019-07-03 21:26:31 --> Model Class Initialized
INFO - 2019-07-03 21:26:31 --> Model Class Initialized
INFO - 2019-07-03 21:26:31 --> Final output sent to browser
DEBUG - 2019-07-03 21:26:31 --> Total execution time: 0.4158
INFO - 2019-07-03 15:26:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 15:26:31 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 15:26:31 --> Database Driver Class Initialized
INFO - 2019-07-03 15:26:31 --> Controller Class Initialized
INFO - 2019-07-03 21:26:31 --> Helper loaded: language_helper
INFO - 2019-07-03 21:26:31 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 21:26:31 --> Model Class Initialized
INFO - 2019-07-03 21:26:31 --> Model Class Initialized
INFO - 2019-07-03 21:26:31 --> Model Class Initialized
INFO - 2019-07-03 21:26:31 --> Model Class Initialized
INFO - 2019-07-03 21:26:31 --> Final output sent to browser
DEBUG - 2019-07-03 21:26:31 --> Total execution time: 0.5507
INFO - 2019-07-03 15:26:33 --> Config Class Initialized
INFO - 2019-07-03 15:26:33 --> Hooks Class Initialized
DEBUG - 2019-07-03 15:26:33 --> UTF-8 Support Enabled
INFO - 2019-07-03 15:26:33 --> Utf8 Class Initialized
INFO - 2019-07-03 15:26:33 --> URI Class Initialized
INFO - 2019-07-03 15:26:33 --> Router Class Initialized
INFO - 2019-07-03 15:26:33 --> Output Class Initialized
INFO - 2019-07-03 15:26:33 --> Security Class Initialized
DEBUG - 2019-07-03 15:26:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 15:26:33 --> Input Class Initialized
INFO - 2019-07-03 15:26:33 --> Language Class Initialized
INFO - 2019-07-03 15:26:33 --> Language Class Initialized
INFO - 2019-07-03 15:26:33 --> Config Class Initialized
INFO - 2019-07-03 15:26:33 --> Loader Class Initialized
DEBUG - 2019-07-03 15:26:33 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 15:26:33 --> Helper loaded: url_helper
INFO - 2019-07-03 15:26:33 --> Helper loaded: inflector_helper
INFO - 2019-07-03 15:26:33 --> Helper loaded: string_helper
INFO - 2019-07-03 15:26:33 --> Helper loaded: array_helper
INFO - 2019-07-03 15:26:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 15:26:33 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 15:26:33 --> Database Driver Class Initialized
INFO - 2019-07-03 15:26:33 --> Controller Class Initialized
INFO - 2019-07-03 21:26:33 --> Helper loaded: language_helper
INFO - 2019-07-03 21:26:33 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 21:26:33 --> Model Class Initialized
INFO - 2019-07-03 21:26:33 --> Model Class Initialized
INFO - 2019-07-03 21:26:33 --> Model Class Initialized
INFO - 2019-07-03 21:26:33 --> Model Class Initialized
INFO - 2019-07-03 21:26:33 --> Model Class Initialized
INFO - 2019-07-03 21:26:33 --> Final output sent to browser
DEBUG - 2019-07-03 21:26:33 --> Total execution time: 0.3214
INFO - 2019-07-03 15:26:33 --> Config Class Initialized
INFO - 2019-07-03 15:26:33 --> Hooks Class Initialized
DEBUG - 2019-07-03 15:26:33 --> UTF-8 Support Enabled
INFO - 2019-07-03 15:26:33 --> Utf8 Class Initialized
INFO - 2019-07-03 15:26:33 --> URI Class Initialized
INFO - 2019-07-03 15:26:33 --> Router Class Initialized
INFO - 2019-07-03 15:26:33 --> Output Class Initialized
INFO - 2019-07-03 15:26:33 --> Security Class Initialized
DEBUG - 2019-07-03 15:26:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 15:26:34 --> Input Class Initialized
INFO - 2019-07-03 15:26:34 --> Language Class Initialized
INFO - 2019-07-03 15:26:34 --> Language Class Initialized
INFO - 2019-07-03 15:26:34 --> Config Class Initialized
INFO - 2019-07-03 15:26:34 --> Loader Class Initialized
DEBUG - 2019-07-03 15:26:34 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 15:26:34 --> Helper loaded: url_helper
INFO - 2019-07-03 15:26:34 --> Helper loaded: inflector_helper
INFO - 2019-07-03 15:26:34 --> Helper loaded: string_helper
INFO - 2019-07-03 15:26:34 --> Helper loaded: array_helper
INFO - 2019-07-03 15:26:34 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 15:26:34 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 15:26:34 --> Database Driver Class Initialized
INFO - 2019-07-03 15:26:34 --> Controller Class Initialized
INFO - 2019-07-03 21:26:34 --> Helper loaded: language_helper
INFO - 2019-07-03 21:26:34 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 21:26:34 --> Model Class Initialized
INFO - 2019-07-03 21:26:34 --> Model Class Initialized
INFO - 2019-07-03 21:26:34 --> Model Class Initialized
INFO - 2019-07-03 21:26:34 --> Model Class Initialized
INFO - 2019-07-03 21:26:34 --> Model Class Initialized
INFO - 2019-07-03 21:26:34 --> Final output sent to browser
DEBUG - 2019-07-03 21:26:34 --> Total execution time: 0.3316
INFO - 2019-07-03 15:27:06 --> Config Class Initialized
INFO - 2019-07-03 15:27:06 --> Config Class Initialized
INFO - 2019-07-03 15:27:06 --> Hooks Class Initialized
INFO - 2019-07-03 15:27:06 --> Hooks Class Initialized
DEBUG - 2019-07-03 15:27:06 --> UTF-8 Support Enabled
DEBUG - 2019-07-03 15:27:06 --> UTF-8 Support Enabled
INFO - 2019-07-03 15:27:06 --> Utf8 Class Initialized
INFO - 2019-07-03 15:27:06 --> Utf8 Class Initialized
INFO - 2019-07-03 15:27:06 --> URI Class Initialized
INFO - 2019-07-03 15:27:07 --> URI Class Initialized
INFO - 2019-07-03 15:27:07 --> Router Class Initialized
INFO - 2019-07-03 15:27:07 --> Router Class Initialized
INFO - 2019-07-03 15:27:07 --> Output Class Initialized
INFO - 2019-07-03 15:27:07 --> Output Class Initialized
INFO - 2019-07-03 15:27:07 --> Security Class Initialized
INFO - 2019-07-03 15:27:07 --> Security Class Initialized
DEBUG - 2019-07-03 15:27:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-03 15:27:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 15:27:07 --> Input Class Initialized
INFO - 2019-07-03 15:27:07 --> Input Class Initialized
INFO - 2019-07-03 15:27:07 --> Language Class Initialized
INFO - 2019-07-03 15:27:07 --> Language Class Initialized
INFO - 2019-07-03 15:27:07 --> Language Class Initialized
INFO - 2019-07-03 15:27:07 --> Language Class Initialized
INFO - 2019-07-03 15:27:07 --> Config Class Initialized
INFO - 2019-07-03 15:27:07 --> Config Class Initialized
INFO - 2019-07-03 15:27:07 --> Loader Class Initialized
INFO - 2019-07-03 15:27:07 --> Loader Class Initialized
DEBUG - 2019-07-03 15:27:07 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-03 15:27:07 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 15:27:07 --> Helper loaded: url_helper
INFO - 2019-07-03 15:27:07 --> Helper loaded: url_helper
INFO - 2019-07-03 15:27:07 --> Helper loaded: inflector_helper
INFO - 2019-07-03 15:27:07 --> Helper loaded: inflector_helper
INFO - 2019-07-03 15:27:07 --> Helper loaded: string_helper
INFO - 2019-07-03 15:27:07 --> Helper loaded: string_helper
INFO - 2019-07-03 15:27:07 --> Helper loaded: array_helper
INFO - 2019-07-03 15:27:07 --> Helper loaded: array_helper
INFO - 2019-07-03 15:27:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 15:27:07 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 15:27:07 --> Database Driver Class Initialized
INFO - 2019-07-03 15:27:07 --> Controller Class Initialized
INFO - 2019-07-03 21:27:07 --> Helper loaded: language_helper
INFO - 2019-07-03 21:27:07 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 21:27:07 --> Model Class Initialized
INFO - 2019-07-03 21:27:07 --> Model Class Initialized
INFO - 2019-07-03 21:27:07 --> Model Class Initialized
INFO - 2019-07-03 21:27:07 --> Model Class Initialized
INFO - 2019-07-03 21:27:07 --> Model Class Initialized
INFO - 2019-07-03 21:27:07 --> Final output sent to browser
DEBUG - 2019-07-03 21:27:07 --> Total execution time: 0.4259
INFO - 2019-07-03 15:27:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 15:27:07 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 15:27:07 --> Database Driver Class Initialized
INFO - 2019-07-03 15:27:07 --> Controller Class Initialized
INFO - 2019-07-03 21:27:07 --> Helper loaded: language_helper
INFO - 2019-07-03 21:27:07 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 21:27:07 --> Model Class Initialized
INFO - 2019-07-03 21:27:07 --> Model Class Initialized
INFO - 2019-07-03 21:27:07 --> Model Class Initialized
INFO - 2019-07-03 21:27:07 --> Model Class Initialized
INFO - 2019-07-03 21:27:07 --> Final output sent to browser
DEBUG - 2019-07-03 21:27:07 --> Total execution time: 0.5345
INFO - 2019-07-03 15:27:09 --> Config Class Initialized
INFO - 2019-07-03 15:27:09 --> Hooks Class Initialized
DEBUG - 2019-07-03 15:27:09 --> UTF-8 Support Enabled
INFO - 2019-07-03 15:27:09 --> Utf8 Class Initialized
INFO - 2019-07-03 15:27:09 --> URI Class Initialized
INFO - 2019-07-03 15:27:09 --> Router Class Initialized
INFO - 2019-07-03 15:27:10 --> Output Class Initialized
INFO - 2019-07-03 15:27:10 --> Security Class Initialized
DEBUG - 2019-07-03 15:27:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 15:27:10 --> Input Class Initialized
INFO - 2019-07-03 15:27:10 --> Language Class Initialized
INFO - 2019-07-03 15:27:10 --> Language Class Initialized
INFO - 2019-07-03 15:27:10 --> Config Class Initialized
INFO - 2019-07-03 15:27:10 --> Loader Class Initialized
DEBUG - 2019-07-03 15:27:10 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 15:27:10 --> Helper loaded: url_helper
INFO - 2019-07-03 15:27:10 --> Helper loaded: inflector_helper
INFO - 2019-07-03 15:27:10 --> Helper loaded: string_helper
INFO - 2019-07-03 15:27:10 --> Helper loaded: array_helper
INFO - 2019-07-03 15:27:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 15:27:10 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 15:27:10 --> Database Driver Class Initialized
INFO - 2019-07-03 15:27:10 --> Controller Class Initialized
INFO - 2019-07-03 21:27:10 --> Helper loaded: language_helper
INFO - 2019-07-03 21:27:10 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 21:27:10 --> Model Class Initialized
INFO - 2019-07-03 21:27:10 --> Model Class Initialized
INFO - 2019-07-03 21:27:10 --> Model Class Initialized
INFO - 2019-07-03 21:27:10 --> Model Class Initialized
INFO - 2019-07-03 21:27:10 --> Model Class Initialized
INFO - 2019-07-03 21:27:10 --> Final output sent to browser
DEBUG - 2019-07-03 21:27:10 --> Total execution time: 0.3053
INFO - 2019-07-03 15:27:10 --> Config Class Initialized
INFO - 2019-07-03 15:27:10 --> Hooks Class Initialized
DEBUG - 2019-07-03 15:27:10 --> UTF-8 Support Enabled
INFO - 2019-07-03 15:27:10 --> Utf8 Class Initialized
INFO - 2019-07-03 15:27:10 --> URI Class Initialized
INFO - 2019-07-03 15:27:10 --> Router Class Initialized
INFO - 2019-07-03 15:27:10 --> Output Class Initialized
INFO - 2019-07-03 15:27:10 --> Security Class Initialized
DEBUG - 2019-07-03 15:27:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 15:27:10 --> Input Class Initialized
INFO - 2019-07-03 15:27:10 --> Language Class Initialized
INFO - 2019-07-03 15:27:10 --> Language Class Initialized
INFO - 2019-07-03 15:27:10 --> Config Class Initialized
INFO - 2019-07-03 15:27:10 --> Loader Class Initialized
DEBUG - 2019-07-03 15:27:10 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 15:27:10 --> Helper loaded: url_helper
INFO - 2019-07-03 15:27:10 --> Helper loaded: inflector_helper
INFO - 2019-07-03 15:27:10 --> Helper loaded: string_helper
INFO - 2019-07-03 15:27:10 --> Helper loaded: array_helper
INFO - 2019-07-03 15:27:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 15:27:10 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 15:27:10 --> Database Driver Class Initialized
INFO - 2019-07-03 15:27:10 --> Controller Class Initialized
INFO - 2019-07-03 21:27:10 --> Helper loaded: language_helper
INFO - 2019-07-03 21:27:10 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 21:27:10 --> Model Class Initialized
INFO - 2019-07-03 21:27:10 --> Model Class Initialized
INFO - 2019-07-03 21:27:10 --> Model Class Initialized
INFO - 2019-07-03 21:27:10 --> Model Class Initialized
INFO - 2019-07-03 21:27:10 --> Model Class Initialized
INFO - 2019-07-03 21:27:10 --> Final output sent to browser
DEBUG - 2019-07-03 21:27:10 --> Total execution time: 0.3268
INFO - 2019-07-03 15:27:22 --> Config Class Initialized
INFO - 2019-07-03 15:27:22 --> Hooks Class Initialized
DEBUG - 2019-07-03 15:27:22 --> UTF-8 Support Enabled
INFO - 2019-07-03 15:27:22 --> Utf8 Class Initialized
INFO - 2019-07-03 15:27:22 --> URI Class Initialized
INFO - 2019-07-03 15:27:22 --> Router Class Initialized
INFO - 2019-07-03 15:27:22 --> Output Class Initialized
INFO - 2019-07-03 15:27:22 --> Security Class Initialized
DEBUG - 2019-07-03 15:27:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 15:27:22 --> Input Class Initialized
INFO - 2019-07-03 15:27:22 --> Language Class Initialized
INFO - 2019-07-03 15:27:22 --> Language Class Initialized
INFO - 2019-07-03 15:27:22 --> Config Class Initialized
INFO - 2019-07-03 15:27:22 --> Loader Class Initialized
DEBUG - 2019-07-03 15:27:22 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 15:27:22 --> Helper loaded: url_helper
INFO - 2019-07-03 15:27:22 --> Helper loaded: inflector_helper
INFO - 2019-07-03 15:27:22 --> Helper loaded: string_helper
INFO - 2019-07-03 15:27:22 --> Helper loaded: array_helper
INFO - 2019-07-03 15:27:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 15:27:22 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 15:27:22 --> Database Driver Class Initialized
INFO - 2019-07-03 15:27:22 --> Controller Class Initialized
INFO - 2019-07-03 21:27:22 --> Helper loaded: language_helper
INFO - 2019-07-03 21:27:22 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 21:27:22 --> Model Class Initialized
INFO - 2019-07-03 21:27:22 --> Model Class Initialized
INFO - 2019-07-03 21:27:22 --> Model Class Initialized
INFO - 2019-07-03 21:27:22 --> Model Class Initialized
INFO - 2019-07-03 21:27:22 --> Model Class Initialized
INFO - 2019-07-03 21:27:22 --> Final output sent to browser
DEBUG - 2019-07-03 21:27:22 --> Total execution time: 0.3438
INFO - 2019-07-03 15:27:22 --> Config Class Initialized
INFO - 2019-07-03 15:27:22 --> Hooks Class Initialized
DEBUG - 2019-07-03 15:27:22 --> UTF-8 Support Enabled
INFO - 2019-07-03 15:27:22 --> Utf8 Class Initialized
INFO - 2019-07-03 15:27:22 --> URI Class Initialized
INFO - 2019-07-03 15:27:22 --> Router Class Initialized
INFO - 2019-07-03 15:27:22 --> Output Class Initialized
INFO - 2019-07-03 15:27:22 --> Security Class Initialized
DEBUG - 2019-07-03 15:27:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 15:27:22 --> Input Class Initialized
INFO - 2019-07-03 15:27:22 --> Language Class Initialized
INFO - 2019-07-03 15:27:22 --> Language Class Initialized
INFO - 2019-07-03 15:27:22 --> Config Class Initialized
INFO - 2019-07-03 15:27:22 --> Loader Class Initialized
DEBUG - 2019-07-03 15:27:22 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 15:27:22 --> Helper loaded: url_helper
INFO - 2019-07-03 15:27:22 --> Helper loaded: inflector_helper
INFO - 2019-07-03 15:27:22 --> Helper loaded: string_helper
INFO - 2019-07-03 15:27:22 --> Helper loaded: array_helper
INFO - 2019-07-03 15:27:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 15:27:22 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 15:27:22 --> Database Driver Class Initialized
INFO - 2019-07-03 15:27:22 --> Controller Class Initialized
INFO - 2019-07-03 21:27:22 --> Helper loaded: language_helper
INFO - 2019-07-03 21:27:22 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 21:27:22 --> Model Class Initialized
INFO - 2019-07-03 21:27:22 --> Model Class Initialized
INFO - 2019-07-03 21:27:22 --> Model Class Initialized
INFO - 2019-07-03 21:27:22 --> Model Class Initialized
INFO - 2019-07-03 21:27:22 --> Model Class Initialized
INFO - 2019-07-03 21:27:22 --> Final output sent to browser
DEBUG - 2019-07-03 21:27:22 --> Total execution time: 0.3144
INFO - 2019-07-03 15:27:23 --> Config Class Initialized
INFO - 2019-07-03 15:27:23 --> Hooks Class Initialized
DEBUG - 2019-07-03 15:27:23 --> UTF-8 Support Enabled
INFO - 2019-07-03 15:27:23 --> Utf8 Class Initialized
INFO - 2019-07-03 15:27:23 --> URI Class Initialized
INFO - 2019-07-03 15:27:23 --> Router Class Initialized
INFO - 2019-07-03 15:27:23 --> Output Class Initialized
INFO - 2019-07-03 15:27:23 --> Security Class Initialized
DEBUG - 2019-07-03 15:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 15:27:23 --> Input Class Initialized
INFO - 2019-07-03 15:27:23 --> Language Class Initialized
INFO - 2019-07-03 15:27:23 --> Language Class Initialized
INFO - 2019-07-03 15:27:23 --> Config Class Initialized
INFO - 2019-07-03 15:27:23 --> Loader Class Initialized
DEBUG - 2019-07-03 15:27:23 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 15:27:23 --> Helper loaded: url_helper
INFO - 2019-07-03 15:27:23 --> Helper loaded: inflector_helper
INFO - 2019-07-03 15:27:23 --> Helper loaded: string_helper
INFO - 2019-07-03 15:27:23 --> Helper loaded: array_helper
INFO - 2019-07-03 15:27:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 15:27:23 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 15:27:23 --> Database Driver Class Initialized
INFO - 2019-07-03 15:27:23 --> Controller Class Initialized
INFO - 2019-07-03 21:27:23 --> Helper loaded: language_helper
INFO - 2019-07-03 21:27:23 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 21:27:23 --> Model Class Initialized
INFO - 2019-07-03 21:27:23 --> Model Class Initialized
INFO - 2019-07-03 21:27:23 --> Model Class Initialized
INFO - 2019-07-03 21:27:23 --> Model Class Initialized
INFO - 2019-07-03 21:27:23 --> Model Class Initialized
INFO - 2019-07-03 21:27:23 --> Final output sent to browser
DEBUG - 2019-07-03 21:27:23 --> Total execution time: 0.3269
INFO - 2019-07-03 15:27:23 --> Config Class Initialized
INFO - 2019-07-03 15:27:23 --> Hooks Class Initialized
DEBUG - 2019-07-03 15:27:23 --> UTF-8 Support Enabled
INFO - 2019-07-03 15:27:23 --> Utf8 Class Initialized
INFO - 2019-07-03 15:27:23 --> URI Class Initialized
INFO - 2019-07-03 15:27:23 --> Router Class Initialized
INFO - 2019-07-03 15:27:23 --> Output Class Initialized
INFO - 2019-07-03 15:27:23 --> Security Class Initialized
DEBUG - 2019-07-03 15:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 15:27:23 --> Input Class Initialized
INFO - 2019-07-03 15:27:23 --> Language Class Initialized
INFO - 2019-07-03 15:27:23 --> Language Class Initialized
INFO - 2019-07-03 15:27:23 --> Config Class Initialized
INFO - 2019-07-03 15:27:23 --> Loader Class Initialized
DEBUG - 2019-07-03 15:27:23 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 15:27:23 --> Helper loaded: url_helper
INFO - 2019-07-03 15:27:23 --> Helper loaded: inflector_helper
INFO - 2019-07-03 15:27:23 --> Helper loaded: string_helper
INFO - 2019-07-03 15:27:23 --> Helper loaded: array_helper
INFO - 2019-07-03 15:27:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 15:27:23 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 15:27:23 --> Database Driver Class Initialized
INFO - 2019-07-03 15:27:23 --> Controller Class Initialized
INFO - 2019-07-03 21:27:23 --> Helper loaded: language_helper
INFO - 2019-07-03 21:27:23 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 21:27:23 --> Model Class Initialized
INFO - 2019-07-03 21:27:23 --> Model Class Initialized
INFO - 2019-07-03 21:27:24 --> Model Class Initialized
INFO - 2019-07-03 21:27:24 --> Model Class Initialized
INFO - 2019-07-03 21:27:24 --> Model Class Initialized
INFO - 2019-07-03 21:27:24 --> Final output sent to browser
DEBUG - 2019-07-03 21:27:24 --> Total execution time: 0.3524
INFO - 2019-07-03 15:48:25 --> Config Class Initialized
INFO - 2019-07-03 15:48:25 --> Config Class Initialized
INFO - 2019-07-03 15:48:25 --> Hooks Class Initialized
INFO - 2019-07-03 15:48:25 --> Hooks Class Initialized
DEBUG - 2019-07-03 15:48:25 --> UTF-8 Support Enabled
DEBUG - 2019-07-03 15:48:25 --> UTF-8 Support Enabled
INFO - 2019-07-03 15:48:25 --> Utf8 Class Initialized
INFO - 2019-07-03 15:48:25 --> Utf8 Class Initialized
INFO - 2019-07-03 15:48:25 --> URI Class Initialized
INFO - 2019-07-03 15:48:25 --> URI Class Initialized
INFO - 2019-07-03 15:48:25 --> Router Class Initialized
INFO - 2019-07-03 15:48:25 --> Router Class Initialized
INFO - 2019-07-03 15:48:25 --> Output Class Initialized
INFO - 2019-07-03 15:48:25 --> Output Class Initialized
INFO - 2019-07-03 15:48:25 --> Security Class Initialized
INFO - 2019-07-03 15:48:25 --> Security Class Initialized
DEBUG - 2019-07-03 15:48:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-03 15:48:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 15:48:25 --> Input Class Initialized
INFO - 2019-07-03 15:48:25 --> Input Class Initialized
INFO - 2019-07-03 15:48:25 --> Language Class Initialized
INFO - 2019-07-03 15:48:25 --> Language Class Initialized
INFO - 2019-07-03 15:48:25 --> Language Class Initialized
INFO - 2019-07-03 15:48:25 --> Language Class Initialized
INFO - 2019-07-03 15:48:25 --> Config Class Initialized
INFO - 2019-07-03 15:48:25 --> Config Class Initialized
INFO - 2019-07-03 15:48:25 --> Loader Class Initialized
INFO - 2019-07-03 15:48:25 --> Loader Class Initialized
DEBUG - 2019-07-03 15:48:25 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-03 15:48:25 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 15:48:25 --> Helper loaded: url_helper
INFO - 2019-07-03 15:48:25 --> Helper loaded: url_helper
INFO - 2019-07-03 15:48:25 --> Helper loaded: inflector_helper
INFO - 2019-07-03 15:48:25 --> Helper loaded: inflector_helper
INFO - 2019-07-03 15:48:25 --> Helper loaded: string_helper
INFO - 2019-07-03 15:48:25 --> Helper loaded: string_helper
INFO - 2019-07-03 15:48:25 --> Helper loaded: array_helper
INFO - 2019-07-03 15:48:25 --> Helper loaded: array_helper
INFO - 2019-07-03 15:48:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 15:48:25 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 15:48:25 --> Database Driver Class Initialized
INFO - 2019-07-03 15:48:25 --> Controller Class Initialized
INFO - 2019-07-03 21:48:25 --> Helper loaded: language_helper
INFO - 2019-07-03 21:48:25 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 21:48:25 --> Model Class Initialized
INFO - 2019-07-03 21:48:25 --> Model Class Initialized
INFO - 2019-07-03 21:48:25 --> Model Class Initialized
INFO - 2019-07-03 21:48:25 --> Model Class Initialized
INFO - 2019-07-03 21:48:25 --> Final output sent to browser
DEBUG - 2019-07-03 21:48:25 --> Total execution time: 0.4437
INFO - 2019-07-03 15:48:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 15:48:25 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 15:48:25 --> Database Driver Class Initialized
INFO - 2019-07-03 15:48:25 --> Controller Class Initialized
INFO - 2019-07-03 21:48:25 --> Helper loaded: language_helper
INFO - 2019-07-03 21:48:25 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 21:48:25 --> Model Class Initialized
INFO - 2019-07-03 21:48:25 --> Model Class Initialized
INFO - 2019-07-03 21:48:25 --> Model Class Initialized
INFO - 2019-07-03 21:48:25 --> Model Class Initialized
INFO - 2019-07-03 21:48:25 --> Model Class Initialized
INFO - 2019-07-03 21:48:25 --> Final output sent to browser
DEBUG - 2019-07-03 21:48:25 --> Total execution time: 0.5747
INFO - 2019-07-03 15:49:53 --> Config Class Initialized
INFO - 2019-07-03 15:49:53 --> Config Class Initialized
INFO - 2019-07-03 15:49:53 --> Hooks Class Initialized
INFO - 2019-07-03 15:49:53 --> Hooks Class Initialized
DEBUG - 2019-07-03 15:49:53 --> UTF-8 Support Enabled
DEBUG - 2019-07-03 15:49:53 --> UTF-8 Support Enabled
INFO - 2019-07-03 15:49:53 --> Utf8 Class Initialized
INFO - 2019-07-03 15:49:53 --> Utf8 Class Initialized
INFO - 2019-07-03 15:49:53 --> URI Class Initialized
INFO - 2019-07-03 15:49:53 --> URI Class Initialized
INFO - 2019-07-03 15:49:53 --> Router Class Initialized
INFO - 2019-07-03 15:49:53 --> Router Class Initialized
INFO - 2019-07-03 15:49:53 --> Output Class Initialized
INFO - 2019-07-03 15:49:53 --> Output Class Initialized
INFO - 2019-07-03 15:49:54 --> Security Class Initialized
INFO - 2019-07-03 15:49:54 --> Security Class Initialized
DEBUG - 2019-07-03 15:49:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-03 15:49:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 15:49:54 --> Input Class Initialized
INFO - 2019-07-03 15:49:54 --> Input Class Initialized
INFO - 2019-07-03 15:49:54 --> Language Class Initialized
INFO - 2019-07-03 15:49:54 --> Language Class Initialized
INFO - 2019-07-03 15:49:54 --> Language Class Initialized
INFO - 2019-07-03 15:49:54 --> Language Class Initialized
INFO - 2019-07-03 15:49:54 --> Config Class Initialized
INFO - 2019-07-03 15:49:54 --> Config Class Initialized
INFO - 2019-07-03 15:49:54 --> Loader Class Initialized
INFO - 2019-07-03 15:49:54 --> Loader Class Initialized
DEBUG - 2019-07-03 15:49:54 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-03 15:49:54 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 15:49:54 --> Helper loaded: url_helper
INFO - 2019-07-03 15:49:54 --> Helper loaded: url_helper
INFO - 2019-07-03 15:49:54 --> Helper loaded: inflector_helper
INFO - 2019-07-03 15:49:54 --> Helper loaded: inflector_helper
INFO - 2019-07-03 15:49:54 --> Helper loaded: string_helper
INFO - 2019-07-03 15:49:54 --> Helper loaded: string_helper
INFO - 2019-07-03 15:49:54 --> Helper loaded: array_helper
INFO - 2019-07-03 15:49:54 --> Helper loaded: array_helper
INFO - 2019-07-03 15:49:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 15:49:54 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 15:49:54 --> Database Driver Class Initialized
INFO - 2019-07-03 15:49:54 --> Controller Class Initialized
INFO - 2019-07-03 21:49:54 --> Helper loaded: language_helper
INFO - 2019-07-03 21:49:54 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 21:49:54 --> Model Class Initialized
INFO - 2019-07-03 21:49:54 --> Model Class Initialized
INFO - 2019-07-03 21:49:54 --> Model Class Initialized
INFO - 2019-07-03 21:49:54 --> Model Class Initialized
INFO - 2019-07-03 21:49:54 --> Model Class Initialized
INFO - 2019-07-03 21:49:54 --> Final output sent to browser
DEBUG - 2019-07-03 21:49:54 --> Total execution time: 0.4429
INFO - 2019-07-03 15:49:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 15:49:54 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 15:49:54 --> Database Driver Class Initialized
INFO - 2019-07-03 15:49:54 --> Controller Class Initialized
INFO - 2019-07-03 21:49:54 --> Helper loaded: language_helper
INFO - 2019-07-03 21:49:54 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 21:49:54 --> Model Class Initialized
INFO - 2019-07-03 21:49:54 --> Model Class Initialized
INFO - 2019-07-03 21:49:54 --> Model Class Initialized
INFO - 2019-07-03 21:49:54 --> Model Class Initialized
INFO - 2019-07-03 21:49:54 --> Final output sent to browser
DEBUG - 2019-07-03 21:49:54 --> Total execution time: 0.5588
INFO - 2019-07-03 15:49:57 --> Config Class Initialized
INFO - 2019-07-03 15:49:57 --> Hooks Class Initialized
DEBUG - 2019-07-03 15:49:57 --> UTF-8 Support Enabled
INFO - 2019-07-03 15:49:57 --> Utf8 Class Initialized
INFO - 2019-07-03 15:49:57 --> URI Class Initialized
INFO - 2019-07-03 15:49:57 --> Router Class Initialized
INFO - 2019-07-03 15:49:57 --> Output Class Initialized
INFO - 2019-07-03 15:49:57 --> Security Class Initialized
DEBUG - 2019-07-03 15:49:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 15:49:57 --> Input Class Initialized
INFO - 2019-07-03 15:49:57 --> Language Class Initialized
INFO - 2019-07-03 15:49:57 --> Language Class Initialized
INFO - 2019-07-03 15:49:57 --> Config Class Initialized
INFO - 2019-07-03 15:49:57 --> Loader Class Initialized
DEBUG - 2019-07-03 15:49:57 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 15:49:57 --> Helper loaded: url_helper
INFO - 2019-07-03 15:49:57 --> Helper loaded: inflector_helper
INFO - 2019-07-03 15:49:57 --> Helper loaded: string_helper
INFO - 2019-07-03 15:49:57 --> Helper loaded: array_helper
INFO - 2019-07-03 15:49:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 15:49:57 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 15:49:57 --> Database Driver Class Initialized
INFO - 2019-07-03 15:49:57 --> Controller Class Initialized
INFO - 2019-07-03 21:49:57 --> Helper loaded: language_helper
INFO - 2019-07-03 21:49:57 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 21:49:57 --> Model Class Initialized
INFO - 2019-07-03 21:49:57 --> Model Class Initialized
INFO - 2019-07-03 21:49:57 --> Model Class Initialized
INFO - 2019-07-03 21:49:57 --> Model Class Initialized
INFO - 2019-07-03 21:49:57 --> Model Class Initialized
INFO - 2019-07-03 21:49:57 --> Final output sent to browser
DEBUG - 2019-07-03 21:49:57 --> Total execution time: 0.3504
INFO - 2019-07-03 15:49:58 --> Config Class Initialized
INFO - 2019-07-03 15:49:58 --> Hooks Class Initialized
DEBUG - 2019-07-03 15:49:58 --> UTF-8 Support Enabled
INFO - 2019-07-03 15:49:58 --> Utf8 Class Initialized
INFO - 2019-07-03 15:49:58 --> URI Class Initialized
INFO - 2019-07-03 15:49:58 --> Router Class Initialized
INFO - 2019-07-03 15:49:58 --> Output Class Initialized
INFO - 2019-07-03 15:49:58 --> Security Class Initialized
DEBUG - 2019-07-03 15:49:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 15:49:58 --> Input Class Initialized
INFO - 2019-07-03 15:49:58 --> Language Class Initialized
INFO - 2019-07-03 15:49:58 --> Language Class Initialized
INFO - 2019-07-03 15:49:58 --> Config Class Initialized
INFO - 2019-07-03 15:49:58 --> Loader Class Initialized
DEBUG - 2019-07-03 15:49:58 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 15:49:58 --> Helper loaded: url_helper
INFO - 2019-07-03 15:49:58 --> Helper loaded: inflector_helper
INFO - 2019-07-03 15:49:58 --> Helper loaded: string_helper
INFO - 2019-07-03 15:49:58 --> Helper loaded: array_helper
INFO - 2019-07-03 15:49:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 15:49:58 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 15:49:58 --> Database Driver Class Initialized
INFO - 2019-07-03 15:49:58 --> Controller Class Initialized
INFO - 2019-07-03 21:49:58 --> Helper loaded: language_helper
INFO - 2019-07-03 21:49:58 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 21:49:58 --> Model Class Initialized
INFO - 2019-07-03 21:49:58 --> Model Class Initialized
INFO - 2019-07-03 21:49:58 --> Model Class Initialized
INFO - 2019-07-03 21:49:58 --> Model Class Initialized
INFO - 2019-07-03 21:49:58 --> Model Class Initialized
INFO - 2019-07-03 21:49:58 --> Final output sent to browser
DEBUG - 2019-07-03 21:49:58 --> Total execution time: 0.3318
INFO - 2019-07-03 15:57:35 --> Config Class Initialized
INFO - 2019-07-03 15:57:35 --> Hooks Class Initialized
INFO - 2019-07-03 15:57:35 --> Config Class Initialized
INFO - 2019-07-03 15:57:35 --> Hooks Class Initialized
DEBUG - 2019-07-03 15:57:35 --> UTF-8 Support Enabled
DEBUG - 2019-07-03 15:57:35 --> UTF-8 Support Enabled
INFO - 2019-07-03 15:57:35 --> Utf8 Class Initialized
INFO - 2019-07-03 15:57:35 --> Utf8 Class Initialized
INFO - 2019-07-03 15:57:35 --> URI Class Initialized
INFO - 2019-07-03 15:57:35 --> URI Class Initialized
INFO - 2019-07-03 15:57:35 --> Router Class Initialized
INFO - 2019-07-03 15:57:35 --> Router Class Initialized
INFO - 2019-07-03 15:57:35 --> Output Class Initialized
INFO - 2019-07-03 15:57:35 --> Output Class Initialized
INFO - 2019-07-03 15:57:36 --> Security Class Initialized
INFO - 2019-07-03 15:57:36 --> Security Class Initialized
DEBUG - 2019-07-03 15:57:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-03 15:57:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 15:57:36 --> Input Class Initialized
INFO - 2019-07-03 15:57:36 --> Input Class Initialized
INFO - 2019-07-03 15:57:36 --> Language Class Initialized
INFO - 2019-07-03 15:57:36 --> Language Class Initialized
INFO - 2019-07-03 15:57:36 --> Language Class Initialized
INFO - 2019-07-03 15:57:36 --> Language Class Initialized
INFO - 2019-07-03 15:57:36 --> Config Class Initialized
INFO - 2019-07-03 15:57:36 --> Config Class Initialized
INFO - 2019-07-03 15:57:36 --> Loader Class Initialized
INFO - 2019-07-03 15:57:36 --> Loader Class Initialized
DEBUG - 2019-07-03 15:57:36 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-03 15:57:36 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 15:57:36 --> Helper loaded: url_helper
INFO - 2019-07-03 15:57:36 --> Helper loaded: url_helper
INFO - 2019-07-03 15:57:36 --> Helper loaded: inflector_helper
INFO - 2019-07-03 15:57:36 --> Helper loaded: inflector_helper
INFO - 2019-07-03 15:57:36 --> Helper loaded: string_helper
INFO - 2019-07-03 15:57:36 --> Helper loaded: string_helper
INFO - 2019-07-03 15:57:36 --> Helper loaded: array_helper
INFO - 2019-07-03 15:57:36 --> Helper loaded: array_helper
INFO - 2019-07-03 15:57:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 15:57:36 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 15:57:36 --> Database Driver Class Initialized
INFO - 2019-07-03 15:57:36 --> Controller Class Initialized
INFO - 2019-07-03 21:57:36 --> Helper loaded: language_helper
INFO - 2019-07-03 21:57:36 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 21:57:36 --> Model Class Initialized
INFO - 2019-07-03 21:57:36 --> Model Class Initialized
INFO - 2019-07-03 21:57:36 --> Model Class Initialized
INFO - 2019-07-03 21:57:36 --> Model Class Initialized
INFO - 2019-07-03 21:57:36 --> Model Class Initialized
INFO - 2019-07-03 21:57:36 --> Final output sent to browser
DEBUG - 2019-07-03 21:57:36 --> Total execution time: 0.4742
INFO - 2019-07-03 15:57:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 15:57:36 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 15:57:36 --> Database Driver Class Initialized
INFO - 2019-07-03 15:57:36 --> Controller Class Initialized
INFO - 2019-07-03 21:57:36 --> Helper loaded: language_helper
INFO - 2019-07-03 21:57:36 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 21:57:36 --> Model Class Initialized
INFO - 2019-07-03 21:57:36 --> Model Class Initialized
INFO - 2019-07-03 21:57:36 --> Model Class Initialized
INFO - 2019-07-03 21:57:36 --> Model Class Initialized
INFO - 2019-07-03 21:57:36 --> Final output sent to browser
DEBUG - 2019-07-03 21:57:36 --> Total execution time: 0.5862
INFO - 2019-07-03 15:57:39 --> Config Class Initialized
INFO - 2019-07-03 15:57:39 --> Config Class Initialized
INFO - 2019-07-03 15:57:39 --> Hooks Class Initialized
INFO - 2019-07-03 15:57:39 --> Hooks Class Initialized
DEBUG - 2019-07-03 15:57:39 --> UTF-8 Support Enabled
DEBUG - 2019-07-03 15:57:39 --> UTF-8 Support Enabled
INFO - 2019-07-03 15:57:39 --> Utf8 Class Initialized
INFO - 2019-07-03 15:57:39 --> Utf8 Class Initialized
INFO - 2019-07-03 15:57:39 --> URI Class Initialized
INFO - 2019-07-03 15:57:39 --> URI Class Initialized
INFO - 2019-07-03 15:57:39 --> Router Class Initialized
INFO - 2019-07-03 15:57:39 --> Router Class Initialized
INFO - 2019-07-03 15:57:39 --> Output Class Initialized
INFO - 2019-07-03 15:57:39 --> Output Class Initialized
INFO - 2019-07-03 15:57:39 --> Security Class Initialized
INFO - 2019-07-03 15:57:39 --> Security Class Initialized
DEBUG - 2019-07-03 15:57:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-03 15:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 15:57:39 --> Input Class Initialized
INFO - 2019-07-03 15:57:39 --> Input Class Initialized
INFO - 2019-07-03 15:57:39 --> Language Class Initialized
INFO - 2019-07-03 15:57:39 --> Language Class Initialized
INFO - 2019-07-03 15:57:39 --> Language Class Initialized
INFO - 2019-07-03 15:57:39 --> Language Class Initialized
INFO - 2019-07-03 15:57:39 --> Config Class Initialized
INFO - 2019-07-03 15:57:39 --> Loader Class Initialized
INFO - 2019-07-03 15:57:39 --> Config Class Initialized
INFO - 2019-07-03 15:57:39 --> Loader Class Initialized
DEBUG - 2019-07-03 15:57:39 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-03 15:57:39 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 15:57:39 --> Helper loaded: url_helper
INFO - 2019-07-03 15:57:39 --> Helper loaded: url_helper
INFO - 2019-07-03 15:57:39 --> Helper loaded: inflector_helper
INFO - 2019-07-03 15:57:39 --> Helper loaded: inflector_helper
INFO - 2019-07-03 15:57:39 --> Helper loaded: string_helper
INFO - 2019-07-03 15:57:39 --> Helper loaded: string_helper
INFO - 2019-07-03 15:57:39 --> Helper loaded: array_helper
INFO - 2019-07-03 15:57:39 --> Helper loaded: array_helper
INFO - 2019-07-03 15:57:39 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 15:57:39 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 15:57:39 --> Database Driver Class Initialized
INFO - 2019-07-03 15:57:39 --> Controller Class Initialized
INFO - 2019-07-03 21:57:39 --> Helper loaded: language_helper
INFO - 2019-07-03 21:57:39 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 21:57:39 --> Model Class Initialized
INFO - 2019-07-03 21:57:39 --> Model Class Initialized
INFO - 2019-07-03 21:57:39 --> Model Class Initialized
INFO - 2019-07-03 21:57:39 --> Model Class Initialized
INFO - 2019-07-03 21:57:39 --> Model Class Initialized
INFO - 2019-07-03 21:57:39 --> Final output sent to browser
DEBUG - 2019-07-03 21:57:39 --> Total execution time: 0.4483
INFO - 2019-07-03 15:57:39 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 15:57:39 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 15:57:39 --> Database Driver Class Initialized
INFO - 2019-07-03 15:57:39 --> Controller Class Initialized
INFO - 2019-07-03 21:57:39 --> Helper loaded: language_helper
INFO - 2019-07-03 21:57:39 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 21:57:39 --> Model Class Initialized
INFO - 2019-07-03 21:57:39 --> Model Class Initialized
INFO - 2019-07-03 21:57:39 --> Model Class Initialized
INFO - 2019-07-03 21:57:39 --> Model Class Initialized
INFO - 2019-07-03 21:57:39 --> Final output sent to browser
DEBUG - 2019-07-03 21:57:39 --> Total execution time: 0.5802
INFO - 2019-07-03 16:00:02 --> Config Class Initialized
INFO - 2019-07-03 16:00:02 --> Hooks Class Initialized
INFO - 2019-07-03 16:00:02 --> Config Class Initialized
DEBUG - 2019-07-03 16:00:02 --> UTF-8 Support Enabled
INFO - 2019-07-03 16:00:02 --> Hooks Class Initialized
INFO - 2019-07-03 16:00:02 --> Utf8 Class Initialized
DEBUG - 2019-07-03 16:00:02 --> UTF-8 Support Enabled
INFO - 2019-07-03 16:00:02 --> URI Class Initialized
INFO - 2019-07-03 16:00:02 --> Utf8 Class Initialized
INFO - 2019-07-03 16:00:02 --> URI Class Initialized
INFO - 2019-07-03 16:00:02 --> Router Class Initialized
INFO - 2019-07-03 16:00:02 --> Router Class Initialized
INFO - 2019-07-03 16:00:02 --> Output Class Initialized
INFO - 2019-07-03 16:00:02 --> Output Class Initialized
INFO - 2019-07-03 16:00:02 --> Security Class Initialized
INFO - 2019-07-03 16:00:02 --> Security Class Initialized
DEBUG - 2019-07-03 16:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-03 16:00:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 16:00:02 --> Input Class Initialized
INFO - 2019-07-03 16:00:02 --> Input Class Initialized
INFO - 2019-07-03 16:00:02 --> Language Class Initialized
INFO - 2019-07-03 16:00:02 --> Language Class Initialized
INFO - 2019-07-03 16:00:02 --> Language Class Initialized
INFO - 2019-07-03 16:00:02 --> Language Class Initialized
INFO - 2019-07-03 16:00:02 --> Config Class Initialized
INFO - 2019-07-03 16:00:02 --> Loader Class Initialized
INFO - 2019-07-03 16:00:02 --> Config Class Initialized
INFO - 2019-07-03 16:00:02 --> Loader Class Initialized
DEBUG - 2019-07-03 16:00:02 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-03 16:00:02 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 16:00:02 --> Helper loaded: url_helper
INFO - 2019-07-03 16:00:02 --> Helper loaded: url_helper
INFO - 2019-07-03 16:00:02 --> Helper loaded: inflector_helper
INFO - 2019-07-03 16:00:02 --> Helper loaded: inflector_helper
INFO - 2019-07-03 16:00:02 --> Helper loaded: string_helper
INFO - 2019-07-03 16:00:02 --> Helper loaded: string_helper
INFO - 2019-07-03 16:00:02 --> Helper loaded: array_helper
INFO - 2019-07-03 16:00:02 --> Helper loaded: array_helper
INFO - 2019-07-03 16:00:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 16:00:02 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 16:00:02 --> Database Driver Class Initialized
INFO - 2019-07-03 16:00:02 --> Controller Class Initialized
INFO - 2019-07-03 22:00:02 --> Helper loaded: language_helper
INFO - 2019-07-03 22:00:02 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 22:00:02 --> Model Class Initialized
INFO - 2019-07-03 22:00:02 --> Model Class Initialized
INFO - 2019-07-03 22:00:02 --> Model Class Initialized
INFO - 2019-07-03 22:00:02 --> Model Class Initialized
INFO - 2019-07-03 22:00:02 --> Model Class Initialized
INFO - 2019-07-03 22:00:02 --> Final output sent to browser
DEBUG - 2019-07-03 22:00:02 --> Total execution time: 0.4341
INFO - 2019-07-03 16:00:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 16:00:02 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 16:00:02 --> Database Driver Class Initialized
INFO - 2019-07-03 16:00:02 --> Controller Class Initialized
INFO - 2019-07-03 22:00:02 --> Helper loaded: language_helper
INFO - 2019-07-03 22:00:02 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 22:00:02 --> Model Class Initialized
INFO - 2019-07-03 22:00:02 --> Model Class Initialized
INFO - 2019-07-03 22:00:02 --> Model Class Initialized
INFO - 2019-07-03 22:00:02 --> Model Class Initialized
INFO - 2019-07-03 22:00:02 --> Final output sent to browser
DEBUG - 2019-07-03 22:00:02 --> Total execution time: 0.5524
INFO - 2019-07-03 16:01:43 --> Config Class Initialized
INFO - 2019-07-03 16:01:43 --> Config Class Initialized
INFO - 2019-07-03 16:01:43 --> Hooks Class Initialized
INFO - 2019-07-03 16:01:43 --> Hooks Class Initialized
DEBUG - 2019-07-03 16:01:43 --> UTF-8 Support Enabled
DEBUG - 2019-07-03 16:01:43 --> UTF-8 Support Enabled
INFO - 2019-07-03 16:01:43 --> Utf8 Class Initialized
INFO - 2019-07-03 16:01:43 --> Utf8 Class Initialized
INFO - 2019-07-03 16:01:43 --> URI Class Initialized
INFO - 2019-07-03 16:01:43 --> URI Class Initialized
INFO - 2019-07-03 16:01:43 --> Router Class Initialized
INFO - 2019-07-03 16:01:43 --> Router Class Initialized
INFO - 2019-07-03 16:01:43 --> Output Class Initialized
INFO - 2019-07-03 16:01:43 --> Output Class Initialized
INFO - 2019-07-03 16:01:43 --> Security Class Initialized
INFO - 2019-07-03 16:01:43 --> Security Class Initialized
DEBUG - 2019-07-03 16:01:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-03 16:01:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 16:01:43 --> Input Class Initialized
INFO - 2019-07-03 16:01:43 --> Input Class Initialized
INFO - 2019-07-03 16:01:43 --> Language Class Initialized
INFO - 2019-07-03 16:01:43 --> Language Class Initialized
INFO - 2019-07-03 16:01:43 --> Language Class Initialized
INFO - 2019-07-03 16:01:43 --> Config Class Initialized
INFO - 2019-07-03 16:01:43 --> Language Class Initialized
INFO - 2019-07-03 16:01:43 --> Config Class Initialized
INFO - 2019-07-03 16:01:43 --> Loader Class Initialized
INFO - 2019-07-03 16:01:43 --> Loader Class Initialized
DEBUG - 2019-07-03 16:01:43 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-03 16:01:43 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 16:01:43 --> Helper loaded: url_helper
INFO - 2019-07-03 16:01:43 --> Helper loaded: url_helper
INFO - 2019-07-03 16:01:43 --> Helper loaded: inflector_helper
INFO - 2019-07-03 16:01:43 --> Helper loaded: inflector_helper
INFO - 2019-07-03 16:01:43 --> Helper loaded: string_helper
INFO - 2019-07-03 16:01:43 --> Helper loaded: string_helper
INFO - 2019-07-03 16:01:43 --> Helper loaded: array_helper
INFO - 2019-07-03 16:01:43 --> Helper loaded: array_helper
INFO - 2019-07-03 16:01:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 16:01:43 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 16:01:43 --> Database Driver Class Initialized
INFO - 2019-07-03 16:01:43 --> Controller Class Initialized
INFO - 2019-07-03 22:01:43 --> Helper loaded: language_helper
INFO - 2019-07-03 22:01:43 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 22:01:43 --> Model Class Initialized
INFO - 2019-07-03 22:01:43 --> Model Class Initialized
INFO - 2019-07-03 22:01:43 --> Model Class Initialized
INFO - 2019-07-03 22:01:43 --> Model Class Initialized
INFO - 2019-07-03 22:01:43 --> Final output sent to browser
DEBUG - 2019-07-03 22:01:43 --> Total execution time: 0.4405
INFO - 2019-07-03 16:01:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 16:01:43 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 16:01:43 --> Database Driver Class Initialized
INFO - 2019-07-03 16:01:43 --> Controller Class Initialized
INFO - 2019-07-03 22:01:43 --> Helper loaded: language_helper
INFO - 2019-07-03 22:01:43 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 22:01:43 --> Model Class Initialized
INFO - 2019-07-03 22:01:43 --> Model Class Initialized
INFO - 2019-07-03 22:01:43 --> Model Class Initialized
INFO - 2019-07-03 22:01:43 --> Model Class Initialized
INFO - 2019-07-03 22:01:43 --> Model Class Initialized
INFO - 2019-07-03 22:01:43 --> Final output sent to browser
DEBUG - 2019-07-03 22:01:43 --> Total execution time: 0.5877
INFO - 2019-07-03 16:01:52 --> Config Class Initialized
INFO - 2019-07-03 16:01:52 --> Hooks Class Initialized
DEBUG - 2019-07-03 16:01:52 --> UTF-8 Support Enabled
INFO - 2019-07-03 16:01:52 --> Utf8 Class Initialized
INFO - 2019-07-03 16:01:52 --> URI Class Initialized
INFO - 2019-07-03 16:01:52 --> Router Class Initialized
INFO - 2019-07-03 16:01:52 --> Output Class Initialized
INFO - 2019-07-03 16:01:52 --> Security Class Initialized
DEBUG - 2019-07-03 16:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 16:01:52 --> Input Class Initialized
INFO - 2019-07-03 16:01:52 --> Language Class Initialized
INFO - 2019-07-03 16:01:52 --> Language Class Initialized
INFO - 2019-07-03 16:01:52 --> Config Class Initialized
INFO - 2019-07-03 16:01:52 --> Loader Class Initialized
DEBUG - 2019-07-03 16:01:52 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 16:01:52 --> Helper loaded: url_helper
INFO - 2019-07-03 16:01:52 --> Helper loaded: inflector_helper
INFO - 2019-07-03 16:01:52 --> Helper loaded: string_helper
INFO - 2019-07-03 16:01:52 --> Helper loaded: array_helper
INFO - 2019-07-03 16:01:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 16:01:52 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 16:01:52 --> Database Driver Class Initialized
INFO - 2019-07-03 16:01:52 --> Controller Class Initialized
INFO - 2019-07-03 22:01:52 --> Helper loaded: language_helper
INFO - 2019-07-03 22:01:52 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 22:01:52 --> Model Class Initialized
INFO - 2019-07-03 22:01:52 --> Model Class Initialized
INFO - 2019-07-03 22:01:52 --> Model Class Initialized
INFO - 2019-07-03 22:01:52 --> Model Class Initialized
INFO - 2019-07-03 22:01:52 --> Model Class Initialized
INFO - 2019-07-03 22:01:52 --> Final output sent to browser
DEBUG - 2019-07-03 22:01:52 --> Total execution time: 0.3471
INFO - 2019-07-03 16:01:52 --> Config Class Initialized
INFO - 2019-07-03 16:01:52 --> Hooks Class Initialized
DEBUG - 2019-07-03 16:01:52 --> UTF-8 Support Enabled
INFO - 2019-07-03 16:01:52 --> Utf8 Class Initialized
INFO - 2019-07-03 16:01:52 --> URI Class Initialized
INFO - 2019-07-03 16:01:52 --> Router Class Initialized
INFO - 2019-07-03 16:01:52 --> Output Class Initialized
INFO - 2019-07-03 16:01:52 --> Security Class Initialized
DEBUG - 2019-07-03 16:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 16:01:52 --> Input Class Initialized
INFO - 2019-07-03 16:01:52 --> Language Class Initialized
INFO - 2019-07-03 16:01:52 --> Language Class Initialized
INFO - 2019-07-03 16:01:52 --> Config Class Initialized
INFO - 2019-07-03 16:01:52 --> Loader Class Initialized
DEBUG - 2019-07-03 16:01:52 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 16:01:52 --> Helper loaded: url_helper
INFO - 2019-07-03 16:01:52 --> Helper loaded: inflector_helper
INFO - 2019-07-03 16:01:52 --> Helper loaded: string_helper
INFO - 2019-07-03 16:01:52 --> Helper loaded: array_helper
INFO - 2019-07-03 16:01:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 16:01:52 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 16:01:52 --> Database Driver Class Initialized
INFO - 2019-07-03 16:01:52 --> Controller Class Initialized
INFO - 2019-07-03 22:01:52 --> Helper loaded: language_helper
INFO - 2019-07-03 22:01:52 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 22:01:52 --> Model Class Initialized
INFO - 2019-07-03 22:01:52 --> Model Class Initialized
INFO - 2019-07-03 22:01:52 --> Model Class Initialized
INFO - 2019-07-03 22:01:52 --> Model Class Initialized
INFO - 2019-07-03 22:01:52 --> Model Class Initialized
INFO - 2019-07-03 22:01:52 --> Final output sent to browser
DEBUG - 2019-07-03 22:01:52 --> Total execution time: 0.3377
INFO - 2019-07-03 16:34:22 --> Config Class Initialized
INFO - 2019-07-03 16:34:22 --> Hooks Class Initialized
DEBUG - 2019-07-03 16:34:22 --> UTF-8 Support Enabled
INFO - 2019-07-03 16:34:22 --> Utf8 Class Initialized
INFO - 2019-07-03 16:34:22 --> URI Class Initialized
INFO - 2019-07-03 16:34:22 --> Router Class Initialized
INFO - 2019-07-03 16:34:22 --> Output Class Initialized
INFO - 2019-07-03 16:34:22 --> Security Class Initialized
DEBUG - 2019-07-03 16:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 16:34:22 --> Input Class Initialized
INFO - 2019-07-03 16:34:22 --> Language Class Initialized
INFO - 2019-07-03 16:34:22 --> Language Class Initialized
INFO - 2019-07-03 16:34:22 --> Config Class Initialized
INFO - 2019-07-03 16:34:22 --> Loader Class Initialized
DEBUG - 2019-07-03 16:34:22 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 16:34:22 --> Helper loaded: url_helper
INFO - 2019-07-03 16:34:22 --> Helper loaded: inflector_helper
INFO - 2019-07-03 16:34:22 --> Helper loaded: string_helper
INFO - 2019-07-03 16:34:22 --> Helper loaded: array_helper
INFO - 2019-07-03 16:34:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 16:34:22 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 16:34:22 --> Database Driver Class Initialized
INFO - 2019-07-03 16:34:22 --> Controller Class Initialized
INFO - 2019-07-03 22:34:22 --> Helper loaded: language_helper
INFO - 2019-07-03 22:34:22 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 22:34:22 --> Model Class Initialized
INFO - 2019-07-03 22:34:22 --> Model Class Initialized
INFO - 2019-07-03 22:34:22 --> Model Class Initialized
INFO - 2019-07-03 22:34:22 --> Model Class Initialized
INFO - 2019-07-03 22:34:22 --> Final output sent to browser
DEBUG - 2019-07-03 22:34:22 --> Total execution time: 0.3178
INFO - 2019-07-03 16:34:25 --> Config Class Initialized
INFO - 2019-07-03 16:34:25 --> Hooks Class Initialized
DEBUG - 2019-07-03 16:34:25 --> UTF-8 Support Enabled
INFO - 2019-07-03 16:34:25 --> Utf8 Class Initialized
INFO - 2019-07-03 16:34:25 --> URI Class Initialized
INFO - 2019-07-03 16:34:25 --> Router Class Initialized
INFO - 2019-07-03 16:34:25 --> Output Class Initialized
INFO - 2019-07-03 16:34:25 --> Security Class Initialized
DEBUG - 2019-07-03 16:34:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 16:34:25 --> Input Class Initialized
INFO - 2019-07-03 16:34:25 --> Language Class Initialized
INFO - 2019-07-03 16:34:25 --> Language Class Initialized
INFO - 2019-07-03 16:34:25 --> Config Class Initialized
INFO - 2019-07-03 16:34:25 --> Loader Class Initialized
DEBUG - 2019-07-03 16:34:25 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 16:34:25 --> Helper loaded: url_helper
INFO - 2019-07-03 16:34:25 --> Helper loaded: inflector_helper
INFO - 2019-07-03 16:34:25 --> Helper loaded: string_helper
INFO - 2019-07-03 16:34:25 --> Helper loaded: array_helper
INFO - 2019-07-03 16:34:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 16:34:25 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 16:34:25 --> Database Driver Class Initialized
INFO - 2019-07-03 16:34:25 --> Controller Class Initialized
INFO - 2019-07-03 22:34:25 --> Helper loaded: language_helper
INFO - 2019-07-03 22:34:25 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 22:34:25 --> Model Class Initialized
INFO - 2019-07-03 22:34:25 --> Model Class Initialized
INFO - 2019-07-03 22:34:25 --> Model Class Initialized
INFO - 2019-07-03 22:34:25 --> Model Class Initialized
INFO - 2019-07-03 22:34:25 --> Final output sent to browser
DEBUG - 2019-07-03 22:34:25 --> Total execution time: 0.3182
INFO - 2019-07-03 16:35:55 --> Config Class Initialized
INFO - 2019-07-03 16:35:55 --> Hooks Class Initialized
DEBUG - 2019-07-03 16:35:55 --> UTF-8 Support Enabled
INFO - 2019-07-03 16:35:55 --> Utf8 Class Initialized
INFO - 2019-07-03 16:35:55 --> URI Class Initialized
INFO - 2019-07-03 16:35:55 --> Router Class Initialized
INFO - 2019-07-03 16:35:55 --> Output Class Initialized
INFO - 2019-07-03 16:35:55 --> Security Class Initialized
DEBUG - 2019-07-03 16:35:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 16:35:55 --> Input Class Initialized
INFO - 2019-07-03 16:35:55 --> Language Class Initialized
INFO - 2019-07-03 16:35:55 --> Language Class Initialized
INFO - 2019-07-03 16:35:55 --> Config Class Initialized
INFO - 2019-07-03 16:35:55 --> Loader Class Initialized
DEBUG - 2019-07-03 16:35:55 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 16:35:55 --> Helper loaded: url_helper
INFO - 2019-07-03 16:35:55 --> Helper loaded: inflector_helper
INFO - 2019-07-03 16:35:55 --> Helper loaded: string_helper
INFO - 2019-07-03 16:35:55 --> Helper loaded: array_helper
INFO - 2019-07-03 16:35:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 16:35:55 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 16:35:55 --> Database Driver Class Initialized
INFO - 2019-07-03 16:35:55 --> Controller Class Initialized
INFO - 2019-07-03 22:35:55 --> Helper loaded: language_helper
INFO - 2019-07-03 22:35:55 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 22:35:55 --> Model Class Initialized
INFO - 2019-07-03 22:35:55 --> Model Class Initialized
INFO - 2019-07-03 22:35:55 --> Model Class Initialized
INFO - 2019-07-03 22:35:55 --> Model Class Initialized
INFO - 2019-07-03 22:35:55 --> Final output sent to browser
DEBUG - 2019-07-03 22:35:55 --> Total execution time: 0.3322
INFO - 2019-07-03 16:36:16 --> Config Class Initialized
INFO - 2019-07-03 16:36:16 --> Hooks Class Initialized
DEBUG - 2019-07-03 16:36:16 --> UTF-8 Support Enabled
INFO - 2019-07-03 16:36:16 --> Config Class Initialized
INFO - 2019-07-03 16:36:16 --> Utf8 Class Initialized
INFO - 2019-07-03 16:36:16 --> Hooks Class Initialized
INFO - 2019-07-03 16:36:16 --> URI Class Initialized
DEBUG - 2019-07-03 16:36:16 --> UTF-8 Support Enabled
INFO - 2019-07-03 16:36:16 --> Utf8 Class Initialized
INFO - 2019-07-03 16:36:16 --> Router Class Initialized
INFO - 2019-07-03 16:36:16 --> URI Class Initialized
INFO - 2019-07-03 16:36:16 --> Output Class Initialized
INFO - 2019-07-03 16:36:16 --> Router Class Initialized
INFO - 2019-07-03 16:36:16 --> Security Class Initialized
INFO - 2019-07-03 16:36:16 --> Output Class Initialized
DEBUG - 2019-07-03 16:36:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 16:36:16 --> Security Class Initialized
INFO - 2019-07-03 16:36:16 --> Input Class Initialized
INFO - 2019-07-03 16:36:16 --> Language Class Initialized
DEBUG - 2019-07-03 16:36:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 16:36:16 --> Language Class Initialized
INFO - 2019-07-03 16:36:16 --> Input Class Initialized
INFO - 2019-07-03 16:36:16 --> Config Class Initialized
INFO - 2019-07-03 16:36:16 --> Language Class Initialized
INFO - 2019-07-03 16:36:16 --> Loader Class Initialized
DEBUG - 2019-07-03 16:36:16 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 16:36:16 --> Language Class Initialized
INFO - 2019-07-03 16:36:16 --> Helper loaded: url_helper
INFO - 2019-07-03 16:36:16 --> Config Class Initialized
INFO - 2019-07-03 16:36:16 --> Loader Class Initialized
INFO - 2019-07-03 16:36:16 --> Helper loaded: inflector_helper
DEBUG - 2019-07-03 16:36:17 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 16:36:17 --> Helper loaded: string_helper
INFO - 2019-07-03 16:36:17 --> Helper loaded: url_helper
INFO - 2019-07-03 16:36:17 --> Helper loaded: array_helper
INFO - 2019-07-03 16:36:17 --> Helper loaded: inflector_helper
INFO - 2019-07-03 16:36:17 --> Session: Class initialized using 'files' driver.
INFO - 2019-07-03 16:36:17 --> Helper loaded: string_helper
DEBUG - 2019-07-03 16:36:17 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 16:36:17 --> Helper loaded: array_helper
INFO - 2019-07-03 16:36:17 --> Database Driver Class Initialized
INFO - 2019-07-03 16:36:17 --> Controller Class Initialized
INFO - 2019-07-03 22:36:17 --> Helper loaded: language_helper
INFO - 2019-07-03 22:36:17 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 22:36:17 --> Model Class Initialized
INFO - 2019-07-03 22:36:17 --> Model Class Initialized
INFO - 2019-07-03 22:36:17 --> Model Class Initialized
INFO - 2019-07-03 22:36:17 --> Model Class Initialized
INFO - 2019-07-03 22:36:17 --> Model Class Initialized
INFO - 2019-07-03 22:36:17 --> Final output sent to browser
DEBUG - 2019-07-03 22:36:17 --> Total execution time: 0.4589
INFO - 2019-07-03 16:36:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 16:36:17 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 16:36:17 --> Database Driver Class Initialized
INFO - 2019-07-03 16:36:17 --> Controller Class Initialized
INFO - 2019-07-03 22:36:17 --> Helper loaded: language_helper
INFO - 2019-07-03 22:36:17 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 22:36:17 --> Model Class Initialized
INFO - 2019-07-03 22:36:17 --> Model Class Initialized
INFO - 2019-07-03 22:36:17 --> Model Class Initialized
INFO - 2019-07-03 22:36:17 --> Model Class Initialized
INFO - 2019-07-03 22:36:17 --> Final output sent to browser
DEBUG - 2019-07-03 22:36:17 --> Total execution time: 0.5582
INFO - 2019-07-03 16:36:43 --> Config Class Initialized
INFO - 2019-07-03 16:36:43 --> Config Class Initialized
INFO - 2019-07-03 16:36:43 --> Hooks Class Initialized
INFO - 2019-07-03 16:36:43 --> Hooks Class Initialized
DEBUG - 2019-07-03 16:36:43 --> UTF-8 Support Enabled
DEBUG - 2019-07-03 16:36:43 --> UTF-8 Support Enabled
INFO - 2019-07-03 16:36:43 --> Utf8 Class Initialized
INFO - 2019-07-03 16:36:43 --> Utf8 Class Initialized
INFO - 2019-07-03 16:36:43 --> URI Class Initialized
INFO - 2019-07-03 16:36:43 --> URI Class Initialized
INFO - 2019-07-03 16:36:43 --> Router Class Initialized
INFO - 2019-07-03 16:36:43 --> Router Class Initialized
INFO - 2019-07-03 16:36:43 --> Output Class Initialized
INFO - 2019-07-03 16:36:43 --> Output Class Initialized
INFO - 2019-07-03 16:36:43 --> Security Class Initialized
INFO - 2019-07-03 16:36:43 --> Security Class Initialized
DEBUG - 2019-07-03 16:36:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-03 16:36:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 16:36:43 --> Input Class Initialized
INFO - 2019-07-03 16:36:43 --> Input Class Initialized
INFO - 2019-07-03 16:36:44 --> Language Class Initialized
INFO - 2019-07-03 16:36:44 --> Language Class Initialized
INFO - 2019-07-03 16:36:44 --> Language Class Initialized
INFO - 2019-07-03 16:36:44 --> Language Class Initialized
INFO - 2019-07-03 16:36:44 --> Config Class Initialized
INFO - 2019-07-03 16:36:44 --> Config Class Initialized
INFO - 2019-07-03 16:36:44 --> Loader Class Initialized
INFO - 2019-07-03 16:36:44 --> Loader Class Initialized
DEBUG - 2019-07-03 16:36:44 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-03 16:36:44 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 16:36:44 --> Helper loaded: url_helper
INFO - 2019-07-03 16:36:44 --> Helper loaded: url_helper
INFO - 2019-07-03 16:36:44 --> Helper loaded: inflector_helper
INFO - 2019-07-03 16:36:44 --> Helper loaded: inflector_helper
INFO - 2019-07-03 16:36:44 --> Helper loaded: string_helper
INFO - 2019-07-03 16:36:44 --> Helper loaded: string_helper
INFO - 2019-07-03 16:36:44 --> Helper loaded: array_helper
INFO - 2019-07-03 16:36:44 --> Helper loaded: array_helper
INFO - 2019-07-03 16:36:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 16:36:44 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 16:36:44 --> Database Driver Class Initialized
INFO - 2019-07-03 16:36:44 --> Controller Class Initialized
INFO - 2019-07-03 22:36:44 --> Helper loaded: language_helper
INFO - 2019-07-03 22:36:44 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 22:36:44 --> Model Class Initialized
INFO - 2019-07-03 22:36:44 --> Model Class Initialized
INFO - 2019-07-03 22:36:44 --> Model Class Initialized
INFO - 2019-07-03 22:36:44 --> Model Class Initialized
INFO - 2019-07-03 22:36:44 --> Model Class Initialized
INFO - 2019-07-03 22:36:44 --> Final output sent to browser
DEBUG - 2019-07-03 22:36:44 --> Total execution time: 0.4281
INFO - 2019-07-03 16:36:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 16:36:44 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 16:36:44 --> Database Driver Class Initialized
INFO - 2019-07-03 16:36:44 --> Controller Class Initialized
INFO - 2019-07-03 22:36:44 --> Helper loaded: language_helper
INFO - 2019-07-03 22:36:44 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 22:36:44 --> Model Class Initialized
INFO - 2019-07-03 22:36:44 --> Model Class Initialized
INFO - 2019-07-03 22:36:44 --> Model Class Initialized
INFO - 2019-07-03 22:36:44 --> Model Class Initialized
INFO - 2019-07-03 22:36:44 --> Final output sent to browser
DEBUG - 2019-07-03 22:36:44 --> Total execution time: 0.5539
INFO - 2019-07-03 16:37:04 --> Config Class Initialized
INFO - 2019-07-03 16:37:04 --> Hooks Class Initialized
INFO - 2019-07-03 16:37:05 --> Config Class Initialized
INFO - 2019-07-03 16:37:05 --> Hooks Class Initialized
DEBUG - 2019-07-03 16:37:05 --> UTF-8 Support Enabled
INFO - 2019-07-03 16:37:05 --> Utf8 Class Initialized
DEBUG - 2019-07-03 16:37:05 --> UTF-8 Support Enabled
INFO - 2019-07-03 16:37:05 --> URI Class Initialized
INFO - 2019-07-03 16:37:05 --> Utf8 Class Initialized
INFO - 2019-07-03 16:37:05 --> URI Class Initialized
INFO - 2019-07-03 16:37:05 --> Router Class Initialized
INFO - 2019-07-03 16:37:05 --> Router Class Initialized
INFO - 2019-07-03 16:37:05 --> Output Class Initialized
INFO - 2019-07-03 16:37:05 --> Output Class Initialized
INFO - 2019-07-03 16:37:05 --> Security Class Initialized
INFO - 2019-07-03 16:37:05 --> Security Class Initialized
DEBUG - 2019-07-03 16:37:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-03 16:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 16:37:05 --> Input Class Initialized
INFO - 2019-07-03 16:37:05 --> Input Class Initialized
INFO - 2019-07-03 16:37:05 --> Language Class Initialized
INFO - 2019-07-03 16:37:05 --> Language Class Initialized
INFO - 2019-07-03 16:37:05 --> Language Class Initialized
INFO - 2019-07-03 16:37:05 --> Language Class Initialized
INFO - 2019-07-03 16:37:05 --> Config Class Initialized
INFO - 2019-07-03 16:37:05 --> Config Class Initialized
INFO - 2019-07-03 16:37:05 --> Loader Class Initialized
INFO - 2019-07-03 16:37:05 --> Loader Class Initialized
DEBUG - 2019-07-03 16:37:05 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-03 16:37:05 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 16:37:05 --> Helper loaded: url_helper
INFO - 2019-07-03 16:37:05 --> Helper loaded: url_helper
INFO - 2019-07-03 16:37:05 --> Helper loaded: inflector_helper
INFO - 2019-07-03 16:37:05 --> Helper loaded: inflector_helper
INFO - 2019-07-03 16:37:05 --> Helper loaded: string_helper
INFO - 2019-07-03 16:37:05 --> Helper loaded: array_helper
INFO - 2019-07-03 16:37:05 --> Session: Class initialized using 'files' driver.
INFO - 2019-07-03 16:37:05 --> Helper loaded: string_helper
DEBUG - 2019-07-03 16:37:05 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 16:37:05 --> Helper loaded: array_helper
INFO - 2019-07-03 16:37:05 --> Database Driver Class Initialized
INFO - 2019-07-03 16:37:05 --> Controller Class Initialized
INFO - 2019-07-03 22:37:05 --> Helper loaded: language_helper
INFO - 2019-07-03 16:37:05 --> Config Class Initialized
INFO - 2019-07-03 16:37:05 --> Config Class Initialized
INFO - 2019-07-03 16:37:05 --> Hooks Class Initialized
INFO - 2019-07-03 22:37:05 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 16:37:05 --> Hooks Class Initialized
DEBUG - 2019-07-03 16:37:05 --> UTF-8 Support Enabled
INFO - 2019-07-03 22:37:05 --> Model Class Initialized
DEBUG - 2019-07-03 16:37:05 --> UTF-8 Support Enabled
INFO - 2019-07-03 16:37:05 --> Utf8 Class Initialized
INFO - 2019-07-03 16:37:05 --> Utf8 Class Initialized
INFO - 2019-07-03 16:37:05 --> URI Class Initialized
INFO - 2019-07-03 22:37:05 --> Model Class Initialized
INFO - 2019-07-03 16:37:05 --> URI Class Initialized
INFO - 2019-07-03 16:37:05 --> Router Class Initialized
INFO - 2019-07-03 22:37:05 --> Model Class Initialized
INFO - 2019-07-03 16:37:05 --> Router Class Initialized
INFO - 2019-07-03 16:37:05 --> Output Class Initialized
INFO - 2019-07-03 22:37:05 --> Model Class Initialized
INFO - 2019-07-03 16:37:05 --> Output Class Initialized
INFO - 2019-07-03 22:37:05 --> Model Class Initialized
INFO - 2019-07-03 16:37:05 --> Security Class Initialized
INFO - 2019-07-03 16:37:05 --> Security Class Initialized
INFO - 2019-07-03 22:37:05 --> Final output sent to browser
DEBUG - 2019-07-03 16:37:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-03 22:37:05 --> Total execution time: 0.6806
DEBUG - 2019-07-03 16:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 16:37:05 --> Input Class Initialized
INFO - 2019-07-03 16:37:05 --> Input Class Initialized
INFO - 2019-07-03 16:37:05 --> Language Class Initialized
INFO - 2019-07-03 16:37:05 --> Session: Class initialized using 'files' driver.
INFO - 2019-07-03 16:37:05 --> Language Class Initialized
DEBUG - 2019-07-03 16:37:05 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 16:37:05 --> Language Class Initialized
INFO - 2019-07-03 16:37:05 --> Language Class Initialized
INFO - 2019-07-03 16:37:05 --> Config Class Initialized
INFO - 2019-07-03 16:37:05 --> Database Driver Class Initialized
INFO - 2019-07-03 16:37:05 --> Config Class Initialized
INFO - 2019-07-03 16:37:05 --> Loader Class Initialized
INFO - 2019-07-03 16:37:05 --> Loader Class Initialized
INFO - 2019-07-03 16:37:05 --> Controller Class Initialized
DEBUG - 2019-07-03 16:37:05 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-03 16:37:05 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 22:37:05 --> Helper loaded: language_helper
INFO - 2019-07-03 16:37:05 --> Helper loaded: url_helper
INFO - 2019-07-03 16:37:05 --> Helper loaded: url_helper
INFO - 2019-07-03 22:37:05 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 16:37:05 --> Helper loaded: inflector_helper
INFO - 2019-07-03 16:37:05 --> Helper loaded: inflector_helper
INFO - 2019-07-03 16:37:05 --> Helper loaded: string_helper
INFO - 2019-07-03 22:37:05 --> Model Class Initialized
INFO - 2019-07-03 16:37:05 --> Helper loaded: string_helper
INFO - 2019-07-03 22:37:05 --> Model Class Initialized
INFO - 2019-07-03 16:37:05 --> Helper loaded: array_helper
INFO - 2019-07-03 16:37:05 --> Helper loaded: array_helper
INFO - 2019-07-03 22:37:05 --> Model Class Initialized
INFO - 2019-07-03 22:37:05 --> Model Class Initialized
INFO - 2019-07-03 22:37:05 --> Final output sent to browser
DEBUG - 2019-07-03 22:37:05 --> Total execution time: 0.8964
INFO - 2019-07-03 16:37:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 16:37:05 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 16:37:05 --> Database Driver Class Initialized
INFO - 2019-07-03 16:37:05 --> Controller Class Initialized
INFO - 2019-07-03 22:37:05 --> Helper loaded: language_helper
INFO - 2019-07-03 22:37:05 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 22:37:05 --> Model Class Initialized
INFO - 2019-07-03 22:37:05 --> Model Class Initialized
INFO - 2019-07-03 22:37:05 --> Model Class Initialized
INFO - 2019-07-03 22:37:06 --> Model Class Initialized
INFO - 2019-07-03 22:37:06 --> Model Class Initialized
INFO - 2019-07-03 22:37:06 --> Final output sent to browser
DEBUG - 2019-07-03 22:37:06 --> Total execution time: 0.5415
INFO - 2019-07-03 16:37:06 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 16:37:06 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 16:37:06 --> Database Driver Class Initialized
INFO - 2019-07-03 16:37:06 --> Controller Class Initialized
INFO - 2019-07-03 22:37:06 --> Helper loaded: language_helper
INFO - 2019-07-03 22:37:06 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 22:37:06 --> Model Class Initialized
INFO - 2019-07-03 22:37:06 --> Model Class Initialized
INFO - 2019-07-03 22:37:06 --> Model Class Initialized
INFO - 2019-07-03 22:37:06 --> Model Class Initialized
INFO - 2019-07-03 22:37:06 --> Final output sent to browser
DEBUG - 2019-07-03 22:37:06 --> Total execution time: 0.6711
INFO - 2019-07-03 16:37:59 --> Config Class Initialized
INFO - 2019-07-03 16:37:59 --> Hooks Class Initialized
DEBUG - 2019-07-03 16:37:59 --> UTF-8 Support Enabled
INFO - 2019-07-03 16:37:59 --> Utf8 Class Initialized
INFO - 2019-07-03 16:37:59 --> URI Class Initialized
INFO - 2019-07-03 16:37:59 --> Router Class Initialized
INFO - 2019-07-03 16:37:59 --> Output Class Initialized
INFO - 2019-07-03 16:37:59 --> Security Class Initialized
DEBUG - 2019-07-03 16:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 16:37:59 --> Input Class Initialized
INFO - 2019-07-03 16:37:59 --> Language Class Initialized
INFO - 2019-07-03 16:37:59 --> Language Class Initialized
INFO - 2019-07-03 16:37:59 --> Config Class Initialized
INFO - 2019-07-03 16:37:59 --> Loader Class Initialized
DEBUG - 2019-07-03 16:37:59 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 16:37:59 --> Helper loaded: url_helper
INFO - 2019-07-03 16:37:59 --> Helper loaded: inflector_helper
INFO - 2019-07-03 16:37:59 --> Helper loaded: string_helper
INFO - 2019-07-03 16:37:59 --> Helper loaded: array_helper
INFO - 2019-07-03 16:37:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 16:37:59 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 16:37:59 --> Database Driver Class Initialized
INFO - 2019-07-03 16:37:59 --> Controller Class Initialized
INFO - 2019-07-03 22:37:59 --> Helper loaded: language_helper
INFO - 2019-07-03 22:37:59 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 22:37:59 --> Model Class Initialized
INFO - 2019-07-03 22:37:59 --> Model Class Initialized
INFO - 2019-07-03 22:37:59 --> Model Class Initialized
INFO - 2019-07-03 22:37:59 --> Model Class Initialized
INFO - 2019-07-03 22:37:59 --> Model Class Initialized
INFO - 2019-07-03 22:37:59 --> Final output sent to browser
DEBUG - 2019-07-03 22:37:59 --> Total execution time: 0.3242
INFO - 2019-07-03 16:38:02 --> Config Class Initialized
INFO - 2019-07-03 16:38:02 --> Hooks Class Initialized
DEBUG - 2019-07-03 16:38:02 --> UTF-8 Support Enabled
INFO - 2019-07-03 16:38:02 --> Utf8 Class Initialized
INFO - 2019-07-03 16:38:02 --> URI Class Initialized
INFO - 2019-07-03 16:38:02 --> Router Class Initialized
INFO - 2019-07-03 16:38:02 --> Output Class Initialized
INFO - 2019-07-03 16:38:02 --> Security Class Initialized
DEBUG - 2019-07-03 16:38:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 16:38:03 --> Input Class Initialized
INFO - 2019-07-03 16:38:03 --> Language Class Initialized
INFO - 2019-07-03 16:38:03 --> Language Class Initialized
INFO - 2019-07-03 16:38:03 --> Config Class Initialized
INFO - 2019-07-03 16:38:03 --> Loader Class Initialized
DEBUG - 2019-07-03 16:38:03 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 16:38:03 --> Helper loaded: url_helper
INFO - 2019-07-03 16:38:03 --> Helper loaded: inflector_helper
INFO - 2019-07-03 16:38:03 --> Helper loaded: string_helper
INFO - 2019-07-03 16:38:03 --> Helper loaded: array_helper
INFO - 2019-07-03 16:38:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 16:38:03 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 16:38:03 --> Database Driver Class Initialized
INFO - 2019-07-03 16:38:03 --> Controller Class Initialized
INFO - 2019-07-03 22:38:03 --> Helper loaded: language_helper
INFO - 2019-07-03 22:38:03 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 22:38:03 --> Model Class Initialized
INFO - 2019-07-03 22:38:03 --> Model Class Initialized
INFO - 2019-07-03 22:38:03 --> Model Class Initialized
INFO - 2019-07-03 22:38:03 --> Model Class Initialized
INFO - 2019-07-03 22:38:03 --> Model Class Initialized
INFO - 2019-07-03 22:38:03 --> Final output sent to browser
DEBUG - 2019-07-03 22:38:03 --> Total execution time: 0.3458
INFO - 2019-07-03 16:38:18 --> Config Class Initialized
INFO - 2019-07-03 16:38:18 --> Hooks Class Initialized
DEBUG - 2019-07-03 16:38:18 --> UTF-8 Support Enabled
INFO - 2019-07-03 16:38:18 --> Utf8 Class Initialized
INFO - 2019-07-03 16:38:18 --> URI Class Initialized
INFO - 2019-07-03 16:38:18 --> Router Class Initialized
INFO - 2019-07-03 16:38:18 --> Output Class Initialized
INFO - 2019-07-03 16:38:18 --> Security Class Initialized
DEBUG - 2019-07-03 16:38:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 16:38:18 --> Input Class Initialized
INFO - 2019-07-03 16:38:18 --> Language Class Initialized
INFO - 2019-07-03 16:38:18 --> Language Class Initialized
INFO - 2019-07-03 16:38:18 --> Config Class Initialized
INFO - 2019-07-03 16:38:18 --> Loader Class Initialized
DEBUG - 2019-07-03 16:38:18 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 16:38:18 --> Helper loaded: url_helper
INFO - 2019-07-03 16:38:18 --> Helper loaded: inflector_helper
INFO - 2019-07-03 16:38:18 --> Helper loaded: string_helper
INFO - 2019-07-03 16:38:18 --> Helper loaded: array_helper
INFO - 2019-07-03 16:38:18 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 16:38:18 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 16:38:18 --> Database Driver Class Initialized
INFO - 2019-07-03 16:38:18 --> Controller Class Initialized
INFO - 2019-07-03 22:38:18 --> Helper loaded: language_helper
INFO - 2019-07-03 22:38:18 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 22:38:18 --> Model Class Initialized
INFO - 2019-07-03 22:38:18 --> Model Class Initialized
INFO - 2019-07-03 22:38:18 --> Model Class Initialized
INFO - 2019-07-03 22:38:18 --> Model Class Initialized
INFO - 2019-07-03 22:38:18 --> Model Class Initialized
INFO - 2019-07-03 22:38:18 --> Final output sent to browser
DEBUG - 2019-07-03 22:38:18 --> Total execution time: 0.3711
INFO - 2019-07-03 16:38:51 --> Config Class Initialized
INFO - 2019-07-03 16:38:51 --> Hooks Class Initialized
DEBUG - 2019-07-03 16:38:51 --> UTF-8 Support Enabled
INFO - 2019-07-03 16:38:51 --> Utf8 Class Initialized
INFO - 2019-07-03 16:38:51 --> URI Class Initialized
INFO - 2019-07-03 16:38:51 --> Router Class Initialized
INFO - 2019-07-03 16:38:51 --> Output Class Initialized
INFO - 2019-07-03 16:38:51 --> Security Class Initialized
DEBUG - 2019-07-03 16:38:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 16:38:51 --> Input Class Initialized
INFO - 2019-07-03 16:38:51 --> Language Class Initialized
INFO - 2019-07-03 16:38:51 --> Language Class Initialized
INFO - 2019-07-03 16:38:51 --> Config Class Initialized
INFO - 2019-07-03 16:38:51 --> Loader Class Initialized
DEBUG - 2019-07-03 16:38:51 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 16:38:51 --> Helper loaded: url_helper
INFO - 2019-07-03 16:38:51 --> Helper loaded: inflector_helper
INFO - 2019-07-03 16:38:51 --> Helper loaded: string_helper
INFO - 2019-07-03 16:38:51 --> Helper loaded: array_helper
INFO - 2019-07-03 16:38:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 16:38:51 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 16:38:51 --> Database Driver Class Initialized
INFO - 2019-07-03 16:38:51 --> Controller Class Initialized
INFO - 2019-07-03 22:38:51 --> Helper loaded: language_helper
INFO - 2019-07-03 22:38:51 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 22:38:51 --> Model Class Initialized
INFO - 2019-07-03 22:38:51 --> Model Class Initialized
INFO - 2019-07-03 22:38:51 --> Model Class Initialized
INFO - 2019-07-03 22:38:51 --> Model Class Initialized
INFO - 2019-07-03 22:38:51 --> Model Class Initialized
INFO - 2019-07-03 22:38:51 --> Final output sent to browser
DEBUG - 2019-07-03 22:38:51 --> Total execution time: 0.3499
INFO - 2019-07-03 16:39:09 --> Config Class Initialized
INFO - 2019-07-03 16:39:09 --> Hooks Class Initialized
DEBUG - 2019-07-03 16:39:09 --> UTF-8 Support Enabled
INFO - 2019-07-03 16:39:09 --> Utf8 Class Initialized
INFO - 2019-07-03 16:39:09 --> URI Class Initialized
INFO - 2019-07-03 16:39:09 --> Router Class Initialized
INFO - 2019-07-03 16:39:09 --> Output Class Initialized
INFO - 2019-07-03 16:39:09 --> Security Class Initialized
DEBUG - 2019-07-03 16:39:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 16:39:09 --> Input Class Initialized
INFO - 2019-07-03 16:39:09 --> Language Class Initialized
INFO - 2019-07-03 16:39:09 --> Language Class Initialized
INFO - 2019-07-03 16:39:09 --> Config Class Initialized
INFO - 2019-07-03 16:39:09 --> Loader Class Initialized
DEBUG - 2019-07-03 16:39:09 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 16:39:09 --> Helper loaded: url_helper
INFO - 2019-07-03 16:39:09 --> Helper loaded: inflector_helper
INFO - 2019-07-03 16:39:09 --> Helper loaded: string_helper
INFO - 2019-07-03 16:39:09 --> Helper loaded: array_helper
INFO - 2019-07-03 16:39:09 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 16:39:09 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 16:39:09 --> Database Driver Class Initialized
INFO - 2019-07-03 16:39:09 --> Controller Class Initialized
INFO - 2019-07-03 22:39:09 --> Helper loaded: language_helper
INFO - 2019-07-03 22:39:09 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 22:39:09 --> Model Class Initialized
INFO - 2019-07-03 22:39:09 --> Model Class Initialized
INFO - 2019-07-03 22:39:09 --> Model Class Initialized
INFO - 2019-07-03 22:39:09 --> Model Class Initialized
INFO - 2019-07-03 22:39:09 --> Model Class Initialized
INFO - 2019-07-03 22:39:09 --> Final output sent to browser
DEBUG - 2019-07-03 22:39:09 --> Total execution time: 0.3396
INFO - 2019-07-03 16:39:24 --> Config Class Initialized
INFO - 2019-07-03 16:39:24 --> Hooks Class Initialized
DEBUG - 2019-07-03 16:39:24 --> UTF-8 Support Enabled
INFO - 2019-07-03 16:39:24 --> Utf8 Class Initialized
INFO - 2019-07-03 16:39:24 --> URI Class Initialized
INFO - 2019-07-03 16:39:24 --> Router Class Initialized
INFO - 2019-07-03 16:39:24 --> Output Class Initialized
INFO - 2019-07-03 16:39:24 --> Security Class Initialized
DEBUG - 2019-07-03 16:39:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 16:39:24 --> Input Class Initialized
INFO - 2019-07-03 16:39:24 --> Language Class Initialized
INFO - 2019-07-03 16:39:24 --> Language Class Initialized
INFO - 2019-07-03 16:39:24 --> Config Class Initialized
INFO - 2019-07-03 16:39:24 --> Loader Class Initialized
DEBUG - 2019-07-03 16:39:24 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 16:39:24 --> Helper loaded: url_helper
INFO - 2019-07-03 16:39:24 --> Helper loaded: inflector_helper
INFO - 2019-07-03 16:39:24 --> Helper loaded: string_helper
INFO - 2019-07-03 16:39:24 --> Helper loaded: array_helper
INFO - 2019-07-03 16:39:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 16:39:24 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 16:39:24 --> Database Driver Class Initialized
INFO - 2019-07-03 16:39:24 --> Controller Class Initialized
INFO - 2019-07-03 22:39:24 --> Helper loaded: language_helper
INFO - 2019-07-03 22:39:24 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 22:39:24 --> Model Class Initialized
INFO - 2019-07-03 22:39:24 --> Model Class Initialized
INFO - 2019-07-03 22:39:24 --> Model Class Initialized
INFO - 2019-07-03 22:39:24 --> Model Class Initialized
INFO - 2019-07-03 22:39:24 --> Model Class Initialized
INFO - 2019-07-03 22:39:24 --> Final output sent to browser
DEBUG - 2019-07-03 22:39:24 --> Total execution time: 0.3363
INFO - 2019-07-03 16:39:24 --> Config Class Initialized
INFO - 2019-07-03 16:39:24 --> Hooks Class Initialized
DEBUG - 2019-07-03 16:39:24 --> UTF-8 Support Enabled
INFO - 2019-07-03 16:39:24 --> Utf8 Class Initialized
INFO - 2019-07-03 16:39:24 --> URI Class Initialized
INFO - 2019-07-03 16:39:24 --> Router Class Initialized
INFO - 2019-07-03 16:39:24 --> Output Class Initialized
INFO - 2019-07-03 16:39:24 --> Security Class Initialized
DEBUG - 2019-07-03 16:39:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 16:39:24 --> Input Class Initialized
INFO - 2019-07-03 16:39:24 --> Language Class Initialized
INFO - 2019-07-03 16:39:24 --> Language Class Initialized
INFO - 2019-07-03 16:39:24 --> Config Class Initialized
INFO - 2019-07-03 16:39:24 --> Loader Class Initialized
DEBUG - 2019-07-03 16:39:24 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 16:39:24 --> Helper loaded: url_helper
INFO - 2019-07-03 16:39:24 --> Helper loaded: inflector_helper
INFO - 2019-07-03 16:39:25 --> Helper loaded: string_helper
INFO - 2019-07-03 16:39:25 --> Helper loaded: array_helper
INFO - 2019-07-03 16:39:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 16:39:25 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 16:39:25 --> Database Driver Class Initialized
INFO - 2019-07-03 16:39:25 --> Controller Class Initialized
INFO - 2019-07-03 22:39:25 --> Helper loaded: language_helper
INFO - 2019-07-03 22:39:25 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 22:39:25 --> Model Class Initialized
INFO - 2019-07-03 22:39:25 --> Model Class Initialized
INFO - 2019-07-03 22:39:25 --> Model Class Initialized
INFO - 2019-07-03 22:39:25 --> Model Class Initialized
INFO - 2019-07-03 22:39:25 --> Final output sent to browser
DEBUG - 2019-07-03 22:39:25 --> Total execution time: 0.3279
INFO - 2019-07-03 16:39:34 --> Config Class Initialized
INFO - 2019-07-03 16:39:34 --> Hooks Class Initialized
DEBUG - 2019-07-03 16:39:34 --> UTF-8 Support Enabled
INFO - 2019-07-03 16:39:34 --> Utf8 Class Initialized
INFO - 2019-07-03 16:39:34 --> URI Class Initialized
INFO - 2019-07-03 16:39:34 --> Router Class Initialized
INFO - 2019-07-03 16:39:34 --> Output Class Initialized
INFO - 2019-07-03 16:39:34 --> Security Class Initialized
DEBUG - 2019-07-03 16:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 16:39:34 --> Input Class Initialized
INFO - 2019-07-03 16:39:34 --> Language Class Initialized
INFO - 2019-07-03 16:39:34 --> Language Class Initialized
INFO - 2019-07-03 16:39:34 --> Config Class Initialized
INFO - 2019-07-03 16:39:34 --> Loader Class Initialized
DEBUG - 2019-07-03 16:39:34 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 16:39:34 --> Helper loaded: url_helper
INFO - 2019-07-03 16:39:34 --> Helper loaded: inflector_helper
INFO - 2019-07-03 16:39:34 --> Helper loaded: string_helper
INFO - 2019-07-03 16:39:34 --> Helper loaded: array_helper
INFO - 2019-07-03 16:39:34 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 16:39:34 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 16:39:34 --> Database Driver Class Initialized
INFO - 2019-07-03 16:39:34 --> Controller Class Initialized
INFO - 2019-07-03 22:39:34 --> Helper loaded: language_helper
INFO - 2019-07-03 22:39:34 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 22:39:34 --> Model Class Initialized
INFO - 2019-07-03 22:39:34 --> Model Class Initialized
INFO - 2019-07-03 22:39:34 --> Model Class Initialized
INFO - 2019-07-03 22:39:34 --> Model Class Initialized
INFO - 2019-07-03 22:39:34 --> Model Class Initialized
INFO - 2019-07-03 22:39:34 --> Final output sent to browser
DEBUG - 2019-07-03 22:39:34 --> Total execution time: 0.3253
INFO - 2019-07-03 16:39:34 --> Config Class Initialized
INFO - 2019-07-03 16:39:34 --> Hooks Class Initialized
DEBUG - 2019-07-03 16:39:34 --> UTF-8 Support Enabled
INFO - 2019-07-03 16:39:34 --> Utf8 Class Initialized
INFO - 2019-07-03 16:39:34 --> URI Class Initialized
INFO - 2019-07-03 16:39:34 --> Router Class Initialized
INFO - 2019-07-03 16:39:34 --> Output Class Initialized
INFO - 2019-07-03 16:39:34 --> Security Class Initialized
DEBUG - 2019-07-03 16:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 16:39:34 --> Input Class Initialized
INFO - 2019-07-03 16:39:34 --> Language Class Initialized
INFO - 2019-07-03 16:39:34 --> Language Class Initialized
INFO - 2019-07-03 16:39:34 --> Config Class Initialized
INFO - 2019-07-03 16:39:34 --> Loader Class Initialized
DEBUG - 2019-07-03 16:39:34 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 16:39:34 --> Helper loaded: url_helper
INFO - 2019-07-03 16:39:34 --> Helper loaded: inflector_helper
INFO - 2019-07-03 16:39:34 --> Helper loaded: string_helper
INFO - 2019-07-03 16:39:34 --> Helper loaded: array_helper
INFO - 2019-07-03 16:39:34 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 16:39:34 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 16:39:34 --> Database Driver Class Initialized
INFO - 2019-07-03 16:39:34 --> Controller Class Initialized
INFO - 2019-07-03 22:39:34 --> Helper loaded: language_helper
INFO - 2019-07-03 22:39:34 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 22:39:34 --> Model Class Initialized
INFO - 2019-07-03 22:39:34 --> Model Class Initialized
INFO - 2019-07-03 22:39:34 --> Model Class Initialized
INFO - 2019-07-03 22:39:35 --> Model Class Initialized
INFO - 2019-07-03 22:39:35 --> Final output sent to browser
DEBUG - 2019-07-03 22:39:35 --> Total execution time: 0.3422
INFO - 2019-07-03 16:40:40 --> Config Class Initialized
INFO - 2019-07-03 16:40:40 --> Hooks Class Initialized
DEBUG - 2019-07-03 16:40:40 --> UTF-8 Support Enabled
INFO - 2019-07-03 16:40:40 --> Utf8 Class Initialized
INFO - 2019-07-03 16:40:40 --> URI Class Initialized
INFO - 2019-07-03 16:40:40 --> Router Class Initialized
INFO - 2019-07-03 16:40:40 --> Output Class Initialized
INFO - 2019-07-03 16:40:40 --> Security Class Initialized
DEBUG - 2019-07-03 16:40:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 16:40:40 --> Input Class Initialized
INFO - 2019-07-03 16:40:40 --> Language Class Initialized
INFO - 2019-07-03 16:40:40 --> Language Class Initialized
INFO - 2019-07-03 16:40:40 --> Config Class Initialized
INFO - 2019-07-03 16:40:40 --> Loader Class Initialized
DEBUG - 2019-07-03 16:40:40 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 16:40:40 --> Helper loaded: url_helper
INFO - 2019-07-03 16:40:40 --> Helper loaded: inflector_helper
INFO - 2019-07-03 16:40:40 --> Helper loaded: string_helper
INFO - 2019-07-03 16:40:40 --> Helper loaded: array_helper
INFO - 2019-07-03 16:40:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 16:40:40 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 16:40:40 --> Database Driver Class Initialized
INFO - 2019-07-03 16:40:40 --> Controller Class Initialized
INFO - 2019-07-03 22:40:40 --> Helper loaded: language_helper
INFO - 2019-07-03 22:40:40 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 22:40:40 --> Model Class Initialized
INFO - 2019-07-03 22:40:40 --> Model Class Initialized
INFO - 2019-07-03 22:40:40 --> Model Class Initialized
INFO - 2019-07-03 22:40:40 --> Model Class Initialized
INFO - 2019-07-03 22:40:40 --> Model Class Initialized
INFO - 2019-07-03 22:40:40 --> Final output sent to browser
DEBUG - 2019-07-03 22:40:40 --> Total execution time: 0.3342
INFO - 2019-07-03 16:40:40 --> Config Class Initialized
INFO - 2019-07-03 16:40:40 --> Hooks Class Initialized
DEBUG - 2019-07-03 16:40:40 --> UTF-8 Support Enabled
INFO - 2019-07-03 16:40:40 --> Utf8 Class Initialized
INFO - 2019-07-03 16:40:40 --> URI Class Initialized
INFO - 2019-07-03 16:40:40 --> Router Class Initialized
INFO - 2019-07-03 16:40:40 --> Output Class Initialized
INFO - 2019-07-03 16:40:40 --> Security Class Initialized
DEBUG - 2019-07-03 16:40:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 16:40:40 --> Input Class Initialized
INFO - 2019-07-03 16:40:40 --> Language Class Initialized
INFO - 2019-07-03 16:40:40 --> Language Class Initialized
INFO - 2019-07-03 16:40:40 --> Config Class Initialized
INFO - 2019-07-03 16:40:40 --> Loader Class Initialized
DEBUG - 2019-07-03 16:40:40 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 16:40:40 --> Helper loaded: url_helper
INFO - 2019-07-03 16:40:40 --> Helper loaded: inflector_helper
INFO - 2019-07-03 16:40:40 --> Helper loaded: string_helper
INFO - 2019-07-03 16:40:40 --> Helper loaded: array_helper
INFO - 2019-07-03 16:40:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 16:40:40 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 16:40:41 --> Database Driver Class Initialized
INFO - 2019-07-03 16:40:41 --> Controller Class Initialized
INFO - 2019-07-03 22:40:41 --> Helper loaded: language_helper
INFO - 2019-07-03 22:40:41 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 22:40:41 --> Model Class Initialized
INFO - 2019-07-03 22:40:41 --> Model Class Initialized
INFO - 2019-07-03 22:40:41 --> Model Class Initialized
INFO - 2019-07-03 22:40:41 --> Model Class Initialized
INFO - 2019-07-03 22:40:41 --> Final output sent to browser
DEBUG - 2019-07-03 22:40:41 --> Total execution time: 0.3330
INFO - 2019-07-03 16:41:10 --> Config Class Initialized
INFO - 2019-07-03 16:41:10 --> Hooks Class Initialized
DEBUG - 2019-07-03 16:41:10 --> UTF-8 Support Enabled
INFO - 2019-07-03 16:41:10 --> Utf8 Class Initialized
INFO - 2019-07-03 16:41:10 --> URI Class Initialized
INFO - 2019-07-03 16:41:10 --> Router Class Initialized
INFO - 2019-07-03 16:41:10 --> Output Class Initialized
INFO - 2019-07-03 16:41:10 --> Security Class Initialized
DEBUG - 2019-07-03 16:41:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 16:41:10 --> Input Class Initialized
INFO - 2019-07-03 16:41:10 --> Language Class Initialized
INFO - 2019-07-03 16:41:10 --> Language Class Initialized
INFO - 2019-07-03 16:41:10 --> Config Class Initialized
INFO - 2019-07-03 16:41:10 --> Loader Class Initialized
DEBUG - 2019-07-03 16:41:10 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 16:41:10 --> Helper loaded: url_helper
INFO - 2019-07-03 16:41:10 --> Helper loaded: inflector_helper
INFO - 2019-07-03 16:41:10 --> Helper loaded: string_helper
INFO - 2019-07-03 16:41:10 --> Helper loaded: array_helper
INFO - 2019-07-03 16:41:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 16:41:10 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 16:41:10 --> Database Driver Class Initialized
INFO - 2019-07-03 16:41:10 --> Controller Class Initialized
INFO - 2019-07-03 22:41:10 --> Helper loaded: language_helper
INFO - 2019-07-03 22:41:10 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 22:41:10 --> Model Class Initialized
INFO - 2019-07-03 22:41:10 --> Model Class Initialized
INFO - 2019-07-03 22:41:10 --> Model Class Initialized
INFO - 2019-07-03 22:41:10 --> Model Class Initialized
INFO - 2019-07-03 22:41:10 --> Model Class Initialized
INFO - 2019-07-03 22:41:10 --> Final output sent to browser
DEBUG - 2019-07-03 22:41:10 --> Total execution time: 0.3448
INFO - 2019-07-03 16:41:11 --> Config Class Initialized
INFO - 2019-07-03 16:41:11 --> Hooks Class Initialized
DEBUG - 2019-07-03 16:41:11 --> UTF-8 Support Enabled
INFO - 2019-07-03 16:41:11 --> Utf8 Class Initialized
INFO - 2019-07-03 16:41:11 --> URI Class Initialized
INFO - 2019-07-03 16:41:11 --> Router Class Initialized
INFO - 2019-07-03 16:41:11 --> Output Class Initialized
INFO - 2019-07-03 16:41:11 --> Security Class Initialized
DEBUG - 2019-07-03 16:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 16:41:11 --> Input Class Initialized
INFO - 2019-07-03 16:41:11 --> Language Class Initialized
INFO - 2019-07-03 16:41:11 --> Language Class Initialized
INFO - 2019-07-03 16:41:11 --> Config Class Initialized
INFO - 2019-07-03 16:41:11 --> Loader Class Initialized
DEBUG - 2019-07-03 16:41:11 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 16:41:11 --> Helper loaded: url_helper
INFO - 2019-07-03 16:41:11 --> Helper loaded: inflector_helper
INFO - 2019-07-03 16:41:11 --> Helper loaded: string_helper
INFO - 2019-07-03 16:41:11 --> Helper loaded: array_helper
INFO - 2019-07-03 16:41:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 16:41:11 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 16:41:11 --> Database Driver Class Initialized
INFO - 2019-07-03 16:41:11 --> Controller Class Initialized
INFO - 2019-07-03 22:41:11 --> Helper loaded: language_helper
INFO - 2019-07-03 22:41:11 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 22:41:11 --> Model Class Initialized
INFO - 2019-07-03 22:41:11 --> Model Class Initialized
INFO - 2019-07-03 22:41:11 --> Model Class Initialized
INFO - 2019-07-03 22:41:11 --> Model Class Initialized
INFO - 2019-07-03 22:41:11 --> Final output sent to browser
DEBUG - 2019-07-03 22:41:11 --> Total execution time: 0.3316
INFO - 2019-07-03 16:41:37 --> Config Class Initialized
INFO - 2019-07-03 16:41:37 --> Hooks Class Initialized
INFO - 2019-07-03 16:41:37 --> Config Class Initialized
INFO - 2019-07-03 16:41:37 --> Hooks Class Initialized
DEBUG - 2019-07-03 16:41:37 --> UTF-8 Support Enabled
INFO - 2019-07-03 16:41:37 --> Utf8 Class Initialized
DEBUG - 2019-07-03 16:41:37 --> UTF-8 Support Enabled
INFO - 2019-07-03 16:41:37 --> URI Class Initialized
INFO - 2019-07-03 16:41:37 --> Utf8 Class Initialized
INFO - 2019-07-03 16:41:37 --> URI Class Initialized
INFO - 2019-07-03 16:41:37 --> Router Class Initialized
INFO - 2019-07-03 16:41:37 --> Router Class Initialized
INFO - 2019-07-03 16:41:37 --> Output Class Initialized
INFO - 2019-07-03 16:41:37 --> Output Class Initialized
INFO - 2019-07-03 16:41:37 --> Security Class Initialized
INFO - 2019-07-03 16:41:37 --> Security Class Initialized
DEBUG - 2019-07-03 16:41:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-03 16:41:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 16:41:37 --> Input Class Initialized
INFO - 2019-07-03 16:41:37 --> Input Class Initialized
INFO - 2019-07-03 16:41:37 --> Language Class Initialized
INFO - 2019-07-03 16:41:37 --> Language Class Initialized
INFO - 2019-07-03 16:41:37 --> Language Class Initialized
INFO - 2019-07-03 16:41:37 --> Language Class Initialized
INFO - 2019-07-03 16:41:37 --> Config Class Initialized
INFO - 2019-07-03 16:41:37 --> Loader Class Initialized
INFO - 2019-07-03 16:41:37 --> Config Class Initialized
INFO - 2019-07-03 16:41:37 --> Loader Class Initialized
DEBUG - 2019-07-03 16:41:37 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-03 16:41:37 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 16:41:37 --> Helper loaded: url_helper
INFO - 2019-07-03 16:41:37 --> Helper loaded: url_helper
INFO - 2019-07-03 16:41:37 --> Helper loaded: inflector_helper
INFO - 2019-07-03 16:41:37 --> Helper loaded: inflector_helper
INFO - 2019-07-03 16:41:37 --> Helper loaded: string_helper
INFO - 2019-07-03 16:41:37 --> Helper loaded: string_helper
INFO - 2019-07-03 16:41:37 --> Helper loaded: array_helper
INFO - 2019-07-03 16:41:37 --> Helper loaded: array_helper
INFO - 2019-07-03 16:41:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 16:41:37 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 16:41:37 --> Database Driver Class Initialized
INFO - 2019-07-03 16:41:37 --> Controller Class Initialized
INFO - 2019-07-03 22:41:37 --> Helper loaded: language_helper
INFO - 2019-07-03 22:41:37 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 22:41:37 --> Model Class Initialized
INFO - 2019-07-03 22:41:37 --> Model Class Initialized
INFO - 2019-07-03 22:41:37 --> Model Class Initialized
INFO - 2019-07-03 22:41:37 --> Model Class Initialized
INFO - 2019-07-03 22:41:37 --> Model Class Initialized
INFO - 2019-07-03 22:41:37 --> Final output sent to browser
DEBUG - 2019-07-03 22:41:37 --> Total execution time: 0.4660
INFO - 2019-07-03 16:41:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 16:41:37 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 16:41:37 --> Database Driver Class Initialized
INFO - 2019-07-03 16:41:37 --> Controller Class Initialized
INFO - 2019-07-03 22:41:37 --> Helper loaded: language_helper
INFO - 2019-07-03 22:41:37 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 22:41:37 --> Model Class Initialized
INFO - 2019-07-03 22:41:37 --> Model Class Initialized
INFO - 2019-07-03 22:41:37 --> Model Class Initialized
INFO - 2019-07-03 22:41:37 --> Model Class Initialized
INFO - 2019-07-03 22:41:37 --> Final output sent to browser
DEBUG - 2019-07-03 22:41:37 --> Total execution time: 0.6139
INFO - 2019-07-03 16:41:38 --> Config Class Initialized
INFO - 2019-07-03 16:41:38 --> Hooks Class Initialized
DEBUG - 2019-07-03 16:41:38 --> UTF-8 Support Enabled
INFO - 2019-07-03 16:41:39 --> Utf8 Class Initialized
INFO - 2019-07-03 16:41:39 --> URI Class Initialized
INFO - 2019-07-03 16:41:39 --> Router Class Initialized
INFO - 2019-07-03 16:41:39 --> Output Class Initialized
INFO - 2019-07-03 16:41:39 --> Security Class Initialized
DEBUG - 2019-07-03 16:41:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 16:41:39 --> Input Class Initialized
INFO - 2019-07-03 16:41:39 --> Language Class Initialized
INFO - 2019-07-03 16:41:39 --> Language Class Initialized
INFO - 2019-07-03 16:41:39 --> Config Class Initialized
INFO - 2019-07-03 16:41:39 --> Loader Class Initialized
DEBUG - 2019-07-03 16:41:39 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 16:41:39 --> Helper loaded: url_helper
INFO - 2019-07-03 16:41:39 --> Helper loaded: inflector_helper
INFO - 2019-07-03 16:41:39 --> Helper loaded: string_helper
INFO - 2019-07-03 16:41:39 --> Helper loaded: array_helper
INFO - 2019-07-03 16:41:39 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 16:41:39 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 16:41:39 --> Database Driver Class Initialized
INFO - 2019-07-03 16:41:39 --> Controller Class Initialized
INFO - 2019-07-03 22:41:39 --> Helper loaded: language_helper
INFO - 2019-07-03 22:41:39 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 22:41:39 --> Model Class Initialized
INFO - 2019-07-03 22:41:39 --> Model Class Initialized
INFO - 2019-07-03 22:41:39 --> Model Class Initialized
INFO - 2019-07-03 22:41:39 --> Model Class Initialized
INFO - 2019-07-03 22:41:39 --> Final output sent to browser
DEBUG - 2019-07-03 22:41:39 --> Total execution time: 0.3321
INFO - 2019-07-03 16:43:32 --> Config Class Initialized
INFO - 2019-07-03 16:43:32 --> Hooks Class Initialized
INFO - 2019-07-03 16:43:32 --> Config Class Initialized
DEBUG - 2019-07-03 16:43:32 --> UTF-8 Support Enabled
INFO - 2019-07-03 16:43:32 --> Hooks Class Initialized
INFO - 2019-07-03 16:43:32 --> Utf8 Class Initialized
DEBUG - 2019-07-03 16:43:32 --> UTF-8 Support Enabled
INFO - 2019-07-03 16:43:32 --> URI Class Initialized
INFO - 2019-07-03 16:43:32 --> Utf8 Class Initialized
INFO - 2019-07-03 16:43:33 --> Router Class Initialized
INFO - 2019-07-03 16:43:33 --> URI Class Initialized
INFO - 2019-07-03 16:43:33 --> Output Class Initialized
INFO - 2019-07-03 16:43:33 --> Router Class Initialized
INFO - 2019-07-03 16:43:33 --> Output Class Initialized
INFO - 2019-07-03 16:43:33 --> Security Class Initialized
INFO - 2019-07-03 16:43:33 --> Security Class Initialized
DEBUG - 2019-07-03 16:43:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 16:43:33 --> Input Class Initialized
DEBUG - 2019-07-03 16:43:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 16:43:33 --> Language Class Initialized
INFO - 2019-07-03 16:43:33 --> Input Class Initialized
INFO - 2019-07-03 16:43:33 --> Language Class Initialized
INFO - 2019-07-03 16:43:33 --> Language Class Initialized
INFO - 2019-07-03 16:43:33 --> Language Class Initialized
INFO - 2019-07-03 16:43:33 --> Config Class Initialized
INFO - 2019-07-03 16:43:33 --> Config Class Initialized
INFO - 2019-07-03 16:43:33 --> Loader Class Initialized
INFO - 2019-07-03 16:43:33 --> Loader Class Initialized
DEBUG - 2019-07-03 16:43:33 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-03 16:43:33 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 16:43:33 --> Helper loaded: url_helper
INFO - 2019-07-03 16:43:33 --> Helper loaded: url_helper
INFO - 2019-07-03 16:43:33 --> Helper loaded: inflector_helper
INFO - 2019-07-03 16:43:33 --> Helper loaded: inflector_helper
INFO - 2019-07-03 16:43:33 --> Helper loaded: string_helper
INFO - 2019-07-03 16:43:33 --> Helper loaded: string_helper
INFO - 2019-07-03 16:43:33 --> Helper loaded: array_helper
INFO - 2019-07-03 16:43:33 --> Helper loaded: array_helper
INFO - 2019-07-03 16:43:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 16:43:33 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 16:43:33 --> Database Driver Class Initialized
INFO - 2019-07-03 16:43:33 --> Controller Class Initialized
INFO - 2019-07-03 22:43:33 --> Helper loaded: language_helper
INFO - 2019-07-03 22:43:33 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 22:43:33 --> Model Class Initialized
INFO - 2019-07-03 22:43:33 --> Model Class Initialized
INFO - 2019-07-03 22:43:33 --> Model Class Initialized
INFO - 2019-07-03 22:43:33 --> Model Class Initialized
INFO - 2019-07-03 22:43:33 --> Model Class Initialized
INFO - 2019-07-03 22:43:33 --> Final output sent to browser
DEBUG - 2019-07-03 22:43:33 --> Total execution time: 0.4814
INFO - 2019-07-03 16:43:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 16:43:33 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 16:43:33 --> Database Driver Class Initialized
INFO - 2019-07-03 16:43:33 --> Controller Class Initialized
INFO - 2019-07-03 22:43:33 --> Helper loaded: language_helper
INFO - 2019-07-03 22:43:33 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 22:43:33 --> Model Class Initialized
INFO - 2019-07-03 22:43:33 --> Model Class Initialized
INFO - 2019-07-03 22:43:33 --> Model Class Initialized
INFO - 2019-07-03 22:43:33 --> Model Class Initialized
INFO - 2019-07-03 22:43:33 --> Final output sent to browser
DEBUG - 2019-07-03 22:43:33 --> Total execution time: 0.6105
INFO - 2019-07-03 16:43:35 --> Config Class Initialized
INFO - 2019-07-03 16:43:35 --> Config Class Initialized
INFO - 2019-07-03 16:43:35 --> Hooks Class Initialized
INFO - 2019-07-03 16:43:36 --> Hooks Class Initialized
DEBUG - 2019-07-03 16:43:36 --> UTF-8 Support Enabled
DEBUG - 2019-07-03 16:43:36 --> UTF-8 Support Enabled
INFO - 2019-07-03 16:43:36 --> Utf8 Class Initialized
INFO - 2019-07-03 16:43:36 --> Utf8 Class Initialized
INFO - 2019-07-03 16:43:36 --> URI Class Initialized
INFO - 2019-07-03 16:43:36 --> URI Class Initialized
INFO - 2019-07-03 16:43:36 --> Router Class Initialized
INFO - 2019-07-03 16:43:36 --> Router Class Initialized
INFO - 2019-07-03 16:43:36 --> Output Class Initialized
INFO - 2019-07-03 16:43:36 --> Output Class Initialized
INFO - 2019-07-03 16:43:36 --> Security Class Initialized
INFO - 2019-07-03 16:43:36 --> Security Class Initialized
DEBUG - 2019-07-03 16:43:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-03 16:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 16:43:36 --> Input Class Initialized
INFO - 2019-07-03 16:43:36 --> Input Class Initialized
INFO - 2019-07-03 16:43:36 --> Language Class Initialized
INFO - 2019-07-03 16:43:36 --> Language Class Initialized
INFO - 2019-07-03 16:43:36 --> Language Class Initialized
INFO - 2019-07-03 16:43:36 --> Language Class Initialized
INFO - 2019-07-03 16:43:36 --> Config Class Initialized
INFO - 2019-07-03 16:43:36 --> Config Class Initialized
INFO - 2019-07-03 16:43:36 --> Loader Class Initialized
INFO - 2019-07-03 16:43:36 --> Loader Class Initialized
DEBUG - 2019-07-03 16:43:36 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-03 16:43:36 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 16:43:36 --> Helper loaded: url_helper
INFO - 2019-07-03 16:43:36 --> Helper loaded: url_helper
INFO - 2019-07-03 16:43:36 --> Helper loaded: inflector_helper
INFO - 2019-07-03 16:43:36 --> Helper loaded: inflector_helper
INFO - 2019-07-03 16:43:36 --> Helper loaded: string_helper
INFO - 2019-07-03 16:43:36 --> Helper loaded: string_helper
INFO - 2019-07-03 16:43:36 --> Helper loaded: array_helper
INFO - 2019-07-03 16:43:36 --> Helper loaded: array_helper
INFO - 2019-07-03 16:43:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 16:43:36 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 16:43:36 --> Database Driver Class Initialized
INFO - 2019-07-03 16:43:36 --> Controller Class Initialized
INFO - 2019-07-03 22:43:36 --> Helper loaded: language_helper
INFO - 2019-07-03 22:43:36 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 22:43:36 --> Model Class Initialized
INFO - 2019-07-03 22:43:36 --> Model Class Initialized
INFO - 2019-07-03 22:43:36 --> Model Class Initialized
INFO - 2019-07-03 22:43:36 --> Model Class Initialized
INFO - 2019-07-03 22:43:36 --> Model Class Initialized
INFO - 2019-07-03 22:43:36 --> Final output sent to browser
DEBUG - 2019-07-03 22:43:36 --> Total execution time: 0.4817
INFO - 2019-07-03 16:43:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 16:43:36 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 16:43:36 --> Database Driver Class Initialized
INFO - 2019-07-03 16:43:36 --> Controller Class Initialized
INFO - 2019-07-03 22:43:36 --> Helper loaded: language_helper
INFO - 2019-07-03 22:43:36 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 22:43:36 --> Model Class Initialized
INFO - 2019-07-03 22:43:36 --> Model Class Initialized
INFO - 2019-07-03 22:43:36 --> Model Class Initialized
INFO - 2019-07-03 22:43:36 --> Model Class Initialized
INFO - 2019-07-03 22:43:36 --> Final output sent to browser
DEBUG - 2019-07-03 22:43:36 --> Total execution time: 0.6094
INFO - 2019-07-03 16:43:41 --> Config Class Initialized
INFO - 2019-07-03 16:43:41 --> Hooks Class Initialized
DEBUG - 2019-07-03 16:43:41 --> UTF-8 Support Enabled
INFO - 2019-07-03 16:43:41 --> Utf8 Class Initialized
INFO - 2019-07-03 16:43:41 --> URI Class Initialized
INFO - 2019-07-03 16:43:41 --> Router Class Initialized
INFO - 2019-07-03 16:43:41 --> Output Class Initialized
INFO - 2019-07-03 16:43:41 --> Security Class Initialized
DEBUG - 2019-07-03 16:43:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 16:43:41 --> Input Class Initialized
INFO - 2019-07-03 16:43:41 --> Language Class Initialized
INFO - 2019-07-03 16:43:41 --> Language Class Initialized
INFO - 2019-07-03 16:43:41 --> Config Class Initialized
INFO - 2019-07-03 16:43:41 --> Loader Class Initialized
DEBUG - 2019-07-03 16:43:41 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 16:43:41 --> Helper loaded: url_helper
INFO - 2019-07-03 16:43:41 --> Helper loaded: inflector_helper
INFO - 2019-07-03 16:43:41 --> Helper loaded: string_helper
INFO - 2019-07-03 16:43:41 --> Helper loaded: array_helper
INFO - 2019-07-03 16:43:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 16:43:41 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 16:43:41 --> Database Driver Class Initialized
INFO - 2019-07-03 16:43:41 --> Controller Class Initialized
INFO - 2019-07-03 22:43:41 --> Helper loaded: language_helper
INFO - 2019-07-03 22:43:41 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 22:43:41 --> Model Class Initialized
INFO - 2019-07-03 22:43:41 --> Model Class Initialized
INFO - 2019-07-03 22:43:41 --> Model Class Initialized
INFO - 2019-07-03 22:43:41 --> Model Class Initialized
INFO - 2019-07-03 22:43:41 --> Final output sent to browser
DEBUG - 2019-07-03 22:43:41 --> Total execution time: 0.3365
INFO - 2019-07-03 16:43:44 --> Config Class Initialized
INFO - 2019-07-03 16:43:44 --> Hooks Class Initialized
DEBUG - 2019-07-03 16:43:44 --> UTF-8 Support Enabled
INFO - 2019-07-03 16:43:44 --> Utf8 Class Initialized
INFO - 2019-07-03 16:43:44 --> URI Class Initialized
INFO - 2019-07-03 16:43:44 --> Router Class Initialized
INFO - 2019-07-03 16:43:44 --> Output Class Initialized
INFO - 2019-07-03 16:43:44 --> Security Class Initialized
DEBUG - 2019-07-03 16:43:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 16:43:44 --> Input Class Initialized
INFO - 2019-07-03 16:43:44 --> Language Class Initialized
INFO - 2019-07-03 16:43:44 --> Language Class Initialized
INFO - 2019-07-03 16:43:44 --> Config Class Initialized
INFO - 2019-07-03 16:43:44 --> Loader Class Initialized
DEBUG - 2019-07-03 16:43:44 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 16:43:44 --> Helper loaded: url_helper
INFO - 2019-07-03 16:43:44 --> Helper loaded: inflector_helper
INFO - 2019-07-03 16:43:44 --> Helper loaded: string_helper
INFO - 2019-07-03 16:43:44 --> Helper loaded: array_helper
INFO - 2019-07-03 16:43:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 16:43:44 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 16:43:44 --> Database Driver Class Initialized
INFO - 2019-07-03 16:43:44 --> Controller Class Initialized
INFO - 2019-07-03 22:43:44 --> Helper loaded: language_helper
INFO - 2019-07-03 22:43:44 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 22:43:44 --> Model Class Initialized
INFO - 2019-07-03 22:43:44 --> Model Class Initialized
INFO - 2019-07-03 22:43:44 --> Model Class Initialized
INFO - 2019-07-03 22:43:44 --> Model Class Initialized
INFO - 2019-07-03 22:43:44 --> Model Class Initialized
INFO - 2019-07-03 22:43:44 --> Final output sent to browser
DEBUG - 2019-07-03 22:43:44 --> Total execution time: 0.3694
INFO - 2019-07-03 16:43:44 --> Config Class Initialized
INFO - 2019-07-03 16:43:45 --> Hooks Class Initialized
DEBUG - 2019-07-03 16:43:45 --> UTF-8 Support Enabled
INFO - 2019-07-03 16:43:45 --> Utf8 Class Initialized
INFO - 2019-07-03 16:43:45 --> URI Class Initialized
INFO - 2019-07-03 16:43:45 --> Router Class Initialized
INFO - 2019-07-03 16:43:45 --> Output Class Initialized
INFO - 2019-07-03 16:43:45 --> Security Class Initialized
DEBUG - 2019-07-03 16:43:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 16:43:45 --> Input Class Initialized
INFO - 2019-07-03 16:43:45 --> Language Class Initialized
INFO - 2019-07-03 16:43:45 --> Language Class Initialized
INFO - 2019-07-03 16:43:45 --> Config Class Initialized
INFO - 2019-07-03 16:43:45 --> Loader Class Initialized
DEBUG - 2019-07-03 16:43:45 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 16:43:45 --> Helper loaded: url_helper
INFO - 2019-07-03 16:43:45 --> Helper loaded: inflector_helper
INFO - 2019-07-03 16:43:45 --> Helper loaded: string_helper
INFO - 2019-07-03 16:43:45 --> Helper loaded: array_helper
INFO - 2019-07-03 16:43:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 16:43:45 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 16:43:45 --> Database Driver Class Initialized
INFO - 2019-07-03 16:43:45 --> Controller Class Initialized
INFO - 2019-07-03 22:43:45 --> Helper loaded: language_helper
INFO - 2019-07-03 22:43:45 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 22:43:45 --> Model Class Initialized
INFO - 2019-07-03 22:43:45 --> Model Class Initialized
INFO - 2019-07-03 22:43:45 --> Model Class Initialized
INFO - 2019-07-03 22:43:45 --> Model Class Initialized
INFO - 2019-07-03 22:43:45 --> Model Class Initialized
INFO - 2019-07-03 22:43:45 --> Final output sent to browser
DEBUG - 2019-07-03 22:43:45 --> Total execution time: 0.3678
INFO - 2019-07-03 16:44:35 --> Config Class Initialized
INFO - 2019-07-03 16:44:35 --> Hooks Class Initialized
DEBUG - 2019-07-03 16:44:35 --> UTF-8 Support Enabled
INFO - 2019-07-03 16:44:35 --> Utf8 Class Initialized
INFO - 2019-07-03 16:44:35 --> URI Class Initialized
INFO - 2019-07-03 16:44:35 --> Router Class Initialized
INFO - 2019-07-03 16:44:35 --> Output Class Initialized
INFO - 2019-07-03 16:44:35 --> Security Class Initialized
DEBUG - 2019-07-03 16:44:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 16:44:35 --> Input Class Initialized
INFO - 2019-07-03 16:44:35 --> Language Class Initialized
INFO - 2019-07-03 16:44:35 --> Language Class Initialized
INFO - 2019-07-03 16:44:35 --> Config Class Initialized
INFO - 2019-07-03 16:44:35 --> Loader Class Initialized
DEBUG - 2019-07-03 16:44:35 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 16:44:35 --> Helper loaded: url_helper
INFO - 2019-07-03 16:44:35 --> Helper loaded: inflector_helper
INFO - 2019-07-03 16:44:35 --> Helper loaded: string_helper
INFO - 2019-07-03 16:44:35 --> Helper loaded: array_helper
INFO - 2019-07-03 16:44:35 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 16:44:35 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 16:44:35 --> Database Driver Class Initialized
INFO - 2019-07-03 16:44:35 --> Controller Class Initialized
INFO - 2019-07-03 22:44:35 --> Helper loaded: language_helper
INFO - 2019-07-03 22:44:35 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 22:44:36 --> Model Class Initialized
INFO - 2019-07-03 22:44:36 --> Model Class Initialized
INFO - 2019-07-03 22:44:36 --> Model Class Initialized
INFO - 2019-07-03 22:44:36 --> Model Class Initialized
INFO - 2019-07-03 22:44:36 --> Model Class Initialized
INFO - 2019-07-03 22:44:36 --> Final output sent to browser
DEBUG - 2019-07-03 22:44:36 --> Total execution time: 0.3797
INFO - 2019-07-03 16:44:36 --> Config Class Initialized
INFO - 2019-07-03 16:44:36 --> Hooks Class Initialized
DEBUG - 2019-07-03 16:44:36 --> UTF-8 Support Enabled
INFO - 2019-07-03 16:44:36 --> Utf8 Class Initialized
INFO - 2019-07-03 16:44:36 --> URI Class Initialized
INFO - 2019-07-03 16:44:36 --> Router Class Initialized
INFO - 2019-07-03 16:44:36 --> Output Class Initialized
INFO - 2019-07-03 16:44:36 --> Security Class Initialized
DEBUG - 2019-07-03 16:44:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 16:44:36 --> Input Class Initialized
INFO - 2019-07-03 16:44:36 --> Language Class Initialized
INFO - 2019-07-03 16:44:36 --> Language Class Initialized
INFO - 2019-07-03 16:44:36 --> Config Class Initialized
INFO - 2019-07-03 16:44:36 --> Loader Class Initialized
DEBUG - 2019-07-03 16:44:36 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 16:44:36 --> Helper loaded: url_helper
INFO - 2019-07-03 16:44:36 --> Helper loaded: inflector_helper
INFO - 2019-07-03 16:44:36 --> Helper loaded: string_helper
INFO - 2019-07-03 16:44:36 --> Helper loaded: array_helper
INFO - 2019-07-03 16:44:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 16:44:36 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 16:44:36 --> Database Driver Class Initialized
INFO - 2019-07-03 16:44:36 --> Controller Class Initialized
INFO - 2019-07-03 22:44:36 --> Helper loaded: language_helper
INFO - 2019-07-03 22:44:36 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 22:44:36 --> Model Class Initialized
INFO - 2019-07-03 22:44:36 --> Model Class Initialized
INFO - 2019-07-03 22:44:36 --> Model Class Initialized
INFO - 2019-07-03 22:44:36 --> Model Class Initialized
INFO - 2019-07-03 22:44:36 --> Model Class Initialized
INFO - 2019-07-03 22:44:36 --> Final output sent to browser
DEBUG - 2019-07-03 22:44:36 --> Total execution time: 0.3576
INFO - 2019-07-03 16:44:39 --> Config Class Initialized
INFO - 2019-07-03 16:44:39 --> Config Class Initialized
INFO - 2019-07-03 16:44:39 --> Hooks Class Initialized
INFO - 2019-07-03 16:44:39 --> Hooks Class Initialized
DEBUG - 2019-07-03 16:44:39 --> UTF-8 Support Enabled
DEBUG - 2019-07-03 16:44:39 --> UTF-8 Support Enabled
INFO - 2019-07-03 16:44:39 --> Utf8 Class Initialized
INFO - 2019-07-03 16:44:39 --> Utf8 Class Initialized
INFO - 2019-07-03 16:44:39 --> URI Class Initialized
INFO - 2019-07-03 16:44:39 --> URI Class Initialized
INFO - 2019-07-03 16:44:39 --> Router Class Initialized
INFO - 2019-07-03 16:44:39 --> Router Class Initialized
INFO - 2019-07-03 16:44:39 --> Output Class Initialized
INFO - 2019-07-03 16:44:39 --> Output Class Initialized
INFO - 2019-07-03 16:44:39 --> Security Class Initialized
INFO - 2019-07-03 16:44:39 --> Security Class Initialized
DEBUG - 2019-07-03 16:44:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-03 16:44:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 16:44:39 --> Input Class Initialized
INFO - 2019-07-03 16:44:39 --> Input Class Initialized
INFO - 2019-07-03 16:44:39 --> Language Class Initialized
INFO - 2019-07-03 16:44:39 --> Language Class Initialized
INFO - 2019-07-03 16:44:39 --> Language Class Initialized
INFO - 2019-07-03 16:44:39 --> Language Class Initialized
INFO - 2019-07-03 16:44:39 --> Config Class Initialized
INFO - 2019-07-03 16:44:39 --> Config Class Initialized
INFO - 2019-07-03 16:44:39 --> Loader Class Initialized
INFO - 2019-07-03 16:44:39 --> Loader Class Initialized
DEBUG - 2019-07-03 16:44:39 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-03 16:44:39 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 16:44:39 --> Helper loaded: url_helper
INFO - 2019-07-03 16:44:39 --> Helper loaded: url_helper
INFO - 2019-07-03 16:44:39 --> Helper loaded: inflector_helper
INFO - 2019-07-03 16:44:39 --> Helper loaded: inflector_helper
INFO - 2019-07-03 16:44:39 --> Helper loaded: string_helper
INFO - 2019-07-03 16:44:39 --> Helper loaded: string_helper
INFO - 2019-07-03 16:44:39 --> Helper loaded: array_helper
INFO - 2019-07-03 16:44:39 --> Helper loaded: array_helper
INFO - 2019-07-03 16:44:39 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 16:44:39 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 16:44:39 --> Database Driver Class Initialized
INFO - 2019-07-03 16:44:39 --> Controller Class Initialized
INFO - 2019-07-03 22:44:39 --> Helper loaded: language_helper
INFO - 2019-07-03 22:44:39 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 22:44:39 --> Model Class Initialized
INFO - 2019-07-03 22:44:39 --> Model Class Initialized
INFO - 2019-07-03 22:44:39 --> Model Class Initialized
INFO - 2019-07-03 22:44:39 --> Model Class Initialized
INFO - 2019-07-03 22:44:39 --> Model Class Initialized
INFO - 2019-07-03 22:44:39 --> Final output sent to browser
DEBUG - 2019-07-03 22:44:39 --> Total execution time: 0.5104
INFO - 2019-07-03 16:44:39 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 16:44:39 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 16:44:39 --> Database Driver Class Initialized
INFO - 2019-07-03 16:44:39 --> Controller Class Initialized
INFO - 2019-07-03 22:44:39 --> Helper loaded: language_helper
INFO - 2019-07-03 22:44:39 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 22:44:39 --> Model Class Initialized
INFO - 2019-07-03 22:44:39 --> Model Class Initialized
INFO - 2019-07-03 22:44:39 --> Model Class Initialized
INFO - 2019-07-03 22:44:39 --> Model Class Initialized
INFO - 2019-07-03 22:44:39 --> Final output sent to browser
DEBUG - 2019-07-03 22:44:39 --> Total execution time: 0.6528
INFO - 2019-07-03 16:44:40 --> Config Class Initialized
INFO - 2019-07-03 16:44:40 --> Hooks Class Initialized
DEBUG - 2019-07-03 16:44:40 --> UTF-8 Support Enabled
INFO - 2019-07-03 16:44:40 --> Utf8 Class Initialized
INFO - 2019-07-03 16:44:40 --> URI Class Initialized
INFO - 2019-07-03 16:44:40 --> Router Class Initialized
INFO - 2019-07-03 16:44:40 --> Output Class Initialized
INFO - 2019-07-03 16:44:40 --> Security Class Initialized
DEBUG - 2019-07-03 16:44:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 16:44:40 --> Input Class Initialized
INFO - 2019-07-03 16:44:40 --> Language Class Initialized
INFO - 2019-07-03 16:44:40 --> Language Class Initialized
INFO - 2019-07-03 16:44:40 --> Config Class Initialized
INFO - 2019-07-03 16:44:40 --> Loader Class Initialized
DEBUG - 2019-07-03 16:44:40 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 16:44:40 --> Helper loaded: url_helper
INFO - 2019-07-03 16:44:40 --> Helper loaded: inflector_helper
INFO - 2019-07-03 16:44:40 --> Helper loaded: string_helper
INFO - 2019-07-03 16:44:40 --> Helper loaded: array_helper
INFO - 2019-07-03 16:44:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 16:44:40 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 16:44:40 --> Database Driver Class Initialized
INFO - 2019-07-03 16:44:40 --> Controller Class Initialized
INFO - 2019-07-03 22:44:40 --> Helper loaded: language_helper
INFO - 2019-07-03 22:44:40 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 22:44:40 --> Model Class Initialized
INFO - 2019-07-03 22:44:40 --> Model Class Initialized
INFO - 2019-07-03 22:44:40 --> Model Class Initialized
INFO - 2019-07-03 22:44:40 --> Model Class Initialized
INFO - 2019-07-03 22:44:40 --> Model Class Initialized
INFO - 2019-07-03 22:44:40 --> Final output sent to browser
DEBUG - 2019-07-03 22:44:40 --> Total execution time: 0.3739
INFO - 2019-07-03 16:44:40 --> Config Class Initialized
INFO - 2019-07-03 16:44:40 --> Hooks Class Initialized
DEBUG - 2019-07-03 16:44:40 --> UTF-8 Support Enabled
INFO - 2019-07-03 16:44:40 --> Utf8 Class Initialized
INFO - 2019-07-03 16:44:40 --> URI Class Initialized
INFO - 2019-07-03 16:44:40 --> Router Class Initialized
INFO - 2019-07-03 16:44:40 --> Output Class Initialized
INFO - 2019-07-03 16:44:40 --> Security Class Initialized
DEBUG - 2019-07-03 16:44:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 16:44:40 --> Input Class Initialized
INFO - 2019-07-03 16:44:40 --> Language Class Initialized
INFO - 2019-07-03 16:44:40 --> Language Class Initialized
INFO - 2019-07-03 16:44:40 --> Config Class Initialized
INFO - 2019-07-03 16:44:40 --> Loader Class Initialized
DEBUG - 2019-07-03 16:44:40 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 16:44:40 --> Helper loaded: url_helper
INFO - 2019-07-03 16:44:40 --> Helper loaded: inflector_helper
INFO - 2019-07-03 16:44:40 --> Helper loaded: string_helper
INFO - 2019-07-03 16:44:40 --> Helper loaded: array_helper
INFO - 2019-07-03 16:44:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 16:44:40 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 16:44:40 --> Database Driver Class Initialized
INFO - 2019-07-03 16:44:40 --> Controller Class Initialized
INFO - 2019-07-03 22:44:41 --> Helper loaded: language_helper
INFO - 2019-07-03 22:44:41 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 22:44:41 --> Model Class Initialized
INFO - 2019-07-03 22:44:41 --> Model Class Initialized
INFO - 2019-07-03 22:44:41 --> Model Class Initialized
INFO - 2019-07-03 22:44:41 --> Model Class Initialized
INFO - 2019-07-03 22:44:41 --> Final output sent to browser
DEBUG - 2019-07-03 22:44:41 --> Total execution time: 0.3552
INFO - 2019-07-03 16:45:46 --> Config Class Initialized
INFO - 2019-07-03 16:45:46 --> Hooks Class Initialized
DEBUG - 2019-07-03 16:45:46 --> UTF-8 Support Enabled
INFO - 2019-07-03 16:45:46 --> Utf8 Class Initialized
INFO - 2019-07-03 16:45:46 --> URI Class Initialized
INFO - 2019-07-03 16:45:46 --> Router Class Initialized
INFO - 2019-07-03 16:45:46 --> Output Class Initialized
INFO - 2019-07-03 16:45:46 --> Security Class Initialized
DEBUG - 2019-07-03 16:45:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 16:45:46 --> Input Class Initialized
INFO - 2019-07-03 16:45:46 --> Language Class Initialized
INFO - 2019-07-03 16:45:46 --> Language Class Initialized
INFO - 2019-07-03 16:45:46 --> Config Class Initialized
INFO - 2019-07-03 16:45:46 --> Loader Class Initialized
DEBUG - 2019-07-03 16:45:46 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 16:45:46 --> Helper loaded: url_helper
INFO - 2019-07-03 16:45:46 --> Helper loaded: inflector_helper
INFO - 2019-07-03 16:45:46 --> Helper loaded: string_helper
INFO - 2019-07-03 16:45:46 --> Helper loaded: array_helper
INFO - 2019-07-03 16:45:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 16:45:46 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 16:45:46 --> Database Driver Class Initialized
INFO - 2019-07-03 16:45:46 --> Controller Class Initialized
INFO - 2019-07-03 22:45:46 --> Helper loaded: language_helper
INFO - 2019-07-03 22:45:46 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 22:45:46 --> Model Class Initialized
INFO - 2019-07-03 22:45:46 --> Model Class Initialized
INFO - 2019-07-03 22:45:46 --> Model Class Initialized
INFO - 2019-07-03 22:45:46 --> Model Class Initialized
INFO - 2019-07-03 22:45:46 --> Model Class Initialized
INFO - 2019-07-03 22:45:46 --> Final output sent to browser
DEBUG - 2019-07-03 22:45:46 --> Total execution time: 0.3561
INFO - 2019-07-03 16:45:49 --> Config Class Initialized
INFO - 2019-07-03 16:45:49 --> Hooks Class Initialized
DEBUG - 2019-07-03 16:45:49 --> UTF-8 Support Enabled
INFO - 2019-07-03 16:45:49 --> Utf8 Class Initialized
INFO - 2019-07-03 16:45:49 --> URI Class Initialized
INFO - 2019-07-03 16:45:49 --> Router Class Initialized
INFO - 2019-07-03 16:45:49 --> Output Class Initialized
INFO - 2019-07-03 16:45:49 --> Security Class Initialized
DEBUG - 2019-07-03 16:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 16:45:49 --> Input Class Initialized
INFO - 2019-07-03 16:45:49 --> Language Class Initialized
INFO - 2019-07-03 16:45:49 --> Language Class Initialized
INFO - 2019-07-03 16:45:49 --> Config Class Initialized
INFO - 2019-07-03 16:45:49 --> Loader Class Initialized
DEBUG - 2019-07-03 16:45:49 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 16:45:49 --> Helper loaded: url_helper
INFO - 2019-07-03 16:45:49 --> Helper loaded: inflector_helper
INFO - 2019-07-03 16:45:49 --> Helper loaded: string_helper
INFO - 2019-07-03 16:45:49 --> Helper loaded: array_helper
INFO - 2019-07-03 16:45:49 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 16:45:49 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 16:45:49 --> Database Driver Class Initialized
INFO - 2019-07-03 16:45:49 --> Controller Class Initialized
INFO - 2019-07-03 22:45:49 --> Helper loaded: language_helper
INFO - 2019-07-03 22:45:49 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 22:45:49 --> Model Class Initialized
INFO - 2019-07-03 22:45:49 --> Model Class Initialized
INFO - 2019-07-03 22:45:49 --> Model Class Initialized
INFO - 2019-07-03 22:45:49 --> Model Class Initialized
INFO - 2019-07-03 22:45:49 --> Model Class Initialized
INFO - 2019-07-03 22:45:49 --> Final output sent to browser
DEBUG - 2019-07-03 22:45:49 --> Total execution time: 0.3504
INFO - 2019-07-03 16:46:22 --> Config Class Initialized
INFO - 2019-07-03 16:46:22 --> Hooks Class Initialized
DEBUG - 2019-07-03 16:46:22 --> UTF-8 Support Enabled
INFO - 2019-07-03 16:46:22 --> Utf8 Class Initialized
INFO - 2019-07-03 16:46:22 --> URI Class Initialized
INFO - 2019-07-03 16:46:22 --> Router Class Initialized
INFO - 2019-07-03 16:46:22 --> Output Class Initialized
INFO - 2019-07-03 16:46:22 --> Security Class Initialized
DEBUG - 2019-07-03 16:46:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 16:46:22 --> Input Class Initialized
INFO - 2019-07-03 16:46:22 --> Language Class Initialized
INFO - 2019-07-03 16:46:22 --> Language Class Initialized
INFO - 2019-07-03 16:46:22 --> Config Class Initialized
INFO - 2019-07-03 16:46:22 --> Loader Class Initialized
DEBUG - 2019-07-03 16:46:22 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 16:46:22 --> Helper loaded: url_helper
INFO - 2019-07-03 16:46:22 --> Helper loaded: inflector_helper
INFO - 2019-07-03 16:46:22 --> Helper loaded: string_helper
INFO - 2019-07-03 16:46:22 --> Helper loaded: array_helper
INFO - 2019-07-03 16:46:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 16:46:22 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 16:46:22 --> Database Driver Class Initialized
INFO - 2019-07-03 16:46:22 --> Controller Class Initialized
INFO - 2019-07-03 22:46:22 --> Helper loaded: language_helper
INFO - 2019-07-03 22:46:22 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 22:46:22 --> Model Class Initialized
INFO - 2019-07-03 22:46:22 --> Model Class Initialized
INFO - 2019-07-03 22:46:22 --> Model Class Initialized
INFO - 2019-07-03 22:46:22 --> Model Class Initialized
INFO - 2019-07-03 22:46:22 --> Model Class Initialized
INFO - 2019-07-03 22:46:22 --> Final output sent to browser
DEBUG - 2019-07-03 22:46:22 --> Total execution time: 0.3847
INFO - 2019-07-03 16:47:10 --> Config Class Initialized
INFO - 2019-07-03 16:47:10 --> Hooks Class Initialized
DEBUG - 2019-07-03 16:47:10 --> UTF-8 Support Enabled
INFO - 2019-07-03 16:47:10 --> Utf8 Class Initialized
INFO - 2019-07-03 16:47:10 --> URI Class Initialized
INFO - 2019-07-03 16:47:10 --> Router Class Initialized
INFO - 2019-07-03 16:47:10 --> Output Class Initialized
INFO - 2019-07-03 16:47:10 --> Security Class Initialized
DEBUG - 2019-07-03 16:47:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 16:47:10 --> Input Class Initialized
INFO - 2019-07-03 16:47:10 --> Language Class Initialized
INFO - 2019-07-03 16:47:10 --> Language Class Initialized
INFO - 2019-07-03 16:47:10 --> Config Class Initialized
INFO - 2019-07-03 16:47:10 --> Loader Class Initialized
DEBUG - 2019-07-03 16:47:10 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 16:47:10 --> Helper loaded: url_helper
INFO - 2019-07-03 16:47:10 --> Helper loaded: inflector_helper
INFO - 2019-07-03 16:47:11 --> Helper loaded: string_helper
INFO - 2019-07-03 16:47:11 --> Helper loaded: array_helper
INFO - 2019-07-03 16:47:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 16:47:11 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 16:47:11 --> Database Driver Class Initialized
INFO - 2019-07-03 16:47:11 --> Controller Class Initialized
INFO - 2019-07-03 22:47:11 --> Helper loaded: language_helper
INFO - 2019-07-03 22:47:11 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 22:47:11 --> Model Class Initialized
INFO - 2019-07-03 22:47:11 --> Model Class Initialized
INFO - 2019-07-03 22:47:11 --> Model Class Initialized
INFO - 2019-07-03 22:47:11 --> Model Class Initialized
INFO - 2019-07-03 22:47:11 --> Model Class Initialized
INFO - 2019-07-03 22:47:11 --> Final output sent to browser
DEBUG - 2019-07-03 22:47:11 --> Total execution time: 0.3767
INFO - 2019-07-03 16:47:45 --> Config Class Initialized
INFO - 2019-07-03 16:47:45 --> Hooks Class Initialized
DEBUG - 2019-07-03 16:47:45 --> UTF-8 Support Enabled
INFO - 2019-07-03 16:47:45 --> Utf8 Class Initialized
INFO - 2019-07-03 16:47:45 --> URI Class Initialized
INFO - 2019-07-03 16:47:45 --> Router Class Initialized
INFO - 2019-07-03 16:47:45 --> Output Class Initialized
INFO - 2019-07-03 16:47:45 --> Security Class Initialized
DEBUG - 2019-07-03 16:47:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 16:47:45 --> Input Class Initialized
INFO - 2019-07-03 16:47:45 --> Language Class Initialized
INFO - 2019-07-03 16:47:45 --> Language Class Initialized
INFO - 2019-07-03 16:47:45 --> Config Class Initialized
INFO - 2019-07-03 16:47:45 --> Loader Class Initialized
DEBUG - 2019-07-03 16:47:45 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 16:47:45 --> Helper loaded: url_helper
INFO - 2019-07-03 16:47:45 --> Helper loaded: inflector_helper
INFO - 2019-07-03 16:47:45 --> Helper loaded: string_helper
INFO - 2019-07-03 16:47:45 --> Helper loaded: array_helper
INFO - 2019-07-03 16:47:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 16:47:45 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 16:47:45 --> Database Driver Class Initialized
INFO - 2019-07-03 16:47:45 --> Controller Class Initialized
INFO - 2019-07-03 22:47:45 --> Helper loaded: language_helper
INFO - 2019-07-03 22:47:45 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 22:47:45 --> Model Class Initialized
INFO - 2019-07-03 22:47:45 --> Model Class Initialized
INFO - 2019-07-03 22:47:45 --> Model Class Initialized
INFO - 2019-07-03 22:47:45 --> Model Class Initialized
INFO - 2019-07-03 22:47:45 --> Model Class Initialized
INFO - 2019-07-03 22:47:45 --> Final output sent to browser
DEBUG - 2019-07-03 22:47:45 --> Total execution time: 0.3592
INFO - 2019-07-03 16:47:45 --> Config Class Initialized
INFO - 2019-07-03 16:47:45 --> Hooks Class Initialized
DEBUG - 2019-07-03 16:47:45 --> UTF-8 Support Enabled
INFO - 2019-07-03 16:47:45 --> Utf8 Class Initialized
INFO - 2019-07-03 16:47:45 --> URI Class Initialized
INFO - 2019-07-03 16:47:45 --> Router Class Initialized
INFO - 2019-07-03 16:47:45 --> Output Class Initialized
INFO - 2019-07-03 16:47:45 --> Security Class Initialized
DEBUG - 2019-07-03 16:47:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 16:47:45 --> Input Class Initialized
INFO - 2019-07-03 16:47:45 --> Language Class Initialized
INFO - 2019-07-03 16:47:45 --> Language Class Initialized
INFO - 2019-07-03 16:47:45 --> Config Class Initialized
INFO - 2019-07-03 16:47:45 --> Loader Class Initialized
DEBUG - 2019-07-03 16:47:45 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 16:47:45 --> Helper loaded: url_helper
INFO - 2019-07-03 16:47:45 --> Helper loaded: inflector_helper
INFO - 2019-07-03 16:47:45 --> Helper loaded: string_helper
INFO - 2019-07-03 16:47:45 --> Helper loaded: array_helper
INFO - 2019-07-03 16:47:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 16:47:45 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 16:47:45 --> Database Driver Class Initialized
INFO - 2019-07-03 16:47:45 --> Controller Class Initialized
INFO - 2019-07-03 22:47:45 --> Helper loaded: language_helper
INFO - 2019-07-03 22:47:45 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 22:47:45 --> Model Class Initialized
INFO - 2019-07-03 22:47:45 --> Model Class Initialized
INFO - 2019-07-03 22:47:45 --> Model Class Initialized
INFO - 2019-07-03 22:47:46 --> Model Class Initialized
INFO - 2019-07-03 22:47:46 --> Helper loaded: form_helper
INFO - 2019-07-03 22:47:46 --> Form Validation Class Initialized
DEBUG - 2019-07-03 22:47:46 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-03 22:47:46 --> Model Class Initialized
INFO - 2019-07-03 22:47:46 --> Model Class Initialized
ERROR - 2019-07-03 22:47:46 --> Severity: Error --> Call to undefined method Order_model::fetch_ordorder_statusers() C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 46
INFO - 2019-07-03 16:47:48 --> Config Class Initialized
INFO - 2019-07-03 16:47:48 --> Hooks Class Initialized
DEBUG - 2019-07-03 16:47:48 --> UTF-8 Support Enabled
INFO - 2019-07-03 16:47:48 --> Utf8 Class Initialized
INFO - 2019-07-03 16:47:48 --> URI Class Initialized
INFO - 2019-07-03 16:47:48 --> Router Class Initialized
INFO - 2019-07-03 16:47:48 --> Output Class Initialized
INFO - 2019-07-03 16:47:48 --> Security Class Initialized
DEBUG - 2019-07-03 16:47:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 16:47:48 --> Input Class Initialized
INFO - 2019-07-03 16:47:48 --> Language Class Initialized
INFO - 2019-07-03 16:47:48 --> Language Class Initialized
INFO - 2019-07-03 16:47:48 --> Config Class Initialized
INFO - 2019-07-03 16:47:48 --> Loader Class Initialized
DEBUG - 2019-07-03 16:47:48 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 16:47:48 --> Helper loaded: url_helper
INFO - 2019-07-03 16:47:48 --> Helper loaded: inflector_helper
INFO - 2019-07-03 16:47:48 --> Helper loaded: string_helper
INFO - 2019-07-03 16:47:48 --> Helper loaded: array_helper
INFO - 2019-07-03 16:47:48 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 16:47:48 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 16:47:48 --> Database Driver Class Initialized
INFO - 2019-07-03 16:47:48 --> Controller Class Initialized
INFO - 2019-07-03 22:47:48 --> Helper loaded: language_helper
INFO - 2019-07-03 22:47:48 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 22:47:48 --> Model Class Initialized
INFO - 2019-07-03 22:47:48 --> Model Class Initialized
INFO - 2019-07-03 22:47:48 --> Model Class Initialized
INFO - 2019-07-03 22:47:48 --> Model Class Initialized
INFO - 2019-07-03 22:47:48 --> Model Class Initialized
INFO - 2019-07-03 22:47:48 --> Final output sent to browser
DEBUG - 2019-07-03 22:47:48 --> Total execution time: 0.3595
INFO - 2019-07-03 16:47:48 --> Config Class Initialized
INFO - 2019-07-03 16:47:48 --> Hooks Class Initialized
DEBUG - 2019-07-03 16:47:48 --> UTF-8 Support Enabled
INFO - 2019-07-03 16:47:48 --> Utf8 Class Initialized
INFO - 2019-07-03 16:47:48 --> URI Class Initialized
INFO - 2019-07-03 16:47:48 --> Router Class Initialized
INFO - 2019-07-03 16:47:48 --> Output Class Initialized
INFO - 2019-07-03 16:47:48 --> Security Class Initialized
DEBUG - 2019-07-03 16:47:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 16:47:48 --> Input Class Initialized
INFO - 2019-07-03 16:47:48 --> Language Class Initialized
INFO - 2019-07-03 16:47:48 --> Language Class Initialized
INFO - 2019-07-03 16:47:48 --> Config Class Initialized
INFO - 2019-07-03 16:47:48 --> Loader Class Initialized
DEBUG - 2019-07-03 16:47:48 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 16:47:48 --> Helper loaded: url_helper
INFO - 2019-07-03 16:47:48 --> Helper loaded: inflector_helper
INFO - 2019-07-03 16:47:48 --> Helper loaded: string_helper
INFO - 2019-07-03 16:47:49 --> Helper loaded: array_helper
INFO - 2019-07-03 16:47:49 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 16:47:49 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 16:47:49 --> Database Driver Class Initialized
INFO - 2019-07-03 16:47:49 --> Controller Class Initialized
INFO - 2019-07-03 22:47:49 --> Helper loaded: language_helper
INFO - 2019-07-03 22:47:49 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 22:47:49 --> Model Class Initialized
INFO - 2019-07-03 22:47:49 --> Model Class Initialized
INFO - 2019-07-03 22:47:49 --> Model Class Initialized
INFO - 2019-07-03 22:47:49 --> Model Class Initialized
INFO - 2019-07-03 22:47:49 --> Helper loaded: form_helper
INFO - 2019-07-03 22:47:49 --> Form Validation Class Initialized
DEBUG - 2019-07-03 22:47:49 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-03 22:47:49 --> Model Class Initialized
INFO - 2019-07-03 22:47:49 --> Model Class Initialized
ERROR - 2019-07-03 22:47:49 --> Severity: Error --> Call to undefined method Order_model::fetch_ordorder_statusers() C:\xampp\htdocs\crapi_admin\application\modules\api_v1\controllers\Orders.php 46
INFO - 2019-07-03 16:48:26 --> Config Class Initialized
INFO - 2019-07-03 16:48:26 --> Hooks Class Initialized
DEBUG - 2019-07-03 16:48:26 --> UTF-8 Support Enabled
INFO - 2019-07-03 16:48:26 --> Utf8 Class Initialized
INFO - 2019-07-03 16:48:26 --> URI Class Initialized
INFO - 2019-07-03 16:48:27 --> Router Class Initialized
INFO - 2019-07-03 16:48:27 --> Output Class Initialized
INFO - 2019-07-03 16:48:27 --> Security Class Initialized
DEBUG - 2019-07-03 16:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 16:48:27 --> Input Class Initialized
INFO - 2019-07-03 16:48:27 --> Language Class Initialized
INFO - 2019-07-03 16:48:27 --> Language Class Initialized
INFO - 2019-07-03 16:48:27 --> Config Class Initialized
INFO - 2019-07-03 16:48:27 --> Loader Class Initialized
DEBUG - 2019-07-03 16:48:27 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 16:48:27 --> Helper loaded: url_helper
INFO - 2019-07-03 16:48:27 --> Helper loaded: inflector_helper
INFO - 2019-07-03 16:48:27 --> Helper loaded: string_helper
INFO - 2019-07-03 16:48:27 --> Helper loaded: array_helper
INFO - 2019-07-03 16:48:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 16:48:27 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 16:48:27 --> Database Driver Class Initialized
INFO - 2019-07-03 16:48:27 --> Controller Class Initialized
INFO - 2019-07-03 22:48:27 --> Helper loaded: language_helper
INFO - 2019-07-03 22:48:27 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 22:48:27 --> Model Class Initialized
INFO - 2019-07-03 22:48:27 --> Model Class Initialized
INFO - 2019-07-03 22:48:27 --> Model Class Initialized
INFO - 2019-07-03 22:48:27 --> Model Class Initialized
INFO - 2019-07-03 22:48:27 --> Model Class Initialized
INFO - 2019-07-03 22:48:27 --> Final output sent to browser
DEBUG - 2019-07-03 22:48:27 --> Total execution time: 0.4385
INFO - 2019-07-03 16:48:27 --> Config Class Initialized
INFO - 2019-07-03 16:48:27 --> Hooks Class Initialized
DEBUG - 2019-07-03 16:48:27 --> UTF-8 Support Enabled
INFO - 2019-07-03 16:48:27 --> Utf8 Class Initialized
INFO - 2019-07-03 16:48:27 --> URI Class Initialized
INFO - 2019-07-03 16:48:27 --> Router Class Initialized
INFO - 2019-07-03 16:48:27 --> Output Class Initialized
INFO - 2019-07-03 16:48:27 --> Security Class Initialized
DEBUG - 2019-07-03 16:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 16:48:27 --> Input Class Initialized
INFO - 2019-07-03 16:48:27 --> Language Class Initialized
INFO - 2019-07-03 16:48:27 --> Language Class Initialized
INFO - 2019-07-03 16:48:27 --> Config Class Initialized
INFO - 2019-07-03 16:48:27 --> Loader Class Initialized
DEBUG - 2019-07-03 16:48:27 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 16:48:27 --> Helper loaded: url_helper
INFO - 2019-07-03 16:48:27 --> Helper loaded: inflector_helper
INFO - 2019-07-03 16:48:27 --> Helper loaded: string_helper
INFO - 2019-07-03 16:48:27 --> Helper loaded: array_helper
INFO - 2019-07-03 16:48:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 16:48:27 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 16:48:27 --> Database Driver Class Initialized
INFO - 2019-07-03 16:48:27 --> Controller Class Initialized
INFO - 2019-07-03 22:48:27 --> Helper loaded: language_helper
INFO - 2019-07-03 22:48:27 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 22:48:27 --> Model Class Initialized
INFO - 2019-07-03 22:48:27 --> Model Class Initialized
INFO - 2019-07-03 22:48:27 --> Model Class Initialized
INFO - 2019-07-03 22:48:27 --> Model Class Initialized
INFO - 2019-07-03 22:48:27 --> Helper loaded: form_helper
INFO - 2019-07-03 22:48:27 --> Form Validation Class Initialized
DEBUG - 2019-07-03 22:48:27 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-03 22:48:27 --> Model Class Initialized
INFO - 2019-07-03 22:48:27 --> Model Class Initialized
INFO - 2019-07-03 22:48:27 --> Final output sent to browser
DEBUG - 2019-07-03 22:48:27 --> Total execution time: 0.4274
INFO - 2019-07-03 16:51:03 --> Config Class Initialized
INFO - 2019-07-03 16:51:03 --> Hooks Class Initialized
DEBUG - 2019-07-03 16:51:03 --> UTF-8 Support Enabled
INFO - 2019-07-03 16:51:03 --> Utf8 Class Initialized
INFO - 2019-07-03 16:51:03 --> URI Class Initialized
INFO - 2019-07-03 16:51:03 --> Router Class Initialized
INFO - 2019-07-03 16:51:03 --> Output Class Initialized
INFO - 2019-07-03 16:51:03 --> Security Class Initialized
DEBUG - 2019-07-03 16:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 16:51:03 --> Input Class Initialized
INFO - 2019-07-03 16:51:03 --> Language Class Initialized
INFO - 2019-07-03 16:51:03 --> Language Class Initialized
INFO - 2019-07-03 16:51:03 --> Config Class Initialized
INFO - 2019-07-03 16:51:03 --> Loader Class Initialized
DEBUG - 2019-07-03 16:51:03 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 16:51:03 --> Helper loaded: url_helper
INFO - 2019-07-03 16:51:03 --> Helper loaded: inflector_helper
INFO - 2019-07-03 16:51:03 --> Helper loaded: string_helper
INFO - 2019-07-03 16:51:03 --> Helper loaded: array_helper
INFO - 2019-07-03 16:51:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 16:51:03 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 16:51:03 --> Database Driver Class Initialized
INFO - 2019-07-03 16:51:03 --> Controller Class Initialized
INFO - 2019-07-03 22:51:03 --> Helper loaded: language_helper
INFO - 2019-07-03 22:51:03 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 22:51:03 --> Model Class Initialized
INFO - 2019-07-03 22:51:03 --> Model Class Initialized
INFO - 2019-07-03 22:51:03 --> Model Class Initialized
INFO - 2019-07-03 22:51:03 --> Model Class Initialized
INFO - 2019-07-03 22:51:03 --> Model Class Initialized
INFO - 2019-07-03 22:51:03 --> Final output sent to browser
DEBUG - 2019-07-03 22:51:03 --> Total execution time: 0.3793
INFO - 2019-07-03 16:51:03 --> Config Class Initialized
INFO - 2019-07-03 16:51:03 --> Hooks Class Initialized
DEBUG - 2019-07-03 16:51:03 --> UTF-8 Support Enabled
INFO - 2019-07-03 16:51:03 --> Utf8 Class Initialized
INFO - 2019-07-03 16:51:03 --> URI Class Initialized
INFO - 2019-07-03 16:51:03 --> Router Class Initialized
INFO - 2019-07-03 16:51:03 --> Output Class Initialized
INFO - 2019-07-03 16:51:03 --> Security Class Initialized
DEBUG - 2019-07-03 16:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 16:51:03 --> Input Class Initialized
INFO - 2019-07-03 16:51:03 --> Language Class Initialized
INFO - 2019-07-03 16:51:03 --> Language Class Initialized
INFO - 2019-07-03 16:51:03 --> Config Class Initialized
INFO - 2019-07-03 16:51:03 --> Loader Class Initialized
DEBUG - 2019-07-03 16:51:03 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 16:51:03 --> Helper loaded: url_helper
INFO - 2019-07-03 16:51:03 --> Helper loaded: inflector_helper
INFO - 2019-07-03 16:51:03 --> Helper loaded: string_helper
INFO - 2019-07-03 16:51:03 --> Helper loaded: array_helper
INFO - 2019-07-03 16:51:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 16:51:03 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 16:51:03 --> Database Driver Class Initialized
INFO - 2019-07-03 16:51:03 --> Controller Class Initialized
INFO - 2019-07-03 22:51:03 --> Helper loaded: language_helper
INFO - 2019-07-03 22:51:03 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 22:51:03 --> Model Class Initialized
INFO - 2019-07-03 22:51:03 --> Model Class Initialized
INFO - 2019-07-03 22:51:03 --> Model Class Initialized
INFO - 2019-07-03 22:51:03 --> Model Class Initialized
INFO - 2019-07-03 22:51:03 --> Helper loaded: form_helper
INFO - 2019-07-03 22:51:03 --> Form Validation Class Initialized
DEBUG - 2019-07-03 22:51:03 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-03 22:51:03 --> Model Class Initialized
INFO - 2019-07-03 22:51:03 --> Model Class Initialized
INFO - 2019-07-03 22:51:03 --> Final output sent to browser
DEBUG - 2019-07-03 22:51:03 --> Total execution time: 0.4106
INFO - 2019-07-03 16:51:27 --> Config Class Initialized
INFO - 2019-07-03 16:51:27 --> Hooks Class Initialized
DEBUG - 2019-07-03 16:51:27 --> UTF-8 Support Enabled
INFO - 2019-07-03 16:51:27 --> Utf8 Class Initialized
INFO - 2019-07-03 16:51:27 --> URI Class Initialized
INFO - 2019-07-03 16:51:27 --> Router Class Initialized
INFO - 2019-07-03 16:51:27 --> Output Class Initialized
INFO - 2019-07-03 16:51:27 --> Security Class Initialized
DEBUG - 2019-07-03 16:51:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 16:51:27 --> Input Class Initialized
INFO - 2019-07-03 16:51:27 --> Language Class Initialized
INFO - 2019-07-03 16:51:27 --> Language Class Initialized
INFO - 2019-07-03 16:51:27 --> Config Class Initialized
INFO - 2019-07-03 16:51:27 --> Loader Class Initialized
DEBUG - 2019-07-03 16:51:27 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 16:51:27 --> Helper loaded: url_helper
INFO - 2019-07-03 16:51:27 --> Helper loaded: inflector_helper
INFO - 2019-07-03 16:51:27 --> Helper loaded: string_helper
INFO - 2019-07-03 16:51:27 --> Helper loaded: array_helper
INFO - 2019-07-03 16:51:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 16:51:27 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 16:51:27 --> Database Driver Class Initialized
INFO - 2019-07-03 16:51:27 --> Controller Class Initialized
INFO - 2019-07-03 22:51:27 --> Helper loaded: language_helper
INFO - 2019-07-03 22:51:27 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 22:51:27 --> Model Class Initialized
INFO - 2019-07-03 22:51:27 --> Model Class Initialized
INFO - 2019-07-03 22:51:27 --> Model Class Initialized
INFO - 2019-07-03 22:51:27 --> Model Class Initialized
INFO - 2019-07-03 22:51:27 --> Model Class Initialized
INFO - 2019-07-03 22:51:27 --> Final output sent to browser
DEBUG - 2019-07-03 22:51:27 --> Total execution time: 0.4057
INFO - 2019-07-03 16:51:27 --> Config Class Initialized
INFO - 2019-07-03 16:51:27 --> Hooks Class Initialized
DEBUG - 2019-07-03 16:51:27 --> UTF-8 Support Enabled
INFO - 2019-07-03 16:51:27 --> Utf8 Class Initialized
INFO - 2019-07-03 16:51:27 --> URI Class Initialized
INFO - 2019-07-03 16:51:27 --> Router Class Initialized
INFO - 2019-07-03 16:51:27 --> Output Class Initialized
INFO - 2019-07-03 16:51:27 --> Security Class Initialized
DEBUG - 2019-07-03 16:51:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 16:51:27 --> Input Class Initialized
INFO - 2019-07-03 16:51:27 --> Language Class Initialized
INFO - 2019-07-03 16:51:27 --> Language Class Initialized
INFO - 2019-07-03 16:51:27 --> Config Class Initialized
INFO - 2019-07-03 16:51:27 --> Loader Class Initialized
DEBUG - 2019-07-03 16:51:27 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 16:51:27 --> Helper loaded: url_helper
INFO - 2019-07-03 16:51:27 --> Helper loaded: inflector_helper
INFO - 2019-07-03 16:51:27 --> Helper loaded: string_helper
INFO - 2019-07-03 16:51:27 --> Helper loaded: array_helper
INFO - 2019-07-03 16:51:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 16:51:27 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 16:51:27 --> Database Driver Class Initialized
INFO - 2019-07-03 16:51:28 --> Controller Class Initialized
INFO - 2019-07-03 22:51:28 --> Helper loaded: language_helper
INFO - 2019-07-03 22:51:28 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 22:51:28 --> Model Class Initialized
INFO - 2019-07-03 22:51:28 --> Model Class Initialized
INFO - 2019-07-03 22:51:28 --> Model Class Initialized
INFO - 2019-07-03 22:51:28 --> Model Class Initialized
INFO - 2019-07-03 22:51:28 --> Helper loaded: form_helper
INFO - 2019-07-03 22:51:28 --> Form Validation Class Initialized
DEBUG - 2019-07-03 22:51:28 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-03 22:51:28 --> Model Class Initialized
INFO - 2019-07-03 22:51:28 --> Model Class Initialized
INFO - 2019-07-03 22:51:28 --> Final output sent to browser
DEBUG - 2019-07-03 22:51:28 --> Total execution time: 0.4237
INFO - 2019-07-03 16:51:54 --> Config Class Initialized
INFO - 2019-07-03 16:51:54 --> Hooks Class Initialized
DEBUG - 2019-07-03 16:51:54 --> UTF-8 Support Enabled
INFO - 2019-07-03 16:51:54 --> Utf8 Class Initialized
INFO - 2019-07-03 16:51:54 --> URI Class Initialized
INFO - 2019-07-03 16:51:54 --> Router Class Initialized
INFO - 2019-07-03 16:51:54 --> Output Class Initialized
INFO - 2019-07-03 16:51:54 --> Security Class Initialized
DEBUG - 2019-07-03 16:51:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 16:51:54 --> Input Class Initialized
INFO - 2019-07-03 16:51:54 --> Language Class Initialized
INFO - 2019-07-03 16:51:54 --> Language Class Initialized
INFO - 2019-07-03 16:51:54 --> Config Class Initialized
INFO - 2019-07-03 16:51:54 --> Loader Class Initialized
DEBUG - 2019-07-03 16:51:54 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 16:51:54 --> Helper loaded: url_helper
INFO - 2019-07-03 16:51:54 --> Helper loaded: inflector_helper
INFO - 2019-07-03 16:51:54 --> Helper loaded: string_helper
INFO - 2019-07-03 16:51:54 --> Helper loaded: array_helper
INFO - 2019-07-03 16:51:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 16:51:54 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 16:51:54 --> Database Driver Class Initialized
INFO - 2019-07-03 16:51:54 --> Controller Class Initialized
INFO - 2019-07-03 22:51:54 --> Helper loaded: language_helper
INFO - 2019-07-03 22:51:54 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 22:51:54 --> Model Class Initialized
INFO - 2019-07-03 22:51:54 --> Model Class Initialized
INFO - 2019-07-03 22:51:54 --> Model Class Initialized
INFO - 2019-07-03 22:51:54 --> Model Class Initialized
INFO - 2019-07-03 22:51:54 --> Model Class Initialized
INFO - 2019-07-03 22:51:54 --> Final output sent to browser
DEBUG - 2019-07-03 22:51:54 --> Total execution time: 0.4341
INFO - 2019-07-03 16:51:54 --> Config Class Initialized
INFO - 2019-07-03 16:51:54 --> Hooks Class Initialized
DEBUG - 2019-07-03 16:51:54 --> UTF-8 Support Enabled
INFO - 2019-07-03 16:51:54 --> Utf8 Class Initialized
INFO - 2019-07-03 16:51:54 --> URI Class Initialized
INFO - 2019-07-03 16:51:54 --> Router Class Initialized
INFO - 2019-07-03 16:51:54 --> Output Class Initialized
INFO - 2019-07-03 16:51:54 --> Security Class Initialized
DEBUG - 2019-07-03 16:51:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 16:51:55 --> Input Class Initialized
INFO - 2019-07-03 16:51:55 --> Language Class Initialized
INFO - 2019-07-03 16:51:55 --> Language Class Initialized
INFO - 2019-07-03 16:51:55 --> Config Class Initialized
INFO - 2019-07-03 16:51:55 --> Loader Class Initialized
DEBUG - 2019-07-03 16:51:55 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 16:51:55 --> Helper loaded: url_helper
INFO - 2019-07-03 16:51:55 --> Helper loaded: inflector_helper
INFO - 2019-07-03 16:51:55 --> Helper loaded: string_helper
INFO - 2019-07-03 16:51:55 --> Helper loaded: array_helper
INFO - 2019-07-03 16:51:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 16:51:55 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 16:51:55 --> Database Driver Class Initialized
INFO - 2019-07-03 16:51:55 --> Controller Class Initialized
INFO - 2019-07-03 22:51:55 --> Helper loaded: language_helper
INFO - 2019-07-03 22:51:55 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 22:51:55 --> Model Class Initialized
INFO - 2019-07-03 22:51:55 --> Model Class Initialized
INFO - 2019-07-03 22:51:55 --> Model Class Initialized
INFO - 2019-07-03 22:51:55 --> Model Class Initialized
INFO - 2019-07-03 22:51:55 --> Helper loaded: form_helper
INFO - 2019-07-03 22:51:55 --> Form Validation Class Initialized
DEBUG - 2019-07-03 22:51:55 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-03 22:51:55 --> Model Class Initialized
INFO - 2019-07-03 22:51:55 --> Model Class Initialized
INFO - 2019-07-03 22:51:55 --> Final output sent to browser
DEBUG - 2019-07-03 22:51:55 --> Total execution time: 0.4406
INFO - 2019-07-03 16:52:12 --> Config Class Initialized
INFO - 2019-07-03 16:52:12 --> Hooks Class Initialized
DEBUG - 2019-07-03 16:52:12 --> UTF-8 Support Enabled
INFO - 2019-07-03 16:52:12 --> Utf8 Class Initialized
INFO - 2019-07-03 16:52:12 --> URI Class Initialized
INFO - 2019-07-03 16:52:12 --> Router Class Initialized
INFO - 2019-07-03 16:52:12 --> Output Class Initialized
INFO - 2019-07-03 16:52:12 --> Security Class Initialized
DEBUG - 2019-07-03 16:52:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 16:52:12 --> Input Class Initialized
INFO - 2019-07-03 16:52:12 --> Language Class Initialized
INFO - 2019-07-03 16:52:12 --> Language Class Initialized
INFO - 2019-07-03 16:52:12 --> Config Class Initialized
INFO - 2019-07-03 16:52:12 --> Loader Class Initialized
DEBUG - 2019-07-03 16:52:12 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 16:52:12 --> Helper loaded: url_helper
INFO - 2019-07-03 16:52:12 --> Helper loaded: inflector_helper
INFO - 2019-07-03 16:52:12 --> Helper loaded: string_helper
INFO - 2019-07-03 16:52:12 --> Helper loaded: array_helper
INFO - 2019-07-03 16:52:12 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 16:52:12 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 16:52:12 --> Database Driver Class Initialized
INFO - 2019-07-03 16:52:12 --> Controller Class Initialized
INFO - 2019-07-03 22:52:12 --> Helper loaded: language_helper
INFO - 2019-07-03 22:52:12 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 22:52:12 --> Model Class Initialized
INFO - 2019-07-03 22:52:12 --> Model Class Initialized
INFO - 2019-07-03 22:52:12 --> Model Class Initialized
INFO - 2019-07-03 22:52:12 --> Model Class Initialized
INFO - 2019-07-03 22:52:12 --> Model Class Initialized
INFO - 2019-07-03 22:52:12 --> Final output sent to browser
DEBUG - 2019-07-03 22:52:12 --> Total execution time: 0.4012
INFO - 2019-07-03 16:52:12 --> Config Class Initialized
INFO - 2019-07-03 16:52:12 --> Hooks Class Initialized
DEBUG - 2019-07-03 16:52:12 --> UTF-8 Support Enabled
INFO - 2019-07-03 16:52:12 --> Utf8 Class Initialized
INFO - 2019-07-03 16:52:12 --> URI Class Initialized
INFO - 2019-07-03 16:52:12 --> Router Class Initialized
INFO - 2019-07-03 16:52:12 --> Output Class Initialized
INFO - 2019-07-03 16:52:12 --> Security Class Initialized
DEBUG - 2019-07-03 16:52:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 16:52:12 --> Input Class Initialized
INFO - 2019-07-03 16:52:12 --> Language Class Initialized
INFO - 2019-07-03 16:52:12 --> Language Class Initialized
INFO - 2019-07-03 16:52:12 --> Config Class Initialized
INFO - 2019-07-03 16:52:12 --> Loader Class Initialized
DEBUG - 2019-07-03 16:52:12 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 16:52:12 --> Helper loaded: url_helper
INFO - 2019-07-03 16:52:12 --> Helper loaded: inflector_helper
INFO - 2019-07-03 16:52:12 --> Helper loaded: string_helper
INFO - 2019-07-03 16:52:12 --> Helper loaded: array_helper
INFO - 2019-07-03 16:52:12 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 16:52:12 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 16:52:12 --> Database Driver Class Initialized
INFO - 2019-07-03 16:52:12 --> Controller Class Initialized
INFO - 2019-07-03 22:52:12 --> Helper loaded: language_helper
INFO - 2019-07-03 22:52:12 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 22:52:12 --> Model Class Initialized
INFO - 2019-07-03 22:52:12 --> Model Class Initialized
INFO - 2019-07-03 22:52:12 --> Model Class Initialized
INFO - 2019-07-03 22:52:12 --> Model Class Initialized
INFO - 2019-07-03 22:52:12 --> Helper loaded: form_helper
INFO - 2019-07-03 22:52:12 --> Form Validation Class Initialized
DEBUG - 2019-07-03 22:52:12 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-03 22:52:13 --> Model Class Initialized
INFO - 2019-07-03 22:52:13 --> Model Class Initialized
INFO - 2019-07-03 22:52:13 --> Final output sent to browser
DEBUG - 2019-07-03 22:52:13 --> Total execution time: 0.4311
INFO - 2019-07-03 16:52:15 --> Config Class Initialized
INFO - 2019-07-03 16:52:15 --> Hooks Class Initialized
DEBUG - 2019-07-03 16:52:15 --> UTF-8 Support Enabled
INFO - 2019-07-03 16:52:15 --> Utf8 Class Initialized
INFO - 2019-07-03 16:52:15 --> URI Class Initialized
INFO - 2019-07-03 16:52:15 --> Router Class Initialized
INFO - 2019-07-03 16:52:15 --> Output Class Initialized
INFO - 2019-07-03 16:52:15 --> Security Class Initialized
DEBUG - 2019-07-03 16:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 16:52:15 --> Input Class Initialized
INFO - 2019-07-03 16:52:15 --> Language Class Initialized
INFO - 2019-07-03 16:52:15 --> Language Class Initialized
INFO - 2019-07-03 16:52:15 --> Config Class Initialized
INFO - 2019-07-03 16:52:15 --> Loader Class Initialized
DEBUG - 2019-07-03 16:52:15 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 16:52:15 --> Helper loaded: url_helper
INFO - 2019-07-03 16:52:15 --> Helper loaded: inflector_helper
INFO - 2019-07-03 16:52:15 --> Helper loaded: string_helper
INFO - 2019-07-03 16:52:15 --> Helper loaded: array_helper
INFO - 2019-07-03 16:52:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 16:52:15 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 16:52:15 --> Database Driver Class Initialized
INFO - 2019-07-03 16:52:15 --> Controller Class Initialized
INFO - 2019-07-03 22:52:15 --> Helper loaded: language_helper
INFO - 2019-07-03 22:52:15 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 22:52:15 --> Model Class Initialized
INFO - 2019-07-03 22:52:15 --> Model Class Initialized
INFO - 2019-07-03 22:52:15 --> Model Class Initialized
INFO - 2019-07-03 22:52:15 --> Model Class Initialized
INFO - 2019-07-03 22:52:15 --> Model Class Initialized
INFO - 2019-07-03 22:52:15 --> Final output sent to browser
DEBUG - 2019-07-03 22:52:15 --> Total execution time: 0.4011
INFO - 2019-07-03 16:52:15 --> Config Class Initialized
INFO - 2019-07-03 16:52:15 --> Hooks Class Initialized
DEBUG - 2019-07-03 16:52:15 --> UTF-8 Support Enabled
INFO - 2019-07-03 16:52:15 --> Utf8 Class Initialized
INFO - 2019-07-03 16:52:15 --> URI Class Initialized
INFO - 2019-07-03 16:52:15 --> Router Class Initialized
INFO - 2019-07-03 16:52:15 --> Output Class Initialized
INFO - 2019-07-03 16:52:15 --> Security Class Initialized
DEBUG - 2019-07-03 16:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 16:52:15 --> Input Class Initialized
INFO - 2019-07-03 16:52:15 --> Language Class Initialized
INFO - 2019-07-03 16:52:15 --> Language Class Initialized
INFO - 2019-07-03 16:52:15 --> Config Class Initialized
INFO - 2019-07-03 16:52:15 --> Loader Class Initialized
DEBUG - 2019-07-03 16:52:15 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 16:52:15 --> Helper loaded: url_helper
INFO - 2019-07-03 16:52:15 --> Helper loaded: inflector_helper
INFO - 2019-07-03 16:52:15 --> Helper loaded: string_helper
INFO - 2019-07-03 16:52:15 --> Helper loaded: array_helper
INFO - 2019-07-03 16:52:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 16:52:15 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 16:52:15 --> Database Driver Class Initialized
INFO - 2019-07-03 16:52:15 --> Controller Class Initialized
INFO - 2019-07-03 22:52:15 --> Helper loaded: language_helper
INFO - 2019-07-03 22:52:16 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 22:52:16 --> Model Class Initialized
INFO - 2019-07-03 22:52:16 --> Model Class Initialized
INFO - 2019-07-03 22:52:16 --> Model Class Initialized
INFO - 2019-07-03 22:52:16 --> Model Class Initialized
INFO - 2019-07-03 22:52:16 --> Helper loaded: form_helper
INFO - 2019-07-03 22:52:16 --> Form Validation Class Initialized
DEBUG - 2019-07-03 22:52:16 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-03 22:52:16 --> Model Class Initialized
INFO - 2019-07-03 22:52:16 --> Model Class Initialized
INFO - 2019-07-03 22:52:16 --> Final output sent to browser
DEBUG - 2019-07-03 22:52:16 --> Total execution time: 0.4415
INFO - 2019-07-03 16:52:42 --> Config Class Initialized
INFO - 2019-07-03 16:52:42 --> Hooks Class Initialized
DEBUG - 2019-07-03 16:52:42 --> UTF-8 Support Enabled
INFO - 2019-07-03 16:52:42 --> Utf8 Class Initialized
INFO - 2019-07-03 16:52:42 --> URI Class Initialized
INFO - 2019-07-03 16:52:42 --> Router Class Initialized
INFO - 2019-07-03 16:52:42 --> Output Class Initialized
INFO - 2019-07-03 16:52:42 --> Security Class Initialized
DEBUG - 2019-07-03 16:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 16:52:42 --> Input Class Initialized
INFO - 2019-07-03 16:52:42 --> Language Class Initialized
INFO - 2019-07-03 16:52:42 --> Language Class Initialized
INFO - 2019-07-03 16:52:42 --> Config Class Initialized
INFO - 2019-07-03 16:52:42 --> Loader Class Initialized
DEBUG - 2019-07-03 16:52:42 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 16:52:42 --> Helper loaded: url_helper
INFO - 2019-07-03 16:52:42 --> Helper loaded: inflector_helper
INFO - 2019-07-03 16:52:42 --> Helper loaded: string_helper
INFO - 2019-07-03 16:52:42 --> Helper loaded: array_helper
INFO - 2019-07-03 16:52:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 16:52:42 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 16:52:42 --> Database Driver Class Initialized
INFO - 2019-07-03 16:52:42 --> Controller Class Initialized
INFO - 2019-07-03 22:52:42 --> Helper loaded: language_helper
INFO - 2019-07-03 22:52:42 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 22:52:42 --> Model Class Initialized
INFO - 2019-07-03 22:52:42 --> Model Class Initialized
INFO - 2019-07-03 22:52:42 --> Model Class Initialized
INFO - 2019-07-03 22:52:42 --> Model Class Initialized
INFO - 2019-07-03 22:52:42 --> Model Class Initialized
INFO - 2019-07-03 22:52:42 --> Final output sent to browser
DEBUG - 2019-07-03 22:52:42 --> Total execution time: 0.4194
INFO - 2019-07-03 16:52:42 --> Config Class Initialized
INFO - 2019-07-03 16:52:42 --> Hooks Class Initialized
DEBUG - 2019-07-03 16:52:42 --> UTF-8 Support Enabled
INFO - 2019-07-03 16:52:42 --> Utf8 Class Initialized
INFO - 2019-07-03 16:52:42 --> URI Class Initialized
INFO - 2019-07-03 16:52:42 --> Router Class Initialized
INFO - 2019-07-03 16:52:42 --> Output Class Initialized
INFO - 2019-07-03 16:52:42 --> Security Class Initialized
DEBUG - 2019-07-03 16:52:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 16:52:42 --> Input Class Initialized
INFO - 2019-07-03 16:52:42 --> Language Class Initialized
INFO - 2019-07-03 16:52:43 --> Language Class Initialized
INFO - 2019-07-03 16:52:43 --> Config Class Initialized
INFO - 2019-07-03 16:52:43 --> Loader Class Initialized
DEBUG - 2019-07-03 16:52:43 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 16:52:43 --> Helper loaded: url_helper
INFO - 2019-07-03 16:52:43 --> Helper loaded: inflector_helper
INFO - 2019-07-03 16:52:43 --> Helper loaded: string_helper
INFO - 2019-07-03 16:52:43 --> Helper loaded: array_helper
INFO - 2019-07-03 16:52:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 16:52:43 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 16:52:43 --> Database Driver Class Initialized
INFO - 2019-07-03 16:52:43 --> Controller Class Initialized
INFO - 2019-07-03 22:52:43 --> Helper loaded: language_helper
INFO - 2019-07-03 22:52:43 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 22:52:43 --> Model Class Initialized
INFO - 2019-07-03 22:52:43 --> Model Class Initialized
INFO - 2019-07-03 22:52:43 --> Model Class Initialized
INFO - 2019-07-03 22:52:43 --> Model Class Initialized
INFO - 2019-07-03 22:52:43 --> Helper loaded: form_helper
INFO - 2019-07-03 22:52:43 --> Form Validation Class Initialized
DEBUG - 2019-07-03 22:52:43 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-03 22:52:43 --> Model Class Initialized
INFO - 2019-07-03 22:52:43 --> Model Class Initialized
INFO - 2019-07-03 22:52:43 --> Final output sent to browser
DEBUG - 2019-07-03 22:52:43 --> Total execution time: 0.4316
INFO - 2019-07-03 16:54:12 --> Config Class Initialized
INFO - 2019-07-03 16:54:12 --> Hooks Class Initialized
DEBUG - 2019-07-03 16:54:12 --> UTF-8 Support Enabled
INFO - 2019-07-03 16:54:12 --> Utf8 Class Initialized
INFO - 2019-07-03 16:54:12 --> URI Class Initialized
INFO - 2019-07-03 16:54:12 --> Router Class Initialized
INFO - 2019-07-03 16:54:12 --> Output Class Initialized
INFO - 2019-07-03 16:54:12 --> Security Class Initialized
DEBUG - 2019-07-03 16:54:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 16:54:12 --> Input Class Initialized
INFO - 2019-07-03 16:54:12 --> Language Class Initialized
INFO - 2019-07-03 16:54:12 --> Language Class Initialized
INFO - 2019-07-03 16:54:12 --> Config Class Initialized
INFO - 2019-07-03 16:54:12 --> Loader Class Initialized
DEBUG - 2019-07-03 16:54:12 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 16:54:12 --> Helper loaded: url_helper
INFO - 2019-07-03 16:54:12 --> Helper loaded: inflector_helper
INFO - 2019-07-03 16:54:12 --> Helper loaded: string_helper
INFO - 2019-07-03 16:54:12 --> Helper loaded: array_helper
INFO - 2019-07-03 16:54:12 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 16:54:12 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 16:54:12 --> Database Driver Class Initialized
INFO - 2019-07-03 16:54:12 --> Controller Class Initialized
INFO - 2019-07-03 22:54:12 --> Helper loaded: language_helper
INFO - 2019-07-03 22:54:12 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 22:54:12 --> Model Class Initialized
INFO - 2019-07-03 22:54:12 --> Model Class Initialized
INFO - 2019-07-03 22:54:12 --> Model Class Initialized
INFO - 2019-07-03 22:54:12 --> Model Class Initialized
INFO - 2019-07-03 22:54:12 --> Model Class Initialized
INFO - 2019-07-03 22:54:12 --> Final output sent to browser
DEBUG - 2019-07-03 22:54:12 --> Total execution time: 0.3918
INFO - 2019-07-03 16:54:12 --> Config Class Initialized
INFO - 2019-07-03 16:54:12 --> Hooks Class Initialized
DEBUG - 2019-07-03 16:54:12 --> UTF-8 Support Enabled
INFO - 2019-07-03 16:54:12 --> Utf8 Class Initialized
INFO - 2019-07-03 16:54:12 --> URI Class Initialized
INFO - 2019-07-03 16:54:12 --> Router Class Initialized
INFO - 2019-07-03 16:54:12 --> Output Class Initialized
INFO - 2019-07-03 16:54:12 --> Security Class Initialized
DEBUG - 2019-07-03 16:54:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 16:54:12 --> Input Class Initialized
INFO - 2019-07-03 16:54:12 --> Language Class Initialized
INFO - 2019-07-03 16:54:13 --> Language Class Initialized
INFO - 2019-07-03 16:54:13 --> Config Class Initialized
INFO - 2019-07-03 16:54:13 --> Loader Class Initialized
DEBUG - 2019-07-03 16:54:13 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 16:54:13 --> Helper loaded: url_helper
INFO - 2019-07-03 16:54:13 --> Helper loaded: inflector_helper
INFO - 2019-07-03 16:54:13 --> Helper loaded: string_helper
INFO - 2019-07-03 16:54:13 --> Helper loaded: array_helper
INFO - 2019-07-03 16:54:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 16:54:13 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 16:54:13 --> Database Driver Class Initialized
INFO - 2019-07-03 16:54:13 --> Controller Class Initialized
INFO - 2019-07-03 22:54:13 --> Helper loaded: language_helper
INFO - 2019-07-03 22:54:13 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 22:54:13 --> Model Class Initialized
INFO - 2019-07-03 22:54:13 --> Model Class Initialized
INFO - 2019-07-03 22:54:13 --> Model Class Initialized
INFO - 2019-07-03 22:54:13 --> Model Class Initialized
INFO - 2019-07-03 22:54:13 --> Helper loaded: form_helper
INFO - 2019-07-03 22:54:13 --> Form Validation Class Initialized
DEBUG - 2019-07-03 22:54:13 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-03 22:54:13 --> Model Class Initialized
INFO - 2019-07-03 22:54:13 --> Model Class Initialized
INFO - 2019-07-03 22:54:13 --> Final output sent to browser
DEBUG - 2019-07-03 22:54:13 --> Total execution time: 0.4399
INFO - 2019-07-03 16:54:39 --> Config Class Initialized
INFO - 2019-07-03 16:54:39 --> Hooks Class Initialized
DEBUG - 2019-07-03 16:54:39 --> UTF-8 Support Enabled
INFO - 2019-07-03 16:54:39 --> Utf8 Class Initialized
INFO - 2019-07-03 16:54:39 --> URI Class Initialized
INFO - 2019-07-03 16:54:39 --> Router Class Initialized
INFO - 2019-07-03 16:54:39 --> Output Class Initialized
INFO - 2019-07-03 16:54:39 --> Security Class Initialized
DEBUG - 2019-07-03 16:54:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 16:54:39 --> Input Class Initialized
INFO - 2019-07-03 16:54:39 --> Language Class Initialized
INFO - 2019-07-03 16:54:39 --> Language Class Initialized
INFO - 2019-07-03 16:54:39 --> Config Class Initialized
INFO - 2019-07-03 16:54:39 --> Loader Class Initialized
DEBUG - 2019-07-03 16:54:39 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 16:54:39 --> Helper loaded: url_helper
INFO - 2019-07-03 16:54:39 --> Helper loaded: inflector_helper
INFO - 2019-07-03 16:54:39 --> Helper loaded: string_helper
INFO - 2019-07-03 16:54:39 --> Helper loaded: array_helper
INFO - 2019-07-03 16:54:39 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 16:54:39 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 16:54:39 --> Database Driver Class Initialized
INFO - 2019-07-03 16:54:39 --> Controller Class Initialized
INFO - 2019-07-03 22:54:39 --> Helper loaded: language_helper
INFO - 2019-07-03 22:54:39 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 22:54:39 --> Model Class Initialized
INFO - 2019-07-03 22:54:39 --> Model Class Initialized
INFO - 2019-07-03 22:54:39 --> Model Class Initialized
INFO - 2019-07-03 22:54:39 --> Model Class Initialized
INFO - 2019-07-03 22:54:39 --> Model Class Initialized
INFO - 2019-07-03 22:54:39 --> Final output sent to browser
DEBUG - 2019-07-03 22:54:39 --> Total execution time: 0.3743
INFO - 2019-07-03 16:54:40 --> Config Class Initialized
INFO - 2019-07-03 16:54:40 --> Hooks Class Initialized
DEBUG - 2019-07-03 16:54:40 --> UTF-8 Support Enabled
INFO - 2019-07-03 16:54:40 --> Utf8 Class Initialized
INFO - 2019-07-03 16:54:40 --> URI Class Initialized
INFO - 2019-07-03 16:54:40 --> Router Class Initialized
INFO - 2019-07-03 16:54:40 --> Output Class Initialized
INFO - 2019-07-03 16:54:40 --> Security Class Initialized
DEBUG - 2019-07-03 16:54:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 16:54:40 --> Input Class Initialized
INFO - 2019-07-03 16:54:40 --> Language Class Initialized
INFO - 2019-07-03 16:54:40 --> Language Class Initialized
INFO - 2019-07-03 16:54:40 --> Config Class Initialized
INFO - 2019-07-03 16:54:40 --> Loader Class Initialized
DEBUG - 2019-07-03 16:54:40 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 16:54:40 --> Helper loaded: url_helper
INFO - 2019-07-03 16:54:40 --> Helper loaded: inflector_helper
INFO - 2019-07-03 16:54:40 --> Helper loaded: string_helper
INFO - 2019-07-03 16:54:40 --> Helper loaded: array_helper
INFO - 2019-07-03 16:54:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 16:54:40 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 16:54:40 --> Database Driver Class Initialized
INFO - 2019-07-03 16:54:40 --> Controller Class Initialized
INFO - 2019-07-03 22:54:40 --> Helper loaded: language_helper
INFO - 2019-07-03 22:54:40 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 22:54:40 --> Model Class Initialized
INFO - 2019-07-03 22:54:40 --> Model Class Initialized
INFO - 2019-07-03 22:54:40 --> Model Class Initialized
INFO - 2019-07-03 22:54:40 --> Model Class Initialized
INFO - 2019-07-03 22:54:40 --> Helper loaded: form_helper
INFO - 2019-07-03 22:54:40 --> Form Validation Class Initialized
DEBUG - 2019-07-03 22:54:40 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-03 22:54:40 --> Model Class Initialized
INFO - 2019-07-03 22:54:40 --> Model Class Initialized
INFO - 2019-07-03 22:54:40 --> Final output sent to browser
DEBUG - 2019-07-03 22:54:40 --> Total execution time: 0.4653
INFO - 2019-07-03 16:55:17 --> Config Class Initialized
INFO - 2019-07-03 16:55:17 --> Config Class Initialized
INFO - 2019-07-03 16:55:17 --> Hooks Class Initialized
INFO - 2019-07-03 16:55:17 --> Hooks Class Initialized
DEBUG - 2019-07-03 16:55:17 --> UTF-8 Support Enabled
DEBUG - 2019-07-03 16:55:17 --> UTF-8 Support Enabled
INFO - 2019-07-03 16:55:17 --> Utf8 Class Initialized
INFO - 2019-07-03 16:55:17 --> Utf8 Class Initialized
INFO - 2019-07-03 16:55:17 --> URI Class Initialized
INFO - 2019-07-03 16:55:17 --> URI Class Initialized
INFO - 2019-07-03 16:55:17 --> Router Class Initialized
INFO - 2019-07-03 16:55:17 --> Router Class Initialized
INFO - 2019-07-03 16:55:17 --> Output Class Initialized
INFO - 2019-07-03 16:55:17 --> Output Class Initialized
INFO - 2019-07-03 16:55:17 --> Security Class Initialized
INFO - 2019-07-03 16:55:17 --> Security Class Initialized
DEBUG - 2019-07-03 16:55:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-03 16:55:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 16:55:17 --> Input Class Initialized
INFO - 2019-07-03 16:55:17 --> Input Class Initialized
INFO - 2019-07-03 16:55:17 --> Language Class Initialized
INFO - 2019-07-03 16:55:17 --> Language Class Initialized
INFO - 2019-07-03 16:55:17 --> Language Class Initialized
INFO - 2019-07-03 16:55:17 --> Language Class Initialized
INFO - 2019-07-03 16:55:17 --> Config Class Initialized
INFO - 2019-07-03 16:55:17 --> Config Class Initialized
INFO - 2019-07-03 16:55:17 --> Loader Class Initialized
INFO - 2019-07-03 16:55:17 --> Loader Class Initialized
DEBUG - 2019-07-03 16:55:17 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-03 16:55:17 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 16:55:18 --> Helper loaded: url_helper
INFO - 2019-07-03 16:55:18 --> Helper loaded: url_helper
INFO - 2019-07-03 16:55:18 --> Helper loaded: inflector_helper
INFO - 2019-07-03 16:55:18 --> Helper loaded: inflector_helper
INFO - 2019-07-03 16:55:18 --> Helper loaded: string_helper
INFO - 2019-07-03 16:55:18 --> Helper loaded: string_helper
INFO - 2019-07-03 16:55:18 --> Helper loaded: array_helper
INFO - 2019-07-03 16:55:18 --> Helper loaded: array_helper
INFO - 2019-07-03 16:55:18 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 16:55:18 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 16:55:18 --> Database Driver Class Initialized
INFO - 2019-07-03 16:55:18 --> Controller Class Initialized
INFO - 2019-07-03 22:55:18 --> Helper loaded: language_helper
INFO - 2019-07-03 22:55:18 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 22:55:18 --> Model Class Initialized
INFO - 2019-07-03 22:55:18 --> Model Class Initialized
INFO - 2019-07-03 22:55:18 --> Model Class Initialized
INFO - 2019-07-03 22:55:18 --> Model Class Initialized
INFO - 2019-07-03 22:55:18 --> Final output sent to browser
DEBUG - 2019-07-03 22:55:18 --> Total execution time: 0.4936
INFO - 2019-07-03 16:55:18 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 16:55:18 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 16:55:18 --> Database Driver Class Initialized
INFO - 2019-07-03 16:55:18 --> Controller Class Initialized
INFO - 2019-07-03 22:55:18 --> Helper loaded: language_helper
INFO - 2019-07-03 22:55:18 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 22:55:18 --> Model Class Initialized
INFO - 2019-07-03 22:55:18 --> Model Class Initialized
INFO - 2019-07-03 22:55:18 --> Model Class Initialized
INFO - 2019-07-03 22:55:18 --> Model Class Initialized
INFO - 2019-07-03 22:55:18 --> Model Class Initialized
INFO - 2019-07-03 22:55:18 --> Final output sent to browser
DEBUG - 2019-07-03 22:55:18 --> Total execution time: 0.6943
INFO - 2019-07-03 16:55:32 --> Config Class Initialized
INFO - 2019-07-03 16:55:32 --> Hooks Class Initialized
INFO - 2019-07-03 16:55:32 --> Config Class Initialized
DEBUG - 2019-07-03 16:55:32 --> UTF-8 Support Enabled
INFO - 2019-07-03 16:55:32 --> Hooks Class Initialized
INFO - 2019-07-03 16:55:32 --> Utf8 Class Initialized
DEBUG - 2019-07-03 16:55:32 --> UTF-8 Support Enabled
INFO - 2019-07-03 16:55:32 --> URI Class Initialized
INFO - 2019-07-03 16:55:32 --> Utf8 Class Initialized
INFO - 2019-07-03 16:55:32 --> URI Class Initialized
INFO - 2019-07-03 16:55:33 --> Router Class Initialized
INFO - 2019-07-03 16:55:33 --> Output Class Initialized
INFO - 2019-07-03 16:55:33 --> Router Class Initialized
INFO - 2019-07-03 16:55:33 --> Security Class Initialized
INFO - 2019-07-03 16:55:33 --> Output Class Initialized
DEBUG - 2019-07-03 16:55:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 16:55:33 --> Security Class Initialized
INFO - 2019-07-03 16:55:33 --> Input Class Initialized
INFO - 2019-07-03 16:55:33 --> Language Class Initialized
DEBUG - 2019-07-03 16:55:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 16:55:33 --> Language Class Initialized
INFO - 2019-07-03 16:55:33 --> Input Class Initialized
INFO - 2019-07-03 16:55:33 --> Config Class Initialized
INFO - 2019-07-03 16:55:33 --> Language Class Initialized
INFO - 2019-07-03 16:55:33 --> Loader Class Initialized
DEBUG - 2019-07-03 16:55:33 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 16:55:33 --> Language Class Initialized
INFO - 2019-07-03 16:55:33 --> Config Class Initialized
INFO - 2019-07-03 16:55:33 --> Helper loaded: url_helper
INFO - 2019-07-03 16:55:33 --> Loader Class Initialized
INFO - 2019-07-03 16:55:33 --> Helper loaded: inflector_helper
DEBUG - 2019-07-03 16:55:33 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 16:55:33 --> Helper loaded: string_helper
INFO - 2019-07-03 16:55:33 --> Helper loaded: url_helper
INFO - 2019-07-03 16:55:33 --> Helper loaded: array_helper
INFO - 2019-07-03 16:55:33 --> Helper loaded: inflector_helper
INFO - 2019-07-03 16:55:33 --> Session: Class initialized using 'files' driver.
INFO - 2019-07-03 16:55:33 --> Helper loaded: string_helper
DEBUG - 2019-07-03 16:55:33 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 16:55:33 --> Helper loaded: array_helper
INFO - 2019-07-03 16:55:33 --> Database Driver Class Initialized
INFO - 2019-07-03 16:55:33 --> Controller Class Initialized
INFO - 2019-07-03 22:55:33 --> Helper loaded: language_helper
INFO - 2019-07-03 22:55:33 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 22:55:33 --> Model Class Initialized
INFO - 2019-07-03 22:55:33 --> Model Class Initialized
INFO - 2019-07-03 22:55:33 --> Model Class Initialized
INFO - 2019-07-03 22:55:33 --> Model Class Initialized
INFO - 2019-07-03 22:55:33 --> Final output sent to browser
DEBUG - 2019-07-03 22:55:33 --> Total execution time: 0.5443
INFO - 2019-07-03 16:55:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 16:55:33 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 16:55:33 --> Database Driver Class Initialized
INFO - 2019-07-03 16:55:33 --> Controller Class Initialized
INFO - 2019-07-03 22:55:33 --> Helper loaded: language_helper
INFO - 2019-07-03 22:55:33 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 22:55:33 --> Model Class Initialized
INFO - 2019-07-03 22:55:33 --> Model Class Initialized
INFO - 2019-07-03 22:55:33 --> Model Class Initialized
INFO - 2019-07-03 22:55:33 --> Model Class Initialized
INFO - 2019-07-03 22:55:33 --> Model Class Initialized
INFO - 2019-07-03 22:55:33 --> Final output sent to browser
DEBUG - 2019-07-03 22:55:33 --> Total execution time: 0.7732
INFO - 2019-07-03 16:56:05 --> Config Class Initialized
INFO - 2019-07-03 16:56:05 --> Hooks Class Initialized
INFO - 2019-07-03 16:56:05 --> Config Class Initialized
DEBUG - 2019-07-03 16:56:05 --> UTF-8 Support Enabled
INFO - 2019-07-03 16:56:05 --> Hooks Class Initialized
INFO - 2019-07-03 16:56:05 --> Utf8 Class Initialized
DEBUG - 2019-07-03 16:56:06 --> UTF-8 Support Enabled
INFO - 2019-07-03 16:56:06 --> Utf8 Class Initialized
INFO - 2019-07-03 16:56:06 --> URI Class Initialized
INFO - 2019-07-03 16:56:06 --> URI Class Initialized
INFO - 2019-07-03 16:56:06 --> Router Class Initialized
INFO - 2019-07-03 16:56:06 --> Router Class Initialized
INFO - 2019-07-03 16:56:06 --> Output Class Initialized
INFO - 2019-07-03 16:56:06 --> Output Class Initialized
INFO - 2019-07-03 16:56:06 --> Security Class Initialized
INFO - 2019-07-03 16:56:06 --> Security Class Initialized
DEBUG - 2019-07-03 16:56:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-03 16:56:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 16:56:06 --> Input Class Initialized
INFO - 2019-07-03 16:56:06 --> Input Class Initialized
INFO - 2019-07-03 16:56:06 --> Language Class Initialized
INFO - 2019-07-03 16:56:06 --> Language Class Initialized
INFO - 2019-07-03 16:56:06 --> Language Class Initialized
INFO - 2019-07-03 16:56:06 --> Language Class Initialized
INFO - 2019-07-03 16:56:06 --> Config Class Initialized
INFO - 2019-07-03 16:56:06 --> Config Class Initialized
INFO - 2019-07-03 16:56:06 --> Loader Class Initialized
INFO - 2019-07-03 16:56:06 --> Loader Class Initialized
DEBUG - 2019-07-03 16:56:06 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-03 16:56:06 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 16:56:06 --> Helper loaded: url_helper
INFO - 2019-07-03 16:56:06 --> Helper loaded: url_helper
INFO - 2019-07-03 16:56:06 --> Helper loaded: inflector_helper
INFO - 2019-07-03 16:56:06 --> Helper loaded: inflector_helper
INFO - 2019-07-03 16:56:06 --> Helper loaded: string_helper
INFO - 2019-07-03 16:56:06 --> Helper loaded: string_helper
INFO - 2019-07-03 16:56:06 --> Helper loaded: array_helper
INFO - 2019-07-03 16:56:06 --> Helper loaded: array_helper
INFO - 2019-07-03 16:56:06 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 16:56:06 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 16:56:06 --> Database Driver Class Initialized
INFO - 2019-07-03 16:56:06 --> Controller Class Initialized
INFO - 2019-07-03 22:56:06 --> Helper loaded: language_helper
INFO - 2019-07-03 22:56:06 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 22:56:06 --> Model Class Initialized
INFO - 2019-07-03 22:56:06 --> Model Class Initialized
INFO - 2019-07-03 22:56:06 --> Model Class Initialized
INFO - 2019-07-03 22:56:06 --> Model Class Initialized
INFO - 2019-07-03 22:56:06 --> Model Class Initialized
INFO - 2019-07-03 22:56:06 --> Final output sent to browser
DEBUG - 2019-07-03 22:56:06 --> Total execution time: 0.5625
INFO - 2019-07-03 16:56:06 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 16:56:06 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 16:56:06 --> Database Driver Class Initialized
INFO - 2019-07-03 16:56:06 --> Controller Class Initialized
INFO - 2019-07-03 22:56:06 --> Helper loaded: language_helper
INFO - 2019-07-03 22:56:06 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 22:56:06 --> Model Class Initialized
INFO - 2019-07-03 22:56:06 --> Model Class Initialized
INFO - 2019-07-03 22:56:06 --> Model Class Initialized
INFO - 2019-07-03 22:56:06 --> Model Class Initialized
INFO - 2019-07-03 22:56:06 --> Final output sent to browser
DEBUG - 2019-07-03 22:56:06 --> Total execution time: 0.7035
INFO - 2019-07-03 16:56:08 --> Config Class Initialized
INFO - 2019-07-03 16:56:08 --> Hooks Class Initialized
DEBUG - 2019-07-03 16:56:08 --> UTF-8 Support Enabled
INFO - 2019-07-03 16:56:08 --> Utf8 Class Initialized
INFO - 2019-07-03 16:56:08 --> URI Class Initialized
INFO - 2019-07-03 16:56:08 --> Router Class Initialized
INFO - 2019-07-03 16:56:08 --> Output Class Initialized
INFO - 2019-07-03 16:56:08 --> Security Class Initialized
DEBUG - 2019-07-03 16:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 16:56:08 --> Input Class Initialized
INFO - 2019-07-03 16:56:08 --> Language Class Initialized
INFO - 2019-07-03 16:56:08 --> Language Class Initialized
INFO - 2019-07-03 16:56:08 --> Config Class Initialized
INFO - 2019-07-03 16:56:08 --> Loader Class Initialized
DEBUG - 2019-07-03 16:56:08 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 16:56:08 --> Helper loaded: url_helper
INFO - 2019-07-03 16:56:08 --> Helper loaded: inflector_helper
INFO - 2019-07-03 16:56:08 --> Helper loaded: string_helper
INFO - 2019-07-03 16:56:08 --> Helper loaded: array_helper
INFO - 2019-07-03 16:56:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 16:56:08 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 16:56:08 --> Database Driver Class Initialized
INFO - 2019-07-03 16:56:08 --> Controller Class Initialized
INFO - 2019-07-03 22:56:08 --> Helper loaded: language_helper
INFO - 2019-07-03 22:56:08 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 22:56:08 --> Model Class Initialized
INFO - 2019-07-03 22:56:08 --> Model Class Initialized
INFO - 2019-07-03 22:56:08 --> Model Class Initialized
INFO - 2019-07-03 22:56:08 --> Model Class Initialized
INFO - 2019-07-03 22:56:08 --> Model Class Initialized
INFO - 2019-07-03 22:56:08 --> Final output sent to browser
DEBUG - 2019-07-03 22:56:08 --> Total execution time: 0.4154
INFO - 2019-07-03 16:56:08 --> Config Class Initialized
INFO - 2019-07-03 16:56:08 --> Hooks Class Initialized
DEBUG - 2019-07-03 16:56:08 --> UTF-8 Support Enabled
INFO - 2019-07-03 16:56:08 --> Utf8 Class Initialized
INFO - 2019-07-03 16:56:08 --> URI Class Initialized
INFO - 2019-07-03 16:56:08 --> Router Class Initialized
INFO - 2019-07-03 16:56:08 --> Output Class Initialized
INFO - 2019-07-03 16:56:08 --> Security Class Initialized
DEBUG - 2019-07-03 16:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 16:56:08 --> Input Class Initialized
INFO - 2019-07-03 16:56:08 --> Language Class Initialized
INFO - 2019-07-03 16:56:08 --> Language Class Initialized
INFO - 2019-07-03 16:56:08 --> Config Class Initialized
INFO - 2019-07-03 16:56:08 --> Loader Class Initialized
DEBUG - 2019-07-03 16:56:08 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 16:56:08 --> Helper loaded: url_helper
INFO - 2019-07-03 16:56:08 --> Helper loaded: inflector_helper
INFO - 2019-07-03 16:56:08 --> Helper loaded: string_helper
INFO - 2019-07-03 16:56:08 --> Helper loaded: array_helper
INFO - 2019-07-03 16:56:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 16:56:08 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 16:56:08 --> Database Driver Class Initialized
INFO - 2019-07-03 16:56:08 --> Controller Class Initialized
INFO - 2019-07-03 22:56:08 --> Helper loaded: language_helper
INFO - 2019-07-03 22:56:09 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 22:56:09 --> Model Class Initialized
INFO - 2019-07-03 22:56:09 --> Model Class Initialized
INFO - 2019-07-03 22:56:09 --> Model Class Initialized
INFO - 2019-07-03 22:56:09 --> Model Class Initialized
INFO - 2019-07-03 22:56:09 --> Helper loaded: form_helper
INFO - 2019-07-03 22:56:09 --> Form Validation Class Initialized
DEBUG - 2019-07-03 22:56:09 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-03 22:56:09 --> Model Class Initialized
INFO - 2019-07-03 22:56:09 --> Model Class Initialized
INFO - 2019-07-03 22:56:09 --> Final output sent to browser
DEBUG - 2019-07-03 22:56:09 --> Total execution time: 0.4762
INFO - 2019-07-03 16:56:38 --> Config Class Initialized
INFO - 2019-07-03 16:56:38 --> Hooks Class Initialized
DEBUG - 2019-07-03 16:56:38 --> UTF-8 Support Enabled
INFO - 2019-07-03 16:56:38 --> Utf8 Class Initialized
INFO - 2019-07-03 16:56:38 --> URI Class Initialized
INFO - 2019-07-03 16:56:38 --> Router Class Initialized
INFO - 2019-07-03 16:56:38 --> Output Class Initialized
INFO - 2019-07-03 16:56:38 --> Security Class Initialized
DEBUG - 2019-07-03 16:56:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 16:56:38 --> Input Class Initialized
INFO - 2019-07-03 16:56:38 --> Language Class Initialized
INFO - 2019-07-03 16:56:38 --> Language Class Initialized
INFO - 2019-07-03 16:56:38 --> Config Class Initialized
INFO - 2019-07-03 16:56:38 --> Loader Class Initialized
DEBUG - 2019-07-03 16:56:38 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 16:56:38 --> Helper loaded: url_helper
INFO - 2019-07-03 16:56:38 --> Helper loaded: inflector_helper
INFO - 2019-07-03 16:56:38 --> Helper loaded: string_helper
INFO - 2019-07-03 16:56:38 --> Helper loaded: array_helper
INFO - 2019-07-03 16:56:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 16:56:38 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 16:56:38 --> Database Driver Class Initialized
INFO - 2019-07-03 16:56:38 --> Controller Class Initialized
INFO - 2019-07-03 22:56:38 --> Helper loaded: language_helper
INFO - 2019-07-03 22:56:38 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 22:56:38 --> Model Class Initialized
INFO - 2019-07-03 22:56:38 --> Model Class Initialized
INFO - 2019-07-03 22:56:38 --> Model Class Initialized
INFO - 2019-07-03 22:56:38 --> Model Class Initialized
INFO - 2019-07-03 22:56:38 --> Model Class Initialized
INFO - 2019-07-03 22:56:38 --> Final output sent to browser
DEBUG - 2019-07-03 22:56:38 --> Total execution time: 0.3843
INFO - 2019-07-03 16:56:38 --> Config Class Initialized
INFO - 2019-07-03 16:56:38 --> Hooks Class Initialized
DEBUG - 2019-07-03 16:56:38 --> UTF-8 Support Enabled
INFO - 2019-07-03 16:56:38 --> Utf8 Class Initialized
INFO - 2019-07-03 16:56:38 --> URI Class Initialized
INFO - 2019-07-03 16:56:38 --> Router Class Initialized
INFO - 2019-07-03 16:56:38 --> Output Class Initialized
INFO - 2019-07-03 16:56:38 --> Security Class Initialized
DEBUG - 2019-07-03 16:56:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 16:56:38 --> Input Class Initialized
INFO - 2019-07-03 16:56:38 --> Language Class Initialized
INFO - 2019-07-03 16:56:38 --> Language Class Initialized
INFO - 2019-07-03 16:56:38 --> Config Class Initialized
INFO - 2019-07-03 16:56:38 --> Loader Class Initialized
DEBUG - 2019-07-03 16:56:38 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 16:56:38 --> Helper loaded: url_helper
INFO - 2019-07-03 16:56:39 --> Helper loaded: inflector_helper
INFO - 2019-07-03 16:56:39 --> Helper loaded: string_helper
INFO - 2019-07-03 16:56:39 --> Helper loaded: array_helper
INFO - 2019-07-03 16:56:39 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 16:56:39 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 16:56:39 --> Database Driver Class Initialized
INFO - 2019-07-03 16:56:39 --> Controller Class Initialized
INFO - 2019-07-03 22:56:39 --> Helper loaded: language_helper
INFO - 2019-07-03 22:56:39 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 22:56:39 --> Model Class Initialized
INFO - 2019-07-03 22:56:39 --> Model Class Initialized
INFO - 2019-07-03 22:56:39 --> Model Class Initialized
INFO - 2019-07-03 22:56:39 --> Model Class Initialized
INFO - 2019-07-03 22:56:39 --> Helper loaded: form_helper
INFO - 2019-07-03 22:56:39 --> Form Validation Class Initialized
DEBUG - 2019-07-03 22:56:39 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-03 22:56:39 --> Model Class Initialized
INFO - 2019-07-03 22:56:39 --> Model Class Initialized
INFO - 2019-07-03 22:56:39 --> Final output sent to browser
DEBUG - 2019-07-03 22:56:39 --> Total execution time: 0.4546
INFO - 2019-07-03 16:57:03 --> Config Class Initialized
INFO - 2019-07-03 16:57:03 --> Hooks Class Initialized
DEBUG - 2019-07-03 16:57:03 --> UTF-8 Support Enabled
INFO - 2019-07-03 16:57:03 --> Utf8 Class Initialized
INFO - 2019-07-03 16:57:03 --> URI Class Initialized
INFO - 2019-07-03 16:57:03 --> Router Class Initialized
INFO - 2019-07-03 16:57:03 --> Output Class Initialized
INFO - 2019-07-03 16:57:03 --> Security Class Initialized
DEBUG - 2019-07-03 16:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 16:57:03 --> Input Class Initialized
INFO - 2019-07-03 16:57:03 --> Language Class Initialized
INFO - 2019-07-03 16:57:03 --> Language Class Initialized
INFO - 2019-07-03 16:57:03 --> Config Class Initialized
INFO - 2019-07-03 16:57:03 --> Loader Class Initialized
DEBUG - 2019-07-03 16:57:03 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 16:57:03 --> Helper loaded: url_helper
INFO - 2019-07-03 16:57:03 --> Helper loaded: inflector_helper
INFO - 2019-07-03 16:57:03 --> Helper loaded: string_helper
INFO - 2019-07-03 16:57:03 --> Helper loaded: array_helper
INFO - 2019-07-03 16:57:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 16:57:03 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 16:57:03 --> Database Driver Class Initialized
INFO - 2019-07-03 16:57:03 --> Controller Class Initialized
INFO - 2019-07-03 22:57:03 --> Helper loaded: language_helper
INFO - 2019-07-03 22:57:03 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 22:57:03 --> Model Class Initialized
INFO - 2019-07-03 22:57:03 --> Model Class Initialized
INFO - 2019-07-03 22:57:03 --> Model Class Initialized
INFO - 2019-07-03 22:57:03 --> Model Class Initialized
INFO - 2019-07-03 22:57:03 --> Model Class Initialized
INFO - 2019-07-03 22:57:03 --> Final output sent to browser
DEBUG - 2019-07-03 22:57:03 --> Total execution time: 0.4109
INFO - 2019-07-03 16:57:03 --> Config Class Initialized
INFO - 2019-07-03 16:57:03 --> Hooks Class Initialized
DEBUG - 2019-07-03 16:57:03 --> UTF-8 Support Enabled
INFO - 2019-07-03 16:57:03 --> Utf8 Class Initialized
INFO - 2019-07-03 16:57:03 --> URI Class Initialized
INFO - 2019-07-03 16:57:03 --> Router Class Initialized
INFO - 2019-07-03 16:57:03 --> Output Class Initialized
INFO - 2019-07-03 16:57:03 --> Security Class Initialized
DEBUG - 2019-07-03 16:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 16:57:03 --> Input Class Initialized
INFO - 2019-07-03 16:57:03 --> Language Class Initialized
INFO - 2019-07-03 16:57:03 --> Language Class Initialized
INFO - 2019-07-03 16:57:03 --> Config Class Initialized
INFO - 2019-07-03 16:57:03 --> Loader Class Initialized
DEBUG - 2019-07-03 16:57:03 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 16:57:03 --> Helper loaded: url_helper
INFO - 2019-07-03 16:57:03 --> Helper loaded: inflector_helper
INFO - 2019-07-03 16:57:03 --> Helper loaded: string_helper
INFO - 2019-07-03 16:57:03 --> Helper loaded: array_helper
INFO - 2019-07-03 16:57:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 16:57:04 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 16:57:04 --> Database Driver Class Initialized
INFO - 2019-07-03 16:57:04 --> Controller Class Initialized
INFO - 2019-07-03 22:57:04 --> Helper loaded: language_helper
INFO - 2019-07-03 22:57:04 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 22:57:04 --> Model Class Initialized
INFO - 2019-07-03 22:57:04 --> Model Class Initialized
INFO - 2019-07-03 22:57:04 --> Model Class Initialized
INFO - 2019-07-03 22:57:04 --> Model Class Initialized
INFO - 2019-07-03 22:57:04 --> Model Class Initialized
INFO - 2019-07-03 22:57:04 --> Final output sent to browser
DEBUG - 2019-07-03 22:57:04 --> Total execution time: 0.4218
INFO - 2019-07-03 16:57:05 --> Config Class Initialized
INFO - 2019-07-03 16:57:05 --> Hooks Class Initialized
DEBUG - 2019-07-03 16:57:05 --> UTF-8 Support Enabled
INFO - 2019-07-03 16:57:05 --> Utf8 Class Initialized
INFO - 2019-07-03 16:57:05 --> URI Class Initialized
INFO - 2019-07-03 16:57:05 --> Router Class Initialized
INFO - 2019-07-03 16:57:05 --> Output Class Initialized
INFO - 2019-07-03 16:57:05 --> Security Class Initialized
DEBUG - 2019-07-03 16:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 16:57:05 --> Input Class Initialized
INFO - 2019-07-03 16:57:05 --> Language Class Initialized
INFO - 2019-07-03 16:57:05 --> Language Class Initialized
INFO - 2019-07-03 16:57:05 --> Config Class Initialized
INFO - 2019-07-03 16:57:05 --> Loader Class Initialized
DEBUG - 2019-07-03 16:57:05 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 16:57:05 --> Helper loaded: url_helper
INFO - 2019-07-03 16:57:05 --> Helper loaded: inflector_helper
INFO - 2019-07-03 16:57:05 --> Helper loaded: string_helper
INFO - 2019-07-03 16:57:05 --> Helper loaded: array_helper
INFO - 2019-07-03 16:57:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 16:57:05 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 16:57:05 --> Database Driver Class Initialized
INFO - 2019-07-03 16:57:05 --> Controller Class Initialized
INFO - 2019-07-03 22:57:05 --> Helper loaded: language_helper
INFO - 2019-07-03 22:57:05 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 22:57:05 --> Model Class Initialized
INFO - 2019-07-03 22:57:05 --> Model Class Initialized
INFO - 2019-07-03 22:57:05 --> Model Class Initialized
INFO - 2019-07-03 22:57:05 --> Model Class Initialized
INFO - 2019-07-03 22:57:05 --> Model Class Initialized
INFO - 2019-07-03 22:57:05 --> Final output sent to browser
DEBUG - 2019-07-03 22:57:05 --> Total execution time: 0.4087
INFO - 2019-07-03 16:57:45 --> Config Class Initialized
INFO - 2019-07-03 16:57:45 --> Hooks Class Initialized
DEBUG - 2019-07-03 16:57:45 --> UTF-8 Support Enabled
INFO - 2019-07-03 16:57:45 --> Utf8 Class Initialized
INFO - 2019-07-03 16:57:45 --> URI Class Initialized
INFO - 2019-07-03 16:57:45 --> Router Class Initialized
INFO - 2019-07-03 16:57:45 --> Output Class Initialized
INFO - 2019-07-03 16:57:45 --> Security Class Initialized
DEBUG - 2019-07-03 16:57:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 16:57:45 --> Input Class Initialized
INFO - 2019-07-03 16:57:45 --> Language Class Initialized
INFO - 2019-07-03 16:57:45 --> Language Class Initialized
INFO - 2019-07-03 16:57:45 --> Config Class Initialized
INFO - 2019-07-03 16:57:45 --> Loader Class Initialized
DEBUG - 2019-07-03 16:57:45 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 16:57:45 --> Helper loaded: url_helper
INFO - 2019-07-03 16:57:45 --> Helper loaded: inflector_helper
INFO - 2019-07-03 16:57:45 --> Helper loaded: string_helper
INFO - 2019-07-03 16:57:45 --> Helper loaded: array_helper
INFO - 2019-07-03 16:57:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 16:57:45 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 16:57:45 --> Database Driver Class Initialized
INFO - 2019-07-03 16:57:45 --> Controller Class Initialized
INFO - 2019-07-03 22:57:45 --> Helper loaded: language_helper
INFO - 2019-07-03 22:57:45 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 22:57:45 --> Model Class Initialized
INFO - 2019-07-03 22:57:45 --> Model Class Initialized
INFO - 2019-07-03 22:57:45 --> Model Class Initialized
INFO - 2019-07-03 22:57:45 --> Model Class Initialized
INFO - 2019-07-03 22:57:45 --> Model Class Initialized
INFO - 2019-07-03 22:57:45 --> Final output sent to browser
DEBUG - 2019-07-03 22:57:45 --> Total execution time: 0.4188
INFO - 2019-07-03 16:57:45 --> Config Class Initialized
INFO - 2019-07-03 16:57:45 --> Hooks Class Initialized
DEBUG - 2019-07-03 16:57:45 --> UTF-8 Support Enabled
INFO - 2019-07-03 16:57:45 --> Utf8 Class Initialized
INFO - 2019-07-03 16:57:45 --> URI Class Initialized
INFO - 2019-07-03 16:57:45 --> Router Class Initialized
INFO - 2019-07-03 16:57:45 --> Output Class Initialized
INFO - 2019-07-03 16:57:45 --> Security Class Initialized
DEBUG - 2019-07-03 16:57:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 16:57:46 --> Input Class Initialized
INFO - 2019-07-03 16:57:46 --> Language Class Initialized
INFO - 2019-07-03 16:57:46 --> Language Class Initialized
INFO - 2019-07-03 16:57:46 --> Config Class Initialized
INFO - 2019-07-03 16:57:46 --> Loader Class Initialized
DEBUG - 2019-07-03 16:57:46 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 16:57:46 --> Config Class Initialized
INFO - 2019-07-03 16:57:46 --> Helper loaded: url_helper
INFO - 2019-07-03 16:57:46 --> Hooks Class Initialized
INFO - 2019-07-03 16:57:46 --> Helper loaded: inflector_helper
INFO - 2019-07-03 16:57:46 --> Helper loaded: string_helper
INFO - 2019-07-03 16:57:46 --> Helper loaded: array_helper
INFO - 2019-07-03 16:57:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 16:57:46 --> UTF-8 Support Enabled
DEBUG - 2019-07-03 16:57:46 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 16:57:46 --> Utf8 Class Initialized
INFO - 2019-07-03 16:57:46 --> Database Driver Class Initialized
INFO - 2019-07-03 16:57:46 --> URI Class Initialized
INFO - 2019-07-03 16:57:46 --> Controller Class Initialized
INFO - 2019-07-03 16:57:46 --> Router Class Initialized
INFO - 2019-07-03 22:57:46 --> Helper loaded: language_helper
INFO - 2019-07-03 16:57:46 --> Output Class Initialized
INFO - 2019-07-03 22:57:46 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 16:57:46 --> Security Class Initialized
INFO - 2019-07-03 22:57:46 --> Model Class Initialized
DEBUG - 2019-07-03 16:57:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 22:57:46 --> Model Class Initialized
INFO - 2019-07-03 16:57:46 --> Input Class Initialized
INFO - 2019-07-03 16:57:46 --> Language Class Initialized
INFO - 2019-07-03 22:57:46 --> Model Class Initialized
INFO - 2019-07-03 16:57:46 --> Language Class Initialized
INFO - 2019-07-03 22:57:46 --> Model Class Initialized
INFO - 2019-07-03 16:57:46 --> Config Class Initialized
INFO - 2019-07-03 16:57:46 --> Loader Class Initialized
INFO - 2019-07-03 22:57:46 --> Model Class Initialized
DEBUG - 2019-07-03 16:57:46 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 22:57:46 --> Final output sent to browser
INFO - 2019-07-03 16:57:46 --> Helper loaded: url_helper
DEBUG - 2019-07-03 22:57:46 --> Total execution time: 0.7136
INFO - 2019-07-03 16:57:46 --> Helper loaded: inflector_helper
INFO - 2019-07-03 16:57:46 --> Helper loaded: string_helper
INFO - 2019-07-03 16:57:46 --> Helper loaded: array_helper
INFO - 2019-07-03 16:57:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 16:57:46 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 16:57:46 --> Database Driver Class Initialized
INFO - 2019-07-03 16:57:46 --> Controller Class Initialized
INFO - 2019-07-03 22:57:46 --> Helper loaded: language_helper
INFO - 2019-07-03 22:57:46 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 22:57:46 --> Model Class Initialized
INFO - 2019-07-03 22:57:46 --> Model Class Initialized
INFO - 2019-07-03 22:57:46 --> Model Class Initialized
INFO - 2019-07-03 22:57:46 --> Model Class Initialized
INFO - 2019-07-03 22:57:46 --> Model Class Initialized
INFO - 2019-07-03 22:57:46 --> Final output sent to browser
DEBUG - 2019-07-03 22:57:46 --> Total execution time: 0.5763
INFO - 2019-07-03 16:57:46 --> Config Class Initialized
INFO - 2019-07-03 16:57:46 --> Hooks Class Initialized
DEBUG - 2019-07-03 16:57:46 --> UTF-8 Support Enabled
INFO - 2019-07-03 16:57:46 --> Utf8 Class Initialized
INFO - 2019-07-03 16:57:46 --> URI Class Initialized
INFO - 2019-07-03 16:57:46 --> Router Class Initialized
INFO - 2019-07-03 16:57:46 --> Output Class Initialized
INFO - 2019-07-03 16:57:46 --> Security Class Initialized
DEBUG - 2019-07-03 16:57:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 16:57:46 --> Input Class Initialized
INFO - 2019-07-03 16:57:47 --> Language Class Initialized
INFO - 2019-07-03 16:57:47 --> Language Class Initialized
INFO - 2019-07-03 16:57:47 --> Config Class Initialized
INFO - 2019-07-03 16:57:47 --> Loader Class Initialized
DEBUG - 2019-07-03 16:57:47 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 16:57:47 --> Helper loaded: url_helper
INFO - 2019-07-03 16:57:47 --> Helper loaded: inflector_helper
INFO - 2019-07-03 16:57:47 --> Helper loaded: string_helper
INFO - 2019-07-03 16:57:47 --> Helper loaded: array_helper
INFO - 2019-07-03 16:57:47 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 16:57:47 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 16:57:47 --> Database Driver Class Initialized
INFO - 2019-07-03 16:57:47 --> Controller Class Initialized
INFO - 2019-07-03 22:57:47 --> Helper loaded: language_helper
INFO - 2019-07-03 22:57:47 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 22:57:47 --> Model Class Initialized
INFO - 2019-07-03 22:57:47 --> Model Class Initialized
INFO - 2019-07-03 22:57:47 --> Model Class Initialized
INFO - 2019-07-03 22:57:47 --> Model Class Initialized
INFO - 2019-07-03 22:57:47 --> Model Class Initialized
INFO - 2019-07-03 22:57:47 --> Final output sent to browser
DEBUG - 2019-07-03 22:57:47 --> Total execution time: 0.4274
INFO - 2019-07-03 16:57:54 --> Config Class Initialized
INFO - 2019-07-03 16:57:54 --> Hooks Class Initialized
DEBUG - 2019-07-03 16:57:54 --> UTF-8 Support Enabled
INFO - 2019-07-03 16:57:54 --> Utf8 Class Initialized
INFO - 2019-07-03 16:57:54 --> URI Class Initialized
INFO - 2019-07-03 16:57:54 --> Router Class Initialized
INFO - 2019-07-03 16:57:54 --> Output Class Initialized
INFO - 2019-07-03 16:57:54 --> Security Class Initialized
DEBUG - 2019-07-03 16:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 16:57:54 --> Input Class Initialized
INFO - 2019-07-03 16:57:54 --> Language Class Initialized
INFO - 2019-07-03 16:57:54 --> Language Class Initialized
INFO - 2019-07-03 16:57:54 --> Config Class Initialized
INFO - 2019-07-03 16:57:54 --> Loader Class Initialized
DEBUG - 2019-07-03 16:57:54 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 16:57:54 --> Helper loaded: url_helper
INFO - 2019-07-03 16:57:54 --> Helper loaded: inflector_helper
INFO - 2019-07-03 16:57:54 --> Helper loaded: string_helper
INFO - 2019-07-03 16:57:54 --> Helper loaded: array_helper
INFO - 2019-07-03 16:57:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 16:57:54 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 16:57:54 --> Database Driver Class Initialized
INFO - 2019-07-03 16:57:54 --> Controller Class Initialized
INFO - 2019-07-03 22:57:54 --> Helper loaded: language_helper
INFO - 2019-07-03 22:57:54 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 22:57:54 --> Model Class Initialized
INFO - 2019-07-03 22:57:54 --> Model Class Initialized
INFO - 2019-07-03 22:57:54 --> Model Class Initialized
INFO - 2019-07-03 22:57:54 --> Model Class Initialized
INFO - 2019-07-03 22:57:54 --> Model Class Initialized
INFO - 2019-07-03 22:57:54 --> Final output sent to browser
DEBUG - 2019-07-03 22:57:54 --> Total execution time: 0.4426
INFO - 2019-07-03 16:57:54 --> Config Class Initialized
INFO - 2019-07-03 16:57:54 --> Hooks Class Initialized
DEBUG - 2019-07-03 16:57:54 --> UTF-8 Support Enabled
INFO - 2019-07-03 16:57:54 --> Utf8 Class Initialized
INFO - 2019-07-03 16:57:54 --> URI Class Initialized
INFO - 2019-07-03 16:57:55 --> Router Class Initialized
INFO - 2019-07-03 16:57:55 --> Output Class Initialized
INFO - 2019-07-03 16:57:55 --> Security Class Initialized
DEBUG - 2019-07-03 16:57:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 16:57:55 --> Input Class Initialized
INFO - 2019-07-03 16:57:55 --> Language Class Initialized
INFO - 2019-07-03 16:57:55 --> Language Class Initialized
INFO - 2019-07-03 16:57:55 --> Config Class Initialized
INFO - 2019-07-03 16:57:55 --> Loader Class Initialized
DEBUG - 2019-07-03 16:57:55 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 16:57:55 --> Helper loaded: url_helper
INFO - 2019-07-03 16:57:55 --> Helper loaded: inflector_helper
INFO - 2019-07-03 16:57:55 --> Helper loaded: string_helper
INFO - 2019-07-03 16:57:55 --> Helper loaded: array_helper
INFO - 2019-07-03 16:57:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 16:57:55 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 16:57:55 --> Database Driver Class Initialized
INFO - 2019-07-03 16:57:55 --> Controller Class Initialized
INFO - 2019-07-03 22:57:55 --> Helper loaded: language_helper
INFO - 2019-07-03 22:57:55 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 22:57:55 --> Model Class Initialized
INFO - 2019-07-03 22:57:55 --> Model Class Initialized
INFO - 2019-07-03 22:57:55 --> Model Class Initialized
INFO - 2019-07-03 22:57:55 --> Model Class Initialized
INFO - 2019-07-03 22:57:55 --> Helper loaded: form_helper
INFO - 2019-07-03 22:57:55 --> Form Validation Class Initialized
DEBUG - 2019-07-03 22:57:55 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-03 22:57:55 --> Model Class Initialized
INFO - 2019-07-03 22:57:55 --> Model Class Initialized
INFO - 2019-07-03 22:57:55 --> Final output sent to browser
DEBUG - 2019-07-03 22:57:55 --> Total execution time: 0.4886
INFO - 2019-07-03 16:58:54 --> Config Class Initialized
INFO - 2019-07-03 16:58:54 --> Hooks Class Initialized
DEBUG - 2019-07-03 16:58:54 --> UTF-8 Support Enabled
INFO - 2019-07-03 16:58:54 --> Utf8 Class Initialized
INFO - 2019-07-03 16:58:54 --> URI Class Initialized
INFO - 2019-07-03 16:58:54 --> Router Class Initialized
INFO - 2019-07-03 16:58:54 --> Output Class Initialized
INFO - 2019-07-03 16:58:54 --> Security Class Initialized
DEBUG - 2019-07-03 16:58:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 16:58:54 --> Input Class Initialized
INFO - 2019-07-03 16:58:54 --> Language Class Initialized
INFO - 2019-07-03 16:58:54 --> Language Class Initialized
INFO - 2019-07-03 16:58:54 --> Config Class Initialized
INFO - 2019-07-03 16:58:54 --> Loader Class Initialized
DEBUG - 2019-07-03 16:58:54 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 16:58:54 --> Helper loaded: url_helper
INFO - 2019-07-03 16:58:54 --> Helper loaded: inflector_helper
INFO - 2019-07-03 16:58:54 --> Helper loaded: string_helper
INFO - 2019-07-03 16:58:54 --> Helper loaded: array_helper
INFO - 2019-07-03 16:58:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 16:58:54 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 16:58:54 --> Database Driver Class Initialized
INFO - 2019-07-03 16:58:54 --> Controller Class Initialized
INFO - 2019-07-03 22:58:54 --> Helper loaded: language_helper
INFO - 2019-07-03 22:58:54 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 22:58:54 --> Model Class Initialized
INFO - 2019-07-03 22:58:54 --> Model Class Initialized
INFO - 2019-07-03 22:58:54 --> Model Class Initialized
INFO - 2019-07-03 22:58:54 --> Model Class Initialized
INFO - 2019-07-03 22:58:54 --> Model Class Initialized
INFO - 2019-07-03 22:58:54 --> Final output sent to browser
DEBUG - 2019-07-03 22:58:55 --> Total execution time: 0.4144
INFO - 2019-07-03 16:58:55 --> Config Class Initialized
INFO - 2019-07-03 16:58:55 --> Hooks Class Initialized
DEBUG - 2019-07-03 16:58:55 --> UTF-8 Support Enabled
INFO - 2019-07-03 16:58:55 --> Utf8 Class Initialized
INFO - 2019-07-03 16:58:55 --> URI Class Initialized
INFO - 2019-07-03 16:58:55 --> Router Class Initialized
INFO - 2019-07-03 16:58:55 --> Output Class Initialized
INFO - 2019-07-03 16:58:55 --> Security Class Initialized
DEBUG - 2019-07-03 16:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 16:58:55 --> Input Class Initialized
INFO - 2019-07-03 16:58:55 --> Language Class Initialized
INFO - 2019-07-03 16:58:55 --> Language Class Initialized
INFO - 2019-07-03 16:58:55 --> Config Class Initialized
INFO - 2019-07-03 16:58:55 --> Loader Class Initialized
DEBUG - 2019-07-03 16:58:55 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 16:58:55 --> Helper loaded: url_helper
INFO - 2019-07-03 16:58:55 --> Helper loaded: inflector_helper
INFO - 2019-07-03 16:58:55 --> Helper loaded: string_helper
INFO - 2019-07-03 16:58:55 --> Helper loaded: array_helper
INFO - 2019-07-03 16:58:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 16:58:55 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 16:58:55 --> Database Driver Class Initialized
INFO - 2019-07-03 16:58:55 --> Controller Class Initialized
INFO - 2019-07-03 22:58:55 --> Helper loaded: language_helper
INFO - 2019-07-03 22:58:55 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 22:58:55 --> Model Class Initialized
INFO - 2019-07-03 22:58:55 --> Model Class Initialized
INFO - 2019-07-03 22:58:55 --> Model Class Initialized
INFO - 2019-07-03 22:58:55 --> Model Class Initialized
INFO - 2019-07-03 22:58:55 --> Helper loaded: form_helper
INFO - 2019-07-03 22:58:55 --> Form Validation Class Initialized
DEBUG - 2019-07-03 22:58:55 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-03 22:58:55 --> Model Class Initialized
INFO - 2019-07-03 22:58:55 --> Model Class Initialized
INFO - 2019-07-03 22:58:55 --> Final output sent to browser
DEBUG - 2019-07-03 22:58:55 --> Total execution time: 0.4741
INFO - 2019-07-03 17:00:18 --> Config Class Initialized
INFO - 2019-07-03 17:00:18 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:00:18 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:00:18 --> Utf8 Class Initialized
INFO - 2019-07-03 17:00:18 --> URI Class Initialized
INFO - 2019-07-03 17:00:18 --> Router Class Initialized
INFO - 2019-07-03 17:00:18 --> Output Class Initialized
INFO - 2019-07-03 17:00:18 --> Security Class Initialized
DEBUG - 2019-07-03 17:00:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:00:18 --> Input Class Initialized
INFO - 2019-07-03 17:00:18 --> Language Class Initialized
INFO - 2019-07-03 17:00:18 --> Language Class Initialized
INFO - 2019-07-03 17:00:18 --> Config Class Initialized
INFO - 2019-07-03 17:00:18 --> Loader Class Initialized
DEBUG - 2019-07-03 17:00:18 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:00:18 --> Helper loaded: url_helper
INFO - 2019-07-03 17:00:18 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:00:18 --> Helper loaded: string_helper
INFO - 2019-07-03 17:00:19 --> Helper loaded: array_helper
INFO - 2019-07-03 17:00:19 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:00:19 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:00:19 --> Database Driver Class Initialized
INFO - 2019-07-03 17:00:19 --> Controller Class Initialized
INFO - 2019-07-03 23:00:19 --> Helper loaded: language_helper
INFO - 2019-07-03 23:00:19 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:00:19 --> Model Class Initialized
INFO - 2019-07-03 23:00:19 --> Model Class Initialized
INFO - 2019-07-03 23:00:19 --> Model Class Initialized
INFO - 2019-07-03 23:00:19 --> Model Class Initialized
INFO - 2019-07-03 23:00:19 --> Model Class Initialized
INFO - 2019-07-03 23:00:19 --> Final output sent to browser
DEBUG - 2019-07-03 23:00:19 --> Total execution time: 0.4025
INFO - 2019-07-03 17:00:19 --> Config Class Initialized
INFO - 2019-07-03 17:00:19 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:00:19 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:00:19 --> Utf8 Class Initialized
INFO - 2019-07-03 17:00:19 --> URI Class Initialized
INFO - 2019-07-03 17:00:19 --> Router Class Initialized
INFO - 2019-07-03 17:00:19 --> Output Class Initialized
INFO - 2019-07-03 17:00:19 --> Security Class Initialized
DEBUG - 2019-07-03 17:00:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:00:19 --> Input Class Initialized
INFO - 2019-07-03 17:00:19 --> Language Class Initialized
INFO - 2019-07-03 17:00:19 --> Language Class Initialized
INFO - 2019-07-03 17:00:19 --> Config Class Initialized
INFO - 2019-07-03 17:00:19 --> Loader Class Initialized
DEBUG - 2019-07-03 17:00:19 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:00:19 --> Helper loaded: url_helper
INFO - 2019-07-03 17:00:19 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:00:19 --> Helper loaded: string_helper
INFO - 2019-07-03 17:00:19 --> Helper loaded: array_helper
INFO - 2019-07-03 17:00:19 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:00:19 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:00:19 --> Database Driver Class Initialized
INFO - 2019-07-03 17:00:19 --> Controller Class Initialized
INFO - 2019-07-03 23:00:19 --> Helper loaded: language_helper
INFO - 2019-07-03 23:00:19 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:00:19 --> Model Class Initialized
INFO - 2019-07-03 23:00:19 --> Model Class Initialized
INFO - 2019-07-03 23:00:19 --> Model Class Initialized
INFO - 2019-07-03 23:00:19 --> Model Class Initialized
INFO - 2019-07-03 23:00:19 --> Helper loaded: form_helper
INFO - 2019-07-03 23:00:19 --> Form Validation Class Initialized
DEBUG - 2019-07-03 23:00:19 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-03 23:00:19 --> Model Class Initialized
INFO - 2019-07-03 23:00:19 --> Model Class Initialized
INFO - 2019-07-03 23:00:19 --> Final output sent to browser
DEBUG - 2019-07-03 23:00:19 --> Total execution time: 0.4726
INFO - 2019-07-03 17:18:22 --> Config Class Initialized
INFO - 2019-07-03 17:18:22 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:18:22 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:18:22 --> Utf8 Class Initialized
INFO - 2019-07-03 17:18:22 --> URI Class Initialized
INFO - 2019-07-03 17:18:22 --> Router Class Initialized
INFO - 2019-07-03 17:18:22 --> Output Class Initialized
INFO - 2019-07-03 17:18:22 --> Security Class Initialized
DEBUG - 2019-07-03 17:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:18:22 --> Input Class Initialized
INFO - 2019-07-03 17:18:22 --> Language Class Initialized
INFO - 2019-07-03 17:18:22 --> Language Class Initialized
INFO - 2019-07-03 17:18:22 --> Config Class Initialized
INFO - 2019-07-03 17:18:22 --> Loader Class Initialized
DEBUG - 2019-07-03 17:18:22 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:18:22 --> Helper loaded: url_helper
INFO - 2019-07-03 17:18:22 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:18:22 --> Helper loaded: string_helper
INFO - 2019-07-03 17:18:22 --> Helper loaded: array_helper
INFO - 2019-07-03 17:18:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:18:22 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:18:22 --> Database Driver Class Initialized
INFO - 2019-07-03 17:18:22 --> Controller Class Initialized
INFO - 2019-07-03 23:18:22 --> Helper loaded: language_helper
INFO - 2019-07-03 23:18:22 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:18:22 --> Model Class Initialized
INFO - 2019-07-03 23:18:22 --> Model Class Initialized
INFO - 2019-07-03 23:18:22 --> Model Class Initialized
INFO - 2019-07-03 23:18:22 --> Model Class Initialized
INFO - 2019-07-03 23:18:22 --> Final output sent to browser
DEBUG - 2019-07-03 23:18:22 --> Total execution time: 0.4442
INFO - 2019-07-03 17:18:22 --> Config Class Initialized
INFO - 2019-07-03 17:18:22 --> Config Class Initialized
INFO - 2019-07-03 17:18:22 --> Hooks Class Initialized
INFO - 2019-07-03 17:18:22 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:18:22 --> UTF-8 Support Enabled
DEBUG - 2019-07-03 17:18:22 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:18:22 --> Utf8 Class Initialized
INFO - 2019-07-03 17:18:22 --> Utf8 Class Initialized
INFO - 2019-07-03 17:18:22 --> URI Class Initialized
INFO - 2019-07-03 17:18:22 --> URI Class Initialized
INFO - 2019-07-03 17:18:22 --> Router Class Initialized
INFO - 2019-07-03 17:18:22 --> Router Class Initialized
INFO - 2019-07-03 17:18:22 --> Output Class Initialized
INFO - 2019-07-03 17:18:23 --> Output Class Initialized
INFO - 2019-07-03 17:18:23 --> Security Class Initialized
INFO - 2019-07-03 17:18:23 --> Security Class Initialized
DEBUG - 2019-07-03 17:18:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:18:23 --> Input Class Initialized
DEBUG - 2019-07-03 17:18:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:18:23 --> Input Class Initialized
INFO - 2019-07-03 17:18:23 --> Language Class Initialized
INFO - 2019-07-03 17:18:23 --> Language Class Initialized
INFO - 2019-07-03 17:18:23 --> Language Class Initialized
INFO - 2019-07-03 17:18:23 --> Config Class Initialized
INFO - 2019-07-03 17:18:23 --> Language Class Initialized
INFO - 2019-07-03 17:18:23 --> Config Class Initialized
INFO - 2019-07-03 17:18:23 --> Loader Class Initialized
INFO - 2019-07-03 17:18:23 --> Loader Class Initialized
DEBUG - 2019-07-03 17:18:23 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-03 17:18:23 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:18:23 --> Helper loaded: url_helper
INFO - 2019-07-03 17:18:23 --> Helper loaded: url_helper
INFO - 2019-07-03 17:18:23 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:18:23 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:18:23 --> Helper loaded: string_helper
INFO - 2019-07-03 17:18:23 --> Helper loaded: string_helper
INFO - 2019-07-03 17:18:23 --> Helper loaded: array_helper
INFO - 2019-07-03 17:18:23 --> Helper loaded: array_helper
INFO - 2019-07-03 17:18:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:18:23 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:18:23 --> Database Driver Class Initialized
INFO - 2019-07-03 17:18:23 --> Controller Class Initialized
INFO - 2019-07-03 23:18:23 --> Helper loaded: language_helper
INFO - 2019-07-03 23:18:23 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:18:23 --> Model Class Initialized
INFO - 2019-07-03 23:18:23 --> Model Class Initialized
INFO - 2019-07-03 23:18:23 --> Model Class Initialized
INFO - 2019-07-03 23:18:23 --> Model Class Initialized
INFO - 2019-07-03 23:18:23 --> Model Class Initialized
INFO - 2019-07-03 23:18:23 --> Final output sent to browser
DEBUG - 2019-07-03 23:18:23 --> Total execution time: 0.6192
INFO - 2019-07-03 17:18:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:18:23 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:18:23 --> Database Driver Class Initialized
INFO - 2019-07-03 17:18:23 --> Controller Class Initialized
INFO - 2019-07-03 23:18:23 --> Helper loaded: language_helper
INFO - 2019-07-03 23:18:23 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:18:23 --> Model Class Initialized
INFO - 2019-07-03 23:18:23 --> Model Class Initialized
INFO - 2019-07-03 23:18:23 --> Model Class Initialized
INFO - 2019-07-03 23:18:23 --> Model Class Initialized
INFO - 2019-07-03 23:18:23 --> Final output sent to browser
DEBUG - 2019-07-03 23:18:23 --> Total execution time: 0.7637
INFO - 2019-07-03 17:18:31 --> Config Class Initialized
INFO - 2019-07-03 17:18:31 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:18:31 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:18:31 --> Utf8 Class Initialized
INFO - 2019-07-03 17:18:31 --> URI Class Initialized
INFO - 2019-07-03 17:18:31 --> Router Class Initialized
INFO - 2019-07-03 17:18:31 --> Output Class Initialized
INFO - 2019-07-03 17:18:31 --> Security Class Initialized
DEBUG - 2019-07-03 17:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:18:31 --> Input Class Initialized
INFO - 2019-07-03 17:18:31 --> Language Class Initialized
INFO - 2019-07-03 17:18:31 --> Language Class Initialized
INFO - 2019-07-03 17:18:31 --> Config Class Initialized
INFO - 2019-07-03 17:18:31 --> Loader Class Initialized
DEBUG - 2019-07-03 17:18:31 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:18:31 --> Helper loaded: url_helper
INFO - 2019-07-03 17:18:31 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:18:31 --> Helper loaded: string_helper
INFO - 2019-07-03 17:18:31 --> Helper loaded: array_helper
INFO - 2019-07-03 17:18:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:18:31 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:18:31 --> Database Driver Class Initialized
INFO - 2019-07-03 17:18:31 --> Controller Class Initialized
INFO - 2019-07-03 23:18:31 --> Helper loaded: language_helper
INFO - 2019-07-03 23:18:31 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:18:31 --> Model Class Initialized
INFO - 2019-07-03 23:18:31 --> Model Class Initialized
INFO - 2019-07-03 23:18:31 --> Model Class Initialized
INFO - 2019-07-03 23:18:31 --> Model Class Initialized
INFO - 2019-07-03 23:18:31 --> Model Class Initialized
INFO - 2019-07-03 23:18:31 --> Final output sent to browser
DEBUG - 2019-07-03 23:18:31 --> Total execution time: 0.4288
INFO - 2019-07-03 17:18:31 --> Config Class Initialized
INFO - 2019-07-03 17:18:31 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:18:31 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:18:31 --> Utf8 Class Initialized
INFO - 2019-07-03 17:18:31 --> URI Class Initialized
INFO - 2019-07-03 17:18:31 --> Router Class Initialized
INFO - 2019-07-03 17:18:31 --> Output Class Initialized
INFO - 2019-07-03 17:18:31 --> Security Class Initialized
DEBUG - 2019-07-03 17:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:18:31 --> Input Class Initialized
INFO - 2019-07-03 17:18:31 --> Language Class Initialized
INFO - 2019-07-03 17:18:31 --> Language Class Initialized
INFO - 2019-07-03 17:18:31 --> Config Class Initialized
INFO - 2019-07-03 17:18:31 --> Loader Class Initialized
DEBUG - 2019-07-03 17:18:31 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:18:31 --> Helper loaded: url_helper
INFO - 2019-07-03 17:18:31 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:18:31 --> Helper loaded: string_helper
INFO - 2019-07-03 17:18:31 --> Helper loaded: array_helper
INFO - 2019-07-03 17:18:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:18:31 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:18:32 --> Database Driver Class Initialized
INFO - 2019-07-03 17:18:32 --> Controller Class Initialized
INFO - 2019-07-03 23:18:32 --> Helper loaded: language_helper
INFO - 2019-07-03 23:18:32 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:18:32 --> Model Class Initialized
INFO - 2019-07-03 23:18:32 --> Model Class Initialized
INFO - 2019-07-03 23:18:32 --> Model Class Initialized
INFO - 2019-07-03 23:18:32 --> Model Class Initialized
INFO - 2019-07-03 23:18:32 --> Model Class Initialized
INFO - 2019-07-03 23:18:32 --> Final output sent to browser
DEBUG - 2019-07-03 23:18:32 --> Total execution time: 0.4291
INFO - 2019-07-03 17:18:35 --> Config Class Initialized
INFO - 2019-07-03 17:18:35 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:18:35 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:18:35 --> Utf8 Class Initialized
INFO - 2019-07-03 17:18:35 --> URI Class Initialized
INFO - 2019-07-03 17:18:35 --> Router Class Initialized
INFO - 2019-07-03 17:18:35 --> Output Class Initialized
INFO - 2019-07-03 17:18:35 --> Security Class Initialized
DEBUG - 2019-07-03 17:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:18:35 --> Input Class Initialized
INFO - 2019-07-03 17:18:35 --> Language Class Initialized
INFO - 2019-07-03 17:18:35 --> Language Class Initialized
INFO - 2019-07-03 17:18:35 --> Config Class Initialized
INFO - 2019-07-03 17:18:35 --> Loader Class Initialized
DEBUG - 2019-07-03 17:18:35 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:18:35 --> Helper loaded: url_helper
INFO - 2019-07-03 17:18:35 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:18:35 --> Helper loaded: string_helper
INFO - 2019-07-03 17:18:35 --> Helper loaded: array_helper
INFO - 2019-07-03 17:18:35 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:18:35 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:18:35 --> Database Driver Class Initialized
INFO - 2019-07-03 17:18:35 --> Controller Class Initialized
INFO - 2019-07-03 23:18:35 --> Helper loaded: language_helper
INFO - 2019-07-03 23:18:35 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:18:35 --> Model Class Initialized
INFO - 2019-07-03 23:18:35 --> Model Class Initialized
INFO - 2019-07-03 23:18:35 --> Model Class Initialized
INFO - 2019-07-03 23:18:35 --> Model Class Initialized
INFO - 2019-07-03 23:18:35 --> Model Class Initialized
INFO - 2019-07-03 23:18:35 --> Final output sent to browser
DEBUG - 2019-07-03 23:18:35 --> Total execution time: 0.4128
INFO - 2019-07-03 17:18:35 --> Config Class Initialized
INFO - 2019-07-03 17:18:35 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:18:35 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:18:35 --> Utf8 Class Initialized
INFO - 2019-07-03 17:18:35 --> URI Class Initialized
INFO - 2019-07-03 17:18:35 --> Router Class Initialized
INFO - 2019-07-03 17:18:35 --> Output Class Initialized
INFO - 2019-07-03 17:18:35 --> Security Class Initialized
DEBUG - 2019-07-03 17:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:18:35 --> Input Class Initialized
INFO - 2019-07-03 17:18:35 --> Language Class Initialized
INFO - 2019-07-03 17:18:35 --> Language Class Initialized
INFO - 2019-07-03 17:18:35 --> Config Class Initialized
INFO - 2019-07-03 17:18:35 --> Loader Class Initialized
DEBUG - 2019-07-03 17:18:35 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:18:35 --> Helper loaded: url_helper
INFO - 2019-07-03 17:18:35 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:18:35 --> Helper loaded: string_helper
INFO - 2019-07-03 17:18:35 --> Helper loaded: array_helper
INFO - 2019-07-03 17:18:35 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:18:35 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:18:36 --> Database Driver Class Initialized
INFO - 2019-07-03 17:18:36 --> Controller Class Initialized
INFO - 2019-07-03 23:18:36 --> Helper loaded: language_helper
INFO - 2019-07-03 23:18:36 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:18:36 --> Model Class Initialized
INFO - 2019-07-03 23:18:36 --> Model Class Initialized
INFO - 2019-07-03 23:18:36 --> Model Class Initialized
INFO - 2019-07-03 23:18:36 --> Model Class Initialized
INFO - 2019-07-03 23:18:36 --> Helper loaded: form_helper
INFO - 2019-07-03 23:18:36 --> Form Validation Class Initialized
DEBUG - 2019-07-03 23:18:36 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-03 23:18:36 --> Model Class Initialized
INFO - 2019-07-03 23:18:36 --> Model Class Initialized
INFO - 2019-07-03 23:18:36 --> Final output sent to browser
DEBUG - 2019-07-03 23:18:36 --> Total execution time: 0.4912
INFO - 2019-07-03 17:22:22 --> Config Class Initialized
INFO - 2019-07-03 17:22:22 --> Config Class Initialized
INFO - 2019-07-03 17:22:22 --> Hooks Class Initialized
INFO - 2019-07-03 17:22:22 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:22:22 --> UTF-8 Support Enabled
DEBUG - 2019-07-03 17:22:22 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:22:22 --> Utf8 Class Initialized
INFO - 2019-07-03 17:22:22 --> Utf8 Class Initialized
INFO - 2019-07-03 17:22:22 --> URI Class Initialized
INFO - 2019-07-03 17:22:22 --> URI Class Initialized
INFO - 2019-07-03 17:22:22 --> Router Class Initialized
INFO - 2019-07-03 17:22:22 --> Router Class Initialized
INFO - 2019-07-03 17:22:22 --> Output Class Initialized
INFO - 2019-07-03 17:22:22 --> Output Class Initialized
INFO - 2019-07-03 17:22:22 --> Security Class Initialized
INFO - 2019-07-03 17:22:22 --> Security Class Initialized
DEBUG - 2019-07-03 17:22:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-03 17:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:22:22 --> Input Class Initialized
INFO - 2019-07-03 17:22:22 --> Input Class Initialized
INFO - 2019-07-03 17:22:22 --> Language Class Initialized
INFO - 2019-07-03 17:22:22 --> Language Class Initialized
INFO - 2019-07-03 17:22:22 --> Language Class Initialized
INFO - 2019-07-03 17:22:22 --> Language Class Initialized
INFO - 2019-07-03 17:22:22 --> Config Class Initialized
INFO - 2019-07-03 17:22:22 --> Config Class Initialized
INFO - 2019-07-03 17:22:22 --> Loader Class Initialized
INFO - 2019-07-03 17:22:22 --> Loader Class Initialized
DEBUG - 2019-07-03 17:22:22 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-03 17:22:22 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:22:22 --> Helper loaded: url_helper
INFO - 2019-07-03 17:22:22 --> Helper loaded: url_helper
INFO - 2019-07-03 17:22:22 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:22:22 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:22:22 --> Helper loaded: string_helper
INFO - 2019-07-03 17:22:23 --> Helper loaded: string_helper
INFO - 2019-07-03 17:22:23 --> Helper loaded: array_helper
INFO - 2019-07-03 17:22:23 --> Helper loaded: array_helper
INFO - 2019-07-03 17:22:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:22:23 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:22:23 --> Database Driver Class Initialized
INFO - 2019-07-03 17:22:23 --> Controller Class Initialized
INFO - 2019-07-03 23:22:23 --> Helper loaded: language_helper
INFO - 2019-07-03 23:22:23 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:22:23 --> Model Class Initialized
INFO - 2019-07-03 23:22:23 --> Model Class Initialized
INFO - 2019-07-03 23:22:23 --> Model Class Initialized
INFO - 2019-07-03 23:22:23 --> Model Class Initialized
INFO - 2019-07-03 23:22:23 --> Model Class Initialized
INFO - 2019-07-03 23:22:23 --> Final output sent to browser
DEBUG - 2019-07-03 23:22:23 --> Total execution time: 0.5972
INFO - 2019-07-03 17:22:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:22:23 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:22:23 --> Database Driver Class Initialized
INFO - 2019-07-03 17:22:23 --> Controller Class Initialized
INFO - 2019-07-03 23:22:23 --> Helper loaded: language_helper
INFO - 2019-07-03 23:22:23 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:22:23 --> Model Class Initialized
INFO - 2019-07-03 23:22:23 --> Model Class Initialized
INFO - 2019-07-03 23:22:23 --> Model Class Initialized
INFO - 2019-07-03 23:22:23 --> Model Class Initialized
INFO - 2019-07-03 23:22:23 --> Final output sent to browser
DEBUG - 2019-07-03 23:22:23 --> Total execution time: 0.7607
INFO - 2019-07-03 17:22:26 --> Config Class Initialized
INFO - 2019-07-03 17:22:26 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:22:26 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:22:26 --> Utf8 Class Initialized
INFO - 2019-07-03 17:22:26 --> URI Class Initialized
INFO - 2019-07-03 17:22:26 --> Router Class Initialized
INFO - 2019-07-03 17:22:26 --> Output Class Initialized
INFO - 2019-07-03 17:22:26 --> Security Class Initialized
DEBUG - 2019-07-03 17:22:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:22:26 --> Input Class Initialized
INFO - 2019-07-03 17:22:26 --> Language Class Initialized
INFO - 2019-07-03 17:22:26 --> Language Class Initialized
INFO - 2019-07-03 17:22:26 --> Config Class Initialized
INFO - 2019-07-03 17:22:26 --> Loader Class Initialized
DEBUG - 2019-07-03 17:22:26 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:22:26 --> Helper loaded: url_helper
INFO - 2019-07-03 17:22:26 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:22:26 --> Helper loaded: string_helper
INFO - 2019-07-03 17:22:26 --> Helper loaded: array_helper
INFO - 2019-07-03 17:22:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:22:26 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:22:26 --> Database Driver Class Initialized
INFO - 2019-07-03 17:22:26 --> Controller Class Initialized
INFO - 2019-07-03 23:22:26 --> Helper loaded: language_helper
INFO - 2019-07-03 23:22:26 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:22:26 --> Model Class Initialized
INFO - 2019-07-03 23:22:26 --> Model Class Initialized
INFO - 2019-07-03 23:22:26 --> Model Class Initialized
INFO - 2019-07-03 23:22:26 --> Model Class Initialized
INFO - 2019-07-03 23:22:26 --> Model Class Initialized
INFO - 2019-07-03 23:22:26 --> Final output sent to browser
DEBUG - 2019-07-03 23:22:26 --> Total execution time: 0.4129
INFO - 2019-07-03 17:22:26 --> Config Class Initialized
INFO - 2019-07-03 17:22:26 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:22:26 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:22:26 --> Utf8 Class Initialized
INFO - 2019-07-03 17:22:26 --> URI Class Initialized
INFO - 2019-07-03 17:22:26 --> Router Class Initialized
INFO - 2019-07-03 17:22:26 --> Output Class Initialized
INFO - 2019-07-03 17:22:26 --> Security Class Initialized
DEBUG - 2019-07-03 17:22:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:22:26 --> Input Class Initialized
INFO - 2019-07-03 17:22:26 --> Language Class Initialized
INFO - 2019-07-03 17:22:26 --> Language Class Initialized
INFO - 2019-07-03 17:22:27 --> Config Class Initialized
INFO - 2019-07-03 17:22:27 --> Loader Class Initialized
DEBUG - 2019-07-03 17:22:27 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:22:27 --> Helper loaded: url_helper
INFO - 2019-07-03 17:22:27 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:22:27 --> Helper loaded: string_helper
INFO - 2019-07-03 17:22:27 --> Helper loaded: array_helper
INFO - 2019-07-03 17:22:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:22:27 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:22:27 --> Database Driver Class Initialized
INFO - 2019-07-03 17:22:27 --> Controller Class Initialized
INFO - 2019-07-03 23:22:27 --> Helper loaded: language_helper
INFO - 2019-07-03 23:22:27 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:22:27 --> Model Class Initialized
INFO - 2019-07-03 23:22:27 --> Model Class Initialized
INFO - 2019-07-03 23:22:27 --> Model Class Initialized
INFO - 2019-07-03 23:22:27 --> Model Class Initialized
INFO - 2019-07-03 23:22:27 --> Helper loaded: form_helper
INFO - 2019-07-03 23:22:27 --> Form Validation Class Initialized
DEBUG - 2019-07-03 23:22:27 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-03 23:22:27 --> Model Class Initialized
INFO - 2019-07-03 23:22:27 --> Model Class Initialized
INFO - 2019-07-03 23:22:27 --> Final output sent to browser
DEBUG - 2019-07-03 23:22:27 --> Total execution time: 0.4662
INFO - 2019-07-03 17:22:56 --> Config Class Initialized
INFO - 2019-07-03 17:22:56 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:22:56 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:22:56 --> Utf8 Class Initialized
INFO - 2019-07-03 17:22:56 --> URI Class Initialized
INFO - 2019-07-03 17:22:56 --> Router Class Initialized
INFO - 2019-07-03 17:22:56 --> Output Class Initialized
INFO - 2019-07-03 17:22:56 --> Security Class Initialized
DEBUG - 2019-07-03 17:22:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:22:56 --> Input Class Initialized
INFO - 2019-07-03 17:22:56 --> Language Class Initialized
INFO - 2019-07-03 17:22:56 --> Language Class Initialized
INFO - 2019-07-03 17:22:56 --> Config Class Initialized
INFO - 2019-07-03 17:22:56 --> Loader Class Initialized
DEBUG - 2019-07-03 17:22:56 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:22:56 --> Helper loaded: url_helper
INFO - 2019-07-03 17:22:56 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:22:56 --> Helper loaded: string_helper
INFO - 2019-07-03 17:22:56 --> Helper loaded: array_helper
INFO - 2019-07-03 17:22:56 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:22:56 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:22:56 --> Database Driver Class Initialized
INFO - 2019-07-03 17:22:56 --> Controller Class Initialized
INFO - 2019-07-03 23:22:56 --> Helper loaded: language_helper
INFO - 2019-07-03 23:22:56 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:22:56 --> Model Class Initialized
INFO - 2019-07-03 23:22:56 --> Model Class Initialized
INFO - 2019-07-03 23:22:56 --> Model Class Initialized
INFO - 2019-07-03 23:22:56 --> Model Class Initialized
INFO - 2019-07-03 23:22:56 --> Model Class Initialized
INFO - 2019-07-03 23:22:56 --> Final output sent to browser
DEBUG - 2019-07-03 23:22:56 --> Total execution time: 0.4134
INFO - 2019-07-03 17:22:57 --> Config Class Initialized
INFO - 2019-07-03 17:22:57 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:22:57 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:22:57 --> Utf8 Class Initialized
INFO - 2019-07-03 17:22:57 --> URI Class Initialized
INFO - 2019-07-03 17:22:57 --> Router Class Initialized
INFO - 2019-07-03 17:22:57 --> Output Class Initialized
INFO - 2019-07-03 17:22:57 --> Security Class Initialized
DEBUG - 2019-07-03 17:22:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:22:57 --> Input Class Initialized
INFO - 2019-07-03 17:22:57 --> Language Class Initialized
INFO - 2019-07-03 17:22:57 --> Language Class Initialized
INFO - 2019-07-03 17:22:57 --> Config Class Initialized
INFO - 2019-07-03 17:22:57 --> Loader Class Initialized
DEBUG - 2019-07-03 17:22:57 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:22:57 --> Helper loaded: url_helper
INFO - 2019-07-03 17:22:57 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:22:57 --> Helper loaded: string_helper
INFO - 2019-07-03 17:22:57 --> Helper loaded: array_helper
INFO - 2019-07-03 17:22:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:22:57 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:22:57 --> Database Driver Class Initialized
INFO - 2019-07-03 17:22:57 --> Controller Class Initialized
INFO - 2019-07-03 23:22:57 --> Helper loaded: language_helper
INFO - 2019-07-03 23:22:57 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:22:57 --> Model Class Initialized
INFO - 2019-07-03 23:22:57 --> Model Class Initialized
INFO - 2019-07-03 23:22:57 --> Model Class Initialized
INFO - 2019-07-03 23:22:57 --> Model Class Initialized
INFO - 2019-07-03 23:22:57 --> Helper loaded: form_helper
INFO - 2019-07-03 23:22:57 --> Form Validation Class Initialized
DEBUG - 2019-07-03 23:22:57 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-03 23:22:57 --> Model Class Initialized
INFO - 2019-07-03 23:22:57 --> Model Class Initialized
INFO - 2019-07-03 23:22:57 --> Final output sent to browser
DEBUG - 2019-07-03 23:22:57 --> Total execution time: 0.4808
INFO - 2019-07-03 17:23:08 --> Config Class Initialized
INFO - 2019-07-03 17:23:08 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:23:08 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:23:08 --> Utf8 Class Initialized
INFO - 2019-07-03 17:23:08 --> URI Class Initialized
INFO - 2019-07-03 17:23:08 --> Router Class Initialized
INFO - 2019-07-03 17:23:08 --> Output Class Initialized
INFO - 2019-07-03 17:23:08 --> Security Class Initialized
DEBUG - 2019-07-03 17:23:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:23:08 --> Input Class Initialized
INFO - 2019-07-03 17:23:08 --> Language Class Initialized
INFO - 2019-07-03 17:23:08 --> Language Class Initialized
INFO - 2019-07-03 17:23:08 --> Config Class Initialized
INFO - 2019-07-03 17:23:08 --> Loader Class Initialized
DEBUG - 2019-07-03 17:23:08 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:23:08 --> Helper loaded: url_helper
INFO - 2019-07-03 17:23:08 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:23:08 --> Helper loaded: string_helper
INFO - 2019-07-03 17:23:08 --> Helper loaded: array_helper
INFO - 2019-07-03 17:23:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:23:08 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:23:08 --> Database Driver Class Initialized
INFO - 2019-07-03 17:23:08 --> Controller Class Initialized
INFO - 2019-07-03 23:23:08 --> Helper loaded: language_helper
INFO - 2019-07-03 23:23:08 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:23:08 --> Model Class Initialized
INFO - 2019-07-03 23:23:08 --> Model Class Initialized
INFO - 2019-07-03 23:23:09 --> Model Class Initialized
INFO - 2019-07-03 23:23:09 --> Model Class Initialized
INFO - 2019-07-03 23:23:09 --> Model Class Initialized
INFO - 2019-07-03 23:23:09 --> Final output sent to browser
DEBUG - 2019-07-03 23:23:09 --> Total execution time: 0.4152
INFO - 2019-07-03 17:23:09 --> Config Class Initialized
INFO - 2019-07-03 17:23:09 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:23:09 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:23:09 --> Utf8 Class Initialized
INFO - 2019-07-03 17:23:09 --> URI Class Initialized
INFO - 2019-07-03 17:23:09 --> Router Class Initialized
INFO - 2019-07-03 17:23:09 --> Output Class Initialized
INFO - 2019-07-03 17:23:09 --> Security Class Initialized
DEBUG - 2019-07-03 17:23:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:23:09 --> Input Class Initialized
INFO - 2019-07-03 17:23:09 --> Language Class Initialized
INFO - 2019-07-03 17:23:09 --> Language Class Initialized
INFO - 2019-07-03 17:23:09 --> Config Class Initialized
INFO - 2019-07-03 17:23:09 --> Loader Class Initialized
DEBUG - 2019-07-03 17:23:09 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:23:09 --> Helper loaded: url_helper
INFO - 2019-07-03 17:23:09 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:23:09 --> Helper loaded: string_helper
INFO - 2019-07-03 17:23:09 --> Helper loaded: array_helper
INFO - 2019-07-03 17:23:09 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:23:09 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:23:09 --> Database Driver Class Initialized
INFO - 2019-07-03 17:23:09 --> Controller Class Initialized
INFO - 2019-07-03 23:23:09 --> Helper loaded: language_helper
INFO - 2019-07-03 23:23:09 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:23:09 --> Model Class Initialized
INFO - 2019-07-03 23:23:09 --> Model Class Initialized
INFO - 2019-07-03 23:23:09 --> Model Class Initialized
INFO - 2019-07-03 23:23:09 --> Model Class Initialized
INFO - 2019-07-03 23:23:09 --> Helper loaded: form_helper
INFO - 2019-07-03 23:23:09 --> Form Validation Class Initialized
DEBUG - 2019-07-03 23:23:09 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-03 23:23:09 --> Model Class Initialized
INFO - 2019-07-03 23:23:09 --> Model Class Initialized
INFO - 2019-07-03 23:23:09 --> Final output sent to browser
DEBUG - 2019-07-03 23:23:09 --> Total execution time: 0.4796
INFO - 2019-07-03 17:23:17 --> Config Class Initialized
INFO - 2019-07-03 17:23:17 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:23:17 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:23:17 --> Utf8 Class Initialized
INFO - 2019-07-03 17:23:17 --> URI Class Initialized
INFO - 2019-07-03 17:23:17 --> Router Class Initialized
INFO - 2019-07-03 17:23:17 --> Output Class Initialized
INFO - 2019-07-03 17:23:17 --> Security Class Initialized
DEBUG - 2019-07-03 17:23:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:23:17 --> Input Class Initialized
INFO - 2019-07-03 17:23:17 --> Language Class Initialized
INFO - 2019-07-03 17:23:17 --> Language Class Initialized
INFO - 2019-07-03 17:23:17 --> Config Class Initialized
INFO - 2019-07-03 17:23:17 --> Loader Class Initialized
DEBUG - 2019-07-03 17:23:17 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:23:17 --> Helper loaded: url_helper
INFO - 2019-07-03 17:23:17 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:23:17 --> Helper loaded: string_helper
INFO - 2019-07-03 17:23:17 --> Helper loaded: array_helper
INFO - 2019-07-03 17:23:18 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:23:18 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:23:18 --> Database Driver Class Initialized
INFO - 2019-07-03 17:23:18 --> Controller Class Initialized
INFO - 2019-07-03 23:23:18 --> Helper loaded: language_helper
INFO - 2019-07-03 23:23:18 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:23:18 --> Model Class Initialized
INFO - 2019-07-03 23:23:18 --> Model Class Initialized
INFO - 2019-07-03 23:23:18 --> Model Class Initialized
INFO - 2019-07-03 23:23:18 --> Model Class Initialized
INFO - 2019-07-03 23:23:18 --> Model Class Initialized
INFO - 2019-07-03 23:23:18 --> Final output sent to browser
DEBUG - 2019-07-03 23:23:18 --> Total execution time: 0.4299
INFO - 2019-07-03 17:23:18 --> Config Class Initialized
INFO - 2019-07-03 17:23:18 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:23:18 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:23:18 --> Utf8 Class Initialized
INFO - 2019-07-03 17:23:18 --> URI Class Initialized
INFO - 2019-07-03 17:23:18 --> Router Class Initialized
INFO - 2019-07-03 17:23:18 --> Output Class Initialized
INFO - 2019-07-03 17:23:18 --> Security Class Initialized
DEBUG - 2019-07-03 17:23:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:23:18 --> Input Class Initialized
INFO - 2019-07-03 17:23:18 --> Language Class Initialized
INFO - 2019-07-03 17:23:18 --> Language Class Initialized
INFO - 2019-07-03 17:23:18 --> Config Class Initialized
INFO - 2019-07-03 17:23:18 --> Loader Class Initialized
DEBUG - 2019-07-03 17:23:18 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:23:18 --> Helper loaded: url_helper
INFO - 2019-07-03 17:23:18 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:23:18 --> Helper loaded: string_helper
INFO - 2019-07-03 17:23:18 --> Helper loaded: array_helper
INFO - 2019-07-03 17:23:18 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:23:18 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:23:18 --> Database Driver Class Initialized
INFO - 2019-07-03 17:23:18 --> Controller Class Initialized
INFO - 2019-07-03 23:23:18 --> Helper loaded: language_helper
INFO - 2019-07-03 23:23:18 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:23:18 --> Model Class Initialized
INFO - 2019-07-03 23:23:18 --> Model Class Initialized
INFO - 2019-07-03 23:23:18 --> Model Class Initialized
INFO - 2019-07-03 23:23:18 --> Model Class Initialized
INFO - 2019-07-03 23:23:18 --> Helper loaded: form_helper
INFO - 2019-07-03 23:23:18 --> Form Validation Class Initialized
DEBUG - 2019-07-03 23:23:18 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-03 23:23:18 --> Model Class Initialized
INFO - 2019-07-03 23:23:18 --> Model Class Initialized
INFO - 2019-07-03 23:23:18 --> Final output sent to browser
DEBUG - 2019-07-03 23:23:18 --> Total execution time: 0.4743
INFO - 2019-07-03 17:24:02 --> Config Class Initialized
INFO - 2019-07-03 17:24:02 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:24:02 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:24:02 --> Utf8 Class Initialized
INFO - 2019-07-03 17:24:03 --> URI Class Initialized
INFO - 2019-07-03 17:24:03 --> Router Class Initialized
INFO - 2019-07-03 17:24:03 --> Output Class Initialized
INFO - 2019-07-03 17:24:03 --> Security Class Initialized
DEBUG - 2019-07-03 17:24:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:24:03 --> Input Class Initialized
INFO - 2019-07-03 17:24:03 --> Config Class Initialized
INFO - 2019-07-03 17:24:03 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:24:03 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:24:03 --> Language Class Initialized
INFO - 2019-07-03 17:24:03 --> Utf8 Class Initialized
INFO - 2019-07-03 17:24:03 --> URI Class Initialized
INFO - 2019-07-03 17:24:03 --> Language Class Initialized
INFO - 2019-07-03 17:24:03 --> Router Class Initialized
INFO - 2019-07-03 17:24:03 --> Config Class Initialized
INFO - 2019-07-03 17:24:03 --> Loader Class Initialized
INFO - 2019-07-03 17:24:03 --> Output Class Initialized
DEBUG - 2019-07-03 17:24:03 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:24:03 --> Security Class Initialized
INFO - 2019-07-03 17:24:03 --> Helper loaded: url_helper
DEBUG - 2019-07-03 17:24:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:24:03 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:24:03 --> Input Class Initialized
INFO - 2019-07-03 17:24:03 --> Language Class Initialized
INFO - 2019-07-03 17:24:03 --> Helper loaded: string_helper
INFO - 2019-07-03 17:24:03 --> Language Class Initialized
INFO - 2019-07-03 17:24:03 --> Helper loaded: array_helper
INFO - 2019-07-03 17:24:03 --> Config Class Initialized
INFO - 2019-07-03 17:24:03 --> Loader Class Initialized
INFO - 2019-07-03 17:24:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:24:03 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-03 17:24:03 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:24:03 --> Helper loaded: url_helper
INFO - 2019-07-03 17:24:03 --> Database Driver Class Initialized
INFO - 2019-07-03 17:24:03 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:24:03 --> Controller Class Initialized
INFO - 2019-07-03 17:24:03 --> Helper loaded: string_helper
INFO - 2019-07-03 23:24:03 --> Helper loaded: language_helper
INFO - 2019-07-03 17:24:03 --> Helper loaded: array_helper
INFO - 2019-07-03 23:24:03 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:24:03 --> Model Class Initialized
INFO - 2019-07-03 23:24:03 --> Model Class Initialized
INFO - 2019-07-03 23:24:03 --> Model Class Initialized
INFO - 2019-07-03 23:24:03 --> Model Class Initialized
INFO - 2019-07-03 23:24:03 --> Model Class Initialized
INFO - 2019-07-03 23:24:03 --> Final output sent to browser
DEBUG - 2019-07-03 23:24:03 --> Total execution time: 0.7683
INFO - 2019-07-03 17:24:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:24:03 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:24:03 --> Database Driver Class Initialized
INFO - 2019-07-03 17:24:03 --> Controller Class Initialized
INFO - 2019-07-03 23:24:03 --> Helper loaded: language_helper
INFO - 2019-07-03 23:24:03 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:24:03 --> Model Class Initialized
INFO - 2019-07-03 23:24:03 --> Model Class Initialized
INFO - 2019-07-03 23:24:03 --> Model Class Initialized
INFO - 2019-07-03 23:24:03 --> Model Class Initialized
INFO - 2019-07-03 23:24:03 --> Model Class Initialized
INFO - 2019-07-03 23:24:03 --> Final output sent to browser
DEBUG - 2019-07-03 23:24:03 --> Total execution time: 0.6844
INFO - 2019-07-03 17:24:03 --> Config Class Initialized
INFO - 2019-07-03 17:24:03 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:24:03 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:24:03 --> Utf8 Class Initialized
INFO - 2019-07-03 17:24:03 --> URI Class Initialized
INFO - 2019-07-03 17:24:03 --> Router Class Initialized
INFO - 2019-07-03 17:24:03 --> Output Class Initialized
INFO - 2019-07-03 17:24:03 --> Security Class Initialized
DEBUG - 2019-07-03 17:24:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:24:04 --> Input Class Initialized
INFO - 2019-07-03 17:24:04 --> Language Class Initialized
INFO - 2019-07-03 17:24:04 --> Language Class Initialized
INFO - 2019-07-03 17:24:04 --> Config Class Initialized
INFO - 2019-07-03 17:24:04 --> Loader Class Initialized
DEBUG - 2019-07-03 17:24:04 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:24:04 --> Helper loaded: url_helper
INFO - 2019-07-03 17:24:04 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:24:04 --> Helper loaded: string_helper
INFO - 2019-07-03 17:24:04 --> Helper loaded: array_helper
INFO - 2019-07-03 17:24:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:24:04 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:24:04 --> Database Driver Class Initialized
INFO - 2019-07-03 17:24:04 --> Controller Class Initialized
INFO - 2019-07-03 23:24:04 --> Helper loaded: language_helper
INFO - 2019-07-03 23:24:04 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:24:04 --> Model Class Initialized
INFO - 2019-07-03 23:24:04 --> Model Class Initialized
INFO - 2019-07-03 23:24:04 --> Model Class Initialized
INFO - 2019-07-03 23:24:04 --> Model Class Initialized
INFO - 2019-07-03 23:24:04 --> Helper loaded: form_helper
INFO - 2019-07-03 23:24:04 --> Form Validation Class Initialized
DEBUG - 2019-07-03 23:24:04 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-03 23:24:04 --> Model Class Initialized
INFO - 2019-07-03 23:24:04 --> Model Class Initialized
INFO - 2019-07-03 23:24:04 --> Final output sent to browser
DEBUG - 2019-07-03 23:24:04 --> Total execution time: 0.4696
INFO - 2019-07-03 17:24:21 --> Config Class Initialized
INFO - 2019-07-03 17:24:21 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:24:21 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:24:21 --> Utf8 Class Initialized
INFO - 2019-07-03 17:24:21 --> URI Class Initialized
INFO - 2019-07-03 17:24:21 --> Router Class Initialized
INFO - 2019-07-03 17:24:21 --> Output Class Initialized
INFO - 2019-07-03 17:24:21 --> Security Class Initialized
DEBUG - 2019-07-03 17:24:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:24:21 --> Input Class Initialized
INFO - 2019-07-03 17:24:21 --> Language Class Initialized
INFO - 2019-07-03 17:24:21 --> Language Class Initialized
INFO - 2019-07-03 17:24:21 --> Config Class Initialized
INFO - 2019-07-03 17:24:21 --> Loader Class Initialized
DEBUG - 2019-07-03 17:24:21 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:24:21 --> Helper loaded: url_helper
INFO - 2019-07-03 17:24:21 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:24:21 --> Helper loaded: string_helper
INFO - 2019-07-03 17:24:21 --> Helper loaded: array_helper
INFO - 2019-07-03 17:24:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:24:21 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:24:21 --> Database Driver Class Initialized
INFO - 2019-07-03 17:24:21 --> Controller Class Initialized
INFO - 2019-07-03 23:24:21 --> Helper loaded: language_helper
INFO - 2019-07-03 23:24:21 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:24:21 --> Model Class Initialized
INFO - 2019-07-03 23:24:21 --> Model Class Initialized
INFO - 2019-07-03 23:24:21 --> Model Class Initialized
INFO - 2019-07-03 23:24:21 --> Model Class Initialized
INFO - 2019-07-03 23:24:21 --> Model Class Initialized
INFO - 2019-07-03 23:24:21 --> Final output sent to browser
DEBUG - 2019-07-03 23:24:21 --> Total execution time: 0.4077
INFO - 2019-07-03 17:24:21 --> Config Class Initialized
INFO - 2019-07-03 17:24:21 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:24:21 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:24:21 --> Utf8 Class Initialized
INFO - 2019-07-03 17:24:21 --> URI Class Initialized
INFO - 2019-07-03 17:24:21 --> Router Class Initialized
INFO - 2019-07-03 17:24:21 --> Output Class Initialized
INFO - 2019-07-03 17:24:21 --> Security Class Initialized
DEBUG - 2019-07-03 17:24:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:24:21 --> Input Class Initialized
INFO - 2019-07-03 17:24:21 --> Language Class Initialized
INFO - 2019-07-03 17:24:21 --> Language Class Initialized
INFO - 2019-07-03 17:24:21 --> Config Class Initialized
INFO - 2019-07-03 17:24:21 --> Loader Class Initialized
DEBUG - 2019-07-03 17:24:21 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:24:21 --> Helper loaded: url_helper
INFO - 2019-07-03 17:24:21 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:24:21 --> Helper loaded: string_helper
INFO - 2019-07-03 17:24:21 --> Helper loaded: array_helper
INFO - 2019-07-03 17:24:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:24:22 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:24:22 --> Database Driver Class Initialized
INFO - 2019-07-03 17:24:22 --> Controller Class Initialized
INFO - 2019-07-03 23:24:22 --> Helper loaded: language_helper
INFO - 2019-07-03 23:24:22 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:24:22 --> Model Class Initialized
INFO - 2019-07-03 23:24:22 --> Model Class Initialized
INFO - 2019-07-03 23:24:22 --> Model Class Initialized
INFO - 2019-07-03 23:24:22 --> Model Class Initialized
INFO - 2019-07-03 17:24:22 --> Config Class Initialized
INFO - 2019-07-03 23:24:22 --> Helper loaded: form_helper
INFO - 2019-07-03 17:24:22 --> Hooks Class Initialized
INFO - 2019-07-03 23:24:22 --> Form Validation Class Initialized
DEBUG - 2019-07-03 17:24:22 --> UTF-8 Support Enabled
DEBUG - 2019-07-03 23:24:22 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-03 17:24:22 --> Utf8 Class Initialized
INFO - 2019-07-03 17:24:22 --> URI Class Initialized
INFO - 2019-07-03 23:24:22 --> Model Class Initialized
INFO - 2019-07-03 17:24:22 --> Router Class Initialized
INFO - 2019-07-03 23:24:22 --> Model Class Initialized
INFO - 2019-07-03 17:24:22 --> Output Class Initialized
INFO - 2019-07-03 23:24:22 --> Final output sent to browser
INFO - 2019-07-03 17:24:22 --> Security Class Initialized
DEBUG - 2019-07-03 23:24:22 --> Total execution time: 0.6529
DEBUG - 2019-07-03 17:24:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:24:22 --> Input Class Initialized
INFO - 2019-07-03 17:24:22 --> Language Class Initialized
INFO - 2019-07-03 17:24:22 --> Language Class Initialized
INFO - 2019-07-03 17:24:22 --> Config Class Initialized
INFO - 2019-07-03 17:24:22 --> Loader Class Initialized
DEBUG - 2019-07-03 17:24:22 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:24:22 --> Helper loaded: url_helper
INFO - 2019-07-03 17:24:22 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:24:22 --> Helper loaded: string_helper
INFO - 2019-07-03 17:24:22 --> Helper loaded: array_helper
INFO - 2019-07-03 17:24:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:24:22 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:24:22 --> Database Driver Class Initialized
INFO - 2019-07-03 17:24:22 --> Controller Class Initialized
INFO - 2019-07-03 23:24:22 --> Helper loaded: language_helper
INFO - 2019-07-03 23:24:22 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:24:22 --> Model Class Initialized
INFO - 2019-07-03 23:24:22 --> Model Class Initialized
INFO - 2019-07-03 23:24:22 --> Model Class Initialized
INFO - 2019-07-03 23:24:22 --> Model Class Initialized
INFO - 2019-07-03 23:24:22 --> Model Class Initialized
INFO - 2019-07-03 23:24:22 --> Final output sent to browser
DEBUG - 2019-07-03 23:24:22 --> Total execution time: 0.4823
INFO - 2019-07-03 17:24:22 --> Config Class Initialized
INFO - 2019-07-03 17:24:22 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:24:22 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:24:22 --> Utf8 Class Initialized
INFO - 2019-07-03 17:24:22 --> URI Class Initialized
INFO - 2019-07-03 17:24:22 --> Router Class Initialized
INFO - 2019-07-03 17:24:22 --> Output Class Initialized
INFO - 2019-07-03 17:24:22 --> Security Class Initialized
DEBUG - 2019-07-03 17:24:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:24:22 --> Input Class Initialized
INFO - 2019-07-03 17:24:22 --> Language Class Initialized
INFO - 2019-07-03 17:24:22 --> Language Class Initialized
INFO - 2019-07-03 17:24:22 --> Config Class Initialized
INFO - 2019-07-03 17:24:22 --> Loader Class Initialized
DEBUG - 2019-07-03 17:24:22 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:24:23 --> Helper loaded: url_helper
INFO - 2019-07-03 17:24:23 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:24:23 --> Helper loaded: string_helper
INFO - 2019-07-03 17:24:23 --> Helper loaded: array_helper
INFO - 2019-07-03 17:24:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:24:23 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:24:23 --> Database Driver Class Initialized
INFO - 2019-07-03 17:24:23 --> Controller Class Initialized
INFO - 2019-07-03 23:24:23 --> Helper loaded: language_helper
INFO - 2019-07-03 23:24:23 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:24:23 --> Model Class Initialized
INFO - 2019-07-03 23:24:23 --> Model Class Initialized
INFO - 2019-07-03 23:24:23 --> Model Class Initialized
INFO - 2019-07-03 23:24:23 --> Model Class Initialized
INFO - 2019-07-03 23:24:23 --> Helper loaded: form_helper
INFO - 2019-07-03 23:24:23 --> Form Validation Class Initialized
DEBUG - 2019-07-03 23:24:23 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-03 23:24:23 --> Model Class Initialized
INFO - 2019-07-03 23:24:23 --> Model Class Initialized
INFO - 2019-07-03 23:24:23 --> Final output sent to browser
DEBUG - 2019-07-03 23:24:23 --> Total execution time: 0.4899
INFO - 2019-07-03 17:24:33 --> Config Class Initialized
INFO - 2019-07-03 17:24:33 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:24:33 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:24:33 --> Utf8 Class Initialized
INFO - 2019-07-03 17:24:33 --> URI Class Initialized
INFO - 2019-07-03 17:24:33 --> Router Class Initialized
INFO - 2019-07-03 17:24:33 --> Output Class Initialized
INFO - 2019-07-03 17:24:33 --> Security Class Initialized
DEBUG - 2019-07-03 17:24:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:24:33 --> Input Class Initialized
INFO - 2019-07-03 17:24:33 --> Language Class Initialized
INFO - 2019-07-03 17:24:33 --> Language Class Initialized
INFO - 2019-07-03 17:24:33 --> Config Class Initialized
INFO - 2019-07-03 17:24:33 --> Loader Class Initialized
DEBUG - 2019-07-03 17:24:33 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:24:33 --> Helper loaded: url_helper
INFO - 2019-07-03 17:24:33 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:24:33 --> Helper loaded: string_helper
INFO - 2019-07-03 17:24:33 --> Helper loaded: array_helper
INFO - 2019-07-03 17:24:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:24:33 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:24:33 --> Database Driver Class Initialized
INFO - 2019-07-03 17:24:33 --> Controller Class Initialized
INFO - 2019-07-03 23:24:33 --> Helper loaded: language_helper
INFO - 2019-07-03 23:24:33 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:24:33 --> Model Class Initialized
INFO - 2019-07-03 23:24:33 --> Model Class Initialized
INFO - 2019-07-03 23:24:33 --> Model Class Initialized
INFO - 2019-07-03 23:24:33 --> Model Class Initialized
INFO - 2019-07-03 23:24:33 --> Helper loaded: form_helper
INFO - 2019-07-03 23:24:33 --> Form Validation Class Initialized
DEBUG - 2019-07-03 23:24:33 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-03 23:24:33 --> Model Class Initialized
INFO - 2019-07-03 23:24:33 --> Model Class Initialized
INFO - 2019-07-03 23:24:33 --> Final output sent to browser
DEBUG - 2019-07-03 23:24:33 --> Total execution time: 0.4835
INFO - 2019-07-03 17:24:38 --> Config Class Initialized
INFO - 2019-07-03 17:24:38 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:24:38 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:24:38 --> Utf8 Class Initialized
INFO - 2019-07-03 17:24:38 --> URI Class Initialized
INFO - 2019-07-03 17:24:38 --> Router Class Initialized
INFO - 2019-07-03 17:24:38 --> Output Class Initialized
INFO - 2019-07-03 17:24:38 --> Security Class Initialized
DEBUG - 2019-07-03 17:24:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:24:38 --> Input Class Initialized
INFO - 2019-07-03 17:24:38 --> Language Class Initialized
INFO - 2019-07-03 17:24:38 --> Language Class Initialized
INFO - 2019-07-03 17:24:38 --> Config Class Initialized
INFO - 2019-07-03 17:24:38 --> Loader Class Initialized
DEBUG - 2019-07-03 17:24:38 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:24:38 --> Helper loaded: url_helper
INFO - 2019-07-03 17:24:38 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:24:38 --> Helper loaded: string_helper
INFO - 2019-07-03 17:24:38 --> Helper loaded: array_helper
INFO - 2019-07-03 17:24:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:24:38 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:24:38 --> Database Driver Class Initialized
INFO - 2019-07-03 17:24:38 --> Controller Class Initialized
INFO - 2019-07-03 23:24:38 --> Helper loaded: language_helper
INFO - 2019-07-03 23:24:38 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:24:38 --> Model Class Initialized
INFO - 2019-07-03 23:24:38 --> Model Class Initialized
INFO - 2019-07-03 23:24:38 --> Model Class Initialized
INFO - 2019-07-03 23:24:38 --> Model Class Initialized
INFO - 2019-07-03 23:24:38 --> Helper loaded: form_helper
INFO - 2019-07-03 23:24:38 --> Form Validation Class Initialized
DEBUG - 2019-07-03 23:24:38 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-03 23:24:38 --> Model Class Initialized
INFO - 2019-07-03 23:24:38 --> Model Class Initialized
INFO - 2019-07-03 23:24:38 --> Final output sent to browser
DEBUG - 2019-07-03 23:24:38 --> Total execution time: 0.4831
INFO - 2019-07-03 17:24:41 --> Config Class Initialized
INFO - 2019-07-03 17:24:41 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:24:41 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:24:41 --> Utf8 Class Initialized
INFO - 2019-07-03 17:24:41 --> URI Class Initialized
INFO - 2019-07-03 17:24:41 --> Router Class Initialized
INFO - 2019-07-03 17:24:41 --> Output Class Initialized
INFO - 2019-07-03 17:24:41 --> Security Class Initialized
DEBUG - 2019-07-03 17:24:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:24:41 --> Input Class Initialized
INFO - 2019-07-03 17:24:41 --> Language Class Initialized
INFO - 2019-07-03 17:24:41 --> Language Class Initialized
INFO - 2019-07-03 17:24:41 --> Config Class Initialized
INFO - 2019-07-03 17:24:41 --> Loader Class Initialized
DEBUG - 2019-07-03 17:24:41 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:24:41 --> Helper loaded: url_helper
INFO - 2019-07-03 17:24:41 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:24:41 --> Helper loaded: string_helper
INFO - 2019-07-03 17:24:41 --> Helper loaded: array_helper
INFO - 2019-07-03 17:24:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:24:41 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:24:41 --> Database Driver Class Initialized
INFO - 2019-07-03 17:24:41 --> Controller Class Initialized
INFO - 2019-07-03 23:24:41 --> Helper loaded: language_helper
INFO - 2019-07-03 23:24:41 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:24:41 --> Model Class Initialized
INFO - 2019-07-03 23:24:41 --> Model Class Initialized
INFO - 2019-07-03 23:24:41 --> Model Class Initialized
INFO - 2019-07-03 23:24:41 --> Model Class Initialized
INFO - 2019-07-03 23:24:41 --> Model Class Initialized
INFO - 2019-07-03 23:24:41 --> Final output sent to browser
DEBUG - 2019-07-03 23:24:41 --> Total execution time: 0.4175
INFO - 2019-07-03 17:24:41 --> Config Class Initialized
INFO - 2019-07-03 17:24:41 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:24:41 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:24:41 --> Utf8 Class Initialized
INFO - 2019-07-03 17:24:41 --> URI Class Initialized
INFO - 2019-07-03 17:24:41 --> Router Class Initialized
INFO - 2019-07-03 17:24:41 --> Output Class Initialized
INFO - 2019-07-03 17:24:41 --> Security Class Initialized
DEBUG - 2019-07-03 17:24:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:24:41 --> Input Class Initialized
INFO - 2019-07-03 17:24:41 --> Language Class Initialized
INFO - 2019-07-03 17:24:41 --> Language Class Initialized
INFO - 2019-07-03 17:24:41 --> Config Class Initialized
INFO - 2019-07-03 17:24:41 --> Loader Class Initialized
DEBUG - 2019-07-03 17:24:41 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:24:41 --> Helper loaded: url_helper
INFO - 2019-07-03 17:24:41 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:24:41 --> Helper loaded: string_helper
INFO - 2019-07-03 17:24:41 --> Helper loaded: array_helper
INFO - 2019-07-03 17:24:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:24:41 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:24:41 --> Database Driver Class Initialized
INFO - 2019-07-03 17:24:41 --> Controller Class Initialized
INFO - 2019-07-03 23:24:41 --> Helper loaded: language_helper
INFO - 2019-07-03 23:24:41 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:24:41 --> Model Class Initialized
INFO - 2019-07-03 23:24:41 --> Model Class Initialized
INFO - 2019-07-03 23:24:41 --> Model Class Initialized
INFO - 2019-07-03 23:24:41 --> Model Class Initialized
INFO - 2019-07-03 23:24:41 --> Helper loaded: form_helper
INFO - 2019-07-03 23:24:41 --> Form Validation Class Initialized
DEBUG - 2019-07-03 23:24:41 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-03 23:24:42 --> Model Class Initialized
INFO - 2019-07-03 23:24:42 --> Model Class Initialized
INFO - 2019-07-03 23:24:42 --> Final output sent to browser
DEBUG - 2019-07-03 23:24:42 --> Total execution time: 0.4889
INFO - 2019-07-03 17:26:20 --> Config Class Initialized
INFO - 2019-07-03 17:26:20 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:26:20 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:26:20 --> Utf8 Class Initialized
INFO - 2019-07-03 17:26:20 --> URI Class Initialized
INFO - 2019-07-03 17:26:20 --> Router Class Initialized
INFO - 2019-07-03 17:26:20 --> Output Class Initialized
INFO - 2019-07-03 17:26:20 --> Security Class Initialized
DEBUG - 2019-07-03 17:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:26:20 --> Input Class Initialized
INFO - 2019-07-03 17:26:20 --> Language Class Initialized
INFO - 2019-07-03 17:26:20 --> Language Class Initialized
INFO - 2019-07-03 17:26:20 --> Config Class Initialized
INFO - 2019-07-03 17:26:20 --> Loader Class Initialized
DEBUG - 2019-07-03 17:26:20 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:26:20 --> Helper loaded: url_helper
INFO - 2019-07-03 17:26:20 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:26:20 --> Helper loaded: string_helper
INFO - 2019-07-03 17:26:20 --> Helper loaded: array_helper
INFO - 2019-07-03 17:26:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:26:20 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:26:20 --> Database Driver Class Initialized
INFO - 2019-07-03 17:26:20 --> Controller Class Initialized
INFO - 2019-07-03 23:26:20 --> Helper loaded: language_helper
INFO - 2019-07-03 23:26:20 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:26:20 --> Model Class Initialized
INFO - 2019-07-03 23:26:20 --> Model Class Initialized
INFO - 2019-07-03 23:26:20 --> Model Class Initialized
INFO - 2019-07-03 23:26:20 --> Model Class Initialized
INFO - 2019-07-03 23:26:20 --> Model Class Initialized
INFO - 2019-07-03 23:26:20 --> Final output sent to browser
DEBUG - 2019-07-03 23:26:20 --> Total execution time: 0.4165
INFO - 2019-07-03 17:26:20 --> Config Class Initialized
INFO - 2019-07-03 17:26:20 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:26:20 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:26:20 --> Utf8 Class Initialized
INFO - 2019-07-03 17:26:20 --> URI Class Initialized
INFO - 2019-07-03 17:26:20 --> Router Class Initialized
INFO - 2019-07-03 17:26:20 --> Output Class Initialized
INFO - 2019-07-03 17:26:20 --> Security Class Initialized
DEBUG - 2019-07-03 17:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:26:20 --> Input Class Initialized
INFO - 2019-07-03 17:26:20 --> Language Class Initialized
INFO - 2019-07-03 17:26:20 --> Language Class Initialized
INFO - 2019-07-03 17:26:20 --> Config Class Initialized
INFO - 2019-07-03 17:26:20 --> Loader Class Initialized
DEBUG - 2019-07-03 17:26:20 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:26:20 --> Helper loaded: url_helper
INFO - 2019-07-03 17:26:20 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:26:20 --> Helper loaded: string_helper
INFO - 2019-07-03 17:26:20 --> Helper loaded: array_helper
INFO - 2019-07-03 17:26:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:26:20 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:26:20 --> Database Driver Class Initialized
INFO - 2019-07-03 17:26:20 --> Controller Class Initialized
INFO - 2019-07-03 23:26:21 --> Helper loaded: language_helper
INFO - 2019-07-03 23:26:21 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:26:21 --> Model Class Initialized
INFO - 2019-07-03 23:26:21 --> Model Class Initialized
INFO - 2019-07-03 23:26:21 --> Model Class Initialized
INFO - 2019-07-03 23:26:21 --> Model Class Initialized
INFO - 2019-07-03 23:26:21 --> Helper loaded: form_helper
INFO - 2019-07-03 23:26:21 --> Form Validation Class Initialized
DEBUG - 2019-07-03 23:26:21 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-03 23:26:21 --> Model Class Initialized
INFO - 2019-07-03 23:26:21 --> Model Class Initialized
INFO - 2019-07-03 23:26:21 --> Final output sent to browser
DEBUG - 2019-07-03 23:26:21 --> Total execution time: 0.4826
INFO - 2019-07-03 17:28:51 --> Config Class Initialized
INFO - 2019-07-03 17:28:51 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:28:51 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:28:51 --> Utf8 Class Initialized
INFO - 2019-07-03 17:28:51 --> URI Class Initialized
INFO - 2019-07-03 17:28:51 --> Router Class Initialized
INFO - 2019-07-03 17:28:51 --> Output Class Initialized
INFO - 2019-07-03 17:28:51 --> Security Class Initialized
DEBUG - 2019-07-03 17:28:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:28:51 --> Input Class Initialized
INFO - 2019-07-03 17:28:51 --> Language Class Initialized
INFO - 2019-07-03 17:28:51 --> Language Class Initialized
INFO - 2019-07-03 17:28:51 --> Config Class Initialized
INFO - 2019-07-03 17:28:51 --> Loader Class Initialized
DEBUG - 2019-07-03 17:28:51 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:28:51 --> Helper loaded: url_helper
INFO - 2019-07-03 17:28:51 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:28:51 --> Helper loaded: string_helper
INFO - 2019-07-03 17:28:51 --> Helper loaded: array_helper
INFO - 2019-07-03 17:28:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:28:51 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:28:51 --> Database Driver Class Initialized
INFO - 2019-07-03 17:28:51 --> Controller Class Initialized
INFO - 2019-07-03 23:28:51 --> Helper loaded: language_helper
INFO - 2019-07-03 23:28:51 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:28:51 --> Model Class Initialized
INFO - 2019-07-03 23:28:51 --> Model Class Initialized
INFO - 2019-07-03 23:28:51 --> Model Class Initialized
INFO - 2019-07-03 23:28:51 --> Model Class Initialized
INFO - 2019-07-03 23:28:51 --> Model Class Initialized
INFO - 2019-07-03 23:28:51 --> Final output sent to browser
DEBUG - 2019-07-03 23:28:51 --> Total execution time: 0.4310
INFO - 2019-07-03 17:28:52 --> Config Class Initialized
INFO - 2019-07-03 17:28:52 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:28:52 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:28:52 --> Utf8 Class Initialized
INFO - 2019-07-03 17:28:52 --> URI Class Initialized
INFO - 2019-07-03 17:28:52 --> Router Class Initialized
INFO - 2019-07-03 17:28:52 --> Output Class Initialized
INFO - 2019-07-03 17:28:52 --> Security Class Initialized
DEBUG - 2019-07-03 17:28:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:28:52 --> Input Class Initialized
INFO - 2019-07-03 17:28:52 --> Language Class Initialized
INFO - 2019-07-03 17:28:52 --> Language Class Initialized
INFO - 2019-07-03 17:28:52 --> Config Class Initialized
INFO - 2019-07-03 17:28:52 --> Loader Class Initialized
DEBUG - 2019-07-03 17:28:52 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:28:52 --> Helper loaded: url_helper
INFO - 2019-07-03 17:28:52 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:28:52 --> Helper loaded: string_helper
INFO - 2019-07-03 17:28:52 --> Helper loaded: array_helper
INFO - 2019-07-03 17:28:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:28:52 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:28:52 --> Database Driver Class Initialized
INFO - 2019-07-03 17:28:52 --> Controller Class Initialized
INFO - 2019-07-03 23:28:52 --> Helper loaded: language_helper
INFO - 2019-07-03 23:28:52 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:28:52 --> Model Class Initialized
INFO - 2019-07-03 23:28:52 --> Model Class Initialized
INFO - 2019-07-03 23:28:52 --> Model Class Initialized
INFO - 2019-07-03 23:28:52 --> Model Class Initialized
INFO - 2019-07-03 23:28:52 --> Helper loaded: form_helper
INFO - 2019-07-03 23:28:52 --> Form Validation Class Initialized
DEBUG - 2019-07-03 23:28:52 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-03 23:28:52 --> Model Class Initialized
INFO - 2019-07-03 23:28:52 --> Model Class Initialized
INFO - 2019-07-03 23:28:52 --> Final output sent to browser
DEBUG - 2019-07-03 23:28:52 --> Total execution time: 0.4585
INFO - 2019-07-03 17:29:01 --> Config Class Initialized
INFO - 2019-07-03 17:29:01 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:29:01 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:29:01 --> Utf8 Class Initialized
INFO - 2019-07-03 17:29:01 --> URI Class Initialized
INFO - 2019-07-03 17:29:01 --> Router Class Initialized
INFO - 2019-07-03 17:29:01 --> Output Class Initialized
INFO - 2019-07-03 17:29:01 --> Security Class Initialized
DEBUG - 2019-07-03 17:29:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:29:01 --> Input Class Initialized
INFO - 2019-07-03 17:29:01 --> Language Class Initialized
INFO - 2019-07-03 17:29:01 --> Language Class Initialized
INFO - 2019-07-03 17:29:01 --> Config Class Initialized
INFO - 2019-07-03 17:29:01 --> Loader Class Initialized
DEBUG - 2019-07-03 17:29:01 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:29:01 --> Helper loaded: url_helper
INFO - 2019-07-03 17:29:01 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:29:01 --> Helper loaded: string_helper
INFO - 2019-07-03 17:29:01 --> Helper loaded: array_helper
INFO - 2019-07-03 17:29:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:29:01 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:29:01 --> Database Driver Class Initialized
INFO - 2019-07-03 17:29:01 --> Controller Class Initialized
INFO - 2019-07-03 23:29:01 --> Helper loaded: language_helper
INFO - 2019-07-03 23:29:01 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:29:01 --> Model Class Initialized
INFO - 2019-07-03 23:29:01 --> Model Class Initialized
INFO - 2019-07-03 23:29:01 --> Model Class Initialized
INFO - 2019-07-03 23:29:01 --> Model Class Initialized
INFO - 2019-07-03 23:29:01 --> Model Class Initialized
INFO - 2019-07-03 23:29:01 --> Final output sent to browser
DEBUG - 2019-07-03 23:29:01 --> Total execution time: 0.5252
INFO - 2019-07-03 17:29:02 --> Config Class Initialized
INFO - 2019-07-03 17:29:02 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:29:02 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:29:02 --> Utf8 Class Initialized
INFO - 2019-07-03 17:29:02 --> URI Class Initialized
INFO - 2019-07-03 17:29:02 --> Router Class Initialized
INFO - 2019-07-03 17:29:02 --> Output Class Initialized
INFO - 2019-07-03 17:29:02 --> Security Class Initialized
DEBUG - 2019-07-03 17:29:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:29:02 --> Input Class Initialized
INFO - 2019-07-03 17:29:02 --> Language Class Initialized
INFO - 2019-07-03 17:29:02 --> Language Class Initialized
INFO - 2019-07-03 17:29:02 --> Config Class Initialized
INFO - 2019-07-03 17:29:02 --> Loader Class Initialized
DEBUG - 2019-07-03 17:29:02 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:29:02 --> Helper loaded: url_helper
INFO - 2019-07-03 17:29:02 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:29:02 --> Helper loaded: string_helper
INFO - 2019-07-03 17:29:02 --> Helper loaded: array_helper
INFO - 2019-07-03 17:29:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:29:02 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:29:02 --> Database Driver Class Initialized
INFO - 2019-07-03 17:29:02 --> Controller Class Initialized
INFO - 2019-07-03 23:29:02 --> Helper loaded: language_helper
INFO - 2019-07-03 23:29:02 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:29:02 --> Model Class Initialized
INFO - 2019-07-03 23:29:02 --> Model Class Initialized
INFO - 2019-07-03 23:29:02 --> Model Class Initialized
INFO - 2019-07-03 23:29:02 --> Model Class Initialized
INFO - 2019-07-03 23:29:02 --> Helper loaded: form_helper
INFO - 2019-07-03 23:29:02 --> Form Validation Class Initialized
DEBUG - 2019-07-03 23:29:02 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-03 23:29:02 --> Model Class Initialized
INFO - 2019-07-03 23:29:02 --> Model Class Initialized
INFO - 2019-07-03 23:29:02 --> Final output sent to browser
DEBUG - 2019-07-03 23:29:02 --> Total execution time: 0.4671
INFO - 2019-07-03 17:29:23 --> Config Class Initialized
INFO - 2019-07-03 17:29:23 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:29:23 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:29:23 --> Utf8 Class Initialized
INFO - 2019-07-03 17:29:23 --> URI Class Initialized
INFO - 2019-07-03 17:29:23 --> Router Class Initialized
INFO - 2019-07-03 17:29:23 --> Output Class Initialized
INFO - 2019-07-03 17:29:23 --> Security Class Initialized
DEBUG - 2019-07-03 17:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:29:23 --> Input Class Initialized
INFO - 2019-07-03 17:29:23 --> Language Class Initialized
INFO - 2019-07-03 17:29:23 --> Language Class Initialized
INFO - 2019-07-03 17:29:23 --> Config Class Initialized
INFO - 2019-07-03 17:29:23 --> Loader Class Initialized
DEBUG - 2019-07-03 17:29:23 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:29:23 --> Helper loaded: url_helper
INFO - 2019-07-03 17:29:23 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:29:23 --> Helper loaded: string_helper
INFO - 2019-07-03 17:29:23 --> Helper loaded: array_helper
INFO - 2019-07-03 17:29:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:29:23 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:29:23 --> Database Driver Class Initialized
INFO - 2019-07-03 17:29:23 --> Controller Class Initialized
INFO - 2019-07-03 23:29:23 --> Helper loaded: language_helper
INFO - 2019-07-03 23:29:23 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:29:23 --> Model Class Initialized
INFO - 2019-07-03 23:29:23 --> Model Class Initialized
INFO - 2019-07-03 23:29:23 --> Model Class Initialized
INFO - 2019-07-03 23:29:23 --> Model Class Initialized
INFO - 2019-07-03 23:29:23 --> Model Class Initialized
INFO - 2019-07-03 23:29:23 --> Final output sent to browser
DEBUG - 2019-07-03 23:29:23 --> Total execution time: 0.4257
INFO - 2019-07-03 17:29:24 --> Config Class Initialized
INFO - 2019-07-03 17:29:24 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:29:24 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:29:24 --> Utf8 Class Initialized
INFO - 2019-07-03 17:29:24 --> URI Class Initialized
INFO - 2019-07-03 17:29:24 --> Router Class Initialized
INFO - 2019-07-03 17:29:24 --> Output Class Initialized
INFO - 2019-07-03 17:29:24 --> Security Class Initialized
DEBUG - 2019-07-03 17:29:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:29:24 --> Input Class Initialized
INFO - 2019-07-03 17:29:24 --> Language Class Initialized
INFO - 2019-07-03 17:29:24 --> Language Class Initialized
INFO - 2019-07-03 17:29:24 --> Config Class Initialized
INFO - 2019-07-03 17:29:24 --> Loader Class Initialized
DEBUG - 2019-07-03 17:29:24 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:29:24 --> Helper loaded: url_helper
INFO - 2019-07-03 17:29:24 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:29:24 --> Helper loaded: string_helper
INFO - 2019-07-03 17:29:24 --> Helper loaded: array_helper
INFO - 2019-07-03 17:29:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:29:24 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:29:24 --> Database Driver Class Initialized
INFO - 2019-07-03 17:29:24 --> Controller Class Initialized
INFO - 2019-07-03 23:29:24 --> Helper loaded: language_helper
INFO - 2019-07-03 23:29:24 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:29:24 --> Model Class Initialized
INFO - 2019-07-03 23:29:24 --> Model Class Initialized
INFO - 2019-07-03 23:29:24 --> Model Class Initialized
INFO - 2019-07-03 23:29:24 --> Model Class Initialized
INFO - 2019-07-03 23:29:24 --> Helper loaded: form_helper
INFO - 2019-07-03 23:29:24 --> Form Validation Class Initialized
DEBUG - 2019-07-03 23:29:24 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-03 23:29:24 --> Model Class Initialized
INFO - 2019-07-03 23:29:24 --> Model Class Initialized
INFO - 2019-07-03 23:29:24 --> Final output sent to browser
DEBUG - 2019-07-03 23:29:24 --> Total execution time: 0.4808
INFO - 2019-07-03 17:29:33 --> Config Class Initialized
INFO - 2019-07-03 17:29:33 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:29:33 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:29:33 --> Utf8 Class Initialized
INFO - 2019-07-03 17:29:33 --> URI Class Initialized
INFO - 2019-07-03 17:29:33 --> Router Class Initialized
INFO - 2019-07-03 17:29:33 --> Output Class Initialized
INFO - 2019-07-03 17:29:33 --> Security Class Initialized
DEBUG - 2019-07-03 17:29:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:29:33 --> Input Class Initialized
INFO - 2019-07-03 17:29:33 --> Language Class Initialized
INFO - 2019-07-03 17:29:33 --> Language Class Initialized
INFO - 2019-07-03 17:29:33 --> Config Class Initialized
INFO - 2019-07-03 17:29:33 --> Loader Class Initialized
DEBUG - 2019-07-03 17:29:33 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:29:33 --> Helper loaded: url_helper
INFO - 2019-07-03 17:29:33 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:29:33 --> Helper loaded: string_helper
INFO - 2019-07-03 17:29:33 --> Helper loaded: array_helper
INFO - 2019-07-03 17:29:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:29:33 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:29:33 --> Database Driver Class Initialized
INFO - 2019-07-03 17:29:33 --> Controller Class Initialized
INFO - 2019-07-03 23:29:33 --> Helper loaded: language_helper
INFO - 2019-07-03 23:29:33 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:29:33 --> Model Class Initialized
INFO - 2019-07-03 23:29:33 --> Model Class Initialized
INFO - 2019-07-03 23:29:33 --> Model Class Initialized
INFO - 2019-07-03 23:29:33 --> Model Class Initialized
INFO - 2019-07-03 23:29:33 --> Model Class Initialized
INFO - 2019-07-03 23:29:33 --> Final output sent to browser
DEBUG - 2019-07-03 23:29:33 --> Total execution time: 0.4324
INFO - 2019-07-03 17:29:34 --> Config Class Initialized
INFO - 2019-07-03 17:29:34 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:29:34 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:29:34 --> Utf8 Class Initialized
INFO - 2019-07-03 17:29:34 --> URI Class Initialized
INFO - 2019-07-03 17:29:34 --> Router Class Initialized
INFO - 2019-07-03 17:29:34 --> Output Class Initialized
INFO - 2019-07-03 17:29:34 --> Security Class Initialized
DEBUG - 2019-07-03 17:29:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:29:34 --> Input Class Initialized
INFO - 2019-07-03 17:29:34 --> Language Class Initialized
INFO - 2019-07-03 17:29:34 --> Language Class Initialized
INFO - 2019-07-03 17:29:34 --> Config Class Initialized
INFO - 2019-07-03 17:29:34 --> Loader Class Initialized
DEBUG - 2019-07-03 17:29:34 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:29:34 --> Helper loaded: url_helper
INFO - 2019-07-03 17:29:34 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:29:34 --> Helper loaded: string_helper
INFO - 2019-07-03 17:29:34 --> Helper loaded: array_helper
INFO - 2019-07-03 17:29:34 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:29:34 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:29:34 --> Database Driver Class Initialized
INFO - 2019-07-03 17:29:34 --> Controller Class Initialized
INFO - 2019-07-03 23:29:34 --> Helper loaded: language_helper
INFO - 2019-07-03 23:29:34 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:29:34 --> Model Class Initialized
INFO - 2019-07-03 23:29:34 --> Model Class Initialized
INFO - 2019-07-03 23:29:34 --> Model Class Initialized
INFO - 2019-07-03 23:29:34 --> Model Class Initialized
INFO - 2019-07-03 23:29:34 --> Helper loaded: form_helper
INFO - 2019-07-03 23:29:34 --> Form Validation Class Initialized
DEBUG - 2019-07-03 23:29:34 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-03 23:29:34 --> Model Class Initialized
INFO - 2019-07-03 23:29:34 --> Model Class Initialized
INFO - 2019-07-03 23:29:34 --> Final output sent to browser
DEBUG - 2019-07-03 23:29:34 --> Total execution time: 0.4778
INFO - 2019-07-03 17:29:55 --> Config Class Initialized
INFO - 2019-07-03 17:29:55 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:29:55 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:29:55 --> Utf8 Class Initialized
INFO - 2019-07-03 17:29:55 --> URI Class Initialized
INFO - 2019-07-03 17:29:55 --> Router Class Initialized
INFO - 2019-07-03 17:29:55 --> Output Class Initialized
INFO - 2019-07-03 17:29:55 --> Security Class Initialized
DEBUG - 2019-07-03 17:29:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:29:55 --> Input Class Initialized
INFO - 2019-07-03 17:29:55 --> Language Class Initialized
INFO - 2019-07-03 17:29:55 --> Language Class Initialized
INFO - 2019-07-03 17:29:55 --> Config Class Initialized
INFO - 2019-07-03 17:29:55 --> Loader Class Initialized
DEBUG - 2019-07-03 17:29:55 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:29:55 --> Helper loaded: url_helper
INFO - 2019-07-03 17:29:55 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:29:55 --> Helper loaded: string_helper
INFO - 2019-07-03 17:29:55 --> Helper loaded: array_helper
INFO - 2019-07-03 17:29:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:29:55 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:29:55 --> Database Driver Class Initialized
INFO - 2019-07-03 17:29:55 --> Controller Class Initialized
INFO - 2019-07-03 23:29:55 --> Helper loaded: language_helper
INFO - 2019-07-03 23:29:55 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:29:55 --> Model Class Initialized
INFO - 2019-07-03 23:29:55 --> Model Class Initialized
INFO - 2019-07-03 23:29:55 --> Model Class Initialized
INFO - 2019-07-03 23:29:55 --> Model Class Initialized
INFO - 2019-07-03 23:29:55 --> Model Class Initialized
INFO - 2019-07-03 23:29:55 --> Final output sent to browser
DEBUG - 2019-07-03 23:29:55 --> Total execution time: 0.4255
INFO - 2019-07-03 17:29:56 --> Config Class Initialized
INFO - 2019-07-03 17:29:56 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:29:56 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:29:56 --> Utf8 Class Initialized
INFO - 2019-07-03 17:29:56 --> URI Class Initialized
INFO - 2019-07-03 17:29:56 --> Router Class Initialized
INFO - 2019-07-03 17:29:56 --> Output Class Initialized
INFO - 2019-07-03 17:29:56 --> Security Class Initialized
DEBUG - 2019-07-03 17:29:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:29:56 --> Input Class Initialized
INFO - 2019-07-03 17:29:56 --> Language Class Initialized
INFO - 2019-07-03 17:29:56 --> Language Class Initialized
INFO - 2019-07-03 17:29:56 --> Config Class Initialized
INFO - 2019-07-03 17:29:56 --> Loader Class Initialized
DEBUG - 2019-07-03 17:29:56 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:29:56 --> Helper loaded: url_helper
INFO - 2019-07-03 17:29:56 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:29:56 --> Helper loaded: string_helper
INFO - 2019-07-03 17:29:56 --> Helper loaded: array_helper
INFO - 2019-07-03 17:29:56 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:29:56 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:29:56 --> Database Driver Class Initialized
INFO - 2019-07-03 17:29:56 --> Controller Class Initialized
INFO - 2019-07-03 23:29:56 --> Helper loaded: language_helper
INFO - 2019-07-03 23:29:56 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:29:56 --> Model Class Initialized
INFO - 2019-07-03 23:29:56 --> Model Class Initialized
INFO - 2019-07-03 23:29:56 --> Model Class Initialized
INFO - 2019-07-03 23:29:56 --> Model Class Initialized
INFO - 2019-07-03 23:29:56 --> Helper loaded: form_helper
INFO - 2019-07-03 23:29:56 --> Form Validation Class Initialized
DEBUG - 2019-07-03 23:29:56 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-03 23:29:56 --> Model Class Initialized
INFO - 2019-07-03 23:29:56 --> Model Class Initialized
INFO - 2019-07-03 23:29:56 --> Final output sent to browser
DEBUG - 2019-07-03 23:29:56 --> Total execution time: 0.4680
INFO - 2019-07-03 17:30:05 --> Config Class Initialized
INFO - 2019-07-03 17:30:05 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:30:05 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:30:05 --> Utf8 Class Initialized
INFO - 2019-07-03 17:30:05 --> URI Class Initialized
INFO - 2019-07-03 17:30:05 --> Router Class Initialized
INFO - 2019-07-03 17:30:05 --> Output Class Initialized
INFO - 2019-07-03 17:30:05 --> Security Class Initialized
DEBUG - 2019-07-03 17:30:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:30:05 --> Input Class Initialized
INFO - 2019-07-03 17:30:05 --> Language Class Initialized
INFO - 2019-07-03 17:30:05 --> Language Class Initialized
INFO - 2019-07-03 17:30:05 --> Config Class Initialized
INFO - 2019-07-03 17:30:05 --> Loader Class Initialized
DEBUG - 2019-07-03 17:30:05 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:30:05 --> Helper loaded: url_helper
INFO - 2019-07-03 17:30:05 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:30:05 --> Helper loaded: string_helper
INFO - 2019-07-03 17:30:05 --> Helper loaded: array_helper
INFO - 2019-07-03 17:30:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:30:05 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:30:05 --> Database Driver Class Initialized
INFO - 2019-07-03 17:30:05 --> Controller Class Initialized
INFO - 2019-07-03 23:30:05 --> Helper loaded: language_helper
INFO - 2019-07-03 23:30:05 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:30:05 --> Model Class Initialized
INFO - 2019-07-03 23:30:05 --> Model Class Initialized
INFO - 2019-07-03 23:30:05 --> Model Class Initialized
INFO - 2019-07-03 23:30:05 --> Model Class Initialized
INFO - 2019-07-03 23:30:05 --> Model Class Initialized
INFO - 2019-07-03 23:30:05 --> Final output sent to browser
DEBUG - 2019-07-03 23:30:05 --> Total execution time: 0.4100
INFO - 2019-07-03 17:30:06 --> Config Class Initialized
INFO - 2019-07-03 17:30:06 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:30:06 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:30:06 --> Utf8 Class Initialized
INFO - 2019-07-03 17:30:06 --> URI Class Initialized
INFO - 2019-07-03 17:30:06 --> Router Class Initialized
INFO - 2019-07-03 17:30:06 --> Output Class Initialized
INFO - 2019-07-03 17:30:06 --> Security Class Initialized
DEBUG - 2019-07-03 17:30:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:30:06 --> Input Class Initialized
INFO - 2019-07-03 17:30:06 --> Language Class Initialized
INFO - 2019-07-03 17:30:06 --> Language Class Initialized
INFO - 2019-07-03 17:30:06 --> Config Class Initialized
INFO - 2019-07-03 17:30:06 --> Loader Class Initialized
DEBUG - 2019-07-03 17:30:06 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:30:06 --> Helper loaded: url_helper
INFO - 2019-07-03 17:30:06 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:30:06 --> Helper loaded: string_helper
INFO - 2019-07-03 17:30:06 --> Helper loaded: array_helper
INFO - 2019-07-03 17:30:06 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:30:06 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:30:06 --> Database Driver Class Initialized
INFO - 2019-07-03 17:30:06 --> Controller Class Initialized
INFO - 2019-07-03 23:30:06 --> Helper loaded: language_helper
INFO - 2019-07-03 23:30:06 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:30:06 --> Model Class Initialized
INFO - 2019-07-03 23:30:06 --> Model Class Initialized
INFO - 2019-07-03 23:30:06 --> Model Class Initialized
INFO - 2019-07-03 23:30:06 --> Model Class Initialized
INFO - 2019-07-03 23:30:06 --> Helper loaded: form_helper
INFO - 2019-07-03 23:30:06 --> Form Validation Class Initialized
DEBUG - 2019-07-03 23:30:06 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-03 23:30:06 --> Model Class Initialized
INFO - 2019-07-03 23:30:06 --> Model Class Initialized
INFO - 2019-07-03 23:30:06 --> Final output sent to browser
DEBUG - 2019-07-03 23:30:06 --> Total execution time: 0.4792
INFO - 2019-07-03 17:30:16 --> Config Class Initialized
INFO - 2019-07-03 17:30:17 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:30:17 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:30:17 --> Utf8 Class Initialized
INFO - 2019-07-03 17:30:17 --> URI Class Initialized
INFO - 2019-07-03 17:30:17 --> Router Class Initialized
INFO - 2019-07-03 17:30:17 --> Output Class Initialized
INFO - 2019-07-03 17:30:17 --> Security Class Initialized
DEBUG - 2019-07-03 17:30:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:30:17 --> Input Class Initialized
INFO - 2019-07-03 17:30:17 --> Language Class Initialized
INFO - 2019-07-03 17:30:17 --> Language Class Initialized
INFO - 2019-07-03 17:30:17 --> Config Class Initialized
INFO - 2019-07-03 17:30:17 --> Loader Class Initialized
DEBUG - 2019-07-03 17:30:17 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:30:17 --> Helper loaded: url_helper
INFO - 2019-07-03 17:30:17 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:30:17 --> Helper loaded: string_helper
INFO - 2019-07-03 17:30:17 --> Helper loaded: array_helper
INFO - 2019-07-03 17:30:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:30:17 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:30:17 --> Database Driver Class Initialized
INFO - 2019-07-03 17:30:17 --> Controller Class Initialized
INFO - 2019-07-03 23:30:17 --> Helper loaded: language_helper
INFO - 2019-07-03 23:30:17 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:30:17 --> Model Class Initialized
INFO - 2019-07-03 23:30:17 --> Model Class Initialized
INFO - 2019-07-03 23:30:17 --> Model Class Initialized
INFO - 2019-07-03 23:30:17 --> Model Class Initialized
INFO - 2019-07-03 23:30:17 --> Model Class Initialized
INFO - 2019-07-03 23:30:17 --> Final output sent to browser
DEBUG - 2019-07-03 23:30:17 --> Total execution time: 0.4917
INFO - 2019-07-03 17:30:17 --> Config Class Initialized
INFO - 2019-07-03 17:30:17 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:30:17 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:30:17 --> Utf8 Class Initialized
INFO - 2019-07-03 17:30:17 --> URI Class Initialized
INFO - 2019-07-03 17:30:17 --> Router Class Initialized
INFO - 2019-07-03 17:30:17 --> Output Class Initialized
INFO - 2019-07-03 17:30:17 --> Security Class Initialized
DEBUG - 2019-07-03 17:30:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:30:17 --> Input Class Initialized
INFO - 2019-07-03 17:30:17 --> Language Class Initialized
INFO - 2019-07-03 17:30:17 --> Language Class Initialized
INFO - 2019-07-03 17:30:17 --> Config Class Initialized
INFO - 2019-07-03 17:30:17 --> Loader Class Initialized
DEBUG - 2019-07-03 17:30:17 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:30:17 --> Helper loaded: url_helper
INFO - 2019-07-03 17:30:17 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:30:17 --> Helper loaded: string_helper
INFO - 2019-07-03 17:30:17 --> Helper loaded: array_helper
INFO - 2019-07-03 17:30:17 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:30:17 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:30:17 --> Database Driver Class Initialized
INFO - 2019-07-03 17:30:17 --> Controller Class Initialized
INFO - 2019-07-03 23:30:17 --> Helper loaded: language_helper
INFO - 2019-07-03 23:30:17 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:30:17 --> Model Class Initialized
INFO - 2019-07-03 23:30:17 --> Model Class Initialized
INFO - 2019-07-03 23:30:17 --> Model Class Initialized
INFO - 2019-07-03 23:30:17 --> Model Class Initialized
INFO - 2019-07-03 23:30:17 --> Helper loaded: form_helper
INFO - 2019-07-03 23:30:17 --> Form Validation Class Initialized
DEBUG - 2019-07-03 23:30:18 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-03 23:30:18 --> Model Class Initialized
INFO - 2019-07-03 23:30:18 --> Model Class Initialized
INFO - 2019-07-03 23:30:18 --> Final output sent to browser
DEBUG - 2019-07-03 23:30:18 --> Total execution time: 0.5117
INFO - 2019-07-03 17:30:19 --> Config Class Initialized
INFO - 2019-07-03 17:30:19 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:30:19 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:30:19 --> Utf8 Class Initialized
INFO - 2019-07-03 17:30:19 --> URI Class Initialized
INFO - 2019-07-03 17:30:19 --> Router Class Initialized
INFO - 2019-07-03 17:30:19 --> Output Class Initialized
INFO - 2019-07-03 17:30:19 --> Security Class Initialized
DEBUG - 2019-07-03 17:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:30:19 --> Input Class Initialized
INFO - 2019-07-03 17:30:19 --> Language Class Initialized
INFO - 2019-07-03 17:30:19 --> Language Class Initialized
INFO - 2019-07-03 17:30:19 --> Config Class Initialized
INFO - 2019-07-03 17:30:19 --> Loader Class Initialized
DEBUG - 2019-07-03 17:30:19 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:30:19 --> Helper loaded: url_helper
INFO - 2019-07-03 17:30:19 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:30:19 --> Helper loaded: string_helper
INFO - 2019-07-03 17:30:19 --> Helper loaded: array_helper
INFO - 2019-07-03 17:30:19 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:30:19 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:30:19 --> Database Driver Class Initialized
INFO - 2019-07-03 17:30:19 --> Controller Class Initialized
INFO - 2019-07-03 23:30:19 --> Helper loaded: language_helper
INFO - 2019-07-03 23:30:19 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:30:19 --> Model Class Initialized
INFO - 2019-07-03 23:30:19 --> Model Class Initialized
INFO - 2019-07-03 23:30:19 --> Model Class Initialized
INFO - 2019-07-03 23:30:19 --> Model Class Initialized
INFO - 2019-07-03 23:30:19 --> Helper loaded: form_helper
INFO - 2019-07-03 23:30:19 --> Form Validation Class Initialized
DEBUG - 2019-07-03 23:30:19 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-03 23:30:19 --> Model Class Initialized
INFO - 2019-07-03 23:30:19 --> Model Class Initialized
INFO - 2019-07-03 23:30:19 --> Final output sent to browser
DEBUG - 2019-07-03 23:30:19 --> Total execution time: 0.5354
INFO - 2019-07-03 17:31:04 --> Config Class Initialized
INFO - 2019-07-03 17:31:04 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:31:04 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:31:04 --> Utf8 Class Initialized
INFO - 2019-07-03 17:31:04 --> URI Class Initialized
INFO - 2019-07-03 17:31:04 --> Router Class Initialized
INFO - 2019-07-03 17:31:04 --> Output Class Initialized
INFO - 2019-07-03 17:31:04 --> Security Class Initialized
DEBUG - 2019-07-03 17:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:31:04 --> Input Class Initialized
INFO - 2019-07-03 17:31:04 --> Language Class Initialized
INFO - 2019-07-03 17:31:04 --> Language Class Initialized
INFO - 2019-07-03 17:31:04 --> Config Class Initialized
INFO - 2019-07-03 17:31:05 --> Loader Class Initialized
DEBUG - 2019-07-03 17:31:05 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:31:05 --> Helper loaded: url_helper
INFO - 2019-07-03 17:31:05 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:31:05 --> Helper loaded: string_helper
INFO - 2019-07-03 17:31:05 --> Helper loaded: array_helper
INFO - 2019-07-03 17:31:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:31:05 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:31:05 --> Database Driver Class Initialized
INFO - 2019-07-03 17:31:05 --> Controller Class Initialized
INFO - 2019-07-03 23:31:05 --> Helper loaded: language_helper
INFO - 2019-07-03 23:31:05 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:31:05 --> Model Class Initialized
INFO - 2019-07-03 23:31:05 --> Model Class Initialized
INFO - 2019-07-03 23:31:05 --> Model Class Initialized
INFO - 2019-07-03 23:31:05 --> Model Class Initialized
INFO - 2019-07-03 23:31:05 --> Helper loaded: form_helper
INFO - 2019-07-03 23:31:05 --> Form Validation Class Initialized
DEBUG - 2019-07-03 23:31:05 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-03 23:31:05 --> Model Class Initialized
INFO - 2019-07-03 23:31:05 --> Model Class Initialized
INFO - 2019-07-03 17:31:30 --> Config Class Initialized
INFO - 2019-07-03 17:31:30 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:31:30 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:31:30 --> Utf8 Class Initialized
INFO - 2019-07-03 17:31:30 --> URI Class Initialized
INFO - 2019-07-03 17:31:30 --> Router Class Initialized
INFO - 2019-07-03 17:31:30 --> Output Class Initialized
INFO - 2019-07-03 17:31:30 --> Security Class Initialized
DEBUG - 2019-07-03 17:31:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:31:30 --> Input Class Initialized
INFO - 2019-07-03 17:31:30 --> Language Class Initialized
INFO - 2019-07-03 17:31:30 --> Language Class Initialized
INFO - 2019-07-03 17:31:30 --> Config Class Initialized
INFO - 2019-07-03 17:31:30 --> Loader Class Initialized
DEBUG - 2019-07-03 17:31:30 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:31:30 --> Helper loaded: url_helper
INFO - 2019-07-03 17:31:30 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:31:30 --> Helper loaded: string_helper
INFO - 2019-07-03 17:31:30 --> Helper loaded: array_helper
INFO - 2019-07-03 17:31:30 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:31:30 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:31:30 --> Database Driver Class Initialized
INFO - 2019-07-03 17:31:30 --> Controller Class Initialized
INFO - 2019-07-03 23:31:31 --> Helper loaded: language_helper
INFO - 2019-07-03 23:31:31 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:31:31 --> Model Class Initialized
INFO - 2019-07-03 23:31:31 --> Model Class Initialized
INFO - 2019-07-03 23:31:31 --> Model Class Initialized
INFO - 2019-07-03 23:31:31 --> Model Class Initialized
INFO - 2019-07-03 23:31:31 --> Model Class Initialized
INFO - 2019-07-03 23:31:31 --> Final output sent to browser
DEBUG - 2019-07-03 23:31:31 --> Total execution time: 0.6971
INFO - 2019-07-03 17:31:31 --> Config Class Initialized
INFO - 2019-07-03 17:31:31 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:31:31 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:31:31 --> Utf8 Class Initialized
INFO - 2019-07-03 17:31:31 --> URI Class Initialized
INFO - 2019-07-03 17:31:31 --> Router Class Initialized
INFO - 2019-07-03 17:31:31 --> Output Class Initialized
INFO - 2019-07-03 17:31:31 --> Security Class Initialized
DEBUG - 2019-07-03 17:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:31:31 --> Input Class Initialized
INFO - 2019-07-03 17:31:31 --> Language Class Initialized
INFO - 2019-07-03 17:31:32 --> Language Class Initialized
INFO - 2019-07-03 17:31:32 --> Config Class Initialized
INFO - 2019-07-03 17:31:32 --> Loader Class Initialized
DEBUG - 2019-07-03 17:31:32 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:31:32 --> Helper loaded: url_helper
INFO - 2019-07-03 17:31:32 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:31:32 --> Helper loaded: string_helper
INFO - 2019-07-03 17:31:32 --> Helper loaded: array_helper
INFO - 2019-07-03 17:31:32 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:31:32 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:31:32 --> Database Driver Class Initialized
INFO - 2019-07-03 17:31:32 --> Controller Class Initialized
INFO - 2019-07-03 23:31:32 --> Helper loaded: language_helper
INFO - 2019-07-03 23:31:32 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:31:32 --> Model Class Initialized
INFO - 2019-07-03 23:31:32 --> Model Class Initialized
INFO - 2019-07-03 23:31:32 --> Model Class Initialized
INFO - 2019-07-03 23:31:32 --> Model Class Initialized
INFO - 2019-07-03 23:31:32 --> Helper loaded: form_helper
INFO - 2019-07-03 23:31:32 --> Form Validation Class Initialized
DEBUG - 2019-07-03 23:31:32 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-03 23:31:32 --> Model Class Initialized
INFO - 2019-07-03 23:31:32 --> Model Class Initialized
INFO - 2019-07-03 23:31:32 --> Final output sent to browser
DEBUG - 2019-07-03 23:31:32 --> Total execution time: 1.2579
INFO - 2019-07-03 17:31:35 --> Config Class Initialized
INFO - 2019-07-03 17:31:35 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:31:35 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:31:35 --> Utf8 Class Initialized
INFO - 2019-07-03 17:31:35 --> URI Class Initialized
INFO - 2019-07-03 17:31:35 --> Router Class Initialized
INFO - 2019-07-03 17:31:35 --> Output Class Initialized
INFO - 2019-07-03 17:31:35 --> Security Class Initialized
DEBUG - 2019-07-03 17:31:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:31:35 --> Input Class Initialized
INFO - 2019-07-03 17:31:35 --> Language Class Initialized
INFO - 2019-07-03 17:31:35 --> Language Class Initialized
INFO - 2019-07-03 17:31:35 --> Config Class Initialized
INFO - 2019-07-03 17:31:36 --> Loader Class Initialized
DEBUG - 2019-07-03 17:31:36 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:31:36 --> Helper loaded: url_helper
INFO - 2019-07-03 17:31:36 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:31:36 --> Helper loaded: string_helper
INFO - 2019-07-03 17:31:36 --> Helper loaded: array_helper
INFO - 2019-07-03 17:31:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:31:36 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:31:36 --> Database Driver Class Initialized
INFO - 2019-07-03 17:31:36 --> Controller Class Initialized
INFO - 2019-07-03 23:31:36 --> Helper loaded: language_helper
INFO - 2019-07-03 23:31:36 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:31:36 --> Model Class Initialized
INFO - 2019-07-03 23:31:36 --> Model Class Initialized
INFO - 2019-07-03 23:31:36 --> Model Class Initialized
INFO - 2019-07-03 23:31:36 --> Model Class Initialized
INFO - 2019-07-03 23:31:36 --> Helper loaded: form_helper
INFO - 2019-07-03 23:31:36 --> Form Validation Class Initialized
DEBUG - 2019-07-03 23:31:36 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-03 23:31:36 --> Model Class Initialized
INFO - 2019-07-03 23:31:36 --> Model Class Initialized
INFO - 2019-07-03 17:31:53 --> Config Class Initialized
INFO - 2019-07-03 17:31:53 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:31:53 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:31:53 --> Utf8 Class Initialized
INFO - 2019-07-03 17:31:53 --> URI Class Initialized
INFO - 2019-07-03 17:31:53 --> Router Class Initialized
INFO - 2019-07-03 17:31:53 --> Output Class Initialized
INFO - 2019-07-03 17:31:53 --> Security Class Initialized
DEBUG - 2019-07-03 17:31:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:31:53 --> Input Class Initialized
INFO - 2019-07-03 17:31:53 --> Language Class Initialized
INFO - 2019-07-03 17:31:53 --> Language Class Initialized
INFO - 2019-07-03 17:31:53 --> Config Class Initialized
INFO - 2019-07-03 17:31:53 --> Loader Class Initialized
DEBUG - 2019-07-03 17:31:53 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:31:53 --> Helper loaded: url_helper
INFO - 2019-07-03 17:31:53 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:31:53 --> Helper loaded: string_helper
INFO - 2019-07-03 17:31:53 --> Helper loaded: array_helper
INFO - 2019-07-03 17:31:53 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:31:53 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:31:53 --> Database Driver Class Initialized
INFO - 2019-07-03 17:31:53 --> Controller Class Initialized
INFO - 2019-07-03 23:31:53 --> Helper loaded: language_helper
INFO - 2019-07-03 23:31:53 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:31:53 --> Model Class Initialized
INFO - 2019-07-03 23:31:53 --> Model Class Initialized
INFO - 2019-07-03 23:31:53 --> Model Class Initialized
INFO - 2019-07-03 23:31:53 --> Model Class Initialized
INFO - 2019-07-03 23:31:53 --> Helper loaded: form_helper
INFO - 2019-07-03 23:31:53 --> Form Validation Class Initialized
DEBUG - 2019-07-03 23:31:53 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-03 23:31:53 --> Model Class Initialized
INFO - 2019-07-03 23:31:53 --> Model Class Initialized
INFO - 2019-07-03 17:32:58 --> Config Class Initialized
INFO - 2019-07-03 17:32:58 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:32:58 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:32:58 --> Utf8 Class Initialized
INFO - 2019-07-03 17:32:58 --> URI Class Initialized
INFO - 2019-07-03 17:32:58 --> Router Class Initialized
INFO - 2019-07-03 17:32:58 --> Output Class Initialized
INFO - 2019-07-03 17:32:58 --> Security Class Initialized
DEBUG - 2019-07-03 17:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:32:58 --> Input Class Initialized
INFO - 2019-07-03 17:32:58 --> Language Class Initialized
INFO - 2019-07-03 17:32:58 --> Language Class Initialized
INFO - 2019-07-03 17:32:58 --> Config Class Initialized
INFO - 2019-07-03 17:32:58 --> Loader Class Initialized
DEBUG - 2019-07-03 17:32:58 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:32:58 --> Helper loaded: url_helper
INFO - 2019-07-03 17:32:58 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:32:58 --> Helper loaded: string_helper
INFO - 2019-07-03 17:32:58 --> Helper loaded: array_helper
INFO - 2019-07-03 17:32:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:32:58 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:32:58 --> Database Driver Class Initialized
INFO - 2019-07-03 17:32:58 --> Controller Class Initialized
INFO - 2019-07-03 23:32:58 --> Helper loaded: language_helper
INFO - 2019-07-03 23:32:58 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:32:58 --> Model Class Initialized
INFO - 2019-07-03 23:32:58 --> Model Class Initialized
INFO - 2019-07-03 23:32:58 --> Model Class Initialized
INFO - 2019-07-03 23:32:58 --> Model Class Initialized
INFO - 2019-07-03 23:32:59 --> Model Class Initialized
INFO - 2019-07-03 23:32:59 --> Final output sent to browser
DEBUG - 2019-07-03 23:32:59 --> Total execution time: 0.4924
INFO - 2019-07-03 17:32:59 --> Config Class Initialized
INFO - 2019-07-03 17:32:59 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:32:59 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:32:59 --> Utf8 Class Initialized
INFO - 2019-07-03 17:32:59 --> URI Class Initialized
INFO - 2019-07-03 17:32:59 --> Router Class Initialized
INFO - 2019-07-03 17:32:59 --> Output Class Initialized
INFO - 2019-07-03 17:32:59 --> Security Class Initialized
DEBUG - 2019-07-03 17:32:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:32:59 --> Input Class Initialized
INFO - 2019-07-03 17:32:59 --> Language Class Initialized
INFO - 2019-07-03 17:32:59 --> Language Class Initialized
INFO - 2019-07-03 17:32:59 --> Config Class Initialized
INFO - 2019-07-03 17:32:59 --> Loader Class Initialized
DEBUG - 2019-07-03 17:32:59 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:32:59 --> Helper loaded: url_helper
INFO - 2019-07-03 17:32:59 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:32:59 --> Helper loaded: string_helper
INFO - 2019-07-03 17:32:59 --> Helper loaded: array_helper
INFO - 2019-07-03 17:32:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:32:59 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:32:59 --> Database Driver Class Initialized
INFO - 2019-07-03 17:32:59 --> Controller Class Initialized
INFO - 2019-07-03 23:32:59 --> Helper loaded: language_helper
INFO - 2019-07-03 23:32:59 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:32:59 --> Model Class Initialized
INFO - 2019-07-03 23:32:59 --> Model Class Initialized
INFO - 2019-07-03 23:32:59 --> Model Class Initialized
INFO - 2019-07-03 23:32:59 --> Model Class Initialized
INFO - 2019-07-03 23:32:59 --> Helper loaded: form_helper
INFO - 2019-07-03 23:32:59 --> Form Validation Class Initialized
DEBUG - 2019-07-03 23:32:59 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-03 23:32:59 --> Model Class Initialized
INFO - 2019-07-03 23:32:59 --> Model Class Initialized
INFO - 2019-07-03 23:32:59 --> Final output sent to browser
DEBUG - 2019-07-03 23:32:59 --> Total execution time: 0.6057
INFO - 2019-07-03 17:33:02 --> Config Class Initialized
INFO - 2019-07-03 17:33:02 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:33:02 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:33:02 --> Utf8 Class Initialized
INFO - 2019-07-03 17:33:02 --> URI Class Initialized
INFO - 2019-07-03 17:33:02 --> Router Class Initialized
INFO - 2019-07-03 17:33:02 --> Output Class Initialized
INFO - 2019-07-03 17:33:02 --> Security Class Initialized
DEBUG - 2019-07-03 17:33:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:33:02 --> Input Class Initialized
INFO - 2019-07-03 17:33:02 --> Language Class Initialized
INFO - 2019-07-03 17:33:02 --> Language Class Initialized
INFO - 2019-07-03 17:33:02 --> Config Class Initialized
INFO - 2019-07-03 17:33:02 --> Loader Class Initialized
DEBUG - 2019-07-03 17:33:03 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:33:03 --> Helper loaded: url_helper
INFO - 2019-07-03 17:33:03 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:33:03 --> Helper loaded: string_helper
INFO - 2019-07-03 17:33:03 --> Helper loaded: array_helper
INFO - 2019-07-03 17:33:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:33:03 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:33:03 --> Database Driver Class Initialized
INFO - 2019-07-03 17:33:03 --> Controller Class Initialized
INFO - 2019-07-03 23:33:03 --> Helper loaded: language_helper
INFO - 2019-07-03 23:33:03 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:33:03 --> Model Class Initialized
INFO - 2019-07-03 23:33:03 --> Model Class Initialized
INFO - 2019-07-03 23:33:03 --> Model Class Initialized
INFO - 2019-07-03 23:33:03 --> Model Class Initialized
INFO - 2019-07-03 23:33:03 --> Helper loaded: form_helper
INFO - 2019-07-03 23:33:03 --> Form Validation Class Initialized
DEBUG - 2019-07-03 23:33:03 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-03 23:33:03 --> Model Class Initialized
INFO - 2019-07-03 23:33:03 --> Model Class Initialized
INFO - 2019-07-03 17:33:11 --> Config Class Initialized
INFO - 2019-07-03 17:33:11 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:33:11 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:33:11 --> Utf8 Class Initialized
INFO - 2019-07-03 17:33:11 --> URI Class Initialized
INFO - 2019-07-03 17:33:11 --> Router Class Initialized
INFO - 2019-07-03 17:33:11 --> Output Class Initialized
INFO - 2019-07-03 17:33:11 --> Security Class Initialized
DEBUG - 2019-07-03 17:33:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:33:11 --> Input Class Initialized
INFO - 2019-07-03 17:33:11 --> Language Class Initialized
INFO - 2019-07-03 17:33:11 --> Language Class Initialized
INFO - 2019-07-03 17:33:11 --> Config Class Initialized
INFO - 2019-07-03 17:33:11 --> Loader Class Initialized
DEBUG - 2019-07-03 17:33:11 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:33:11 --> Helper loaded: url_helper
INFO - 2019-07-03 17:33:11 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:33:11 --> Helper loaded: string_helper
INFO - 2019-07-03 17:33:11 --> Helper loaded: array_helper
INFO - 2019-07-03 17:33:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:33:11 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:33:11 --> Database Driver Class Initialized
INFO - 2019-07-03 17:33:11 --> Controller Class Initialized
INFO - 2019-07-03 23:33:12 --> Helper loaded: language_helper
INFO - 2019-07-03 23:33:12 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:33:12 --> Model Class Initialized
INFO - 2019-07-03 23:33:12 --> Model Class Initialized
INFO - 2019-07-03 23:33:12 --> Model Class Initialized
INFO - 2019-07-03 23:33:12 --> Model Class Initialized
INFO - 2019-07-03 23:33:12 --> Model Class Initialized
INFO - 2019-07-03 23:33:12 --> Final output sent to browser
DEBUG - 2019-07-03 23:33:12 --> Total execution time: 0.4667
INFO - 2019-07-03 17:33:12 --> Config Class Initialized
INFO - 2019-07-03 17:33:12 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:33:12 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:33:12 --> Utf8 Class Initialized
INFO - 2019-07-03 17:33:12 --> URI Class Initialized
INFO - 2019-07-03 17:33:12 --> Router Class Initialized
INFO - 2019-07-03 17:33:12 --> Output Class Initialized
INFO - 2019-07-03 17:33:12 --> Security Class Initialized
DEBUG - 2019-07-03 17:33:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:33:12 --> Input Class Initialized
INFO - 2019-07-03 17:33:12 --> Language Class Initialized
INFO - 2019-07-03 17:33:12 --> Language Class Initialized
INFO - 2019-07-03 17:33:12 --> Config Class Initialized
INFO - 2019-07-03 17:33:12 --> Loader Class Initialized
DEBUG - 2019-07-03 17:33:12 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:33:12 --> Helper loaded: url_helper
INFO - 2019-07-03 17:33:12 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:33:12 --> Helper loaded: string_helper
INFO - 2019-07-03 17:33:12 --> Helper loaded: array_helper
INFO - 2019-07-03 17:33:12 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:33:12 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:33:12 --> Database Driver Class Initialized
INFO - 2019-07-03 17:33:12 --> Controller Class Initialized
INFO - 2019-07-03 23:33:12 --> Helper loaded: language_helper
INFO - 2019-07-03 23:33:12 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:33:12 --> Model Class Initialized
INFO - 2019-07-03 23:33:12 --> Model Class Initialized
INFO - 2019-07-03 23:33:12 --> Model Class Initialized
INFO - 2019-07-03 23:33:12 --> Model Class Initialized
INFO - 2019-07-03 23:33:12 --> Helper loaded: form_helper
INFO - 2019-07-03 23:33:12 --> Form Validation Class Initialized
DEBUG - 2019-07-03 23:33:12 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-03 23:33:12 --> Model Class Initialized
INFO - 2019-07-03 23:33:12 --> Model Class Initialized
INFO - 2019-07-03 23:33:12 --> Final output sent to browser
DEBUG - 2019-07-03 23:33:12 --> Total execution time: 0.5188
INFO - 2019-07-03 17:33:13 --> Config Class Initialized
INFO - 2019-07-03 17:33:13 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:33:13 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:33:13 --> Utf8 Class Initialized
INFO - 2019-07-03 17:33:13 --> URI Class Initialized
INFO - 2019-07-03 17:33:13 --> Router Class Initialized
INFO - 2019-07-03 17:33:13 --> Output Class Initialized
INFO - 2019-07-03 17:33:13 --> Security Class Initialized
DEBUG - 2019-07-03 17:33:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:33:13 --> Input Class Initialized
INFO - 2019-07-03 17:33:13 --> Language Class Initialized
INFO - 2019-07-03 17:33:13 --> Language Class Initialized
INFO - 2019-07-03 17:33:13 --> Config Class Initialized
INFO - 2019-07-03 17:33:13 --> Loader Class Initialized
DEBUG - 2019-07-03 17:33:13 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:33:13 --> Helper loaded: url_helper
INFO - 2019-07-03 17:33:13 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:33:13 --> Helper loaded: string_helper
INFO - 2019-07-03 17:33:13 --> Helper loaded: array_helper
INFO - 2019-07-03 17:33:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:33:13 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:33:13 --> Database Driver Class Initialized
INFO - 2019-07-03 17:33:13 --> Controller Class Initialized
INFO - 2019-07-03 23:33:13 --> Helper loaded: language_helper
INFO - 2019-07-03 23:33:13 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:33:13 --> Model Class Initialized
INFO - 2019-07-03 23:33:13 --> Model Class Initialized
INFO - 2019-07-03 23:33:13 --> Model Class Initialized
INFO - 2019-07-03 23:33:13 --> Model Class Initialized
INFO - 2019-07-03 23:33:13 --> Helper loaded: form_helper
INFO - 2019-07-03 23:33:13 --> Form Validation Class Initialized
DEBUG - 2019-07-03 23:33:13 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-03 23:33:13 --> Model Class Initialized
INFO - 2019-07-03 23:33:13 --> Model Class Initialized
INFO - 2019-07-03 23:33:13 --> Final output sent to browser
DEBUG - 2019-07-03 23:33:13 --> Total execution time: 0.5298
INFO - 2019-07-03 17:37:07 --> Config Class Initialized
INFO - 2019-07-03 17:37:07 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:37:07 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:37:07 --> Utf8 Class Initialized
INFO - 2019-07-03 17:37:07 --> URI Class Initialized
INFO - 2019-07-03 17:37:07 --> Router Class Initialized
INFO - 2019-07-03 17:37:07 --> Output Class Initialized
INFO - 2019-07-03 17:37:07 --> Security Class Initialized
DEBUG - 2019-07-03 17:37:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:37:07 --> Input Class Initialized
INFO - 2019-07-03 17:37:07 --> Language Class Initialized
INFO - 2019-07-03 17:37:07 --> Language Class Initialized
INFO - 2019-07-03 17:37:07 --> Config Class Initialized
INFO - 2019-07-03 17:37:07 --> Loader Class Initialized
DEBUG - 2019-07-03 17:37:07 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:37:07 --> Helper loaded: url_helper
INFO - 2019-07-03 17:37:07 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:37:07 --> Helper loaded: string_helper
INFO - 2019-07-03 17:37:07 --> Helper loaded: array_helper
INFO - 2019-07-03 17:37:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:37:07 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:37:07 --> Database Driver Class Initialized
INFO - 2019-07-03 17:37:07 --> Controller Class Initialized
INFO - 2019-07-03 23:37:07 --> Helper loaded: language_helper
INFO - 2019-07-03 23:37:07 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:37:07 --> Model Class Initialized
INFO - 2019-07-03 23:37:07 --> Model Class Initialized
INFO - 2019-07-03 23:37:07 --> Model Class Initialized
INFO - 2019-07-03 23:37:07 --> Model Class Initialized
INFO - 2019-07-03 23:37:07 --> Model Class Initialized
INFO - 2019-07-03 23:37:07 --> Final output sent to browser
DEBUG - 2019-07-03 23:37:07 --> Total execution time: 0.4350
INFO - 2019-07-03 17:37:08 --> Config Class Initialized
INFO - 2019-07-03 17:37:08 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:37:08 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:37:08 --> Utf8 Class Initialized
INFO - 2019-07-03 17:37:08 --> URI Class Initialized
INFO - 2019-07-03 17:37:08 --> Router Class Initialized
INFO - 2019-07-03 17:37:08 --> Output Class Initialized
INFO - 2019-07-03 17:37:08 --> Security Class Initialized
DEBUG - 2019-07-03 17:37:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:37:08 --> Input Class Initialized
INFO - 2019-07-03 17:37:08 --> Language Class Initialized
INFO - 2019-07-03 17:37:08 --> Language Class Initialized
INFO - 2019-07-03 17:37:08 --> Config Class Initialized
INFO - 2019-07-03 17:37:08 --> Loader Class Initialized
DEBUG - 2019-07-03 17:37:08 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:37:08 --> Helper loaded: url_helper
INFO - 2019-07-03 17:37:08 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:37:08 --> Helper loaded: string_helper
INFO - 2019-07-03 17:37:08 --> Helper loaded: array_helper
INFO - 2019-07-03 17:37:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:37:08 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:37:08 --> Database Driver Class Initialized
INFO - 2019-07-03 17:37:08 --> Controller Class Initialized
INFO - 2019-07-03 23:37:08 --> Helper loaded: language_helper
INFO - 2019-07-03 23:37:08 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:37:08 --> Model Class Initialized
INFO - 2019-07-03 23:37:08 --> Model Class Initialized
INFO - 2019-07-03 23:37:08 --> Model Class Initialized
INFO - 2019-07-03 23:37:08 --> Model Class Initialized
INFO - 2019-07-03 23:37:08 --> Helper loaded: form_helper
INFO - 2019-07-03 23:37:08 --> Form Validation Class Initialized
DEBUG - 2019-07-03 23:37:08 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-03 23:37:08 --> Model Class Initialized
INFO - 2019-07-03 23:37:08 --> Model Class Initialized
INFO - 2019-07-03 23:37:08 --> Final output sent to browser
DEBUG - 2019-07-03 23:37:08 --> Total execution time: 0.4908
INFO - 2019-07-03 17:37:11 --> Config Class Initialized
INFO - 2019-07-03 17:37:11 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:37:11 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:37:11 --> Utf8 Class Initialized
INFO - 2019-07-03 17:37:11 --> URI Class Initialized
INFO - 2019-07-03 17:37:11 --> Router Class Initialized
INFO - 2019-07-03 17:37:11 --> Output Class Initialized
INFO - 2019-07-03 17:37:11 --> Security Class Initialized
DEBUG - 2019-07-03 17:37:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:37:11 --> Input Class Initialized
INFO - 2019-07-03 17:37:11 --> Language Class Initialized
INFO - 2019-07-03 17:37:11 --> Language Class Initialized
INFO - 2019-07-03 17:37:11 --> Config Class Initialized
INFO - 2019-07-03 17:37:11 --> Loader Class Initialized
DEBUG - 2019-07-03 17:37:11 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:37:11 --> Helper loaded: url_helper
INFO - 2019-07-03 17:37:11 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:37:11 --> Helper loaded: string_helper
INFO - 2019-07-03 17:37:11 --> Helper loaded: array_helper
INFO - 2019-07-03 17:37:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:37:11 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:37:11 --> Database Driver Class Initialized
INFO - 2019-07-03 17:37:11 --> Controller Class Initialized
INFO - 2019-07-03 23:37:11 --> Helper loaded: language_helper
INFO - 2019-07-03 23:37:11 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:37:11 --> Model Class Initialized
INFO - 2019-07-03 23:37:11 --> Model Class Initialized
INFO - 2019-07-03 23:37:11 --> Model Class Initialized
INFO - 2019-07-03 23:37:11 --> Model Class Initialized
INFO - 2019-07-03 23:37:11 --> Model Class Initialized
INFO - 2019-07-03 23:37:11 --> Final output sent to browser
DEBUG - 2019-07-03 23:37:11 --> Total execution time: 0.4575
INFO - 2019-07-03 17:37:12 --> Config Class Initialized
INFO - 2019-07-03 17:37:12 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:37:12 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:37:12 --> Utf8 Class Initialized
INFO - 2019-07-03 17:37:12 --> URI Class Initialized
INFO - 2019-07-03 17:37:12 --> Router Class Initialized
INFO - 2019-07-03 17:37:12 --> Output Class Initialized
INFO - 2019-07-03 17:37:12 --> Security Class Initialized
DEBUG - 2019-07-03 17:37:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:37:12 --> Input Class Initialized
INFO - 2019-07-03 17:37:12 --> Language Class Initialized
INFO - 2019-07-03 17:37:12 --> Language Class Initialized
INFO - 2019-07-03 17:37:12 --> Config Class Initialized
INFO - 2019-07-03 17:37:12 --> Loader Class Initialized
DEBUG - 2019-07-03 17:37:12 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:37:12 --> Helper loaded: url_helper
INFO - 2019-07-03 17:37:12 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:37:12 --> Helper loaded: string_helper
INFO - 2019-07-03 17:37:12 --> Helper loaded: array_helper
INFO - 2019-07-03 17:37:12 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:37:12 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:37:12 --> Database Driver Class Initialized
INFO - 2019-07-03 17:37:12 --> Controller Class Initialized
INFO - 2019-07-03 23:37:12 --> Helper loaded: language_helper
INFO - 2019-07-03 23:37:12 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:37:12 --> Model Class Initialized
INFO - 2019-07-03 23:37:12 --> Model Class Initialized
INFO - 2019-07-03 23:37:12 --> Model Class Initialized
INFO - 2019-07-03 23:37:12 --> Model Class Initialized
INFO - 2019-07-03 23:37:12 --> Helper loaded: form_helper
INFO - 2019-07-03 23:37:12 --> Form Validation Class Initialized
DEBUG - 2019-07-03 23:37:12 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-03 23:37:12 --> Model Class Initialized
INFO - 2019-07-03 23:37:12 --> Model Class Initialized
INFO - 2019-07-03 23:37:12 --> Final output sent to browser
DEBUG - 2019-07-03 23:37:12 --> Total execution time: 0.4925
INFO - 2019-07-03 17:37:29 --> Config Class Initialized
INFO - 2019-07-03 17:37:29 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:37:29 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:37:29 --> Utf8 Class Initialized
INFO - 2019-07-03 17:37:29 --> URI Class Initialized
INFO - 2019-07-03 17:37:29 --> Router Class Initialized
INFO - 2019-07-03 17:37:29 --> Output Class Initialized
INFO - 2019-07-03 17:37:29 --> Security Class Initialized
DEBUG - 2019-07-03 17:37:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:37:29 --> Input Class Initialized
INFO - 2019-07-03 17:37:29 --> Language Class Initialized
INFO - 2019-07-03 17:37:29 --> Language Class Initialized
INFO - 2019-07-03 17:37:29 --> Config Class Initialized
INFO - 2019-07-03 17:37:29 --> Loader Class Initialized
DEBUG - 2019-07-03 17:37:29 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:37:29 --> Helper loaded: url_helper
INFO - 2019-07-03 17:37:29 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:37:29 --> Helper loaded: string_helper
INFO - 2019-07-03 17:37:29 --> Helper loaded: array_helper
INFO - 2019-07-03 17:37:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:37:29 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:37:29 --> Database Driver Class Initialized
INFO - 2019-07-03 17:37:29 --> Controller Class Initialized
INFO - 2019-07-03 23:37:29 --> Helper loaded: language_helper
INFO - 2019-07-03 23:37:29 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:37:29 --> Model Class Initialized
INFO - 2019-07-03 23:37:29 --> Model Class Initialized
INFO - 2019-07-03 23:37:29 --> Model Class Initialized
INFO - 2019-07-03 23:37:29 --> Model Class Initialized
INFO - 2019-07-03 23:37:29 --> Model Class Initialized
INFO - 2019-07-03 23:37:29 --> Final output sent to browser
DEBUG - 2019-07-03 23:37:29 --> Total execution time: 0.4959
INFO - 2019-07-03 17:37:29 --> Config Class Initialized
INFO - 2019-07-03 17:37:29 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:37:29 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:37:29 --> Utf8 Class Initialized
INFO - 2019-07-03 17:37:29 --> URI Class Initialized
INFO - 2019-07-03 17:37:30 --> Router Class Initialized
INFO - 2019-07-03 17:37:30 --> Output Class Initialized
INFO - 2019-07-03 17:37:30 --> Security Class Initialized
DEBUG - 2019-07-03 17:37:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:37:30 --> Input Class Initialized
INFO - 2019-07-03 17:37:30 --> Language Class Initialized
INFO - 2019-07-03 17:37:30 --> Language Class Initialized
INFO - 2019-07-03 17:37:30 --> Config Class Initialized
INFO - 2019-07-03 17:37:30 --> Loader Class Initialized
DEBUG - 2019-07-03 17:37:30 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:37:30 --> Helper loaded: url_helper
INFO - 2019-07-03 17:37:30 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:37:30 --> Helper loaded: string_helper
INFO - 2019-07-03 17:37:30 --> Helper loaded: array_helper
INFO - 2019-07-03 17:37:30 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:37:30 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:37:30 --> Database Driver Class Initialized
INFO - 2019-07-03 17:37:30 --> Controller Class Initialized
INFO - 2019-07-03 23:37:30 --> Helper loaded: language_helper
INFO - 2019-07-03 23:37:30 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:37:30 --> Model Class Initialized
INFO - 2019-07-03 23:37:30 --> Model Class Initialized
INFO - 2019-07-03 23:37:30 --> Model Class Initialized
INFO - 2019-07-03 23:37:30 --> Model Class Initialized
INFO - 2019-07-03 23:37:30 --> Helper loaded: form_helper
INFO - 2019-07-03 23:37:30 --> Form Validation Class Initialized
DEBUG - 2019-07-03 23:37:30 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-03 23:37:30 --> Model Class Initialized
INFO - 2019-07-03 23:37:30 --> Model Class Initialized
INFO - 2019-07-03 23:37:30 --> Final output sent to browser
DEBUG - 2019-07-03 23:37:30 --> Total execution time: 0.5667
INFO - 2019-07-03 17:37:30 --> Config Class Initialized
INFO - 2019-07-03 17:37:30 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:37:30 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:37:30 --> Utf8 Class Initialized
INFO - 2019-07-03 17:37:30 --> URI Class Initialized
INFO - 2019-07-03 17:37:30 --> Router Class Initialized
INFO - 2019-07-03 17:37:30 --> Output Class Initialized
INFO - 2019-07-03 17:37:30 --> Security Class Initialized
DEBUG - 2019-07-03 17:37:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:37:30 --> Input Class Initialized
INFO - 2019-07-03 17:37:30 --> Language Class Initialized
INFO - 2019-07-03 17:37:30 --> Language Class Initialized
INFO - 2019-07-03 17:37:30 --> Config Class Initialized
INFO - 2019-07-03 17:37:30 --> Loader Class Initialized
DEBUG - 2019-07-03 17:37:30 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:37:30 --> Helper loaded: url_helper
INFO - 2019-07-03 17:37:30 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:37:30 --> Helper loaded: string_helper
INFO - 2019-07-03 17:37:30 --> Helper loaded: array_helper
INFO - 2019-07-03 17:37:30 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:37:30 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:37:30 --> Database Driver Class Initialized
INFO - 2019-07-03 17:37:30 --> Controller Class Initialized
INFO - 2019-07-03 23:37:31 --> Helper loaded: language_helper
INFO - 2019-07-03 23:37:31 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:37:31 --> Model Class Initialized
INFO - 2019-07-03 23:37:31 --> Model Class Initialized
INFO - 2019-07-03 23:37:31 --> Model Class Initialized
INFO - 2019-07-03 23:37:31 --> Model Class Initialized
INFO - 2019-07-03 23:37:31 --> Model Class Initialized
INFO - 2019-07-03 23:37:31 --> Final output sent to browser
DEBUG - 2019-07-03 23:37:31 --> Total execution time: 0.4498
INFO - 2019-07-03 17:37:31 --> Config Class Initialized
INFO - 2019-07-03 17:37:31 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:37:31 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:37:31 --> Utf8 Class Initialized
INFO - 2019-07-03 17:37:31 --> URI Class Initialized
INFO - 2019-07-03 17:37:31 --> Router Class Initialized
INFO - 2019-07-03 17:37:31 --> Output Class Initialized
INFO - 2019-07-03 17:37:31 --> Security Class Initialized
DEBUG - 2019-07-03 17:37:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:37:31 --> Input Class Initialized
INFO - 2019-07-03 17:37:31 --> Language Class Initialized
INFO - 2019-07-03 17:37:31 --> Language Class Initialized
INFO - 2019-07-03 17:37:31 --> Config Class Initialized
INFO - 2019-07-03 17:37:31 --> Loader Class Initialized
DEBUG - 2019-07-03 17:37:31 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:37:31 --> Helper loaded: url_helper
INFO - 2019-07-03 17:37:31 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:37:31 --> Helper loaded: string_helper
INFO - 2019-07-03 17:37:31 --> Helper loaded: array_helper
INFO - 2019-07-03 17:37:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:37:31 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:37:31 --> Database Driver Class Initialized
INFO - 2019-07-03 17:37:31 --> Controller Class Initialized
INFO - 2019-07-03 23:37:31 --> Helper loaded: language_helper
INFO - 2019-07-03 23:37:31 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:37:31 --> Model Class Initialized
INFO - 2019-07-03 23:37:31 --> Model Class Initialized
INFO - 2019-07-03 23:37:31 --> Model Class Initialized
INFO - 2019-07-03 23:37:31 --> Model Class Initialized
INFO - 2019-07-03 23:37:31 --> Helper loaded: form_helper
INFO - 2019-07-03 23:37:31 --> Form Validation Class Initialized
DEBUG - 2019-07-03 23:37:31 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-03 23:37:31 --> Model Class Initialized
INFO - 2019-07-03 23:37:31 --> Model Class Initialized
INFO - 2019-07-03 23:37:31 --> Final output sent to browser
DEBUG - 2019-07-03 23:37:31 --> Total execution time: 0.5366
INFO - 2019-07-03 17:37:34 --> Config Class Initialized
INFO - 2019-07-03 17:37:34 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:37:34 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:37:34 --> Utf8 Class Initialized
INFO - 2019-07-03 17:37:34 --> URI Class Initialized
INFO - 2019-07-03 17:37:34 --> Router Class Initialized
INFO - 2019-07-03 17:37:34 --> Output Class Initialized
INFO - 2019-07-03 17:37:34 --> Security Class Initialized
DEBUG - 2019-07-03 17:37:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:37:34 --> Input Class Initialized
INFO - 2019-07-03 17:37:34 --> Language Class Initialized
INFO - 2019-07-03 17:37:34 --> Language Class Initialized
INFO - 2019-07-03 17:37:34 --> Config Class Initialized
INFO - 2019-07-03 17:37:34 --> Loader Class Initialized
DEBUG - 2019-07-03 17:37:34 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:37:34 --> Helper loaded: url_helper
INFO - 2019-07-03 17:37:34 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:37:34 --> Helper loaded: string_helper
INFO - 2019-07-03 17:37:34 --> Helper loaded: array_helper
INFO - 2019-07-03 17:37:34 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:37:34 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:37:34 --> Database Driver Class Initialized
INFO - 2019-07-03 17:37:34 --> Controller Class Initialized
INFO - 2019-07-03 23:37:34 --> Helper loaded: language_helper
INFO - 2019-07-03 23:37:34 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:37:34 --> Model Class Initialized
INFO - 2019-07-03 23:37:34 --> Model Class Initialized
INFO - 2019-07-03 23:37:34 --> Model Class Initialized
INFO - 2019-07-03 23:37:34 --> Model Class Initialized
INFO - 2019-07-03 23:37:34 --> Helper loaded: form_helper
INFO - 2019-07-03 23:37:34 --> Form Validation Class Initialized
DEBUG - 2019-07-03 23:37:34 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-03 23:37:34 --> Model Class Initialized
INFO - 2019-07-03 23:37:34 --> Model Class Initialized
INFO - 2019-07-03 23:37:34 --> Final output sent to browser
DEBUG - 2019-07-03 23:37:34 --> Total execution time: 0.5278
INFO - 2019-07-03 17:37:40 --> Config Class Initialized
INFO - 2019-07-03 17:37:40 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:37:40 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:37:40 --> Utf8 Class Initialized
INFO - 2019-07-03 17:37:40 --> URI Class Initialized
INFO - 2019-07-03 17:37:40 --> Router Class Initialized
INFO - 2019-07-03 17:37:40 --> Output Class Initialized
INFO - 2019-07-03 17:37:40 --> Security Class Initialized
DEBUG - 2019-07-03 17:37:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:37:40 --> Input Class Initialized
INFO - 2019-07-03 17:37:40 --> Language Class Initialized
INFO - 2019-07-03 17:37:40 --> Language Class Initialized
INFO - 2019-07-03 17:37:40 --> Config Class Initialized
INFO - 2019-07-03 17:37:40 --> Loader Class Initialized
DEBUG - 2019-07-03 17:37:40 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:37:40 --> Helper loaded: url_helper
INFO - 2019-07-03 17:37:40 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:37:40 --> Helper loaded: string_helper
INFO - 2019-07-03 17:37:40 --> Helper loaded: array_helper
INFO - 2019-07-03 17:37:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:37:40 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:37:40 --> Database Driver Class Initialized
INFO - 2019-07-03 17:37:40 --> Controller Class Initialized
INFO - 2019-07-03 23:37:40 --> Helper loaded: language_helper
INFO - 2019-07-03 23:37:41 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:37:41 --> Model Class Initialized
INFO - 2019-07-03 23:37:41 --> Model Class Initialized
INFO - 2019-07-03 23:37:41 --> Model Class Initialized
INFO - 2019-07-03 23:37:41 --> Model Class Initialized
INFO - 2019-07-03 23:37:41 --> Helper loaded: form_helper
INFO - 2019-07-03 23:37:41 --> Form Validation Class Initialized
DEBUG - 2019-07-03 23:37:41 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-03 23:37:41 --> Model Class Initialized
INFO - 2019-07-03 23:37:41 --> Model Class Initialized
INFO - 2019-07-03 23:37:41 --> Final output sent to browser
DEBUG - 2019-07-03 23:37:41 --> Total execution time: 0.5391
INFO - 2019-07-03 17:40:21 --> Config Class Initialized
INFO - 2019-07-03 17:40:21 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:40:21 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:40:21 --> Utf8 Class Initialized
INFO - 2019-07-03 17:40:21 --> URI Class Initialized
INFO - 2019-07-03 17:40:21 --> Router Class Initialized
INFO - 2019-07-03 17:40:21 --> Output Class Initialized
INFO - 2019-07-03 17:40:21 --> Security Class Initialized
DEBUG - 2019-07-03 17:40:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:40:21 --> Input Class Initialized
INFO - 2019-07-03 17:40:22 --> Language Class Initialized
INFO - 2019-07-03 17:40:22 --> Language Class Initialized
INFO - 2019-07-03 17:40:22 --> Config Class Initialized
INFO - 2019-07-03 17:40:22 --> Loader Class Initialized
DEBUG - 2019-07-03 17:40:22 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:40:22 --> Helper loaded: url_helper
INFO - 2019-07-03 17:40:22 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:40:22 --> Helper loaded: string_helper
INFO - 2019-07-03 17:40:22 --> Helper loaded: array_helper
INFO - 2019-07-03 17:40:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:40:22 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:40:22 --> Database Driver Class Initialized
INFO - 2019-07-03 17:40:22 --> Controller Class Initialized
INFO - 2019-07-03 23:40:22 --> Helper loaded: language_helper
INFO - 2019-07-03 23:40:22 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:40:22 --> Model Class Initialized
INFO - 2019-07-03 23:40:22 --> Model Class Initialized
INFO - 2019-07-03 23:40:22 --> Model Class Initialized
INFO - 2019-07-03 23:40:22 --> Model Class Initialized
INFO - 2019-07-03 23:40:22 --> Model Class Initialized
INFO - 2019-07-03 23:40:22 --> Final output sent to browser
DEBUG - 2019-07-03 23:40:22 --> Total execution time: 0.4795
INFO - 2019-07-03 17:40:22 --> Config Class Initialized
INFO - 2019-07-03 17:40:22 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:40:22 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:40:22 --> Utf8 Class Initialized
INFO - 2019-07-03 17:40:22 --> URI Class Initialized
INFO - 2019-07-03 17:40:22 --> Router Class Initialized
INFO - 2019-07-03 17:40:22 --> Output Class Initialized
INFO - 2019-07-03 17:40:22 --> Security Class Initialized
DEBUG - 2019-07-03 17:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:40:22 --> Input Class Initialized
INFO - 2019-07-03 17:40:22 --> Language Class Initialized
INFO - 2019-07-03 17:40:22 --> Language Class Initialized
INFO - 2019-07-03 17:40:22 --> Config Class Initialized
INFO - 2019-07-03 17:40:22 --> Loader Class Initialized
DEBUG - 2019-07-03 17:40:22 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:40:22 --> Helper loaded: url_helper
INFO - 2019-07-03 17:40:22 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:40:22 --> Helper loaded: string_helper
INFO - 2019-07-03 17:40:22 --> Helper loaded: array_helper
INFO - 2019-07-03 17:40:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:40:22 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:40:22 --> Database Driver Class Initialized
INFO - 2019-07-03 17:40:22 --> Controller Class Initialized
INFO - 2019-07-03 23:40:22 --> Helper loaded: language_helper
INFO - 2019-07-03 23:40:22 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:40:22 --> Model Class Initialized
INFO - 2019-07-03 23:40:22 --> Model Class Initialized
INFO - 2019-07-03 23:40:22 --> Model Class Initialized
INFO - 2019-07-03 23:40:22 --> Model Class Initialized
INFO - 2019-07-03 23:40:22 --> Helper loaded: form_helper
INFO - 2019-07-03 23:40:22 --> Form Validation Class Initialized
DEBUG - 2019-07-03 23:40:22 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-03 23:40:22 --> Model Class Initialized
INFO - 2019-07-03 23:40:22 --> Model Class Initialized
INFO - 2019-07-03 23:40:22 --> Final output sent to browser
DEBUG - 2019-07-03 23:40:22 --> Total execution time: 0.5349
INFO - 2019-07-03 17:41:21 --> Config Class Initialized
INFO - 2019-07-03 17:41:21 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:41:21 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:41:22 --> Utf8 Class Initialized
INFO - 2019-07-03 17:41:22 --> URI Class Initialized
INFO - 2019-07-03 17:41:22 --> Router Class Initialized
INFO - 2019-07-03 17:41:22 --> Output Class Initialized
INFO - 2019-07-03 17:41:22 --> Security Class Initialized
DEBUG - 2019-07-03 17:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:41:22 --> Input Class Initialized
INFO - 2019-07-03 17:41:22 --> Language Class Initialized
INFO - 2019-07-03 17:41:22 --> Language Class Initialized
INFO - 2019-07-03 17:41:22 --> Config Class Initialized
INFO - 2019-07-03 17:41:22 --> Loader Class Initialized
DEBUG - 2019-07-03 17:41:22 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:41:22 --> Helper loaded: url_helper
INFO - 2019-07-03 17:41:22 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:41:22 --> Helper loaded: string_helper
INFO - 2019-07-03 17:41:22 --> Helper loaded: array_helper
INFO - 2019-07-03 17:41:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:41:22 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:41:22 --> Database Driver Class Initialized
INFO - 2019-07-03 17:41:22 --> Controller Class Initialized
INFO - 2019-07-03 23:41:22 --> Helper loaded: language_helper
INFO - 2019-07-03 23:41:22 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:41:22 --> Model Class Initialized
INFO - 2019-07-03 23:41:22 --> Model Class Initialized
INFO - 2019-07-03 23:41:22 --> Model Class Initialized
INFO - 2019-07-03 23:41:22 --> Model Class Initialized
INFO - 2019-07-03 23:41:22 --> Model Class Initialized
INFO - 2019-07-03 23:41:22 --> Final output sent to browser
DEBUG - 2019-07-03 23:41:22 --> Total execution time: 0.5010
INFO - 2019-07-03 17:41:22 --> Config Class Initialized
INFO - 2019-07-03 17:41:22 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:41:22 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:41:22 --> Utf8 Class Initialized
INFO - 2019-07-03 17:41:22 --> URI Class Initialized
INFO - 2019-07-03 17:41:22 --> Router Class Initialized
INFO - 2019-07-03 17:41:22 --> Output Class Initialized
INFO - 2019-07-03 17:41:22 --> Security Class Initialized
DEBUG - 2019-07-03 17:41:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:41:22 --> Input Class Initialized
INFO - 2019-07-03 17:41:22 --> Language Class Initialized
INFO - 2019-07-03 17:41:22 --> Language Class Initialized
INFO - 2019-07-03 17:41:22 --> Config Class Initialized
INFO - 2019-07-03 17:41:22 --> Loader Class Initialized
DEBUG - 2019-07-03 17:41:22 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:41:22 --> Helper loaded: url_helper
INFO - 2019-07-03 17:41:22 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:41:22 --> Helper loaded: string_helper
INFO - 2019-07-03 17:41:22 --> Helper loaded: array_helper
INFO - 2019-07-03 17:41:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:41:22 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:41:22 --> Database Driver Class Initialized
INFO - 2019-07-03 17:41:22 --> Controller Class Initialized
INFO - 2019-07-03 23:41:22 --> Helper loaded: language_helper
INFO - 2019-07-03 23:41:22 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:41:22 --> Model Class Initialized
INFO - 2019-07-03 23:41:22 --> Model Class Initialized
INFO - 2019-07-03 23:41:22 --> Model Class Initialized
INFO - 2019-07-03 23:41:22 --> Model Class Initialized
INFO - 2019-07-03 23:41:22 --> Helper loaded: form_helper
INFO - 2019-07-03 23:41:23 --> Form Validation Class Initialized
DEBUG - 2019-07-03 23:41:23 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-03 23:41:23 --> Model Class Initialized
INFO - 2019-07-03 23:41:23 --> Model Class Initialized
INFO - 2019-07-03 23:41:23 --> Final output sent to browser
DEBUG - 2019-07-03 23:41:23 --> Total execution time: 0.5723
INFO - 2019-07-03 17:41:24 --> Config Class Initialized
INFO - 2019-07-03 17:41:24 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:41:24 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:41:24 --> Utf8 Class Initialized
INFO - 2019-07-03 17:41:24 --> URI Class Initialized
INFO - 2019-07-03 17:41:24 --> Router Class Initialized
INFO - 2019-07-03 17:41:24 --> Output Class Initialized
INFO - 2019-07-03 17:41:24 --> Security Class Initialized
DEBUG - 2019-07-03 17:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:41:24 --> Input Class Initialized
INFO - 2019-07-03 17:41:24 --> Language Class Initialized
INFO - 2019-07-03 17:41:24 --> Language Class Initialized
INFO - 2019-07-03 17:41:24 --> Config Class Initialized
INFO - 2019-07-03 17:41:24 --> Loader Class Initialized
DEBUG - 2019-07-03 17:41:24 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:41:24 --> Helper loaded: url_helper
INFO - 2019-07-03 17:41:24 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:41:24 --> Helper loaded: string_helper
INFO - 2019-07-03 17:41:24 --> Helper loaded: array_helper
INFO - 2019-07-03 17:41:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:41:24 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:41:24 --> Database Driver Class Initialized
INFO - 2019-07-03 17:41:24 --> Controller Class Initialized
INFO - 2019-07-03 23:41:24 --> Helper loaded: language_helper
INFO - 2019-07-03 23:41:24 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:41:24 --> Model Class Initialized
INFO - 2019-07-03 23:41:24 --> Model Class Initialized
INFO - 2019-07-03 23:41:24 --> Model Class Initialized
INFO - 2019-07-03 23:41:24 --> Model Class Initialized
INFO - 2019-07-03 23:41:24 --> Helper loaded: form_helper
INFO - 2019-07-03 23:41:24 --> Form Validation Class Initialized
DEBUG - 2019-07-03 23:41:24 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-03 23:41:24 --> Model Class Initialized
INFO - 2019-07-03 23:41:24 --> Model Class Initialized
INFO - 2019-07-03 23:41:25 --> Final output sent to browser
DEBUG - 2019-07-03 23:41:25 --> Total execution time: 0.5814
INFO - 2019-07-03 17:42:19 --> Config Class Initialized
INFO - 2019-07-03 17:42:19 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:42:19 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:42:19 --> Utf8 Class Initialized
INFO - 2019-07-03 17:42:19 --> URI Class Initialized
INFO - 2019-07-03 17:42:19 --> Router Class Initialized
INFO - 2019-07-03 17:42:19 --> Output Class Initialized
INFO - 2019-07-03 17:42:19 --> Security Class Initialized
DEBUG - 2019-07-03 17:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:42:19 --> Input Class Initialized
INFO - 2019-07-03 17:42:19 --> Language Class Initialized
INFO - 2019-07-03 17:42:19 --> Language Class Initialized
INFO - 2019-07-03 17:42:19 --> Config Class Initialized
INFO - 2019-07-03 17:42:19 --> Loader Class Initialized
DEBUG - 2019-07-03 17:42:19 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:42:19 --> Helper loaded: url_helper
INFO - 2019-07-03 17:42:19 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:42:19 --> Helper loaded: string_helper
INFO - 2019-07-03 17:42:19 --> Helper loaded: array_helper
INFO - 2019-07-03 17:42:19 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:42:19 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:42:19 --> Database Driver Class Initialized
INFO - 2019-07-03 17:42:19 --> Controller Class Initialized
INFO - 2019-07-03 23:42:19 --> Helper loaded: language_helper
INFO - 2019-07-03 23:42:19 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:42:19 --> Model Class Initialized
INFO - 2019-07-03 23:42:19 --> Model Class Initialized
INFO - 2019-07-03 23:42:19 --> Model Class Initialized
INFO - 2019-07-03 23:42:19 --> Model Class Initialized
INFO - 2019-07-03 23:42:19 --> Model Class Initialized
INFO - 2019-07-03 23:42:19 --> Final output sent to browser
DEBUG - 2019-07-03 23:42:19 --> Total execution time: 0.4729
INFO - 2019-07-03 17:42:19 --> Config Class Initialized
INFO - 2019-07-03 17:42:19 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:42:19 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:42:19 --> Utf8 Class Initialized
INFO - 2019-07-03 17:42:19 --> URI Class Initialized
INFO - 2019-07-03 17:42:19 --> Router Class Initialized
INFO - 2019-07-03 17:42:19 --> Output Class Initialized
INFO - 2019-07-03 17:42:19 --> Security Class Initialized
DEBUG - 2019-07-03 17:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:42:19 --> Input Class Initialized
INFO - 2019-07-03 17:42:19 --> Language Class Initialized
INFO - 2019-07-03 17:42:19 --> Language Class Initialized
INFO - 2019-07-03 17:42:19 --> Config Class Initialized
INFO - 2019-07-03 17:42:19 --> Loader Class Initialized
DEBUG - 2019-07-03 17:42:19 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:42:19 --> Helper loaded: url_helper
INFO - 2019-07-03 17:42:19 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:42:19 --> Helper loaded: string_helper
INFO - 2019-07-03 17:42:19 --> Helper loaded: array_helper
INFO - 2019-07-03 17:42:19 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:42:19 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:42:19 --> Database Driver Class Initialized
INFO - 2019-07-03 17:42:19 --> Controller Class Initialized
INFO - 2019-07-03 23:42:19 --> Helper loaded: language_helper
INFO - 2019-07-03 23:42:19 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:42:20 --> Model Class Initialized
INFO - 2019-07-03 23:42:20 --> Model Class Initialized
INFO - 2019-07-03 23:42:20 --> Model Class Initialized
INFO - 2019-07-03 23:42:20 --> Model Class Initialized
INFO - 2019-07-03 23:42:20 --> Helper loaded: form_helper
INFO - 2019-07-03 23:42:20 --> Form Validation Class Initialized
DEBUG - 2019-07-03 23:42:20 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-03 23:42:20 --> Model Class Initialized
INFO - 2019-07-03 23:42:20 --> Model Class Initialized
INFO - 2019-07-03 23:42:20 --> Final output sent to browser
DEBUG - 2019-07-03 23:42:20 --> Total execution time: 0.5485
INFO - 2019-07-03 17:42:25 --> Config Class Initialized
INFO - 2019-07-03 17:42:25 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:42:25 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:42:25 --> Utf8 Class Initialized
INFO - 2019-07-03 17:42:25 --> URI Class Initialized
INFO - 2019-07-03 17:42:25 --> Router Class Initialized
INFO - 2019-07-03 17:42:25 --> Output Class Initialized
INFO - 2019-07-03 17:42:25 --> Security Class Initialized
DEBUG - 2019-07-03 17:42:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:42:25 --> Input Class Initialized
INFO - 2019-07-03 17:42:25 --> Language Class Initialized
INFO - 2019-07-03 17:42:25 --> Language Class Initialized
INFO - 2019-07-03 17:42:25 --> Config Class Initialized
INFO - 2019-07-03 17:42:25 --> Loader Class Initialized
DEBUG - 2019-07-03 17:42:25 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:42:25 --> Helper loaded: url_helper
INFO - 2019-07-03 17:42:25 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:42:25 --> Helper loaded: string_helper
INFO - 2019-07-03 17:42:25 --> Helper loaded: array_helper
INFO - 2019-07-03 17:42:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:42:25 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:42:25 --> Database Driver Class Initialized
INFO - 2019-07-03 17:42:25 --> Controller Class Initialized
INFO - 2019-07-03 23:42:25 --> Helper loaded: language_helper
INFO - 2019-07-03 23:42:25 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:42:25 --> Model Class Initialized
INFO - 2019-07-03 23:42:25 --> Model Class Initialized
INFO - 2019-07-03 23:42:25 --> Model Class Initialized
INFO - 2019-07-03 23:42:25 --> Model Class Initialized
INFO - 2019-07-03 23:42:25 --> Model Class Initialized
INFO - 2019-07-03 23:42:25 --> Final output sent to browser
DEBUG - 2019-07-03 23:42:25 --> Total execution time: 0.4870
INFO - 2019-07-03 17:42:25 --> Config Class Initialized
INFO - 2019-07-03 17:42:25 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:42:25 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:42:25 --> Utf8 Class Initialized
INFO - 2019-07-03 17:42:25 --> URI Class Initialized
INFO - 2019-07-03 17:42:25 --> Router Class Initialized
INFO - 2019-07-03 17:42:25 --> Output Class Initialized
INFO - 2019-07-03 17:42:25 --> Security Class Initialized
DEBUG - 2019-07-03 17:42:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:42:25 --> Input Class Initialized
INFO - 2019-07-03 17:42:25 --> Language Class Initialized
INFO - 2019-07-03 17:42:25 --> Language Class Initialized
INFO - 2019-07-03 17:42:25 --> Config Class Initialized
INFO - 2019-07-03 17:42:25 --> Loader Class Initialized
DEBUG - 2019-07-03 17:42:25 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:42:26 --> Helper loaded: url_helper
INFO - 2019-07-03 17:42:26 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:42:26 --> Helper loaded: string_helper
INFO - 2019-07-03 17:42:26 --> Helper loaded: array_helper
INFO - 2019-07-03 17:42:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:42:26 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:42:26 --> Database Driver Class Initialized
INFO - 2019-07-03 17:42:26 --> Controller Class Initialized
INFO - 2019-07-03 23:42:26 --> Helper loaded: language_helper
INFO - 2019-07-03 23:42:26 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:42:26 --> Model Class Initialized
INFO - 2019-07-03 23:42:26 --> Model Class Initialized
INFO - 2019-07-03 23:42:26 --> Model Class Initialized
INFO - 2019-07-03 23:42:26 --> Model Class Initialized
INFO - 2019-07-03 23:42:26 --> Helper loaded: form_helper
INFO - 2019-07-03 23:42:26 --> Form Validation Class Initialized
DEBUG - 2019-07-03 23:42:26 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-03 23:42:26 --> Model Class Initialized
INFO - 2019-07-03 23:42:26 --> Model Class Initialized
INFO - 2019-07-03 23:42:26 --> Final output sent to browser
DEBUG - 2019-07-03 23:42:26 --> Total execution time: 0.5460
INFO - 2019-07-03 17:42:31 --> Config Class Initialized
INFO - 2019-07-03 17:42:31 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:42:31 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:42:31 --> Utf8 Class Initialized
INFO - 2019-07-03 17:42:31 --> URI Class Initialized
INFO - 2019-07-03 17:42:31 --> Router Class Initialized
INFO - 2019-07-03 17:42:31 --> Output Class Initialized
INFO - 2019-07-03 17:42:31 --> Security Class Initialized
DEBUG - 2019-07-03 17:42:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:42:31 --> Input Class Initialized
INFO - 2019-07-03 17:42:31 --> Language Class Initialized
INFO - 2019-07-03 17:42:31 --> Language Class Initialized
INFO - 2019-07-03 17:42:31 --> Config Class Initialized
INFO - 2019-07-03 17:42:31 --> Loader Class Initialized
DEBUG - 2019-07-03 17:42:31 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:42:31 --> Helper loaded: url_helper
INFO - 2019-07-03 17:42:31 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:42:31 --> Helper loaded: string_helper
INFO - 2019-07-03 17:42:31 --> Helper loaded: array_helper
INFO - 2019-07-03 17:42:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:42:31 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:42:31 --> Database Driver Class Initialized
INFO - 2019-07-03 17:42:31 --> Controller Class Initialized
INFO - 2019-07-03 23:42:31 --> Helper loaded: language_helper
INFO - 2019-07-03 23:42:31 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:42:31 --> Model Class Initialized
INFO - 2019-07-03 23:42:31 --> Model Class Initialized
INFO - 2019-07-03 23:42:31 --> Model Class Initialized
INFO - 2019-07-03 23:42:31 --> Model Class Initialized
INFO - 2019-07-03 23:42:31 --> Model Class Initialized
INFO - 2019-07-03 23:42:31 --> Final output sent to browser
DEBUG - 2019-07-03 23:42:31 --> Total execution time: 0.4758
INFO - 2019-07-03 17:42:31 --> Config Class Initialized
INFO - 2019-07-03 17:42:31 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:42:31 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:42:31 --> Utf8 Class Initialized
INFO - 2019-07-03 17:42:31 --> URI Class Initialized
INFO - 2019-07-03 17:42:31 --> Router Class Initialized
INFO - 2019-07-03 17:42:31 --> Output Class Initialized
INFO - 2019-07-03 17:42:31 --> Security Class Initialized
DEBUG - 2019-07-03 17:42:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:42:32 --> Input Class Initialized
INFO - 2019-07-03 17:42:32 --> Language Class Initialized
INFO - 2019-07-03 17:42:32 --> Language Class Initialized
INFO - 2019-07-03 17:42:32 --> Config Class Initialized
INFO - 2019-07-03 17:42:32 --> Loader Class Initialized
DEBUG - 2019-07-03 17:42:32 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:42:32 --> Helper loaded: url_helper
INFO - 2019-07-03 17:42:32 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:42:32 --> Helper loaded: string_helper
INFO - 2019-07-03 17:42:32 --> Helper loaded: array_helper
INFO - 2019-07-03 17:42:32 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:42:32 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:42:32 --> Database Driver Class Initialized
INFO - 2019-07-03 17:42:32 --> Controller Class Initialized
INFO - 2019-07-03 23:42:32 --> Helper loaded: language_helper
INFO - 2019-07-03 23:42:32 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:42:32 --> Model Class Initialized
INFO - 2019-07-03 23:42:32 --> Model Class Initialized
INFO - 2019-07-03 23:42:32 --> Model Class Initialized
INFO - 2019-07-03 23:42:32 --> Model Class Initialized
INFO - 2019-07-03 23:42:32 --> Helper loaded: form_helper
INFO - 2019-07-03 23:42:32 --> Form Validation Class Initialized
DEBUG - 2019-07-03 23:42:32 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-03 23:42:32 --> Model Class Initialized
INFO - 2019-07-03 23:42:32 --> Model Class Initialized
INFO - 2019-07-03 23:42:32 --> Final output sent to browser
DEBUG - 2019-07-03 23:42:32 --> Total execution time: 0.5282
INFO - 2019-07-03 17:42:49 --> Config Class Initialized
INFO - 2019-07-03 17:42:49 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:42:49 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:42:49 --> Utf8 Class Initialized
INFO - 2019-07-03 17:42:49 --> URI Class Initialized
INFO - 2019-07-03 17:42:49 --> Router Class Initialized
INFO - 2019-07-03 17:42:49 --> Output Class Initialized
INFO - 2019-07-03 17:42:49 --> Security Class Initialized
DEBUG - 2019-07-03 17:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:42:49 --> Input Class Initialized
INFO - 2019-07-03 17:42:49 --> Language Class Initialized
INFO - 2019-07-03 17:42:49 --> Language Class Initialized
INFO - 2019-07-03 17:42:49 --> Config Class Initialized
INFO - 2019-07-03 17:42:49 --> Loader Class Initialized
DEBUG - 2019-07-03 17:42:49 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:42:49 --> Helper loaded: url_helper
INFO - 2019-07-03 17:42:49 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:42:49 --> Helper loaded: string_helper
INFO - 2019-07-03 17:42:49 --> Helper loaded: array_helper
INFO - 2019-07-03 17:42:49 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:42:49 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:42:49 --> Database Driver Class Initialized
INFO - 2019-07-03 17:42:49 --> Controller Class Initialized
INFO - 2019-07-03 23:42:49 --> Helper loaded: language_helper
INFO - 2019-07-03 23:42:49 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:42:49 --> Model Class Initialized
INFO - 2019-07-03 23:42:49 --> Model Class Initialized
INFO - 2019-07-03 23:42:49 --> Model Class Initialized
INFO - 2019-07-03 23:42:49 --> Model Class Initialized
INFO - 2019-07-03 23:42:49 --> Model Class Initialized
INFO - 2019-07-03 23:42:49 --> Final output sent to browser
DEBUG - 2019-07-03 23:42:50 --> Total execution time: 0.5066
INFO - 2019-07-03 17:42:50 --> Config Class Initialized
INFO - 2019-07-03 17:42:50 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:42:50 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:42:50 --> Utf8 Class Initialized
INFO - 2019-07-03 17:42:50 --> URI Class Initialized
INFO - 2019-07-03 17:42:50 --> Router Class Initialized
INFO - 2019-07-03 17:42:50 --> Output Class Initialized
INFO - 2019-07-03 17:42:50 --> Security Class Initialized
DEBUG - 2019-07-03 17:42:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:42:50 --> Input Class Initialized
INFO - 2019-07-03 17:42:50 --> Language Class Initialized
INFO - 2019-07-03 17:42:50 --> Language Class Initialized
INFO - 2019-07-03 17:42:50 --> Config Class Initialized
INFO - 2019-07-03 17:42:50 --> Loader Class Initialized
DEBUG - 2019-07-03 17:42:50 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:42:50 --> Helper loaded: url_helper
INFO - 2019-07-03 17:42:50 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:42:50 --> Helper loaded: string_helper
INFO - 2019-07-03 17:42:50 --> Helper loaded: array_helper
INFO - 2019-07-03 17:42:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:42:50 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:42:50 --> Database Driver Class Initialized
INFO - 2019-07-03 17:42:50 --> Controller Class Initialized
INFO - 2019-07-03 23:42:50 --> Helper loaded: language_helper
INFO - 2019-07-03 23:42:50 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:42:50 --> Model Class Initialized
INFO - 2019-07-03 23:42:50 --> Model Class Initialized
INFO - 2019-07-03 23:42:50 --> Model Class Initialized
INFO - 2019-07-03 23:42:50 --> Model Class Initialized
INFO - 2019-07-03 23:42:50 --> Helper loaded: form_helper
INFO - 2019-07-03 23:42:50 --> Form Validation Class Initialized
DEBUG - 2019-07-03 23:42:50 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-03 23:42:50 --> Model Class Initialized
INFO - 2019-07-03 23:42:50 --> Model Class Initialized
INFO - 2019-07-03 23:42:50 --> Final output sent to browser
DEBUG - 2019-07-03 23:42:50 --> Total execution time: 0.5364
INFO - 2019-07-03 17:42:52 --> Config Class Initialized
INFO - 2019-07-03 17:42:52 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:42:52 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:42:52 --> Utf8 Class Initialized
INFO - 2019-07-03 17:42:52 --> URI Class Initialized
INFO - 2019-07-03 17:42:52 --> Router Class Initialized
INFO - 2019-07-03 17:42:52 --> Output Class Initialized
INFO - 2019-07-03 17:42:52 --> Security Class Initialized
DEBUG - 2019-07-03 17:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:42:52 --> Input Class Initialized
INFO - 2019-07-03 17:42:52 --> Language Class Initialized
INFO - 2019-07-03 17:42:52 --> Language Class Initialized
INFO - 2019-07-03 17:42:52 --> Config Class Initialized
INFO - 2019-07-03 17:42:52 --> Loader Class Initialized
DEBUG - 2019-07-03 17:42:52 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:42:52 --> Helper loaded: url_helper
INFO - 2019-07-03 17:42:52 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:42:52 --> Helper loaded: string_helper
INFO - 2019-07-03 17:42:52 --> Helper loaded: array_helper
INFO - 2019-07-03 17:42:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:42:52 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:42:52 --> Database Driver Class Initialized
INFO - 2019-07-03 17:42:52 --> Controller Class Initialized
INFO - 2019-07-03 23:42:52 --> Helper loaded: language_helper
INFO - 2019-07-03 23:42:53 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:42:53 --> Model Class Initialized
INFO - 2019-07-03 23:42:53 --> Model Class Initialized
INFO - 2019-07-03 23:42:53 --> Model Class Initialized
INFO - 2019-07-03 23:42:53 --> Model Class Initialized
INFO - 2019-07-03 23:42:53 --> Model Class Initialized
INFO - 2019-07-03 23:42:53 --> Final output sent to browser
DEBUG - 2019-07-03 23:42:53 --> Total execution time: 0.4613
INFO - 2019-07-03 17:42:53 --> Config Class Initialized
INFO - 2019-07-03 17:42:53 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:42:53 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:42:53 --> Utf8 Class Initialized
INFO - 2019-07-03 17:42:53 --> URI Class Initialized
INFO - 2019-07-03 17:42:53 --> Router Class Initialized
INFO - 2019-07-03 17:42:53 --> Output Class Initialized
INFO - 2019-07-03 17:42:53 --> Security Class Initialized
DEBUG - 2019-07-03 17:42:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:42:53 --> Input Class Initialized
INFO - 2019-07-03 17:42:53 --> Language Class Initialized
INFO - 2019-07-03 17:42:53 --> Language Class Initialized
INFO - 2019-07-03 17:42:53 --> Config Class Initialized
INFO - 2019-07-03 17:42:53 --> Loader Class Initialized
DEBUG - 2019-07-03 17:42:53 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:42:53 --> Helper loaded: url_helper
INFO - 2019-07-03 17:42:53 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:42:53 --> Helper loaded: string_helper
INFO - 2019-07-03 17:42:53 --> Helper loaded: array_helper
INFO - 2019-07-03 17:42:53 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:42:53 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:42:53 --> Database Driver Class Initialized
INFO - 2019-07-03 17:42:53 --> Controller Class Initialized
INFO - 2019-07-03 23:42:53 --> Helper loaded: language_helper
INFO - 2019-07-03 23:42:53 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:42:53 --> Model Class Initialized
INFO - 2019-07-03 23:42:53 --> Model Class Initialized
INFO - 2019-07-03 23:42:53 --> Model Class Initialized
INFO - 2019-07-03 23:42:53 --> Model Class Initialized
INFO - 2019-07-03 23:42:53 --> Helper loaded: form_helper
INFO - 2019-07-03 23:42:53 --> Form Validation Class Initialized
DEBUG - 2019-07-03 23:42:53 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-03 23:42:53 --> Model Class Initialized
INFO - 2019-07-03 23:42:53 --> Model Class Initialized
INFO - 2019-07-03 23:42:53 --> Final output sent to browser
DEBUG - 2019-07-03 23:42:53 --> Total execution time: 0.5805
INFO - 2019-07-03 17:42:54 --> Config Class Initialized
INFO - 2019-07-03 17:42:54 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:42:54 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:42:54 --> Utf8 Class Initialized
INFO - 2019-07-03 17:42:54 --> URI Class Initialized
INFO - 2019-07-03 17:42:54 --> Router Class Initialized
INFO - 2019-07-03 17:42:54 --> Output Class Initialized
INFO - 2019-07-03 17:42:54 --> Security Class Initialized
DEBUG - 2019-07-03 17:42:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:42:54 --> Input Class Initialized
INFO - 2019-07-03 17:42:55 --> Language Class Initialized
INFO - 2019-07-03 17:42:55 --> Language Class Initialized
INFO - 2019-07-03 17:42:55 --> Config Class Initialized
INFO - 2019-07-03 17:42:55 --> Loader Class Initialized
DEBUG - 2019-07-03 17:42:55 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:42:55 --> Helper loaded: url_helper
INFO - 2019-07-03 17:42:55 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:42:55 --> Helper loaded: string_helper
INFO - 2019-07-03 17:42:55 --> Helper loaded: array_helper
INFO - 2019-07-03 17:42:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:42:55 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:42:55 --> Database Driver Class Initialized
INFO - 2019-07-03 17:42:55 --> Controller Class Initialized
INFO - 2019-07-03 23:42:55 --> Helper loaded: language_helper
INFO - 2019-07-03 23:42:55 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:42:55 --> Model Class Initialized
INFO - 2019-07-03 23:42:55 --> Model Class Initialized
INFO - 2019-07-03 23:42:55 --> Model Class Initialized
INFO - 2019-07-03 23:42:55 --> Model Class Initialized
INFO - 2019-07-03 23:42:55 --> Helper loaded: form_helper
INFO - 2019-07-03 23:42:55 --> Form Validation Class Initialized
DEBUG - 2019-07-03 23:42:55 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-03 23:42:55 --> Model Class Initialized
INFO - 2019-07-03 23:42:55 --> Model Class Initialized
INFO - 2019-07-03 23:42:55 --> Final output sent to browser
DEBUG - 2019-07-03 23:42:55 --> Total execution time: 0.5492
INFO - 2019-07-03 17:43:25 --> Config Class Initialized
INFO - 2019-07-03 17:43:25 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:43:25 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:43:25 --> Utf8 Class Initialized
INFO - 2019-07-03 17:43:25 --> URI Class Initialized
INFO - 2019-07-03 17:43:25 --> Router Class Initialized
INFO - 2019-07-03 17:43:25 --> Output Class Initialized
INFO - 2019-07-03 17:43:25 --> Security Class Initialized
DEBUG - 2019-07-03 17:43:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:43:25 --> Input Class Initialized
INFO - 2019-07-03 17:43:25 --> Language Class Initialized
INFO - 2019-07-03 17:43:25 --> Language Class Initialized
INFO - 2019-07-03 17:43:26 --> Config Class Initialized
INFO - 2019-07-03 17:43:26 --> Loader Class Initialized
DEBUG - 2019-07-03 17:43:26 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:43:26 --> Helper loaded: url_helper
INFO - 2019-07-03 17:43:26 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:43:26 --> Helper loaded: string_helper
INFO - 2019-07-03 17:43:26 --> Helper loaded: array_helper
INFO - 2019-07-03 17:43:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:43:26 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:43:26 --> Database Driver Class Initialized
INFO - 2019-07-03 17:43:26 --> Controller Class Initialized
INFO - 2019-07-03 23:43:26 --> Helper loaded: language_helper
INFO - 2019-07-03 23:43:26 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:43:26 --> Model Class Initialized
INFO - 2019-07-03 23:43:26 --> Model Class Initialized
INFO - 2019-07-03 23:43:26 --> Model Class Initialized
INFO - 2019-07-03 23:43:26 --> Model Class Initialized
INFO - 2019-07-03 23:43:26 --> Model Class Initialized
INFO - 2019-07-03 23:43:26 --> Final output sent to browser
DEBUG - 2019-07-03 23:43:26 --> Total execution time: 0.4776
INFO - 2019-07-03 17:43:26 --> Config Class Initialized
INFO - 2019-07-03 17:43:26 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:43:26 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:43:26 --> Utf8 Class Initialized
INFO - 2019-07-03 17:43:26 --> URI Class Initialized
INFO - 2019-07-03 17:43:26 --> Router Class Initialized
INFO - 2019-07-03 17:43:26 --> Output Class Initialized
INFO - 2019-07-03 17:43:26 --> Security Class Initialized
DEBUG - 2019-07-03 17:43:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:43:26 --> Input Class Initialized
INFO - 2019-07-03 17:43:26 --> Language Class Initialized
INFO - 2019-07-03 17:43:26 --> Language Class Initialized
INFO - 2019-07-03 17:43:26 --> Config Class Initialized
INFO - 2019-07-03 17:43:26 --> Loader Class Initialized
DEBUG - 2019-07-03 17:43:26 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:43:26 --> Helper loaded: url_helper
INFO - 2019-07-03 17:43:26 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:43:26 --> Helper loaded: string_helper
INFO - 2019-07-03 17:43:26 --> Helper loaded: array_helper
INFO - 2019-07-03 17:43:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:43:26 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:43:26 --> Database Driver Class Initialized
INFO - 2019-07-03 17:43:26 --> Controller Class Initialized
INFO - 2019-07-03 23:43:26 --> Helper loaded: language_helper
INFO - 2019-07-03 23:43:26 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:43:26 --> Model Class Initialized
INFO - 2019-07-03 23:43:26 --> Model Class Initialized
INFO - 2019-07-03 23:43:26 --> Model Class Initialized
INFO - 2019-07-03 23:43:26 --> Model Class Initialized
INFO - 2019-07-03 23:43:26 --> Helper loaded: form_helper
INFO - 2019-07-03 23:43:26 --> Form Validation Class Initialized
DEBUG - 2019-07-03 23:43:26 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-03 23:43:26 --> Model Class Initialized
INFO - 2019-07-03 23:43:26 --> Model Class Initialized
INFO - 2019-07-03 23:43:26 --> Final output sent to browser
DEBUG - 2019-07-03 23:43:26 --> Total execution time: 0.5365
INFO - 2019-07-03 17:43:40 --> Config Class Initialized
INFO - 2019-07-03 17:43:40 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:43:40 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:43:40 --> Utf8 Class Initialized
INFO - 2019-07-03 17:43:40 --> URI Class Initialized
INFO - 2019-07-03 17:43:40 --> Router Class Initialized
INFO - 2019-07-03 17:43:40 --> Output Class Initialized
INFO - 2019-07-03 17:43:40 --> Security Class Initialized
DEBUG - 2019-07-03 17:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:43:40 --> Input Class Initialized
INFO - 2019-07-03 17:43:40 --> Language Class Initialized
INFO - 2019-07-03 17:43:40 --> Language Class Initialized
INFO - 2019-07-03 17:43:40 --> Config Class Initialized
INFO - 2019-07-03 17:43:40 --> Loader Class Initialized
DEBUG - 2019-07-03 17:43:40 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:43:40 --> Helper loaded: url_helper
INFO - 2019-07-03 17:43:40 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:43:40 --> Helper loaded: string_helper
INFO - 2019-07-03 17:43:40 --> Helper loaded: array_helper
INFO - 2019-07-03 17:43:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:43:40 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:43:40 --> Database Driver Class Initialized
INFO - 2019-07-03 17:43:40 --> Controller Class Initialized
INFO - 2019-07-03 23:43:40 --> Helper loaded: language_helper
INFO - 2019-07-03 23:43:40 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:43:40 --> Model Class Initialized
INFO - 2019-07-03 23:43:40 --> Model Class Initialized
INFO - 2019-07-03 23:43:40 --> Model Class Initialized
INFO - 2019-07-03 23:43:40 --> Model Class Initialized
INFO - 2019-07-03 23:43:40 --> Model Class Initialized
INFO - 2019-07-03 23:43:40 --> Final output sent to browser
DEBUG - 2019-07-03 23:43:40 --> Total execution time: 0.5017
INFO - 2019-07-03 17:43:40 --> Config Class Initialized
INFO - 2019-07-03 17:43:40 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:43:40 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:43:40 --> Utf8 Class Initialized
INFO - 2019-07-03 17:43:40 --> URI Class Initialized
INFO - 2019-07-03 17:43:40 --> Router Class Initialized
INFO - 2019-07-03 17:43:40 --> Output Class Initialized
INFO - 2019-07-03 17:43:40 --> Security Class Initialized
DEBUG - 2019-07-03 17:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:43:40 --> Input Class Initialized
INFO - 2019-07-03 17:43:40 --> Language Class Initialized
INFO - 2019-07-03 17:43:40 --> Language Class Initialized
INFO - 2019-07-03 17:43:40 --> Config Class Initialized
INFO - 2019-07-03 17:43:40 --> Loader Class Initialized
DEBUG - 2019-07-03 17:43:40 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:43:40 --> Helper loaded: url_helper
INFO - 2019-07-03 17:43:40 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:43:40 --> Helper loaded: string_helper
INFO - 2019-07-03 17:43:40 --> Helper loaded: array_helper
INFO - 2019-07-03 17:43:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:43:40 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:43:41 --> Database Driver Class Initialized
INFO - 2019-07-03 17:43:41 --> Controller Class Initialized
INFO - 2019-07-03 23:43:41 --> Helper loaded: language_helper
INFO - 2019-07-03 23:43:41 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:43:41 --> Model Class Initialized
INFO - 2019-07-03 23:43:41 --> Model Class Initialized
INFO - 2019-07-03 23:43:41 --> Model Class Initialized
INFO - 2019-07-03 23:43:41 --> Model Class Initialized
INFO - 2019-07-03 23:43:41 --> Helper loaded: form_helper
INFO - 2019-07-03 23:43:41 --> Form Validation Class Initialized
DEBUG - 2019-07-03 23:43:41 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-03 23:43:41 --> Model Class Initialized
INFO - 2019-07-03 23:43:41 --> Model Class Initialized
INFO - 2019-07-03 23:43:41 --> Final output sent to browser
DEBUG - 2019-07-03 23:43:41 --> Total execution time: 0.5742
INFO - 2019-07-03 17:43:41 --> Config Class Initialized
INFO - 2019-07-03 17:43:41 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:43:41 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:43:41 --> Utf8 Class Initialized
INFO - 2019-07-03 17:43:41 --> URI Class Initialized
INFO - 2019-07-03 17:43:41 --> Router Class Initialized
INFO - 2019-07-03 17:43:41 --> Output Class Initialized
INFO - 2019-07-03 17:43:42 --> Security Class Initialized
DEBUG - 2019-07-03 17:43:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:43:42 --> Input Class Initialized
INFO - 2019-07-03 17:43:42 --> Language Class Initialized
INFO - 2019-07-03 17:43:42 --> Language Class Initialized
INFO - 2019-07-03 17:43:42 --> Config Class Initialized
INFO - 2019-07-03 17:43:42 --> Loader Class Initialized
DEBUG - 2019-07-03 17:43:42 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:43:42 --> Helper loaded: url_helper
INFO - 2019-07-03 17:43:42 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:43:42 --> Helper loaded: string_helper
INFO - 2019-07-03 17:43:42 --> Helper loaded: array_helper
INFO - 2019-07-03 17:43:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:43:42 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:43:42 --> Database Driver Class Initialized
INFO - 2019-07-03 17:43:42 --> Controller Class Initialized
INFO - 2019-07-03 23:43:42 --> Helper loaded: language_helper
INFO - 2019-07-03 23:43:42 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:43:42 --> Model Class Initialized
INFO - 2019-07-03 23:43:42 --> Model Class Initialized
INFO - 2019-07-03 23:43:42 --> Model Class Initialized
INFO - 2019-07-03 23:43:42 --> Model Class Initialized
INFO - 2019-07-03 23:43:42 --> Helper loaded: form_helper
INFO - 2019-07-03 23:43:42 --> Form Validation Class Initialized
DEBUG - 2019-07-03 23:43:42 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-03 23:43:42 --> Model Class Initialized
INFO - 2019-07-03 23:43:42 --> Model Class Initialized
INFO - 2019-07-03 23:43:42 --> Final output sent to browser
DEBUG - 2019-07-03 23:43:42 --> Total execution time: 0.5512
INFO - 2019-07-03 17:43:43 --> Config Class Initialized
INFO - 2019-07-03 17:43:43 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:43:43 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:43:43 --> Utf8 Class Initialized
INFO - 2019-07-03 17:43:43 --> URI Class Initialized
INFO - 2019-07-03 17:43:43 --> Router Class Initialized
INFO - 2019-07-03 17:43:43 --> Output Class Initialized
INFO - 2019-07-03 17:43:43 --> Security Class Initialized
DEBUG - 2019-07-03 17:43:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:43:43 --> Input Class Initialized
INFO - 2019-07-03 17:43:43 --> Language Class Initialized
INFO - 2019-07-03 17:43:43 --> Language Class Initialized
INFO - 2019-07-03 17:43:43 --> Config Class Initialized
INFO - 2019-07-03 17:43:43 --> Loader Class Initialized
DEBUG - 2019-07-03 17:43:43 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:43:43 --> Helper loaded: url_helper
INFO - 2019-07-03 17:43:43 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:43:43 --> Helper loaded: string_helper
INFO - 2019-07-03 17:43:43 --> Helper loaded: array_helper
INFO - 2019-07-03 17:43:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:43:43 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:43:43 --> Database Driver Class Initialized
INFO - 2019-07-03 17:43:43 --> Controller Class Initialized
INFO - 2019-07-03 23:43:43 --> Helper loaded: language_helper
INFO - 2019-07-03 23:43:43 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:43:43 --> Model Class Initialized
INFO - 2019-07-03 23:43:43 --> Model Class Initialized
INFO - 2019-07-03 23:43:43 --> Model Class Initialized
INFO - 2019-07-03 23:43:43 --> Model Class Initialized
INFO - 2019-07-03 23:43:43 --> Model Class Initialized
INFO - 2019-07-03 23:43:43 --> Final output sent to browser
DEBUG - 2019-07-03 23:43:43 --> Total execution time: 0.4801
INFO - 2019-07-03 17:43:43 --> Config Class Initialized
INFO - 2019-07-03 17:43:43 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:43:43 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:43:43 --> Utf8 Class Initialized
INFO - 2019-07-03 17:43:43 --> URI Class Initialized
INFO - 2019-07-03 17:43:43 --> Router Class Initialized
INFO - 2019-07-03 17:43:43 --> Output Class Initialized
INFO - 2019-07-03 17:43:43 --> Security Class Initialized
DEBUG - 2019-07-03 17:43:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:43:43 --> Input Class Initialized
INFO - 2019-07-03 17:43:43 --> Language Class Initialized
INFO - 2019-07-03 17:43:43 --> Language Class Initialized
INFO - 2019-07-03 17:43:43 --> Config Class Initialized
INFO - 2019-07-03 17:43:43 --> Loader Class Initialized
DEBUG - 2019-07-03 17:43:43 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:43:43 --> Helper loaded: url_helper
INFO - 2019-07-03 17:43:43 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:43:44 --> Helper loaded: string_helper
INFO - 2019-07-03 17:43:44 --> Helper loaded: array_helper
INFO - 2019-07-03 17:43:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:43:44 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:43:44 --> Database Driver Class Initialized
INFO - 2019-07-03 17:43:44 --> Controller Class Initialized
INFO - 2019-07-03 23:43:44 --> Helper loaded: language_helper
INFO - 2019-07-03 23:43:44 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:43:44 --> Model Class Initialized
INFO - 2019-07-03 23:43:44 --> Model Class Initialized
INFO - 2019-07-03 23:43:44 --> Model Class Initialized
INFO - 2019-07-03 23:43:44 --> Model Class Initialized
INFO - 2019-07-03 23:43:44 --> Helper loaded: form_helper
INFO - 2019-07-03 23:43:44 --> Form Validation Class Initialized
DEBUG - 2019-07-03 23:43:44 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-03 23:43:44 --> Model Class Initialized
INFO - 2019-07-03 23:43:44 --> Model Class Initialized
INFO - 2019-07-03 23:43:44 --> Final output sent to browser
DEBUG - 2019-07-03 23:43:44 --> Total execution time: 0.5611
INFO - 2019-07-03 17:43:45 --> Config Class Initialized
INFO - 2019-07-03 17:43:45 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:43:45 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:43:45 --> Utf8 Class Initialized
INFO - 2019-07-03 17:43:45 --> URI Class Initialized
INFO - 2019-07-03 17:43:45 --> Router Class Initialized
INFO - 2019-07-03 17:43:45 --> Output Class Initialized
INFO - 2019-07-03 17:43:45 --> Security Class Initialized
DEBUG - 2019-07-03 17:43:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:43:45 --> Input Class Initialized
INFO - 2019-07-03 17:43:45 --> Language Class Initialized
INFO - 2019-07-03 17:43:45 --> Language Class Initialized
INFO - 2019-07-03 17:43:45 --> Config Class Initialized
INFO - 2019-07-03 17:43:45 --> Loader Class Initialized
DEBUG - 2019-07-03 17:43:45 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:43:45 --> Helper loaded: url_helper
INFO - 2019-07-03 17:43:45 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:43:45 --> Helper loaded: string_helper
INFO - 2019-07-03 17:43:45 --> Helper loaded: array_helper
INFO - 2019-07-03 17:43:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:43:45 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:43:45 --> Database Driver Class Initialized
INFO - 2019-07-03 17:43:45 --> Controller Class Initialized
INFO - 2019-07-03 23:43:45 --> Helper loaded: language_helper
INFO - 2019-07-03 23:43:45 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:43:45 --> Model Class Initialized
INFO - 2019-07-03 23:43:45 --> Model Class Initialized
INFO - 2019-07-03 23:43:45 --> Model Class Initialized
INFO - 2019-07-03 23:43:45 --> Model Class Initialized
INFO - 2019-07-03 23:43:45 --> Helper loaded: form_helper
INFO - 2019-07-03 23:43:45 --> Form Validation Class Initialized
DEBUG - 2019-07-03 23:43:45 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-03 23:43:45 --> Model Class Initialized
INFO - 2019-07-03 23:43:45 --> Model Class Initialized
INFO - 2019-07-03 23:43:45 --> Final output sent to browser
DEBUG - 2019-07-03 23:43:45 --> Total execution time: 0.5482
INFO - 2019-07-03 17:45:31 --> Config Class Initialized
INFO - 2019-07-03 17:45:31 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:45:31 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:45:31 --> Utf8 Class Initialized
INFO - 2019-07-03 17:45:31 --> URI Class Initialized
INFO - 2019-07-03 17:45:31 --> Router Class Initialized
INFO - 2019-07-03 17:45:31 --> Output Class Initialized
INFO - 2019-07-03 17:45:31 --> Security Class Initialized
DEBUG - 2019-07-03 17:45:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:45:31 --> Input Class Initialized
INFO - 2019-07-03 17:45:31 --> Language Class Initialized
INFO - 2019-07-03 17:45:31 --> Language Class Initialized
INFO - 2019-07-03 17:45:31 --> Config Class Initialized
INFO - 2019-07-03 17:45:31 --> Loader Class Initialized
DEBUG - 2019-07-03 17:45:31 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:45:31 --> Helper loaded: url_helper
INFO - 2019-07-03 17:45:31 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:45:31 --> Helper loaded: string_helper
INFO - 2019-07-03 17:45:31 --> Helper loaded: array_helper
INFO - 2019-07-03 17:45:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:45:31 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:45:31 --> Database Driver Class Initialized
INFO - 2019-07-03 17:45:31 --> Controller Class Initialized
INFO - 2019-07-03 23:45:31 --> Helper loaded: language_helper
INFO - 2019-07-03 23:45:31 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:45:31 --> Model Class Initialized
INFO - 2019-07-03 23:45:31 --> Model Class Initialized
INFO - 2019-07-03 23:45:31 --> Model Class Initialized
INFO - 2019-07-03 23:45:31 --> Model Class Initialized
INFO - 2019-07-03 23:45:31 --> Model Class Initialized
INFO - 2019-07-03 23:45:31 --> Final output sent to browser
INFO - 2019-07-03 17:45:31 --> Config Class Initialized
DEBUG - 2019-07-03 23:45:31 --> Total execution time: 0.5872
INFO - 2019-07-03 17:45:31 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:45:31 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:45:32 --> Utf8 Class Initialized
INFO - 2019-07-03 17:45:32 --> URI Class Initialized
INFO - 2019-07-03 17:45:32 --> Router Class Initialized
INFO - 2019-07-03 17:45:32 --> Output Class Initialized
INFO - 2019-07-03 17:45:32 --> Security Class Initialized
DEBUG - 2019-07-03 17:45:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:45:32 --> Input Class Initialized
INFO - 2019-07-03 17:45:32 --> Language Class Initialized
INFO - 2019-07-03 17:45:32 --> Language Class Initialized
INFO - 2019-07-03 17:45:32 --> Config Class Initialized
INFO - 2019-07-03 17:45:32 --> Loader Class Initialized
DEBUG - 2019-07-03 17:45:32 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:45:32 --> Helper loaded: url_helper
INFO - 2019-07-03 17:45:32 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:45:32 --> Helper loaded: string_helper
INFO - 2019-07-03 17:45:32 --> Helper loaded: array_helper
INFO - 2019-07-03 17:45:32 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:45:32 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:45:32 --> Database Driver Class Initialized
INFO - 2019-07-03 17:45:32 --> Controller Class Initialized
INFO - 2019-07-03 23:45:32 --> Helper loaded: language_helper
INFO - 2019-07-03 23:45:32 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:45:32 --> Model Class Initialized
INFO - 2019-07-03 23:45:32 --> Model Class Initialized
INFO - 2019-07-03 23:45:32 --> Model Class Initialized
INFO - 2019-07-03 23:45:32 --> Model Class Initialized
INFO - 2019-07-03 23:45:32 --> Model Class Initialized
INFO - 2019-07-03 23:45:32 --> Final output sent to browser
DEBUG - 2019-07-03 23:45:32 --> Total execution time: 0.4798
INFO - 2019-07-03 17:45:32 --> Config Class Initialized
INFO - 2019-07-03 17:45:32 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:45:32 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:45:32 --> Utf8 Class Initialized
INFO - 2019-07-03 17:45:32 --> URI Class Initialized
INFO - 2019-07-03 17:45:32 --> Router Class Initialized
INFO - 2019-07-03 17:45:32 --> Output Class Initialized
INFO - 2019-07-03 17:45:32 --> Security Class Initialized
DEBUG - 2019-07-03 17:45:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:45:32 --> Input Class Initialized
INFO - 2019-07-03 17:45:32 --> Language Class Initialized
INFO - 2019-07-03 17:45:32 --> Language Class Initialized
INFO - 2019-07-03 17:45:32 --> Config Class Initialized
INFO - 2019-07-03 17:45:32 --> Loader Class Initialized
DEBUG - 2019-07-03 17:45:32 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:45:32 --> Helper loaded: url_helper
INFO - 2019-07-03 17:45:32 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:45:32 --> Helper loaded: string_helper
INFO - 2019-07-03 17:45:32 --> Helper loaded: array_helper
INFO - 2019-07-03 17:45:32 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:45:32 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:45:32 --> Database Driver Class Initialized
INFO - 2019-07-03 17:45:32 --> Controller Class Initialized
INFO - 2019-07-03 23:45:32 --> Helper loaded: language_helper
INFO - 2019-07-03 23:45:32 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:45:32 --> Model Class Initialized
INFO - 2019-07-03 23:45:32 --> Model Class Initialized
INFO - 2019-07-03 23:45:32 --> Model Class Initialized
INFO - 2019-07-03 23:45:32 --> Model Class Initialized
INFO - 2019-07-03 23:45:32 --> Helper loaded: form_helper
INFO - 2019-07-03 23:45:32 --> Form Validation Class Initialized
DEBUG - 2019-07-03 23:45:33 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-03 23:45:33 --> Model Class Initialized
INFO - 2019-07-03 23:45:33 --> Model Class Initialized
INFO - 2019-07-03 23:45:33 --> Final output sent to browser
DEBUG - 2019-07-03 23:45:33 --> Total execution time: 0.5734
INFO - 2019-07-03 17:45:33 --> Config Class Initialized
INFO - 2019-07-03 17:45:33 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:45:33 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:45:33 --> Utf8 Class Initialized
INFO - 2019-07-03 17:45:33 --> URI Class Initialized
INFO - 2019-07-03 17:45:33 --> Router Class Initialized
INFO - 2019-07-03 17:45:33 --> Output Class Initialized
INFO - 2019-07-03 17:45:33 --> Security Class Initialized
DEBUG - 2019-07-03 17:45:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:45:33 --> Input Class Initialized
INFO - 2019-07-03 17:45:33 --> Language Class Initialized
INFO - 2019-07-03 17:45:33 --> Language Class Initialized
INFO - 2019-07-03 17:45:34 --> Config Class Initialized
INFO - 2019-07-03 17:45:34 --> Loader Class Initialized
DEBUG - 2019-07-03 17:45:34 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:45:34 --> Helper loaded: url_helper
INFO - 2019-07-03 17:45:34 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:45:34 --> Helper loaded: string_helper
INFO - 2019-07-03 17:45:34 --> Helper loaded: array_helper
INFO - 2019-07-03 17:45:34 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:45:34 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:45:34 --> Database Driver Class Initialized
INFO - 2019-07-03 17:45:34 --> Controller Class Initialized
INFO - 2019-07-03 23:45:34 --> Helper loaded: language_helper
INFO - 2019-07-03 23:45:34 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:45:34 --> Model Class Initialized
INFO - 2019-07-03 23:45:34 --> Model Class Initialized
INFO - 2019-07-03 23:45:34 --> Model Class Initialized
INFO - 2019-07-03 23:45:34 --> Model Class Initialized
INFO - 2019-07-03 23:45:34 --> Helper loaded: form_helper
INFO - 2019-07-03 23:45:34 --> Form Validation Class Initialized
DEBUG - 2019-07-03 23:45:34 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-03 23:45:34 --> Model Class Initialized
INFO - 2019-07-03 23:45:34 --> Model Class Initialized
INFO - 2019-07-03 23:45:34 --> Final output sent to browser
DEBUG - 2019-07-03 23:45:34 --> Total execution time: 0.5836
INFO - 2019-07-03 17:46:12 --> Config Class Initialized
INFO - 2019-07-03 17:46:12 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:46:12 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:46:12 --> Utf8 Class Initialized
INFO - 2019-07-03 17:46:12 --> URI Class Initialized
INFO - 2019-07-03 17:46:12 --> Router Class Initialized
INFO - 2019-07-03 17:46:12 --> Output Class Initialized
INFO - 2019-07-03 17:46:12 --> Security Class Initialized
DEBUG - 2019-07-03 17:46:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:46:12 --> Input Class Initialized
INFO - 2019-07-03 17:46:12 --> Language Class Initialized
INFO - 2019-07-03 17:46:13 --> Language Class Initialized
INFO - 2019-07-03 17:46:13 --> Config Class Initialized
INFO - 2019-07-03 17:46:13 --> Loader Class Initialized
DEBUG - 2019-07-03 17:46:13 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:46:13 --> Helper loaded: url_helper
INFO - 2019-07-03 17:46:13 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:46:13 --> Helper loaded: string_helper
INFO - 2019-07-03 17:46:13 --> Helper loaded: array_helper
INFO - 2019-07-03 17:46:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:46:13 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:46:13 --> Database Driver Class Initialized
INFO - 2019-07-03 17:46:13 --> Controller Class Initialized
INFO - 2019-07-03 23:46:13 --> Helper loaded: language_helper
INFO - 2019-07-03 23:46:13 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:46:13 --> Model Class Initialized
INFO - 2019-07-03 23:46:13 --> Model Class Initialized
INFO - 2019-07-03 23:46:13 --> Model Class Initialized
INFO - 2019-07-03 23:46:13 --> Model Class Initialized
INFO - 2019-07-03 23:46:13 --> Helper loaded: form_helper
INFO - 2019-07-03 23:46:13 --> Form Validation Class Initialized
DEBUG - 2019-07-03 23:46:13 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-03 23:46:13 --> Model Class Initialized
INFO - 2019-07-03 23:46:13 --> Model Class Initialized
INFO - 2019-07-03 23:46:13 --> Final output sent to browser
DEBUG - 2019-07-03 23:46:13 --> Total execution time: 0.5683
INFO - 2019-07-03 17:46:21 --> Config Class Initialized
INFO - 2019-07-03 17:46:21 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:46:21 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:46:21 --> Utf8 Class Initialized
INFO - 2019-07-03 17:46:21 --> URI Class Initialized
INFO - 2019-07-03 17:46:21 --> Router Class Initialized
INFO - 2019-07-03 17:46:21 --> Output Class Initialized
INFO - 2019-07-03 17:46:21 --> Security Class Initialized
DEBUG - 2019-07-03 17:46:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:46:21 --> Input Class Initialized
INFO - 2019-07-03 17:46:21 --> Language Class Initialized
INFO - 2019-07-03 17:46:21 --> Language Class Initialized
INFO - 2019-07-03 17:46:21 --> Config Class Initialized
INFO - 2019-07-03 17:46:21 --> Loader Class Initialized
DEBUG - 2019-07-03 17:46:22 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:46:22 --> Helper loaded: url_helper
INFO - 2019-07-03 17:46:22 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:46:22 --> Helper loaded: string_helper
INFO - 2019-07-03 17:46:22 --> Helper loaded: array_helper
INFO - 2019-07-03 17:46:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:46:22 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:46:22 --> Database Driver Class Initialized
INFO - 2019-07-03 17:46:22 --> Controller Class Initialized
INFO - 2019-07-03 23:46:22 --> Helper loaded: language_helper
INFO - 2019-07-03 23:46:22 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:46:22 --> Model Class Initialized
INFO - 2019-07-03 23:46:22 --> Model Class Initialized
INFO - 2019-07-03 23:46:22 --> Model Class Initialized
INFO - 2019-07-03 23:46:22 --> Model Class Initialized
INFO - 2019-07-03 23:46:22 --> Helper loaded: form_helper
INFO - 2019-07-03 23:46:22 --> Form Validation Class Initialized
DEBUG - 2019-07-03 23:46:22 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-03 23:46:22 --> Model Class Initialized
INFO - 2019-07-03 23:46:22 --> Model Class Initialized
INFO - 2019-07-03 23:46:22 --> Final output sent to browser
DEBUG - 2019-07-03 23:46:22 --> Total execution time: 0.5614
INFO - 2019-07-03 17:47:04 --> Config Class Initialized
INFO - 2019-07-03 17:47:05 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:47:05 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:47:05 --> Utf8 Class Initialized
INFO - 2019-07-03 17:47:05 --> URI Class Initialized
INFO - 2019-07-03 17:47:05 --> Router Class Initialized
INFO - 2019-07-03 17:47:05 --> Output Class Initialized
INFO - 2019-07-03 17:47:05 --> Security Class Initialized
DEBUG - 2019-07-03 17:47:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:47:05 --> Input Class Initialized
INFO - 2019-07-03 17:47:05 --> Language Class Initialized
INFO - 2019-07-03 17:47:05 --> Language Class Initialized
INFO - 2019-07-03 17:47:05 --> Config Class Initialized
INFO - 2019-07-03 17:47:05 --> Loader Class Initialized
DEBUG - 2019-07-03 17:47:05 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:47:05 --> Helper loaded: url_helper
INFO - 2019-07-03 17:47:05 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:47:05 --> Helper loaded: string_helper
INFO - 2019-07-03 17:47:05 --> Helper loaded: array_helper
INFO - 2019-07-03 17:47:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:47:05 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:47:05 --> Database Driver Class Initialized
INFO - 2019-07-03 17:47:05 --> Controller Class Initialized
INFO - 2019-07-03 23:47:05 --> Helper loaded: language_helper
INFO - 2019-07-03 23:47:05 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:47:05 --> Model Class Initialized
INFO - 2019-07-03 23:47:05 --> Model Class Initialized
INFO - 2019-07-03 23:47:05 --> Model Class Initialized
INFO - 2019-07-03 23:47:05 --> Model Class Initialized
INFO - 2019-07-03 23:47:05 --> Helper loaded: form_helper
INFO - 2019-07-03 23:47:05 --> Form Validation Class Initialized
DEBUG - 2019-07-03 23:47:05 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-03 23:47:05 --> Model Class Initialized
INFO - 2019-07-03 23:47:05 --> Model Class Initialized
INFO - 2019-07-03 23:47:05 --> Final output sent to browser
DEBUG - 2019-07-03 23:47:05 --> Total execution time: 0.5699
INFO - 2019-07-03 17:47:10 --> Config Class Initialized
INFO - 2019-07-03 17:47:10 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:47:11 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:47:11 --> Utf8 Class Initialized
INFO - 2019-07-03 17:47:11 --> URI Class Initialized
INFO - 2019-07-03 17:47:11 --> Router Class Initialized
INFO - 2019-07-03 17:47:11 --> Output Class Initialized
INFO - 2019-07-03 17:47:11 --> Security Class Initialized
DEBUG - 2019-07-03 17:47:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:47:11 --> Input Class Initialized
INFO - 2019-07-03 17:47:11 --> Language Class Initialized
INFO - 2019-07-03 17:47:11 --> Language Class Initialized
INFO - 2019-07-03 17:47:11 --> Config Class Initialized
INFO - 2019-07-03 17:47:11 --> Loader Class Initialized
DEBUG - 2019-07-03 17:47:11 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:47:11 --> Helper loaded: url_helper
INFO - 2019-07-03 17:47:11 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:47:11 --> Helper loaded: string_helper
INFO - 2019-07-03 17:47:11 --> Helper loaded: array_helper
INFO - 2019-07-03 17:47:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:47:11 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:47:11 --> Database Driver Class Initialized
INFO - 2019-07-03 17:47:11 --> Controller Class Initialized
INFO - 2019-07-03 23:47:11 --> Helper loaded: language_helper
INFO - 2019-07-03 23:47:11 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:47:11 --> Model Class Initialized
INFO - 2019-07-03 23:47:11 --> Model Class Initialized
INFO - 2019-07-03 23:47:11 --> Model Class Initialized
INFO - 2019-07-03 23:47:11 --> Model Class Initialized
INFO - 2019-07-03 23:47:11 --> Helper loaded: form_helper
INFO - 2019-07-03 23:47:11 --> Form Validation Class Initialized
DEBUG - 2019-07-03 23:47:11 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-03 23:47:11 --> Model Class Initialized
INFO - 2019-07-03 23:47:11 --> Model Class Initialized
INFO - 2019-07-03 23:47:11 --> Final output sent to browser
DEBUG - 2019-07-03 23:47:11 --> Total execution time: 0.5511
INFO - 2019-07-03 17:49:02 --> Config Class Initialized
INFO - 2019-07-03 17:49:02 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:49:02 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:49:02 --> Utf8 Class Initialized
INFO - 2019-07-03 17:49:02 --> URI Class Initialized
INFO - 2019-07-03 17:49:02 --> Router Class Initialized
INFO - 2019-07-03 17:49:02 --> Output Class Initialized
INFO - 2019-07-03 17:49:02 --> Security Class Initialized
DEBUG - 2019-07-03 17:49:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:49:02 --> Input Class Initialized
INFO - 2019-07-03 17:49:02 --> Language Class Initialized
INFO - 2019-07-03 17:49:02 --> Language Class Initialized
INFO - 2019-07-03 17:49:02 --> Config Class Initialized
INFO - 2019-07-03 17:49:02 --> Loader Class Initialized
DEBUG - 2019-07-03 17:49:02 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:49:02 --> Helper loaded: url_helper
INFO - 2019-07-03 17:49:02 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:49:02 --> Helper loaded: string_helper
INFO - 2019-07-03 17:49:02 --> Helper loaded: array_helper
INFO - 2019-07-03 17:49:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:49:02 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:49:02 --> Database Driver Class Initialized
INFO - 2019-07-03 17:49:02 --> Controller Class Initialized
INFO - 2019-07-03 23:49:02 --> Helper loaded: language_helper
INFO - 2019-07-03 23:49:02 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:49:02 --> Model Class Initialized
INFO - 2019-07-03 23:49:02 --> Model Class Initialized
INFO - 2019-07-03 23:49:02 --> Model Class Initialized
INFO - 2019-07-03 23:49:02 --> Model Class Initialized
INFO - 2019-07-03 23:49:02 --> Model Class Initialized
INFO - 2019-07-03 23:49:02 --> Final output sent to browser
DEBUG - 2019-07-03 23:49:02 --> Total execution time: 0.4974
INFO - 2019-07-03 17:49:02 --> Config Class Initialized
INFO - 2019-07-03 17:49:02 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:49:02 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:49:02 --> Utf8 Class Initialized
INFO - 2019-07-03 17:49:02 --> URI Class Initialized
INFO - 2019-07-03 17:49:02 --> Router Class Initialized
INFO - 2019-07-03 17:49:02 --> Output Class Initialized
INFO - 2019-07-03 17:49:02 --> Security Class Initialized
DEBUG - 2019-07-03 17:49:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:49:02 --> Input Class Initialized
INFO - 2019-07-03 17:49:02 --> Language Class Initialized
INFO - 2019-07-03 17:49:02 --> Language Class Initialized
INFO - 2019-07-03 17:49:02 --> Config Class Initialized
INFO - 2019-07-03 17:49:02 --> Loader Class Initialized
DEBUG - 2019-07-03 17:49:02 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:49:02 --> Helper loaded: url_helper
INFO - 2019-07-03 17:49:02 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:49:02 --> Helper loaded: string_helper
INFO - 2019-07-03 17:49:02 --> Helper loaded: array_helper
INFO - 2019-07-03 17:49:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:49:02 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:49:03 --> Database Driver Class Initialized
INFO - 2019-07-03 17:49:03 --> Controller Class Initialized
INFO - 2019-07-03 23:49:03 --> Helper loaded: language_helper
INFO - 2019-07-03 23:49:03 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:49:03 --> Model Class Initialized
INFO - 2019-07-03 23:49:03 --> Model Class Initialized
INFO - 2019-07-03 23:49:03 --> Model Class Initialized
INFO - 2019-07-03 23:49:03 --> Model Class Initialized
INFO - 2019-07-03 23:49:03 --> Helper loaded: form_helper
INFO - 2019-07-03 23:49:03 --> Form Validation Class Initialized
DEBUG - 2019-07-03 23:49:03 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-03 23:49:03 --> Model Class Initialized
INFO - 2019-07-03 23:49:03 --> Model Class Initialized
INFO - 2019-07-03 23:49:03 --> Final output sent to browser
DEBUG - 2019-07-03 23:49:03 --> Total execution time: 0.5649
INFO - 2019-07-03 17:51:41 --> Config Class Initialized
INFO - 2019-07-03 17:51:41 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:51:41 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:51:41 --> Utf8 Class Initialized
INFO - 2019-07-03 17:51:41 --> URI Class Initialized
INFO - 2019-07-03 17:51:41 --> Router Class Initialized
INFO - 2019-07-03 17:51:41 --> Output Class Initialized
INFO - 2019-07-03 17:51:41 --> Security Class Initialized
DEBUG - 2019-07-03 17:51:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:51:41 --> Input Class Initialized
INFO - 2019-07-03 17:51:41 --> Language Class Initialized
INFO - 2019-07-03 17:51:41 --> Language Class Initialized
INFO - 2019-07-03 17:51:41 --> Config Class Initialized
INFO - 2019-07-03 17:51:41 --> Loader Class Initialized
DEBUG - 2019-07-03 17:51:41 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:51:41 --> Helper loaded: url_helper
INFO - 2019-07-03 17:51:41 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:51:41 --> Helper loaded: string_helper
INFO - 2019-07-03 17:51:41 --> Helper loaded: array_helper
INFO - 2019-07-03 17:51:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:51:41 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:51:41 --> Database Driver Class Initialized
INFO - 2019-07-03 17:51:41 --> Controller Class Initialized
INFO - 2019-07-03 23:51:41 --> Helper loaded: language_helper
INFO - 2019-07-03 23:51:41 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:51:41 --> Model Class Initialized
INFO - 2019-07-03 23:51:41 --> Model Class Initialized
INFO - 2019-07-03 23:51:41 --> Model Class Initialized
INFO - 2019-07-03 23:51:41 --> Model Class Initialized
INFO - 2019-07-03 23:51:41 --> Model Class Initialized
INFO - 2019-07-03 23:51:41 --> Final output sent to browser
DEBUG - 2019-07-03 23:51:41 --> Total execution time: 0.4784
INFO - 2019-07-03 17:51:41 --> Config Class Initialized
INFO - 2019-07-03 17:51:41 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:51:41 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:51:41 --> Utf8 Class Initialized
INFO - 2019-07-03 17:51:41 --> URI Class Initialized
INFO - 2019-07-03 17:51:41 --> Router Class Initialized
INFO - 2019-07-03 17:51:41 --> Output Class Initialized
INFO - 2019-07-03 17:51:41 --> Security Class Initialized
DEBUG - 2019-07-03 17:51:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:51:41 --> Input Class Initialized
INFO - 2019-07-03 17:51:41 --> Language Class Initialized
INFO - 2019-07-03 17:51:41 --> Language Class Initialized
INFO - 2019-07-03 17:51:41 --> Config Class Initialized
INFO - 2019-07-03 17:51:42 --> Loader Class Initialized
DEBUG - 2019-07-03 17:51:42 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:51:42 --> Helper loaded: url_helper
INFO - 2019-07-03 17:51:42 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:51:42 --> Helper loaded: string_helper
INFO - 2019-07-03 17:51:42 --> Helper loaded: array_helper
INFO - 2019-07-03 17:51:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:51:42 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:51:42 --> Database Driver Class Initialized
INFO - 2019-07-03 17:51:42 --> Controller Class Initialized
INFO - 2019-07-03 23:51:42 --> Helper loaded: language_helper
INFO - 2019-07-03 23:51:42 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:51:42 --> Model Class Initialized
INFO - 2019-07-03 23:51:42 --> Model Class Initialized
INFO - 2019-07-03 23:51:42 --> Model Class Initialized
INFO - 2019-07-03 23:51:42 --> Model Class Initialized
INFO - 2019-07-03 23:51:42 --> Helper loaded: form_helper
INFO - 2019-07-03 23:51:42 --> Form Validation Class Initialized
DEBUG - 2019-07-03 23:51:42 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-03 23:51:42 --> Model Class Initialized
INFO - 2019-07-03 23:51:42 --> Model Class Initialized
INFO - 2019-07-03 23:51:42 --> Final output sent to browser
DEBUG - 2019-07-03 23:51:42 --> Total execution time: 0.5469
INFO - 2019-07-03 17:51:59 --> Config Class Initialized
INFO - 2019-07-03 17:51:59 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:51:59 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:51:59 --> Utf8 Class Initialized
INFO - 2019-07-03 17:51:59 --> URI Class Initialized
INFO - 2019-07-03 17:51:59 --> Router Class Initialized
INFO - 2019-07-03 17:51:59 --> Output Class Initialized
INFO - 2019-07-03 17:51:59 --> Security Class Initialized
DEBUG - 2019-07-03 17:51:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:51:59 --> Input Class Initialized
INFO - 2019-07-03 17:51:59 --> Language Class Initialized
INFO - 2019-07-03 17:51:59 --> Language Class Initialized
INFO - 2019-07-03 17:51:59 --> Config Class Initialized
INFO - 2019-07-03 17:51:59 --> Loader Class Initialized
DEBUG - 2019-07-03 17:51:59 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:51:59 --> Helper loaded: url_helper
INFO - 2019-07-03 17:51:59 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:51:59 --> Helper loaded: string_helper
INFO - 2019-07-03 17:51:59 --> Helper loaded: array_helper
INFO - 2019-07-03 17:51:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:51:59 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:51:59 --> Database Driver Class Initialized
INFO - 2019-07-03 17:51:59 --> Controller Class Initialized
INFO - 2019-07-03 23:51:59 --> Helper loaded: language_helper
INFO - 2019-07-03 23:51:59 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:51:59 --> Model Class Initialized
INFO - 2019-07-03 23:51:59 --> Model Class Initialized
INFO - 2019-07-03 23:51:59 --> Model Class Initialized
INFO - 2019-07-03 23:51:59 --> Model Class Initialized
INFO - 2019-07-03 23:51:59 --> Model Class Initialized
INFO - 2019-07-03 23:51:59 --> Final output sent to browser
DEBUG - 2019-07-03 23:51:59 --> Total execution time: 0.4803
INFO - 2019-07-03 17:51:59 --> Config Class Initialized
INFO - 2019-07-03 17:51:59 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:51:59 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:51:59 --> Utf8 Class Initialized
INFO - 2019-07-03 17:51:59 --> URI Class Initialized
INFO - 2019-07-03 17:51:59 --> Router Class Initialized
INFO - 2019-07-03 17:51:59 --> Output Class Initialized
INFO - 2019-07-03 17:51:59 --> Security Class Initialized
DEBUG - 2019-07-03 17:52:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:52:00 --> Input Class Initialized
INFO - 2019-07-03 17:52:00 --> Language Class Initialized
INFO - 2019-07-03 17:52:00 --> Language Class Initialized
INFO - 2019-07-03 17:52:00 --> Config Class Initialized
INFO - 2019-07-03 17:52:00 --> Loader Class Initialized
DEBUG - 2019-07-03 17:52:00 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:52:00 --> Helper loaded: url_helper
INFO - 2019-07-03 17:52:00 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:52:00 --> Helper loaded: string_helper
INFO - 2019-07-03 17:52:00 --> Helper loaded: array_helper
INFO - 2019-07-03 17:52:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:52:00 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:52:00 --> Database Driver Class Initialized
INFO - 2019-07-03 17:52:00 --> Controller Class Initialized
INFO - 2019-07-03 23:52:00 --> Helper loaded: language_helper
INFO - 2019-07-03 23:52:00 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:52:00 --> Model Class Initialized
INFO - 2019-07-03 23:52:00 --> Model Class Initialized
INFO - 2019-07-03 23:52:00 --> Model Class Initialized
INFO - 2019-07-03 23:52:00 --> Model Class Initialized
INFO - 2019-07-03 23:52:00 --> Helper loaded: form_helper
INFO - 2019-07-03 23:52:00 --> Form Validation Class Initialized
DEBUG - 2019-07-03 23:52:00 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-03 23:52:00 --> Model Class Initialized
INFO - 2019-07-03 23:52:00 --> Model Class Initialized
INFO - 2019-07-03 23:52:00 --> Final output sent to browser
DEBUG - 2019-07-03 23:52:00 --> Total execution time: 0.5783
INFO - 2019-07-03 17:54:21 --> Config Class Initialized
INFO - 2019-07-03 17:54:21 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:54:21 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:54:21 --> Utf8 Class Initialized
INFO - 2019-07-03 17:54:21 --> URI Class Initialized
INFO - 2019-07-03 17:54:22 --> Router Class Initialized
INFO - 2019-07-03 17:54:22 --> Output Class Initialized
INFO - 2019-07-03 17:54:22 --> Security Class Initialized
DEBUG - 2019-07-03 17:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:54:22 --> Input Class Initialized
INFO - 2019-07-03 17:54:22 --> Language Class Initialized
INFO - 2019-07-03 17:54:22 --> Language Class Initialized
INFO - 2019-07-03 17:54:22 --> Config Class Initialized
INFO - 2019-07-03 17:54:22 --> Loader Class Initialized
DEBUG - 2019-07-03 17:54:22 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:54:22 --> Helper loaded: url_helper
INFO - 2019-07-03 17:54:22 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:54:22 --> Helper loaded: string_helper
INFO - 2019-07-03 17:54:22 --> Helper loaded: array_helper
INFO - 2019-07-03 17:54:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:54:22 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:54:22 --> Database Driver Class Initialized
INFO - 2019-07-03 17:54:22 --> Controller Class Initialized
INFO - 2019-07-03 23:54:22 --> Helper loaded: language_helper
INFO - 2019-07-03 23:54:22 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:54:22 --> Model Class Initialized
INFO - 2019-07-03 23:54:22 --> Model Class Initialized
INFO - 2019-07-03 23:54:22 --> Model Class Initialized
INFO - 2019-07-03 23:54:22 --> Model Class Initialized
INFO - 2019-07-03 23:54:22 --> Helper loaded: form_helper
INFO - 2019-07-03 23:54:22 --> Form Validation Class Initialized
DEBUG - 2019-07-03 23:54:22 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-03 23:54:22 --> Model Class Initialized
INFO - 2019-07-03 23:54:22 --> Model Class Initialized
INFO - 2019-07-03 23:54:22 --> Final output sent to browser
DEBUG - 2019-07-03 23:54:22 --> Total execution time: 0.5570
INFO - 2019-07-03 17:55:11 --> Config Class Initialized
INFO - 2019-07-03 17:55:11 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:55:11 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:55:11 --> Utf8 Class Initialized
INFO - 2019-07-03 17:55:11 --> URI Class Initialized
INFO - 2019-07-03 17:55:11 --> Router Class Initialized
INFO - 2019-07-03 17:55:11 --> Output Class Initialized
INFO - 2019-07-03 17:55:11 --> Security Class Initialized
DEBUG - 2019-07-03 17:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:55:11 --> Input Class Initialized
INFO - 2019-07-03 17:55:11 --> Language Class Initialized
INFO - 2019-07-03 17:55:11 --> Language Class Initialized
INFO - 2019-07-03 17:55:11 --> Config Class Initialized
INFO - 2019-07-03 17:55:11 --> Loader Class Initialized
DEBUG - 2019-07-03 17:55:11 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:55:11 --> Helper loaded: url_helper
INFO - 2019-07-03 17:55:11 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:55:11 --> Helper loaded: string_helper
INFO - 2019-07-03 17:55:11 --> Helper loaded: array_helper
INFO - 2019-07-03 17:55:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:55:11 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:55:11 --> Database Driver Class Initialized
INFO - 2019-07-03 17:55:11 --> Controller Class Initialized
INFO - 2019-07-03 23:55:11 --> Helper loaded: language_helper
INFO - 2019-07-03 23:55:11 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:55:11 --> Model Class Initialized
INFO - 2019-07-03 23:55:11 --> Model Class Initialized
INFO - 2019-07-03 23:55:11 --> Model Class Initialized
INFO - 2019-07-03 23:55:11 --> Model Class Initialized
INFO - 2019-07-03 23:55:11 --> Model Class Initialized
INFO - 2019-07-03 23:55:11 --> Final output sent to browser
DEBUG - 2019-07-03 23:55:11 --> Total execution time: 0.4746
INFO - 2019-07-03 17:55:11 --> Config Class Initialized
INFO - 2019-07-03 17:55:12 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:55:12 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:55:12 --> Utf8 Class Initialized
INFO - 2019-07-03 17:55:12 --> URI Class Initialized
INFO - 2019-07-03 17:55:12 --> Router Class Initialized
INFO - 2019-07-03 17:55:12 --> Output Class Initialized
INFO - 2019-07-03 17:55:12 --> Security Class Initialized
DEBUG - 2019-07-03 17:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:55:12 --> Input Class Initialized
INFO - 2019-07-03 17:55:12 --> Language Class Initialized
INFO - 2019-07-03 17:55:12 --> Language Class Initialized
INFO - 2019-07-03 17:55:12 --> Config Class Initialized
INFO - 2019-07-03 17:55:12 --> Loader Class Initialized
DEBUG - 2019-07-03 17:55:12 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:55:12 --> Helper loaded: url_helper
INFO - 2019-07-03 17:55:12 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:55:12 --> Helper loaded: string_helper
INFO - 2019-07-03 17:55:12 --> Helper loaded: array_helper
INFO - 2019-07-03 17:55:12 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:55:12 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:55:12 --> Database Driver Class Initialized
INFO - 2019-07-03 17:55:12 --> Controller Class Initialized
INFO - 2019-07-03 23:55:12 --> Helper loaded: language_helper
INFO - 2019-07-03 23:55:12 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:55:12 --> Model Class Initialized
INFO - 2019-07-03 23:55:12 --> Model Class Initialized
INFO - 2019-07-03 23:55:12 --> Model Class Initialized
INFO - 2019-07-03 23:55:12 --> Model Class Initialized
INFO - 2019-07-03 23:55:12 --> Helper loaded: form_helper
INFO - 2019-07-03 23:55:12 --> Form Validation Class Initialized
DEBUG - 2019-07-03 23:55:12 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-03 23:55:12 --> Model Class Initialized
INFO - 2019-07-03 23:55:12 --> Model Class Initialized
INFO - 2019-07-03 23:55:12 --> Final output sent to browser
DEBUG - 2019-07-03 23:55:12 --> Total execution time: 0.5516
INFO - 2019-07-03 17:55:15 --> Config Class Initialized
INFO - 2019-07-03 17:55:15 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:55:15 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:55:15 --> Utf8 Class Initialized
INFO - 2019-07-03 17:55:15 --> URI Class Initialized
INFO - 2019-07-03 17:55:15 --> Router Class Initialized
INFO - 2019-07-03 17:55:15 --> Output Class Initialized
INFO - 2019-07-03 17:55:15 --> Security Class Initialized
DEBUG - 2019-07-03 17:55:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:55:15 --> Input Class Initialized
INFO - 2019-07-03 17:55:15 --> Language Class Initialized
INFO - 2019-07-03 17:55:15 --> Language Class Initialized
INFO - 2019-07-03 17:55:15 --> Config Class Initialized
INFO - 2019-07-03 17:55:15 --> Loader Class Initialized
DEBUG - 2019-07-03 17:55:15 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:55:15 --> Helper loaded: url_helper
INFO - 2019-07-03 17:55:15 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:55:15 --> Helper loaded: string_helper
INFO - 2019-07-03 17:55:15 --> Helper loaded: array_helper
INFO - 2019-07-03 17:55:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:55:15 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:55:15 --> Database Driver Class Initialized
INFO - 2019-07-03 17:55:15 --> Controller Class Initialized
INFO - 2019-07-03 23:55:15 --> Helper loaded: language_helper
INFO - 2019-07-03 23:55:15 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:55:15 --> Model Class Initialized
INFO - 2019-07-03 23:55:15 --> Model Class Initialized
INFO - 2019-07-03 23:55:15 --> Model Class Initialized
INFO - 2019-07-03 23:55:15 --> Model Class Initialized
INFO - 2019-07-03 23:55:15 --> Helper loaded: form_helper
INFO - 2019-07-03 23:55:16 --> Form Validation Class Initialized
DEBUG - 2019-07-03 23:55:16 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-03 23:55:16 --> Model Class Initialized
INFO - 2019-07-03 23:55:16 --> Model Class Initialized
INFO - 2019-07-03 23:55:16 --> Final output sent to browser
DEBUG - 2019-07-03 23:55:16 --> Total execution time: 0.5527
INFO - 2019-07-03 17:55:44 --> Config Class Initialized
INFO - 2019-07-03 17:55:44 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:55:44 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:55:44 --> Utf8 Class Initialized
INFO - 2019-07-03 17:55:44 --> URI Class Initialized
INFO - 2019-07-03 17:55:44 --> Router Class Initialized
INFO - 2019-07-03 17:55:44 --> Output Class Initialized
INFO - 2019-07-03 17:55:44 --> Security Class Initialized
DEBUG - 2019-07-03 17:55:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:55:44 --> Input Class Initialized
INFO - 2019-07-03 17:55:44 --> Language Class Initialized
INFO - 2019-07-03 17:55:44 --> Language Class Initialized
INFO - 2019-07-03 17:55:44 --> Config Class Initialized
INFO - 2019-07-03 17:55:44 --> Loader Class Initialized
DEBUG - 2019-07-03 17:55:44 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:55:44 --> Helper loaded: url_helper
INFO - 2019-07-03 17:55:44 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:55:44 --> Helper loaded: string_helper
INFO - 2019-07-03 17:55:44 --> Helper loaded: array_helper
INFO - 2019-07-03 17:55:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:55:44 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:55:44 --> Database Driver Class Initialized
INFO - 2019-07-03 17:55:44 --> Controller Class Initialized
INFO - 2019-07-03 23:55:44 --> Helper loaded: language_helper
INFO - 2019-07-03 23:55:45 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:55:45 --> Model Class Initialized
INFO - 2019-07-03 23:55:45 --> Model Class Initialized
INFO - 2019-07-03 23:55:45 --> Model Class Initialized
INFO - 2019-07-03 23:55:45 --> Model Class Initialized
INFO - 2019-07-03 23:55:45 --> Model Class Initialized
INFO - 2019-07-03 23:55:45 --> Final output sent to browser
DEBUG - 2019-07-03 23:55:45 --> Total execution time: 0.4825
INFO - 2019-07-03 17:55:45 --> Config Class Initialized
INFO - 2019-07-03 17:55:45 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:55:45 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:55:45 --> Utf8 Class Initialized
INFO - 2019-07-03 17:55:45 --> URI Class Initialized
INFO - 2019-07-03 17:55:45 --> Router Class Initialized
INFO - 2019-07-03 17:55:45 --> Output Class Initialized
INFO - 2019-07-03 17:55:45 --> Security Class Initialized
DEBUG - 2019-07-03 17:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:55:45 --> Input Class Initialized
INFO - 2019-07-03 17:55:45 --> Language Class Initialized
INFO - 2019-07-03 17:55:45 --> Language Class Initialized
INFO - 2019-07-03 17:55:45 --> Config Class Initialized
INFO - 2019-07-03 17:55:45 --> Loader Class Initialized
DEBUG - 2019-07-03 17:55:45 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:55:45 --> Helper loaded: url_helper
INFO - 2019-07-03 17:55:45 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:55:45 --> Helper loaded: string_helper
INFO - 2019-07-03 17:55:45 --> Helper loaded: array_helper
INFO - 2019-07-03 17:55:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:55:45 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:55:45 --> Database Driver Class Initialized
INFO - 2019-07-03 17:55:45 --> Controller Class Initialized
INFO - 2019-07-03 23:55:45 --> Helper loaded: language_helper
INFO - 2019-07-03 23:55:45 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:55:45 --> Model Class Initialized
INFO - 2019-07-03 23:55:45 --> Model Class Initialized
INFO - 2019-07-03 23:55:45 --> Model Class Initialized
INFO - 2019-07-03 23:55:45 --> Model Class Initialized
INFO - 2019-07-03 23:55:45 --> Helper loaded: form_helper
INFO - 2019-07-03 23:55:45 --> Form Validation Class Initialized
DEBUG - 2019-07-03 23:55:45 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-03 23:55:45 --> Model Class Initialized
INFO - 2019-07-03 23:55:45 --> Model Class Initialized
INFO - 2019-07-03 23:55:45 --> Final output sent to browser
DEBUG - 2019-07-03 23:55:45 --> Total execution time: 0.5734
INFO - 2019-07-03 17:55:56 --> Config Class Initialized
INFO - 2019-07-03 17:55:56 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:55:56 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:55:56 --> Utf8 Class Initialized
INFO - 2019-07-03 17:55:56 --> URI Class Initialized
INFO - 2019-07-03 17:55:56 --> Router Class Initialized
INFO - 2019-07-03 17:55:56 --> Output Class Initialized
INFO - 2019-07-03 17:55:56 --> Security Class Initialized
DEBUG - 2019-07-03 17:55:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:55:56 --> Input Class Initialized
INFO - 2019-07-03 17:55:56 --> Language Class Initialized
INFO - 2019-07-03 17:55:57 --> Language Class Initialized
INFO - 2019-07-03 17:55:57 --> Config Class Initialized
INFO - 2019-07-03 17:55:57 --> Loader Class Initialized
DEBUG - 2019-07-03 17:55:57 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:55:57 --> Helper loaded: url_helper
INFO - 2019-07-03 17:55:57 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:55:57 --> Helper loaded: string_helper
INFO - 2019-07-03 17:55:57 --> Helper loaded: array_helper
INFO - 2019-07-03 17:55:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:55:57 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:55:57 --> Database Driver Class Initialized
INFO - 2019-07-03 17:55:57 --> Controller Class Initialized
INFO - 2019-07-03 23:55:57 --> Helper loaded: language_helper
INFO - 2019-07-03 23:55:57 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:55:57 --> Model Class Initialized
INFO - 2019-07-03 23:55:57 --> Model Class Initialized
INFO - 2019-07-03 23:55:57 --> Model Class Initialized
INFO - 2019-07-03 23:55:57 --> Model Class Initialized
INFO - 2019-07-03 23:55:57 --> Helper loaded: form_helper
INFO - 2019-07-03 23:55:57 --> Form Validation Class Initialized
DEBUG - 2019-07-03 23:55:57 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-03 23:55:57 --> Model Class Initialized
INFO - 2019-07-03 23:55:57 --> Model Class Initialized
INFO - 2019-07-03 23:55:57 --> Final output sent to browser
DEBUG - 2019-07-03 23:55:57 --> Total execution time: 0.5641
INFO - 2019-07-03 17:56:02 --> Config Class Initialized
INFO - 2019-07-03 17:56:02 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:56:02 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:56:02 --> Utf8 Class Initialized
INFO - 2019-07-03 17:56:02 --> URI Class Initialized
INFO - 2019-07-03 17:56:02 --> Router Class Initialized
INFO - 2019-07-03 17:56:02 --> Output Class Initialized
INFO - 2019-07-03 17:56:02 --> Security Class Initialized
DEBUG - 2019-07-03 17:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:56:02 --> Input Class Initialized
INFO - 2019-07-03 17:56:02 --> Language Class Initialized
INFO - 2019-07-03 17:56:02 --> Language Class Initialized
INFO - 2019-07-03 17:56:03 --> Config Class Initialized
INFO - 2019-07-03 17:56:03 --> Loader Class Initialized
DEBUG - 2019-07-03 17:56:03 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:56:03 --> Helper loaded: url_helper
INFO - 2019-07-03 17:56:03 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:56:03 --> Helper loaded: string_helper
INFO - 2019-07-03 17:56:03 --> Helper loaded: array_helper
INFO - 2019-07-03 17:56:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:56:03 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:56:03 --> Database Driver Class Initialized
INFO - 2019-07-03 17:56:03 --> Controller Class Initialized
INFO - 2019-07-03 23:56:03 --> Helper loaded: language_helper
INFO - 2019-07-03 23:56:03 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:56:03 --> Model Class Initialized
INFO - 2019-07-03 23:56:03 --> Model Class Initialized
INFO - 2019-07-03 23:56:03 --> Model Class Initialized
INFO - 2019-07-03 23:56:03 --> Model Class Initialized
INFO - 2019-07-03 23:56:03 --> Model Class Initialized
INFO - 2019-07-03 23:56:03 --> Final output sent to browser
DEBUG - 2019-07-03 23:56:03 --> Total execution time: 0.4951
INFO - 2019-07-03 17:56:03 --> Config Class Initialized
INFO - 2019-07-03 17:56:03 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:56:03 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:56:03 --> Utf8 Class Initialized
INFO - 2019-07-03 17:56:03 --> URI Class Initialized
INFO - 2019-07-03 17:56:03 --> Router Class Initialized
INFO - 2019-07-03 17:56:03 --> Output Class Initialized
INFO - 2019-07-03 17:56:03 --> Security Class Initialized
DEBUG - 2019-07-03 17:56:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:56:03 --> Input Class Initialized
INFO - 2019-07-03 17:56:03 --> Language Class Initialized
INFO - 2019-07-03 17:56:03 --> Language Class Initialized
INFO - 2019-07-03 17:56:03 --> Config Class Initialized
INFO - 2019-07-03 17:56:03 --> Loader Class Initialized
DEBUG - 2019-07-03 17:56:03 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:56:03 --> Helper loaded: url_helper
INFO - 2019-07-03 17:56:03 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:56:03 --> Helper loaded: string_helper
INFO - 2019-07-03 17:56:03 --> Helper loaded: array_helper
INFO - 2019-07-03 17:56:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:56:03 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:56:03 --> Database Driver Class Initialized
INFO - 2019-07-03 17:56:03 --> Controller Class Initialized
INFO - 2019-07-03 23:56:03 --> Helper loaded: language_helper
INFO - 2019-07-03 23:56:03 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:56:03 --> Model Class Initialized
INFO - 2019-07-03 23:56:03 --> Model Class Initialized
INFO - 2019-07-03 23:56:03 --> Model Class Initialized
INFO - 2019-07-03 23:56:03 --> Model Class Initialized
INFO - 2019-07-03 23:56:03 --> Helper loaded: form_helper
INFO - 2019-07-03 23:56:03 --> Form Validation Class Initialized
DEBUG - 2019-07-03 23:56:03 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-03 23:56:03 --> Model Class Initialized
INFO - 2019-07-03 23:56:03 --> Model Class Initialized
INFO - 2019-07-03 23:56:03 --> Final output sent to browser
DEBUG - 2019-07-03 23:56:03 --> Total execution time: 0.5654
INFO - 2019-07-03 17:56:05 --> Config Class Initialized
INFO - 2019-07-03 17:56:05 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:56:05 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:56:05 --> Utf8 Class Initialized
INFO - 2019-07-03 17:56:05 --> URI Class Initialized
INFO - 2019-07-03 17:56:05 --> Router Class Initialized
INFO - 2019-07-03 17:56:05 --> Output Class Initialized
INFO - 2019-07-03 17:56:05 --> Security Class Initialized
DEBUG - 2019-07-03 17:56:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:56:05 --> Input Class Initialized
INFO - 2019-07-03 17:56:05 --> Language Class Initialized
INFO - 2019-07-03 17:56:06 --> Language Class Initialized
INFO - 2019-07-03 17:56:06 --> Config Class Initialized
INFO - 2019-07-03 17:56:06 --> Loader Class Initialized
DEBUG - 2019-07-03 17:56:06 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:56:06 --> Helper loaded: url_helper
INFO - 2019-07-03 17:56:06 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:56:06 --> Helper loaded: string_helper
INFO - 2019-07-03 17:56:06 --> Helper loaded: array_helper
INFO - 2019-07-03 17:56:06 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:56:06 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:56:06 --> Database Driver Class Initialized
INFO - 2019-07-03 17:56:06 --> Controller Class Initialized
INFO - 2019-07-03 23:56:06 --> Helper loaded: language_helper
INFO - 2019-07-03 23:56:06 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:56:06 --> Model Class Initialized
INFO - 2019-07-03 23:56:06 --> Model Class Initialized
INFO - 2019-07-03 23:56:06 --> Model Class Initialized
INFO - 2019-07-03 23:56:06 --> Model Class Initialized
INFO - 2019-07-03 23:56:06 --> Model Class Initialized
INFO - 2019-07-03 23:56:06 --> Final output sent to browser
DEBUG - 2019-07-03 23:56:06 --> Total execution time: 0.4840
INFO - 2019-07-03 17:56:06 --> Config Class Initialized
INFO - 2019-07-03 17:56:06 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:56:06 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:56:06 --> Utf8 Class Initialized
INFO - 2019-07-03 17:56:06 --> URI Class Initialized
INFO - 2019-07-03 17:56:06 --> Router Class Initialized
INFO - 2019-07-03 17:56:06 --> Output Class Initialized
INFO - 2019-07-03 17:56:06 --> Security Class Initialized
DEBUG - 2019-07-03 17:56:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:56:06 --> Input Class Initialized
INFO - 2019-07-03 17:56:06 --> Language Class Initialized
INFO - 2019-07-03 17:56:06 --> Language Class Initialized
INFO - 2019-07-03 17:56:06 --> Config Class Initialized
INFO - 2019-07-03 17:56:06 --> Loader Class Initialized
DEBUG - 2019-07-03 17:56:06 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:56:06 --> Helper loaded: url_helper
INFO - 2019-07-03 17:56:06 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:56:06 --> Helper loaded: string_helper
INFO - 2019-07-03 17:56:06 --> Helper loaded: array_helper
INFO - 2019-07-03 17:56:06 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:56:06 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:56:06 --> Database Driver Class Initialized
INFO - 2019-07-03 17:56:06 --> Controller Class Initialized
INFO - 2019-07-03 23:56:06 --> Helper loaded: language_helper
INFO - 2019-07-03 23:56:06 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:56:06 --> Model Class Initialized
INFO - 2019-07-03 23:56:06 --> Model Class Initialized
INFO - 2019-07-03 23:56:06 --> Model Class Initialized
INFO - 2019-07-03 23:56:06 --> Model Class Initialized
INFO - 2019-07-03 23:56:06 --> Helper loaded: form_helper
INFO - 2019-07-03 23:56:06 --> Form Validation Class Initialized
DEBUG - 2019-07-03 23:56:06 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-03 23:56:06 --> Model Class Initialized
INFO - 2019-07-03 23:56:06 --> Model Class Initialized
INFO - 2019-07-03 23:56:06 --> Final output sent to browser
DEBUG - 2019-07-03 23:56:06 --> Total execution time: 0.5805
INFO - 2019-07-03 17:56:08 --> Config Class Initialized
INFO - 2019-07-03 17:56:08 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:56:08 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:56:08 --> Utf8 Class Initialized
INFO - 2019-07-03 17:56:08 --> URI Class Initialized
INFO - 2019-07-03 17:56:08 --> Router Class Initialized
INFO - 2019-07-03 17:56:08 --> Output Class Initialized
INFO - 2019-07-03 17:56:08 --> Security Class Initialized
DEBUG - 2019-07-03 17:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:56:08 --> Input Class Initialized
INFO - 2019-07-03 17:56:08 --> Language Class Initialized
INFO - 2019-07-03 17:56:08 --> Language Class Initialized
INFO - 2019-07-03 17:56:08 --> Config Class Initialized
INFO - 2019-07-03 17:56:08 --> Loader Class Initialized
DEBUG - 2019-07-03 17:56:08 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:56:08 --> Helper loaded: url_helper
INFO - 2019-07-03 17:56:08 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:56:08 --> Helper loaded: string_helper
INFO - 2019-07-03 17:56:08 --> Helper loaded: array_helper
INFO - 2019-07-03 17:56:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:56:08 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:56:08 --> Database Driver Class Initialized
INFO - 2019-07-03 17:56:08 --> Controller Class Initialized
INFO - 2019-07-03 23:56:08 --> Helper loaded: language_helper
INFO - 2019-07-03 23:56:08 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:56:08 --> Model Class Initialized
INFO - 2019-07-03 23:56:08 --> Model Class Initialized
INFO - 2019-07-03 23:56:08 --> Model Class Initialized
INFO - 2019-07-03 23:56:08 --> Model Class Initialized
INFO - 2019-07-03 23:56:09 --> Helper loaded: form_helper
INFO - 2019-07-03 23:56:09 --> Form Validation Class Initialized
DEBUG - 2019-07-03 23:56:09 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-03 23:56:09 --> Model Class Initialized
INFO - 2019-07-03 23:56:09 --> Model Class Initialized
INFO - 2019-07-03 23:56:09 --> Final output sent to browser
DEBUG - 2019-07-03 23:56:09 --> Total execution time: 0.5534
INFO - 2019-07-03 17:56:41 --> Config Class Initialized
INFO - 2019-07-03 17:56:41 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:56:41 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:56:41 --> Utf8 Class Initialized
INFO - 2019-07-03 17:56:42 --> URI Class Initialized
INFO - 2019-07-03 17:56:42 --> Router Class Initialized
INFO - 2019-07-03 17:56:42 --> Output Class Initialized
INFO - 2019-07-03 17:56:42 --> Security Class Initialized
DEBUG - 2019-07-03 17:56:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:56:42 --> Input Class Initialized
INFO - 2019-07-03 17:56:42 --> Language Class Initialized
INFO - 2019-07-03 17:56:42 --> Language Class Initialized
INFO - 2019-07-03 17:56:42 --> Config Class Initialized
INFO - 2019-07-03 17:56:42 --> Loader Class Initialized
DEBUG - 2019-07-03 17:56:42 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:56:42 --> Helper loaded: url_helper
INFO - 2019-07-03 17:56:42 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:56:42 --> Helper loaded: string_helper
INFO - 2019-07-03 17:56:42 --> Helper loaded: array_helper
INFO - 2019-07-03 17:56:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:56:42 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:56:42 --> Database Driver Class Initialized
INFO - 2019-07-03 17:56:42 --> Controller Class Initialized
INFO - 2019-07-03 23:56:42 --> Helper loaded: language_helper
INFO - 2019-07-03 23:56:42 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:56:42 --> Model Class Initialized
INFO - 2019-07-03 23:56:42 --> Model Class Initialized
INFO - 2019-07-03 23:56:42 --> Model Class Initialized
INFO - 2019-07-03 23:56:42 --> Model Class Initialized
INFO - 2019-07-03 23:56:42 --> Model Class Initialized
INFO - 2019-07-03 23:56:42 --> Final output sent to browser
DEBUG - 2019-07-03 23:56:42 --> Total execution time: 0.4711
INFO - 2019-07-03 17:56:42 --> Config Class Initialized
INFO - 2019-07-03 17:56:42 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:56:42 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:56:42 --> Utf8 Class Initialized
INFO - 2019-07-03 17:56:42 --> URI Class Initialized
INFO - 2019-07-03 17:56:42 --> Router Class Initialized
INFO - 2019-07-03 17:56:42 --> Output Class Initialized
INFO - 2019-07-03 17:56:42 --> Security Class Initialized
DEBUG - 2019-07-03 17:56:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:56:42 --> Input Class Initialized
INFO - 2019-07-03 17:56:42 --> Language Class Initialized
INFO - 2019-07-03 17:56:42 --> Language Class Initialized
INFO - 2019-07-03 17:56:42 --> Config Class Initialized
INFO - 2019-07-03 17:56:42 --> Loader Class Initialized
DEBUG - 2019-07-03 17:56:42 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:56:42 --> Helper loaded: url_helper
INFO - 2019-07-03 17:56:42 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:56:42 --> Helper loaded: string_helper
INFO - 2019-07-03 17:56:42 --> Helper loaded: array_helper
INFO - 2019-07-03 17:56:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:56:42 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:56:42 --> Database Driver Class Initialized
INFO - 2019-07-03 17:56:42 --> Controller Class Initialized
INFO - 2019-07-03 23:56:42 --> Helper loaded: language_helper
INFO - 2019-07-03 23:56:42 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:56:42 --> Model Class Initialized
INFO - 2019-07-03 23:56:42 --> Model Class Initialized
INFO - 2019-07-03 23:56:42 --> Model Class Initialized
INFO - 2019-07-03 23:56:42 --> Model Class Initialized
INFO - 2019-07-03 23:56:42 --> Helper loaded: form_helper
INFO - 2019-07-03 23:56:42 --> Form Validation Class Initialized
DEBUG - 2019-07-03 23:56:43 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-03 23:56:43 --> Model Class Initialized
INFO - 2019-07-03 23:56:43 --> Model Class Initialized
INFO - 2019-07-03 23:56:43 --> Final output sent to browser
DEBUG - 2019-07-03 23:56:43 --> Total execution time: 0.5756
INFO - 2019-07-03 17:56:43 --> Config Class Initialized
INFO - 2019-07-03 17:56:43 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:56:43 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:56:43 --> Utf8 Class Initialized
INFO - 2019-07-03 17:56:43 --> URI Class Initialized
INFO - 2019-07-03 17:56:43 --> Router Class Initialized
INFO - 2019-07-03 17:56:43 --> Output Class Initialized
INFO - 2019-07-03 17:56:43 --> Security Class Initialized
DEBUG - 2019-07-03 17:56:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:56:43 --> Input Class Initialized
INFO - 2019-07-03 17:56:43 --> Language Class Initialized
INFO - 2019-07-03 17:56:43 --> Language Class Initialized
INFO - 2019-07-03 17:56:43 --> Config Class Initialized
INFO - 2019-07-03 17:56:43 --> Loader Class Initialized
DEBUG - 2019-07-03 17:56:43 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:56:43 --> Helper loaded: url_helper
INFO - 2019-07-03 17:56:43 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:56:43 --> Helper loaded: string_helper
INFO - 2019-07-03 17:56:43 --> Helper loaded: array_helper
INFO - 2019-07-03 17:56:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:56:44 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:56:44 --> Database Driver Class Initialized
INFO - 2019-07-03 17:56:44 --> Controller Class Initialized
INFO - 2019-07-03 23:56:44 --> Helper loaded: language_helper
INFO - 2019-07-03 23:56:44 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:56:44 --> Model Class Initialized
INFO - 2019-07-03 23:56:44 --> Model Class Initialized
INFO - 2019-07-03 23:56:44 --> Model Class Initialized
INFO - 2019-07-03 23:56:44 --> Model Class Initialized
INFO - 2019-07-03 23:56:44 --> Helper loaded: form_helper
INFO - 2019-07-03 23:56:44 --> Form Validation Class Initialized
DEBUG - 2019-07-03 23:56:44 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-03 23:56:44 --> Model Class Initialized
INFO - 2019-07-03 23:56:44 --> Model Class Initialized
INFO - 2019-07-03 23:56:44 --> Final output sent to browser
DEBUG - 2019-07-03 23:56:44 --> Total execution time: 0.5748
INFO - 2019-07-03 17:57:03 --> Config Class Initialized
INFO - 2019-07-03 17:57:03 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:57:03 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:57:03 --> Utf8 Class Initialized
INFO - 2019-07-03 17:57:03 --> URI Class Initialized
INFO - 2019-07-03 17:57:03 --> Router Class Initialized
INFO - 2019-07-03 17:57:03 --> Output Class Initialized
INFO - 2019-07-03 17:57:03 --> Security Class Initialized
DEBUG - 2019-07-03 17:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:57:03 --> Input Class Initialized
INFO - 2019-07-03 17:57:03 --> Language Class Initialized
INFO - 2019-07-03 17:57:03 --> Language Class Initialized
INFO - 2019-07-03 17:57:03 --> Config Class Initialized
INFO - 2019-07-03 17:57:03 --> Loader Class Initialized
DEBUG - 2019-07-03 17:57:03 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:57:03 --> Helper loaded: url_helper
INFO - 2019-07-03 17:57:03 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:57:03 --> Helper loaded: string_helper
INFO - 2019-07-03 17:57:03 --> Helper loaded: array_helper
INFO - 2019-07-03 17:57:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:57:03 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:57:03 --> Database Driver Class Initialized
INFO - 2019-07-03 17:57:03 --> Controller Class Initialized
INFO - 2019-07-03 23:57:03 --> Helper loaded: language_helper
INFO - 2019-07-03 23:57:03 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:57:03 --> Model Class Initialized
INFO - 2019-07-03 23:57:03 --> Model Class Initialized
INFO - 2019-07-03 23:57:03 --> Model Class Initialized
INFO - 2019-07-03 23:57:03 --> Model Class Initialized
INFO - 2019-07-03 23:57:03 --> Model Class Initialized
INFO - 2019-07-03 23:57:03 --> Final output sent to browser
DEBUG - 2019-07-03 23:57:03 --> Total execution time: 0.4896
INFO - 2019-07-03 17:57:03 --> Config Class Initialized
INFO - 2019-07-03 17:57:03 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:57:03 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:57:03 --> Utf8 Class Initialized
INFO - 2019-07-03 17:57:03 --> URI Class Initialized
INFO - 2019-07-03 17:57:03 --> Router Class Initialized
INFO - 2019-07-03 17:57:03 --> Output Class Initialized
INFO - 2019-07-03 17:57:03 --> Security Class Initialized
DEBUG - 2019-07-03 17:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:57:03 --> Input Class Initialized
INFO - 2019-07-03 17:57:03 --> Language Class Initialized
INFO - 2019-07-03 17:57:03 --> Language Class Initialized
INFO - 2019-07-03 17:57:03 --> Config Class Initialized
INFO - 2019-07-03 17:57:03 --> Loader Class Initialized
DEBUG - 2019-07-03 17:57:03 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:57:03 --> Helper loaded: url_helper
INFO - 2019-07-03 17:57:03 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:57:03 --> Helper loaded: string_helper
INFO - 2019-07-03 17:57:03 --> Helper loaded: array_helper
INFO - 2019-07-03 17:57:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:57:03 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:57:03 --> Database Driver Class Initialized
INFO - 2019-07-03 17:57:03 --> Controller Class Initialized
INFO - 2019-07-03 23:57:04 --> Helper loaded: language_helper
INFO - 2019-07-03 23:57:04 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:57:04 --> Model Class Initialized
INFO - 2019-07-03 23:57:04 --> Model Class Initialized
INFO - 2019-07-03 23:57:04 --> Model Class Initialized
INFO - 2019-07-03 23:57:04 --> Model Class Initialized
INFO - 2019-07-03 23:57:04 --> Helper loaded: form_helper
INFO - 2019-07-03 23:57:04 --> Form Validation Class Initialized
DEBUG - 2019-07-03 23:57:04 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-03 23:57:04 --> Model Class Initialized
INFO - 2019-07-03 23:57:04 --> Model Class Initialized
INFO - 2019-07-03 23:57:04 --> Final output sent to browser
DEBUG - 2019-07-03 23:57:04 --> Total execution time: 0.5655
INFO - 2019-07-03 17:57:04 --> Config Class Initialized
INFO - 2019-07-03 17:57:04 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:57:04 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:57:04 --> Utf8 Class Initialized
INFO - 2019-07-03 17:57:04 --> URI Class Initialized
INFO - 2019-07-03 17:57:04 --> Router Class Initialized
INFO - 2019-07-03 17:57:04 --> Output Class Initialized
INFO - 2019-07-03 17:57:04 --> Security Class Initialized
DEBUG - 2019-07-03 17:57:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:57:04 --> Input Class Initialized
INFO - 2019-07-03 17:57:05 --> Language Class Initialized
INFO - 2019-07-03 17:57:05 --> Language Class Initialized
INFO - 2019-07-03 17:57:05 --> Config Class Initialized
INFO - 2019-07-03 17:57:05 --> Loader Class Initialized
DEBUG - 2019-07-03 17:57:05 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:57:05 --> Helper loaded: url_helper
INFO - 2019-07-03 17:57:05 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:57:05 --> Helper loaded: string_helper
INFO - 2019-07-03 17:57:05 --> Helper loaded: array_helper
INFO - 2019-07-03 17:57:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:57:05 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:57:05 --> Database Driver Class Initialized
INFO - 2019-07-03 17:57:05 --> Controller Class Initialized
INFO - 2019-07-03 23:57:05 --> Helper loaded: language_helper
INFO - 2019-07-03 23:57:05 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:57:05 --> Model Class Initialized
INFO - 2019-07-03 23:57:05 --> Model Class Initialized
INFO - 2019-07-03 23:57:05 --> Model Class Initialized
INFO - 2019-07-03 23:57:05 --> Model Class Initialized
INFO - 2019-07-03 23:57:05 --> Helper loaded: form_helper
INFO - 2019-07-03 23:57:05 --> Form Validation Class Initialized
DEBUG - 2019-07-03 23:57:05 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-03 23:57:05 --> Model Class Initialized
INFO - 2019-07-03 23:57:05 --> Model Class Initialized
INFO - 2019-07-03 23:57:05 --> Final output sent to browser
DEBUG - 2019-07-03 23:57:05 --> Total execution time: 0.5748
INFO - 2019-07-03 17:57:39 --> Config Class Initialized
INFO - 2019-07-03 17:57:39 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:57:39 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:57:39 --> Utf8 Class Initialized
INFO - 2019-07-03 17:57:39 --> URI Class Initialized
INFO - 2019-07-03 17:57:39 --> Router Class Initialized
INFO - 2019-07-03 17:57:39 --> Output Class Initialized
INFO - 2019-07-03 17:57:39 --> Security Class Initialized
DEBUG - 2019-07-03 17:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:57:39 --> Input Class Initialized
INFO - 2019-07-03 17:57:39 --> Language Class Initialized
INFO - 2019-07-03 17:57:39 --> Language Class Initialized
INFO - 2019-07-03 17:57:39 --> Config Class Initialized
INFO - 2019-07-03 17:57:39 --> Loader Class Initialized
DEBUG - 2019-07-03 17:57:39 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:57:39 --> Helper loaded: url_helper
INFO - 2019-07-03 17:57:39 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:57:39 --> Helper loaded: string_helper
INFO - 2019-07-03 17:57:39 --> Helper loaded: array_helper
INFO - 2019-07-03 17:57:39 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:57:39 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:57:39 --> Database Driver Class Initialized
INFO - 2019-07-03 17:57:39 --> Controller Class Initialized
INFO - 2019-07-03 23:57:39 --> Helper loaded: language_helper
INFO - 2019-07-03 23:57:39 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:57:39 --> Model Class Initialized
INFO - 2019-07-03 23:57:39 --> Model Class Initialized
INFO - 2019-07-03 23:57:39 --> Model Class Initialized
INFO - 2019-07-03 23:57:39 --> Model Class Initialized
INFO - 2019-07-03 23:57:39 --> Model Class Initialized
INFO - 2019-07-03 23:57:39 --> Final output sent to browser
DEBUG - 2019-07-03 23:57:39 --> Total execution time: 0.4957
INFO - 2019-07-03 17:57:39 --> Config Class Initialized
INFO - 2019-07-03 17:57:39 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:57:39 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:57:39 --> Utf8 Class Initialized
INFO - 2019-07-03 17:57:39 --> URI Class Initialized
INFO - 2019-07-03 17:57:39 --> Router Class Initialized
INFO - 2019-07-03 17:57:39 --> Output Class Initialized
INFO - 2019-07-03 17:57:39 --> Security Class Initialized
DEBUG - 2019-07-03 17:57:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:57:39 --> Input Class Initialized
INFO - 2019-07-03 17:57:39 --> Language Class Initialized
INFO - 2019-07-03 17:57:39 --> Language Class Initialized
INFO - 2019-07-03 17:57:39 --> Config Class Initialized
INFO - 2019-07-03 17:57:39 --> Loader Class Initialized
DEBUG - 2019-07-03 17:57:39 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:57:40 --> Helper loaded: url_helper
INFO - 2019-07-03 17:57:40 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:57:40 --> Helper loaded: string_helper
INFO - 2019-07-03 17:57:40 --> Helper loaded: array_helper
INFO - 2019-07-03 17:57:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:57:40 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:57:40 --> Database Driver Class Initialized
INFO - 2019-07-03 17:57:40 --> Controller Class Initialized
INFO - 2019-07-03 23:57:40 --> Helper loaded: language_helper
INFO - 2019-07-03 23:57:40 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:57:40 --> Model Class Initialized
INFO - 2019-07-03 23:57:40 --> Model Class Initialized
INFO - 2019-07-03 23:57:40 --> Model Class Initialized
INFO - 2019-07-03 23:57:40 --> Model Class Initialized
INFO - 2019-07-03 23:57:40 --> Helper loaded: form_helper
INFO - 2019-07-03 23:57:40 --> Form Validation Class Initialized
DEBUG - 2019-07-03 23:57:40 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-03 23:57:40 --> Model Class Initialized
INFO - 2019-07-03 23:57:40 --> Model Class Initialized
INFO - 2019-07-03 23:57:40 --> Final output sent to browser
DEBUG - 2019-07-03 23:57:40 --> Total execution time: 0.5635
INFO - 2019-07-03 17:57:42 --> Config Class Initialized
INFO - 2019-07-03 17:57:42 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:57:42 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:57:42 --> Utf8 Class Initialized
INFO - 2019-07-03 17:57:42 --> URI Class Initialized
INFO - 2019-07-03 17:57:42 --> Router Class Initialized
INFO - 2019-07-03 17:57:42 --> Output Class Initialized
INFO - 2019-07-03 17:57:42 --> Security Class Initialized
DEBUG - 2019-07-03 17:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:57:42 --> Input Class Initialized
INFO - 2019-07-03 17:57:42 --> Language Class Initialized
INFO - 2019-07-03 17:57:42 --> Language Class Initialized
INFO - 2019-07-03 17:57:42 --> Config Class Initialized
INFO - 2019-07-03 17:57:42 --> Loader Class Initialized
DEBUG - 2019-07-03 17:57:42 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:57:42 --> Helper loaded: url_helper
INFO - 2019-07-03 17:57:42 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:57:42 --> Helper loaded: string_helper
INFO - 2019-07-03 17:57:42 --> Helper loaded: array_helper
INFO - 2019-07-03 17:57:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:57:42 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:57:42 --> Database Driver Class Initialized
INFO - 2019-07-03 17:57:42 --> Controller Class Initialized
INFO - 2019-07-03 23:57:42 --> Helper loaded: language_helper
INFO - 2019-07-03 23:57:42 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:57:42 --> Model Class Initialized
INFO - 2019-07-03 23:57:42 --> Model Class Initialized
INFO - 2019-07-03 23:57:42 --> Model Class Initialized
INFO - 2019-07-03 23:57:42 --> Model Class Initialized
INFO - 2019-07-03 23:57:42 --> Helper loaded: form_helper
INFO - 2019-07-03 23:57:42 --> Form Validation Class Initialized
DEBUG - 2019-07-03 23:57:42 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-03 23:57:42 --> Model Class Initialized
INFO - 2019-07-03 23:57:42 --> Model Class Initialized
INFO - 2019-07-03 23:57:42 --> Final output sent to browser
DEBUG - 2019-07-03 23:57:42 --> Total execution time: 0.5855
INFO - 2019-07-03 17:59:13 --> Config Class Initialized
INFO - 2019-07-03 17:59:13 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:59:13 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:59:13 --> Utf8 Class Initialized
INFO - 2019-07-03 17:59:13 --> URI Class Initialized
INFO - 2019-07-03 17:59:13 --> Router Class Initialized
INFO - 2019-07-03 17:59:13 --> Output Class Initialized
INFO - 2019-07-03 17:59:13 --> Security Class Initialized
DEBUG - 2019-07-03 17:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:59:13 --> Input Class Initialized
INFO - 2019-07-03 17:59:13 --> Language Class Initialized
INFO - 2019-07-03 17:59:13 --> Language Class Initialized
INFO - 2019-07-03 17:59:13 --> Config Class Initialized
INFO - 2019-07-03 17:59:13 --> Loader Class Initialized
DEBUG - 2019-07-03 17:59:13 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:59:13 --> Helper loaded: url_helper
INFO - 2019-07-03 17:59:13 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:59:13 --> Helper loaded: string_helper
INFO - 2019-07-03 17:59:13 --> Helper loaded: array_helper
INFO - 2019-07-03 17:59:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:59:13 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:59:13 --> Database Driver Class Initialized
INFO - 2019-07-03 17:59:13 --> Controller Class Initialized
INFO - 2019-07-03 23:59:13 --> Helper loaded: language_helper
INFO - 2019-07-03 23:59:13 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:59:13 --> Model Class Initialized
INFO - 2019-07-03 23:59:13 --> Model Class Initialized
INFO - 2019-07-03 23:59:13 --> Model Class Initialized
INFO - 2019-07-03 23:59:13 --> Model Class Initialized
INFO - 2019-07-03 23:59:13 --> Model Class Initialized
INFO - 2019-07-03 23:59:13 --> Final output sent to browser
DEBUG - 2019-07-03 23:59:13 --> Total execution time: 0.5480
INFO - 2019-07-03 17:59:13 --> Config Class Initialized
INFO - 2019-07-03 17:59:13 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:59:13 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:59:13 --> Utf8 Class Initialized
INFO - 2019-07-03 17:59:13 --> URI Class Initialized
INFO - 2019-07-03 17:59:13 --> Router Class Initialized
INFO - 2019-07-03 17:59:13 --> Output Class Initialized
INFO - 2019-07-03 17:59:13 --> Security Class Initialized
DEBUG - 2019-07-03 17:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:59:13 --> Input Class Initialized
INFO - 2019-07-03 17:59:13 --> Language Class Initialized
INFO - 2019-07-03 17:59:13 --> Language Class Initialized
INFO - 2019-07-03 17:59:13 --> Config Class Initialized
INFO - 2019-07-03 17:59:14 --> Loader Class Initialized
DEBUG - 2019-07-03 17:59:14 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:59:14 --> Helper loaded: url_helper
INFO - 2019-07-03 17:59:14 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:59:14 --> Helper loaded: string_helper
INFO - 2019-07-03 17:59:14 --> Helper loaded: array_helper
INFO - 2019-07-03 17:59:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:59:14 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:59:14 --> Database Driver Class Initialized
INFO - 2019-07-03 17:59:14 --> Controller Class Initialized
INFO - 2019-07-03 23:59:14 --> Helper loaded: language_helper
INFO - 2019-07-03 23:59:14 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:59:14 --> Model Class Initialized
INFO - 2019-07-03 23:59:14 --> Model Class Initialized
INFO - 2019-07-03 23:59:14 --> Model Class Initialized
INFO - 2019-07-03 23:59:14 --> Model Class Initialized
INFO - 2019-07-03 23:59:14 --> Helper loaded: form_helper
INFO - 2019-07-03 23:59:14 --> Form Validation Class Initialized
DEBUG - 2019-07-03 23:59:14 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-03 23:59:14 --> Model Class Initialized
INFO - 2019-07-03 23:59:14 --> Model Class Initialized
INFO - 2019-07-03 23:59:14 --> Final output sent to browser
DEBUG - 2019-07-03 23:59:14 --> Total execution time: 0.5978
INFO - 2019-07-03 17:59:15 --> Config Class Initialized
INFO - 2019-07-03 17:59:15 --> Hooks Class Initialized
DEBUG - 2019-07-03 17:59:15 --> UTF-8 Support Enabled
INFO - 2019-07-03 17:59:15 --> Utf8 Class Initialized
INFO - 2019-07-03 17:59:15 --> URI Class Initialized
INFO - 2019-07-03 17:59:15 --> Router Class Initialized
INFO - 2019-07-03 17:59:15 --> Output Class Initialized
INFO - 2019-07-03 17:59:15 --> Security Class Initialized
DEBUG - 2019-07-03 17:59:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 17:59:15 --> Input Class Initialized
INFO - 2019-07-03 17:59:15 --> Language Class Initialized
INFO - 2019-07-03 17:59:15 --> Language Class Initialized
INFO - 2019-07-03 17:59:15 --> Config Class Initialized
INFO - 2019-07-03 17:59:15 --> Loader Class Initialized
DEBUG - 2019-07-03 17:59:15 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 17:59:15 --> Helper loaded: url_helper
INFO - 2019-07-03 17:59:15 --> Helper loaded: inflector_helper
INFO - 2019-07-03 17:59:15 --> Helper loaded: string_helper
INFO - 2019-07-03 17:59:15 --> Helper loaded: array_helper
INFO - 2019-07-03 17:59:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 17:59:15 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 17:59:15 --> Database Driver Class Initialized
INFO - 2019-07-03 17:59:15 --> Controller Class Initialized
INFO - 2019-07-03 23:59:15 --> Helper loaded: language_helper
INFO - 2019-07-03 23:59:15 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-03 23:59:15 --> Model Class Initialized
INFO - 2019-07-03 23:59:15 --> Model Class Initialized
INFO - 2019-07-03 23:59:15 --> Model Class Initialized
INFO - 2019-07-03 23:59:15 --> Model Class Initialized
INFO - 2019-07-03 23:59:15 --> Helper loaded: form_helper
INFO - 2019-07-03 23:59:15 --> Form Validation Class Initialized
DEBUG - 2019-07-03 23:59:15 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-03 23:59:15 --> Model Class Initialized
INFO - 2019-07-03 23:59:15 --> Model Class Initialized
INFO - 2019-07-03 23:59:15 --> Final output sent to browser
DEBUG - 2019-07-03 23:59:15 --> Total execution time: 0.5881
INFO - 2019-07-03 18:02:23 --> Config Class Initialized
INFO - 2019-07-03 18:02:23 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:02:23 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:02:23 --> Utf8 Class Initialized
INFO - 2019-07-03 18:02:23 --> URI Class Initialized
INFO - 2019-07-03 18:02:23 --> Router Class Initialized
INFO - 2019-07-03 18:02:23 --> Output Class Initialized
INFO - 2019-07-03 18:02:23 --> Security Class Initialized
DEBUG - 2019-07-03 18:02:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:02:23 --> Input Class Initialized
INFO - 2019-07-03 18:02:23 --> Language Class Initialized
INFO - 2019-07-03 18:02:23 --> Language Class Initialized
INFO - 2019-07-03 18:02:23 --> Config Class Initialized
INFO - 2019-07-03 18:02:23 --> Loader Class Initialized
DEBUG - 2019-07-03 18:02:23 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:02:23 --> Helper loaded: url_helper
INFO - 2019-07-03 18:02:23 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:02:23 --> Helper loaded: string_helper
INFO - 2019-07-03 18:02:23 --> Helper loaded: array_helper
INFO - 2019-07-03 18:02:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:02:23 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:02:23 --> Database Driver Class Initialized
INFO - 2019-07-03 18:02:23 --> Controller Class Initialized
INFO - 2019-07-03 18:02:23 --> Config Class Initialized
INFO - 2019-07-03 18:02:23 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:02:23 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:02:23 --> Utf8 Class Initialized
INFO - 2019-07-03 18:02:23 --> URI Class Initialized
INFO - 2019-07-03 18:02:23 --> Router Class Initialized
INFO - 2019-07-03 18:02:23 --> Output Class Initialized
INFO - 2019-07-03 18:02:23 --> Security Class Initialized
DEBUG - 2019-07-03 18:02:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:02:23 --> Input Class Initialized
INFO - 2019-07-03 18:02:23 --> Language Class Initialized
INFO - 2019-07-03 18:02:23 --> Language Class Initialized
INFO - 2019-07-03 18:02:23 --> Config Class Initialized
INFO - 2019-07-03 18:02:23 --> Loader Class Initialized
DEBUG - 2019-07-03 18:02:23 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:02:23 --> Helper loaded: url_helper
INFO - 2019-07-03 18:02:23 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:02:23 --> Helper loaded: string_helper
INFO - 2019-07-03 18:02:23 --> Helper loaded: array_helper
INFO - 2019-07-03 18:02:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:02:23 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:02:23 --> Database Driver Class Initialized
INFO - 2019-07-03 18:02:23 --> Controller Class Initialized
INFO - 2019-07-03 18:02:24 --> Config Class Initialized
INFO - 2019-07-03 18:02:24 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:02:24 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:02:24 --> Utf8 Class Initialized
INFO - 2019-07-03 18:02:24 --> URI Class Initialized
INFO - 2019-07-03 18:02:24 --> Router Class Initialized
INFO - 2019-07-03 18:02:24 --> Output Class Initialized
INFO - 2019-07-03 18:02:24 --> Security Class Initialized
DEBUG - 2019-07-03 18:02:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:02:24 --> Input Class Initialized
INFO - 2019-07-03 18:02:24 --> Language Class Initialized
INFO - 2019-07-03 18:02:24 --> Language Class Initialized
INFO - 2019-07-03 18:02:24 --> Config Class Initialized
INFO - 2019-07-03 18:02:24 --> Loader Class Initialized
DEBUG - 2019-07-03 18:02:24 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:02:24 --> Helper loaded: url_helper
INFO - 2019-07-03 18:02:24 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:02:24 --> Helper loaded: string_helper
INFO - 2019-07-03 18:02:24 --> Helper loaded: array_helper
INFO - 2019-07-03 18:02:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:02:24 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:02:24 --> Database Driver Class Initialized
INFO - 2019-07-03 18:02:24 --> Controller Class Initialized
INFO - 2019-07-03 18:02:24 --> Config Class Initialized
INFO - 2019-07-03 18:02:24 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:02:24 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:02:24 --> Utf8 Class Initialized
INFO - 2019-07-03 18:02:24 --> URI Class Initialized
INFO - 2019-07-03 18:02:24 --> Router Class Initialized
INFO - 2019-07-03 18:02:24 --> Output Class Initialized
INFO - 2019-07-03 18:02:24 --> Security Class Initialized
DEBUG - 2019-07-03 18:02:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:02:24 --> Input Class Initialized
INFO - 2019-07-03 18:02:24 --> Language Class Initialized
INFO - 2019-07-03 18:02:24 --> Language Class Initialized
INFO - 2019-07-03 18:02:25 --> Config Class Initialized
INFO - 2019-07-03 18:02:25 --> Loader Class Initialized
DEBUG - 2019-07-03 18:02:25 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:02:25 --> Helper loaded: url_helper
INFO - 2019-07-03 18:02:25 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:02:25 --> Helper loaded: string_helper
INFO - 2019-07-03 18:02:25 --> Helper loaded: array_helper
INFO - 2019-07-03 18:02:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:02:25 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:02:25 --> Database Driver Class Initialized
INFO - 2019-07-03 18:02:25 --> Controller Class Initialized
INFO - 2019-07-03 18:02:32 --> Config Class Initialized
INFO - 2019-07-03 18:02:32 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:02:32 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:02:32 --> Utf8 Class Initialized
INFO - 2019-07-03 18:02:32 --> URI Class Initialized
INFO - 2019-07-03 18:02:32 --> Router Class Initialized
INFO - 2019-07-03 18:02:32 --> Output Class Initialized
INFO - 2019-07-03 18:02:32 --> Security Class Initialized
DEBUG - 2019-07-03 18:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:02:32 --> Input Class Initialized
INFO - 2019-07-03 18:02:32 --> Language Class Initialized
INFO - 2019-07-03 18:02:32 --> Language Class Initialized
INFO - 2019-07-03 18:02:32 --> Config Class Initialized
INFO - 2019-07-03 18:02:32 --> Loader Class Initialized
DEBUG - 2019-07-03 18:02:32 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:02:32 --> Helper loaded: url_helper
INFO - 2019-07-03 18:02:32 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:02:32 --> Helper loaded: string_helper
INFO - 2019-07-03 18:02:32 --> Helper loaded: array_helper
INFO - 2019-07-03 18:02:32 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:02:32 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:02:32 --> Database Driver Class Initialized
INFO - 2019-07-03 18:02:32 --> Controller Class Initialized
INFO - 2019-07-03 18:04:06 --> Config Class Initialized
INFO - 2019-07-03 18:04:06 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:04:06 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:04:06 --> Utf8 Class Initialized
INFO - 2019-07-03 18:04:06 --> URI Class Initialized
INFO - 2019-07-03 18:04:06 --> Router Class Initialized
INFO - 2019-07-03 18:04:06 --> Output Class Initialized
INFO - 2019-07-03 18:04:06 --> Security Class Initialized
DEBUG - 2019-07-03 18:04:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:04:06 --> Input Class Initialized
INFO - 2019-07-03 18:04:06 --> Language Class Initialized
INFO - 2019-07-03 18:04:06 --> Language Class Initialized
INFO - 2019-07-03 18:04:06 --> Config Class Initialized
INFO - 2019-07-03 18:04:06 --> Loader Class Initialized
DEBUG - 2019-07-03 18:04:06 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:04:06 --> Helper loaded: url_helper
INFO - 2019-07-03 18:04:06 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:04:06 --> Helper loaded: string_helper
INFO - 2019-07-03 18:04:06 --> Helper loaded: array_helper
INFO - 2019-07-03 18:04:06 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:04:06 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:04:06 --> Database Driver Class Initialized
INFO - 2019-07-03 18:04:06 --> Controller Class Initialized
INFO - 2019-07-03 18:04:07 --> Config Class Initialized
INFO - 2019-07-03 18:04:07 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:04:07 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:04:07 --> Utf8 Class Initialized
INFO - 2019-07-03 18:04:07 --> URI Class Initialized
INFO - 2019-07-03 18:04:07 --> Router Class Initialized
INFO - 2019-07-03 18:04:07 --> Output Class Initialized
INFO - 2019-07-03 18:04:07 --> Security Class Initialized
DEBUG - 2019-07-03 18:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:04:07 --> Input Class Initialized
INFO - 2019-07-03 18:04:07 --> Language Class Initialized
INFO - 2019-07-03 18:04:07 --> Language Class Initialized
INFO - 2019-07-03 18:04:07 --> Config Class Initialized
INFO - 2019-07-03 18:04:07 --> Loader Class Initialized
DEBUG - 2019-07-03 18:04:07 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:04:07 --> Helper loaded: url_helper
INFO - 2019-07-03 18:04:07 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:04:07 --> Helper loaded: string_helper
INFO - 2019-07-03 18:04:07 --> Helper loaded: array_helper
INFO - 2019-07-03 18:04:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:04:07 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:04:07 --> Database Driver Class Initialized
INFO - 2019-07-03 18:04:07 --> Controller Class Initialized
INFO - 2019-07-03 18:04:14 --> Config Class Initialized
INFO - 2019-07-03 18:04:14 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:04:14 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:04:14 --> Utf8 Class Initialized
INFO - 2019-07-03 18:04:14 --> URI Class Initialized
INFO - 2019-07-03 18:04:14 --> Router Class Initialized
INFO - 2019-07-03 18:04:14 --> Output Class Initialized
INFO - 2019-07-03 18:04:14 --> Security Class Initialized
DEBUG - 2019-07-03 18:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:04:14 --> Input Class Initialized
INFO - 2019-07-03 18:04:14 --> Language Class Initialized
INFO - 2019-07-03 18:04:14 --> Language Class Initialized
INFO - 2019-07-03 18:04:14 --> Config Class Initialized
INFO - 2019-07-03 18:04:14 --> Loader Class Initialized
DEBUG - 2019-07-03 18:04:14 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:04:14 --> Helper loaded: url_helper
INFO - 2019-07-03 18:04:14 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:04:14 --> Helper loaded: string_helper
INFO - 2019-07-03 18:04:14 --> Helper loaded: array_helper
INFO - 2019-07-03 18:04:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:04:14 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:04:14 --> Database Driver Class Initialized
INFO - 2019-07-03 18:04:14 --> Controller Class Initialized
INFO - 2019-07-03 18:04:27 --> Config Class Initialized
INFO - 2019-07-03 18:04:27 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:04:27 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:04:27 --> Utf8 Class Initialized
INFO - 2019-07-03 18:04:27 --> URI Class Initialized
INFO - 2019-07-03 18:04:27 --> Router Class Initialized
INFO - 2019-07-03 18:04:27 --> Output Class Initialized
INFO - 2019-07-03 18:04:27 --> Security Class Initialized
DEBUG - 2019-07-03 18:04:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:04:27 --> Input Class Initialized
INFO - 2019-07-03 18:04:27 --> Language Class Initialized
INFO - 2019-07-03 18:04:27 --> Language Class Initialized
INFO - 2019-07-03 18:04:27 --> Config Class Initialized
INFO - 2019-07-03 18:04:27 --> Loader Class Initialized
DEBUG - 2019-07-03 18:04:27 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:04:27 --> Helper loaded: url_helper
INFO - 2019-07-03 18:04:27 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:04:27 --> Helper loaded: string_helper
INFO - 2019-07-03 18:04:27 --> Helper loaded: array_helper
INFO - 2019-07-03 18:04:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:04:27 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:04:27 --> Database Driver Class Initialized
INFO - 2019-07-03 18:04:27 --> Controller Class Initialized
INFO - 2019-07-03 18:04:28 --> Config Class Initialized
INFO - 2019-07-03 18:04:28 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:04:28 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:04:28 --> Utf8 Class Initialized
INFO - 2019-07-03 18:04:28 --> URI Class Initialized
INFO - 2019-07-03 18:04:28 --> Router Class Initialized
INFO - 2019-07-03 18:04:28 --> Output Class Initialized
INFO - 2019-07-03 18:04:28 --> Security Class Initialized
DEBUG - 2019-07-03 18:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:04:28 --> Input Class Initialized
INFO - 2019-07-03 18:04:28 --> Language Class Initialized
INFO - 2019-07-03 18:04:28 --> Language Class Initialized
INFO - 2019-07-03 18:04:28 --> Config Class Initialized
INFO - 2019-07-03 18:04:28 --> Loader Class Initialized
DEBUG - 2019-07-03 18:04:28 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:04:28 --> Helper loaded: url_helper
INFO - 2019-07-03 18:04:28 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:04:28 --> Helper loaded: string_helper
INFO - 2019-07-03 18:04:28 --> Helper loaded: array_helper
INFO - 2019-07-03 18:04:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:04:28 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:04:28 --> Database Driver Class Initialized
INFO - 2019-07-03 18:04:28 --> Controller Class Initialized
INFO - 2019-07-03 18:04:30 --> Config Class Initialized
INFO - 2019-07-03 18:04:30 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:04:30 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:04:30 --> Utf8 Class Initialized
INFO - 2019-07-03 18:04:30 --> URI Class Initialized
INFO - 2019-07-03 18:04:30 --> Router Class Initialized
INFO - 2019-07-03 18:04:30 --> Output Class Initialized
INFO - 2019-07-03 18:04:30 --> Security Class Initialized
DEBUG - 2019-07-03 18:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:04:30 --> Input Class Initialized
INFO - 2019-07-03 18:04:30 --> Language Class Initialized
INFO - 2019-07-03 18:04:30 --> Language Class Initialized
INFO - 2019-07-03 18:04:30 --> Config Class Initialized
INFO - 2019-07-03 18:04:30 --> Loader Class Initialized
DEBUG - 2019-07-03 18:04:30 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:04:30 --> Helper loaded: url_helper
INFO - 2019-07-03 18:04:30 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:04:30 --> Helper loaded: string_helper
INFO - 2019-07-03 18:04:30 --> Helper loaded: array_helper
INFO - 2019-07-03 18:04:30 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:04:30 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:04:30 --> Database Driver Class Initialized
INFO - 2019-07-03 18:04:30 --> Controller Class Initialized
INFO - 2019-07-03 18:04:57 --> Config Class Initialized
INFO - 2019-07-03 18:04:57 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:04:57 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:04:57 --> Utf8 Class Initialized
INFO - 2019-07-03 18:04:57 --> URI Class Initialized
INFO - 2019-07-03 18:04:57 --> Router Class Initialized
INFO - 2019-07-03 18:04:57 --> Output Class Initialized
INFO - 2019-07-03 18:04:57 --> Security Class Initialized
DEBUG - 2019-07-03 18:04:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:04:57 --> Input Class Initialized
INFO - 2019-07-03 18:04:57 --> Language Class Initialized
INFO - 2019-07-03 18:04:57 --> Language Class Initialized
INFO - 2019-07-03 18:04:57 --> Config Class Initialized
INFO - 2019-07-03 18:04:57 --> Loader Class Initialized
DEBUG - 2019-07-03 18:04:57 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:04:57 --> Helper loaded: url_helper
INFO - 2019-07-03 18:04:57 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:04:57 --> Helper loaded: string_helper
INFO - 2019-07-03 18:04:57 --> Helper loaded: array_helper
INFO - 2019-07-03 18:04:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:04:58 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:04:58 --> Database Driver Class Initialized
INFO - 2019-07-03 18:04:58 --> Controller Class Initialized
INFO - 2019-07-03 18:04:58 --> Config Class Initialized
INFO - 2019-07-03 18:04:58 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:04:58 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:04:58 --> Utf8 Class Initialized
INFO - 2019-07-03 18:04:58 --> URI Class Initialized
INFO - 2019-07-03 18:04:58 --> Router Class Initialized
INFO - 2019-07-03 18:04:58 --> Output Class Initialized
INFO - 2019-07-03 18:04:58 --> Security Class Initialized
DEBUG - 2019-07-03 18:04:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:04:58 --> Input Class Initialized
INFO - 2019-07-03 18:04:58 --> Language Class Initialized
INFO - 2019-07-03 18:04:58 --> Language Class Initialized
INFO - 2019-07-03 18:04:58 --> Config Class Initialized
INFO - 2019-07-03 18:04:58 --> Loader Class Initialized
DEBUG - 2019-07-03 18:04:58 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:04:58 --> Helper loaded: url_helper
INFO - 2019-07-03 18:04:58 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:04:58 --> Helper loaded: string_helper
INFO - 2019-07-03 18:04:58 --> Helper loaded: array_helper
INFO - 2019-07-03 18:04:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:04:58 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:04:58 --> Database Driver Class Initialized
INFO - 2019-07-03 18:04:58 --> Controller Class Initialized
INFO - 2019-07-03 18:04:59 --> Config Class Initialized
INFO - 2019-07-03 18:04:59 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:04:59 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:04:59 --> Utf8 Class Initialized
INFO - 2019-07-03 18:04:59 --> URI Class Initialized
INFO - 2019-07-03 18:04:59 --> Router Class Initialized
INFO - 2019-07-03 18:04:59 --> Output Class Initialized
INFO - 2019-07-03 18:04:59 --> Security Class Initialized
DEBUG - 2019-07-03 18:04:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:04:59 --> Input Class Initialized
INFO - 2019-07-03 18:04:59 --> Language Class Initialized
INFO - 2019-07-03 18:04:59 --> Language Class Initialized
INFO - 2019-07-03 18:04:59 --> Config Class Initialized
INFO - 2019-07-03 18:04:59 --> Loader Class Initialized
DEBUG - 2019-07-03 18:04:59 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:04:59 --> Helper loaded: url_helper
INFO - 2019-07-03 18:04:59 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:04:59 --> Helper loaded: string_helper
INFO - 2019-07-03 18:04:59 --> Helper loaded: array_helper
INFO - 2019-07-03 18:04:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:04:59 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:04:59 --> Database Driver Class Initialized
INFO - 2019-07-03 18:04:59 --> Controller Class Initialized
INFO - 2019-07-03 18:05:42 --> Config Class Initialized
INFO - 2019-07-03 18:05:42 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:05:42 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:05:42 --> Utf8 Class Initialized
INFO - 2019-07-03 18:05:42 --> URI Class Initialized
INFO - 2019-07-03 18:05:42 --> Router Class Initialized
INFO - 2019-07-03 18:05:42 --> Output Class Initialized
INFO - 2019-07-03 18:05:42 --> Security Class Initialized
DEBUG - 2019-07-03 18:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:05:42 --> Input Class Initialized
INFO - 2019-07-03 18:05:42 --> Language Class Initialized
INFO - 2019-07-03 18:05:43 --> Language Class Initialized
INFO - 2019-07-03 18:05:43 --> Config Class Initialized
INFO - 2019-07-03 18:05:43 --> Loader Class Initialized
DEBUG - 2019-07-03 18:05:43 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:05:43 --> Helper loaded: url_helper
INFO - 2019-07-03 18:05:43 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:05:43 --> Helper loaded: string_helper
INFO - 2019-07-03 18:05:43 --> Helper loaded: array_helper
INFO - 2019-07-03 18:05:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:05:43 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:05:43 --> Database Driver Class Initialized
INFO - 2019-07-03 18:05:43 --> Controller Class Initialized
INFO - 2019-07-03 18:05:43 --> Config Class Initialized
INFO - 2019-07-03 18:05:43 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:05:43 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:05:43 --> Utf8 Class Initialized
INFO - 2019-07-03 18:05:43 --> URI Class Initialized
INFO - 2019-07-03 18:05:43 --> Router Class Initialized
INFO - 2019-07-03 18:05:43 --> Output Class Initialized
INFO - 2019-07-03 18:05:43 --> Security Class Initialized
DEBUG - 2019-07-03 18:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:05:43 --> Input Class Initialized
INFO - 2019-07-03 18:05:43 --> Language Class Initialized
INFO - 2019-07-03 18:05:43 --> Language Class Initialized
INFO - 2019-07-03 18:05:43 --> Config Class Initialized
INFO - 2019-07-03 18:05:43 --> Loader Class Initialized
DEBUG - 2019-07-03 18:05:43 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:05:43 --> Helper loaded: url_helper
INFO - 2019-07-03 18:05:43 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:05:43 --> Helper loaded: string_helper
INFO - 2019-07-03 18:05:43 --> Helper loaded: array_helper
INFO - 2019-07-03 18:05:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:05:43 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:05:43 --> Database Driver Class Initialized
INFO - 2019-07-03 18:05:43 --> Controller Class Initialized
INFO - 2019-07-03 18:05:44 --> Config Class Initialized
INFO - 2019-07-03 18:05:44 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:05:44 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:05:44 --> Utf8 Class Initialized
INFO - 2019-07-03 18:05:44 --> URI Class Initialized
INFO - 2019-07-03 18:05:44 --> Router Class Initialized
INFO - 2019-07-03 18:05:44 --> Output Class Initialized
INFO - 2019-07-03 18:05:44 --> Security Class Initialized
DEBUG - 2019-07-03 18:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:05:44 --> Input Class Initialized
INFO - 2019-07-03 18:05:44 --> Language Class Initialized
INFO - 2019-07-03 18:05:44 --> Language Class Initialized
INFO - 2019-07-03 18:05:44 --> Config Class Initialized
INFO - 2019-07-03 18:05:44 --> Loader Class Initialized
DEBUG - 2019-07-03 18:05:44 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:05:44 --> Helper loaded: url_helper
INFO - 2019-07-03 18:05:44 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:05:44 --> Helper loaded: string_helper
INFO - 2019-07-03 18:05:44 --> Helper loaded: array_helper
INFO - 2019-07-03 18:05:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:05:44 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:05:44 --> Database Driver Class Initialized
INFO - 2019-07-03 18:05:44 --> Controller Class Initialized
INFO - 2019-07-03 18:06:00 --> Config Class Initialized
INFO - 2019-07-03 18:06:00 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:06:00 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:06:01 --> Utf8 Class Initialized
INFO - 2019-07-03 18:06:01 --> URI Class Initialized
INFO - 2019-07-03 18:06:01 --> Router Class Initialized
INFO - 2019-07-03 18:06:01 --> Output Class Initialized
INFO - 2019-07-03 18:06:01 --> Security Class Initialized
DEBUG - 2019-07-03 18:06:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:06:01 --> Input Class Initialized
INFO - 2019-07-03 18:06:01 --> Language Class Initialized
INFO - 2019-07-03 18:06:01 --> Language Class Initialized
INFO - 2019-07-03 18:06:01 --> Config Class Initialized
INFO - 2019-07-03 18:06:01 --> Loader Class Initialized
DEBUG - 2019-07-03 18:06:01 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:06:01 --> Helper loaded: url_helper
INFO - 2019-07-03 18:06:01 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:06:01 --> Helper loaded: string_helper
INFO - 2019-07-03 18:06:01 --> Helper loaded: array_helper
INFO - 2019-07-03 18:06:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:06:01 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:06:01 --> Database Driver Class Initialized
INFO - 2019-07-03 18:06:01 --> Controller Class Initialized
INFO - 2019-07-03 18:06:01 --> Config Class Initialized
INFO - 2019-07-03 18:06:01 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:06:01 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:06:01 --> Utf8 Class Initialized
INFO - 2019-07-03 18:06:01 --> URI Class Initialized
INFO - 2019-07-03 18:06:01 --> Router Class Initialized
INFO - 2019-07-03 18:06:01 --> Output Class Initialized
INFO - 2019-07-03 18:06:01 --> Security Class Initialized
DEBUG - 2019-07-03 18:06:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:06:01 --> Input Class Initialized
INFO - 2019-07-03 18:06:01 --> Language Class Initialized
INFO - 2019-07-03 18:06:01 --> Language Class Initialized
INFO - 2019-07-03 18:06:01 --> Config Class Initialized
INFO - 2019-07-03 18:06:01 --> Loader Class Initialized
DEBUG - 2019-07-03 18:06:01 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:06:01 --> Helper loaded: url_helper
INFO - 2019-07-03 18:06:01 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:06:01 --> Helper loaded: string_helper
INFO - 2019-07-03 18:06:01 --> Helper loaded: array_helper
INFO - 2019-07-03 18:06:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:06:01 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:06:01 --> Database Driver Class Initialized
INFO - 2019-07-03 18:06:01 --> Controller Class Initialized
INFO - 2019-07-03 18:06:13 --> Config Class Initialized
INFO - 2019-07-03 18:06:13 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:06:13 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:06:13 --> Utf8 Class Initialized
INFO - 2019-07-03 18:06:13 --> URI Class Initialized
INFO - 2019-07-03 18:06:13 --> Router Class Initialized
INFO - 2019-07-03 18:06:13 --> Output Class Initialized
INFO - 2019-07-03 18:06:13 --> Security Class Initialized
DEBUG - 2019-07-03 18:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:06:13 --> Input Class Initialized
INFO - 2019-07-03 18:06:13 --> Language Class Initialized
INFO - 2019-07-03 18:06:13 --> Language Class Initialized
INFO - 2019-07-03 18:06:13 --> Config Class Initialized
INFO - 2019-07-03 18:06:13 --> Loader Class Initialized
DEBUG - 2019-07-03 18:06:13 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:06:13 --> Helper loaded: url_helper
INFO - 2019-07-03 18:06:13 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:06:13 --> Helper loaded: string_helper
INFO - 2019-07-03 18:06:13 --> Helper loaded: array_helper
INFO - 2019-07-03 18:06:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:06:13 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:06:13 --> Database Driver Class Initialized
INFO - 2019-07-03 18:06:13 --> Controller Class Initialized
INFO - 2019-07-03 18:06:13 --> Config Class Initialized
INFO - 2019-07-03 18:06:13 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:06:13 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:06:13 --> Utf8 Class Initialized
INFO - 2019-07-03 18:06:13 --> URI Class Initialized
INFO - 2019-07-03 18:06:13 --> Router Class Initialized
INFO - 2019-07-03 18:06:13 --> Output Class Initialized
INFO - 2019-07-03 18:06:13 --> Security Class Initialized
DEBUG - 2019-07-03 18:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:06:13 --> Input Class Initialized
INFO - 2019-07-03 18:06:13 --> Language Class Initialized
INFO - 2019-07-03 18:06:13 --> Language Class Initialized
INFO - 2019-07-03 18:06:13 --> Config Class Initialized
INFO - 2019-07-03 18:06:13 --> Loader Class Initialized
DEBUG - 2019-07-03 18:06:13 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:06:13 --> Helper loaded: url_helper
INFO - 2019-07-03 18:06:13 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:06:13 --> Helper loaded: string_helper
INFO - 2019-07-03 18:06:13 --> Helper loaded: array_helper
INFO - 2019-07-03 18:06:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:06:13 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:06:13 --> Database Driver Class Initialized
INFO - 2019-07-03 18:06:13 --> Controller Class Initialized
INFO - 2019-07-03 18:06:22 --> Config Class Initialized
INFO - 2019-07-03 18:06:22 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:06:22 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:06:22 --> Utf8 Class Initialized
INFO - 2019-07-03 18:06:22 --> URI Class Initialized
INFO - 2019-07-03 18:06:22 --> Router Class Initialized
INFO - 2019-07-03 18:06:22 --> Output Class Initialized
INFO - 2019-07-03 18:06:22 --> Security Class Initialized
DEBUG - 2019-07-03 18:06:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:06:22 --> Input Class Initialized
INFO - 2019-07-03 18:06:22 --> Language Class Initialized
INFO - 2019-07-03 18:06:22 --> Language Class Initialized
INFO - 2019-07-03 18:06:22 --> Config Class Initialized
INFO - 2019-07-03 18:06:22 --> Loader Class Initialized
DEBUG - 2019-07-03 18:06:22 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:06:22 --> Helper loaded: url_helper
INFO - 2019-07-03 18:06:22 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:06:22 --> Helper loaded: string_helper
INFO - 2019-07-03 18:06:22 --> Helper loaded: array_helper
INFO - 2019-07-03 18:06:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:06:22 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:06:22 --> Database Driver Class Initialized
INFO - 2019-07-03 18:06:22 --> Controller Class Initialized
INFO - 2019-07-03 18:06:22 --> Config Class Initialized
INFO - 2019-07-03 18:06:22 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:06:22 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:06:22 --> Utf8 Class Initialized
INFO - 2019-07-03 18:06:22 --> URI Class Initialized
INFO - 2019-07-03 18:06:22 --> Router Class Initialized
INFO - 2019-07-03 18:06:22 --> Output Class Initialized
INFO - 2019-07-03 18:06:22 --> Security Class Initialized
DEBUG - 2019-07-03 18:06:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:06:22 --> Input Class Initialized
INFO - 2019-07-03 18:06:22 --> Language Class Initialized
INFO - 2019-07-03 18:06:22 --> Language Class Initialized
INFO - 2019-07-03 18:06:22 --> Config Class Initialized
INFO - 2019-07-03 18:06:22 --> Loader Class Initialized
DEBUG - 2019-07-03 18:06:23 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:06:23 --> Helper loaded: url_helper
INFO - 2019-07-03 18:06:23 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:06:23 --> Helper loaded: string_helper
INFO - 2019-07-03 18:06:23 --> Helper loaded: array_helper
INFO - 2019-07-03 18:06:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:06:23 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:06:23 --> Database Driver Class Initialized
INFO - 2019-07-03 18:06:23 --> Controller Class Initialized
INFO - 2019-07-03 18:06:24 --> Config Class Initialized
INFO - 2019-07-03 18:06:24 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:06:24 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:06:24 --> Utf8 Class Initialized
INFO - 2019-07-03 18:06:24 --> URI Class Initialized
INFO - 2019-07-03 18:06:24 --> Router Class Initialized
INFO - 2019-07-03 18:06:24 --> Output Class Initialized
INFO - 2019-07-03 18:06:24 --> Security Class Initialized
DEBUG - 2019-07-03 18:06:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:06:24 --> Input Class Initialized
INFO - 2019-07-03 18:06:24 --> Language Class Initialized
INFO - 2019-07-03 18:06:24 --> Language Class Initialized
INFO - 2019-07-03 18:06:24 --> Config Class Initialized
INFO - 2019-07-03 18:06:24 --> Loader Class Initialized
DEBUG - 2019-07-03 18:06:24 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:06:24 --> Helper loaded: url_helper
INFO - 2019-07-03 18:06:24 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:06:24 --> Helper loaded: string_helper
INFO - 2019-07-03 18:06:24 --> Helper loaded: array_helper
INFO - 2019-07-03 18:06:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:06:24 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:06:24 --> Database Driver Class Initialized
INFO - 2019-07-03 18:06:24 --> Controller Class Initialized
INFO - 2019-07-03 18:19:48 --> Config Class Initialized
INFO - 2019-07-03 18:19:48 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:19:48 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:19:48 --> Utf8 Class Initialized
INFO - 2019-07-03 18:19:48 --> URI Class Initialized
INFO - 2019-07-03 18:19:48 --> Router Class Initialized
INFO - 2019-07-03 18:19:48 --> Output Class Initialized
INFO - 2019-07-03 18:19:48 --> Security Class Initialized
DEBUG - 2019-07-03 18:19:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:19:48 --> Input Class Initialized
INFO - 2019-07-03 18:19:48 --> Language Class Initialized
INFO - 2019-07-03 18:19:48 --> Language Class Initialized
INFO - 2019-07-03 18:19:48 --> Config Class Initialized
INFO - 2019-07-03 18:19:48 --> Loader Class Initialized
DEBUG - 2019-07-03 18:19:48 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:19:48 --> Helper loaded: url_helper
INFO - 2019-07-03 18:19:48 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:19:48 --> Helper loaded: string_helper
INFO - 2019-07-03 18:19:48 --> Helper loaded: array_helper
INFO - 2019-07-03 18:19:48 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:19:48 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:19:48 --> Database Driver Class Initialized
INFO - 2019-07-03 18:19:48 --> Controller Class Initialized
INFO - 2019-07-03 18:19:49 --> Config Class Initialized
INFO - 2019-07-03 18:19:49 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:19:49 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:19:49 --> Utf8 Class Initialized
INFO - 2019-07-03 18:19:49 --> URI Class Initialized
INFO - 2019-07-03 18:19:49 --> Router Class Initialized
INFO - 2019-07-03 18:19:49 --> Output Class Initialized
INFO - 2019-07-03 18:19:49 --> Security Class Initialized
DEBUG - 2019-07-03 18:19:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:19:49 --> Input Class Initialized
INFO - 2019-07-03 18:19:49 --> Language Class Initialized
INFO - 2019-07-03 18:19:49 --> Language Class Initialized
INFO - 2019-07-03 18:19:49 --> Config Class Initialized
INFO - 2019-07-03 18:19:49 --> Loader Class Initialized
DEBUG - 2019-07-03 18:19:49 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:19:49 --> Helper loaded: url_helper
INFO - 2019-07-03 18:19:49 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:19:49 --> Helper loaded: string_helper
INFO - 2019-07-03 18:19:49 --> Helper loaded: array_helper
INFO - 2019-07-03 18:19:49 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:19:49 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:19:49 --> Database Driver Class Initialized
INFO - 2019-07-03 18:19:49 --> Controller Class Initialized
INFO - 2019-07-03 18:19:55 --> Config Class Initialized
INFO - 2019-07-03 18:19:55 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:19:55 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:19:55 --> Utf8 Class Initialized
INFO - 2019-07-03 18:19:55 --> URI Class Initialized
INFO - 2019-07-03 18:19:55 --> Router Class Initialized
INFO - 2019-07-03 18:19:55 --> Output Class Initialized
INFO - 2019-07-03 18:19:55 --> Security Class Initialized
DEBUG - 2019-07-03 18:19:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:19:55 --> Input Class Initialized
INFO - 2019-07-03 18:19:55 --> Language Class Initialized
INFO - 2019-07-03 18:19:55 --> Language Class Initialized
INFO - 2019-07-03 18:19:55 --> Config Class Initialized
INFO - 2019-07-03 18:19:55 --> Loader Class Initialized
DEBUG - 2019-07-03 18:19:55 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:19:55 --> Helper loaded: url_helper
INFO - 2019-07-03 18:19:55 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:19:55 --> Helper loaded: string_helper
INFO - 2019-07-03 18:19:55 --> Helper loaded: array_helper
INFO - 2019-07-03 18:19:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:19:55 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:19:55 --> Database Driver Class Initialized
INFO - 2019-07-03 18:19:55 --> Controller Class Initialized
INFO - 2019-07-03 18:19:56 --> Config Class Initialized
INFO - 2019-07-03 18:19:56 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:19:56 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:19:56 --> Utf8 Class Initialized
INFO - 2019-07-03 18:19:56 --> URI Class Initialized
INFO - 2019-07-03 18:19:56 --> Router Class Initialized
INFO - 2019-07-03 18:19:56 --> Output Class Initialized
INFO - 2019-07-03 18:19:56 --> Security Class Initialized
DEBUG - 2019-07-03 18:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:19:56 --> Input Class Initialized
INFO - 2019-07-03 18:19:56 --> Language Class Initialized
INFO - 2019-07-03 18:19:56 --> Language Class Initialized
INFO - 2019-07-03 18:19:56 --> Config Class Initialized
INFO - 2019-07-03 18:19:56 --> Loader Class Initialized
DEBUG - 2019-07-03 18:19:56 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:19:56 --> Helper loaded: url_helper
INFO - 2019-07-03 18:19:56 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:19:56 --> Helper loaded: string_helper
INFO - 2019-07-03 18:19:56 --> Helper loaded: array_helper
INFO - 2019-07-03 18:19:56 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:19:56 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:19:56 --> Database Driver Class Initialized
INFO - 2019-07-03 18:19:56 --> Controller Class Initialized
INFO - 2019-07-03 18:21:08 --> Config Class Initialized
INFO - 2019-07-03 18:21:08 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:21:08 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:21:08 --> Utf8 Class Initialized
INFO - 2019-07-03 18:21:08 --> URI Class Initialized
INFO - 2019-07-03 18:21:08 --> Router Class Initialized
INFO - 2019-07-03 18:21:08 --> Output Class Initialized
INFO - 2019-07-03 18:21:08 --> Security Class Initialized
DEBUG - 2019-07-03 18:21:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:21:08 --> Input Class Initialized
INFO - 2019-07-03 18:21:08 --> Language Class Initialized
INFO - 2019-07-03 18:21:08 --> Language Class Initialized
INFO - 2019-07-03 18:21:08 --> Config Class Initialized
INFO - 2019-07-03 18:21:08 --> Loader Class Initialized
DEBUG - 2019-07-03 18:21:08 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:21:08 --> Helper loaded: url_helper
INFO - 2019-07-03 18:21:08 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:21:08 --> Helper loaded: string_helper
INFO - 2019-07-03 18:21:08 --> Helper loaded: array_helper
INFO - 2019-07-03 18:21:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:21:08 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:21:08 --> Database Driver Class Initialized
INFO - 2019-07-03 18:21:08 --> Controller Class Initialized
INFO - 2019-07-03 18:21:09 --> Config Class Initialized
INFO - 2019-07-03 18:21:09 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:21:09 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:21:09 --> Utf8 Class Initialized
INFO - 2019-07-03 18:21:09 --> URI Class Initialized
INFO - 2019-07-03 18:21:09 --> Router Class Initialized
INFO - 2019-07-03 18:21:09 --> Output Class Initialized
INFO - 2019-07-03 18:21:09 --> Security Class Initialized
DEBUG - 2019-07-03 18:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:21:09 --> Input Class Initialized
INFO - 2019-07-03 18:21:09 --> Language Class Initialized
INFO - 2019-07-03 18:21:09 --> Language Class Initialized
INFO - 2019-07-03 18:21:09 --> Config Class Initialized
INFO - 2019-07-03 18:21:09 --> Loader Class Initialized
DEBUG - 2019-07-03 18:21:09 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:21:09 --> Helper loaded: url_helper
INFO - 2019-07-03 18:21:09 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:21:09 --> Helper loaded: string_helper
INFO - 2019-07-03 18:21:09 --> Helper loaded: array_helper
INFO - 2019-07-03 18:21:09 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:21:09 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:21:09 --> Database Driver Class Initialized
INFO - 2019-07-03 18:21:09 --> Controller Class Initialized
INFO - 2019-07-03 18:21:15 --> Config Class Initialized
INFO - 2019-07-03 18:21:15 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:21:15 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:21:15 --> Utf8 Class Initialized
INFO - 2019-07-03 18:21:15 --> URI Class Initialized
INFO - 2019-07-03 18:21:15 --> Router Class Initialized
INFO - 2019-07-03 18:21:15 --> Output Class Initialized
INFO - 2019-07-03 18:21:15 --> Security Class Initialized
DEBUG - 2019-07-03 18:21:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:21:15 --> Input Class Initialized
INFO - 2019-07-03 18:21:15 --> Language Class Initialized
INFO - 2019-07-03 18:21:15 --> Language Class Initialized
INFO - 2019-07-03 18:21:15 --> Config Class Initialized
INFO - 2019-07-03 18:21:15 --> Loader Class Initialized
DEBUG - 2019-07-03 18:21:15 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:21:15 --> Helper loaded: url_helper
INFO - 2019-07-03 18:21:15 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:21:15 --> Helper loaded: string_helper
INFO - 2019-07-03 18:21:15 --> Helper loaded: array_helper
INFO - 2019-07-03 18:21:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:21:15 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:21:15 --> Database Driver Class Initialized
INFO - 2019-07-03 18:21:15 --> Controller Class Initialized
INFO - 2019-07-03 18:21:16 --> Config Class Initialized
INFO - 2019-07-03 18:21:16 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:21:16 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:21:16 --> Utf8 Class Initialized
INFO - 2019-07-03 18:21:16 --> URI Class Initialized
INFO - 2019-07-03 18:21:16 --> Router Class Initialized
INFO - 2019-07-03 18:21:16 --> Output Class Initialized
INFO - 2019-07-03 18:21:16 --> Security Class Initialized
DEBUG - 2019-07-03 18:21:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:21:16 --> Input Class Initialized
INFO - 2019-07-03 18:21:16 --> Language Class Initialized
INFO - 2019-07-03 18:21:16 --> Language Class Initialized
INFO - 2019-07-03 18:21:16 --> Config Class Initialized
INFO - 2019-07-03 18:21:16 --> Loader Class Initialized
DEBUG - 2019-07-03 18:21:16 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:21:16 --> Helper loaded: url_helper
INFO - 2019-07-03 18:21:16 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:21:16 --> Helper loaded: string_helper
INFO - 2019-07-03 18:21:16 --> Helper loaded: array_helper
INFO - 2019-07-03 18:21:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:21:16 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:21:16 --> Database Driver Class Initialized
INFO - 2019-07-03 18:21:16 --> Controller Class Initialized
INFO - 2019-07-03 18:21:37 --> Config Class Initialized
INFO - 2019-07-03 18:21:37 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:21:37 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:21:37 --> Utf8 Class Initialized
INFO - 2019-07-03 18:21:37 --> URI Class Initialized
INFO - 2019-07-03 18:21:37 --> Router Class Initialized
INFO - 2019-07-03 18:21:37 --> Output Class Initialized
INFO - 2019-07-03 18:21:37 --> Security Class Initialized
DEBUG - 2019-07-03 18:21:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:21:37 --> Input Class Initialized
INFO - 2019-07-03 18:21:37 --> Language Class Initialized
INFO - 2019-07-03 18:21:37 --> Language Class Initialized
INFO - 2019-07-03 18:21:37 --> Config Class Initialized
INFO - 2019-07-03 18:21:37 --> Loader Class Initialized
DEBUG - 2019-07-03 18:21:37 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:21:37 --> Helper loaded: url_helper
INFO - 2019-07-03 18:21:37 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:21:37 --> Helper loaded: string_helper
INFO - 2019-07-03 18:21:37 --> Helper loaded: array_helper
INFO - 2019-07-03 18:21:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:21:37 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:21:37 --> Database Driver Class Initialized
INFO - 2019-07-03 18:21:37 --> Controller Class Initialized
INFO - 2019-07-03 18:21:38 --> Config Class Initialized
INFO - 2019-07-03 18:21:38 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:21:38 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:21:38 --> Utf8 Class Initialized
INFO - 2019-07-03 18:21:38 --> URI Class Initialized
INFO - 2019-07-03 18:21:38 --> Router Class Initialized
INFO - 2019-07-03 18:21:38 --> Output Class Initialized
INFO - 2019-07-03 18:21:38 --> Security Class Initialized
DEBUG - 2019-07-03 18:21:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:21:38 --> Input Class Initialized
INFO - 2019-07-03 18:21:38 --> Language Class Initialized
INFO - 2019-07-03 18:21:38 --> Language Class Initialized
INFO - 2019-07-03 18:21:38 --> Config Class Initialized
INFO - 2019-07-03 18:21:38 --> Loader Class Initialized
DEBUG - 2019-07-03 18:21:38 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:21:38 --> Helper loaded: url_helper
INFO - 2019-07-03 18:21:38 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:21:38 --> Helper loaded: string_helper
INFO - 2019-07-03 18:21:38 --> Helper loaded: array_helper
INFO - 2019-07-03 18:21:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:21:38 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:21:38 --> Database Driver Class Initialized
INFO - 2019-07-03 18:21:38 --> Controller Class Initialized
INFO - 2019-07-03 18:23:23 --> Config Class Initialized
INFO - 2019-07-03 18:23:23 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:23:23 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:23:23 --> Utf8 Class Initialized
INFO - 2019-07-03 18:23:23 --> URI Class Initialized
INFO - 2019-07-03 18:23:23 --> Router Class Initialized
INFO - 2019-07-03 18:23:23 --> Output Class Initialized
INFO - 2019-07-03 18:23:23 --> Security Class Initialized
DEBUG - 2019-07-03 18:23:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:23:23 --> Input Class Initialized
INFO - 2019-07-03 18:23:23 --> Language Class Initialized
INFO - 2019-07-03 18:23:23 --> Language Class Initialized
INFO - 2019-07-03 18:23:23 --> Config Class Initialized
INFO - 2019-07-03 18:23:23 --> Loader Class Initialized
DEBUG - 2019-07-03 18:23:23 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:23:23 --> Helper loaded: url_helper
INFO - 2019-07-03 18:23:23 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:23:23 --> Helper loaded: string_helper
INFO - 2019-07-03 18:23:23 --> Helper loaded: array_helper
INFO - 2019-07-03 18:23:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:23:23 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:23:23 --> Database Driver Class Initialized
INFO - 2019-07-03 18:23:23 --> Controller Class Initialized
INFO - 2019-07-03 18:23:24 --> Config Class Initialized
INFO - 2019-07-03 18:23:24 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:23:24 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:23:24 --> Utf8 Class Initialized
INFO - 2019-07-03 18:23:24 --> URI Class Initialized
INFO - 2019-07-03 18:23:24 --> Router Class Initialized
INFO - 2019-07-03 18:23:24 --> Output Class Initialized
INFO - 2019-07-03 18:23:24 --> Security Class Initialized
DEBUG - 2019-07-03 18:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:23:24 --> Input Class Initialized
INFO - 2019-07-03 18:23:24 --> Language Class Initialized
INFO - 2019-07-03 18:23:24 --> Language Class Initialized
INFO - 2019-07-03 18:23:24 --> Config Class Initialized
INFO - 2019-07-03 18:23:24 --> Loader Class Initialized
DEBUG - 2019-07-03 18:23:24 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:23:24 --> Helper loaded: url_helper
INFO - 2019-07-03 18:23:24 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:23:24 --> Helper loaded: string_helper
INFO - 2019-07-03 18:23:24 --> Helper loaded: array_helper
INFO - 2019-07-03 18:23:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:23:24 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:23:24 --> Database Driver Class Initialized
INFO - 2019-07-03 18:23:24 --> Controller Class Initialized
INFO - 2019-07-03 18:23:53 --> Config Class Initialized
INFO - 2019-07-03 18:23:53 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:23:53 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:23:53 --> Utf8 Class Initialized
INFO - 2019-07-03 18:23:53 --> URI Class Initialized
INFO - 2019-07-03 18:23:53 --> Router Class Initialized
INFO - 2019-07-03 18:23:53 --> Output Class Initialized
INFO - 2019-07-03 18:23:53 --> Security Class Initialized
DEBUG - 2019-07-03 18:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:23:53 --> Input Class Initialized
INFO - 2019-07-03 18:23:53 --> Language Class Initialized
INFO - 2019-07-03 18:23:53 --> Language Class Initialized
INFO - 2019-07-03 18:23:53 --> Config Class Initialized
INFO - 2019-07-03 18:23:53 --> Loader Class Initialized
DEBUG - 2019-07-03 18:23:53 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:23:53 --> Helper loaded: url_helper
INFO - 2019-07-03 18:23:53 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:23:53 --> Helper loaded: string_helper
INFO - 2019-07-03 18:23:53 --> Helper loaded: array_helper
INFO - 2019-07-03 18:23:53 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:23:53 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:23:53 --> Database Driver Class Initialized
INFO - 2019-07-03 18:23:53 --> Controller Class Initialized
INFO - 2019-07-03 18:23:53 --> Config Class Initialized
INFO - 2019-07-03 18:23:53 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:23:53 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:23:53 --> Utf8 Class Initialized
INFO - 2019-07-03 18:23:53 --> URI Class Initialized
INFO - 2019-07-03 18:23:53 --> Router Class Initialized
INFO - 2019-07-03 18:23:53 --> Output Class Initialized
INFO - 2019-07-03 18:23:53 --> Security Class Initialized
DEBUG - 2019-07-03 18:23:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:23:53 --> Input Class Initialized
INFO - 2019-07-03 18:23:53 --> Language Class Initialized
INFO - 2019-07-03 18:23:53 --> Language Class Initialized
INFO - 2019-07-03 18:23:53 --> Config Class Initialized
INFO - 2019-07-03 18:23:53 --> Loader Class Initialized
DEBUG - 2019-07-03 18:23:53 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:23:53 --> Helper loaded: url_helper
INFO - 2019-07-03 18:23:53 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:23:53 --> Helper loaded: string_helper
INFO - 2019-07-03 18:23:53 --> Helper loaded: array_helper
INFO - 2019-07-03 18:23:53 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:23:53 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:23:53 --> Database Driver Class Initialized
INFO - 2019-07-03 18:23:53 --> Controller Class Initialized
INFO - 2019-07-03 18:23:54 --> Config Class Initialized
INFO - 2019-07-03 18:23:54 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:23:54 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:23:54 --> Utf8 Class Initialized
INFO - 2019-07-03 18:23:54 --> URI Class Initialized
INFO - 2019-07-03 18:23:54 --> Router Class Initialized
INFO - 2019-07-03 18:23:54 --> Output Class Initialized
INFO - 2019-07-03 18:23:54 --> Security Class Initialized
DEBUG - 2019-07-03 18:23:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:23:54 --> Input Class Initialized
INFO - 2019-07-03 18:23:54 --> Language Class Initialized
INFO - 2019-07-03 18:23:54 --> Language Class Initialized
INFO - 2019-07-03 18:23:54 --> Config Class Initialized
INFO - 2019-07-03 18:23:54 --> Loader Class Initialized
DEBUG - 2019-07-03 18:23:54 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:23:54 --> Helper loaded: url_helper
INFO - 2019-07-03 18:23:55 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:23:55 --> Helper loaded: string_helper
INFO - 2019-07-03 18:23:55 --> Helper loaded: array_helper
INFO - 2019-07-03 18:23:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:23:55 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:23:55 --> Database Driver Class Initialized
INFO - 2019-07-03 18:23:55 --> Controller Class Initialized
INFO - 2019-07-03 18:25:24 --> Config Class Initialized
INFO - 2019-07-03 18:25:24 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:25:24 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:25:24 --> Utf8 Class Initialized
INFO - 2019-07-03 18:25:24 --> URI Class Initialized
INFO - 2019-07-03 18:25:24 --> Router Class Initialized
INFO - 2019-07-03 18:25:24 --> Output Class Initialized
INFO - 2019-07-03 18:25:24 --> Security Class Initialized
DEBUG - 2019-07-03 18:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:25:24 --> Input Class Initialized
INFO - 2019-07-03 18:25:24 --> Language Class Initialized
INFO - 2019-07-03 18:25:24 --> Language Class Initialized
INFO - 2019-07-03 18:25:24 --> Config Class Initialized
INFO - 2019-07-03 18:25:24 --> Loader Class Initialized
DEBUG - 2019-07-03 18:25:24 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:25:24 --> Helper loaded: url_helper
INFO - 2019-07-03 18:25:24 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:25:24 --> Helper loaded: string_helper
INFO - 2019-07-03 18:25:24 --> Helper loaded: array_helper
INFO - 2019-07-03 18:25:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:25:24 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:25:24 --> Database Driver Class Initialized
INFO - 2019-07-03 18:25:24 --> Controller Class Initialized
INFO - 2019-07-03 18:25:25 --> Config Class Initialized
INFO - 2019-07-03 18:25:25 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:25:25 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:25:25 --> Utf8 Class Initialized
INFO - 2019-07-03 18:25:25 --> URI Class Initialized
INFO - 2019-07-03 18:25:25 --> Router Class Initialized
INFO - 2019-07-03 18:25:25 --> Output Class Initialized
INFO - 2019-07-03 18:25:25 --> Security Class Initialized
DEBUG - 2019-07-03 18:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:25:25 --> Input Class Initialized
INFO - 2019-07-03 18:25:25 --> Language Class Initialized
INFO - 2019-07-03 18:25:25 --> Language Class Initialized
INFO - 2019-07-03 18:25:25 --> Config Class Initialized
INFO - 2019-07-03 18:25:25 --> Loader Class Initialized
DEBUG - 2019-07-03 18:25:25 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:25:25 --> Helper loaded: url_helper
INFO - 2019-07-03 18:25:25 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:25:25 --> Helper loaded: string_helper
INFO - 2019-07-03 18:25:25 --> Helper loaded: array_helper
INFO - 2019-07-03 18:25:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:25:25 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:25:25 --> Database Driver Class Initialized
INFO - 2019-07-03 18:25:25 --> Controller Class Initialized
INFO - 2019-07-03 18:25:52 --> Config Class Initialized
INFO - 2019-07-03 18:25:52 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:25:52 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:25:52 --> Utf8 Class Initialized
INFO - 2019-07-03 18:25:52 --> URI Class Initialized
INFO - 2019-07-03 18:25:52 --> Router Class Initialized
INFO - 2019-07-03 18:25:52 --> Output Class Initialized
INFO - 2019-07-03 18:25:52 --> Security Class Initialized
DEBUG - 2019-07-03 18:25:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:25:52 --> Input Class Initialized
INFO - 2019-07-03 18:25:52 --> Language Class Initialized
INFO - 2019-07-03 18:25:52 --> Language Class Initialized
INFO - 2019-07-03 18:25:52 --> Config Class Initialized
INFO - 2019-07-03 18:25:52 --> Loader Class Initialized
DEBUG - 2019-07-03 18:25:52 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:25:52 --> Helper loaded: url_helper
INFO - 2019-07-03 18:25:52 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:25:52 --> Helper loaded: string_helper
INFO - 2019-07-03 18:25:52 --> Helper loaded: array_helper
INFO - 2019-07-03 18:25:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:25:52 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:25:52 --> Database Driver Class Initialized
INFO - 2019-07-03 18:25:52 --> Controller Class Initialized
INFO - 2019-07-03 18:25:53 --> Config Class Initialized
INFO - 2019-07-03 18:25:53 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:25:53 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:25:53 --> Utf8 Class Initialized
INFO - 2019-07-03 18:25:53 --> URI Class Initialized
INFO - 2019-07-03 18:25:53 --> Router Class Initialized
INFO - 2019-07-03 18:25:53 --> Output Class Initialized
INFO - 2019-07-03 18:25:53 --> Security Class Initialized
DEBUG - 2019-07-03 18:25:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:25:53 --> Input Class Initialized
INFO - 2019-07-03 18:25:53 --> Language Class Initialized
INFO - 2019-07-03 18:25:53 --> Language Class Initialized
INFO - 2019-07-03 18:25:53 --> Config Class Initialized
INFO - 2019-07-03 18:25:53 --> Loader Class Initialized
DEBUG - 2019-07-03 18:25:53 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:25:53 --> Helper loaded: url_helper
INFO - 2019-07-03 18:25:53 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:25:53 --> Helper loaded: string_helper
INFO - 2019-07-03 18:25:53 --> Helper loaded: array_helper
INFO - 2019-07-03 18:25:53 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:25:53 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:25:53 --> Database Driver Class Initialized
INFO - 2019-07-03 18:25:53 --> Controller Class Initialized
INFO - 2019-07-03 18:26:20 --> Config Class Initialized
INFO - 2019-07-03 18:26:20 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:26:20 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:26:20 --> Utf8 Class Initialized
INFO - 2019-07-03 18:26:20 --> URI Class Initialized
INFO - 2019-07-03 18:26:20 --> Router Class Initialized
INFO - 2019-07-03 18:26:20 --> Output Class Initialized
INFO - 2019-07-03 18:26:20 --> Security Class Initialized
DEBUG - 2019-07-03 18:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:26:20 --> Input Class Initialized
INFO - 2019-07-03 18:26:20 --> Language Class Initialized
INFO - 2019-07-03 18:26:20 --> Language Class Initialized
INFO - 2019-07-03 18:26:20 --> Config Class Initialized
INFO - 2019-07-03 18:26:20 --> Loader Class Initialized
DEBUG - 2019-07-03 18:26:20 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:26:20 --> Helper loaded: url_helper
INFO - 2019-07-03 18:26:20 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:26:20 --> Helper loaded: string_helper
INFO - 2019-07-03 18:26:20 --> Helper loaded: array_helper
INFO - 2019-07-03 18:26:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:26:20 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:26:20 --> Database Driver Class Initialized
INFO - 2019-07-03 18:26:20 --> Controller Class Initialized
INFO - 2019-07-03 18:26:21 --> Config Class Initialized
INFO - 2019-07-03 18:26:21 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:26:21 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:26:21 --> Utf8 Class Initialized
INFO - 2019-07-03 18:26:21 --> URI Class Initialized
INFO - 2019-07-03 18:26:21 --> Router Class Initialized
INFO - 2019-07-03 18:26:21 --> Output Class Initialized
INFO - 2019-07-03 18:26:21 --> Security Class Initialized
DEBUG - 2019-07-03 18:26:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:26:21 --> Input Class Initialized
INFO - 2019-07-03 18:26:21 --> Language Class Initialized
INFO - 2019-07-03 18:26:21 --> Language Class Initialized
INFO - 2019-07-03 18:26:21 --> Config Class Initialized
INFO - 2019-07-03 18:26:21 --> Loader Class Initialized
DEBUG - 2019-07-03 18:26:21 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:26:21 --> Helper loaded: url_helper
INFO - 2019-07-03 18:26:21 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:26:21 --> Helper loaded: string_helper
INFO - 2019-07-03 18:26:21 --> Helper loaded: array_helper
INFO - 2019-07-03 18:26:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:26:21 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:26:21 --> Database Driver Class Initialized
INFO - 2019-07-03 18:26:21 --> Controller Class Initialized
INFO - 2019-07-03 18:26:45 --> Config Class Initialized
INFO - 2019-07-03 18:26:45 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:26:45 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:26:45 --> Utf8 Class Initialized
INFO - 2019-07-03 18:26:45 --> URI Class Initialized
INFO - 2019-07-03 18:26:45 --> Router Class Initialized
INFO - 2019-07-03 18:26:45 --> Output Class Initialized
INFO - 2019-07-03 18:26:45 --> Security Class Initialized
DEBUG - 2019-07-03 18:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:26:45 --> Input Class Initialized
INFO - 2019-07-03 18:26:45 --> Language Class Initialized
INFO - 2019-07-03 18:26:45 --> Language Class Initialized
INFO - 2019-07-03 18:26:45 --> Config Class Initialized
INFO - 2019-07-03 18:26:45 --> Loader Class Initialized
DEBUG - 2019-07-03 18:26:45 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:26:45 --> Helper loaded: url_helper
INFO - 2019-07-03 18:26:45 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:26:45 --> Helper loaded: string_helper
INFO - 2019-07-03 18:26:45 --> Helper loaded: array_helper
INFO - 2019-07-03 18:26:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:26:45 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:26:45 --> Database Driver Class Initialized
INFO - 2019-07-03 18:26:45 --> Controller Class Initialized
INFO - 2019-07-03 18:26:45 --> Config Class Initialized
INFO - 2019-07-03 18:26:45 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:26:45 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:26:45 --> Utf8 Class Initialized
INFO - 2019-07-03 18:26:45 --> URI Class Initialized
INFO - 2019-07-03 18:26:45 --> Router Class Initialized
INFO - 2019-07-03 18:26:45 --> Output Class Initialized
INFO - 2019-07-03 18:26:45 --> Security Class Initialized
DEBUG - 2019-07-03 18:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:26:45 --> Input Class Initialized
INFO - 2019-07-03 18:26:45 --> Language Class Initialized
INFO - 2019-07-03 18:26:45 --> Language Class Initialized
INFO - 2019-07-03 18:26:45 --> Config Class Initialized
INFO - 2019-07-03 18:26:46 --> Loader Class Initialized
DEBUG - 2019-07-03 18:26:46 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:26:46 --> Helper loaded: url_helper
INFO - 2019-07-03 18:26:46 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:26:46 --> Helper loaded: string_helper
INFO - 2019-07-03 18:26:46 --> Helper loaded: array_helper
INFO - 2019-07-03 18:26:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:26:46 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:26:46 --> Database Driver Class Initialized
INFO - 2019-07-03 18:26:46 --> Controller Class Initialized
INFO - 2019-07-03 18:26:47 --> Config Class Initialized
INFO - 2019-07-03 18:26:47 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:26:47 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:26:47 --> Utf8 Class Initialized
INFO - 2019-07-03 18:26:47 --> URI Class Initialized
INFO - 2019-07-03 18:26:47 --> Router Class Initialized
INFO - 2019-07-03 18:26:47 --> Output Class Initialized
INFO - 2019-07-03 18:26:47 --> Security Class Initialized
DEBUG - 2019-07-03 18:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:26:47 --> Input Class Initialized
INFO - 2019-07-03 18:26:47 --> Language Class Initialized
INFO - 2019-07-03 18:26:47 --> Language Class Initialized
INFO - 2019-07-03 18:26:47 --> Config Class Initialized
INFO - 2019-07-03 18:26:47 --> Loader Class Initialized
DEBUG - 2019-07-03 18:26:47 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:26:47 --> Helper loaded: url_helper
INFO - 2019-07-03 18:26:47 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:26:47 --> Helper loaded: string_helper
INFO - 2019-07-03 18:26:47 --> Helper loaded: array_helper
INFO - 2019-07-03 18:26:47 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:26:47 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:26:47 --> Database Driver Class Initialized
INFO - 2019-07-03 18:26:47 --> Controller Class Initialized
INFO - 2019-07-03 18:28:11 --> Config Class Initialized
INFO - 2019-07-03 18:28:11 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:28:11 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:28:11 --> Utf8 Class Initialized
INFO - 2019-07-03 18:28:11 --> URI Class Initialized
INFO - 2019-07-03 18:28:11 --> Router Class Initialized
INFO - 2019-07-03 18:28:11 --> Output Class Initialized
INFO - 2019-07-03 18:28:11 --> Security Class Initialized
DEBUG - 2019-07-03 18:28:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:28:11 --> Input Class Initialized
INFO - 2019-07-03 18:28:11 --> Language Class Initialized
INFO - 2019-07-03 18:28:11 --> Language Class Initialized
INFO - 2019-07-03 18:28:11 --> Config Class Initialized
INFO - 2019-07-03 18:28:11 --> Loader Class Initialized
DEBUG - 2019-07-03 18:28:11 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:28:11 --> Helper loaded: url_helper
INFO - 2019-07-03 18:28:11 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:28:11 --> Helper loaded: string_helper
INFO - 2019-07-03 18:28:11 --> Helper loaded: array_helper
INFO - 2019-07-03 18:28:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:28:11 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:28:11 --> Database Driver Class Initialized
INFO - 2019-07-03 18:28:11 --> Controller Class Initialized
INFO - 2019-07-03 18:28:12 --> Config Class Initialized
INFO - 2019-07-03 18:28:12 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:28:12 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:28:12 --> Utf8 Class Initialized
INFO - 2019-07-03 18:28:12 --> URI Class Initialized
INFO - 2019-07-03 18:28:12 --> Router Class Initialized
INFO - 2019-07-03 18:28:12 --> Output Class Initialized
INFO - 2019-07-03 18:28:12 --> Security Class Initialized
DEBUG - 2019-07-03 18:28:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:28:12 --> Input Class Initialized
INFO - 2019-07-03 18:28:12 --> Language Class Initialized
INFO - 2019-07-03 18:28:12 --> Language Class Initialized
INFO - 2019-07-03 18:28:12 --> Config Class Initialized
INFO - 2019-07-03 18:28:12 --> Loader Class Initialized
DEBUG - 2019-07-03 18:28:12 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:28:12 --> Helper loaded: url_helper
INFO - 2019-07-03 18:28:12 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:28:12 --> Helper loaded: string_helper
INFO - 2019-07-03 18:28:12 --> Helper loaded: array_helper
INFO - 2019-07-03 18:28:12 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:28:12 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:28:12 --> Database Driver Class Initialized
INFO - 2019-07-03 18:28:12 --> Controller Class Initialized
INFO - 2019-07-03 18:28:53 --> Config Class Initialized
INFO - 2019-07-03 18:28:53 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:28:53 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:28:53 --> Utf8 Class Initialized
INFO - 2019-07-03 18:28:53 --> URI Class Initialized
INFO - 2019-07-03 18:28:53 --> Router Class Initialized
INFO - 2019-07-03 18:28:53 --> Output Class Initialized
INFO - 2019-07-03 18:28:53 --> Security Class Initialized
DEBUG - 2019-07-03 18:28:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:28:53 --> Input Class Initialized
INFO - 2019-07-03 18:28:53 --> Language Class Initialized
INFO - 2019-07-03 18:28:53 --> Language Class Initialized
INFO - 2019-07-03 18:28:53 --> Config Class Initialized
INFO - 2019-07-03 18:28:53 --> Loader Class Initialized
DEBUG - 2019-07-03 18:28:53 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:28:53 --> Helper loaded: url_helper
INFO - 2019-07-03 18:28:53 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:28:53 --> Helper loaded: string_helper
INFO - 2019-07-03 18:28:53 --> Helper loaded: array_helper
INFO - 2019-07-03 18:28:53 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:28:53 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:28:54 --> Database Driver Class Initialized
INFO - 2019-07-03 18:28:54 --> Controller Class Initialized
INFO - 2019-07-03 18:28:54 --> Config Class Initialized
INFO - 2019-07-03 18:28:54 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:28:54 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:28:54 --> Utf8 Class Initialized
INFO - 2019-07-03 18:28:54 --> URI Class Initialized
INFO - 2019-07-03 18:28:54 --> Router Class Initialized
INFO - 2019-07-03 18:28:54 --> Output Class Initialized
INFO - 2019-07-03 18:28:54 --> Security Class Initialized
DEBUG - 2019-07-03 18:28:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:28:54 --> Input Class Initialized
INFO - 2019-07-03 18:28:54 --> Language Class Initialized
INFO - 2019-07-03 18:28:54 --> Language Class Initialized
INFO - 2019-07-03 18:28:54 --> Config Class Initialized
INFO - 2019-07-03 18:28:54 --> Loader Class Initialized
DEBUG - 2019-07-03 18:28:54 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:28:54 --> Helper loaded: url_helper
INFO - 2019-07-03 18:28:54 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:28:54 --> Helper loaded: string_helper
INFO - 2019-07-03 18:28:54 --> Helper loaded: array_helper
INFO - 2019-07-03 18:28:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:28:54 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:28:54 --> Database Driver Class Initialized
INFO - 2019-07-03 18:28:54 --> Controller Class Initialized
INFO - 2019-07-03 18:29:38 --> Config Class Initialized
INFO - 2019-07-03 18:29:38 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:29:38 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:29:38 --> Utf8 Class Initialized
INFO - 2019-07-03 18:29:38 --> URI Class Initialized
INFO - 2019-07-03 18:29:38 --> Router Class Initialized
INFO - 2019-07-03 18:29:38 --> Output Class Initialized
INFO - 2019-07-03 18:29:38 --> Security Class Initialized
DEBUG - 2019-07-03 18:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:29:38 --> Input Class Initialized
INFO - 2019-07-03 18:29:38 --> Language Class Initialized
INFO - 2019-07-03 18:29:39 --> Language Class Initialized
INFO - 2019-07-03 18:29:39 --> Config Class Initialized
INFO - 2019-07-03 18:29:39 --> Loader Class Initialized
DEBUG - 2019-07-03 18:29:39 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:29:39 --> Helper loaded: url_helper
INFO - 2019-07-03 18:29:39 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:29:39 --> Helper loaded: string_helper
INFO - 2019-07-03 18:29:39 --> Helper loaded: array_helper
INFO - 2019-07-03 18:29:39 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:29:39 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:29:39 --> Database Driver Class Initialized
INFO - 2019-07-03 18:29:39 --> Controller Class Initialized
INFO - 2019-07-03 18:29:39 --> Config Class Initialized
INFO - 2019-07-03 18:29:39 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:29:39 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:29:39 --> Utf8 Class Initialized
INFO - 2019-07-03 18:29:39 --> URI Class Initialized
INFO - 2019-07-03 18:29:39 --> Router Class Initialized
INFO - 2019-07-03 18:29:39 --> Output Class Initialized
INFO - 2019-07-03 18:29:39 --> Security Class Initialized
DEBUG - 2019-07-03 18:29:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:29:39 --> Input Class Initialized
INFO - 2019-07-03 18:29:39 --> Language Class Initialized
INFO - 2019-07-03 18:29:39 --> Language Class Initialized
INFO - 2019-07-03 18:29:39 --> Config Class Initialized
INFO - 2019-07-03 18:29:39 --> Loader Class Initialized
DEBUG - 2019-07-03 18:29:39 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:29:39 --> Helper loaded: url_helper
INFO - 2019-07-03 18:29:39 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:29:39 --> Helper loaded: string_helper
INFO - 2019-07-03 18:29:39 --> Helper loaded: array_helper
INFO - 2019-07-03 18:29:39 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:29:39 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:29:39 --> Database Driver Class Initialized
INFO - 2019-07-03 18:29:39 --> Controller Class Initialized
INFO - 2019-07-03 18:29:40 --> Config Class Initialized
INFO - 2019-07-03 18:29:40 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:29:40 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:29:40 --> Utf8 Class Initialized
INFO - 2019-07-03 18:29:40 --> URI Class Initialized
INFO - 2019-07-03 18:29:40 --> Router Class Initialized
INFO - 2019-07-03 18:29:40 --> Output Class Initialized
INFO - 2019-07-03 18:29:40 --> Security Class Initialized
DEBUG - 2019-07-03 18:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:29:40 --> Input Class Initialized
INFO - 2019-07-03 18:29:40 --> Language Class Initialized
INFO - 2019-07-03 18:29:40 --> Language Class Initialized
INFO - 2019-07-03 18:29:40 --> Config Class Initialized
INFO - 2019-07-03 18:29:40 --> Loader Class Initialized
DEBUG - 2019-07-03 18:29:40 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:29:40 --> Helper loaded: url_helper
INFO - 2019-07-03 18:29:40 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:29:40 --> Helper loaded: string_helper
INFO - 2019-07-03 18:29:40 --> Helper loaded: array_helper
INFO - 2019-07-03 18:29:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:29:40 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:29:40 --> Database Driver Class Initialized
INFO - 2019-07-03 18:29:40 --> Controller Class Initialized
INFO - 2019-07-03 18:29:59 --> Config Class Initialized
INFO - 2019-07-03 18:29:59 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:29:59 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:29:59 --> Utf8 Class Initialized
INFO - 2019-07-03 18:30:00 --> URI Class Initialized
INFO - 2019-07-03 18:30:00 --> Router Class Initialized
INFO - 2019-07-03 18:30:00 --> Output Class Initialized
INFO - 2019-07-03 18:30:00 --> Security Class Initialized
DEBUG - 2019-07-03 18:30:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:30:00 --> Input Class Initialized
INFO - 2019-07-03 18:30:00 --> Language Class Initialized
INFO - 2019-07-03 18:30:00 --> Language Class Initialized
INFO - 2019-07-03 18:30:00 --> Config Class Initialized
INFO - 2019-07-03 18:30:00 --> Loader Class Initialized
DEBUG - 2019-07-03 18:30:00 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:30:00 --> Helper loaded: url_helper
INFO - 2019-07-03 18:30:00 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:30:00 --> Helper loaded: string_helper
INFO - 2019-07-03 18:30:00 --> Helper loaded: array_helper
INFO - 2019-07-03 18:30:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:30:00 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:30:00 --> Database Driver Class Initialized
INFO - 2019-07-03 18:30:00 --> Controller Class Initialized
INFO - 2019-07-03 18:30:00 --> Config Class Initialized
INFO - 2019-07-03 18:30:00 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:30:00 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:30:00 --> Utf8 Class Initialized
INFO - 2019-07-03 18:30:00 --> URI Class Initialized
INFO - 2019-07-03 18:30:00 --> Router Class Initialized
INFO - 2019-07-03 18:30:00 --> Output Class Initialized
INFO - 2019-07-03 18:30:00 --> Security Class Initialized
DEBUG - 2019-07-03 18:30:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:30:00 --> Input Class Initialized
INFO - 2019-07-03 18:30:00 --> Language Class Initialized
INFO - 2019-07-03 18:30:00 --> Language Class Initialized
INFO - 2019-07-03 18:30:00 --> Config Class Initialized
INFO - 2019-07-03 18:30:00 --> Loader Class Initialized
DEBUG - 2019-07-03 18:30:00 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:30:00 --> Helper loaded: url_helper
INFO - 2019-07-03 18:30:00 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:30:00 --> Helper loaded: string_helper
INFO - 2019-07-03 18:30:00 --> Helper loaded: array_helper
INFO - 2019-07-03 18:30:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:30:00 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:30:00 --> Database Driver Class Initialized
INFO - 2019-07-03 18:30:00 --> Controller Class Initialized
INFO - 2019-07-03 18:30:01 --> Config Class Initialized
INFO - 2019-07-03 18:30:01 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:30:01 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:30:01 --> Utf8 Class Initialized
INFO - 2019-07-03 18:30:01 --> URI Class Initialized
INFO - 2019-07-03 18:30:01 --> Router Class Initialized
INFO - 2019-07-03 18:30:01 --> Output Class Initialized
INFO - 2019-07-03 18:30:01 --> Security Class Initialized
DEBUG - 2019-07-03 18:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:30:01 --> Input Class Initialized
INFO - 2019-07-03 18:30:01 --> Language Class Initialized
INFO - 2019-07-03 18:30:01 --> Language Class Initialized
INFO - 2019-07-03 18:30:01 --> Config Class Initialized
INFO - 2019-07-03 18:30:01 --> Loader Class Initialized
DEBUG - 2019-07-03 18:30:01 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:30:02 --> Helper loaded: url_helper
INFO - 2019-07-03 18:30:02 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:30:02 --> Helper loaded: string_helper
INFO - 2019-07-03 18:30:02 --> Helper loaded: array_helper
INFO - 2019-07-03 18:30:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:30:02 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:30:02 --> Database Driver Class Initialized
INFO - 2019-07-03 18:30:02 --> Controller Class Initialized
INFO - 2019-07-03 18:30:21 --> Config Class Initialized
INFO - 2019-07-03 18:30:21 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:30:21 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:30:21 --> Utf8 Class Initialized
INFO - 2019-07-03 18:30:21 --> URI Class Initialized
INFO - 2019-07-03 18:30:21 --> Router Class Initialized
INFO - 2019-07-03 18:30:21 --> Output Class Initialized
INFO - 2019-07-03 18:30:21 --> Security Class Initialized
DEBUG - 2019-07-03 18:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:30:21 --> Input Class Initialized
INFO - 2019-07-03 18:30:21 --> Language Class Initialized
INFO - 2019-07-03 18:30:21 --> Language Class Initialized
INFO - 2019-07-03 18:30:21 --> Config Class Initialized
INFO - 2019-07-03 18:30:21 --> Loader Class Initialized
DEBUG - 2019-07-03 18:30:21 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:30:21 --> Helper loaded: url_helper
INFO - 2019-07-03 18:30:21 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:30:21 --> Helper loaded: string_helper
INFO - 2019-07-03 18:30:21 --> Helper loaded: array_helper
INFO - 2019-07-03 18:30:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:30:21 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:30:21 --> Database Driver Class Initialized
INFO - 2019-07-03 18:30:21 --> Controller Class Initialized
INFO - 2019-07-03 18:30:21 --> Config Class Initialized
INFO - 2019-07-03 18:30:21 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:30:21 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:30:21 --> Utf8 Class Initialized
INFO - 2019-07-03 18:30:21 --> URI Class Initialized
INFO - 2019-07-03 18:30:21 --> Router Class Initialized
INFO - 2019-07-03 18:30:21 --> Output Class Initialized
INFO - 2019-07-03 18:30:21 --> Security Class Initialized
DEBUG - 2019-07-03 18:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:30:21 --> Input Class Initialized
INFO - 2019-07-03 18:30:21 --> Language Class Initialized
INFO - 2019-07-03 18:30:21 --> Language Class Initialized
INFO - 2019-07-03 18:30:21 --> Config Class Initialized
INFO - 2019-07-03 18:30:21 --> Loader Class Initialized
DEBUG - 2019-07-03 18:30:21 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:30:21 --> Helper loaded: url_helper
INFO - 2019-07-03 18:30:21 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:30:21 --> Helper loaded: string_helper
INFO - 2019-07-03 18:30:21 --> Helper loaded: array_helper
INFO - 2019-07-03 18:30:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:30:21 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:30:22 --> Database Driver Class Initialized
INFO - 2019-07-03 18:30:22 --> Controller Class Initialized
INFO - 2019-07-03 18:30:23 --> Config Class Initialized
INFO - 2019-07-03 18:30:23 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:30:23 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:30:23 --> Utf8 Class Initialized
INFO - 2019-07-03 18:30:23 --> URI Class Initialized
INFO - 2019-07-03 18:30:23 --> Router Class Initialized
INFO - 2019-07-03 18:30:23 --> Output Class Initialized
INFO - 2019-07-03 18:30:23 --> Security Class Initialized
DEBUG - 2019-07-03 18:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:30:23 --> Input Class Initialized
INFO - 2019-07-03 18:30:23 --> Language Class Initialized
INFO - 2019-07-03 18:30:23 --> Language Class Initialized
INFO - 2019-07-03 18:30:23 --> Config Class Initialized
INFO - 2019-07-03 18:30:23 --> Loader Class Initialized
DEBUG - 2019-07-03 18:30:23 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:30:23 --> Helper loaded: url_helper
INFO - 2019-07-03 18:30:23 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:30:23 --> Helper loaded: string_helper
INFO - 2019-07-03 18:30:23 --> Helper loaded: array_helper
INFO - 2019-07-03 18:30:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:30:23 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:30:23 --> Database Driver Class Initialized
INFO - 2019-07-03 18:30:23 --> Controller Class Initialized
INFO - 2019-07-03 18:31:57 --> Config Class Initialized
INFO - 2019-07-03 18:31:57 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:31:57 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:31:57 --> Utf8 Class Initialized
INFO - 2019-07-03 18:31:57 --> URI Class Initialized
INFO - 2019-07-03 18:31:57 --> Router Class Initialized
INFO - 2019-07-03 18:31:57 --> Output Class Initialized
INFO - 2019-07-03 18:31:57 --> Security Class Initialized
DEBUG - 2019-07-03 18:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:31:57 --> Input Class Initialized
INFO - 2019-07-03 18:31:57 --> Language Class Initialized
INFO - 2019-07-03 18:31:57 --> Language Class Initialized
INFO - 2019-07-03 18:31:57 --> Config Class Initialized
INFO - 2019-07-03 18:31:57 --> Loader Class Initialized
DEBUG - 2019-07-03 18:31:57 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:31:57 --> Helper loaded: url_helper
INFO - 2019-07-03 18:31:57 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:31:57 --> Helper loaded: string_helper
INFO - 2019-07-03 18:31:57 --> Helper loaded: array_helper
INFO - 2019-07-03 18:31:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:31:57 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:31:57 --> Database Driver Class Initialized
INFO - 2019-07-03 18:31:57 --> Controller Class Initialized
INFO - 2019-07-03 18:31:57 --> Config Class Initialized
INFO - 2019-07-03 18:31:57 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:31:57 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:31:57 --> Utf8 Class Initialized
INFO - 2019-07-03 18:31:57 --> URI Class Initialized
INFO - 2019-07-03 18:31:57 --> Router Class Initialized
INFO - 2019-07-03 18:31:57 --> Output Class Initialized
INFO - 2019-07-03 18:31:57 --> Security Class Initialized
DEBUG - 2019-07-03 18:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:31:57 --> Input Class Initialized
INFO - 2019-07-03 18:31:57 --> Language Class Initialized
INFO - 2019-07-03 18:31:57 --> Language Class Initialized
INFO - 2019-07-03 18:31:58 --> Config Class Initialized
INFO - 2019-07-03 18:31:58 --> Loader Class Initialized
DEBUG - 2019-07-03 18:31:58 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:31:58 --> Helper loaded: url_helper
INFO - 2019-07-03 18:31:58 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:31:58 --> Helper loaded: string_helper
INFO - 2019-07-03 18:31:58 --> Helper loaded: array_helper
INFO - 2019-07-03 18:31:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:31:58 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:31:58 --> Database Driver Class Initialized
INFO - 2019-07-03 18:31:58 --> Controller Class Initialized
INFO - 2019-07-03 18:31:58 --> Config Class Initialized
INFO - 2019-07-03 18:31:58 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:31:58 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:31:58 --> Utf8 Class Initialized
INFO - 2019-07-03 18:31:58 --> URI Class Initialized
INFO - 2019-07-03 18:31:59 --> Router Class Initialized
INFO - 2019-07-03 18:31:59 --> Output Class Initialized
INFO - 2019-07-03 18:31:59 --> Security Class Initialized
DEBUG - 2019-07-03 18:31:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:31:59 --> Input Class Initialized
INFO - 2019-07-03 18:31:59 --> Language Class Initialized
INFO - 2019-07-03 18:31:59 --> Language Class Initialized
INFO - 2019-07-03 18:31:59 --> Config Class Initialized
INFO - 2019-07-03 18:31:59 --> Loader Class Initialized
DEBUG - 2019-07-03 18:31:59 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:31:59 --> Helper loaded: url_helper
INFO - 2019-07-03 18:31:59 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:31:59 --> Helper loaded: string_helper
INFO - 2019-07-03 18:31:59 --> Helper loaded: array_helper
INFO - 2019-07-03 18:31:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:31:59 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:31:59 --> Database Driver Class Initialized
INFO - 2019-07-03 18:31:59 --> Controller Class Initialized
INFO - 2019-07-03 18:32:09 --> Config Class Initialized
INFO - 2019-07-03 18:32:09 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:32:09 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:32:09 --> Utf8 Class Initialized
INFO - 2019-07-03 18:32:09 --> URI Class Initialized
INFO - 2019-07-03 18:32:09 --> Router Class Initialized
INFO - 2019-07-03 18:32:09 --> Output Class Initialized
INFO - 2019-07-03 18:32:09 --> Security Class Initialized
DEBUG - 2019-07-03 18:32:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:32:09 --> Input Class Initialized
INFO - 2019-07-03 18:32:09 --> Language Class Initialized
INFO - 2019-07-03 18:32:09 --> Language Class Initialized
INFO - 2019-07-03 18:32:09 --> Config Class Initialized
INFO - 2019-07-03 18:32:09 --> Loader Class Initialized
DEBUG - 2019-07-03 18:32:09 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:32:09 --> Helper loaded: url_helper
INFO - 2019-07-03 18:32:09 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:32:09 --> Helper loaded: string_helper
INFO - 2019-07-03 18:32:09 --> Helper loaded: array_helper
INFO - 2019-07-03 18:32:09 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:32:09 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:32:09 --> Database Driver Class Initialized
INFO - 2019-07-03 18:32:09 --> Controller Class Initialized
INFO - 2019-07-03 18:32:09 --> Config Class Initialized
INFO - 2019-07-03 18:32:09 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:32:09 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:32:09 --> Utf8 Class Initialized
INFO - 2019-07-03 18:32:09 --> URI Class Initialized
INFO - 2019-07-03 18:32:09 --> Router Class Initialized
INFO - 2019-07-03 18:32:09 --> Output Class Initialized
INFO - 2019-07-03 18:32:10 --> Security Class Initialized
DEBUG - 2019-07-03 18:32:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:32:10 --> Input Class Initialized
INFO - 2019-07-03 18:32:10 --> Language Class Initialized
INFO - 2019-07-03 18:32:10 --> Language Class Initialized
INFO - 2019-07-03 18:32:10 --> Config Class Initialized
INFO - 2019-07-03 18:32:10 --> Loader Class Initialized
DEBUG - 2019-07-03 18:32:10 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:32:10 --> Helper loaded: url_helper
INFO - 2019-07-03 18:32:10 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:32:10 --> Helper loaded: string_helper
INFO - 2019-07-03 18:32:10 --> Helper loaded: array_helper
INFO - 2019-07-03 18:32:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:32:10 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:32:10 --> Database Driver Class Initialized
INFO - 2019-07-03 18:32:10 --> Controller Class Initialized
INFO - 2019-07-03 18:32:12 --> Config Class Initialized
INFO - 2019-07-03 18:32:12 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:32:12 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:32:12 --> Utf8 Class Initialized
INFO - 2019-07-03 18:32:12 --> URI Class Initialized
INFO - 2019-07-03 18:32:12 --> Router Class Initialized
INFO - 2019-07-03 18:32:12 --> Output Class Initialized
INFO - 2019-07-03 18:32:12 --> Security Class Initialized
DEBUG - 2019-07-03 18:32:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:32:12 --> Input Class Initialized
INFO - 2019-07-03 18:32:12 --> Language Class Initialized
INFO - 2019-07-03 18:32:12 --> Language Class Initialized
INFO - 2019-07-03 18:32:12 --> Config Class Initialized
INFO - 2019-07-03 18:32:12 --> Loader Class Initialized
DEBUG - 2019-07-03 18:32:12 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:32:12 --> Helper loaded: url_helper
INFO - 2019-07-03 18:32:12 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:32:12 --> Helper loaded: string_helper
INFO - 2019-07-03 18:32:12 --> Helper loaded: array_helper
INFO - 2019-07-03 18:32:12 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:32:12 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:32:12 --> Database Driver Class Initialized
INFO - 2019-07-03 18:32:12 --> Controller Class Initialized
INFO - 2019-07-03 18:32:27 --> Config Class Initialized
INFO - 2019-07-03 18:32:27 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:32:27 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:32:27 --> Utf8 Class Initialized
INFO - 2019-07-03 18:32:27 --> URI Class Initialized
INFO - 2019-07-03 18:32:27 --> Router Class Initialized
INFO - 2019-07-03 18:32:27 --> Output Class Initialized
INFO - 2019-07-03 18:32:27 --> Security Class Initialized
DEBUG - 2019-07-03 18:32:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:32:27 --> Input Class Initialized
INFO - 2019-07-03 18:32:27 --> Language Class Initialized
INFO - 2019-07-03 18:32:27 --> Language Class Initialized
INFO - 2019-07-03 18:32:27 --> Config Class Initialized
INFO - 2019-07-03 18:32:27 --> Loader Class Initialized
DEBUG - 2019-07-03 18:32:27 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:32:27 --> Helper loaded: url_helper
INFO - 2019-07-03 18:32:27 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:32:27 --> Helper loaded: string_helper
INFO - 2019-07-03 18:32:27 --> Helper loaded: array_helper
INFO - 2019-07-03 18:32:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:32:27 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:32:27 --> Database Driver Class Initialized
INFO - 2019-07-03 18:32:27 --> Controller Class Initialized
INFO - 2019-07-03 18:32:28 --> Config Class Initialized
INFO - 2019-07-03 18:32:28 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:32:28 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:32:28 --> Utf8 Class Initialized
INFO - 2019-07-03 18:32:28 --> URI Class Initialized
INFO - 2019-07-03 18:32:28 --> Router Class Initialized
INFO - 2019-07-03 18:32:28 --> Output Class Initialized
INFO - 2019-07-03 18:32:28 --> Security Class Initialized
DEBUG - 2019-07-03 18:32:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:32:28 --> Input Class Initialized
INFO - 2019-07-03 18:32:28 --> Language Class Initialized
INFO - 2019-07-03 18:32:28 --> Language Class Initialized
INFO - 2019-07-03 18:32:28 --> Config Class Initialized
INFO - 2019-07-03 18:32:28 --> Loader Class Initialized
DEBUG - 2019-07-03 18:32:28 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:32:28 --> Helper loaded: url_helper
INFO - 2019-07-03 18:32:28 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:32:28 --> Helper loaded: string_helper
INFO - 2019-07-03 18:32:28 --> Helper loaded: array_helper
INFO - 2019-07-03 18:32:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:32:28 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:32:28 --> Database Driver Class Initialized
INFO - 2019-07-03 18:32:28 --> Controller Class Initialized
INFO - 2019-07-03 18:32:29 --> Config Class Initialized
INFO - 2019-07-03 18:32:29 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:32:29 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:32:29 --> Utf8 Class Initialized
INFO - 2019-07-03 18:32:29 --> URI Class Initialized
INFO - 2019-07-03 18:32:29 --> Router Class Initialized
INFO - 2019-07-03 18:32:29 --> Output Class Initialized
INFO - 2019-07-03 18:32:29 --> Security Class Initialized
DEBUG - 2019-07-03 18:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:32:29 --> Input Class Initialized
INFO - 2019-07-03 18:32:30 --> Language Class Initialized
INFO - 2019-07-03 18:32:30 --> Language Class Initialized
INFO - 2019-07-03 18:32:30 --> Config Class Initialized
INFO - 2019-07-03 18:32:30 --> Loader Class Initialized
DEBUG - 2019-07-03 18:32:30 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:32:30 --> Helper loaded: url_helper
INFO - 2019-07-03 18:32:30 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:32:30 --> Helper loaded: string_helper
INFO - 2019-07-03 18:32:30 --> Helper loaded: array_helper
INFO - 2019-07-03 18:32:30 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:32:30 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:32:30 --> Database Driver Class Initialized
INFO - 2019-07-03 18:32:30 --> Controller Class Initialized
INFO - 2019-07-03 18:32:39 --> Config Class Initialized
INFO - 2019-07-03 18:32:39 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:32:39 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:32:39 --> Utf8 Class Initialized
INFO - 2019-07-03 18:32:39 --> URI Class Initialized
INFO - 2019-07-03 18:32:39 --> Router Class Initialized
INFO - 2019-07-03 18:32:39 --> Output Class Initialized
INFO - 2019-07-03 18:32:39 --> Security Class Initialized
DEBUG - 2019-07-03 18:32:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:32:39 --> Input Class Initialized
INFO - 2019-07-03 18:32:39 --> Language Class Initialized
INFO - 2019-07-03 18:32:39 --> Language Class Initialized
INFO - 2019-07-03 18:32:39 --> Config Class Initialized
INFO - 2019-07-03 18:32:39 --> Loader Class Initialized
DEBUG - 2019-07-03 18:32:39 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:32:39 --> Helper loaded: url_helper
INFO - 2019-07-03 18:32:39 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:32:39 --> Helper loaded: string_helper
INFO - 2019-07-03 18:32:39 --> Helper loaded: array_helper
INFO - 2019-07-03 18:32:39 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:32:39 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:32:40 --> Database Driver Class Initialized
INFO - 2019-07-03 18:32:40 --> Controller Class Initialized
INFO - 2019-07-03 18:32:40 --> Config Class Initialized
INFO - 2019-07-03 18:32:40 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:32:40 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:32:40 --> Utf8 Class Initialized
INFO - 2019-07-03 18:32:40 --> URI Class Initialized
INFO - 2019-07-03 18:32:40 --> Router Class Initialized
INFO - 2019-07-03 18:32:40 --> Output Class Initialized
INFO - 2019-07-03 18:32:40 --> Security Class Initialized
DEBUG - 2019-07-03 18:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:32:40 --> Input Class Initialized
INFO - 2019-07-03 18:32:40 --> Language Class Initialized
INFO - 2019-07-03 18:32:40 --> Language Class Initialized
INFO - 2019-07-03 18:32:40 --> Config Class Initialized
INFO - 2019-07-03 18:32:40 --> Loader Class Initialized
DEBUG - 2019-07-03 18:32:40 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:32:40 --> Helper loaded: url_helper
INFO - 2019-07-03 18:32:40 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:32:40 --> Helper loaded: string_helper
INFO - 2019-07-03 18:32:40 --> Helper loaded: array_helper
INFO - 2019-07-03 18:32:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:32:40 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:32:40 --> Database Driver Class Initialized
INFO - 2019-07-03 18:32:40 --> Controller Class Initialized
INFO - 2019-07-03 18:32:41 --> Config Class Initialized
INFO - 2019-07-03 18:32:41 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:32:41 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:32:41 --> Utf8 Class Initialized
INFO - 2019-07-03 18:32:41 --> URI Class Initialized
INFO - 2019-07-03 18:32:41 --> Router Class Initialized
INFO - 2019-07-03 18:32:41 --> Output Class Initialized
INFO - 2019-07-03 18:32:41 --> Security Class Initialized
DEBUG - 2019-07-03 18:32:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:32:41 --> Input Class Initialized
INFO - 2019-07-03 18:32:41 --> Language Class Initialized
INFO - 2019-07-03 18:32:41 --> Language Class Initialized
INFO - 2019-07-03 18:32:41 --> Config Class Initialized
INFO - 2019-07-03 18:32:41 --> Loader Class Initialized
DEBUG - 2019-07-03 18:32:41 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:32:41 --> Helper loaded: url_helper
INFO - 2019-07-03 18:32:41 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:32:41 --> Helper loaded: string_helper
INFO - 2019-07-03 18:32:41 --> Helper loaded: array_helper
INFO - 2019-07-03 18:32:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:32:41 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:32:41 --> Database Driver Class Initialized
INFO - 2019-07-03 18:32:41 --> Controller Class Initialized
INFO - 2019-07-03 18:33:36 --> Config Class Initialized
INFO - 2019-07-03 18:33:36 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:33:36 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:33:36 --> Utf8 Class Initialized
INFO - 2019-07-03 18:33:36 --> URI Class Initialized
INFO - 2019-07-03 18:33:36 --> Router Class Initialized
INFO - 2019-07-03 18:33:36 --> Output Class Initialized
INFO - 2019-07-03 18:33:37 --> Security Class Initialized
DEBUG - 2019-07-03 18:33:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:33:37 --> Input Class Initialized
INFO - 2019-07-03 18:33:37 --> Language Class Initialized
INFO - 2019-07-03 18:33:37 --> Language Class Initialized
INFO - 2019-07-03 18:33:37 --> Config Class Initialized
INFO - 2019-07-03 18:33:37 --> Loader Class Initialized
DEBUG - 2019-07-03 18:33:37 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:33:37 --> Helper loaded: url_helper
INFO - 2019-07-03 18:33:37 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:33:37 --> Helper loaded: string_helper
INFO - 2019-07-03 18:33:37 --> Helper loaded: array_helper
INFO - 2019-07-03 18:33:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:33:37 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:33:37 --> Database Driver Class Initialized
INFO - 2019-07-03 18:33:37 --> Controller Class Initialized
INFO - 2019-07-03 18:33:37 --> Config Class Initialized
INFO - 2019-07-03 18:33:37 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:33:37 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:33:37 --> Utf8 Class Initialized
INFO - 2019-07-03 18:33:37 --> URI Class Initialized
INFO - 2019-07-03 18:33:37 --> Router Class Initialized
INFO - 2019-07-03 18:33:37 --> Output Class Initialized
INFO - 2019-07-03 18:33:37 --> Security Class Initialized
DEBUG - 2019-07-03 18:33:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:33:37 --> Input Class Initialized
INFO - 2019-07-03 18:33:37 --> Language Class Initialized
INFO - 2019-07-03 18:33:37 --> Language Class Initialized
INFO - 2019-07-03 18:33:37 --> Config Class Initialized
INFO - 2019-07-03 18:33:37 --> Loader Class Initialized
DEBUG - 2019-07-03 18:33:37 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:33:37 --> Helper loaded: url_helper
INFO - 2019-07-03 18:33:37 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:33:37 --> Helper loaded: string_helper
INFO - 2019-07-03 18:33:37 --> Helper loaded: array_helper
INFO - 2019-07-03 18:33:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:33:37 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:33:37 --> Database Driver Class Initialized
INFO - 2019-07-03 18:33:37 --> Controller Class Initialized
INFO - 2019-07-03 18:33:39 --> Config Class Initialized
INFO - 2019-07-03 18:33:39 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:33:39 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:33:39 --> Utf8 Class Initialized
INFO - 2019-07-03 18:33:40 --> URI Class Initialized
INFO - 2019-07-03 18:33:40 --> Router Class Initialized
INFO - 2019-07-03 18:33:40 --> Output Class Initialized
INFO - 2019-07-03 18:33:40 --> Security Class Initialized
DEBUG - 2019-07-03 18:33:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:33:40 --> Input Class Initialized
INFO - 2019-07-03 18:33:40 --> Language Class Initialized
INFO - 2019-07-03 18:33:40 --> Language Class Initialized
INFO - 2019-07-03 18:33:40 --> Config Class Initialized
INFO - 2019-07-03 18:33:40 --> Loader Class Initialized
DEBUG - 2019-07-03 18:33:40 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:33:40 --> Helper loaded: url_helper
INFO - 2019-07-03 18:33:40 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:33:40 --> Helper loaded: string_helper
INFO - 2019-07-03 18:33:40 --> Helper loaded: array_helper
INFO - 2019-07-03 18:33:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:33:40 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:33:40 --> Database Driver Class Initialized
INFO - 2019-07-03 18:33:40 --> Controller Class Initialized
INFO - 2019-07-03 18:33:40 --> Config Class Initialized
INFO - 2019-07-03 18:33:40 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:33:40 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:33:40 --> Utf8 Class Initialized
INFO - 2019-07-03 18:33:40 --> URI Class Initialized
INFO - 2019-07-03 18:33:40 --> Router Class Initialized
INFO - 2019-07-03 18:33:40 --> Output Class Initialized
INFO - 2019-07-03 18:33:40 --> Security Class Initialized
DEBUG - 2019-07-03 18:33:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:33:40 --> Input Class Initialized
INFO - 2019-07-03 18:33:40 --> Language Class Initialized
INFO - 2019-07-03 18:33:40 --> Language Class Initialized
INFO - 2019-07-03 18:33:40 --> Config Class Initialized
INFO - 2019-07-03 18:33:40 --> Loader Class Initialized
DEBUG - 2019-07-03 18:33:40 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:33:40 --> Helper loaded: url_helper
INFO - 2019-07-03 18:33:40 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:33:40 --> Helper loaded: string_helper
INFO - 2019-07-03 18:33:40 --> Helper loaded: array_helper
INFO - 2019-07-03 18:33:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:33:40 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:33:40 --> Database Driver Class Initialized
INFO - 2019-07-03 18:33:40 --> Controller Class Initialized
INFO - 2019-07-03 18:33:41 --> Config Class Initialized
INFO - 2019-07-03 18:33:41 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:33:41 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:33:41 --> Utf8 Class Initialized
INFO - 2019-07-03 18:33:41 --> URI Class Initialized
INFO - 2019-07-03 18:33:41 --> Router Class Initialized
INFO - 2019-07-03 18:33:41 --> Output Class Initialized
INFO - 2019-07-03 18:33:41 --> Security Class Initialized
DEBUG - 2019-07-03 18:33:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:33:41 --> Input Class Initialized
INFO - 2019-07-03 18:33:41 --> Language Class Initialized
INFO - 2019-07-03 18:33:41 --> Language Class Initialized
INFO - 2019-07-03 18:33:41 --> Config Class Initialized
INFO - 2019-07-03 18:33:41 --> Loader Class Initialized
DEBUG - 2019-07-03 18:33:41 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:33:41 --> Helper loaded: url_helper
INFO - 2019-07-03 18:33:41 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:33:41 --> Helper loaded: string_helper
INFO - 2019-07-03 18:33:42 --> Helper loaded: array_helper
INFO - 2019-07-03 18:33:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:33:42 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:33:42 --> Database Driver Class Initialized
INFO - 2019-07-03 18:33:42 --> Controller Class Initialized
INFO - 2019-07-03 18:33:55 --> Config Class Initialized
INFO - 2019-07-03 18:33:55 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:33:55 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:33:55 --> Utf8 Class Initialized
INFO - 2019-07-03 18:33:55 --> URI Class Initialized
INFO - 2019-07-03 18:33:55 --> Router Class Initialized
INFO - 2019-07-03 18:33:55 --> Output Class Initialized
INFO - 2019-07-03 18:33:55 --> Security Class Initialized
DEBUG - 2019-07-03 18:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:33:55 --> Input Class Initialized
INFO - 2019-07-03 18:33:55 --> Language Class Initialized
INFO - 2019-07-03 18:33:55 --> Language Class Initialized
INFO - 2019-07-03 18:33:55 --> Config Class Initialized
INFO - 2019-07-03 18:33:55 --> Loader Class Initialized
DEBUG - 2019-07-03 18:33:55 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:33:55 --> Helper loaded: url_helper
INFO - 2019-07-03 18:33:55 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:33:55 --> Helper loaded: string_helper
INFO - 2019-07-03 18:33:55 --> Helper loaded: array_helper
INFO - 2019-07-03 18:33:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:33:55 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:33:55 --> Database Driver Class Initialized
INFO - 2019-07-03 18:33:55 --> Controller Class Initialized
INFO - 2019-07-03 18:33:55 --> Config Class Initialized
INFO - 2019-07-03 18:33:55 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:33:55 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:33:55 --> Utf8 Class Initialized
INFO - 2019-07-03 18:33:55 --> URI Class Initialized
INFO - 2019-07-03 18:33:55 --> Router Class Initialized
INFO - 2019-07-03 18:33:55 --> Output Class Initialized
INFO - 2019-07-03 18:33:55 --> Security Class Initialized
DEBUG - 2019-07-03 18:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:33:55 --> Input Class Initialized
INFO - 2019-07-03 18:33:55 --> Language Class Initialized
INFO - 2019-07-03 18:33:55 --> Language Class Initialized
INFO - 2019-07-03 18:33:55 --> Config Class Initialized
INFO - 2019-07-03 18:33:55 --> Loader Class Initialized
DEBUG - 2019-07-03 18:33:55 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:33:55 --> Helper loaded: url_helper
INFO - 2019-07-03 18:33:55 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:33:55 --> Helper loaded: string_helper
INFO - 2019-07-03 18:33:55 --> Helper loaded: array_helper
INFO - 2019-07-03 18:33:56 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:33:56 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:33:56 --> Database Driver Class Initialized
INFO - 2019-07-03 18:33:56 --> Controller Class Initialized
INFO - 2019-07-03 18:33:56 --> Config Class Initialized
INFO - 2019-07-03 18:33:56 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:33:56 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:33:56 --> Utf8 Class Initialized
INFO - 2019-07-03 18:33:56 --> URI Class Initialized
INFO - 2019-07-03 18:33:56 --> Router Class Initialized
INFO - 2019-07-03 18:33:56 --> Output Class Initialized
INFO - 2019-07-03 18:33:56 --> Security Class Initialized
DEBUG - 2019-07-03 18:33:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:33:56 --> Input Class Initialized
INFO - 2019-07-03 18:33:56 --> Language Class Initialized
INFO - 2019-07-03 18:33:56 --> Language Class Initialized
INFO - 2019-07-03 18:33:56 --> Config Class Initialized
INFO - 2019-07-03 18:33:56 --> Loader Class Initialized
DEBUG - 2019-07-03 18:33:57 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:33:57 --> Helper loaded: url_helper
INFO - 2019-07-03 18:33:57 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:33:57 --> Helper loaded: string_helper
INFO - 2019-07-03 18:33:57 --> Helper loaded: array_helper
INFO - 2019-07-03 18:33:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:33:57 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:33:57 --> Database Driver Class Initialized
INFO - 2019-07-03 18:33:57 --> Controller Class Initialized
INFO - 2019-07-03 18:34:07 --> Config Class Initialized
INFO - 2019-07-03 18:34:07 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:34:07 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:34:07 --> Utf8 Class Initialized
INFO - 2019-07-03 18:34:07 --> URI Class Initialized
INFO - 2019-07-03 18:34:07 --> Router Class Initialized
INFO - 2019-07-03 18:34:07 --> Output Class Initialized
INFO - 2019-07-03 18:34:07 --> Security Class Initialized
DEBUG - 2019-07-03 18:34:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:34:07 --> Input Class Initialized
INFO - 2019-07-03 18:34:07 --> Language Class Initialized
INFO - 2019-07-03 18:34:07 --> Language Class Initialized
INFO - 2019-07-03 18:34:07 --> Config Class Initialized
INFO - 2019-07-03 18:34:07 --> Loader Class Initialized
DEBUG - 2019-07-03 18:34:07 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:34:07 --> Helper loaded: url_helper
INFO - 2019-07-03 18:34:07 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:34:07 --> Helper loaded: string_helper
INFO - 2019-07-03 18:34:07 --> Helper loaded: array_helper
INFO - 2019-07-03 18:34:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:34:07 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:34:07 --> Database Driver Class Initialized
INFO - 2019-07-03 18:34:07 --> Controller Class Initialized
INFO - 2019-07-03 18:34:07 --> Config Class Initialized
INFO - 2019-07-03 18:34:07 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:34:07 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:34:07 --> Utf8 Class Initialized
INFO - 2019-07-03 18:34:07 --> URI Class Initialized
INFO - 2019-07-03 18:34:07 --> Router Class Initialized
INFO - 2019-07-03 18:34:07 --> Output Class Initialized
INFO - 2019-07-03 18:34:07 --> Security Class Initialized
DEBUG - 2019-07-03 18:34:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:34:07 --> Input Class Initialized
INFO - 2019-07-03 18:34:07 --> Language Class Initialized
INFO - 2019-07-03 18:34:07 --> Language Class Initialized
INFO - 2019-07-03 18:34:07 --> Config Class Initialized
INFO - 2019-07-03 18:34:07 --> Loader Class Initialized
DEBUG - 2019-07-03 18:34:07 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:34:07 --> Helper loaded: url_helper
INFO - 2019-07-03 18:34:08 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:34:08 --> Helper loaded: string_helper
INFO - 2019-07-03 18:34:08 --> Helper loaded: array_helper
INFO - 2019-07-03 18:34:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:34:08 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:34:08 --> Database Driver Class Initialized
INFO - 2019-07-03 18:34:08 --> Controller Class Initialized
INFO - 2019-07-03 18:34:09 --> Config Class Initialized
INFO - 2019-07-03 18:34:09 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:34:09 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:34:09 --> Utf8 Class Initialized
INFO - 2019-07-03 18:34:09 --> URI Class Initialized
INFO - 2019-07-03 18:34:09 --> Router Class Initialized
INFO - 2019-07-03 18:34:09 --> Output Class Initialized
INFO - 2019-07-03 18:34:09 --> Security Class Initialized
DEBUG - 2019-07-03 18:34:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:34:09 --> Input Class Initialized
INFO - 2019-07-03 18:34:09 --> Language Class Initialized
INFO - 2019-07-03 18:34:09 --> Language Class Initialized
INFO - 2019-07-03 18:34:09 --> Config Class Initialized
INFO - 2019-07-03 18:34:09 --> Loader Class Initialized
DEBUG - 2019-07-03 18:34:09 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:34:09 --> Helper loaded: url_helper
INFO - 2019-07-03 18:34:09 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:34:09 --> Helper loaded: string_helper
INFO - 2019-07-03 18:34:09 --> Helper loaded: array_helper
INFO - 2019-07-03 18:34:09 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:34:09 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:34:09 --> Database Driver Class Initialized
INFO - 2019-07-03 18:34:10 --> Controller Class Initialized
INFO - 2019-07-03 18:34:34 --> Config Class Initialized
INFO - 2019-07-03 18:34:34 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:34:34 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:34:34 --> Utf8 Class Initialized
INFO - 2019-07-03 18:34:34 --> URI Class Initialized
INFO - 2019-07-03 18:34:34 --> Router Class Initialized
INFO - 2019-07-03 18:34:34 --> Output Class Initialized
INFO - 2019-07-03 18:34:34 --> Security Class Initialized
DEBUG - 2019-07-03 18:34:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:34:34 --> Input Class Initialized
INFO - 2019-07-03 18:34:34 --> Language Class Initialized
INFO - 2019-07-03 18:34:34 --> Language Class Initialized
INFO - 2019-07-03 18:34:34 --> Config Class Initialized
INFO - 2019-07-03 18:34:34 --> Loader Class Initialized
DEBUG - 2019-07-03 18:34:34 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:34:34 --> Helper loaded: url_helper
INFO - 2019-07-03 18:34:34 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:34:34 --> Helper loaded: string_helper
INFO - 2019-07-03 18:34:34 --> Helper loaded: array_helper
INFO - 2019-07-03 18:34:34 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:34:34 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:34:34 --> Database Driver Class Initialized
INFO - 2019-07-03 18:34:34 --> Controller Class Initialized
INFO - 2019-07-03 18:34:34 --> Config Class Initialized
INFO - 2019-07-03 18:34:34 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:34:34 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:34:34 --> Utf8 Class Initialized
INFO - 2019-07-03 18:34:34 --> URI Class Initialized
INFO - 2019-07-03 18:34:35 --> Router Class Initialized
INFO - 2019-07-03 18:34:35 --> Output Class Initialized
INFO - 2019-07-03 18:34:35 --> Security Class Initialized
DEBUG - 2019-07-03 18:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:34:35 --> Input Class Initialized
INFO - 2019-07-03 18:34:35 --> Language Class Initialized
INFO - 2019-07-03 18:34:35 --> Language Class Initialized
INFO - 2019-07-03 18:34:35 --> Config Class Initialized
INFO - 2019-07-03 18:34:35 --> Loader Class Initialized
DEBUG - 2019-07-03 18:34:35 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:34:35 --> Helper loaded: url_helper
INFO - 2019-07-03 18:34:35 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:34:35 --> Helper loaded: string_helper
INFO - 2019-07-03 18:34:35 --> Helper loaded: array_helper
INFO - 2019-07-03 18:34:35 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:34:35 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:34:35 --> Database Driver Class Initialized
INFO - 2019-07-03 18:34:35 --> Controller Class Initialized
INFO - 2019-07-03 18:34:46 --> Config Class Initialized
INFO - 2019-07-03 18:34:46 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:34:46 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:34:46 --> Utf8 Class Initialized
INFO - 2019-07-03 18:34:46 --> URI Class Initialized
INFO - 2019-07-03 18:34:46 --> Router Class Initialized
INFO - 2019-07-03 18:34:46 --> Output Class Initialized
INFO - 2019-07-03 18:34:46 --> Security Class Initialized
DEBUG - 2019-07-03 18:34:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:34:46 --> Input Class Initialized
INFO - 2019-07-03 18:34:46 --> Language Class Initialized
INFO - 2019-07-03 18:34:46 --> Language Class Initialized
INFO - 2019-07-03 18:34:46 --> Config Class Initialized
INFO - 2019-07-03 18:34:46 --> Loader Class Initialized
DEBUG - 2019-07-03 18:34:46 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:34:46 --> Helper loaded: url_helper
INFO - 2019-07-03 18:34:46 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:34:46 --> Helper loaded: string_helper
INFO - 2019-07-03 18:34:46 --> Helper loaded: array_helper
INFO - 2019-07-03 18:34:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:34:46 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:34:46 --> Database Driver Class Initialized
INFO - 2019-07-03 18:34:46 --> Controller Class Initialized
INFO - 2019-07-03 18:35:40 --> Config Class Initialized
INFO - 2019-07-03 18:35:40 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:35:40 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:35:40 --> Utf8 Class Initialized
INFO - 2019-07-03 18:35:40 --> URI Class Initialized
INFO - 2019-07-03 18:35:40 --> Router Class Initialized
INFO - 2019-07-03 18:35:40 --> Output Class Initialized
INFO - 2019-07-03 18:35:40 --> Security Class Initialized
DEBUG - 2019-07-03 18:35:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:35:40 --> Input Class Initialized
INFO - 2019-07-03 18:35:40 --> Language Class Initialized
INFO - 2019-07-03 18:35:40 --> Language Class Initialized
INFO - 2019-07-03 18:35:40 --> Config Class Initialized
INFO - 2019-07-03 18:35:40 --> Loader Class Initialized
DEBUG - 2019-07-03 18:35:40 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:35:40 --> Helper loaded: url_helper
INFO - 2019-07-03 18:35:40 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:35:40 --> Helper loaded: string_helper
INFO - 2019-07-03 18:35:40 --> Helper loaded: array_helper
INFO - 2019-07-03 18:35:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:35:40 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:35:40 --> Database Driver Class Initialized
INFO - 2019-07-03 18:35:40 --> Controller Class Initialized
INFO - 2019-07-03 18:35:41 --> Config Class Initialized
INFO - 2019-07-03 18:35:41 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:35:41 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:35:41 --> Utf8 Class Initialized
INFO - 2019-07-03 18:35:41 --> URI Class Initialized
INFO - 2019-07-03 18:35:41 --> Router Class Initialized
INFO - 2019-07-03 18:35:41 --> Output Class Initialized
INFO - 2019-07-03 18:35:41 --> Security Class Initialized
DEBUG - 2019-07-03 18:35:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:35:41 --> Input Class Initialized
INFO - 2019-07-03 18:35:41 --> Language Class Initialized
INFO - 2019-07-03 18:35:41 --> Language Class Initialized
INFO - 2019-07-03 18:35:41 --> Config Class Initialized
INFO - 2019-07-03 18:35:41 --> Loader Class Initialized
DEBUG - 2019-07-03 18:35:41 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:35:41 --> Helper loaded: url_helper
INFO - 2019-07-03 18:35:41 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:35:41 --> Helper loaded: string_helper
INFO - 2019-07-03 18:35:41 --> Helper loaded: array_helper
INFO - 2019-07-03 18:35:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:35:41 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:35:41 --> Database Driver Class Initialized
INFO - 2019-07-03 18:35:41 --> Controller Class Initialized
INFO - 2019-07-03 18:35:42 --> Config Class Initialized
INFO - 2019-07-03 18:35:42 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:35:42 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:35:42 --> Utf8 Class Initialized
INFO - 2019-07-03 18:35:42 --> URI Class Initialized
INFO - 2019-07-03 18:35:42 --> Router Class Initialized
INFO - 2019-07-03 18:35:42 --> Output Class Initialized
INFO - 2019-07-03 18:35:42 --> Security Class Initialized
DEBUG - 2019-07-03 18:35:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:35:42 --> Input Class Initialized
INFO - 2019-07-03 18:35:42 --> Language Class Initialized
INFO - 2019-07-03 18:35:42 --> Language Class Initialized
INFO - 2019-07-03 18:35:42 --> Config Class Initialized
INFO - 2019-07-03 18:35:42 --> Loader Class Initialized
DEBUG - 2019-07-03 18:35:42 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:35:42 --> Helper loaded: url_helper
INFO - 2019-07-03 18:35:42 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:35:42 --> Helper loaded: string_helper
INFO - 2019-07-03 18:35:42 --> Helper loaded: array_helper
INFO - 2019-07-03 18:35:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:35:42 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:35:42 --> Database Driver Class Initialized
INFO - 2019-07-03 18:35:42 --> Controller Class Initialized
INFO - 2019-07-03 18:36:58 --> Config Class Initialized
INFO - 2019-07-03 18:36:58 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:36:58 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:36:58 --> Utf8 Class Initialized
INFO - 2019-07-03 18:36:58 --> URI Class Initialized
INFO - 2019-07-03 18:36:58 --> Router Class Initialized
INFO - 2019-07-03 18:36:58 --> Output Class Initialized
INFO - 2019-07-03 18:36:58 --> Security Class Initialized
DEBUG - 2019-07-03 18:36:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:36:58 --> Input Class Initialized
INFO - 2019-07-03 18:36:58 --> Language Class Initialized
INFO - 2019-07-03 18:36:58 --> Language Class Initialized
INFO - 2019-07-03 18:36:58 --> Config Class Initialized
INFO - 2019-07-03 18:36:58 --> Loader Class Initialized
DEBUG - 2019-07-03 18:36:58 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:36:58 --> Helper loaded: url_helper
INFO - 2019-07-03 18:36:58 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:36:58 --> Helper loaded: string_helper
INFO - 2019-07-03 18:36:58 --> Helper loaded: array_helper
INFO - 2019-07-03 18:36:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:36:59 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:36:59 --> Database Driver Class Initialized
INFO - 2019-07-03 18:36:59 --> Controller Class Initialized
INFO - 2019-07-03 18:36:59 --> Config Class Initialized
INFO - 2019-07-03 18:36:59 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:36:59 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:36:59 --> Utf8 Class Initialized
INFO - 2019-07-03 18:36:59 --> URI Class Initialized
INFO - 2019-07-03 18:36:59 --> Router Class Initialized
INFO - 2019-07-03 18:36:59 --> Output Class Initialized
INFO - 2019-07-03 18:36:59 --> Security Class Initialized
DEBUG - 2019-07-03 18:36:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:36:59 --> Input Class Initialized
INFO - 2019-07-03 18:36:59 --> Language Class Initialized
INFO - 2019-07-03 18:36:59 --> Language Class Initialized
INFO - 2019-07-03 18:36:59 --> Config Class Initialized
INFO - 2019-07-03 18:36:59 --> Loader Class Initialized
DEBUG - 2019-07-03 18:36:59 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:36:59 --> Helper loaded: url_helper
INFO - 2019-07-03 18:36:59 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:36:59 --> Helper loaded: string_helper
INFO - 2019-07-03 18:36:59 --> Helper loaded: array_helper
INFO - 2019-07-03 18:36:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:36:59 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:36:59 --> Database Driver Class Initialized
INFO - 2019-07-03 18:36:59 --> Controller Class Initialized
INFO - 2019-07-03 18:37:00 --> Config Class Initialized
INFO - 2019-07-03 18:37:00 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:37:00 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:37:00 --> Utf8 Class Initialized
INFO - 2019-07-03 18:37:00 --> URI Class Initialized
INFO - 2019-07-03 18:37:00 --> Router Class Initialized
INFO - 2019-07-03 18:37:00 --> Output Class Initialized
INFO - 2019-07-03 18:37:00 --> Security Class Initialized
DEBUG - 2019-07-03 18:37:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:37:00 --> Input Class Initialized
INFO - 2019-07-03 18:37:00 --> Language Class Initialized
INFO - 2019-07-03 18:37:00 --> Language Class Initialized
INFO - 2019-07-03 18:37:00 --> Config Class Initialized
INFO - 2019-07-03 18:37:00 --> Loader Class Initialized
DEBUG - 2019-07-03 18:37:00 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:37:00 --> Helper loaded: url_helper
INFO - 2019-07-03 18:37:00 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:37:00 --> Helper loaded: string_helper
INFO - 2019-07-03 18:37:00 --> Helper loaded: array_helper
INFO - 2019-07-03 18:37:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:37:00 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:37:00 --> Database Driver Class Initialized
INFO - 2019-07-03 18:37:00 --> Controller Class Initialized
INFO - 2019-07-03 18:37:40 --> Config Class Initialized
INFO - 2019-07-03 18:37:40 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:37:40 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:37:40 --> Utf8 Class Initialized
INFO - 2019-07-03 18:37:40 --> URI Class Initialized
INFO - 2019-07-03 18:37:40 --> Router Class Initialized
INFO - 2019-07-03 18:37:40 --> Output Class Initialized
INFO - 2019-07-03 18:37:40 --> Security Class Initialized
DEBUG - 2019-07-03 18:37:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:37:40 --> Input Class Initialized
INFO - 2019-07-03 18:37:40 --> Language Class Initialized
INFO - 2019-07-03 18:37:40 --> Language Class Initialized
INFO - 2019-07-03 18:37:40 --> Config Class Initialized
INFO - 2019-07-03 18:37:40 --> Loader Class Initialized
DEBUG - 2019-07-03 18:37:41 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:37:41 --> Helper loaded: url_helper
INFO - 2019-07-03 18:37:41 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:37:41 --> Helper loaded: string_helper
INFO - 2019-07-03 18:37:41 --> Helper loaded: array_helper
INFO - 2019-07-03 18:37:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:37:41 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:37:41 --> Database Driver Class Initialized
INFO - 2019-07-03 18:37:41 --> Controller Class Initialized
INFO - 2019-07-03 18:37:41 --> Config Class Initialized
INFO - 2019-07-03 18:37:41 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:37:41 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:37:41 --> Utf8 Class Initialized
INFO - 2019-07-03 18:37:41 --> URI Class Initialized
INFO - 2019-07-03 18:37:41 --> Router Class Initialized
INFO - 2019-07-03 18:37:41 --> Output Class Initialized
INFO - 2019-07-03 18:37:41 --> Security Class Initialized
DEBUG - 2019-07-03 18:37:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:37:41 --> Input Class Initialized
INFO - 2019-07-03 18:37:41 --> Language Class Initialized
INFO - 2019-07-03 18:37:41 --> Language Class Initialized
INFO - 2019-07-03 18:37:41 --> Config Class Initialized
INFO - 2019-07-03 18:37:41 --> Loader Class Initialized
DEBUG - 2019-07-03 18:37:41 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:37:41 --> Helper loaded: url_helper
INFO - 2019-07-03 18:37:41 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:37:41 --> Helper loaded: string_helper
INFO - 2019-07-03 18:37:41 --> Helper loaded: array_helper
INFO - 2019-07-03 18:37:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:37:41 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:37:41 --> Database Driver Class Initialized
INFO - 2019-07-03 18:37:41 --> Controller Class Initialized
INFO - 2019-07-03 18:37:42 --> Config Class Initialized
INFO - 2019-07-03 18:37:42 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:37:42 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:37:42 --> Utf8 Class Initialized
INFO - 2019-07-03 18:37:42 --> URI Class Initialized
INFO - 2019-07-03 18:37:42 --> Router Class Initialized
INFO - 2019-07-03 18:37:42 --> Output Class Initialized
INFO - 2019-07-03 18:37:42 --> Security Class Initialized
DEBUG - 2019-07-03 18:37:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:37:42 --> Input Class Initialized
INFO - 2019-07-03 18:37:42 --> Language Class Initialized
INFO - 2019-07-03 18:37:42 --> Language Class Initialized
INFO - 2019-07-03 18:37:42 --> Config Class Initialized
INFO - 2019-07-03 18:37:42 --> Loader Class Initialized
DEBUG - 2019-07-03 18:37:42 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:37:42 --> Helper loaded: url_helper
INFO - 2019-07-03 18:37:42 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:37:42 --> Helper loaded: string_helper
INFO - 2019-07-03 18:37:42 --> Helper loaded: array_helper
INFO - 2019-07-03 18:37:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:37:42 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:37:42 --> Database Driver Class Initialized
INFO - 2019-07-03 18:37:42 --> Controller Class Initialized
INFO - 2019-07-03 18:37:52 --> Config Class Initialized
INFO - 2019-07-03 18:37:52 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:37:52 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:37:52 --> Utf8 Class Initialized
INFO - 2019-07-03 18:37:52 --> URI Class Initialized
INFO - 2019-07-03 18:37:52 --> Router Class Initialized
INFO - 2019-07-03 18:37:52 --> Output Class Initialized
INFO - 2019-07-03 18:37:53 --> Security Class Initialized
DEBUG - 2019-07-03 18:37:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:37:53 --> Input Class Initialized
INFO - 2019-07-03 18:37:53 --> Language Class Initialized
INFO - 2019-07-03 18:37:53 --> Language Class Initialized
INFO - 2019-07-03 18:37:53 --> Config Class Initialized
INFO - 2019-07-03 18:37:53 --> Loader Class Initialized
DEBUG - 2019-07-03 18:37:53 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:37:53 --> Helper loaded: url_helper
INFO - 2019-07-03 18:37:53 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:37:53 --> Helper loaded: string_helper
INFO - 2019-07-03 18:37:53 --> Helper loaded: array_helper
INFO - 2019-07-03 18:37:53 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:37:53 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:37:53 --> Database Driver Class Initialized
INFO - 2019-07-03 18:37:53 --> Controller Class Initialized
INFO - 2019-07-03 18:37:53 --> Config Class Initialized
INFO - 2019-07-03 18:37:53 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:37:53 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:37:53 --> Utf8 Class Initialized
INFO - 2019-07-03 18:37:53 --> URI Class Initialized
INFO - 2019-07-03 18:37:53 --> Router Class Initialized
INFO - 2019-07-03 18:37:53 --> Output Class Initialized
INFO - 2019-07-03 18:37:53 --> Security Class Initialized
DEBUG - 2019-07-03 18:37:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:37:53 --> Input Class Initialized
INFO - 2019-07-03 18:37:53 --> Language Class Initialized
INFO - 2019-07-03 18:37:53 --> Language Class Initialized
INFO - 2019-07-03 18:37:53 --> Config Class Initialized
INFO - 2019-07-03 18:37:53 --> Loader Class Initialized
DEBUG - 2019-07-03 18:37:53 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:37:53 --> Helper loaded: url_helper
INFO - 2019-07-03 18:37:53 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:37:53 --> Helper loaded: string_helper
INFO - 2019-07-03 18:37:53 --> Helper loaded: array_helper
INFO - 2019-07-03 18:37:53 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:37:53 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:37:53 --> Database Driver Class Initialized
INFO - 2019-07-03 18:37:53 --> Controller Class Initialized
INFO - 2019-07-03 18:38:14 --> Config Class Initialized
INFO - 2019-07-03 18:38:14 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:38:14 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:38:14 --> Utf8 Class Initialized
INFO - 2019-07-03 18:38:14 --> URI Class Initialized
INFO - 2019-07-03 18:38:14 --> Router Class Initialized
INFO - 2019-07-03 18:38:14 --> Output Class Initialized
INFO - 2019-07-03 18:38:14 --> Security Class Initialized
DEBUG - 2019-07-03 18:38:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:38:14 --> Input Class Initialized
INFO - 2019-07-03 18:38:14 --> Language Class Initialized
INFO - 2019-07-03 18:38:14 --> Language Class Initialized
INFO - 2019-07-03 18:38:14 --> Config Class Initialized
INFO - 2019-07-03 18:38:14 --> Loader Class Initialized
DEBUG - 2019-07-03 18:38:14 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:38:14 --> Helper loaded: url_helper
INFO - 2019-07-03 18:38:14 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:38:14 --> Helper loaded: string_helper
INFO - 2019-07-03 18:38:14 --> Helper loaded: array_helper
INFO - 2019-07-03 18:38:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:38:14 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:38:14 --> Database Driver Class Initialized
INFO - 2019-07-03 18:38:14 --> Controller Class Initialized
INFO - 2019-07-03 18:38:14 --> Config Class Initialized
INFO - 2019-07-03 18:38:14 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:38:14 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:38:14 --> Utf8 Class Initialized
INFO - 2019-07-03 18:38:14 --> URI Class Initialized
INFO - 2019-07-03 18:38:14 --> Router Class Initialized
INFO - 2019-07-03 18:38:14 --> Output Class Initialized
INFO - 2019-07-03 18:38:14 --> Security Class Initialized
DEBUG - 2019-07-03 18:38:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:38:14 --> Input Class Initialized
INFO - 2019-07-03 18:38:14 --> Language Class Initialized
INFO - 2019-07-03 18:38:14 --> Language Class Initialized
INFO - 2019-07-03 18:38:14 --> Config Class Initialized
INFO - 2019-07-03 18:38:14 --> Loader Class Initialized
DEBUG - 2019-07-03 18:38:14 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:38:14 --> Helper loaded: url_helper
INFO - 2019-07-03 18:38:14 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:38:14 --> Helper loaded: string_helper
INFO - 2019-07-03 18:38:14 --> Helper loaded: array_helper
INFO - 2019-07-03 18:38:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:38:14 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:38:15 --> Database Driver Class Initialized
INFO - 2019-07-03 18:38:15 --> Controller Class Initialized
INFO - 2019-07-03 18:38:15 --> Config Class Initialized
INFO - 2019-07-03 18:38:15 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:38:15 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:38:15 --> Utf8 Class Initialized
INFO - 2019-07-03 18:38:15 --> URI Class Initialized
INFO - 2019-07-03 18:38:15 --> Router Class Initialized
INFO - 2019-07-03 18:38:15 --> Output Class Initialized
INFO - 2019-07-03 18:38:15 --> Security Class Initialized
DEBUG - 2019-07-03 18:38:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:38:15 --> Input Class Initialized
INFO - 2019-07-03 18:38:15 --> Language Class Initialized
INFO - 2019-07-03 18:38:15 --> Language Class Initialized
INFO - 2019-07-03 18:38:15 --> Config Class Initialized
INFO - 2019-07-03 18:38:15 --> Loader Class Initialized
DEBUG - 2019-07-03 18:38:15 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:38:15 --> Helper loaded: url_helper
INFO - 2019-07-03 18:38:15 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:38:15 --> Helper loaded: string_helper
INFO - 2019-07-03 18:38:15 --> Helper loaded: array_helper
INFO - 2019-07-03 18:38:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:38:16 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:38:16 --> Database Driver Class Initialized
INFO - 2019-07-03 18:38:16 --> Controller Class Initialized
INFO - 2019-07-03 18:38:41 --> Config Class Initialized
INFO - 2019-07-03 18:38:41 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:38:41 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:38:41 --> Utf8 Class Initialized
INFO - 2019-07-03 18:38:41 --> URI Class Initialized
INFO - 2019-07-03 18:38:41 --> Router Class Initialized
INFO - 2019-07-03 18:38:41 --> Output Class Initialized
INFO - 2019-07-03 18:38:41 --> Security Class Initialized
DEBUG - 2019-07-03 18:38:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:38:41 --> Input Class Initialized
INFO - 2019-07-03 18:38:41 --> Language Class Initialized
INFO - 2019-07-03 18:38:41 --> Language Class Initialized
INFO - 2019-07-03 18:38:41 --> Config Class Initialized
INFO - 2019-07-03 18:38:41 --> Loader Class Initialized
DEBUG - 2019-07-03 18:38:41 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:38:41 --> Helper loaded: url_helper
INFO - 2019-07-03 18:38:41 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:38:41 --> Helper loaded: string_helper
INFO - 2019-07-03 18:38:41 --> Helper loaded: array_helper
INFO - 2019-07-03 18:38:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:38:41 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:38:41 --> Database Driver Class Initialized
INFO - 2019-07-03 18:38:41 --> Controller Class Initialized
INFO - 2019-07-03 18:38:41 --> Config Class Initialized
INFO - 2019-07-03 18:38:41 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:38:41 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:38:41 --> Utf8 Class Initialized
INFO - 2019-07-03 18:38:41 --> URI Class Initialized
INFO - 2019-07-03 18:38:41 --> Router Class Initialized
INFO - 2019-07-03 18:38:41 --> Output Class Initialized
INFO - 2019-07-03 18:38:41 --> Security Class Initialized
DEBUG - 2019-07-03 18:38:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:38:41 --> Input Class Initialized
INFO - 2019-07-03 18:38:41 --> Language Class Initialized
INFO - 2019-07-03 18:38:41 --> Language Class Initialized
INFO - 2019-07-03 18:38:41 --> Config Class Initialized
INFO - 2019-07-03 18:38:41 --> Loader Class Initialized
DEBUG - 2019-07-03 18:38:41 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:38:41 --> Helper loaded: url_helper
INFO - 2019-07-03 18:38:41 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:38:42 --> Helper loaded: string_helper
INFO - 2019-07-03 18:38:42 --> Helper loaded: array_helper
INFO - 2019-07-03 18:38:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:38:42 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:38:42 --> Database Driver Class Initialized
INFO - 2019-07-03 18:38:42 --> Controller Class Initialized
INFO - 2019-07-03 18:38:42 --> Config Class Initialized
INFO - 2019-07-03 18:38:42 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:38:42 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:38:42 --> Utf8 Class Initialized
INFO - 2019-07-03 18:38:42 --> URI Class Initialized
INFO - 2019-07-03 18:38:43 --> Router Class Initialized
INFO - 2019-07-03 18:38:43 --> Output Class Initialized
INFO - 2019-07-03 18:38:43 --> Security Class Initialized
DEBUG - 2019-07-03 18:38:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:38:43 --> Input Class Initialized
INFO - 2019-07-03 18:38:43 --> Language Class Initialized
INFO - 2019-07-03 18:38:43 --> Language Class Initialized
INFO - 2019-07-03 18:38:43 --> Config Class Initialized
INFO - 2019-07-03 18:38:43 --> Loader Class Initialized
DEBUG - 2019-07-03 18:38:43 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:38:43 --> Helper loaded: url_helper
INFO - 2019-07-03 18:38:43 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:38:43 --> Helper loaded: string_helper
INFO - 2019-07-03 18:38:43 --> Helper loaded: array_helper
INFO - 2019-07-03 18:38:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:38:43 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:38:43 --> Database Driver Class Initialized
INFO - 2019-07-03 18:38:43 --> Controller Class Initialized
INFO - 2019-07-03 18:38:53 --> Config Class Initialized
INFO - 2019-07-03 18:38:53 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:38:53 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:38:53 --> Utf8 Class Initialized
INFO - 2019-07-03 18:38:53 --> URI Class Initialized
INFO - 2019-07-03 18:38:53 --> Router Class Initialized
INFO - 2019-07-03 18:38:53 --> Output Class Initialized
INFO - 2019-07-03 18:38:53 --> Security Class Initialized
DEBUG - 2019-07-03 18:38:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:38:53 --> Input Class Initialized
INFO - 2019-07-03 18:38:53 --> Language Class Initialized
INFO - 2019-07-03 18:38:53 --> Language Class Initialized
INFO - 2019-07-03 18:38:53 --> Config Class Initialized
INFO - 2019-07-03 18:38:53 --> Loader Class Initialized
DEBUG - 2019-07-03 18:38:53 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:38:53 --> Helper loaded: url_helper
INFO - 2019-07-03 18:38:53 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:38:53 --> Helper loaded: string_helper
INFO - 2019-07-03 18:38:53 --> Helper loaded: array_helper
INFO - 2019-07-03 18:38:53 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:38:53 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:38:53 --> Database Driver Class Initialized
INFO - 2019-07-03 18:38:53 --> Controller Class Initialized
INFO - 2019-07-03 18:38:53 --> Config Class Initialized
INFO - 2019-07-03 18:38:53 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:38:53 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:38:53 --> Utf8 Class Initialized
INFO - 2019-07-03 18:38:53 --> URI Class Initialized
INFO - 2019-07-03 18:38:53 --> Router Class Initialized
INFO - 2019-07-03 18:38:53 --> Output Class Initialized
INFO - 2019-07-03 18:38:54 --> Security Class Initialized
DEBUG - 2019-07-03 18:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:38:54 --> Input Class Initialized
INFO - 2019-07-03 18:38:54 --> Language Class Initialized
INFO - 2019-07-03 18:38:54 --> Language Class Initialized
INFO - 2019-07-03 18:38:54 --> Config Class Initialized
INFO - 2019-07-03 18:38:54 --> Loader Class Initialized
DEBUG - 2019-07-03 18:38:54 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:38:54 --> Helper loaded: url_helper
INFO - 2019-07-03 18:38:54 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:38:54 --> Helper loaded: string_helper
INFO - 2019-07-03 18:38:54 --> Helper loaded: array_helper
INFO - 2019-07-03 18:38:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:38:54 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:38:54 --> Database Driver Class Initialized
INFO - 2019-07-03 18:38:54 --> Controller Class Initialized
INFO - 2019-07-03 18:38:54 --> Config Class Initialized
INFO - 2019-07-03 18:38:54 --> Hooks Class Initialized
DEBUG - 2019-07-03 18:38:54 --> UTF-8 Support Enabled
INFO - 2019-07-03 18:38:55 --> Utf8 Class Initialized
INFO - 2019-07-03 18:38:55 --> URI Class Initialized
INFO - 2019-07-03 18:38:55 --> Router Class Initialized
INFO - 2019-07-03 18:38:55 --> Output Class Initialized
INFO - 2019-07-03 18:38:55 --> Security Class Initialized
DEBUG - 2019-07-03 18:38:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 18:38:55 --> Input Class Initialized
INFO - 2019-07-03 18:38:55 --> Language Class Initialized
INFO - 2019-07-03 18:38:55 --> Language Class Initialized
INFO - 2019-07-03 18:38:55 --> Config Class Initialized
INFO - 2019-07-03 18:38:55 --> Loader Class Initialized
DEBUG - 2019-07-03 18:38:55 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 18:38:55 --> Helper loaded: url_helper
INFO - 2019-07-03 18:38:55 --> Helper loaded: inflector_helper
INFO - 2019-07-03 18:38:55 --> Helper loaded: string_helper
INFO - 2019-07-03 18:38:55 --> Helper loaded: array_helper
INFO - 2019-07-03 18:38:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 18:38:55 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 18:38:55 --> Database Driver Class Initialized
INFO - 2019-07-03 18:38:55 --> Controller Class Initialized
INFO - 2019-07-03 19:00:56 --> Config Class Initialized
INFO - 2019-07-03 19:00:56 --> Hooks Class Initialized
DEBUG - 2019-07-03 19:00:56 --> UTF-8 Support Enabled
INFO - 2019-07-03 19:00:56 --> Utf8 Class Initialized
INFO - 2019-07-03 19:00:56 --> URI Class Initialized
INFO - 2019-07-03 19:00:56 --> Router Class Initialized
INFO - 2019-07-03 19:00:56 --> Output Class Initialized
INFO - 2019-07-03 19:00:56 --> Security Class Initialized
DEBUG - 2019-07-03 19:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 19:00:56 --> Input Class Initialized
INFO - 2019-07-03 19:00:56 --> Language Class Initialized
INFO - 2019-07-03 19:00:56 --> Language Class Initialized
INFO - 2019-07-03 19:00:56 --> Config Class Initialized
INFO - 2019-07-03 19:00:56 --> Loader Class Initialized
DEBUG - 2019-07-03 19:00:56 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 19:00:56 --> Helper loaded: url_helper
INFO - 2019-07-03 19:00:56 --> Helper loaded: inflector_helper
INFO - 2019-07-03 19:00:56 --> Helper loaded: string_helper
INFO - 2019-07-03 19:00:56 --> Helper loaded: array_helper
INFO - 2019-07-03 19:00:56 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 19:00:56 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 19:00:56 --> Database Driver Class Initialized
INFO - 2019-07-03 19:00:56 --> Controller Class Initialized
INFO - 2019-07-03 19:00:56 --> Config Class Initialized
INFO - 2019-07-03 19:00:56 --> Config Class Initialized
INFO - 2019-07-03 19:00:56 --> Hooks Class Initialized
INFO - 2019-07-03 19:00:56 --> Hooks Class Initialized
DEBUG - 2019-07-03 19:00:56 --> UTF-8 Support Enabled
DEBUG - 2019-07-03 19:00:56 --> UTF-8 Support Enabled
INFO - 2019-07-03 19:00:56 --> Utf8 Class Initialized
INFO - 2019-07-03 19:00:56 --> Utf8 Class Initialized
INFO - 2019-07-03 19:00:56 --> URI Class Initialized
INFO - 2019-07-03 19:00:56 --> URI Class Initialized
INFO - 2019-07-03 19:00:56 --> Router Class Initialized
INFO - 2019-07-03 19:00:56 --> Router Class Initialized
INFO - 2019-07-03 19:00:56 --> Output Class Initialized
INFO - 2019-07-03 19:00:57 --> Output Class Initialized
INFO - 2019-07-03 19:00:57 --> Security Class Initialized
INFO - 2019-07-03 19:00:57 --> Security Class Initialized
DEBUG - 2019-07-03 19:00:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-03 19:00:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 19:00:57 --> Input Class Initialized
INFO - 2019-07-03 19:00:57 --> Input Class Initialized
INFO - 2019-07-03 19:00:57 --> Language Class Initialized
INFO - 2019-07-03 19:00:57 --> Language Class Initialized
INFO - 2019-07-03 19:00:57 --> Language Class Initialized
INFO - 2019-07-03 19:00:57 --> Language Class Initialized
INFO - 2019-07-03 19:00:57 --> Config Class Initialized
INFO - 2019-07-03 19:00:57 --> Loader Class Initialized
INFO - 2019-07-03 19:00:57 --> Config Class Initialized
INFO - 2019-07-03 19:00:57 --> Loader Class Initialized
DEBUG - 2019-07-03 19:00:57 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-03 19:00:57 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 19:00:57 --> Helper loaded: url_helper
INFO - 2019-07-03 19:00:57 --> Helper loaded: url_helper
INFO - 2019-07-03 19:00:57 --> Helper loaded: inflector_helper
INFO - 2019-07-03 19:00:57 --> Helper loaded: inflector_helper
INFO - 2019-07-03 19:00:57 --> Helper loaded: string_helper
INFO - 2019-07-03 19:00:57 --> Helper loaded: string_helper
INFO - 2019-07-03 19:00:57 --> Helper loaded: array_helper
INFO - 2019-07-03 19:00:57 --> Helper loaded: array_helper
INFO - 2019-07-03 19:00:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 19:00:57 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 19:00:57 --> Database Driver Class Initialized
INFO - 2019-07-03 19:00:57 --> Controller Class Initialized
INFO - 2019-07-03 19:00:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 19:00:57 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 19:00:57 --> Database Driver Class Initialized
INFO - 2019-07-03 19:00:57 --> Controller Class Initialized
INFO - 2019-07-03 19:00:59 --> Config Class Initialized
INFO - 2019-07-03 19:00:59 --> Hooks Class Initialized
DEBUG - 2019-07-03 19:00:59 --> UTF-8 Support Enabled
INFO - 2019-07-03 19:00:59 --> Utf8 Class Initialized
INFO - 2019-07-03 19:00:59 --> URI Class Initialized
INFO - 2019-07-03 19:00:59 --> Router Class Initialized
INFO - 2019-07-03 19:00:59 --> Output Class Initialized
INFO - 2019-07-03 19:00:59 --> Security Class Initialized
DEBUG - 2019-07-03 19:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 19:00:59 --> Input Class Initialized
INFO - 2019-07-03 19:00:59 --> Language Class Initialized
INFO - 2019-07-03 19:00:59 --> Language Class Initialized
INFO - 2019-07-03 19:00:59 --> Config Class Initialized
INFO - 2019-07-03 19:00:59 --> Loader Class Initialized
DEBUG - 2019-07-03 19:00:59 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 19:00:59 --> Helper loaded: url_helper
INFO - 2019-07-03 19:00:59 --> Helper loaded: inflector_helper
INFO - 2019-07-03 19:00:59 --> Helper loaded: string_helper
INFO - 2019-07-03 19:00:59 --> Helper loaded: array_helper
INFO - 2019-07-03 19:00:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 19:00:59 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 19:00:59 --> Database Driver Class Initialized
INFO - 2019-07-03 19:00:59 --> Controller Class Initialized
INFO - 2019-07-03 19:01:05 --> Config Class Initialized
INFO - 2019-07-03 19:01:05 --> Hooks Class Initialized
DEBUG - 2019-07-03 19:01:05 --> UTF-8 Support Enabled
INFO - 2019-07-03 19:01:05 --> Utf8 Class Initialized
INFO - 2019-07-03 19:01:05 --> URI Class Initialized
INFO - 2019-07-03 19:01:05 --> Router Class Initialized
INFO - 2019-07-03 19:01:05 --> Output Class Initialized
INFO - 2019-07-03 19:01:05 --> Security Class Initialized
DEBUG - 2019-07-03 19:01:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 19:01:05 --> Input Class Initialized
INFO - 2019-07-03 19:01:05 --> Language Class Initialized
INFO - 2019-07-03 19:01:05 --> Language Class Initialized
INFO - 2019-07-03 19:01:05 --> Config Class Initialized
INFO - 2019-07-03 19:01:05 --> Loader Class Initialized
DEBUG - 2019-07-03 19:01:05 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 19:01:05 --> Helper loaded: url_helper
INFO - 2019-07-03 19:01:05 --> Helper loaded: inflector_helper
INFO - 2019-07-03 19:01:05 --> Helper loaded: string_helper
INFO - 2019-07-03 19:01:05 --> Helper loaded: array_helper
INFO - 2019-07-03 19:01:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 19:01:05 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 19:01:05 --> Database Driver Class Initialized
INFO - 2019-07-03 19:01:05 --> Controller Class Initialized
INFO - 2019-07-03 19:01:05 --> Config Class Initialized
INFO - 2019-07-03 19:01:05 --> Hooks Class Initialized
DEBUG - 2019-07-03 19:01:05 --> UTF-8 Support Enabled
INFO - 2019-07-03 19:01:05 --> Utf8 Class Initialized
INFO - 2019-07-03 19:01:05 --> URI Class Initialized
INFO - 2019-07-03 19:01:05 --> Router Class Initialized
INFO - 2019-07-03 19:01:05 --> Output Class Initialized
INFO - 2019-07-03 19:01:05 --> Security Class Initialized
DEBUG - 2019-07-03 19:01:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 19:01:05 --> Input Class Initialized
INFO - 2019-07-03 19:01:05 --> Language Class Initialized
INFO - 2019-07-03 19:01:05 --> Language Class Initialized
INFO - 2019-07-03 19:01:05 --> Config Class Initialized
INFO - 2019-07-03 19:01:05 --> Loader Class Initialized
DEBUG - 2019-07-03 19:01:06 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 19:01:06 --> Helper loaded: url_helper
INFO - 2019-07-03 19:01:06 --> Helper loaded: inflector_helper
INFO - 2019-07-03 19:01:06 --> Helper loaded: string_helper
INFO - 2019-07-03 19:01:06 --> Helper loaded: array_helper
INFO - 2019-07-03 19:01:06 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 19:01:06 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 19:01:06 --> Database Driver Class Initialized
INFO - 2019-07-03 19:01:06 --> Controller Class Initialized
INFO - 2019-07-03 19:01:09 --> Config Class Initialized
INFO - 2019-07-03 19:01:09 --> Hooks Class Initialized
DEBUG - 2019-07-03 19:01:09 --> UTF-8 Support Enabled
INFO - 2019-07-03 19:01:09 --> Utf8 Class Initialized
INFO - 2019-07-03 19:01:09 --> URI Class Initialized
INFO - 2019-07-03 19:01:09 --> Router Class Initialized
INFO - 2019-07-03 19:01:09 --> Output Class Initialized
INFO - 2019-07-03 19:01:09 --> Security Class Initialized
DEBUG - 2019-07-03 19:01:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 19:01:09 --> Input Class Initialized
INFO - 2019-07-03 19:01:09 --> Language Class Initialized
INFO - 2019-07-03 19:01:09 --> Language Class Initialized
INFO - 2019-07-03 19:01:09 --> Config Class Initialized
INFO - 2019-07-03 19:01:09 --> Loader Class Initialized
DEBUG - 2019-07-03 19:01:09 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 19:01:09 --> Helper loaded: url_helper
INFO - 2019-07-03 19:01:09 --> Helper loaded: inflector_helper
INFO - 2019-07-03 19:01:09 --> Helper loaded: string_helper
INFO - 2019-07-03 19:01:09 --> Helper loaded: array_helper
INFO - 2019-07-03 19:01:09 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 19:01:09 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 19:01:09 --> Database Driver Class Initialized
INFO - 2019-07-03 19:01:09 --> Controller Class Initialized
INFO - 2019-07-03 19:01:12 --> Config Class Initialized
INFO - 2019-07-03 19:01:13 --> Hooks Class Initialized
DEBUG - 2019-07-03 19:01:13 --> UTF-8 Support Enabled
INFO - 2019-07-03 19:01:13 --> Utf8 Class Initialized
INFO - 2019-07-03 19:01:13 --> URI Class Initialized
INFO - 2019-07-03 19:01:13 --> Router Class Initialized
INFO - 2019-07-03 19:01:13 --> Output Class Initialized
INFO - 2019-07-03 19:01:13 --> Security Class Initialized
DEBUG - 2019-07-03 19:01:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 19:01:13 --> Input Class Initialized
INFO - 2019-07-03 19:01:13 --> Language Class Initialized
INFO - 2019-07-03 19:01:13 --> Language Class Initialized
INFO - 2019-07-03 19:01:13 --> Config Class Initialized
INFO - 2019-07-03 19:01:13 --> Loader Class Initialized
DEBUG - 2019-07-03 19:01:13 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 19:01:13 --> Helper loaded: url_helper
INFO - 2019-07-03 19:01:13 --> Helper loaded: inflector_helper
INFO - 2019-07-03 19:01:13 --> Helper loaded: string_helper
INFO - 2019-07-03 19:01:13 --> Helper loaded: array_helper
INFO - 2019-07-03 19:01:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 19:01:13 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 19:01:13 --> Database Driver Class Initialized
INFO - 2019-07-03 19:01:13 --> Controller Class Initialized
INFO - 2019-07-03 19:01:13 --> Config Class Initialized
INFO - 2019-07-03 19:01:13 --> Hooks Class Initialized
DEBUG - 2019-07-03 19:01:13 --> UTF-8 Support Enabled
INFO - 2019-07-03 19:01:13 --> Utf8 Class Initialized
INFO - 2019-07-03 19:01:13 --> URI Class Initialized
INFO - 2019-07-03 19:01:13 --> Router Class Initialized
INFO - 2019-07-03 19:01:13 --> Output Class Initialized
INFO - 2019-07-03 19:01:13 --> Security Class Initialized
DEBUG - 2019-07-03 19:01:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 19:01:13 --> Input Class Initialized
INFO - 2019-07-03 19:01:13 --> Language Class Initialized
INFO - 2019-07-03 19:01:13 --> Language Class Initialized
INFO - 2019-07-03 19:01:13 --> Config Class Initialized
INFO - 2019-07-03 19:01:13 --> Loader Class Initialized
DEBUG - 2019-07-03 19:01:13 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 19:01:13 --> Helper loaded: url_helper
INFO - 2019-07-03 19:01:13 --> Helper loaded: inflector_helper
INFO - 2019-07-03 19:01:13 --> Helper loaded: string_helper
INFO - 2019-07-03 19:01:13 --> Helper loaded: array_helper
INFO - 2019-07-03 19:01:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 19:01:13 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 19:01:13 --> Database Driver Class Initialized
INFO - 2019-07-03 19:01:13 --> Controller Class Initialized
INFO - 2019-07-03 19:01:46 --> Config Class Initialized
INFO - 2019-07-03 19:01:46 --> Hooks Class Initialized
DEBUG - 2019-07-03 19:01:46 --> UTF-8 Support Enabled
INFO - 2019-07-03 19:01:46 --> Utf8 Class Initialized
INFO - 2019-07-03 19:01:46 --> URI Class Initialized
INFO - 2019-07-03 19:01:46 --> Router Class Initialized
INFO - 2019-07-03 19:01:46 --> Output Class Initialized
INFO - 2019-07-03 19:01:46 --> Security Class Initialized
DEBUG - 2019-07-03 19:01:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 19:01:46 --> Input Class Initialized
INFO - 2019-07-03 19:01:46 --> Language Class Initialized
INFO - 2019-07-03 19:01:46 --> Language Class Initialized
INFO - 2019-07-03 19:01:46 --> Config Class Initialized
INFO - 2019-07-03 19:01:46 --> Loader Class Initialized
DEBUG - 2019-07-03 19:01:46 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 19:01:46 --> Helper loaded: url_helper
INFO - 2019-07-03 19:01:46 --> Helper loaded: inflector_helper
INFO - 2019-07-03 19:01:46 --> Helper loaded: string_helper
INFO - 2019-07-03 19:01:46 --> Helper loaded: array_helper
INFO - 2019-07-03 19:01:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 19:01:46 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 19:01:46 --> Database Driver Class Initialized
INFO - 2019-07-03 19:01:46 --> Controller Class Initialized
INFO - 2019-07-03 19:01:47 --> Config Class Initialized
INFO - 2019-07-03 19:01:47 --> Hooks Class Initialized
DEBUG - 2019-07-03 19:01:47 --> UTF-8 Support Enabled
INFO - 2019-07-03 19:01:47 --> Utf8 Class Initialized
INFO - 2019-07-03 19:01:47 --> URI Class Initialized
INFO - 2019-07-03 19:01:47 --> Router Class Initialized
INFO - 2019-07-03 19:01:47 --> Output Class Initialized
INFO - 2019-07-03 19:01:47 --> Security Class Initialized
DEBUG - 2019-07-03 19:01:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 19:01:47 --> Input Class Initialized
INFO - 2019-07-03 19:01:47 --> Language Class Initialized
INFO - 2019-07-03 19:01:47 --> Language Class Initialized
INFO - 2019-07-03 19:01:47 --> Config Class Initialized
INFO - 2019-07-03 19:01:47 --> Loader Class Initialized
DEBUG - 2019-07-03 19:01:47 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 19:01:47 --> Helper loaded: url_helper
INFO - 2019-07-03 19:01:47 --> Helper loaded: inflector_helper
INFO - 2019-07-03 19:01:47 --> Helper loaded: string_helper
INFO - 2019-07-03 19:01:47 --> Helper loaded: array_helper
INFO - 2019-07-03 19:01:47 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 19:01:47 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 19:01:47 --> Database Driver Class Initialized
INFO - 2019-07-03 19:01:47 --> Controller Class Initialized
INFO - 2019-07-03 19:01:49 --> Config Class Initialized
INFO - 2019-07-03 19:01:49 --> Hooks Class Initialized
DEBUG - 2019-07-03 19:01:49 --> UTF-8 Support Enabled
INFO - 2019-07-03 19:01:49 --> Utf8 Class Initialized
INFO - 2019-07-03 19:01:49 --> URI Class Initialized
INFO - 2019-07-03 19:01:49 --> Router Class Initialized
INFO - 2019-07-03 19:01:49 --> Output Class Initialized
INFO - 2019-07-03 19:01:49 --> Security Class Initialized
DEBUG - 2019-07-03 19:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 19:01:49 --> Input Class Initialized
INFO - 2019-07-03 19:01:49 --> Language Class Initialized
INFO - 2019-07-03 19:01:49 --> Language Class Initialized
INFO - 2019-07-03 19:01:49 --> Config Class Initialized
INFO - 2019-07-03 19:01:49 --> Loader Class Initialized
DEBUG - 2019-07-03 19:01:49 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 19:01:49 --> Helper loaded: url_helper
INFO - 2019-07-03 19:01:49 --> Helper loaded: inflector_helper
INFO - 2019-07-03 19:01:49 --> Helper loaded: string_helper
INFO - 2019-07-03 19:01:49 --> Helper loaded: array_helper
INFO - 2019-07-03 19:01:49 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 19:01:49 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 19:01:49 --> Database Driver Class Initialized
INFO - 2019-07-03 19:01:49 --> Controller Class Initialized
INFO - 2019-07-03 19:01:52 --> Config Class Initialized
INFO - 2019-07-03 19:01:52 --> Hooks Class Initialized
DEBUG - 2019-07-03 19:01:52 --> UTF-8 Support Enabled
INFO - 2019-07-03 19:01:52 --> Utf8 Class Initialized
INFO - 2019-07-03 19:01:52 --> URI Class Initialized
INFO - 2019-07-03 19:01:52 --> Router Class Initialized
INFO - 2019-07-03 19:01:52 --> Output Class Initialized
INFO - 2019-07-03 19:01:52 --> Security Class Initialized
DEBUG - 2019-07-03 19:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 19:01:52 --> Input Class Initialized
INFO - 2019-07-03 19:01:52 --> Language Class Initialized
INFO - 2019-07-03 19:01:52 --> Language Class Initialized
INFO - 2019-07-03 19:01:52 --> Config Class Initialized
INFO - 2019-07-03 19:01:52 --> Loader Class Initialized
DEBUG - 2019-07-03 19:01:52 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 19:01:52 --> Helper loaded: url_helper
INFO - 2019-07-03 19:01:52 --> Helper loaded: inflector_helper
INFO - 2019-07-03 19:01:52 --> Helper loaded: string_helper
INFO - 2019-07-03 19:01:52 --> Helper loaded: array_helper
INFO - 2019-07-03 19:01:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 19:01:52 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 19:01:52 --> Database Driver Class Initialized
INFO - 2019-07-03 19:01:52 --> Controller Class Initialized
INFO - 2019-07-03 19:01:55 --> Config Class Initialized
INFO - 2019-07-03 19:01:55 --> Hooks Class Initialized
DEBUG - 2019-07-03 19:01:55 --> UTF-8 Support Enabled
INFO - 2019-07-03 19:01:55 --> Utf8 Class Initialized
INFO - 2019-07-03 19:01:55 --> URI Class Initialized
INFO - 2019-07-03 19:01:55 --> Router Class Initialized
INFO - 2019-07-03 19:01:55 --> Output Class Initialized
INFO - 2019-07-03 19:01:55 --> Security Class Initialized
DEBUG - 2019-07-03 19:01:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 19:01:55 --> Input Class Initialized
INFO - 2019-07-03 19:01:55 --> Language Class Initialized
INFO - 2019-07-03 19:01:55 --> Language Class Initialized
INFO - 2019-07-03 19:01:55 --> Config Class Initialized
INFO - 2019-07-03 19:01:55 --> Loader Class Initialized
DEBUG - 2019-07-03 19:01:55 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 19:01:55 --> Helper loaded: url_helper
INFO - 2019-07-03 19:01:55 --> Helper loaded: inflector_helper
INFO - 2019-07-03 19:01:55 --> Helper loaded: string_helper
INFO - 2019-07-03 19:01:55 --> Helper loaded: array_helper
INFO - 2019-07-03 19:01:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 19:01:55 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 19:01:55 --> Database Driver Class Initialized
INFO - 2019-07-03 19:01:55 --> Controller Class Initialized
INFO - 2019-07-03 19:01:56 --> Config Class Initialized
INFO - 2019-07-03 19:01:56 --> Hooks Class Initialized
DEBUG - 2019-07-03 19:01:56 --> UTF-8 Support Enabled
INFO - 2019-07-03 19:01:56 --> Utf8 Class Initialized
INFO - 2019-07-03 19:01:56 --> URI Class Initialized
INFO - 2019-07-03 19:01:56 --> Router Class Initialized
INFO - 2019-07-03 19:01:56 --> Output Class Initialized
INFO - 2019-07-03 19:01:56 --> Security Class Initialized
DEBUG - 2019-07-03 19:01:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 19:01:56 --> Input Class Initialized
INFO - 2019-07-03 19:01:56 --> Language Class Initialized
INFO - 2019-07-03 19:01:56 --> Language Class Initialized
INFO - 2019-07-03 19:01:56 --> Config Class Initialized
INFO - 2019-07-03 19:01:56 --> Loader Class Initialized
DEBUG - 2019-07-03 19:01:56 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 19:01:56 --> Helper loaded: url_helper
INFO - 2019-07-03 19:01:56 --> Helper loaded: inflector_helper
INFO - 2019-07-03 19:01:56 --> Helper loaded: string_helper
INFO - 2019-07-03 19:01:56 --> Helper loaded: array_helper
INFO - 2019-07-03 19:01:56 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 19:01:56 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 19:01:56 --> Database Driver Class Initialized
INFO - 2019-07-03 19:01:56 --> Controller Class Initialized
INFO - 2019-07-03 19:01:57 --> Config Class Initialized
INFO - 2019-07-03 19:01:57 --> Hooks Class Initialized
DEBUG - 2019-07-03 19:01:57 --> UTF-8 Support Enabled
INFO - 2019-07-03 19:01:57 --> Utf8 Class Initialized
INFO - 2019-07-03 19:01:57 --> URI Class Initialized
INFO - 2019-07-03 19:01:57 --> Router Class Initialized
INFO - 2019-07-03 19:01:57 --> Output Class Initialized
INFO - 2019-07-03 19:01:57 --> Security Class Initialized
DEBUG - 2019-07-03 19:01:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 19:01:57 --> Input Class Initialized
INFO - 2019-07-03 19:01:57 --> Language Class Initialized
INFO - 2019-07-03 19:01:57 --> Language Class Initialized
INFO - 2019-07-03 19:01:57 --> Config Class Initialized
INFO - 2019-07-03 19:01:57 --> Loader Class Initialized
DEBUG - 2019-07-03 19:01:57 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 19:01:57 --> Helper loaded: url_helper
INFO - 2019-07-03 19:01:57 --> Helper loaded: inflector_helper
INFO - 2019-07-03 19:01:57 --> Helper loaded: string_helper
INFO - 2019-07-03 19:01:57 --> Helper loaded: array_helper
INFO - 2019-07-03 19:01:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 19:01:57 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 19:01:57 --> Database Driver Class Initialized
INFO - 2019-07-03 19:01:57 --> Controller Class Initialized
INFO - 2019-07-03 19:02:02 --> Config Class Initialized
INFO - 2019-07-03 19:02:02 --> Config Class Initialized
INFO - 2019-07-03 19:02:02 --> Hooks Class Initialized
INFO - 2019-07-03 19:02:02 --> Hooks Class Initialized
DEBUG - 2019-07-03 19:02:02 --> UTF-8 Support Enabled
DEBUG - 2019-07-03 19:02:02 --> UTF-8 Support Enabled
INFO - 2019-07-03 19:02:02 --> Utf8 Class Initialized
INFO - 2019-07-03 19:02:02 --> Utf8 Class Initialized
INFO - 2019-07-03 19:02:02 --> URI Class Initialized
INFO - 2019-07-03 19:02:02 --> URI Class Initialized
INFO - 2019-07-03 19:02:02 --> Router Class Initialized
INFO - 2019-07-03 19:02:02 --> Router Class Initialized
INFO - 2019-07-03 19:02:02 --> Output Class Initialized
INFO - 2019-07-03 19:02:02 --> Output Class Initialized
INFO - 2019-07-03 19:02:02 --> Security Class Initialized
INFO - 2019-07-03 19:02:02 --> Security Class Initialized
DEBUG - 2019-07-03 19:02:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-03 19:02:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 19:02:02 --> Input Class Initialized
INFO - 2019-07-03 19:02:02 --> Input Class Initialized
INFO - 2019-07-03 19:02:02 --> Language Class Initialized
INFO - 2019-07-03 19:02:02 --> Language Class Initialized
INFO - 2019-07-03 19:02:02 --> Language Class Initialized
INFO - 2019-07-03 19:02:02 --> Language Class Initialized
INFO - 2019-07-03 19:02:02 --> Config Class Initialized
INFO - 2019-07-03 19:02:02 --> Loader Class Initialized
INFO - 2019-07-03 19:02:02 --> Config Class Initialized
INFO - 2019-07-03 19:02:02 --> Loader Class Initialized
DEBUG - 2019-07-03 19:02:02 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-03 19:02:02 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 19:02:02 --> Helper loaded: url_helper
INFO - 2019-07-03 19:02:02 --> Helper loaded: url_helper
INFO - 2019-07-03 19:02:02 --> Helper loaded: inflector_helper
INFO - 2019-07-03 19:02:02 --> Helper loaded: inflector_helper
INFO - 2019-07-03 19:02:02 --> Helper loaded: string_helper
INFO - 2019-07-03 19:02:02 --> Helper loaded: string_helper
INFO - 2019-07-03 19:02:02 --> Helper loaded: array_helper
INFO - 2019-07-03 19:02:02 --> Helper loaded: array_helper
INFO - 2019-07-03 19:02:02 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 19:02:02 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 19:02:02 --> Database Driver Class Initialized
INFO - 2019-07-03 19:02:02 --> Controller Class Initialized
INFO - 2019-07-03 19:02:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 19:02:03 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 19:02:03 --> Database Driver Class Initialized
INFO - 2019-07-03 19:02:03 --> Controller Class Initialized
INFO - 2019-07-03 19:02:04 --> Config Class Initialized
INFO - 2019-07-03 19:02:04 --> Hooks Class Initialized
DEBUG - 2019-07-03 19:02:04 --> UTF-8 Support Enabled
INFO - 2019-07-03 19:02:04 --> Utf8 Class Initialized
INFO - 2019-07-03 19:02:04 --> URI Class Initialized
INFO - 2019-07-03 19:02:04 --> Router Class Initialized
INFO - 2019-07-03 19:02:04 --> Output Class Initialized
INFO - 2019-07-03 19:02:04 --> Security Class Initialized
DEBUG - 2019-07-03 19:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 19:02:04 --> Input Class Initialized
INFO - 2019-07-03 19:02:04 --> Language Class Initialized
INFO - 2019-07-03 19:02:04 --> Language Class Initialized
INFO - 2019-07-03 19:02:04 --> Config Class Initialized
INFO - 2019-07-03 19:02:04 --> Loader Class Initialized
DEBUG - 2019-07-03 19:02:04 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 19:02:04 --> Helper loaded: url_helper
INFO - 2019-07-03 19:02:04 --> Helper loaded: inflector_helper
INFO - 2019-07-03 19:02:04 --> Helper loaded: string_helper
INFO - 2019-07-03 19:02:04 --> Helper loaded: array_helper
INFO - 2019-07-03 19:02:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 19:02:05 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 19:02:05 --> Database Driver Class Initialized
INFO - 2019-07-03 19:02:05 --> Controller Class Initialized
INFO - 2019-07-03 19:02:05 --> Config Class Initialized
INFO - 2019-07-03 19:02:05 --> Hooks Class Initialized
DEBUG - 2019-07-03 19:02:05 --> UTF-8 Support Enabled
INFO - 2019-07-03 19:02:05 --> Utf8 Class Initialized
INFO - 2019-07-03 19:02:05 --> URI Class Initialized
INFO - 2019-07-03 19:02:05 --> Router Class Initialized
INFO - 2019-07-03 19:02:05 --> Output Class Initialized
INFO - 2019-07-03 19:02:05 --> Security Class Initialized
DEBUG - 2019-07-03 19:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 19:02:05 --> Input Class Initialized
INFO - 2019-07-03 19:02:05 --> Language Class Initialized
INFO - 2019-07-03 19:02:05 --> Language Class Initialized
INFO - 2019-07-03 19:02:05 --> Config Class Initialized
INFO - 2019-07-03 19:02:05 --> Loader Class Initialized
DEBUG - 2019-07-03 19:02:05 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 19:02:05 --> Helper loaded: url_helper
INFO - 2019-07-03 19:02:05 --> Helper loaded: inflector_helper
INFO - 2019-07-03 19:02:05 --> Helper loaded: string_helper
INFO - 2019-07-03 19:02:05 --> Helper loaded: array_helper
INFO - 2019-07-03 19:02:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 19:02:05 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 19:02:05 --> Database Driver Class Initialized
INFO - 2019-07-03 19:02:05 --> Controller Class Initialized
INFO - 2019-07-03 19:02:11 --> Config Class Initialized
INFO - 2019-07-03 19:02:11 --> Hooks Class Initialized
DEBUG - 2019-07-03 19:02:11 --> UTF-8 Support Enabled
INFO - 2019-07-03 19:02:11 --> Utf8 Class Initialized
INFO - 2019-07-03 19:02:11 --> URI Class Initialized
INFO - 2019-07-03 19:02:11 --> Router Class Initialized
INFO - 2019-07-03 19:02:11 --> Output Class Initialized
INFO - 2019-07-03 19:02:11 --> Security Class Initialized
DEBUG - 2019-07-03 19:02:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 19:02:12 --> Input Class Initialized
INFO - 2019-07-03 19:02:12 --> Language Class Initialized
INFO - 2019-07-03 19:02:12 --> Language Class Initialized
INFO - 2019-07-03 19:02:12 --> Config Class Initialized
INFO - 2019-07-03 19:02:12 --> Loader Class Initialized
DEBUG - 2019-07-03 19:02:12 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 19:02:12 --> Helper loaded: url_helper
INFO - 2019-07-03 19:02:12 --> Helper loaded: inflector_helper
INFO - 2019-07-03 19:02:12 --> Helper loaded: string_helper
INFO - 2019-07-03 19:02:12 --> Helper loaded: array_helper
INFO - 2019-07-03 19:02:12 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 19:02:12 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 19:02:12 --> Database Driver Class Initialized
INFO - 2019-07-03 19:02:12 --> Controller Class Initialized
INFO - 2019-07-03 19:02:12 --> Config Class Initialized
INFO - 2019-07-03 19:02:12 --> Hooks Class Initialized
DEBUG - 2019-07-03 19:02:12 --> UTF-8 Support Enabled
INFO - 2019-07-03 19:02:12 --> Utf8 Class Initialized
INFO - 2019-07-03 19:02:12 --> URI Class Initialized
INFO - 2019-07-03 19:02:12 --> Router Class Initialized
INFO - 2019-07-03 19:02:12 --> Output Class Initialized
INFO - 2019-07-03 19:02:12 --> Security Class Initialized
DEBUG - 2019-07-03 19:02:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 19:02:12 --> Input Class Initialized
INFO - 2019-07-03 19:02:12 --> Language Class Initialized
INFO - 2019-07-03 19:02:12 --> Language Class Initialized
INFO - 2019-07-03 19:02:12 --> Config Class Initialized
INFO - 2019-07-03 19:02:12 --> Loader Class Initialized
DEBUG - 2019-07-03 19:02:12 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 19:02:12 --> Helper loaded: url_helper
INFO - 2019-07-03 19:02:12 --> Helper loaded: inflector_helper
INFO - 2019-07-03 19:02:12 --> Helper loaded: string_helper
INFO - 2019-07-03 19:02:12 --> Helper loaded: array_helper
INFO - 2019-07-03 19:02:12 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 19:02:12 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 19:02:12 --> Database Driver Class Initialized
INFO - 2019-07-03 19:02:12 --> Controller Class Initialized
INFO - 2019-07-03 19:02:14 --> Config Class Initialized
INFO - 2019-07-03 19:02:14 --> Hooks Class Initialized
DEBUG - 2019-07-03 19:02:14 --> UTF-8 Support Enabled
INFO - 2019-07-03 19:02:14 --> Utf8 Class Initialized
INFO - 2019-07-03 19:02:14 --> URI Class Initialized
INFO - 2019-07-03 19:02:14 --> Router Class Initialized
INFO - 2019-07-03 19:02:14 --> Output Class Initialized
INFO - 2019-07-03 19:02:14 --> Security Class Initialized
DEBUG - 2019-07-03 19:02:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 19:02:14 --> Input Class Initialized
INFO - 2019-07-03 19:02:14 --> Language Class Initialized
INFO - 2019-07-03 19:02:14 --> Language Class Initialized
INFO - 2019-07-03 19:02:14 --> Config Class Initialized
INFO - 2019-07-03 19:02:14 --> Loader Class Initialized
DEBUG - 2019-07-03 19:02:14 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 19:02:14 --> Helper loaded: url_helper
INFO - 2019-07-03 19:02:14 --> Helper loaded: inflector_helper
INFO - 2019-07-03 19:02:14 --> Helper loaded: string_helper
INFO - 2019-07-03 19:02:14 --> Helper loaded: array_helper
INFO - 2019-07-03 19:02:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 19:02:14 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 19:02:14 --> Database Driver Class Initialized
INFO - 2019-07-03 19:02:14 --> Controller Class Initialized
INFO - 2019-07-03 19:03:15 --> Config Class Initialized
INFO - 2019-07-03 19:03:15 --> Hooks Class Initialized
DEBUG - 2019-07-03 19:03:15 --> UTF-8 Support Enabled
INFO - 2019-07-03 19:03:15 --> Utf8 Class Initialized
INFO - 2019-07-03 19:03:15 --> URI Class Initialized
INFO - 2019-07-03 19:03:15 --> Router Class Initialized
INFO - 2019-07-03 19:03:15 --> Output Class Initialized
INFO - 2019-07-03 19:03:15 --> Security Class Initialized
DEBUG - 2019-07-03 19:03:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 19:03:15 --> Input Class Initialized
INFO - 2019-07-03 19:03:15 --> Language Class Initialized
INFO - 2019-07-03 19:03:15 --> Language Class Initialized
INFO - 2019-07-03 19:03:15 --> Config Class Initialized
INFO - 2019-07-03 19:03:15 --> Loader Class Initialized
DEBUG - 2019-07-03 19:03:15 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 19:03:15 --> Helper loaded: url_helper
INFO - 2019-07-03 19:03:15 --> Helper loaded: inflector_helper
INFO - 2019-07-03 19:03:15 --> Helper loaded: string_helper
INFO - 2019-07-03 19:03:15 --> Helper loaded: array_helper
INFO - 2019-07-03 19:03:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 19:03:15 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 19:03:15 --> Database Driver Class Initialized
INFO - 2019-07-03 19:03:16 --> Controller Class Initialized
INFO - 2019-07-03 19:04:28 --> Config Class Initialized
INFO - 2019-07-03 19:04:28 --> Hooks Class Initialized
DEBUG - 2019-07-03 19:04:28 --> UTF-8 Support Enabled
INFO - 2019-07-03 19:04:28 --> Utf8 Class Initialized
INFO - 2019-07-03 19:04:28 --> URI Class Initialized
INFO - 2019-07-03 19:04:28 --> Router Class Initialized
INFO - 2019-07-03 19:04:28 --> Output Class Initialized
INFO - 2019-07-03 19:04:28 --> Security Class Initialized
DEBUG - 2019-07-03 19:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 19:04:28 --> Input Class Initialized
INFO - 2019-07-03 19:04:28 --> Language Class Initialized
INFO - 2019-07-03 19:04:28 --> Language Class Initialized
INFO - 2019-07-03 19:04:28 --> Config Class Initialized
INFO - 2019-07-03 19:04:28 --> Loader Class Initialized
DEBUG - 2019-07-03 19:04:28 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 19:04:28 --> Helper loaded: url_helper
INFO - 2019-07-03 19:04:28 --> Helper loaded: inflector_helper
INFO - 2019-07-03 19:04:28 --> Helper loaded: string_helper
INFO - 2019-07-03 19:04:28 --> Helper loaded: array_helper
INFO - 2019-07-03 19:04:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 19:04:28 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 19:04:28 --> Database Driver Class Initialized
INFO - 2019-07-03 19:04:28 --> Controller Class Initialized
INFO - 2019-07-03 19:04:29 --> Config Class Initialized
INFO - 2019-07-03 19:04:29 --> Hooks Class Initialized
DEBUG - 2019-07-03 19:04:29 --> UTF-8 Support Enabled
INFO - 2019-07-03 19:04:29 --> Utf8 Class Initialized
INFO - 2019-07-03 19:04:29 --> URI Class Initialized
INFO - 2019-07-03 19:04:29 --> Router Class Initialized
INFO - 2019-07-03 19:04:29 --> Output Class Initialized
INFO - 2019-07-03 19:04:29 --> Security Class Initialized
DEBUG - 2019-07-03 19:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 19:04:29 --> Input Class Initialized
INFO - 2019-07-03 19:04:29 --> Language Class Initialized
INFO - 2019-07-03 19:04:29 --> Language Class Initialized
INFO - 2019-07-03 19:04:29 --> Config Class Initialized
INFO - 2019-07-03 19:04:29 --> Loader Class Initialized
DEBUG - 2019-07-03 19:04:29 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 19:04:29 --> Helper loaded: url_helper
INFO - 2019-07-03 19:04:29 --> Helper loaded: inflector_helper
INFO - 2019-07-03 19:04:29 --> Helper loaded: string_helper
INFO - 2019-07-03 19:04:29 --> Helper loaded: array_helper
INFO - 2019-07-03 19:04:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 19:04:29 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 19:04:29 --> Database Driver Class Initialized
INFO - 2019-07-03 19:04:29 --> Controller Class Initialized
INFO - 2019-07-03 19:04:58 --> Config Class Initialized
INFO - 2019-07-03 19:04:58 --> Hooks Class Initialized
DEBUG - 2019-07-03 19:04:58 --> UTF-8 Support Enabled
INFO - 2019-07-03 19:04:58 --> Utf8 Class Initialized
INFO - 2019-07-03 19:04:58 --> URI Class Initialized
INFO - 2019-07-03 19:04:58 --> Router Class Initialized
INFO - 2019-07-03 19:04:58 --> Output Class Initialized
INFO - 2019-07-03 19:04:58 --> Security Class Initialized
DEBUG - 2019-07-03 19:04:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 19:04:58 --> Input Class Initialized
INFO - 2019-07-03 19:04:58 --> Language Class Initialized
INFO - 2019-07-03 19:04:58 --> Language Class Initialized
INFO - 2019-07-03 19:04:58 --> Config Class Initialized
INFO - 2019-07-03 19:04:58 --> Loader Class Initialized
DEBUG - 2019-07-03 19:04:58 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 19:04:58 --> Helper loaded: url_helper
INFO - 2019-07-03 19:04:59 --> Helper loaded: inflector_helper
INFO - 2019-07-03 19:04:59 --> Helper loaded: string_helper
INFO - 2019-07-03 19:04:59 --> Helper loaded: array_helper
INFO - 2019-07-03 19:04:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 19:04:59 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 19:04:59 --> Database Driver Class Initialized
INFO - 2019-07-03 19:04:59 --> Controller Class Initialized
INFO - 2019-07-03 19:05:00 --> Config Class Initialized
INFO - 2019-07-03 19:05:00 --> Hooks Class Initialized
DEBUG - 2019-07-03 19:05:00 --> UTF-8 Support Enabled
INFO - 2019-07-03 19:05:00 --> Utf8 Class Initialized
INFO - 2019-07-03 19:05:00 --> URI Class Initialized
INFO - 2019-07-03 19:05:00 --> Router Class Initialized
INFO - 2019-07-03 19:05:00 --> Output Class Initialized
INFO - 2019-07-03 19:05:00 --> Security Class Initialized
DEBUG - 2019-07-03 19:05:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-03 19:05:00 --> Input Class Initialized
INFO - 2019-07-03 19:05:00 --> Language Class Initialized
INFO - 2019-07-03 19:05:00 --> Language Class Initialized
INFO - 2019-07-03 19:05:00 --> Config Class Initialized
INFO - 2019-07-03 19:05:00 --> Loader Class Initialized
DEBUG - 2019-07-03 19:05:00 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-03 19:05:00 --> Helper loaded: url_helper
INFO - 2019-07-03 19:05:00 --> Helper loaded: inflector_helper
INFO - 2019-07-03 19:05:00 --> Helper loaded: string_helper
INFO - 2019-07-03 19:05:00 --> Helper loaded: array_helper
INFO - 2019-07-03 19:05:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-03 19:05:00 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-03 19:05:00 --> Database Driver Class Initialized
INFO - 2019-07-03 19:05:00 --> Controller Class Initialized
