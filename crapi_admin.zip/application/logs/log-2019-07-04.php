<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-07-04 00:02:23 --> Helper loaded: language_helper
INFO - 2019-07-04 00:02:23 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:02:23 --> Model Class Initialized
INFO - 2019-07-04 00:02:23 --> Model Class Initialized
INFO - 2019-07-04 00:02:23 --> Model Class Initialized
INFO - 2019-07-04 00:02:23 --> Model Class Initialized
INFO - 2019-07-04 00:02:23 --> Model Class Initialized
INFO - 2019-07-04 00:02:23 --> Final output sent to browser
DEBUG - 2019-07-04 00:02:23 --> Total execution time: 0.4862
INFO - 2019-07-04 00:02:23 --> Helper loaded: language_helper
INFO - 2019-07-04 00:02:23 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:02:23 --> Model Class Initialized
INFO - 2019-07-04 00:02:23 --> Model Class Initialized
INFO - 2019-07-04 00:02:24 --> Model Class Initialized
INFO - 2019-07-04 00:02:24 --> Model Class Initialized
INFO - 2019-07-04 00:02:24 --> Helper loaded: form_helper
INFO - 2019-07-04 00:02:24 --> Form Validation Class Initialized
DEBUG - 2019-07-04 00:02:24 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 00:02:24 --> Model Class Initialized
INFO - 2019-07-04 00:02:24 --> Model Class Initialized
INFO - 2019-07-04 00:02:24 --> Final output sent to browser
DEBUG - 2019-07-04 00:02:24 --> Total execution time: 0.4769
INFO - 2019-07-04 00:02:24 --> Helper loaded: language_helper
INFO - 2019-07-04 00:02:24 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:02:24 --> Model Class Initialized
INFO - 2019-07-04 00:02:24 --> Model Class Initialized
INFO - 2019-07-04 00:02:24 --> Model Class Initialized
INFO - 2019-07-04 00:02:24 --> Model Class Initialized
INFO - 2019-07-04 00:02:24 --> Model Class Initialized
INFO - 2019-07-04 00:02:24 --> Final output sent to browser
DEBUG - 2019-07-04 00:02:24 --> Total execution time: 0.4444
INFO - 2019-07-04 00:02:25 --> Helper loaded: language_helper
INFO - 2019-07-04 00:02:25 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:02:25 --> Model Class Initialized
INFO - 2019-07-04 00:02:25 --> Model Class Initialized
INFO - 2019-07-04 00:02:25 --> Model Class Initialized
INFO - 2019-07-04 00:02:25 --> Model Class Initialized
INFO - 2019-07-04 00:02:25 --> Helper loaded: form_helper
INFO - 2019-07-04 00:02:25 --> Form Validation Class Initialized
DEBUG - 2019-07-04 00:02:25 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 00:02:25 --> Model Class Initialized
INFO - 2019-07-04 00:02:25 --> Model Class Initialized
INFO - 2019-07-04 00:02:25 --> Final output sent to browser
DEBUG - 2019-07-04 00:02:25 --> Total execution time: 0.4790
INFO - 2019-07-04 00:02:32 --> Helper loaded: language_helper
INFO - 2019-07-04 00:02:32 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:02:32 --> Model Class Initialized
INFO - 2019-07-04 00:02:32 --> Model Class Initialized
INFO - 2019-07-04 00:02:33 --> Model Class Initialized
INFO - 2019-07-04 00:02:33 --> Model Class Initialized
INFO - 2019-07-04 00:02:33 --> Helper loaded: form_helper
INFO - 2019-07-04 00:02:33 --> Form Validation Class Initialized
DEBUG - 2019-07-04 00:02:33 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 00:02:33 --> Model Class Initialized
INFO - 2019-07-04 00:02:33 --> Model Class Initialized
INFO - 2019-07-04 00:02:33 --> Final output sent to browser
DEBUG - 2019-07-04 00:02:33 --> Total execution time: 0.4930
INFO - 2019-07-04 00:04:06 --> Helper loaded: language_helper
INFO - 2019-07-04 00:04:06 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:04:06 --> Model Class Initialized
INFO - 2019-07-04 00:04:06 --> Model Class Initialized
INFO - 2019-07-04 00:04:06 --> Model Class Initialized
INFO - 2019-07-04 00:04:06 --> Model Class Initialized
INFO - 2019-07-04 00:04:06 --> Model Class Initialized
INFO - 2019-07-04 00:04:06 --> Final output sent to browser
DEBUG - 2019-07-04 00:04:06 --> Total execution time: 0.4397
INFO - 2019-07-04 00:04:07 --> Helper loaded: language_helper
INFO - 2019-07-04 00:04:07 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:04:07 --> Model Class Initialized
INFO - 2019-07-04 00:04:07 --> Model Class Initialized
INFO - 2019-07-04 00:04:07 --> Model Class Initialized
INFO - 2019-07-04 00:04:07 --> Model Class Initialized
INFO - 2019-07-04 00:04:07 --> Helper loaded: form_helper
INFO - 2019-07-04 00:04:07 --> Form Validation Class Initialized
DEBUG - 2019-07-04 00:04:07 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 00:04:07 --> Model Class Initialized
INFO - 2019-07-04 00:04:07 --> Model Class Initialized
INFO - 2019-07-04 00:04:07 --> Final output sent to browser
DEBUG - 2019-07-04 00:04:07 --> Total execution time: 0.4792
INFO - 2019-07-04 00:04:14 --> Helper loaded: language_helper
INFO - 2019-07-04 00:04:14 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:04:14 --> Model Class Initialized
INFO - 2019-07-04 00:04:14 --> Model Class Initialized
INFO - 2019-07-04 00:04:14 --> Model Class Initialized
INFO - 2019-07-04 00:04:14 --> Model Class Initialized
INFO - 2019-07-04 00:04:14 --> Helper loaded: form_helper
INFO - 2019-07-04 00:04:14 --> Form Validation Class Initialized
DEBUG - 2019-07-04 00:04:14 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 00:04:14 --> Model Class Initialized
INFO - 2019-07-04 00:04:14 --> Model Class Initialized
INFO - 2019-07-04 00:04:14 --> Final output sent to browser
DEBUG - 2019-07-04 00:04:14 --> Total execution time: 0.4829
INFO - 2019-07-04 00:04:27 --> Helper loaded: language_helper
INFO - 2019-07-04 00:04:27 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:04:27 --> Model Class Initialized
INFO - 2019-07-04 00:04:27 --> Model Class Initialized
INFO - 2019-07-04 00:04:27 --> Model Class Initialized
INFO - 2019-07-04 00:04:27 --> Model Class Initialized
INFO - 2019-07-04 00:04:28 --> Model Class Initialized
INFO - 2019-07-04 00:04:28 --> Final output sent to browser
DEBUG - 2019-07-04 00:04:28 --> Total execution time: 0.4610
INFO - 2019-07-04 00:04:28 --> Helper loaded: language_helper
INFO - 2019-07-04 00:04:28 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:04:28 --> Model Class Initialized
INFO - 2019-07-04 00:04:28 --> Model Class Initialized
INFO - 2019-07-04 00:04:28 --> Model Class Initialized
INFO - 2019-07-04 00:04:28 --> Model Class Initialized
INFO - 2019-07-04 00:04:28 --> Helper loaded: form_helper
INFO - 2019-07-04 00:04:28 --> Form Validation Class Initialized
DEBUG - 2019-07-04 00:04:28 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 00:04:28 --> Model Class Initialized
INFO - 2019-07-04 00:04:28 --> Model Class Initialized
INFO - 2019-07-04 00:04:28 --> Final output sent to browser
DEBUG - 2019-07-04 00:04:28 --> Total execution time: 0.4878
INFO - 2019-07-04 00:04:30 --> Helper loaded: language_helper
INFO - 2019-07-04 00:04:30 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:04:30 --> Model Class Initialized
INFO - 2019-07-04 00:04:30 --> Model Class Initialized
INFO - 2019-07-04 00:04:30 --> Model Class Initialized
INFO - 2019-07-04 00:04:30 --> Model Class Initialized
INFO - 2019-07-04 00:04:30 --> Helper loaded: form_helper
INFO - 2019-07-04 00:04:30 --> Form Validation Class Initialized
DEBUG - 2019-07-04 00:04:30 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 00:04:30 --> Model Class Initialized
INFO - 2019-07-04 00:04:30 --> Model Class Initialized
INFO - 2019-07-04 00:04:30 --> Final output sent to browser
DEBUG - 2019-07-04 00:04:30 --> Total execution time: 0.4797
INFO - 2019-07-04 00:04:58 --> Helper loaded: language_helper
INFO - 2019-07-04 00:04:58 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:04:58 --> Model Class Initialized
INFO - 2019-07-04 00:04:58 --> Model Class Initialized
INFO - 2019-07-04 00:04:58 --> Model Class Initialized
INFO - 2019-07-04 00:04:58 --> Model Class Initialized
INFO - 2019-07-04 00:04:58 --> Model Class Initialized
INFO - 2019-07-04 00:04:58 --> Final output sent to browser
DEBUG - 2019-07-04 00:04:58 --> Total execution time: 0.4373
INFO - 2019-07-04 00:04:58 --> Helper loaded: language_helper
INFO - 2019-07-04 00:04:58 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:04:58 --> Model Class Initialized
INFO - 2019-07-04 00:04:58 --> Model Class Initialized
INFO - 2019-07-04 00:04:58 --> Model Class Initialized
INFO - 2019-07-04 00:04:58 --> Model Class Initialized
INFO - 2019-07-04 00:04:58 --> Helper loaded: form_helper
INFO - 2019-07-04 00:04:58 --> Form Validation Class Initialized
DEBUG - 2019-07-04 00:04:58 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 00:04:58 --> Model Class Initialized
INFO - 2019-07-04 00:04:58 --> Model Class Initialized
INFO - 2019-07-04 00:04:58 --> Final output sent to browser
DEBUG - 2019-07-04 00:04:58 --> Total execution time: 0.4887
INFO - 2019-07-04 00:04:59 --> Helper loaded: language_helper
INFO - 2019-07-04 00:04:59 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:04:59 --> Model Class Initialized
INFO - 2019-07-04 00:04:59 --> Model Class Initialized
INFO - 2019-07-04 00:04:59 --> Model Class Initialized
INFO - 2019-07-04 00:04:59 --> Model Class Initialized
INFO - 2019-07-04 00:04:59 --> Helper loaded: form_helper
INFO - 2019-07-04 00:04:59 --> Form Validation Class Initialized
DEBUG - 2019-07-04 00:04:59 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 00:04:59 --> Model Class Initialized
INFO - 2019-07-04 00:04:59 --> Model Class Initialized
INFO - 2019-07-04 00:04:59 --> Final output sent to browser
DEBUG - 2019-07-04 00:04:59 --> Total execution time: 0.5017
INFO - 2019-07-04 00:05:43 --> Helper loaded: language_helper
INFO - 2019-07-04 00:05:43 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:05:43 --> Model Class Initialized
INFO - 2019-07-04 00:05:43 --> Model Class Initialized
INFO - 2019-07-04 00:05:43 --> Model Class Initialized
INFO - 2019-07-04 00:05:43 --> Model Class Initialized
INFO - 2019-07-04 00:05:43 --> Model Class Initialized
INFO - 2019-07-04 00:05:43 --> Final output sent to browser
DEBUG - 2019-07-04 00:05:43 --> Total execution time: 0.4585
INFO - 2019-07-04 00:05:43 --> Helper loaded: language_helper
INFO - 2019-07-04 00:05:43 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:05:43 --> Model Class Initialized
INFO - 2019-07-04 00:05:43 --> Model Class Initialized
INFO - 2019-07-04 00:05:43 --> Model Class Initialized
INFO - 2019-07-04 00:05:43 --> Model Class Initialized
INFO - 2019-07-04 00:05:43 --> Helper loaded: form_helper
INFO - 2019-07-04 00:05:43 --> Form Validation Class Initialized
DEBUG - 2019-07-04 00:05:43 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 00:05:43 --> Model Class Initialized
INFO - 2019-07-04 00:05:43 --> Model Class Initialized
INFO - 2019-07-04 00:05:43 --> Final output sent to browser
DEBUG - 2019-07-04 00:05:43 --> Total execution time: 0.4914
INFO - 2019-07-04 00:05:44 --> Helper loaded: language_helper
INFO - 2019-07-04 00:05:44 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:05:44 --> Model Class Initialized
INFO - 2019-07-04 00:05:44 --> Model Class Initialized
INFO - 2019-07-04 00:05:44 --> Model Class Initialized
INFO - 2019-07-04 00:05:44 --> Model Class Initialized
INFO - 2019-07-04 00:05:44 --> Helper loaded: form_helper
INFO - 2019-07-04 00:05:44 --> Form Validation Class Initialized
DEBUG - 2019-07-04 00:05:44 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 00:05:44 --> Model Class Initialized
INFO - 2019-07-04 00:05:44 --> Model Class Initialized
INFO - 2019-07-04 00:05:44 --> Final output sent to browser
DEBUG - 2019-07-04 00:05:44 --> Total execution time: 0.4930
INFO - 2019-07-04 00:06:01 --> Helper loaded: language_helper
INFO - 2019-07-04 00:06:01 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:06:01 --> Model Class Initialized
INFO - 2019-07-04 00:06:01 --> Model Class Initialized
INFO - 2019-07-04 00:06:01 --> Model Class Initialized
INFO - 2019-07-04 00:06:01 --> Model Class Initialized
INFO - 2019-07-04 00:06:01 --> Model Class Initialized
INFO - 2019-07-04 00:06:01 --> Final output sent to browser
DEBUG - 2019-07-04 00:06:01 --> Total execution time: 0.4999
INFO - 2019-07-04 00:06:01 --> Helper loaded: language_helper
INFO - 2019-07-04 00:06:01 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:06:01 --> Model Class Initialized
INFO - 2019-07-04 00:06:01 --> Model Class Initialized
INFO - 2019-07-04 00:06:01 --> Model Class Initialized
INFO - 2019-07-04 00:06:01 --> Model Class Initialized
INFO - 2019-07-04 00:06:01 --> Helper loaded: form_helper
INFO - 2019-07-04 00:06:01 --> Form Validation Class Initialized
DEBUG - 2019-07-04 00:06:01 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 00:06:01 --> Model Class Initialized
INFO - 2019-07-04 00:06:01 --> Model Class Initialized
INFO - 2019-07-04 00:06:01 --> Final output sent to browser
DEBUG - 2019-07-04 00:06:01 --> Total execution time: 0.5152
INFO - 2019-07-04 00:06:13 --> Helper loaded: language_helper
INFO - 2019-07-04 00:06:13 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:06:13 --> Model Class Initialized
INFO - 2019-07-04 00:06:13 --> Model Class Initialized
INFO - 2019-07-04 00:06:13 --> Model Class Initialized
INFO - 2019-07-04 00:06:13 --> Model Class Initialized
INFO - 2019-07-04 00:06:13 --> Model Class Initialized
INFO - 2019-07-04 00:06:13 --> Final output sent to browser
DEBUG - 2019-07-04 00:06:13 --> Total execution time: 0.4458
INFO - 2019-07-04 00:06:13 --> Helper loaded: language_helper
INFO - 2019-07-04 00:06:13 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:06:14 --> Model Class Initialized
INFO - 2019-07-04 00:06:14 --> Model Class Initialized
INFO - 2019-07-04 00:06:14 --> Model Class Initialized
INFO - 2019-07-04 00:06:14 --> Model Class Initialized
INFO - 2019-07-04 00:06:14 --> Helper loaded: form_helper
INFO - 2019-07-04 00:06:14 --> Form Validation Class Initialized
DEBUG - 2019-07-04 00:06:14 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 00:06:14 --> Model Class Initialized
INFO - 2019-07-04 00:06:14 --> Model Class Initialized
INFO - 2019-07-04 00:06:14 --> Final output sent to browser
DEBUG - 2019-07-04 00:06:14 --> Total execution time: 0.5185
INFO - 2019-07-04 00:06:22 --> Helper loaded: language_helper
INFO - 2019-07-04 00:06:22 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:06:22 --> Model Class Initialized
INFO - 2019-07-04 00:06:22 --> Model Class Initialized
INFO - 2019-07-04 00:06:22 --> Model Class Initialized
INFO - 2019-07-04 00:06:22 --> Model Class Initialized
INFO - 2019-07-04 00:06:22 --> Model Class Initialized
INFO - 2019-07-04 00:06:22 --> Final output sent to browser
DEBUG - 2019-07-04 00:06:22 --> Total execution time: 0.5016
INFO - 2019-07-04 00:06:23 --> Helper loaded: language_helper
INFO - 2019-07-04 00:06:23 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:06:23 --> Model Class Initialized
INFO - 2019-07-04 00:06:23 --> Model Class Initialized
INFO - 2019-07-04 00:06:23 --> Model Class Initialized
INFO - 2019-07-04 00:06:23 --> Model Class Initialized
INFO - 2019-07-04 00:06:23 --> Helper loaded: form_helper
INFO - 2019-07-04 00:06:23 --> Form Validation Class Initialized
DEBUG - 2019-07-04 00:06:23 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 00:06:23 --> Model Class Initialized
INFO - 2019-07-04 00:06:23 --> Model Class Initialized
INFO - 2019-07-04 00:06:23 --> Final output sent to browser
DEBUG - 2019-07-04 00:06:23 --> Total execution time: 0.5048
INFO - 2019-07-04 00:06:24 --> Helper loaded: language_helper
INFO - 2019-07-04 00:06:24 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:06:24 --> Model Class Initialized
INFO - 2019-07-04 00:06:24 --> Model Class Initialized
INFO - 2019-07-04 00:06:24 --> Model Class Initialized
INFO - 2019-07-04 00:06:24 --> Model Class Initialized
INFO - 2019-07-04 00:06:24 --> Helper loaded: form_helper
INFO - 2019-07-04 00:06:24 --> Form Validation Class Initialized
DEBUG - 2019-07-04 00:06:24 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 00:06:24 --> Model Class Initialized
INFO - 2019-07-04 00:06:24 --> Model Class Initialized
INFO - 2019-07-04 00:06:24 --> Final output sent to browser
DEBUG - 2019-07-04 00:06:24 --> Total execution time: 0.4921
INFO - 2019-07-04 00:19:48 --> Helper loaded: language_helper
INFO - 2019-07-04 00:19:48 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:19:48 --> Model Class Initialized
INFO - 2019-07-04 00:19:48 --> Model Class Initialized
INFO - 2019-07-04 00:19:48 --> Model Class Initialized
INFO - 2019-07-04 00:19:48 --> Model Class Initialized
INFO - 2019-07-04 00:19:48 --> Model Class Initialized
INFO - 2019-07-04 00:19:48 --> Final output sent to browser
DEBUG - 2019-07-04 00:19:48 --> Total execution time: 0.4603
INFO - 2019-07-04 00:19:49 --> Helper loaded: language_helper
INFO - 2019-07-04 00:19:49 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:19:49 --> Model Class Initialized
INFO - 2019-07-04 00:19:49 --> Model Class Initialized
INFO - 2019-07-04 00:19:49 --> Model Class Initialized
INFO - 2019-07-04 00:19:49 --> Model Class Initialized
INFO - 2019-07-04 00:19:49 --> Helper loaded: form_helper
INFO - 2019-07-04 00:19:49 --> Form Validation Class Initialized
DEBUG - 2019-07-04 00:19:49 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 00:19:49 --> Model Class Initialized
INFO - 2019-07-04 00:19:49 --> Model Class Initialized
INFO - 2019-07-04 00:19:49 --> Final output sent to browser
DEBUG - 2019-07-04 00:19:49 --> Total execution time: 0.4937
INFO - 2019-07-04 00:19:55 --> Helper loaded: language_helper
INFO - 2019-07-04 00:19:55 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:19:55 --> Model Class Initialized
INFO - 2019-07-04 00:19:55 --> Model Class Initialized
INFO - 2019-07-04 00:19:55 --> Model Class Initialized
INFO - 2019-07-04 00:19:55 --> Model Class Initialized
INFO - 2019-07-04 00:19:55 --> Model Class Initialized
INFO - 2019-07-04 00:19:55 --> Final output sent to browser
DEBUG - 2019-07-04 00:19:55 --> Total execution time: 0.4386
INFO - 2019-07-04 00:19:56 --> Helper loaded: language_helper
INFO - 2019-07-04 00:19:56 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:19:56 --> Model Class Initialized
INFO - 2019-07-04 00:19:56 --> Model Class Initialized
INFO - 2019-07-04 00:19:56 --> Model Class Initialized
INFO - 2019-07-04 00:19:56 --> Model Class Initialized
INFO - 2019-07-04 00:19:56 --> Helper loaded: form_helper
INFO - 2019-07-04 00:19:56 --> Form Validation Class Initialized
DEBUG - 2019-07-04 00:19:56 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 00:19:56 --> Model Class Initialized
INFO - 2019-07-04 00:19:56 --> Model Class Initialized
INFO - 2019-07-04 00:19:56 --> Final output sent to browser
DEBUG - 2019-07-04 00:19:56 --> Total execution time: 0.4771
INFO - 2019-07-04 00:21:08 --> Helper loaded: language_helper
INFO - 2019-07-04 00:21:08 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:21:08 --> Model Class Initialized
INFO - 2019-07-04 00:21:08 --> Model Class Initialized
INFO - 2019-07-04 00:21:08 --> Model Class Initialized
INFO - 2019-07-04 00:21:08 --> Model Class Initialized
INFO - 2019-07-04 00:21:08 --> Model Class Initialized
INFO - 2019-07-04 00:21:08 --> Final output sent to browser
DEBUG - 2019-07-04 00:21:08 --> Total execution time: 0.4516
INFO - 2019-07-04 00:21:09 --> Helper loaded: language_helper
INFO - 2019-07-04 00:21:09 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:21:09 --> Model Class Initialized
INFO - 2019-07-04 00:21:09 --> Model Class Initialized
INFO - 2019-07-04 00:21:09 --> Model Class Initialized
INFO - 2019-07-04 00:21:09 --> Model Class Initialized
INFO - 2019-07-04 00:21:09 --> Helper loaded: form_helper
INFO - 2019-07-04 00:21:09 --> Form Validation Class Initialized
DEBUG - 2019-07-04 00:21:09 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 00:21:09 --> Model Class Initialized
INFO - 2019-07-04 00:21:09 --> Model Class Initialized
INFO - 2019-07-04 00:21:09 --> Final output sent to browser
DEBUG - 2019-07-04 00:21:09 --> Total execution time: 0.4829
INFO - 2019-07-04 00:21:15 --> Helper loaded: language_helper
INFO - 2019-07-04 00:21:15 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:21:15 --> Model Class Initialized
INFO - 2019-07-04 00:21:15 --> Model Class Initialized
INFO - 2019-07-04 00:21:15 --> Model Class Initialized
INFO - 2019-07-04 00:21:15 --> Model Class Initialized
INFO - 2019-07-04 00:21:15 --> Model Class Initialized
INFO - 2019-07-04 00:21:15 --> Final output sent to browser
DEBUG - 2019-07-04 00:21:15 --> Total execution time: 0.4619
INFO - 2019-07-04 00:21:16 --> Helper loaded: language_helper
INFO - 2019-07-04 00:21:16 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:21:16 --> Model Class Initialized
INFO - 2019-07-04 00:21:16 --> Model Class Initialized
INFO - 2019-07-04 00:21:16 --> Model Class Initialized
INFO - 2019-07-04 00:21:16 --> Model Class Initialized
INFO - 2019-07-04 00:21:16 --> Helper loaded: form_helper
INFO - 2019-07-04 00:21:16 --> Form Validation Class Initialized
DEBUG - 2019-07-04 00:21:16 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 00:21:16 --> Model Class Initialized
INFO - 2019-07-04 00:21:16 --> Model Class Initialized
INFO - 2019-07-04 00:21:16 --> Final output sent to browser
DEBUG - 2019-07-04 00:21:16 --> Total execution time: 0.5013
INFO - 2019-07-04 00:21:37 --> Helper loaded: language_helper
INFO - 2019-07-04 00:21:37 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:21:37 --> Model Class Initialized
INFO - 2019-07-04 00:21:37 --> Model Class Initialized
INFO - 2019-07-04 00:21:37 --> Model Class Initialized
INFO - 2019-07-04 00:21:37 --> Model Class Initialized
INFO - 2019-07-04 00:21:37 --> Model Class Initialized
INFO - 2019-07-04 00:21:37 --> Final output sent to browser
DEBUG - 2019-07-04 00:21:37 --> Total execution time: 0.4439
INFO - 2019-07-04 00:21:38 --> Helper loaded: language_helper
INFO - 2019-07-04 00:21:38 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:21:38 --> Model Class Initialized
INFO - 2019-07-04 00:21:38 --> Model Class Initialized
INFO - 2019-07-04 00:21:38 --> Model Class Initialized
INFO - 2019-07-04 00:21:38 --> Model Class Initialized
INFO - 2019-07-04 00:21:38 --> Helper loaded: form_helper
INFO - 2019-07-04 00:21:38 --> Form Validation Class Initialized
DEBUG - 2019-07-04 00:21:38 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 00:21:38 --> Model Class Initialized
INFO - 2019-07-04 00:21:38 --> Model Class Initialized
INFO - 2019-07-04 00:21:38 --> Final output sent to browser
DEBUG - 2019-07-04 00:21:38 --> Total execution time: 0.4912
INFO - 2019-07-04 00:23:23 --> Helper loaded: language_helper
INFO - 2019-07-04 00:23:23 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:23:23 --> Model Class Initialized
INFO - 2019-07-04 00:23:23 --> Model Class Initialized
INFO - 2019-07-04 00:23:23 --> Model Class Initialized
INFO - 2019-07-04 00:23:23 --> Model Class Initialized
INFO - 2019-07-04 00:23:23 --> Model Class Initialized
INFO - 2019-07-04 00:23:23 --> Final output sent to browser
DEBUG - 2019-07-04 00:23:23 --> Total execution time: 0.4695
INFO - 2019-07-04 00:23:24 --> Helper loaded: language_helper
INFO - 2019-07-04 00:23:24 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:23:24 --> Model Class Initialized
INFO - 2019-07-04 00:23:24 --> Model Class Initialized
INFO - 2019-07-04 00:23:24 --> Model Class Initialized
INFO - 2019-07-04 00:23:24 --> Model Class Initialized
INFO - 2019-07-04 00:23:24 --> Helper loaded: form_helper
INFO - 2019-07-04 00:23:24 --> Form Validation Class Initialized
DEBUG - 2019-07-04 00:23:24 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 00:23:24 --> Model Class Initialized
INFO - 2019-07-04 00:23:24 --> Model Class Initialized
INFO - 2019-07-04 00:23:24 --> Final output sent to browser
DEBUG - 2019-07-04 00:23:24 --> Total execution time: 0.5037
INFO - 2019-07-04 00:23:53 --> Helper loaded: language_helper
INFO - 2019-07-04 00:23:53 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:23:53 --> Model Class Initialized
INFO - 2019-07-04 00:23:53 --> Model Class Initialized
INFO - 2019-07-04 00:23:53 --> Model Class Initialized
INFO - 2019-07-04 00:23:53 --> Model Class Initialized
INFO - 2019-07-04 00:23:53 --> Model Class Initialized
INFO - 2019-07-04 00:23:53 --> Final output sent to browser
DEBUG - 2019-07-04 00:23:53 --> Total execution time: 0.4869
INFO - 2019-07-04 00:23:54 --> Helper loaded: language_helper
INFO - 2019-07-04 00:23:54 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:23:54 --> Model Class Initialized
INFO - 2019-07-04 00:23:54 --> Model Class Initialized
INFO - 2019-07-04 00:23:54 --> Model Class Initialized
INFO - 2019-07-04 00:23:54 --> Model Class Initialized
INFO - 2019-07-04 00:23:54 --> Helper loaded: form_helper
INFO - 2019-07-04 00:23:54 --> Form Validation Class Initialized
DEBUG - 2019-07-04 00:23:54 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 00:23:54 --> Model Class Initialized
INFO - 2019-07-04 00:23:54 --> Model Class Initialized
INFO - 2019-07-04 00:23:54 --> Final output sent to browser
DEBUG - 2019-07-04 00:23:54 --> Total execution time: 0.5251
INFO - 2019-07-04 00:23:55 --> Helper loaded: language_helper
INFO - 2019-07-04 00:23:55 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:23:55 --> Model Class Initialized
INFO - 2019-07-04 00:23:55 --> Model Class Initialized
INFO - 2019-07-04 00:23:55 --> Model Class Initialized
INFO - 2019-07-04 00:23:55 --> Model Class Initialized
INFO - 2019-07-04 00:23:55 --> Helper loaded: form_helper
INFO - 2019-07-04 00:23:55 --> Form Validation Class Initialized
DEBUG - 2019-07-04 00:23:55 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 00:23:55 --> Model Class Initialized
INFO - 2019-07-04 00:23:55 --> Model Class Initialized
INFO - 2019-07-04 00:23:55 --> Final output sent to browser
DEBUG - 2019-07-04 00:23:55 --> Total execution time: 0.5186
INFO - 2019-07-04 00:25:24 --> Helper loaded: language_helper
INFO - 2019-07-04 00:25:24 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:25:24 --> Model Class Initialized
INFO - 2019-07-04 00:25:24 --> Model Class Initialized
INFO - 2019-07-04 00:25:24 --> Model Class Initialized
INFO - 2019-07-04 00:25:24 --> Model Class Initialized
INFO - 2019-07-04 00:25:24 --> Model Class Initialized
INFO - 2019-07-04 00:25:24 --> Final output sent to browser
DEBUG - 2019-07-04 00:25:24 --> Total execution time: 0.4669
INFO - 2019-07-04 00:25:25 --> Helper loaded: language_helper
INFO - 2019-07-04 00:25:25 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:25:25 --> Model Class Initialized
INFO - 2019-07-04 00:25:25 --> Model Class Initialized
INFO - 2019-07-04 00:25:25 --> Model Class Initialized
INFO - 2019-07-04 00:25:25 --> Model Class Initialized
INFO - 2019-07-04 00:25:25 --> Helper loaded: form_helper
INFO - 2019-07-04 00:25:25 --> Form Validation Class Initialized
DEBUG - 2019-07-04 00:25:25 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 00:25:25 --> Model Class Initialized
INFO - 2019-07-04 00:25:25 --> Model Class Initialized
INFO - 2019-07-04 00:25:25 --> Final output sent to browser
DEBUG - 2019-07-04 00:25:25 --> Total execution time: 0.4984
INFO - 2019-07-04 00:25:52 --> Helper loaded: language_helper
INFO - 2019-07-04 00:25:52 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:25:52 --> Model Class Initialized
INFO - 2019-07-04 00:25:52 --> Model Class Initialized
INFO - 2019-07-04 00:25:52 --> Model Class Initialized
INFO - 2019-07-04 00:25:52 --> Model Class Initialized
INFO - 2019-07-04 00:25:52 --> Model Class Initialized
INFO - 2019-07-04 00:25:52 --> Final output sent to browser
DEBUG - 2019-07-04 00:25:52 --> Total execution time: 0.4654
INFO - 2019-07-04 00:25:53 --> Helper loaded: language_helper
INFO - 2019-07-04 00:25:53 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:25:53 --> Model Class Initialized
INFO - 2019-07-04 00:25:53 --> Model Class Initialized
INFO - 2019-07-04 00:25:53 --> Model Class Initialized
INFO - 2019-07-04 00:25:53 --> Model Class Initialized
INFO - 2019-07-04 00:25:53 --> Helper loaded: form_helper
INFO - 2019-07-04 00:25:53 --> Form Validation Class Initialized
DEBUG - 2019-07-04 00:25:53 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 00:25:53 --> Model Class Initialized
INFO - 2019-07-04 00:25:53 --> Model Class Initialized
INFO - 2019-07-04 00:25:53 --> Final output sent to browser
DEBUG - 2019-07-04 00:25:53 --> Total execution time: 0.5136
INFO - 2019-07-04 00:26:20 --> Helper loaded: language_helper
INFO - 2019-07-04 00:26:20 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:26:20 --> Model Class Initialized
INFO - 2019-07-04 00:26:20 --> Model Class Initialized
INFO - 2019-07-04 00:26:20 --> Model Class Initialized
INFO - 2019-07-04 00:26:20 --> Model Class Initialized
INFO - 2019-07-04 00:26:20 --> Model Class Initialized
INFO - 2019-07-04 00:26:20 --> Final output sent to browser
DEBUG - 2019-07-04 00:26:20 --> Total execution time: 0.4655
INFO - 2019-07-04 00:26:21 --> Helper loaded: language_helper
INFO - 2019-07-04 00:26:21 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:26:21 --> Model Class Initialized
INFO - 2019-07-04 00:26:21 --> Model Class Initialized
INFO - 2019-07-04 00:26:21 --> Model Class Initialized
INFO - 2019-07-04 00:26:21 --> Model Class Initialized
INFO - 2019-07-04 00:26:21 --> Helper loaded: form_helper
INFO - 2019-07-04 00:26:21 --> Form Validation Class Initialized
DEBUG - 2019-07-04 00:26:21 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 00:26:21 --> Model Class Initialized
INFO - 2019-07-04 00:26:21 --> Model Class Initialized
INFO - 2019-07-04 00:26:21 --> Final output sent to browser
DEBUG - 2019-07-04 00:26:21 --> Total execution time: 0.4983
INFO - 2019-07-04 00:26:45 --> Helper loaded: language_helper
INFO - 2019-07-04 00:26:45 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:26:45 --> Model Class Initialized
INFO - 2019-07-04 00:26:45 --> Model Class Initialized
INFO - 2019-07-04 00:26:45 --> Model Class Initialized
INFO - 2019-07-04 00:26:45 --> Model Class Initialized
INFO - 2019-07-04 00:26:45 --> Model Class Initialized
INFO - 2019-07-04 00:26:45 --> Final output sent to browser
DEBUG - 2019-07-04 00:26:45 --> Total execution time: 0.4758
INFO - 2019-07-04 00:26:46 --> Helper loaded: language_helper
INFO - 2019-07-04 00:26:46 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:26:46 --> Model Class Initialized
INFO - 2019-07-04 00:26:46 --> Model Class Initialized
INFO - 2019-07-04 00:26:46 --> Model Class Initialized
INFO - 2019-07-04 00:26:46 --> Model Class Initialized
INFO - 2019-07-04 00:26:46 --> Helper loaded: form_helper
INFO - 2019-07-04 00:26:46 --> Form Validation Class Initialized
DEBUG - 2019-07-04 00:26:46 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 00:26:46 --> Model Class Initialized
INFO - 2019-07-04 00:26:46 --> Model Class Initialized
INFO - 2019-07-04 00:26:46 --> Final output sent to browser
DEBUG - 2019-07-04 00:26:46 --> Total execution time: 0.5623
INFO - 2019-07-04 00:26:47 --> Helper loaded: language_helper
INFO - 2019-07-04 00:26:47 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:26:47 --> Model Class Initialized
INFO - 2019-07-04 00:26:47 --> Model Class Initialized
INFO - 2019-07-04 00:26:47 --> Model Class Initialized
INFO - 2019-07-04 00:26:47 --> Model Class Initialized
INFO - 2019-07-04 00:26:47 --> Helper loaded: form_helper
INFO - 2019-07-04 00:26:47 --> Form Validation Class Initialized
DEBUG - 2019-07-04 00:26:47 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 00:26:47 --> Model Class Initialized
INFO - 2019-07-04 00:26:47 --> Model Class Initialized
INFO - 2019-07-04 00:26:47 --> Final output sent to browser
DEBUG - 2019-07-04 00:26:47 --> Total execution time: 0.5289
INFO - 2019-07-04 00:28:11 --> Helper loaded: language_helper
INFO - 2019-07-04 00:28:11 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:28:11 --> Model Class Initialized
INFO - 2019-07-04 00:28:11 --> Model Class Initialized
INFO - 2019-07-04 00:28:12 --> Model Class Initialized
INFO - 2019-07-04 00:28:12 --> Model Class Initialized
INFO - 2019-07-04 00:28:12 --> Model Class Initialized
INFO - 2019-07-04 00:28:12 --> Final output sent to browser
DEBUG - 2019-07-04 00:28:12 --> Total execution time: 0.5554
INFO - 2019-07-04 00:28:12 --> Helper loaded: language_helper
INFO - 2019-07-04 00:28:12 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:28:12 --> Model Class Initialized
INFO - 2019-07-04 00:28:12 --> Model Class Initialized
INFO - 2019-07-04 00:28:12 --> Model Class Initialized
INFO - 2019-07-04 00:28:12 --> Model Class Initialized
INFO - 2019-07-04 00:28:12 --> Helper loaded: form_helper
INFO - 2019-07-04 00:28:12 --> Form Validation Class Initialized
DEBUG - 2019-07-04 00:28:12 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 00:28:12 --> Model Class Initialized
INFO - 2019-07-04 00:28:12 --> Model Class Initialized
INFO - 2019-07-04 00:28:12 --> Final output sent to browser
DEBUG - 2019-07-04 00:28:12 --> Total execution time: 0.5355
INFO - 2019-07-04 00:28:54 --> Helper loaded: language_helper
INFO - 2019-07-04 00:28:54 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:28:54 --> Model Class Initialized
INFO - 2019-07-04 00:28:54 --> Model Class Initialized
INFO - 2019-07-04 00:28:54 --> Model Class Initialized
INFO - 2019-07-04 00:28:54 --> Model Class Initialized
INFO - 2019-07-04 00:28:54 --> Model Class Initialized
INFO - 2019-07-04 00:28:54 --> Final output sent to browser
DEBUG - 2019-07-04 00:28:54 --> Total execution time: 0.5088
INFO - 2019-07-04 00:28:54 --> Helper loaded: language_helper
INFO - 2019-07-04 00:28:54 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:28:54 --> Model Class Initialized
INFO - 2019-07-04 00:28:54 --> Model Class Initialized
INFO - 2019-07-04 00:28:54 --> Model Class Initialized
INFO - 2019-07-04 00:28:54 --> Model Class Initialized
INFO - 2019-07-04 00:28:54 --> Helper loaded: form_helper
INFO - 2019-07-04 00:28:54 --> Form Validation Class Initialized
DEBUG - 2019-07-04 00:28:54 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 00:28:54 --> Model Class Initialized
INFO - 2019-07-04 00:28:54 --> Model Class Initialized
INFO - 2019-07-04 00:28:54 --> Final output sent to browser
DEBUG - 2019-07-04 00:28:54 --> Total execution time: 0.5409
INFO - 2019-07-04 00:29:39 --> Helper loaded: language_helper
INFO - 2019-07-04 00:29:39 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:29:39 --> Model Class Initialized
INFO - 2019-07-04 00:29:39 --> Model Class Initialized
INFO - 2019-07-04 00:29:39 --> Model Class Initialized
INFO - 2019-07-04 00:29:39 --> Model Class Initialized
INFO - 2019-07-04 00:29:39 --> Model Class Initialized
INFO - 2019-07-04 00:29:39 --> Final output sent to browser
DEBUG - 2019-07-04 00:29:39 --> Total execution time: 0.4931
INFO - 2019-07-04 00:29:39 --> Helper loaded: language_helper
INFO - 2019-07-04 00:29:39 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:29:39 --> Model Class Initialized
INFO - 2019-07-04 00:29:39 --> Model Class Initialized
INFO - 2019-07-04 00:29:39 --> Model Class Initialized
INFO - 2019-07-04 00:29:39 --> Model Class Initialized
INFO - 2019-07-04 00:29:39 --> Helper loaded: form_helper
INFO - 2019-07-04 00:29:39 --> Form Validation Class Initialized
DEBUG - 2019-07-04 00:29:39 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 00:29:39 --> Model Class Initialized
INFO - 2019-07-04 00:29:39 --> Model Class Initialized
INFO - 2019-07-04 00:29:39 --> Final output sent to browser
DEBUG - 2019-07-04 00:29:39 --> Total execution time: 0.5633
INFO - 2019-07-04 00:29:40 --> Helper loaded: language_helper
INFO - 2019-07-04 00:29:40 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:29:40 --> Model Class Initialized
INFO - 2019-07-04 00:29:40 --> Model Class Initialized
INFO - 2019-07-04 00:29:40 --> Model Class Initialized
INFO - 2019-07-04 00:29:40 --> Model Class Initialized
INFO - 2019-07-04 00:29:40 --> Helper loaded: form_helper
INFO - 2019-07-04 00:29:41 --> Form Validation Class Initialized
DEBUG - 2019-07-04 00:29:41 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 00:29:41 --> Model Class Initialized
INFO - 2019-07-04 00:29:41 --> Model Class Initialized
INFO - 2019-07-04 00:29:41 --> Final output sent to browser
DEBUG - 2019-07-04 00:29:41 --> Total execution time: 0.5618
INFO - 2019-07-04 00:30:00 --> Helper loaded: language_helper
INFO - 2019-07-04 00:30:00 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:30:00 --> Model Class Initialized
INFO - 2019-07-04 00:30:00 --> Model Class Initialized
INFO - 2019-07-04 00:30:00 --> Model Class Initialized
INFO - 2019-07-04 00:30:00 --> Model Class Initialized
INFO - 2019-07-04 00:30:00 --> Model Class Initialized
INFO - 2019-07-04 00:30:00 --> Final output sent to browser
DEBUG - 2019-07-04 00:30:00 --> Total execution time: 0.5009
INFO - 2019-07-04 00:30:00 --> Helper loaded: language_helper
INFO - 2019-07-04 00:30:00 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:30:00 --> Model Class Initialized
INFO - 2019-07-04 00:30:00 --> Model Class Initialized
INFO - 2019-07-04 00:30:00 --> Model Class Initialized
INFO - 2019-07-04 00:30:00 --> Model Class Initialized
INFO - 2019-07-04 00:30:00 --> Helper loaded: form_helper
INFO - 2019-07-04 00:30:01 --> Form Validation Class Initialized
DEBUG - 2019-07-04 00:30:01 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 00:30:01 --> Model Class Initialized
INFO - 2019-07-04 00:30:01 --> Model Class Initialized
INFO - 2019-07-04 00:30:01 --> Final output sent to browser
DEBUG - 2019-07-04 00:30:01 --> Total execution time: 0.5649
INFO - 2019-07-04 00:30:02 --> Helper loaded: language_helper
INFO - 2019-07-04 00:30:02 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:30:02 --> Model Class Initialized
INFO - 2019-07-04 00:30:02 --> Model Class Initialized
INFO - 2019-07-04 00:30:02 --> Model Class Initialized
INFO - 2019-07-04 00:30:02 --> Model Class Initialized
INFO - 2019-07-04 00:30:02 --> Helper loaded: form_helper
INFO - 2019-07-04 00:30:02 --> Form Validation Class Initialized
DEBUG - 2019-07-04 00:30:02 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 00:30:02 --> Model Class Initialized
INFO - 2019-07-04 00:30:02 --> Model Class Initialized
INFO - 2019-07-04 00:30:02 --> Final output sent to browser
DEBUG - 2019-07-04 00:30:02 --> Total execution time: 0.5634
INFO - 2019-07-04 00:30:21 --> Helper loaded: language_helper
INFO - 2019-07-04 00:30:21 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:30:21 --> Model Class Initialized
INFO - 2019-07-04 00:30:21 --> Model Class Initialized
INFO - 2019-07-04 00:30:21 --> Model Class Initialized
INFO - 2019-07-04 00:30:21 --> Model Class Initialized
INFO - 2019-07-04 00:30:21 --> Model Class Initialized
INFO - 2019-07-04 00:30:21 --> Final output sent to browser
DEBUG - 2019-07-04 00:30:21 --> Total execution time: 0.5045
INFO - 2019-07-04 00:30:22 --> Helper loaded: language_helper
INFO - 2019-07-04 00:30:22 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:30:22 --> Model Class Initialized
INFO - 2019-07-04 00:30:22 --> Model Class Initialized
INFO - 2019-07-04 00:30:22 --> Model Class Initialized
INFO - 2019-07-04 00:30:22 --> Model Class Initialized
INFO - 2019-07-04 00:30:22 --> Helper loaded: form_helper
INFO - 2019-07-04 00:30:22 --> Form Validation Class Initialized
DEBUG - 2019-07-04 00:30:22 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 00:30:22 --> Model Class Initialized
INFO - 2019-07-04 00:30:22 --> Model Class Initialized
INFO - 2019-07-04 00:30:22 --> Final output sent to browser
DEBUG - 2019-07-04 00:30:22 --> Total execution time: 0.5343
INFO - 2019-07-04 00:30:23 --> Helper loaded: language_helper
INFO - 2019-07-04 00:30:23 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:30:23 --> Model Class Initialized
INFO - 2019-07-04 00:30:23 --> Model Class Initialized
INFO - 2019-07-04 00:30:23 --> Model Class Initialized
INFO - 2019-07-04 00:30:23 --> Model Class Initialized
INFO - 2019-07-04 00:30:23 --> Helper loaded: form_helper
INFO - 2019-07-04 00:30:23 --> Form Validation Class Initialized
DEBUG - 2019-07-04 00:30:23 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 00:30:23 --> Model Class Initialized
INFO - 2019-07-04 00:30:23 --> Model Class Initialized
INFO - 2019-07-04 00:30:23 --> Final output sent to browser
DEBUG - 2019-07-04 00:30:23 --> Total execution time: 0.5633
INFO - 2019-07-04 00:31:57 --> Helper loaded: language_helper
INFO - 2019-07-04 00:31:57 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:31:57 --> Model Class Initialized
INFO - 2019-07-04 00:31:57 --> Model Class Initialized
INFO - 2019-07-04 00:31:57 --> Model Class Initialized
INFO - 2019-07-04 00:31:57 --> Model Class Initialized
INFO - 2019-07-04 00:31:57 --> Model Class Initialized
INFO - 2019-07-04 00:31:57 --> Final output sent to browser
DEBUG - 2019-07-04 00:31:57 --> Total execution time: 0.5126
INFO - 2019-07-04 00:31:58 --> Helper loaded: language_helper
INFO - 2019-07-04 00:31:58 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:31:58 --> Model Class Initialized
INFO - 2019-07-04 00:31:58 --> Model Class Initialized
INFO - 2019-07-04 00:31:58 --> Model Class Initialized
INFO - 2019-07-04 00:31:58 --> Model Class Initialized
INFO - 2019-07-04 00:31:58 --> Helper loaded: form_helper
INFO - 2019-07-04 00:31:58 --> Form Validation Class Initialized
DEBUG - 2019-07-04 00:31:58 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 00:31:58 --> Model Class Initialized
INFO - 2019-07-04 00:31:58 --> Model Class Initialized
INFO - 2019-07-04 00:31:58 --> Final output sent to browser
DEBUG - 2019-07-04 00:31:58 --> Total execution time: 0.5454
INFO - 2019-07-04 00:31:59 --> Helper loaded: language_helper
INFO - 2019-07-04 00:31:59 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:31:59 --> Model Class Initialized
INFO - 2019-07-04 00:31:59 --> Model Class Initialized
INFO - 2019-07-04 00:31:59 --> Model Class Initialized
INFO - 2019-07-04 00:31:59 --> Model Class Initialized
INFO - 2019-07-04 00:31:59 --> Helper loaded: form_helper
INFO - 2019-07-04 00:31:59 --> Form Validation Class Initialized
DEBUG - 2019-07-04 00:31:59 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 00:31:59 --> Model Class Initialized
INFO - 2019-07-04 00:31:59 --> Model Class Initialized
INFO - 2019-07-04 00:31:59 --> Final output sent to browser
DEBUG - 2019-07-04 00:31:59 --> Total execution time: 0.5319
INFO - 2019-07-04 00:32:09 --> Helper loaded: language_helper
INFO - 2019-07-04 00:32:09 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:32:09 --> Model Class Initialized
INFO - 2019-07-04 00:32:09 --> Model Class Initialized
INFO - 2019-07-04 00:32:09 --> Model Class Initialized
INFO - 2019-07-04 00:32:09 --> Model Class Initialized
INFO - 2019-07-04 00:32:09 --> Model Class Initialized
INFO - 2019-07-04 00:32:09 --> Final output sent to browser
DEBUG - 2019-07-04 00:32:09 --> Total execution time: 0.4896
INFO - 2019-07-04 00:32:10 --> Helper loaded: language_helper
INFO - 2019-07-04 00:32:10 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:32:10 --> Model Class Initialized
INFO - 2019-07-04 00:32:10 --> Model Class Initialized
INFO - 2019-07-04 00:32:10 --> Model Class Initialized
INFO - 2019-07-04 00:32:10 --> Model Class Initialized
INFO - 2019-07-04 00:32:10 --> Helper loaded: form_helper
INFO - 2019-07-04 00:32:10 --> Form Validation Class Initialized
DEBUG - 2019-07-04 00:32:10 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 00:32:10 --> Model Class Initialized
INFO - 2019-07-04 00:32:10 --> Model Class Initialized
INFO - 2019-07-04 00:32:10 --> Final output sent to browser
DEBUG - 2019-07-04 00:32:10 --> Total execution time: 0.5345
INFO - 2019-07-04 00:32:12 --> Helper loaded: language_helper
INFO - 2019-07-04 00:32:12 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:32:12 --> Model Class Initialized
INFO - 2019-07-04 00:32:12 --> Model Class Initialized
INFO - 2019-07-04 00:32:12 --> Model Class Initialized
INFO - 2019-07-04 00:32:12 --> Model Class Initialized
INFO - 2019-07-04 00:32:12 --> Helper loaded: form_helper
INFO - 2019-07-04 00:32:12 --> Form Validation Class Initialized
DEBUG - 2019-07-04 00:32:12 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 00:32:12 --> Model Class Initialized
INFO - 2019-07-04 00:32:12 --> Model Class Initialized
INFO - 2019-07-04 00:32:12 --> Final output sent to browser
DEBUG - 2019-07-04 00:32:12 --> Total execution time: 0.5578
INFO - 2019-07-04 00:32:27 --> Helper loaded: language_helper
INFO - 2019-07-04 00:32:27 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:32:27 --> Model Class Initialized
INFO - 2019-07-04 00:32:27 --> Model Class Initialized
INFO - 2019-07-04 00:32:27 --> Model Class Initialized
INFO - 2019-07-04 00:32:27 --> Model Class Initialized
INFO - 2019-07-04 00:32:27 --> Model Class Initialized
INFO - 2019-07-04 00:32:27 --> Final output sent to browser
DEBUG - 2019-07-04 00:32:27 --> Total execution time: 0.5037
INFO - 2019-07-04 00:32:28 --> Helper loaded: language_helper
INFO - 2019-07-04 00:32:28 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:32:28 --> Model Class Initialized
INFO - 2019-07-04 00:32:28 --> Model Class Initialized
INFO - 2019-07-04 00:32:28 --> Model Class Initialized
INFO - 2019-07-04 00:32:28 --> Model Class Initialized
INFO - 2019-07-04 00:32:28 --> Helper loaded: form_helper
INFO - 2019-07-04 00:32:28 --> Form Validation Class Initialized
DEBUG - 2019-07-04 00:32:28 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 00:32:28 --> Model Class Initialized
INFO - 2019-07-04 00:32:28 --> Model Class Initialized
INFO - 2019-07-04 00:32:28 --> Final output sent to browser
DEBUG - 2019-07-04 00:32:28 --> Total execution time: 0.5617
INFO - 2019-07-04 00:32:30 --> Helper loaded: language_helper
INFO - 2019-07-04 00:32:30 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:32:30 --> Model Class Initialized
INFO - 2019-07-04 00:32:30 --> Model Class Initialized
INFO - 2019-07-04 00:32:30 --> Model Class Initialized
INFO - 2019-07-04 00:32:30 --> Model Class Initialized
INFO - 2019-07-04 00:32:30 --> Helper loaded: form_helper
INFO - 2019-07-04 00:32:30 --> Form Validation Class Initialized
DEBUG - 2019-07-04 00:32:30 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 00:32:30 --> Model Class Initialized
INFO - 2019-07-04 00:32:30 --> Model Class Initialized
INFO - 2019-07-04 00:32:30 --> Final output sent to browser
DEBUG - 2019-07-04 00:32:30 --> Total execution time: 0.5831
INFO - 2019-07-04 00:32:40 --> Helper loaded: language_helper
INFO - 2019-07-04 00:32:40 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:32:40 --> Model Class Initialized
INFO - 2019-07-04 00:32:40 --> Model Class Initialized
INFO - 2019-07-04 00:32:40 --> Model Class Initialized
INFO - 2019-07-04 00:32:40 --> Model Class Initialized
INFO - 2019-07-04 00:32:40 --> Model Class Initialized
INFO - 2019-07-04 00:32:40 --> Final output sent to browser
DEBUG - 2019-07-04 00:32:40 --> Total execution time: 0.5044
INFO - 2019-07-04 00:32:40 --> Helper loaded: language_helper
INFO - 2019-07-04 00:32:40 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:32:40 --> Model Class Initialized
INFO - 2019-07-04 00:32:40 --> Model Class Initialized
INFO - 2019-07-04 00:32:40 --> Model Class Initialized
INFO - 2019-07-04 00:32:40 --> Model Class Initialized
INFO - 2019-07-04 00:32:40 --> Helper loaded: form_helper
INFO - 2019-07-04 00:32:40 --> Form Validation Class Initialized
DEBUG - 2019-07-04 00:32:40 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 00:32:40 --> Model Class Initialized
INFO - 2019-07-04 00:32:40 --> Model Class Initialized
INFO - 2019-07-04 00:32:40 --> Final output sent to browser
DEBUG - 2019-07-04 00:32:40 --> Total execution time: 0.5763
INFO - 2019-07-04 00:32:41 --> Helper loaded: language_helper
INFO - 2019-07-04 00:32:41 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:32:41 --> Model Class Initialized
INFO - 2019-07-04 00:32:41 --> Model Class Initialized
INFO - 2019-07-04 00:32:41 --> Model Class Initialized
INFO - 2019-07-04 00:32:41 --> Model Class Initialized
INFO - 2019-07-04 00:32:41 --> Helper loaded: form_helper
INFO - 2019-07-04 00:32:41 --> Form Validation Class Initialized
DEBUG - 2019-07-04 00:32:41 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 00:32:41 --> Model Class Initialized
INFO - 2019-07-04 00:32:41 --> Model Class Initialized
INFO - 2019-07-04 00:32:41 --> Final output sent to browser
DEBUG - 2019-07-04 00:32:41 --> Total execution time: 0.5686
INFO - 2019-07-04 00:33:37 --> Helper loaded: language_helper
INFO - 2019-07-04 00:33:37 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:33:37 --> Model Class Initialized
INFO - 2019-07-04 00:33:37 --> Model Class Initialized
INFO - 2019-07-04 00:33:37 --> Model Class Initialized
INFO - 2019-07-04 00:33:37 --> Model Class Initialized
INFO - 2019-07-04 00:33:37 --> Model Class Initialized
INFO - 2019-07-04 00:33:37 --> Final output sent to browser
DEBUG - 2019-07-04 00:33:37 --> Total execution time: 0.5819
INFO - 2019-07-04 00:33:37 --> Helper loaded: language_helper
INFO - 2019-07-04 00:33:37 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:33:37 --> Model Class Initialized
INFO - 2019-07-04 00:33:37 --> Model Class Initialized
INFO - 2019-07-04 00:33:37 --> Model Class Initialized
INFO - 2019-07-04 00:33:37 --> Model Class Initialized
INFO - 2019-07-04 00:33:37 --> Helper loaded: form_helper
INFO - 2019-07-04 00:33:37 --> Form Validation Class Initialized
DEBUG - 2019-07-04 00:33:37 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 00:33:37 --> Model Class Initialized
INFO - 2019-07-04 00:33:37 --> Model Class Initialized
INFO - 2019-07-04 00:33:37 --> Final output sent to browser
DEBUG - 2019-07-04 00:33:37 --> Total execution time: 0.5392
INFO - 2019-07-04 00:33:40 --> Helper loaded: language_helper
INFO - 2019-07-04 00:33:40 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:33:40 --> Model Class Initialized
INFO - 2019-07-04 00:33:40 --> Model Class Initialized
INFO - 2019-07-04 00:33:40 --> Model Class Initialized
INFO - 2019-07-04 00:33:40 --> Model Class Initialized
INFO - 2019-07-04 00:33:40 --> Model Class Initialized
INFO - 2019-07-04 00:33:40 --> Final output sent to browser
DEBUG - 2019-07-04 00:33:40 --> Total execution time: 0.5284
INFO - 2019-07-04 00:33:40 --> Helper loaded: language_helper
INFO - 2019-07-04 00:33:40 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:33:40 --> Model Class Initialized
INFO - 2019-07-04 00:33:40 --> Model Class Initialized
INFO - 2019-07-04 00:33:40 --> Model Class Initialized
INFO - 2019-07-04 00:33:41 --> Model Class Initialized
INFO - 2019-07-04 00:33:41 --> Helper loaded: form_helper
INFO - 2019-07-04 00:33:41 --> Form Validation Class Initialized
DEBUG - 2019-07-04 00:33:41 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 00:33:41 --> Model Class Initialized
INFO - 2019-07-04 00:33:41 --> Model Class Initialized
INFO - 2019-07-04 00:33:41 --> Final output sent to browser
DEBUG - 2019-07-04 00:33:41 --> Total execution time: 0.5846
INFO - 2019-07-04 00:33:42 --> Helper loaded: language_helper
INFO - 2019-07-04 00:33:42 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:33:42 --> Model Class Initialized
INFO - 2019-07-04 00:33:42 --> Model Class Initialized
INFO - 2019-07-04 00:33:42 --> Model Class Initialized
INFO - 2019-07-04 00:33:42 --> Model Class Initialized
INFO - 2019-07-04 00:33:42 --> Helper loaded: form_helper
INFO - 2019-07-04 00:33:42 --> Form Validation Class Initialized
DEBUG - 2019-07-04 00:33:42 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 00:33:42 --> Model Class Initialized
INFO - 2019-07-04 00:33:42 --> Model Class Initialized
INFO - 2019-07-04 00:33:42 --> Final output sent to browser
DEBUG - 2019-07-04 00:33:42 --> Total execution time: 0.5630
INFO - 2019-07-04 00:33:55 --> Helper loaded: language_helper
INFO - 2019-07-04 00:33:55 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:33:55 --> Model Class Initialized
INFO - 2019-07-04 00:33:55 --> Model Class Initialized
INFO - 2019-07-04 00:33:55 --> Model Class Initialized
INFO - 2019-07-04 00:33:55 --> Model Class Initialized
INFO - 2019-07-04 00:33:55 --> Model Class Initialized
INFO - 2019-07-04 00:33:55 --> Final output sent to browser
DEBUG - 2019-07-04 00:33:55 --> Total execution time: 0.5166
INFO - 2019-07-04 00:33:56 --> Helper loaded: language_helper
INFO - 2019-07-04 00:33:56 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:33:56 --> Model Class Initialized
INFO - 2019-07-04 00:33:56 --> Model Class Initialized
INFO - 2019-07-04 00:33:56 --> Model Class Initialized
INFO - 2019-07-04 00:33:56 --> Model Class Initialized
INFO - 2019-07-04 00:33:56 --> Helper loaded: form_helper
INFO - 2019-07-04 00:33:56 --> Form Validation Class Initialized
DEBUG - 2019-07-04 00:33:56 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 00:33:56 --> Model Class Initialized
INFO - 2019-07-04 00:33:56 --> Model Class Initialized
INFO - 2019-07-04 00:33:56 --> Final output sent to browser
DEBUG - 2019-07-04 00:33:56 --> Total execution time: 0.5534
INFO - 2019-07-04 00:33:57 --> Helper loaded: language_helper
INFO - 2019-07-04 00:33:57 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:33:57 --> Model Class Initialized
INFO - 2019-07-04 00:33:57 --> Model Class Initialized
INFO - 2019-07-04 00:33:57 --> Model Class Initialized
INFO - 2019-07-04 00:33:57 --> Model Class Initialized
INFO - 2019-07-04 00:33:57 --> Helper loaded: form_helper
INFO - 2019-07-04 00:33:57 --> Form Validation Class Initialized
DEBUG - 2019-07-04 00:33:57 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 00:33:57 --> Model Class Initialized
INFO - 2019-07-04 00:33:57 --> Model Class Initialized
INFO - 2019-07-04 00:33:57 --> Final output sent to browser
DEBUG - 2019-07-04 00:33:57 --> Total execution time: 0.5314
INFO - 2019-07-04 00:34:07 --> Helper loaded: language_helper
INFO - 2019-07-04 00:34:07 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:34:07 --> Model Class Initialized
INFO - 2019-07-04 00:34:07 --> Model Class Initialized
INFO - 2019-07-04 00:34:07 --> Model Class Initialized
INFO - 2019-07-04 00:34:07 --> Model Class Initialized
INFO - 2019-07-04 00:34:07 --> Model Class Initialized
INFO - 2019-07-04 00:34:07 --> Final output sent to browser
DEBUG - 2019-07-04 00:34:07 --> Total execution time: 0.4813
INFO - 2019-07-04 00:34:08 --> Helper loaded: language_helper
INFO - 2019-07-04 00:34:08 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:34:08 --> Model Class Initialized
INFO - 2019-07-04 00:34:08 --> Model Class Initialized
INFO - 2019-07-04 00:34:08 --> Model Class Initialized
INFO - 2019-07-04 00:34:08 --> Model Class Initialized
INFO - 2019-07-04 00:34:08 --> Helper loaded: form_helper
INFO - 2019-07-04 00:34:08 --> Form Validation Class Initialized
DEBUG - 2019-07-04 00:34:08 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 00:34:08 --> Model Class Initialized
INFO - 2019-07-04 00:34:08 --> Model Class Initialized
INFO - 2019-07-04 00:34:08 --> Final output sent to browser
DEBUG - 2019-07-04 00:34:08 --> Total execution time: 0.5493
INFO - 2019-07-04 00:34:10 --> Helper loaded: language_helper
INFO - 2019-07-04 00:34:10 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:34:10 --> Model Class Initialized
INFO - 2019-07-04 00:34:10 --> Model Class Initialized
INFO - 2019-07-04 00:34:10 --> Model Class Initialized
INFO - 2019-07-04 00:34:10 --> Model Class Initialized
INFO - 2019-07-04 00:34:10 --> Helper loaded: form_helper
INFO - 2019-07-04 00:34:10 --> Form Validation Class Initialized
DEBUG - 2019-07-04 00:34:10 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 00:34:10 --> Model Class Initialized
INFO - 2019-07-04 00:34:10 --> Model Class Initialized
INFO - 2019-07-04 00:34:10 --> Final output sent to browser
DEBUG - 2019-07-04 00:34:10 --> Total execution time: 0.5713
INFO - 2019-07-04 00:34:34 --> Helper loaded: language_helper
INFO - 2019-07-04 00:34:34 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:34:34 --> Model Class Initialized
INFO - 2019-07-04 00:34:34 --> Model Class Initialized
INFO - 2019-07-04 00:34:34 --> Model Class Initialized
INFO - 2019-07-04 00:34:34 --> Model Class Initialized
INFO - 2019-07-04 00:34:34 --> Model Class Initialized
INFO - 2019-07-04 00:34:34 --> Final output sent to browser
DEBUG - 2019-07-04 00:34:34 --> Total execution time: 0.5381
INFO - 2019-07-04 00:34:35 --> Helper loaded: language_helper
INFO - 2019-07-04 00:34:35 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:34:35 --> Model Class Initialized
INFO - 2019-07-04 00:34:35 --> Model Class Initialized
INFO - 2019-07-04 00:34:35 --> Model Class Initialized
INFO - 2019-07-04 00:34:35 --> Model Class Initialized
INFO - 2019-07-04 00:34:35 --> Helper loaded: form_helper
INFO - 2019-07-04 00:34:35 --> Form Validation Class Initialized
DEBUG - 2019-07-04 00:34:35 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 00:34:35 --> Model Class Initialized
INFO - 2019-07-04 00:34:35 --> Model Class Initialized
INFO - 2019-07-04 00:34:35 --> Final output sent to browser
DEBUG - 2019-07-04 00:34:35 --> Total execution time: 0.5496
INFO - 2019-07-04 00:34:46 --> Helper loaded: language_helper
INFO - 2019-07-04 00:34:46 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:34:46 --> Model Class Initialized
INFO - 2019-07-04 00:34:46 --> Model Class Initialized
INFO - 2019-07-04 00:34:46 --> Model Class Initialized
INFO - 2019-07-04 00:34:46 --> Model Class Initialized
INFO - 2019-07-04 00:34:46 --> Helper loaded: form_helper
INFO - 2019-07-04 00:34:46 --> Form Validation Class Initialized
DEBUG - 2019-07-04 00:34:46 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 00:34:46 --> Model Class Initialized
INFO - 2019-07-04 00:34:46 --> Model Class Initialized
INFO - 2019-07-04 00:34:46 --> Final output sent to browser
DEBUG - 2019-07-04 00:34:47 --> Total execution time: 0.5696
INFO - 2019-07-04 00:35:40 --> Helper loaded: language_helper
INFO - 2019-07-04 00:35:40 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:35:40 --> Model Class Initialized
INFO - 2019-07-04 00:35:40 --> Model Class Initialized
INFO - 2019-07-04 00:35:40 --> Model Class Initialized
INFO - 2019-07-04 00:35:40 --> Model Class Initialized
INFO - 2019-07-04 00:35:40 --> Model Class Initialized
INFO - 2019-07-04 00:35:40 --> Final output sent to browser
DEBUG - 2019-07-04 00:35:40 --> Total execution time: 0.5100
INFO - 2019-07-04 00:35:41 --> Helper loaded: language_helper
INFO - 2019-07-04 00:35:41 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:35:41 --> Model Class Initialized
INFO - 2019-07-04 00:35:41 --> Model Class Initialized
INFO - 2019-07-04 00:35:41 --> Model Class Initialized
INFO - 2019-07-04 00:35:41 --> Model Class Initialized
INFO - 2019-07-04 00:35:41 --> Helper loaded: form_helper
INFO - 2019-07-04 00:35:41 --> Form Validation Class Initialized
DEBUG - 2019-07-04 00:35:41 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 00:35:41 --> Model Class Initialized
INFO - 2019-07-04 00:35:41 --> Model Class Initialized
INFO - 2019-07-04 00:35:41 --> Final output sent to browser
DEBUG - 2019-07-04 00:35:41 --> Total execution time: 0.5673
INFO - 2019-07-04 00:35:42 --> Helper loaded: language_helper
INFO - 2019-07-04 00:35:42 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:35:42 --> Model Class Initialized
INFO - 2019-07-04 00:35:42 --> Model Class Initialized
INFO - 2019-07-04 00:35:42 --> Model Class Initialized
INFO - 2019-07-04 00:35:42 --> Model Class Initialized
INFO - 2019-07-04 00:35:42 --> Helper loaded: form_helper
INFO - 2019-07-04 00:35:42 --> Form Validation Class Initialized
DEBUG - 2019-07-04 00:35:42 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 00:35:42 --> Model Class Initialized
INFO - 2019-07-04 00:35:42 --> Model Class Initialized
INFO - 2019-07-04 00:35:42 --> Final output sent to browser
DEBUG - 2019-07-04 00:35:42 --> Total execution time: 0.5502
INFO - 2019-07-04 00:36:59 --> Helper loaded: language_helper
INFO - 2019-07-04 00:36:59 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:36:59 --> Model Class Initialized
INFO - 2019-07-04 00:36:59 --> Model Class Initialized
INFO - 2019-07-04 00:36:59 --> Model Class Initialized
INFO - 2019-07-04 00:36:59 --> Model Class Initialized
INFO - 2019-07-04 00:36:59 --> Model Class Initialized
INFO - 2019-07-04 00:36:59 --> Final output sent to browser
DEBUG - 2019-07-04 00:36:59 --> Total execution time: 0.5212
INFO - 2019-07-04 00:36:59 --> Helper loaded: language_helper
INFO - 2019-07-04 00:36:59 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:36:59 --> Model Class Initialized
INFO - 2019-07-04 00:36:59 --> Model Class Initialized
INFO - 2019-07-04 00:36:59 --> Model Class Initialized
INFO - 2019-07-04 00:36:59 --> Model Class Initialized
INFO - 2019-07-04 00:36:59 --> Helper loaded: form_helper
INFO - 2019-07-04 00:36:59 --> Form Validation Class Initialized
DEBUG - 2019-07-04 00:36:59 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 00:36:59 --> Model Class Initialized
INFO - 2019-07-04 00:36:59 --> Model Class Initialized
INFO - 2019-07-04 00:36:59 --> Final output sent to browser
DEBUG - 2019-07-04 00:36:59 --> Total execution time: 0.5667
INFO - 2019-07-04 00:37:00 --> Helper loaded: language_helper
INFO - 2019-07-04 00:37:00 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:37:00 --> Model Class Initialized
INFO - 2019-07-04 00:37:00 --> Model Class Initialized
INFO - 2019-07-04 00:37:00 --> Model Class Initialized
INFO - 2019-07-04 00:37:00 --> Model Class Initialized
INFO - 2019-07-04 00:37:00 --> Helper loaded: form_helper
INFO - 2019-07-04 00:37:00 --> Form Validation Class Initialized
DEBUG - 2019-07-04 00:37:00 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 00:37:00 --> Model Class Initialized
INFO - 2019-07-04 00:37:00 --> Model Class Initialized
INFO - 2019-07-04 00:37:00 --> Final output sent to browser
DEBUG - 2019-07-04 00:37:00 --> Total execution time: 0.5608
INFO - 2019-07-04 00:37:41 --> Helper loaded: language_helper
INFO - 2019-07-04 00:37:41 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:37:41 --> Model Class Initialized
INFO - 2019-07-04 00:37:41 --> Model Class Initialized
INFO - 2019-07-04 00:37:41 --> Model Class Initialized
INFO - 2019-07-04 00:37:41 --> Model Class Initialized
INFO - 2019-07-04 00:37:41 --> Model Class Initialized
INFO - 2019-07-04 00:37:41 --> Final output sent to browser
DEBUG - 2019-07-04 00:37:41 --> Total execution time: 0.5010
INFO - 2019-07-04 00:37:41 --> Helper loaded: language_helper
INFO - 2019-07-04 00:37:41 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:37:41 --> Model Class Initialized
INFO - 2019-07-04 00:37:41 --> Model Class Initialized
INFO - 2019-07-04 00:37:41 --> Model Class Initialized
INFO - 2019-07-04 00:37:41 --> Model Class Initialized
INFO - 2019-07-04 00:37:41 --> Helper loaded: form_helper
INFO - 2019-07-04 00:37:41 --> Form Validation Class Initialized
DEBUG - 2019-07-04 00:37:41 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 00:37:41 --> Model Class Initialized
INFO - 2019-07-04 00:37:41 --> Model Class Initialized
INFO - 2019-07-04 00:37:41 --> Final output sent to browser
DEBUG - 2019-07-04 00:37:41 --> Total execution time: 0.5681
INFO - 2019-07-04 00:37:42 --> Helper loaded: language_helper
INFO - 2019-07-04 00:37:42 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:37:42 --> Model Class Initialized
INFO - 2019-07-04 00:37:42 --> Model Class Initialized
INFO - 2019-07-04 00:37:42 --> Model Class Initialized
INFO - 2019-07-04 00:37:42 --> Model Class Initialized
INFO - 2019-07-04 00:37:42 --> Helper loaded: form_helper
INFO - 2019-07-04 00:37:42 --> Form Validation Class Initialized
DEBUG - 2019-07-04 00:37:42 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 00:37:42 --> Model Class Initialized
INFO - 2019-07-04 00:37:42 --> Model Class Initialized
INFO - 2019-07-04 00:37:42 --> Final output sent to browser
DEBUG - 2019-07-04 00:37:42 --> Total execution time: 0.5476
INFO - 2019-07-04 00:37:53 --> Helper loaded: language_helper
INFO - 2019-07-04 00:37:53 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:37:53 --> Model Class Initialized
INFO - 2019-07-04 00:37:53 --> Model Class Initialized
INFO - 2019-07-04 00:37:53 --> Model Class Initialized
INFO - 2019-07-04 00:37:53 --> Model Class Initialized
INFO - 2019-07-04 00:37:53 --> Model Class Initialized
INFO - 2019-07-04 00:37:53 --> Final output sent to browser
DEBUG - 2019-07-04 00:37:53 --> Total execution time: 0.4965
INFO - 2019-07-04 00:37:53 --> Helper loaded: language_helper
INFO - 2019-07-04 00:37:53 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:37:53 --> Model Class Initialized
INFO - 2019-07-04 00:37:53 --> Model Class Initialized
INFO - 2019-07-04 00:37:53 --> Model Class Initialized
INFO - 2019-07-04 00:37:53 --> Model Class Initialized
INFO - 2019-07-04 00:37:53 --> Helper loaded: form_helper
INFO - 2019-07-04 00:37:53 --> Form Validation Class Initialized
DEBUG - 2019-07-04 00:37:53 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 00:37:53 --> Model Class Initialized
INFO - 2019-07-04 00:37:53 --> Model Class Initialized
INFO - 2019-07-04 00:37:53 --> Final output sent to browser
DEBUG - 2019-07-04 00:37:53 --> Total execution time: 0.5518
INFO - 2019-07-04 00:38:14 --> Helper loaded: language_helper
INFO - 2019-07-04 00:38:14 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:38:14 --> Model Class Initialized
INFO - 2019-07-04 00:38:14 --> Model Class Initialized
INFO - 2019-07-04 00:38:14 --> Model Class Initialized
INFO - 2019-07-04 00:38:14 --> Model Class Initialized
INFO - 2019-07-04 00:38:14 --> Model Class Initialized
INFO - 2019-07-04 00:38:14 --> Final output sent to browser
DEBUG - 2019-07-04 00:38:14 --> Total execution time: 0.5112
INFO - 2019-07-04 00:38:15 --> Helper loaded: language_helper
INFO - 2019-07-04 00:38:15 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:38:15 --> Model Class Initialized
INFO - 2019-07-04 00:38:15 --> Model Class Initialized
INFO - 2019-07-04 00:38:15 --> Model Class Initialized
INFO - 2019-07-04 00:38:15 --> Model Class Initialized
INFO - 2019-07-04 00:38:15 --> Helper loaded: form_helper
INFO - 2019-07-04 00:38:15 --> Form Validation Class Initialized
DEBUG - 2019-07-04 00:38:15 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 00:38:15 --> Model Class Initialized
INFO - 2019-07-04 00:38:15 --> Model Class Initialized
INFO - 2019-07-04 00:38:15 --> Final output sent to browser
DEBUG - 2019-07-04 00:38:15 --> Total execution time: 0.5533
INFO - 2019-07-04 00:38:16 --> Helper loaded: language_helper
INFO - 2019-07-04 00:38:16 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:38:16 --> Model Class Initialized
INFO - 2019-07-04 00:38:16 --> Model Class Initialized
INFO - 2019-07-04 00:38:16 --> Model Class Initialized
INFO - 2019-07-04 00:38:16 --> Model Class Initialized
INFO - 2019-07-04 00:38:16 --> Helper loaded: form_helper
INFO - 2019-07-04 00:38:16 --> Form Validation Class Initialized
DEBUG - 2019-07-04 00:38:16 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 00:38:16 --> Model Class Initialized
INFO - 2019-07-04 00:38:16 --> Model Class Initialized
INFO - 2019-07-04 00:38:16 --> Final output sent to browser
DEBUG - 2019-07-04 00:38:16 --> Total execution time: 0.5677
INFO - 2019-07-04 00:38:41 --> Helper loaded: language_helper
INFO - 2019-07-04 00:38:41 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:38:41 --> Model Class Initialized
INFO - 2019-07-04 00:38:41 --> Model Class Initialized
INFO - 2019-07-04 00:38:41 --> Model Class Initialized
INFO - 2019-07-04 00:38:41 --> Model Class Initialized
INFO - 2019-07-04 00:38:41 --> Model Class Initialized
INFO - 2019-07-04 00:38:41 --> Final output sent to browser
DEBUG - 2019-07-04 00:38:41 --> Total execution time: 0.4924
INFO - 2019-07-04 00:38:42 --> Helper loaded: language_helper
INFO - 2019-07-04 00:38:42 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:38:42 --> Model Class Initialized
INFO - 2019-07-04 00:38:42 --> Model Class Initialized
INFO - 2019-07-04 00:38:42 --> Model Class Initialized
INFO - 2019-07-04 00:38:42 --> Model Class Initialized
INFO - 2019-07-04 00:38:42 --> Helper loaded: form_helper
INFO - 2019-07-04 00:38:42 --> Form Validation Class Initialized
DEBUG - 2019-07-04 00:38:42 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 00:38:42 --> Model Class Initialized
INFO - 2019-07-04 00:38:42 --> Model Class Initialized
INFO - 2019-07-04 00:38:42 --> Final output sent to browser
DEBUG - 2019-07-04 00:38:42 --> Total execution time: 0.5635
INFO - 2019-07-04 00:38:43 --> Helper loaded: language_helper
INFO - 2019-07-04 00:38:43 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:38:43 --> Model Class Initialized
INFO - 2019-07-04 00:38:43 --> Model Class Initialized
INFO - 2019-07-04 00:38:43 --> Model Class Initialized
INFO - 2019-07-04 00:38:43 --> Model Class Initialized
INFO - 2019-07-04 00:38:43 --> Helper loaded: form_helper
INFO - 2019-07-04 00:38:43 --> Form Validation Class Initialized
DEBUG - 2019-07-04 00:38:43 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 00:38:43 --> Model Class Initialized
INFO - 2019-07-04 00:38:43 --> Model Class Initialized
INFO - 2019-07-04 00:38:43 --> Final output sent to browser
DEBUG - 2019-07-04 00:38:43 --> Total execution time: 0.5776
INFO - 2019-07-04 00:38:53 --> Helper loaded: language_helper
INFO - 2019-07-04 00:38:53 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:38:53 --> Model Class Initialized
INFO - 2019-07-04 00:38:53 --> Model Class Initialized
INFO - 2019-07-04 00:38:53 --> Model Class Initialized
INFO - 2019-07-04 00:38:53 --> Model Class Initialized
INFO - 2019-07-04 00:38:53 --> Model Class Initialized
INFO - 2019-07-04 00:38:53 --> Final output sent to browser
DEBUG - 2019-07-04 00:38:53 --> Total execution time: 0.5268
INFO - 2019-07-04 00:38:54 --> Helper loaded: language_helper
INFO - 2019-07-04 00:38:54 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:38:54 --> Model Class Initialized
INFO - 2019-07-04 00:38:54 --> Model Class Initialized
INFO - 2019-07-04 00:38:54 --> Model Class Initialized
INFO - 2019-07-04 00:38:54 --> Model Class Initialized
INFO - 2019-07-04 00:38:54 --> Helper loaded: form_helper
INFO - 2019-07-04 00:38:54 --> Form Validation Class Initialized
DEBUG - 2019-07-04 00:38:54 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 00:38:54 --> Model Class Initialized
INFO - 2019-07-04 00:38:54 --> Model Class Initialized
INFO - 2019-07-04 00:38:54 --> Final output sent to browser
DEBUG - 2019-07-04 00:38:54 --> Total execution time: 0.5655
INFO - 2019-07-04 00:38:55 --> Helper loaded: language_helper
INFO - 2019-07-04 00:38:55 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 00:38:55 --> Model Class Initialized
INFO - 2019-07-04 00:38:55 --> Model Class Initialized
INFO - 2019-07-04 00:38:55 --> Model Class Initialized
INFO - 2019-07-04 00:38:55 --> Model Class Initialized
INFO - 2019-07-04 00:38:55 --> Helper loaded: form_helper
INFO - 2019-07-04 00:38:55 --> Form Validation Class Initialized
DEBUG - 2019-07-04 00:38:55 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 00:38:55 --> Model Class Initialized
INFO - 2019-07-04 00:38:55 --> Model Class Initialized
INFO - 2019-07-04 00:38:55 --> Final output sent to browser
DEBUG - 2019-07-04 00:38:55 --> Total execution time: 0.5814
INFO - 2019-07-04 01:00:56 --> Helper loaded: language_helper
INFO - 2019-07-04 01:00:56 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 01:00:56 --> Model Class Initialized
INFO - 2019-07-04 01:00:56 --> Model Class Initialized
INFO - 2019-07-04 01:00:56 --> Model Class Initialized
INFO - 2019-07-04 01:00:56 --> Model Class Initialized
INFO - 2019-07-04 01:00:56 --> Final output sent to browser
DEBUG - 2019-07-04 01:00:56 --> Total execution time: 0.5475
INFO - 2019-07-04 01:00:57 --> Helper loaded: language_helper
INFO - 2019-07-04 01:00:57 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 01:00:57 --> Model Class Initialized
INFO - 2019-07-04 01:00:57 --> Model Class Initialized
INFO - 2019-07-04 01:00:57 --> Model Class Initialized
INFO - 2019-07-04 01:00:57 --> Model Class Initialized
INFO - 2019-07-04 01:00:57 --> Model Class Initialized
INFO - 2019-07-04 01:00:57 --> Final output sent to browser
DEBUG - 2019-07-04 01:00:57 --> Total execution time: 0.7741
INFO - 2019-07-04 01:00:57 --> Helper loaded: language_helper
INFO - 2019-07-04 01:00:57 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 01:00:57 --> Model Class Initialized
INFO - 2019-07-04 01:00:57 --> Model Class Initialized
INFO - 2019-07-04 01:00:57 --> Model Class Initialized
INFO - 2019-07-04 01:00:57 --> Model Class Initialized
INFO - 2019-07-04 01:00:57 --> Final output sent to browser
DEBUG - 2019-07-04 01:00:57 --> Total execution time: 0.9331
INFO - 2019-07-04 01:00:59 --> Helper loaded: language_helper
INFO - 2019-07-04 01:00:59 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 01:00:59 --> Model Class Initialized
INFO - 2019-07-04 01:00:59 --> Model Class Initialized
INFO - 2019-07-04 01:00:59 --> Model Class Initialized
INFO - 2019-07-04 01:00:59 --> Model Class Initialized
INFO - 2019-07-04 01:00:59 --> Final output sent to browser
DEBUG - 2019-07-04 01:00:59 --> Total execution time: 0.5286
INFO - 2019-07-04 01:01:05 --> Helper loaded: language_helper
INFO - 2019-07-04 01:01:05 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 01:01:05 --> Model Class Initialized
INFO - 2019-07-04 01:01:05 --> Model Class Initialized
INFO - 2019-07-04 01:01:05 --> Model Class Initialized
INFO - 2019-07-04 01:01:05 --> Model Class Initialized
INFO - 2019-07-04 01:01:05 --> Final output sent to browser
DEBUG - 2019-07-04 01:01:05 --> Total execution time: 0.5318
INFO - 2019-07-04 01:01:06 --> Helper loaded: language_helper
INFO - 2019-07-04 01:01:06 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 01:01:06 --> Model Class Initialized
INFO - 2019-07-04 01:01:06 --> Model Class Initialized
INFO - 2019-07-04 01:01:06 --> Model Class Initialized
INFO - 2019-07-04 01:01:06 --> Model Class Initialized
INFO - 2019-07-04 01:01:06 --> Final output sent to browser
DEBUG - 2019-07-04 01:01:06 --> Total execution time: 0.5524
INFO - 2019-07-04 01:01:09 --> Helper loaded: language_helper
INFO - 2019-07-04 01:01:09 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 01:01:09 --> Model Class Initialized
INFO - 2019-07-04 01:01:09 --> Model Class Initialized
INFO - 2019-07-04 01:01:09 --> Model Class Initialized
INFO - 2019-07-04 01:01:09 --> Model Class Initialized
INFO - 2019-07-04 01:01:09 --> Final output sent to browser
DEBUG - 2019-07-04 01:01:09 --> Total execution time: 0.5401
INFO - 2019-07-04 01:01:13 --> Helper loaded: language_helper
INFO - 2019-07-04 01:01:13 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 01:01:13 --> Model Class Initialized
INFO - 2019-07-04 01:01:13 --> Model Class Initialized
INFO - 2019-07-04 01:01:13 --> Model Class Initialized
INFO - 2019-07-04 01:01:13 --> Model Class Initialized
INFO - 2019-07-04 01:01:13 --> Final output sent to browser
DEBUG - 2019-07-04 01:01:13 --> Total execution time: 0.5172
INFO - 2019-07-04 01:01:14 --> Helper loaded: language_helper
INFO - 2019-07-04 01:01:14 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 01:01:14 --> Model Class Initialized
INFO - 2019-07-04 01:01:14 --> Model Class Initialized
INFO - 2019-07-04 01:01:14 --> Model Class Initialized
INFO - 2019-07-04 01:01:14 --> Model Class Initialized
INFO - 2019-07-04 01:01:14 --> Final output sent to browser
DEBUG - 2019-07-04 01:01:14 --> Total execution time: 0.5323
INFO - 2019-07-04 01:01:46 --> Helper loaded: language_helper
INFO - 2019-07-04 01:01:46 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 01:01:46 --> Model Class Initialized
INFO - 2019-07-04 01:01:46 --> Model Class Initialized
INFO - 2019-07-04 01:01:46 --> Model Class Initialized
INFO - 2019-07-04 01:01:46 --> Model Class Initialized
INFO - 2019-07-04 01:01:47 --> Final output sent to browser
DEBUG - 2019-07-04 01:01:47 --> Total execution time: 0.6022
INFO - 2019-07-04 01:01:47 --> Helper loaded: language_helper
INFO - 2019-07-04 01:01:47 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 01:01:47 --> Model Class Initialized
INFO - 2019-07-04 01:01:47 --> Model Class Initialized
INFO - 2019-07-04 01:01:47 --> Model Class Initialized
INFO - 2019-07-04 01:01:47 --> Model Class Initialized
INFO - 2019-07-04 01:01:47 --> Final output sent to browser
DEBUG - 2019-07-04 01:01:47 --> Total execution time: 0.5513
INFO - 2019-07-04 01:01:49 --> Helper loaded: language_helper
INFO - 2019-07-04 01:01:49 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 01:01:49 --> Model Class Initialized
INFO - 2019-07-04 01:01:49 --> Model Class Initialized
INFO - 2019-07-04 01:01:49 --> Model Class Initialized
INFO - 2019-07-04 01:01:49 --> Model Class Initialized
INFO - 2019-07-04 01:01:49 --> Final output sent to browser
DEBUG - 2019-07-04 01:01:49 --> Total execution time: 0.5344
INFO - 2019-07-04 01:01:52 --> Helper loaded: language_helper
INFO - 2019-07-04 01:01:52 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 01:01:52 --> Model Class Initialized
INFO - 2019-07-04 01:01:52 --> Model Class Initialized
INFO - 2019-07-04 01:01:52 --> Model Class Initialized
INFO - 2019-07-04 01:01:52 --> Model Class Initialized
INFO - 2019-07-04 01:01:52 --> Final output sent to browser
DEBUG - 2019-07-04 01:01:53 --> Total execution time: 0.5177
INFO - 2019-07-04 01:01:55 --> Helper loaded: language_helper
INFO - 2019-07-04 01:01:55 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 01:01:55 --> Model Class Initialized
INFO - 2019-07-04 01:01:55 --> Model Class Initialized
INFO - 2019-07-04 01:01:56 --> Model Class Initialized
INFO - 2019-07-04 01:01:56 --> Model Class Initialized
INFO - 2019-07-04 01:01:56 --> Final output sent to browser
DEBUG - 2019-07-04 01:01:56 --> Total execution time: 0.5360
INFO - 2019-07-04 01:01:56 --> Helper loaded: language_helper
INFO - 2019-07-04 01:01:56 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 01:01:56 --> Model Class Initialized
INFO - 2019-07-04 01:01:56 --> Model Class Initialized
INFO - 2019-07-04 01:01:56 --> Model Class Initialized
INFO - 2019-07-04 01:01:56 --> Model Class Initialized
INFO - 2019-07-04 01:01:56 --> Final output sent to browser
DEBUG - 2019-07-04 01:01:56 --> Total execution time: 0.5313
INFO - 2019-07-04 01:01:57 --> Helper loaded: language_helper
INFO - 2019-07-04 01:01:57 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 01:01:57 --> Model Class Initialized
INFO - 2019-07-04 01:01:57 --> Model Class Initialized
INFO - 2019-07-04 01:01:57 --> Model Class Initialized
INFO - 2019-07-04 01:01:57 --> Model Class Initialized
INFO - 2019-07-04 01:01:57 --> Final output sent to browser
DEBUG - 2019-07-04 01:01:57 --> Total execution time: 0.5134
INFO - 2019-07-04 01:02:02 --> Helper loaded: language_helper
INFO - 2019-07-04 01:02:02 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 01:02:02 --> Model Class Initialized
INFO - 2019-07-04 01:02:02 --> Model Class Initialized
INFO - 2019-07-04 01:02:03 --> Model Class Initialized
INFO - 2019-07-04 01:02:03 --> Model Class Initialized
INFO - 2019-07-04 01:02:03 --> Model Class Initialized
INFO - 2019-07-04 01:02:03 --> Final output sent to browser
DEBUG - 2019-07-04 01:02:03 --> Total execution time: 0.7857
INFO - 2019-07-04 01:02:03 --> Helper loaded: language_helper
INFO - 2019-07-04 01:02:03 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 01:02:03 --> Model Class Initialized
INFO - 2019-07-04 01:02:03 --> Model Class Initialized
INFO - 2019-07-04 01:02:03 --> Model Class Initialized
INFO - 2019-07-04 01:02:03 --> Model Class Initialized
INFO - 2019-07-04 01:02:03 --> Final output sent to browser
DEBUG - 2019-07-04 01:02:03 --> Total execution time: 0.9548
INFO - 2019-07-04 01:02:05 --> Helper loaded: language_helper
INFO - 2019-07-04 01:02:05 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 01:02:05 --> Model Class Initialized
INFO - 2019-07-04 01:02:05 --> Model Class Initialized
INFO - 2019-07-04 01:02:05 --> Model Class Initialized
INFO - 2019-07-04 01:02:05 --> Model Class Initialized
INFO - 2019-07-04 01:02:05 --> Model Class Initialized
INFO - 2019-07-04 01:02:05 --> Final output sent to browser
DEBUG - 2019-07-04 01:02:05 --> Total execution time: 0.5413
INFO - 2019-07-04 01:02:05 --> Helper loaded: language_helper
INFO - 2019-07-04 01:02:05 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 01:02:05 --> Model Class Initialized
INFO - 2019-07-04 01:02:05 --> Model Class Initialized
INFO - 2019-07-04 01:02:05 --> Model Class Initialized
INFO - 2019-07-04 01:02:05 --> Model Class Initialized
INFO - 2019-07-04 01:02:05 --> Model Class Initialized
INFO - 2019-07-04 01:02:05 --> Final output sent to browser
DEBUG - 2019-07-04 01:02:05 --> Total execution time: 0.5511
INFO - 2019-07-04 01:02:12 --> Helper loaded: language_helper
INFO - 2019-07-04 01:02:12 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 01:02:12 --> Model Class Initialized
INFO - 2019-07-04 01:02:12 --> Model Class Initialized
INFO - 2019-07-04 01:02:12 --> Model Class Initialized
INFO - 2019-07-04 01:02:12 --> Model Class Initialized
INFO - 2019-07-04 01:02:12 --> Model Class Initialized
INFO - 2019-07-04 01:02:12 --> Final output sent to browser
DEBUG - 2019-07-04 01:02:12 --> Total execution time: 0.5093
INFO - 2019-07-04 01:02:12 --> Helper loaded: language_helper
INFO - 2019-07-04 01:02:12 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 01:02:12 --> Model Class Initialized
INFO - 2019-07-04 01:02:12 --> Model Class Initialized
INFO - 2019-07-04 01:02:12 --> Model Class Initialized
INFO - 2019-07-04 01:02:12 --> Model Class Initialized
INFO - 2019-07-04 01:02:12 --> Helper loaded: form_helper
INFO - 2019-07-04 01:02:12 --> Form Validation Class Initialized
DEBUG - 2019-07-04 01:02:12 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 01:02:12 --> Model Class Initialized
INFO - 2019-07-04 01:02:12 --> Model Class Initialized
INFO - 2019-07-04 01:02:12 --> Final output sent to browser
DEBUG - 2019-07-04 01:02:12 --> Total execution time: 0.5560
INFO - 2019-07-04 01:02:14 --> Helper loaded: language_helper
INFO - 2019-07-04 01:02:14 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 01:02:14 --> Model Class Initialized
INFO - 2019-07-04 01:02:14 --> Model Class Initialized
INFO - 2019-07-04 01:02:14 --> Model Class Initialized
INFO - 2019-07-04 01:02:14 --> Model Class Initialized
INFO - 2019-07-04 01:02:14 --> Helper loaded: form_helper
INFO - 2019-07-04 01:02:14 --> Form Validation Class Initialized
DEBUG - 2019-07-04 01:02:14 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 01:02:14 --> Model Class Initialized
INFO - 2019-07-04 01:02:14 --> Model Class Initialized
INFO - 2019-07-04 01:02:14 --> Final output sent to browser
DEBUG - 2019-07-04 01:02:14 --> Total execution time: 0.5564
INFO - 2019-07-04 01:03:16 --> Helper loaded: language_helper
INFO - 2019-07-04 01:03:16 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 01:03:16 --> Model Class Initialized
INFO - 2019-07-04 01:03:16 --> Model Class Initialized
INFO - 2019-07-04 01:03:16 --> Model Class Initialized
INFO - 2019-07-04 01:03:16 --> Model Class Initialized
INFO - 2019-07-04 01:03:16 --> Helper loaded: form_helper
INFO - 2019-07-04 01:03:16 --> Form Validation Class Initialized
DEBUG - 2019-07-04 01:03:16 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 01:03:16 --> Model Class Initialized
INFO - 2019-07-04 01:03:16 --> Model Class Initialized
INFO - 2019-07-04 01:03:16 --> Final output sent to browser
DEBUG - 2019-07-04 01:03:16 --> Total execution time: 0.5723
INFO - 2019-07-04 01:04:28 --> Helper loaded: language_helper
INFO - 2019-07-04 01:04:28 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 01:04:28 --> Model Class Initialized
INFO - 2019-07-04 01:04:28 --> Model Class Initialized
INFO - 2019-07-04 01:04:28 --> Model Class Initialized
INFO - 2019-07-04 01:04:28 --> Model Class Initialized
INFO - 2019-07-04 01:04:28 --> Model Class Initialized
INFO - 2019-07-04 01:04:28 --> Final output sent to browser
DEBUG - 2019-07-04 01:04:28 --> Total execution time: 0.5093
INFO - 2019-07-04 01:04:29 --> Helper loaded: language_helper
INFO - 2019-07-04 01:04:29 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 01:04:29 --> Model Class Initialized
INFO - 2019-07-04 01:04:29 --> Model Class Initialized
INFO - 2019-07-04 01:04:29 --> Model Class Initialized
INFO - 2019-07-04 01:04:29 --> Model Class Initialized
INFO - 2019-07-04 01:04:29 --> Helper loaded: form_helper
INFO - 2019-07-04 01:04:29 --> Form Validation Class Initialized
DEBUG - 2019-07-04 01:04:29 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 01:04:29 --> Model Class Initialized
INFO - 2019-07-04 01:04:29 --> Model Class Initialized
INFO - 2019-07-04 01:04:29 --> Final output sent to browser
DEBUG - 2019-07-04 01:04:29 --> Total execution time: 0.5625
INFO - 2019-07-04 01:04:59 --> Helper loaded: language_helper
INFO - 2019-07-04 01:04:59 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 01:04:59 --> Model Class Initialized
INFO - 2019-07-04 01:04:59 --> Model Class Initialized
INFO - 2019-07-04 01:04:59 --> Model Class Initialized
INFO - 2019-07-04 01:04:59 --> Model Class Initialized
INFO - 2019-07-04 01:04:59 --> Helper loaded: form_helper
INFO - 2019-07-04 01:04:59 --> Form Validation Class Initialized
DEBUG - 2019-07-04 01:04:59 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 01:04:59 --> Model Class Initialized
INFO - 2019-07-04 01:04:59 --> Model Class Initialized
INFO - 2019-07-04 01:04:59 --> Final output sent to browser
DEBUG - 2019-07-04 01:04:59 --> Total execution time: 0.6008
INFO - 2019-07-04 01:05:00 --> Helper loaded: language_helper
INFO - 2019-07-04 01:05:00 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 01:05:00 --> Model Class Initialized
INFO - 2019-07-04 01:05:00 --> Model Class Initialized
INFO - 2019-07-04 01:05:00 --> Model Class Initialized
INFO - 2019-07-04 01:05:00 --> Model Class Initialized
INFO - 2019-07-04 01:05:00 --> Helper loaded: form_helper
INFO - 2019-07-04 01:05:00 --> Form Validation Class Initialized
DEBUG - 2019-07-04 01:05:00 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 01:05:00 --> Model Class Initialized
INFO - 2019-07-04 01:05:00 --> Model Class Initialized
INFO - 2019-07-04 01:05:00 --> Final output sent to browser
DEBUG - 2019-07-04 01:05:00 --> Total execution time: 0.5870
INFO - 2019-07-04 16:04:28 --> Config Class Initialized
INFO - 2019-07-04 16:04:28 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:04:28 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:04:28 --> Utf8 Class Initialized
INFO - 2019-07-04 16:04:28 --> URI Class Initialized
INFO - 2019-07-04 16:04:28 --> Router Class Initialized
INFO - 2019-07-04 16:04:28 --> Output Class Initialized
INFO - 2019-07-04 16:04:28 --> Security Class Initialized
DEBUG - 2019-07-04 16:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:04:28 --> Input Class Initialized
INFO - 2019-07-04 16:04:28 --> Language Class Initialized
INFO - 2019-07-04 16:04:28 --> Language Class Initialized
INFO - 2019-07-04 16:04:28 --> Config Class Initialized
INFO - 2019-07-04 16:04:28 --> Loader Class Initialized
DEBUG - 2019-07-04 16:04:28 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:04:28 --> Helper loaded: url_helper
INFO - 2019-07-04 16:04:28 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:04:28 --> Helper loaded: string_helper
INFO - 2019-07-04 16:04:28 --> Helper loaded: array_helper
INFO - 2019-07-04 16:04:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:04:28 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:04:28 --> Database Driver Class Initialized
INFO - 2019-07-04 16:04:28 --> Controller Class Initialized
INFO - 2019-07-04 22:04:29 --> Helper loaded: language_helper
INFO - 2019-07-04 22:04:29 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:04:29 --> Model Class Initialized
INFO - 2019-07-04 22:04:29 --> Model Class Initialized
INFO - 2019-07-04 22:04:29 --> Model Class Initialized
INFO - 2019-07-04 22:04:29 --> Model Class Initialized
INFO - 2019-07-04 22:04:29 --> Final output sent to browser
DEBUG - 2019-07-04 22:04:29 --> Total execution time: 1.0890
INFO - 2019-07-04 16:04:29 --> Config Class Initialized
INFO - 2019-07-04 16:04:29 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:04:29 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:04:29 --> Utf8 Class Initialized
INFO - 2019-07-04 16:04:29 --> URI Class Initialized
INFO - 2019-07-04 16:04:29 --> Router Class Initialized
INFO - 2019-07-04 16:04:29 --> Output Class Initialized
INFO - 2019-07-04 16:04:29 --> Security Class Initialized
DEBUG - 2019-07-04 16:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:04:29 --> Input Class Initialized
INFO - 2019-07-04 16:04:29 --> Language Class Initialized
INFO - 2019-07-04 16:04:29 --> Language Class Initialized
INFO - 2019-07-04 16:04:29 --> Config Class Initialized
INFO - 2019-07-04 16:04:29 --> Loader Class Initialized
DEBUG - 2019-07-04 16:04:29 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:04:29 --> Helper loaded: url_helper
INFO - 2019-07-04 16:04:29 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:04:29 --> Helper loaded: string_helper
INFO - 2019-07-04 16:04:29 --> Helper loaded: array_helper
INFO - 2019-07-04 16:04:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:04:29 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:04:29 --> Database Driver Class Initialized
INFO - 2019-07-04 16:04:29 --> Controller Class Initialized
INFO - 2019-07-04 22:04:29 --> Helper loaded: language_helper
INFO - 2019-07-04 22:04:29 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:04:29 --> Model Class Initialized
INFO - 2019-07-04 22:04:29 --> Model Class Initialized
INFO - 2019-07-04 22:04:29 --> Model Class Initialized
INFO - 2019-07-04 22:04:29 --> Model Class Initialized
INFO - 2019-07-04 22:04:29 --> Final output sent to browser
DEBUG - 2019-07-04 22:04:29 --> Total execution time: 0.3634
INFO - 2019-07-04 16:04:34 --> Config Class Initialized
INFO - 2019-07-04 16:04:34 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:04:34 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:04:34 --> Utf8 Class Initialized
INFO - 2019-07-04 16:04:34 --> URI Class Initialized
INFO - 2019-07-04 16:04:34 --> Router Class Initialized
INFO - 2019-07-04 16:04:34 --> Output Class Initialized
INFO - 2019-07-04 16:04:34 --> Security Class Initialized
DEBUG - 2019-07-04 16:04:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:04:34 --> Input Class Initialized
INFO - 2019-07-04 16:04:34 --> Language Class Initialized
INFO - 2019-07-04 16:04:34 --> Language Class Initialized
INFO - 2019-07-04 16:04:34 --> Config Class Initialized
INFO - 2019-07-04 16:04:34 --> Loader Class Initialized
DEBUG - 2019-07-04 16:04:34 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:04:34 --> Helper loaded: url_helper
INFO - 2019-07-04 16:04:34 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:04:34 --> Helper loaded: string_helper
INFO - 2019-07-04 16:04:34 --> Helper loaded: array_helper
INFO - 2019-07-04 16:04:34 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:04:34 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:04:34 --> Database Driver Class Initialized
INFO - 2019-07-04 16:04:34 --> Controller Class Initialized
INFO - 2019-07-04 22:04:34 --> Helper loaded: language_helper
INFO - 2019-07-04 22:04:34 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:04:34 --> Model Class Initialized
INFO - 2019-07-04 22:04:34 --> Model Class Initialized
INFO - 2019-07-04 22:04:34 --> Model Class Initialized
INFO - 2019-07-04 22:04:34 --> Model Class Initialized
INFO - 2019-07-04 22:04:35 --> Final output sent to browser
DEBUG - 2019-07-04 22:04:35 --> Total execution time: 0.3581
INFO - 2019-07-04 16:04:35 --> Config Class Initialized
INFO - 2019-07-04 16:04:35 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:04:35 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:04:35 --> Utf8 Class Initialized
INFO - 2019-07-04 16:04:35 --> URI Class Initialized
INFO - 2019-07-04 16:04:35 --> Router Class Initialized
INFO - 2019-07-04 16:04:35 --> Output Class Initialized
INFO - 2019-07-04 16:04:35 --> Security Class Initialized
DEBUG - 2019-07-04 16:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:04:35 --> Input Class Initialized
INFO - 2019-07-04 16:04:35 --> Language Class Initialized
INFO - 2019-07-04 16:04:35 --> Language Class Initialized
INFO - 2019-07-04 16:04:35 --> Config Class Initialized
INFO - 2019-07-04 16:04:35 --> Loader Class Initialized
DEBUG - 2019-07-04 16:04:35 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:04:35 --> Helper loaded: url_helper
INFO - 2019-07-04 16:04:35 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:04:35 --> Helper loaded: string_helper
INFO - 2019-07-04 16:04:35 --> Helper loaded: array_helper
INFO - 2019-07-04 16:04:35 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:04:35 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:04:35 --> Database Driver Class Initialized
INFO - 2019-07-04 16:04:35 --> Controller Class Initialized
INFO - 2019-07-04 22:04:35 --> Helper loaded: language_helper
INFO - 2019-07-04 22:04:35 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:04:35 --> Model Class Initialized
INFO - 2019-07-04 22:04:35 --> Model Class Initialized
INFO - 2019-07-04 22:04:35 --> Model Class Initialized
INFO - 2019-07-04 22:04:35 --> Model Class Initialized
INFO - 2019-07-04 22:04:35 --> Model Class Initialized
INFO - 2019-07-04 22:04:35 --> Final output sent to browser
DEBUG - 2019-07-04 22:04:35 --> Total execution time: 0.3760
INFO - 2019-07-04 16:04:37 --> Config Class Initialized
INFO - 2019-07-04 16:04:37 --> Hooks Class Initialized
INFO - 2019-07-04 16:04:37 --> Config Class Initialized
DEBUG - 2019-07-04 16:04:37 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:04:37 --> Hooks Class Initialized
INFO - 2019-07-04 16:04:37 --> Utf8 Class Initialized
DEBUG - 2019-07-04 16:04:37 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:04:37 --> URI Class Initialized
INFO - 2019-07-04 16:04:37 --> Utf8 Class Initialized
INFO - 2019-07-04 16:04:37 --> URI Class Initialized
INFO - 2019-07-04 16:04:37 --> Router Class Initialized
INFO - 2019-07-04 16:04:37 --> Router Class Initialized
INFO - 2019-07-04 16:04:37 --> Output Class Initialized
INFO - 2019-07-04 16:04:37 --> Output Class Initialized
INFO - 2019-07-04 16:04:37 --> Security Class Initialized
INFO - 2019-07-04 16:04:37 --> Security Class Initialized
DEBUG - 2019-07-04 16:04:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-04 16:04:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:04:37 --> Input Class Initialized
INFO - 2019-07-04 16:04:37 --> Input Class Initialized
INFO - 2019-07-04 16:04:37 --> Language Class Initialized
INFO - 2019-07-04 16:04:37 --> Language Class Initialized
INFO - 2019-07-04 16:04:37 --> Language Class Initialized
INFO - 2019-07-04 16:04:37 --> Language Class Initialized
INFO - 2019-07-04 16:04:37 --> Config Class Initialized
INFO - 2019-07-04 16:04:37 --> Config Class Initialized
INFO - 2019-07-04 16:04:37 --> Loader Class Initialized
INFO - 2019-07-04 16:04:37 --> Loader Class Initialized
DEBUG - 2019-07-04 16:04:37 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-04 16:04:37 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:04:37 --> Helper loaded: url_helper
INFO - 2019-07-04 16:04:37 --> Helper loaded: url_helper
INFO - 2019-07-04 16:04:37 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:04:37 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:04:37 --> Helper loaded: string_helper
INFO - 2019-07-04 16:04:37 --> Helper loaded: string_helper
INFO - 2019-07-04 16:04:37 --> Helper loaded: array_helper
INFO - 2019-07-04 16:04:37 --> Helper loaded: array_helper
INFO - 2019-07-04 16:04:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:04:37 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:04:37 --> Database Driver Class Initialized
INFO - 2019-07-04 16:04:37 --> Controller Class Initialized
INFO - 2019-07-04 22:04:37 --> Helper loaded: language_helper
INFO - 2019-07-04 22:04:37 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:04:37 --> Model Class Initialized
INFO - 2019-07-04 22:04:37 --> Model Class Initialized
INFO - 2019-07-04 22:04:37 --> Model Class Initialized
INFO - 2019-07-04 22:04:37 --> Model Class Initialized
INFO - 2019-07-04 22:04:37 --> Model Class Initialized
INFO - 2019-07-04 22:04:37 --> Final output sent to browser
DEBUG - 2019-07-04 22:04:37 --> Total execution time: 0.5048
INFO - 2019-07-04 16:04:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:04:37 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:04:37 --> Database Driver Class Initialized
INFO - 2019-07-04 16:04:37 --> Controller Class Initialized
INFO - 2019-07-04 22:04:37 --> Helper loaded: language_helper
INFO - 2019-07-04 22:04:37 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:04:37 --> Model Class Initialized
INFO - 2019-07-04 22:04:37 --> Model Class Initialized
INFO - 2019-07-04 22:04:37 --> Model Class Initialized
INFO - 2019-07-04 22:04:37 --> Model Class Initialized
INFO - 2019-07-04 22:04:37 --> Helper loaded: form_helper
INFO - 2019-07-04 22:04:37 --> Form Validation Class Initialized
DEBUG - 2019-07-04 22:04:37 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 22:04:37 --> Model Class Initialized
INFO - 2019-07-04 22:04:37 --> Model Class Initialized
INFO - 2019-07-04 22:04:37 --> Final output sent to browser
DEBUG - 2019-07-04 22:04:37 --> Total execution time: 0.7933
INFO - 2019-07-04 16:04:41 --> Config Class Initialized
INFO - 2019-07-04 16:04:41 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:04:41 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:04:41 --> Utf8 Class Initialized
INFO - 2019-07-04 16:04:41 --> URI Class Initialized
INFO - 2019-07-04 16:04:41 --> Router Class Initialized
INFO - 2019-07-04 16:04:41 --> Output Class Initialized
INFO - 2019-07-04 16:04:41 --> Security Class Initialized
DEBUG - 2019-07-04 16:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:04:41 --> Input Class Initialized
INFO - 2019-07-04 16:04:41 --> Language Class Initialized
INFO - 2019-07-04 16:04:41 --> Language Class Initialized
INFO - 2019-07-04 16:04:41 --> Config Class Initialized
INFO - 2019-07-04 16:04:41 --> Loader Class Initialized
DEBUG - 2019-07-04 16:04:42 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:04:42 --> Helper loaded: url_helper
INFO - 2019-07-04 16:04:42 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:04:42 --> Helper loaded: string_helper
INFO - 2019-07-04 16:04:42 --> Helper loaded: array_helper
INFO - 2019-07-04 16:04:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:04:42 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:04:42 --> Database Driver Class Initialized
INFO - 2019-07-04 16:04:42 --> Controller Class Initialized
INFO - 2019-07-04 22:04:42 --> Helper loaded: language_helper
INFO - 2019-07-04 22:04:42 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:04:42 --> Model Class Initialized
INFO - 2019-07-04 22:04:42 --> Model Class Initialized
INFO - 2019-07-04 22:04:42 --> Model Class Initialized
INFO - 2019-07-04 22:04:42 --> Model Class Initialized
INFO - 2019-07-04 22:04:42 --> Model Class Initialized
INFO - 2019-07-04 22:04:42 --> Final output sent to browser
DEBUG - 2019-07-04 22:04:42 --> Total execution time: 0.3431
INFO - 2019-07-04 16:04:43 --> Config Class Initialized
INFO - 2019-07-04 16:04:43 --> Hooks Class Initialized
INFO - 2019-07-04 16:04:43 --> Config Class Initialized
INFO - 2019-07-04 16:04:43 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:04:43 --> UTF-8 Support Enabled
DEBUG - 2019-07-04 16:04:43 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:04:43 --> Utf8 Class Initialized
INFO - 2019-07-04 16:04:43 --> Utf8 Class Initialized
INFO - 2019-07-04 16:04:43 --> URI Class Initialized
INFO - 2019-07-04 16:04:43 --> URI Class Initialized
INFO - 2019-07-04 16:04:43 --> Router Class Initialized
INFO - 2019-07-04 16:04:43 --> Router Class Initialized
INFO - 2019-07-04 16:04:43 --> Output Class Initialized
INFO - 2019-07-04 16:04:44 --> Output Class Initialized
INFO - 2019-07-04 16:04:44 --> Security Class Initialized
INFO - 2019-07-04 16:04:44 --> Security Class Initialized
DEBUG - 2019-07-04 16:04:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-04 16:04:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:04:44 --> Input Class Initialized
INFO - 2019-07-04 16:04:44 --> Input Class Initialized
INFO - 2019-07-04 16:04:44 --> Language Class Initialized
INFO - 2019-07-04 16:04:44 --> Language Class Initialized
INFO - 2019-07-04 16:04:44 --> Language Class Initialized
INFO - 2019-07-04 16:04:44 --> Language Class Initialized
INFO - 2019-07-04 16:04:44 --> Config Class Initialized
INFO - 2019-07-04 16:04:44 --> Config Class Initialized
INFO - 2019-07-04 16:04:44 --> Loader Class Initialized
INFO - 2019-07-04 16:04:44 --> Loader Class Initialized
DEBUG - 2019-07-04 16:04:44 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-04 16:04:44 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:04:44 --> Helper loaded: url_helper
INFO - 2019-07-04 16:04:44 --> Helper loaded: url_helper
INFO - 2019-07-04 16:04:44 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:04:44 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:04:44 --> Helper loaded: string_helper
INFO - 2019-07-04 16:04:44 --> Helper loaded: string_helper
INFO - 2019-07-04 16:04:44 --> Helper loaded: array_helper
INFO - 2019-07-04 16:04:44 --> Helper loaded: array_helper
INFO - 2019-07-04 16:04:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:04:44 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:04:44 --> Database Driver Class Initialized
INFO - 2019-07-04 16:04:44 --> Controller Class Initialized
INFO - 2019-07-04 22:04:44 --> Helper loaded: language_helper
INFO - 2019-07-04 22:04:44 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:04:44 --> Model Class Initialized
INFO - 2019-07-04 22:04:44 --> Model Class Initialized
INFO - 2019-07-04 22:04:44 --> Model Class Initialized
INFO - 2019-07-04 22:04:44 --> Model Class Initialized
INFO - 2019-07-04 22:04:44 --> Model Class Initialized
INFO - 2019-07-04 22:04:44 --> Final output sent to browser
DEBUG - 2019-07-04 22:04:44 --> Total execution time: 0.4483
INFO - 2019-07-04 16:04:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:04:44 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:04:44 --> Database Driver Class Initialized
INFO - 2019-07-04 16:04:44 --> Controller Class Initialized
INFO - 2019-07-04 22:04:44 --> Helper loaded: language_helper
INFO - 2019-07-04 22:04:44 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:04:44 --> Model Class Initialized
INFO - 2019-07-04 22:04:44 --> Model Class Initialized
INFO - 2019-07-04 22:04:44 --> Model Class Initialized
INFO - 2019-07-04 22:04:44 --> Model Class Initialized
INFO - 2019-07-04 22:04:44 --> Helper loaded: form_helper
INFO - 2019-07-04 22:04:44 --> Form Validation Class Initialized
DEBUG - 2019-07-04 22:04:44 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 22:04:44 --> Model Class Initialized
INFO - 2019-07-04 22:04:44 --> Model Class Initialized
INFO - 2019-07-04 22:04:44 --> Final output sent to browser
DEBUG - 2019-07-04 22:04:44 --> Total execution time: 0.6343
INFO - 2019-07-04 16:04:45 --> Config Class Initialized
INFO - 2019-07-04 16:04:45 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:04:45 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:04:45 --> Utf8 Class Initialized
INFO - 2019-07-04 16:04:45 --> URI Class Initialized
INFO - 2019-07-04 16:04:45 --> Router Class Initialized
INFO - 2019-07-04 16:04:45 --> Output Class Initialized
INFO - 2019-07-04 16:04:45 --> Security Class Initialized
DEBUG - 2019-07-04 16:04:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:04:45 --> Input Class Initialized
INFO - 2019-07-04 16:04:45 --> Language Class Initialized
INFO - 2019-07-04 16:04:45 --> Language Class Initialized
INFO - 2019-07-04 16:04:45 --> Config Class Initialized
INFO - 2019-07-04 16:04:45 --> Loader Class Initialized
DEBUG - 2019-07-04 16:04:45 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:04:45 --> Helper loaded: url_helper
INFO - 2019-07-04 16:04:45 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:04:45 --> Helper loaded: string_helper
INFO - 2019-07-04 16:04:45 --> Helper loaded: array_helper
INFO - 2019-07-04 16:04:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:04:45 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:04:45 --> Database Driver Class Initialized
INFO - 2019-07-04 16:04:45 --> Controller Class Initialized
INFO - 2019-07-04 22:04:45 --> Helper loaded: language_helper
INFO - 2019-07-04 22:04:45 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:04:45 --> Model Class Initialized
INFO - 2019-07-04 22:04:45 --> Model Class Initialized
INFO - 2019-07-04 22:04:45 --> Model Class Initialized
INFO - 2019-07-04 22:04:45 --> Model Class Initialized
INFO - 2019-07-04 22:04:45 --> Model Class Initialized
INFO - 2019-07-04 22:04:45 --> Final output sent to browser
DEBUG - 2019-07-04 22:04:45 --> Total execution time: 0.3433
INFO - 2019-07-04 16:04:49 --> Config Class Initialized
INFO - 2019-07-04 16:04:49 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:04:49 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:04:49 --> Utf8 Class Initialized
INFO - 2019-07-04 16:04:49 --> URI Class Initialized
INFO - 2019-07-04 16:04:49 --> Router Class Initialized
INFO - 2019-07-04 16:04:49 --> Output Class Initialized
INFO - 2019-07-04 16:04:49 --> Security Class Initialized
DEBUG - 2019-07-04 16:04:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:04:49 --> Input Class Initialized
INFO - 2019-07-04 16:04:49 --> Language Class Initialized
INFO - 2019-07-04 16:04:49 --> Language Class Initialized
INFO - 2019-07-04 16:04:49 --> Config Class Initialized
INFO - 2019-07-04 16:04:49 --> Loader Class Initialized
DEBUG - 2019-07-04 16:04:49 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:04:49 --> Helper loaded: url_helper
INFO - 2019-07-04 16:04:49 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:04:49 --> Helper loaded: string_helper
INFO - 2019-07-04 16:04:49 --> Helper loaded: array_helper
INFO - 2019-07-04 16:04:49 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:04:49 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:04:49 --> Database Driver Class Initialized
INFO - 2019-07-04 16:04:49 --> Controller Class Initialized
INFO - 2019-07-04 22:04:49 --> Helper loaded: language_helper
INFO - 2019-07-04 22:04:49 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:04:49 --> Model Class Initialized
INFO - 2019-07-04 22:04:49 --> Model Class Initialized
INFO - 2019-07-04 22:04:49 --> Model Class Initialized
INFO - 2019-07-04 22:04:49 --> Model Class Initialized
INFO - 2019-07-04 22:04:49 --> Helper loaded: form_helper
INFO - 2019-07-04 22:04:49 --> Form Validation Class Initialized
DEBUG - 2019-07-04 22:04:49 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 22:04:49 --> Model Class Initialized
INFO - 2019-07-04 22:04:49 --> Model Class Initialized
INFO - 2019-07-04 22:04:49 --> Final output sent to browser
DEBUG - 2019-07-04 22:04:49 --> Total execution time: 0.3686
INFO - 2019-07-04 16:04:49 --> Config Class Initialized
INFO - 2019-07-04 16:04:49 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:04:49 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:04:49 --> Utf8 Class Initialized
INFO - 2019-07-04 16:04:49 --> URI Class Initialized
INFO - 2019-07-04 16:04:49 --> Router Class Initialized
INFO - 2019-07-04 16:04:49 --> Output Class Initialized
INFO - 2019-07-04 16:04:49 --> Security Class Initialized
DEBUG - 2019-07-04 16:04:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:04:49 --> Input Class Initialized
INFO - 2019-07-04 16:04:49 --> Language Class Initialized
INFO - 2019-07-04 16:04:49 --> Language Class Initialized
INFO - 2019-07-04 16:04:49 --> Config Class Initialized
INFO - 2019-07-04 16:04:49 --> Loader Class Initialized
DEBUG - 2019-07-04 16:04:49 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:04:49 --> Helper loaded: url_helper
INFO - 2019-07-04 16:04:49 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:04:49 --> Helper loaded: string_helper
INFO - 2019-07-04 16:04:49 --> Helper loaded: array_helper
INFO - 2019-07-04 16:04:49 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:04:49 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:04:49 --> Database Driver Class Initialized
INFO - 2019-07-04 16:04:49 --> Controller Class Initialized
INFO - 2019-07-04 22:04:49 --> Helper loaded: language_helper
INFO - 2019-07-04 22:04:49 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:04:49 --> Model Class Initialized
INFO - 2019-07-04 22:04:49 --> Model Class Initialized
INFO - 2019-07-04 22:04:49 --> Model Class Initialized
INFO - 2019-07-04 22:04:49 --> Model Class Initialized
INFO - 2019-07-04 22:04:49 --> Helper loaded: form_helper
INFO - 2019-07-04 22:04:49 --> Form Validation Class Initialized
DEBUG - 2019-07-04 22:04:49 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 22:04:49 --> Model Class Initialized
INFO - 2019-07-04 22:04:49 --> Model Class Initialized
INFO - 2019-07-04 22:04:49 --> Final output sent to browser
DEBUG - 2019-07-04 22:04:49 --> Total execution time: 0.3702
INFO - 2019-07-04 16:05:51 --> Config Class Initialized
INFO - 2019-07-04 16:05:51 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:05:51 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:05:51 --> Utf8 Class Initialized
INFO - 2019-07-04 16:05:51 --> URI Class Initialized
INFO - 2019-07-04 16:05:51 --> Router Class Initialized
INFO - 2019-07-04 16:05:51 --> Output Class Initialized
INFO - 2019-07-04 16:05:51 --> Security Class Initialized
DEBUG - 2019-07-04 16:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:05:51 --> Input Class Initialized
INFO - 2019-07-04 16:05:51 --> Language Class Initialized
INFO - 2019-07-04 16:05:51 --> Language Class Initialized
INFO - 2019-07-04 16:05:51 --> Config Class Initialized
INFO - 2019-07-04 16:05:51 --> Loader Class Initialized
DEBUG - 2019-07-04 16:05:51 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:05:51 --> Helper loaded: url_helper
INFO - 2019-07-04 16:05:51 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:05:51 --> Helper loaded: string_helper
INFO - 2019-07-04 16:05:51 --> Helper loaded: array_helper
INFO - 2019-07-04 16:05:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:05:51 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:05:51 --> Database Driver Class Initialized
INFO - 2019-07-04 16:05:51 --> Controller Class Initialized
INFO - 2019-07-04 22:05:51 --> Helper loaded: language_helper
INFO - 2019-07-04 22:05:51 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:05:51 --> Model Class Initialized
INFO - 2019-07-04 22:05:51 --> Model Class Initialized
INFO - 2019-07-04 22:05:51 --> Model Class Initialized
INFO - 2019-07-04 22:05:51 --> Model Class Initialized
INFO - 2019-07-04 22:05:51 --> Final output sent to browser
DEBUG - 2019-07-04 22:05:51 --> Total execution time: 0.3707
INFO - 2019-07-04 16:05:52 --> Config Class Initialized
INFO - 2019-07-04 16:05:52 --> Config Class Initialized
INFO - 2019-07-04 16:05:52 --> Hooks Class Initialized
INFO - 2019-07-04 16:05:52 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:05:52 --> UTF-8 Support Enabled
DEBUG - 2019-07-04 16:05:52 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:05:52 --> Utf8 Class Initialized
INFO - 2019-07-04 16:05:52 --> Utf8 Class Initialized
INFO - 2019-07-04 16:05:52 --> URI Class Initialized
INFO - 2019-07-04 16:05:52 --> URI Class Initialized
INFO - 2019-07-04 16:05:52 --> Router Class Initialized
INFO - 2019-07-04 16:05:52 --> Router Class Initialized
INFO - 2019-07-04 16:05:52 --> Output Class Initialized
INFO - 2019-07-04 16:05:52 --> Output Class Initialized
INFO - 2019-07-04 16:05:52 --> Security Class Initialized
INFO - 2019-07-04 16:05:52 --> Security Class Initialized
DEBUG - 2019-07-04 16:05:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-04 16:05:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:05:52 --> Input Class Initialized
INFO - 2019-07-04 16:05:52 --> Input Class Initialized
INFO - 2019-07-04 16:05:52 --> Language Class Initialized
INFO - 2019-07-04 16:05:52 --> Language Class Initialized
INFO - 2019-07-04 16:05:52 --> Language Class Initialized
INFO - 2019-07-04 16:05:52 --> Language Class Initialized
INFO - 2019-07-04 16:05:52 --> Config Class Initialized
INFO - 2019-07-04 16:05:52 --> Config Class Initialized
INFO - 2019-07-04 16:05:52 --> Loader Class Initialized
INFO - 2019-07-04 16:05:52 --> Loader Class Initialized
DEBUG - 2019-07-04 16:05:52 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-04 16:05:52 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:05:52 --> Helper loaded: url_helper
INFO - 2019-07-04 16:05:52 --> Helper loaded: url_helper
INFO - 2019-07-04 16:05:52 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:05:52 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:05:52 --> Helper loaded: string_helper
INFO - 2019-07-04 16:05:52 --> Helper loaded: string_helper
INFO - 2019-07-04 16:05:52 --> Helper loaded: array_helper
INFO - 2019-07-04 16:05:52 --> Helper loaded: array_helper
INFO - 2019-07-04 16:05:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:05:52 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:05:52 --> Database Driver Class Initialized
INFO - 2019-07-04 16:05:52 --> Controller Class Initialized
INFO - 2019-07-04 22:05:52 --> Helper loaded: language_helper
INFO - 2019-07-04 22:05:52 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:05:52 --> Model Class Initialized
INFO - 2019-07-04 22:05:52 --> Model Class Initialized
INFO - 2019-07-04 22:05:52 --> Model Class Initialized
INFO - 2019-07-04 22:05:52 --> Model Class Initialized
INFO - 2019-07-04 22:05:52 --> Model Class Initialized
INFO - 2019-07-04 22:05:52 --> Final output sent to browser
DEBUG - 2019-07-04 22:05:52 --> Total execution time: 0.4513
INFO - 2019-07-04 16:05:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:05:52 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:05:52 --> Database Driver Class Initialized
INFO - 2019-07-04 16:05:52 --> Controller Class Initialized
INFO - 2019-07-04 22:05:52 --> Helper loaded: language_helper
INFO - 2019-07-04 22:05:52 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:05:52 --> Model Class Initialized
INFO - 2019-07-04 22:05:52 --> Model Class Initialized
INFO - 2019-07-04 22:05:52 --> Model Class Initialized
INFO - 2019-07-04 22:05:52 --> Model Class Initialized
INFO - 2019-07-04 22:05:52 --> Final output sent to browser
DEBUG - 2019-07-04 22:05:52 --> Total execution time: 0.5833
INFO - 2019-07-04 16:05:57 --> Config Class Initialized
INFO - 2019-07-04 16:05:57 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:05:57 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:05:57 --> Utf8 Class Initialized
INFO - 2019-07-04 16:05:57 --> URI Class Initialized
INFO - 2019-07-04 16:05:57 --> Router Class Initialized
INFO - 2019-07-04 16:05:57 --> Output Class Initialized
INFO - 2019-07-04 16:05:57 --> Security Class Initialized
DEBUG - 2019-07-04 16:05:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:05:57 --> Input Class Initialized
INFO - 2019-07-04 16:05:57 --> Language Class Initialized
INFO - 2019-07-04 16:05:57 --> Language Class Initialized
INFO - 2019-07-04 16:05:57 --> Config Class Initialized
INFO - 2019-07-04 16:05:57 --> Loader Class Initialized
DEBUG - 2019-07-04 16:05:57 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:05:57 --> Helper loaded: url_helper
INFO - 2019-07-04 16:05:57 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:05:57 --> Helper loaded: string_helper
INFO - 2019-07-04 16:05:57 --> Helper loaded: array_helper
INFO - 2019-07-04 16:05:57 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:05:57 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:05:57 --> Database Driver Class Initialized
INFO - 2019-07-04 16:05:57 --> Controller Class Initialized
INFO - 2019-07-04 22:05:57 --> Helper loaded: language_helper
INFO - 2019-07-04 22:05:57 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:05:57 --> Model Class Initialized
INFO - 2019-07-04 22:05:57 --> Model Class Initialized
INFO - 2019-07-04 22:05:57 --> Model Class Initialized
INFO - 2019-07-04 22:05:57 --> Model Class Initialized
INFO - 2019-07-04 22:05:57 --> Final output sent to browser
DEBUG - 2019-07-04 22:05:57 --> Total execution time: 0.3189
INFO - 2019-07-04 16:08:00 --> Config Class Initialized
INFO - 2019-07-04 16:08:00 --> Config Class Initialized
INFO - 2019-07-04 16:08:00 --> Hooks Class Initialized
INFO - 2019-07-04 16:08:00 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:08:00 --> UTF-8 Support Enabled
DEBUG - 2019-07-04 16:08:00 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:08:00 --> Utf8 Class Initialized
INFO - 2019-07-04 16:08:01 --> Utf8 Class Initialized
INFO - 2019-07-04 16:08:01 --> URI Class Initialized
INFO - 2019-07-04 16:08:01 --> URI Class Initialized
INFO - 2019-07-04 16:08:01 --> Router Class Initialized
INFO - 2019-07-04 16:08:01 --> Router Class Initialized
INFO - 2019-07-04 16:08:01 --> Output Class Initialized
INFO - 2019-07-04 16:08:01 --> Output Class Initialized
INFO - 2019-07-04 16:08:01 --> Security Class Initialized
INFO - 2019-07-04 16:08:01 --> Security Class Initialized
DEBUG - 2019-07-04 16:08:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-04 16:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:08:01 --> Input Class Initialized
INFO - 2019-07-04 16:08:01 --> Input Class Initialized
INFO - 2019-07-04 16:08:01 --> Language Class Initialized
INFO - 2019-07-04 16:08:01 --> Language Class Initialized
INFO - 2019-07-04 16:08:01 --> Language Class Initialized
INFO - 2019-07-04 16:08:01 --> Language Class Initialized
INFO - 2019-07-04 16:08:01 --> Config Class Initialized
INFO - 2019-07-04 16:08:01 --> Config Class Initialized
INFO - 2019-07-04 16:08:01 --> Loader Class Initialized
INFO - 2019-07-04 16:08:01 --> Loader Class Initialized
DEBUG - 2019-07-04 16:08:01 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-04 16:08:01 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:08:01 --> Helper loaded: url_helper
INFO - 2019-07-04 16:08:01 --> Helper loaded: url_helper
INFO - 2019-07-04 16:08:01 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:08:01 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:08:01 --> Helper loaded: string_helper
INFO - 2019-07-04 16:08:01 --> Helper loaded: string_helper
INFO - 2019-07-04 16:08:01 --> Helper loaded: array_helper
INFO - 2019-07-04 16:08:01 --> Helper loaded: array_helper
INFO - 2019-07-04 16:08:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:08:01 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:08:01 --> Database Driver Class Initialized
INFO - 2019-07-04 16:08:01 --> Controller Class Initialized
INFO - 2019-07-04 22:08:01 --> Helper loaded: language_helper
INFO - 2019-07-04 22:08:01 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:08:01 --> Model Class Initialized
INFO - 2019-07-04 22:08:01 --> Model Class Initialized
INFO - 2019-07-04 22:08:01 --> Model Class Initialized
INFO - 2019-07-04 22:08:01 --> Model Class Initialized
INFO - 2019-07-04 22:08:01 --> Final output sent to browser
DEBUG - 2019-07-04 22:08:01 --> Total execution time: 0.4471
INFO - 2019-07-04 16:08:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:08:01 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:08:01 --> Database Driver Class Initialized
INFO - 2019-07-04 16:08:01 --> Controller Class Initialized
INFO - 2019-07-04 22:08:01 --> Helper loaded: language_helper
INFO - 2019-07-04 22:08:01 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:08:01 --> Model Class Initialized
INFO - 2019-07-04 22:08:01 --> Model Class Initialized
INFO - 2019-07-04 22:08:01 --> Model Class Initialized
INFO - 2019-07-04 22:08:01 --> Model Class Initialized
INFO - 2019-07-04 22:08:01 --> Model Class Initialized
INFO - 2019-07-04 22:08:01 --> Final output sent to browser
DEBUG - 2019-07-04 22:08:01 --> Total execution time: 0.6360
INFO - 2019-07-04 16:08:10 --> Config Class Initialized
INFO - 2019-07-04 16:08:10 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:08:10 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:08:10 --> Utf8 Class Initialized
INFO - 2019-07-04 16:08:10 --> URI Class Initialized
INFO - 2019-07-04 16:08:10 --> Router Class Initialized
INFO - 2019-07-04 16:08:10 --> Output Class Initialized
INFO - 2019-07-04 16:08:10 --> Security Class Initialized
DEBUG - 2019-07-04 16:08:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:08:10 --> Input Class Initialized
INFO - 2019-07-04 16:08:10 --> Language Class Initialized
INFO - 2019-07-04 16:08:10 --> Language Class Initialized
INFO - 2019-07-04 16:08:10 --> Config Class Initialized
INFO - 2019-07-04 16:08:10 --> Loader Class Initialized
DEBUG - 2019-07-04 16:08:11 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:08:11 --> Helper loaded: url_helper
INFO - 2019-07-04 16:08:11 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:08:11 --> Helper loaded: string_helper
INFO - 2019-07-04 16:08:11 --> Helper loaded: array_helper
INFO - 2019-07-04 16:08:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:08:11 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:08:11 --> Database Driver Class Initialized
INFO - 2019-07-04 16:08:11 --> Controller Class Initialized
INFO - 2019-07-04 22:08:11 --> Helper loaded: language_helper
INFO - 2019-07-04 22:08:11 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:08:11 --> Model Class Initialized
INFO - 2019-07-04 22:08:11 --> Model Class Initialized
INFO - 2019-07-04 22:08:11 --> Model Class Initialized
INFO - 2019-07-04 22:08:11 --> Model Class Initialized
INFO - 2019-07-04 22:08:11 --> Model Class Initialized
INFO - 2019-07-04 22:08:11 --> Final output sent to browser
DEBUG - 2019-07-04 22:08:11 --> Total execution time: 0.3113
INFO - 2019-07-04 16:08:11 --> Config Class Initialized
INFO - 2019-07-04 16:08:11 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:08:11 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:08:11 --> Utf8 Class Initialized
INFO - 2019-07-04 16:08:11 --> URI Class Initialized
INFO - 2019-07-04 16:08:11 --> Router Class Initialized
INFO - 2019-07-04 16:08:11 --> Output Class Initialized
INFO - 2019-07-04 16:08:11 --> Security Class Initialized
DEBUG - 2019-07-04 16:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:08:11 --> Input Class Initialized
INFO - 2019-07-04 16:08:11 --> Language Class Initialized
INFO - 2019-07-04 16:08:11 --> Language Class Initialized
INFO - 2019-07-04 16:08:11 --> Config Class Initialized
INFO - 2019-07-04 16:08:11 --> Loader Class Initialized
DEBUG - 2019-07-04 16:08:11 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:08:11 --> Helper loaded: url_helper
INFO - 2019-07-04 16:08:11 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:08:11 --> Helper loaded: string_helper
INFO - 2019-07-04 16:08:11 --> Helper loaded: array_helper
INFO - 2019-07-04 16:08:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:08:11 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:08:11 --> Database Driver Class Initialized
INFO - 2019-07-04 16:08:11 --> Controller Class Initialized
INFO - 2019-07-04 22:08:11 --> Helper loaded: language_helper
INFO - 2019-07-04 22:08:11 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:08:11 --> Model Class Initialized
INFO - 2019-07-04 22:08:11 --> Model Class Initialized
INFO - 2019-07-04 22:08:11 --> Model Class Initialized
INFO - 2019-07-04 22:08:11 --> Model Class Initialized
INFO - 2019-07-04 22:08:11 --> Helper loaded: form_helper
INFO - 2019-07-04 22:08:11 --> Form Validation Class Initialized
DEBUG - 2019-07-04 22:08:11 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 22:08:11 --> Model Class Initialized
INFO - 2019-07-04 22:08:11 --> Model Class Initialized
INFO - 2019-07-04 22:08:11 --> Final output sent to browser
DEBUG - 2019-07-04 22:08:11 --> Total execution time: 0.3972
INFO - 2019-07-04 16:08:14 --> Config Class Initialized
INFO - 2019-07-04 16:08:14 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:08:14 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:08:14 --> Utf8 Class Initialized
INFO - 2019-07-04 16:08:14 --> URI Class Initialized
INFO - 2019-07-04 16:08:14 --> Router Class Initialized
INFO - 2019-07-04 16:08:14 --> Output Class Initialized
INFO - 2019-07-04 16:08:14 --> Security Class Initialized
DEBUG - 2019-07-04 16:08:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:08:14 --> Input Class Initialized
INFO - 2019-07-04 16:08:14 --> Language Class Initialized
INFO - 2019-07-04 16:08:14 --> Language Class Initialized
INFO - 2019-07-04 16:08:14 --> Config Class Initialized
INFO - 2019-07-04 16:08:14 --> Loader Class Initialized
DEBUG - 2019-07-04 16:08:14 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:08:14 --> Helper loaded: url_helper
INFO - 2019-07-04 16:08:14 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:08:14 --> Helper loaded: string_helper
INFO - 2019-07-04 16:08:14 --> Helper loaded: array_helper
INFO - 2019-07-04 16:08:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:08:14 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:08:14 --> Database Driver Class Initialized
INFO - 2019-07-04 16:08:14 --> Controller Class Initialized
INFO - 2019-07-04 22:08:14 --> Helper loaded: language_helper
INFO - 2019-07-04 22:08:14 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:08:14 --> Model Class Initialized
INFO - 2019-07-04 22:08:14 --> Model Class Initialized
INFO - 2019-07-04 22:08:15 --> Model Class Initialized
INFO - 2019-07-04 22:08:15 --> Model Class Initialized
INFO - 2019-07-04 22:08:15 --> Helper loaded: form_helper
INFO - 2019-07-04 22:08:15 --> Form Validation Class Initialized
DEBUG - 2019-07-04 22:08:15 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 22:08:15 --> Model Class Initialized
INFO - 2019-07-04 22:08:15 --> Model Class Initialized
INFO - 2019-07-04 22:08:15 --> Final output sent to browser
DEBUG - 2019-07-04 22:08:15 --> Total execution time: 0.3699
INFO - 2019-07-04 16:08:24 --> Config Class Initialized
INFO - 2019-07-04 16:08:24 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:08:24 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:08:24 --> Utf8 Class Initialized
INFO - 2019-07-04 16:08:24 --> URI Class Initialized
INFO - 2019-07-04 16:08:24 --> Router Class Initialized
INFO - 2019-07-04 16:08:24 --> Output Class Initialized
INFO - 2019-07-04 16:08:24 --> Security Class Initialized
DEBUG - 2019-07-04 16:08:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:08:24 --> Input Class Initialized
INFO - 2019-07-04 16:08:24 --> Language Class Initialized
INFO - 2019-07-04 16:08:24 --> Language Class Initialized
INFO - 2019-07-04 16:08:24 --> Config Class Initialized
INFO - 2019-07-04 16:08:24 --> Loader Class Initialized
DEBUG - 2019-07-04 16:08:24 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:08:24 --> Helper loaded: url_helper
INFO - 2019-07-04 16:08:24 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:08:24 --> Helper loaded: string_helper
INFO - 2019-07-04 16:08:24 --> Helper loaded: array_helper
INFO - 2019-07-04 16:08:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:08:24 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:08:24 --> Database Driver Class Initialized
INFO - 2019-07-04 16:08:24 --> Controller Class Initialized
INFO - 2019-07-04 22:08:24 --> Helper loaded: language_helper
INFO - 2019-07-04 22:08:24 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:08:24 --> Model Class Initialized
INFO - 2019-07-04 22:08:24 --> Model Class Initialized
INFO - 2019-07-04 22:08:24 --> Model Class Initialized
INFO - 2019-07-04 22:08:24 --> Model Class Initialized
INFO - 2019-07-04 22:08:24 --> Model Class Initialized
INFO - 2019-07-04 22:08:24 --> Final output sent to browser
DEBUG - 2019-07-04 22:08:24 --> Total execution time: 0.3185
INFO - 2019-07-04 16:08:24 --> Config Class Initialized
INFO - 2019-07-04 16:08:24 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:08:24 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:08:24 --> Utf8 Class Initialized
INFO - 2019-07-04 16:08:24 --> URI Class Initialized
INFO - 2019-07-04 16:08:24 --> Router Class Initialized
INFO - 2019-07-04 16:08:24 --> Output Class Initialized
INFO - 2019-07-04 16:08:24 --> Security Class Initialized
DEBUG - 2019-07-04 16:08:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:08:24 --> Input Class Initialized
INFO - 2019-07-04 16:08:24 --> Language Class Initialized
INFO - 2019-07-04 16:08:24 --> Language Class Initialized
INFO - 2019-07-04 16:08:24 --> Config Class Initialized
INFO - 2019-07-04 16:08:24 --> Loader Class Initialized
DEBUG - 2019-07-04 16:08:24 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:08:24 --> Helper loaded: url_helper
INFO - 2019-07-04 16:08:24 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:08:24 --> Helper loaded: string_helper
INFO - 2019-07-04 16:08:24 --> Helper loaded: array_helper
INFO - 2019-07-04 16:08:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:08:24 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:08:24 --> Database Driver Class Initialized
INFO - 2019-07-04 16:08:24 --> Controller Class Initialized
INFO - 2019-07-04 22:08:24 --> Helper loaded: language_helper
INFO - 2019-07-04 22:08:24 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:08:24 --> Model Class Initialized
INFO - 2019-07-04 22:08:24 --> Model Class Initialized
INFO - 2019-07-04 22:08:24 --> Model Class Initialized
INFO - 2019-07-04 22:08:24 --> Model Class Initialized
INFO - 2019-07-04 22:08:24 --> Model Class Initialized
INFO - 2019-07-04 22:08:24 --> Final output sent to browser
DEBUG - 2019-07-04 22:08:24 --> Total execution time: 0.3339
INFO - 2019-07-04 16:08:26 --> Config Class Initialized
INFO - 2019-07-04 16:08:26 --> Config Class Initialized
INFO - 2019-07-04 16:08:26 --> Hooks Class Initialized
INFO - 2019-07-04 16:08:26 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:08:26 --> UTF-8 Support Enabled
DEBUG - 2019-07-04 16:08:26 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:08:26 --> Utf8 Class Initialized
INFO - 2019-07-04 16:08:26 --> Utf8 Class Initialized
INFO - 2019-07-04 16:08:26 --> URI Class Initialized
INFO - 2019-07-04 16:08:26 --> URI Class Initialized
INFO - 2019-07-04 16:08:26 --> Router Class Initialized
INFO - 2019-07-04 16:08:26 --> Router Class Initialized
INFO - 2019-07-04 16:08:26 --> Output Class Initialized
INFO - 2019-07-04 16:08:26 --> Output Class Initialized
INFO - 2019-07-04 16:08:26 --> Security Class Initialized
INFO - 2019-07-04 16:08:26 --> Security Class Initialized
DEBUG - 2019-07-04 16:08:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-04 16:08:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:08:26 --> Input Class Initialized
INFO - 2019-07-04 16:08:26 --> Input Class Initialized
INFO - 2019-07-04 16:08:26 --> Language Class Initialized
INFO - 2019-07-04 16:08:26 --> Language Class Initialized
INFO - 2019-07-04 16:08:26 --> Language Class Initialized
INFO - 2019-07-04 16:08:26 --> Language Class Initialized
INFO - 2019-07-04 16:08:26 --> Config Class Initialized
INFO - 2019-07-04 16:08:26 --> Loader Class Initialized
INFO - 2019-07-04 16:08:26 --> Config Class Initialized
INFO - 2019-07-04 16:08:26 --> Loader Class Initialized
DEBUG - 2019-07-04 16:08:26 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-04 16:08:26 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:08:26 --> Helper loaded: url_helper
INFO - 2019-07-04 16:08:26 --> Helper loaded: url_helper
INFO - 2019-07-04 16:08:26 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:08:26 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:08:26 --> Helper loaded: string_helper
INFO - 2019-07-04 16:08:26 --> Helper loaded: string_helper
INFO - 2019-07-04 16:08:26 --> Helper loaded: array_helper
INFO - 2019-07-04 16:08:26 --> Helper loaded: array_helper
INFO - 2019-07-04 16:08:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:08:26 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:08:26 --> Database Driver Class Initialized
INFO - 2019-07-04 16:08:26 --> Controller Class Initialized
INFO - 2019-07-04 22:08:26 --> Helper loaded: language_helper
INFO - 2019-07-04 22:08:26 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:08:26 --> Model Class Initialized
INFO - 2019-07-04 22:08:26 --> Model Class Initialized
INFO - 2019-07-04 22:08:26 --> Model Class Initialized
INFO - 2019-07-04 22:08:26 --> Model Class Initialized
INFO - 2019-07-04 22:08:26 --> Final output sent to browser
DEBUG - 2019-07-04 22:08:26 --> Total execution time: 0.4250
INFO - 2019-07-04 16:08:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:08:26 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:08:26 --> Database Driver Class Initialized
INFO - 2019-07-04 16:08:26 --> Controller Class Initialized
INFO - 2019-07-04 22:08:27 --> Helper loaded: language_helper
INFO - 2019-07-04 22:08:27 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:08:27 --> Model Class Initialized
INFO - 2019-07-04 22:08:27 --> Model Class Initialized
INFO - 2019-07-04 22:08:27 --> Model Class Initialized
INFO - 2019-07-04 22:08:27 --> Model Class Initialized
INFO - 2019-07-04 22:08:27 --> Model Class Initialized
INFO - 2019-07-04 22:08:27 --> Final output sent to browser
DEBUG - 2019-07-04 22:08:27 --> Total execution time: 0.5838
INFO - 2019-07-04 16:08:31 --> Config Class Initialized
INFO - 2019-07-04 16:08:31 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:08:31 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:08:31 --> Utf8 Class Initialized
INFO - 2019-07-04 16:08:31 --> URI Class Initialized
INFO - 2019-07-04 16:08:31 --> Router Class Initialized
INFO - 2019-07-04 16:08:31 --> Output Class Initialized
INFO - 2019-07-04 16:08:31 --> Security Class Initialized
DEBUG - 2019-07-04 16:08:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:08:31 --> Input Class Initialized
INFO - 2019-07-04 16:08:31 --> Language Class Initialized
INFO - 2019-07-04 16:08:31 --> Language Class Initialized
INFO - 2019-07-04 16:08:31 --> Config Class Initialized
INFO - 2019-07-04 16:08:31 --> Loader Class Initialized
DEBUG - 2019-07-04 16:08:31 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:08:31 --> Helper loaded: url_helper
INFO - 2019-07-04 16:08:31 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:08:31 --> Helper loaded: string_helper
INFO - 2019-07-04 16:08:31 --> Helper loaded: array_helper
INFO - 2019-07-04 16:08:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:08:31 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:08:31 --> Database Driver Class Initialized
INFO - 2019-07-04 16:08:31 --> Controller Class Initialized
INFO - 2019-07-04 22:08:31 --> Helper loaded: language_helper
INFO - 2019-07-04 22:08:31 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:08:31 --> Model Class Initialized
INFO - 2019-07-04 22:08:31 --> Model Class Initialized
INFO - 2019-07-04 22:08:31 --> Model Class Initialized
INFO - 2019-07-04 22:08:31 --> Model Class Initialized
INFO - 2019-07-04 22:08:31 --> Model Class Initialized
INFO - 2019-07-04 22:08:31 --> Final output sent to browser
DEBUG - 2019-07-04 22:08:31 --> Total execution time: 0.3270
INFO - 2019-07-04 16:08:31 --> Config Class Initialized
INFO - 2019-07-04 16:08:31 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:08:31 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:08:31 --> Utf8 Class Initialized
INFO - 2019-07-04 16:08:31 --> URI Class Initialized
INFO - 2019-07-04 16:08:31 --> Router Class Initialized
INFO - 2019-07-04 16:08:31 --> Output Class Initialized
INFO - 2019-07-04 16:08:31 --> Security Class Initialized
DEBUG - 2019-07-04 16:08:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:08:31 --> Input Class Initialized
INFO - 2019-07-04 16:08:31 --> Language Class Initialized
INFO - 2019-07-04 16:08:31 --> Language Class Initialized
INFO - 2019-07-04 16:08:31 --> Config Class Initialized
INFO - 2019-07-04 16:08:31 --> Loader Class Initialized
DEBUG - 2019-07-04 16:08:31 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:08:31 --> Helper loaded: url_helper
INFO - 2019-07-04 16:08:31 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:08:31 --> Helper loaded: string_helper
INFO - 2019-07-04 16:08:31 --> Helper loaded: array_helper
INFO - 2019-07-04 16:08:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:08:31 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:08:31 --> Database Driver Class Initialized
INFO - 2019-07-04 16:08:31 --> Controller Class Initialized
INFO - 2019-07-04 22:08:31 --> Helper loaded: language_helper
INFO - 2019-07-04 22:08:31 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:08:31 --> Model Class Initialized
INFO - 2019-07-04 22:08:31 --> Model Class Initialized
INFO - 2019-07-04 22:08:31 --> Model Class Initialized
INFO - 2019-07-04 22:08:31 --> Model Class Initialized
INFO - 2019-07-04 22:08:31 --> Helper loaded: form_helper
INFO - 2019-07-04 22:08:31 --> Form Validation Class Initialized
DEBUG - 2019-07-04 22:08:31 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 22:08:31 --> Model Class Initialized
INFO - 2019-07-04 22:08:31 --> Model Class Initialized
INFO - 2019-07-04 22:08:31 --> Final output sent to browser
DEBUG - 2019-07-04 22:08:31 --> Total execution time: 0.3733
INFO - 2019-07-04 16:08:36 --> Config Class Initialized
INFO - 2019-07-04 16:08:36 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:08:36 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:08:36 --> Utf8 Class Initialized
INFO - 2019-07-04 16:08:36 --> URI Class Initialized
INFO - 2019-07-04 16:08:36 --> Router Class Initialized
INFO - 2019-07-04 16:08:36 --> Output Class Initialized
INFO - 2019-07-04 16:08:36 --> Security Class Initialized
DEBUG - 2019-07-04 16:08:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:08:36 --> Input Class Initialized
INFO - 2019-07-04 16:08:36 --> Language Class Initialized
INFO - 2019-07-04 16:08:36 --> Language Class Initialized
INFO - 2019-07-04 16:08:36 --> Config Class Initialized
INFO - 2019-07-04 16:08:36 --> Loader Class Initialized
DEBUG - 2019-07-04 16:08:36 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:08:36 --> Helper loaded: url_helper
INFO - 2019-07-04 16:08:36 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:08:36 --> Helper loaded: string_helper
INFO - 2019-07-04 16:08:36 --> Helper loaded: array_helper
INFO - 2019-07-04 16:08:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:08:36 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:08:36 --> Database Driver Class Initialized
INFO - 2019-07-04 16:08:36 --> Controller Class Initialized
INFO - 2019-07-04 22:08:36 --> Helper loaded: language_helper
INFO - 2019-07-04 22:08:36 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:08:36 --> Model Class Initialized
INFO - 2019-07-04 22:08:36 --> Model Class Initialized
INFO - 2019-07-04 22:08:36 --> Model Class Initialized
INFO - 2019-07-04 22:08:36 --> Model Class Initialized
INFO - 2019-07-04 22:08:36 --> Model Class Initialized
INFO - 2019-07-04 22:08:36 --> Final output sent to browser
DEBUG - 2019-07-04 22:08:36 --> Total execution time: 0.3540
INFO - 2019-07-04 16:08:37 --> Config Class Initialized
INFO - 2019-07-04 16:08:37 --> Config Class Initialized
INFO - 2019-07-04 16:08:37 --> Hooks Class Initialized
INFO - 2019-07-04 16:08:37 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:08:38 --> UTF-8 Support Enabled
DEBUG - 2019-07-04 16:08:38 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:08:38 --> Utf8 Class Initialized
INFO - 2019-07-04 16:08:38 --> Utf8 Class Initialized
INFO - 2019-07-04 16:08:38 --> URI Class Initialized
INFO - 2019-07-04 16:08:38 --> URI Class Initialized
INFO - 2019-07-04 16:08:38 --> Router Class Initialized
INFO - 2019-07-04 16:08:38 --> Router Class Initialized
INFO - 2019-07-04 16:08:38 --> Output Class Initialized
INFO - 2019-07-04 16:08:38 --> Output Class Initialized
INFO - 2019-07-04 16:08:38 --> Security Class Initialized
INFO - 2019-07-04 16:08:38 --> Security Class Initialized
DEBUG - 2019-07-04 16:08:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-04 16:08:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:08:38 --> Input Class Initialized
INFO - 2019-07-04 16:08:38 --> Input Class Initialized
INFO - 2019-07-04 16:08:38 --> Language Class Initialized
INFO - 2019-07-04 16:08:38 --> Language Class Initialized
INFO - 2019-07-04 16:08:38 --> Language Class Initialized
INFO - 2019-07-04 16:08:38 --> Language Class Initialized
INFO - 2019-07-04 16:08:38 --> Config Class Initialized
INFO - 2019-07-04 16:08:38 --> Config Class Initialized
INFO - 2019-07-04 16:08:38 --> Loader Class Initialized
INFO - 2019-07-04 16:08:38 --> Loader Class Initialized
DEBUG - 2019-07-04 16:08:38 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-04 16:08:38 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:08:38 --> Helper loaded: url_helper
INFO - 2019-07-04 16:08:38 --> Helper loaded: url_helper
INFO - 2019-07-04 16:08:38 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:08:38 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:08:38 --> Helper loaded: string_helper
INFO - 2019-07-04 16:08:38 --> Helper loaded: string_helper
INFO - 2019-07-04 16:08:38 --> Helper loaded: array_helper
INFO - 2019-07-04 16:08:38 --> Helper loaded: array_helper
INFO - 2019-07-04 16:08:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:08:38 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:08:38 --> Database Driver Class Initialized
INFO - 2019-07-04 16:08:38 --> Controller Class Initialized
INFO - 2019-07-04 22:08:38 --> Helper loaded: language_helper
INFO - 2019-07-04 22:08:38 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:08:38 --> Model Class Initialized
INFO - 2019-07-04 22:08:38 --> Model Class Initialized
INFO - 2019-07-04 22:08:38 --> Model Class Initialized
INFO - 2019-07-04 22:08:38 --> Model Class Initialized
INFO - 2019-07-04 22:08:38 --> Model Class Initialized
INFO - 2019-07-04 22:08:38 --> Final output sent to browser
DEBUG - 2019-07-04 22:08:38 --> Total execution time: 0.4978
INFO - 2019-07-04 16:08:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:08:38 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:08:38 --> Database Driver Class Initialized
INFO - 2019-07-04 16:08:38 --> Controller Class Initialized
INFO - 2019-07-04 22:08:38 --> Helper loaded: language_helper
INFO - 2019-07-04 22:08:38 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:08:38 --> Model Class Initialized
INFO - 2019-07-04 22:08:38 --> Model Class Initialized
INFO - 2019-07-04 22:08:38 --> Model Class Initialized
INFO - 2019-07-04 22:08:38 --> Model Class Initialized
INFO - 2019-07-04 22:08:38 --> Helper loaded: form_helper
INFO - 2019-07-04 22:08:38 --> Form Validation Class Initialized
DEBUG - 2019-07-04 22:08:38 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 22:08:38 --> Model Class Initialized
INFO - 2019-07-04 22:08:38 --> Model Class Initialized
INFO - 2019-07-04 22:08:38 --> Final output sent to browser
DEBUG - 2019-07-04 22:08:38 --> Total execution time: 0.7317
INFO - 2019-07-04 16:08:39 --> Config Class Initialized
INFO - 2019-07-04 16:08:39 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:08:39 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:08:39 --> Utf8 Class Initialized
INFO - 2019-07-04 16:08:39 --> URI Class Initialized
INFO - 2019-07-04 16:08:39 --> Router Class Initialized
INFO - 2019-07-04 16:08:39 --> Output Class Initialized
INFO - 2019-07-04 16:08:39 --> Security Class Initialized
DEBUG - 2019-07-04 16:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:08:39 --> Input Class Initialized
INFO - 2019-07-04 16:08:39 --> Language Class Initialized
INFO - 2019-07-04 16:08:39 --> Language Class Initialized
INFO - 2019-07-04 16:08:39 --> Config Class Initialized
INFO - 2019-07-04 16:08:39 --> Loader Class Initialized
DEBUG - 2019-07-04 16:08:39 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:08:39 --> Helper loaded: url_helper
INFO - 2019-07-04 16:08:39 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:08:39 --> Helper loaded: string_helper
INFO - 2019-07-04 16:08:39 --> Helper loaded: array_helper
INFO - 2019-07-04 16:08:39 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:08:39 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:08:39 --> Database Driver Class Initialized
INFO - 2019-07-04 16:08:39 --> Controller Class Initialized
INFO - 2019-07-04 22:08:39 --> Helper loaded: language_helper
INFO - 2019-07-04 22:08:39 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:08:39 --> Model Class Initialized
INFO - 2019-07-04 22:08:40 --> Model Class Initialized
INFO - 2019-07-04 22:08:40 --> Model Class Initialized
INFO - 2019-07-04 22:08:40 --> Model Class Initialized
INFO - 2019-07-04 22:08:40 --> Model Class Initialized
INFO - 2019-07-04 22:08:40 --> Final output sent to browser
DEBUG - 2019-07-04 22:08:40 --> Total execution time: 0.3501
INFO - 2019-07-04 16:08:44 --> Config Class Initialized
INFO - 2019-07-04 16:08:44 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:08:44 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:08:44 --> Utf8 Class Initialized
INFO - 2019-07-04 16:08:44 --> URI Class Initialized
INFO - 2019-07-04 16:08:44 --> Router Class Initialized
INFO - 2019-07-04 16:08:44 --> Output Class Initialized
INFO - 2019-07-04 16:08:44 --> Security Class Initialized
DEBUG - 2019-07-04 16:08:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:08:44 --> Input Class Initialized
INFO - 2019-07-04 16:08:44 --> Language Class Initialized
INFO - 2019-07-04 16:08:44 --> Language Class Initialized
INFO - 2019-07-04 16:08:44 --> Config Class Initialized
INFO - 2019-07-04 16:08:44 --> Loader Class Initialized
DEBUG - 2019-07-04 16:08:44 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:08:44 --> Helper loaded: url_helper
INFO - 2019-07-04 16:08:44 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:08:44 --> Helper loaded: string_helper
INFO - 2019-07-04 16:08:44 --> Helper loaded: array_helper
INFO - 2019-07-04 16:08:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:08:44 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:08:44 --> Database Driver Class Initialized
INFO - 2019-07-04 16:08:45 --> Controller Class Initialized
INFO - 2019-07-04 22:08:45 --> Helper loaded: language_helper
INFO - 2019-07-04 22:08:45 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:08:45 --> Model Class Initialized
INFO - 2019-07-04 22:08:45 --> Model Class Initialized
INFO - 2019-07-04 22:08:45 --> Model Class Initialized
INFO - 2019-07-04 22:08:45 --> Model Class Initialized
INFO - 2019-07-04 22:08:45 --> Helper loaded: form_helper
INFO - 2019-07-04 22:08:45 --> Form Validation Class Initialized
DEBUG - 2019-07-04 22:08:45 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 22:08:45 --> Model Class Initialized
INFO - 2019-07-04 22:08:45 --> Model Class Initialized
INFO - 2019-07-04 22:08:45 --> Final output sent to browser
DEBUG - 2019-07-04 22:08:45 --> Total execution time: 0.3922
INFO - 2019-07-04 16:08:45 --> Config Class Initialized
INFO - 2019-07-04 16:08:45 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:08:45 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:08:45 --> Utf8 Class Initialized
INFO - 2019-07-04 16:08:45 --> URI Class Initialized
INFO - 2019-07-04 16:08:45 --> Router Class Initialized
INFO - 2019-07-04 16:08:45 --> Output Class Initialized
INFO - 2019-07-04 16:08:45 --> Security Class Initialized
DEBUG - 2019-07-04 16:08:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:08:45 --> Input Class Initialized
INFO - 2019-07-04 16:08:45 --> Language Class Initialized
INFO - 2019-07-04 16:08:45 --> Language Class Initialized
INFO - 2019-07-04 16:08:45 --> Config Class Initialized
INFO - 2019-07-04 16:08:45 --> Loader Class Initialized
DEBUG - 2019-07-04 16:08:45 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:08:45 --> Helper loaded: url_helper
INFO - 2019-07-04 16:08:45 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:08:45 --> Helper loaded: string_helper
INFO - 2019-07-04 16:08:45 --> Helper loaded: array_helper
INFO - 2019-07-04 16:08:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:08:45 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:08:45 --> Database Driver Class Initialized
INFO - 2019-07-04 16:08:45 --> Controller Class Initialized
INFO - 2019-07-04 22:08:45 --> Helper loaded: language_helper
INFO - 2019-07-04 22:08:45 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:08:45 --> Model Class Initialized
INFO - 2019-07-04 22:08:45 --> Model Class Initialized
INFO - 2019-07-04 22:08:45 --> Model Class Initialized
INFO - 2019-07-04 22:08:45 --> Model Class Initialized
INFO - 2019-07-04 22:08:45 --> Helper loaded: form_helper
INFO - 2019-07-04 22:08:45 --> Form Validation Class Initialized
DEBUG - 2019-07-04 22:08:45 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 22:08:45 --> Model Class Initialized
INFO - 2019-07-04 22:08:45 --> Model Class Initialized
INFO - 2019-07-04 22:08:45 --> Final output sent to browser
DEBUG - 2019-07-04 22:08:45 --> Total execution time: 0.4116
INFO - 2019-07-04 16:08:53 --> Config Class Initialized
INFO - 2019-07-04 16:08:53 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:08:53 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:08:53 --> Utf8 Class Initialized
INFO - 2019-07-04 16:08:53 --> URI Class Initialized
INFO - 2019-07-04 16:08:53 --> Router Class Initialized
INFO - 2019-07-04 16:08:53 --> Output Class Initialized
INFO - 2019-07-04 16:08:54 --> Security Class Initialized
DEBUG - 2019-07-04 16:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:08:54 --> Input Class Initialized
INFO - 2019-07-04 16:08:54 --> Language Class Initialized
INFO - 2019-07-04 16:08:54 --> Language Class Initialized
INFO - 2019-07-04 16:08:54 --> Config Class Initialized
INFO - 2019-07-04 16:08:54 --> Loader Class Initialized
DEBUG - 2019-07-04 16:08:54 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:08:54 --> Helper loaded: url_helper
INFO - 2019-07-04 16:08:54 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:08:54 --> Helper loaded: string_helper
INFO - 2019-07-04 16:08:54 --> Helper loaded: array_helper
INFO - 2019-07-04 16:08:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:08:54 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:08:54 --> Database Driver Class Initialized
INFO - 2019-07-04 16:08:54 --> Controller Class Initialized
INFO - 2019-07-04 22:08:54 --> Helper loaded: language_helper
INFO - 2019-07-04 22:08:54 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:08:54 --> Model Class Initialized
INFO - 2019-07-04 22:08:54 --> Model Class Initialized
INFO - 2019-07-04 22:08:54 --> Model Class Initialized
INFO - 2019-07-04 22:08:54 --> Model Class Initialized
INFO - 2019-07-04 22:08:54 --> Helper loaded: form_helper
INFO - 2019-07-04 22:08:54 --> Form Validation Class Initialized
DEBUG - 2019-07-04 22:08:54 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 22:08:54 --> Model Class Initialized
INFO - 2019-07-04 22:08:54 --> Model Class Initialized
INFO - 2019-07-04 22:08:54 --> Final output sent to browser
DEBUG - 2019-07-04 22:08:54 --> Total execution time: 0.3888
INFO - 2019-07-04 16:08:55 --> Config Class Initialized
INFO - 2019-07-04 16:08:55 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:08:55 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:08:55 --> Utf8 Class Initialized
INFO - 2019-07-04 16:08:55 --> URI Class Initialized
INFO - 2019-07-04 16:08:55 --> Router Class Initialized
INFO - 2019-07-04 16:08:55 --> Output Class Initialized
INFO - 2019-07-04 16:08:55 --> Security Class Initialized
DEBUG - 2019-07-04 16:08:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:08:55 --> Input Class Initialized
INFO - 2019-07-04 16:08:55 --> Language Class Initialized
INFO - 2019-07-04 16:08:55 --> Language Class Initialized
INFO - 2019-07-04 16:08:55 --> Config Class Initialized
INFO - 2019-07-04 16:08:55 --> Loader Class Initialized
DEBUG - 2019-07-04 16:08:55 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:08:55 --> Helper loaded: url_helper
INFO - 2019-07-04 16:08:55 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:08:55 --> Helper loaded: string_helper
INFO - 2019-07-04 16:08:55 --> Helper loaded: array_helper
INFO - 2019-07-04 16:08:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:08:55 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:08:55 --> Database Driver Class Initialized
INFO - 2019-07-04 16:08:55 --> Controller Class Initialized
INFO - 2019-07-04 22:08:55 --> Helper loaded: language_helper
INFO - 2019-07-04 22:08:55 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:08:55 --> Model Class Initialized
INFO - 2019-07-04 22:08:55 --> Model Class Initialized
INFO - 2019-07-04 22:08:55 --> Model Class Initialized
INFO - 2019-07-04 22:08:55 --> Model Class Initialized
INFO - 2019-07-04 22:08:55 --> Helper loaded: form_helper
INFO - 2019-07-04 22:08:55 --> Form Validation Class Initialized
DEBUG - 2019-07-04 22:08:55 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 22:08:55 --> Model Class Initialized
INFO - 2019-07-04 22:08:55 --> Model Class Initialized
INFO - 2019-07-04 22:08:55 --> Final output sent to browser
DEBUG - 2019-07-04 22:08:55 --> Total execution time: 0.3792
INFO - 2019-07-04 16:08:56 --> Config Class Initialized
INFO - 2019-07-04 16:08:56 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:08:56 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:08:56 --> Utf8 Class Initialized
INFO - 2019-07-04 16:08:56 --> URI Class Initialized
INFO - 2019-07-04 16:08:56 --> Router Class Initialized
INFO - 2019-07-04 16:08:56 --> Output Class Initialized
INFO - 2019-07-04 16:08:56 --> Security Class Initialized
DEBUG - 2019-07-04 16:08:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:08:56 --> Input Class Initialized
INFO - 2019-07-04 16:08:56 --> Language Class Initialized
INFO - 2019-07-04 16:08:56 --> Language Class Initialized
INFO - 2019-07-04 16:08:56 --> Config Class Initialized
INFO - 2019-07-04 16:08:56 --> Loader Class Initialized
DEBUG - 2019-07-04 16:08:56 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:08:56 --> Helper loaded: url_helper
INFO - 2019-07-04 16:08:56 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:08:56 --> Helper loaded: string_helper
INFO - 2019-07-04 16:08:56 --> Helper loaded: array_helper
INFO - 2019-07-04 16:08:56 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:08:56 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:08:56 --> Database Driver Class Initialized
INFO - 2019-07-04 16:08:56 --> Controller Class Initialized
INFO - 2019-07-04 22:08:56 --> Helper loaded: language_helper
INFO - 2019-07-04 22:08:56 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:08:56 --> Model Class Initialized
INFO - 2019-07-04 22:08:56 --> Model Class Initialized
INFO - 2019-07-04 22:08:56 --> Model Class Initialized
INFO - 2019-07-04 22:08:56 --> Model Class Initialized
INFO - 2019-07-04 22:08:56 --> Helper loaded: form_helper
INFO - 2019-07-04 22:08:56 --> Form Validation Class Initialized
DEBUG - 2019-07-04 22:08:56 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 22:08:56 --> Model Class Initialized
INFO - 2019-07-04 22:08:56 --> Model Class Initialized
INFO - 2019-07-04 22:08:56 --> Final output sent to browser
DEBUG - 2019-07-04 22:08:56 --> Total execution time: 0.5650
INFO - 2019-07-04 16:09:02 --> Config Class Initialized
INFO - 2019-07-04 16:09:03 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:09:03 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:09:03 --> Utf8 Class Initialized
INFO - 2019-07-04 16:09:03 --> URI Class Initialized
INFO - 2019-07-04 16:09:03 --> Router Class Initialized
INFO - 2019-07-04 16:09:03 --> Output Class Initialized
INFO - 2019-07-04 16:09:03 --> Security Class Initialized
DEBUG - 2019-07-04 16:09:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:09:03 --> Input Class Initialized
INFO - 2019-07-04 16:09:03 --> Language Class Initialized
INFO - 2019-07-04 16:09:03 --> Language Class Initialized
INFO - 2019-07-04 16:09:03 --> Config Class Initialized
INFO - 2019-07-04 16:09:03 --> Loader Class Initialized
DEBUG - 2019-07-04 16:09:03 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:09:03 --> Helper loaded: url_helper
INFO - 2019-07-04 16:09:03 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:09:03 --> Helper loaded: string_helper
INFO - 2019-07-04 16:09:03 --> Helper loaded: array_helper
INFO - 2019-07-04 16:09:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:09:03 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:09:03 --> Database Driver Class Initialized
INFO - 2019-07-04 16:09:03 --> Controller Class Initialized
INFO - 2019-07-04 22:09:03 --> Helper loaded: language_helper
INFO - 2019-07-04 22:09:03 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:09:03 --> Model Class Initialized
INFO - 2019-07-04 22:09:03 --> Model Class Initialized
INFO - 2019-07-04 22:09:03 --> Model Class Initialized
INFO - 2019-07-04 22:09:03 --> Model Class Initialized
INFO - 2019-07-04 22:09:03 --> Model Class Initialized
INFO - 2019-07-04 22:09:03 --> Final output sent to browser
DEBUG - 2019-07-04 22:09:03 --> Total execution time: 0.3413
INFO - 2019-07-04 16:09:03 --> Config Class Initialized
INFO - 2019-07-04 16:09:03 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:09:03 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:09:03 --> Utf8 Class Initialized
INFO - 2019-07-04 16:09:03 --> URI Class Initialized
INFO - 2019-07-04 16:09:03 --> Router Class Initialized
INFO - 2019-07-04 16:09:03 --> Output Class Initialized
INFO - 2019-07-04 16:09:03 --> Security Class Initialized
DEBUG - 2019-07-04 16:09:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:09:03 --> Input Class Initialized
INFO - 2019-07-04 16:09:03 --> Language Class Initialized
INFO - 2019-07-04 16:09:03 --> Language Class Initialized
INFO - 2019-07-04 16:09:03 --> Config Class Initialized
INFO - 2019-07-04 16:09:03 --> Loader Class Initialized
DEBUG - 2019-07-04 16:09:03 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:09:03 --> Helper loaded: url_helper
INFO - 2019-07-04 16:09:03 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:09:03 --> Helper loaded: string_helper
INFO - 2019-07-04 16:09:03 --> Helper loaded: array_helper
INFO - 2019-07-04 16:09:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:09:03 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:09:03 --> Database Driver Class Initialized
INFO - 2019-07-04 16:09:03 --> Controller Class Initialized
INFO - 2019-07-04 22:09:03 --> Helper loaded: language_helper
INFO - 2019-07-04 22:09:03 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:09:03 --> Model Class Initialized
INFO - 2019-07-04 22:09:03 --> Model Class Initialized
INFO - 2019-07-04 22:09:03 --> Model Class Initialized
INFO - 2019-07-04 22:09:03 --> Model Class Initialized
INFO - 2019-07-04 22:09:03 --> Model Class Initialized
INFO - 2019-07-04 22:09:03 --> Final output sent to browser
DEBUG - 2019-07-04 22:09:03 --> Total execution time: 0.3644
INFO - 2019-07-04 16:09:04 --> Config Class Initialized
INFO - 2019-07-04 16:09:04 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:09:04 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:09:04 --> Utf8 Class Initialized
INFO - 2019-07-04 16:09:04 --> URI Class Initialized
INFO - 2019-07-04 16:09:05 --> Router Class Initialized
INFO - 2019-07-04 16:09:05 --> Output Class Initialized
INFO - 2019-07-04 16:09:05 --> Security Class Initialized
DEBUG - 2019-07-04 16:09:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:09:05 --> Input Class Initialized
INFO - 2019-07-04 16:09:05 --> Language Class Initialized
INFO - 2019-07-04 16:09:05 --> Language Class Initialized
INFO - 2019-07-04 16:09:05 --> Config Class Initialized
INFO - 2019-07-04 16:09:05 --> Loader Class Initialized
DEBUG - 2019-07-04 16:09:05 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:09:05 --> Helper loaded: url_helper
INFO - 2019-07-04 16:09:05 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:09:05 --> Helper loaded: string_helper
INFO - 2019-07-04 16:09:05 --> Helper loaded: array_helper
INFO - 2019-07-04 16:09:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:09:05 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:09:05 --> Database Driver Class Initialized
INFO - 2019-07-04 16:09:05 --> Controller Class Initialized
INFO - 2019-07-04 22:09:05 --> Helper loaded: language_helper
INFO - 2019-07-04 22:09:05 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:09:05 --> Model Class Initialized
INFO - 2019-07-04 22:09:05 --> Model Class Initialized
INFO - 2019-07-04 22:09:05 --> Model Class Initialized
INFO - 2019-07-04 22:09:05 --> Model Class Initialized
INFO - 2019-07-04 22:09:05 --> Model Class Initialized
INFO - 2019-07-04 22:09:05 --> Final output sent to browser
DEBUG - 2019-07-04 22:09:05 --> Total execution time: 0.3407
INFO - 2019-07-04 16:09:05 --> Config Class Initialized
INFO - 2019-07-04 16:09:05 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:09:05 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:09:05 --> Utf8 Class Initialized
INFO - 2019-07-04 16:09:05 --> URI Class Initialized
INFO - 2019-07-04 16:09:05 --> Router Class Initialized
INFO - 2019-07-04 16:09:05 --> Output Class Initialized
INFO - 2019-07-04 16:09:05 --> Security Class Initialized
DEBUG - 2019-07-04 16:09:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:09:05 --> Input Class Initialized
INFO - 2019-07-04 16:09:05 --> Language Class Initialized
INFO - 2019-07-04 16:09:05 --> Language Class Initialized
INFO - 2019-07-04 16:09:05 --> Config Class Initialized
INFO - 2019-07-04 16:09:05 --> Loader Class Initialized
DEBUG - 2019-07-04 16:09:05 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:09:05 --> Helper loaded: url_helper
INFO - 2019-07-04 16:09:05 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:09:05 --> Helper loaded: string_helper
INFO - 2019-07-04 16:09:05 --> Helper loaded: array_helper
INFO - 2019-07-04 16:09:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:09:05 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:09:05 --> Database Driver Class Initialized
INFO - 2019-07-04 16:09:05 --> Controller Class Initialized
INFO - 2019-07-04 22:09:05 --> Helper loaded: language_helper
INFO - 2019-07-04 22:09:05 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:09:05 --> Model Class Initialized
INFO - 2019-07-04 22:09:05 --> Model Class Initialized
INFO - 2019-07-04 22:09:05 --> Model Class Initialized
INFO - 2019-07-04 22:09:05 --> Model Class Initialized
INFO - 2019-07-04 22:09:05 --> Helper loaded: form_helper
INFO - 2019-07-04 22:09:05 --> Form Validation Class Initialized
DEBUG - 2019-07-04 22:09:05 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 22:09:05 --> Model Class Initialized
INFO - 2019-07-04 22:09:05 --> Model Class Initialized
INFO - 2019-07-04 22:09:05 --> Final output sent to browser
DEBUG - 2019-07-04 22:09:05 --> Total execution time: 0.4152
INFO - 2019-07-04 16:09:06 --> Config Class Initialized
INFO - 2019-07-04 16:09:06 --> Config Class Initialized
INFO - 2019-07-04 16:09:06 --> Hooks Class Initialized
INFO - 2019-07-04 16:09:06 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:09:06 --> UTF-8 Support Enabled
DEBUG - 2019-07-04 16:09:06 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:09:06 --> Utf8 Class Initialized
INFO - 2019-07-04 16:09:06 --> Utf8 Class Initialized
INFO - 2019-07-04 16:09:06 --> URI Class Initialized
INFO - 2019-07-04 16:09:06 --> URI Class Initialized
INFO - 2019-07-04 16:09:06 --> Router Class Initialized
INFO - 2019-07-04 16:09:06 --> Router Class Initialized
INFO - 2019-07-04 16:09:06 --> Output Class Initialized
INFO - 2019-07-04 16:09:06 --> Output Class Initialized
INFO - 2019-07-04 16:09:06 --> Security Class Initialized
INFO - 2019-07-04 16:09:06 --> Security Class Initialized
DEBUG - 2019-07-04 16:09:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-04 16:09:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:09:07 --> Input Class Initialized
INFO - 2019-07-04 16:09:07 --> Input Class Initialized
INFO - 2019-07-04 16:09:07 --> Language Class Initialized
INFO - 2019-07-04 16:09:07 --> Language Class Initialized
INFO - 2019-07-04 16:09:07 --> Language Class Initialized
INFO - 2019-07-04 16:09:07 --> Language Class Initialized
INFO - 2019-07-04 16:09:07 --> Config Class Initialized
INFO - 2019-07-04 16:09:07 --> Config Class Initialized
INFO - 2019-07-04 16:09:07 --> Loader Class Initialized
INFO - 2019-07-04 16:09:07 --> Loader Class Initialized
DEBUG - 2019-07-04 16:09:07 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-04 16:09:07 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:09:07 --> Helper loaded: url_helper
INFO - 2019-07-04 16:09:07 --> Helper loaded: url_helper
INFO - 2019-07-04 16:09:07 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:09:07 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:09:07 --> Helper loaded: string_helper
INFO - 2019-07-04 16:09:07 --> Helper loaded: string_helper
INFO - 2019-07-04 16:09:07 --> Helper loaded: array_helper
INFO - 2019-07-04 16:09:07 --> Helper loaded: array_helper
INFO - 2019-07-04 16:09:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:09:07 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:09:07 --> Database Driver Class Initialized
INFO - 2019-07-04 16:09:07 --> Controller Class Initialized
INFO - 2019-07-04 22:09:07 --> Helper loaded: language_helper
INFO - 2019-07-04 22:09:07 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:09:07 --> Model Class Initialized
INFO - 2019-07-04 22:09:07 --> Model Class Initialized
INFO - 2019-07-04 22:09:07 --> Model Class Initialized
INFO - 2019-07-04 22:09:07 --> Model Class Initialized
INFO - 2019-07-04 22:09:07 --> Final output sent to browser
DEBUG - 2019-07-04 22:09:07 --> Total execution time: 0.4487
INFO - 2019-07-04 16:09:07 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:09:07 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:09:07 --> Database Driver Class Initialized
INFO - 2019-07-04 16:09:07 --> Controller Class Initialized
INFO - 2019-07-04 22:09:07 --> Helper loaded: language_helper
INFO - 2019-07-04 22:09:07 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:09:07 --> Model Class Initialized
INFO - 2019-07-04 22:09:07 --> Model Class Initialized
INFO - 2019-07-04 22:09:07 --> Model Class Initialized
INFO - 2019-07-04 22:09:07 --> Model Class Initialized
INFO - 2019-07-04 22:09:07 --> Model Class Initialized
INFO - 2019-07-04 22:09:07 --> Final output sent to browser
DEBUG - 2019-07-04 22:09:07 --> Total execution time: 0.6126
INFO - 2019-07-04 16:09:10 --> Config Class Initialized
INFO - 2019-07-04 16:09:10 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:09:10 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:09:10 --> Utf8 Class Initialized
INFO - 2019-07-04 16:09:10 --> URI Class Initialized
INFO - 2019-07-04 16:09:10 --> Router Class Initialized
INFO - 2019-07-04 16:09:10 --> Output Class Initialized
INFO - 2019-07-04 16:09:10 --> Security Class Initialized
DEBUG - 2019-07-04 16:09:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:09:10 --> Input Class Initialized
INFO - 2019-07-04 16:09:10 --> Language Class Initialized
INFO - 2019-07-04 16:09:10 --> Language Class Initialized
INFO - 2019-07-04 16:09:10 --> Config Class Initialized
INFO - 2019-07-04 16:09:10 --> Loader Class Initialized
DEBUG - 2019-07-04 16:09:10 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:09:10 --> Helper loaded: url_helper
INFO - 2019-07-04 16:09:10 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:09:10 --> Helper loaded: string_helper
INFO - 2019-07-04 16:09:10 --> Helper loaded: array_helper
INFO - 2019-07-04 16:09:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:09:10 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:09:10 --> Database Driver Class Initialized
INFO - 2019-07-04 16:09:10 --> Controller Class Initialized
INFO - 2019-07-04 22:09:10 --> Helper loaded: language_helper
INFO - 2019-07-04 22:09:10 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:09:10 --> Model Class Initialized
INFO - 2019-07-04 22:09:10 --> Model Class Initialized
INFO - 2019-07-04 22:09:10 --> Model Class Initialized
INFO - 2019-07-04 22:09:10 --> Model Class Initialized
INFO - 2019-07-04 22:09:10 --> Model Class Initialized
INFO - 2019-07-04 22:09:10 --> Final output sent to browser
DEBUG - 2019-07-04 22:09:10 --> Total execution time: 0.3334
INFO - 2019-07-04 16:09:10 --> Config Class Initialized
INFO - 2019-07-04 16:09:10 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:09:10 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:09:10 --> Utf8 Class Initialized
INFO - 2019-07-04 16:09:10 --> URI Class Initialized
INFO - 2019-07-04 16:09:10 --> Router Class Initialized
INFO - 2019-07-04 16:09:10 --> Output Class Initialized
INFO - 2019-07-04 16:09:10 --> Security Class Initialized
DEBUG - 2019-07-04 16:09:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:09:10 --> Input Class Initialized
INFO - 2019-07-04 16:09:10 --> Language Class Initialized
INFO - 2019-07-04 16:09:10 --> Language Class Initialized
INFO - 2019-07-04 16:09:11 --> Config Class Initialized
INFO - 2019-07-04 16:09:11 --> Loader Class Initialized
DEBUG - 2019-07-04 16:09:11 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:09:11 --> Helper loaded: url_helper
INFO - 2019-07-04 16:09:11 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:09:11 --> Helper loaded: string_helper
INFO - 2019-07-04 16:09:11 --> Helper loaded: array_helper
INFO - 2019-07-04 16:09:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:09:11 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:09:11 --> Database Driver Class Initialized
INFO - 2019-07-04 16:09:11 --> Controller Class Initialized
INFO - 2019-07-04 22:09:11 --> Helper loaded: language_helper
INFO - 2019-07-04 22:09:11 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:09:11 --> Model Class Initialized
INFO - 2019-07-04 22:09:11 --> Model Class Initialized
INFO - 2019-07-04 22:09:11 --> Model Class Initialized
INFO - 2019-07-04 22:09:11 --> Model Class Initialized
INFO - 2019-07-04 22:09:11 --> Helper loaded: form_helper
INFO - 2019-07-04 22:09:11 --> Form Validation Class Initialized
DEBUG - 2019-07-04 22:09:11 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 22:09:11 --> Model Class Initialized
INFO - 2019-07-04 22:09:11 --> Model Class Initialized
INFO - 2019-07-04 22:09:11 --> Final output sent to browser
DEBUG - 2019-07-04 22:09:11 --> Total execution time: 0.4342
INFO - 2019-07-04 16:09:46 --> Config Class Initialized
INFO - 2019-07-04 16:09:46 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:09:46 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:09:46 --> Utf8 Class Initialized
INFO - 2019-07-04 16:09:46 --> URI Class Initialized
INFO - 2019-07-04 16:09:46 --> Router Class Initialized
INFO - 2019-07-04 16:09:46 --> Output Class Initialized
INFO - 2019-07-04 16:09:46 --> Security Class Initialized
DEBUG - 2019-07-04 16:09:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:09:46 --> Input Class Initialized
INFO - 2019-07-04 16:09:46 --> Language Class Initialized
INFO - 2019-07-04 16:09:47 --> Language Class Initialized
INFO - 2019-07-04 16:09:47 --> Config Class Initialized
INFO - 2019-07-04 16:09:47 --> Loader Class Initialized
DEBUG - 2019-07-04 16:09:47 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:09:47 --> Helper loaded: url_helper
INFO - 2019-07-04 16:09:47 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:09:47 --> Helper loaded: string_helper
INFO - 2019-07-04 16:09:47 --> Helper loaded: array_helper
INFO - 2019-07-04 16:09:47 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:09:47 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:09:47 --> Database Driver Class Initialized
INFO - 2019-07-04 16:09:47 --> Controller Class Initialized
INFO - 2019-07-04 22:09:47 --> Helper loaded: language_helper
INFO - 2019-07-04 22:09:47 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:09:47 --> Model Class Initialized
INFO - 2019-07-04 22:09:47 --> Model Class Initialized
INFO - 2019-07-04 22:09:47 --> Model Class Initialized
INFO - 2019-07-04 22:09:47 --> Model Class Initialized
INFO - 2019-07-04 22:09:47 --> Model Class Initialized
INFO - 2019-07-04 22:09:47 --> Final output sent to browser
DEBUG - 2019-07-04 22:09:47 --> Total execution time: 0.3607
INFO - 2019-07-04 16:09:47 --> Config Class Initialized
INFO - 2019-07-04 16:09:47 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:09:47 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:09:47 --> Utf8 Class Initialized
INFO - 2019-07-04 16:09:47 --> URI Class Initialized
INFO - 2019-07-04 16:09:47 --> Router Class Initialized
INFO - 2019-07-04 16:09:47 --> Output Class Initialized
INFO - 2019-07-04 16:09:47 --> Security Class Initialized
DEBUG - 2019-07-04 16:09:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:09:47 --> Input Class Initialized
INFO - 2019-07-04 16:09:47 --> Language Class Initialized
INFO - 2019-07-04 16:09:47 --> Language Class Initialized
INFO - 2019-07-04 16:09:47 --> Config Class Initialized
INFO - 2019-07-04 16:09:47 --> Loader Class Initialized
DEBUG - 2019-07-04 16:09:47 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:09:47 --> Helper loaded: url_helper
INFO - 2019-07-04 16:09:47 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:09:47 --> Helper loaded: string_helper
INFO - 2019-07-04 16:09:47 --> Helper loaded: array_helper
INFO - 2019-07-04 16:09:47 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:09:47 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:09:47 --> Database Driver Class Initialized
INFO - 2019-07-04 16:09:47 --> Controller Class Initialized
INFO - 2019-07-04 22:09:47 --> Helper loaded: language_helper
INFO - 2019-07-04 22:09:47 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:09:47 --> Model Class Initialized
INFO - 2019-07-04 22:09:47 --> Model Class Initialized
INFO - 2019-07-04 22:09:47 --> Model Class Initialized
INFO - 2019-07-04 22:09:47 --> Model Class Initialized
INFO - 2019-07-04 22:09:47 --> Helper loaded: form_helper
INFO - 2019-07-04 22:09:47 --> Form Validation Class Initialized
DEBUG - 2019-07-04 22:09:47 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 22:09:47 --> Model Class Initialized
INFO - 2019-07-04 22:09:47 --> Model Class Initialized
INFO - 2019-07-04 22:09:47 --> Final output sent to browser
DEBUG - 2019-07-04 22:09:47 --> Total execution time: 0.4187
INFO - 2019-07-04 16:09:57 --> Config Class Initialized
INFO - 2019-07-04 16:09:57 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:09:57 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:09:57 --> Utf8 Class Initialized
INFO - 2019-07-04 16:09:57 --> URI Class Initialized
INFO - 2019-07-04 16:09:57 --> Router Class Initialized
INFO - 2019-07-04 16:09:57 --> Output Class Initialized
INFO - 2019-07-04 16:09:57 --> Security Class Initialized
DEBUG - 2019-07-04 16:09:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:09:58 --> Input Class Initialized
INFO - 2019-07-04 16:09:58 --> Language Class Initialized
INFO - 2019-07-04 16:09:58 --> Language Class Initialized
INFO - 2019-07-04 16:09:58 --> Config Class Initialized
INFO - 2019-07-04 16:09:58 --> Loader Class Initialized
DEBUG - 2019-07-04 16:09:58 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:09:58 --> Helper loaded: url_helper
INFO - 2019-07-04 16:09:58 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:09:58 --> Helper loaded: string_helper
INFO - 2019-07-04 16:09:58 --> Helper loaded: array_helper
INFO - 2019-07-04 16:09:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:09:58 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:09:58 --> Database Driver Class Initialized
INFO - 2019-07-04 16:09:58 --> Controller Class Initialized
INFO - 2019-07-04 22:09:58 --> Helper loaded: language_helper
INFO - 2019-07-04 22:09:58 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:09:58 --> Model Class Initialized
INFO - 2019-07-04 22:09:58 --> Model Class Initialized
INFO - 2019-07-04 22:09:58 --> Model Class Initialized
INFO - 2019-07-04 22:09:58 --> Model Class Initialized
INFO - 2019-07-04 22:09:58 --> Helper loaded: form_helper
INFO - 2019-07-04 22:09:58 --> Form Validation Class Initialized
DEBUG - 2019-07-04 22:09:58 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 22:09:58 --> Model Class Initialized
INFO - 2019-07-04 22:09:58 --> Model Class Initialized
INFO - 2019-07-04 22:09:58 --> Final output sent to browser
DEBUG - 2019-07-04 22:09:58 --> Total execution time: 0.4233
INFO - 2019-07-04 16:10:43 --> Config Class Initialized
INFO - 2019-07-04 16:10:43 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:10:43 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:10:43 --> Utf8 Class Initialized
INFO - 2019-07-04 16:10:43 --> URI Class Initialized
INFO - 2019-07-04 16:10:43 --> Router Class Initialized
INFO - 2019-07-04 16:10:43 --> Output Class Initialized
INFO - 2019-07-04 16:10:43 --> Security Class Initialized
DEBUG - 2019-07-04 16:10:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:10:44 --> Input Class Initialized
INFO - 2019-07-04 16:10:44 --> Language Class Initialized
INFO - 2019-07-04 16:10:44 --> Language Class Initialized
INFO - 2019-07-04 16:10:44 --> Config Class Initialized
INFO - 2019-07-04 16:10:44 --> Loader Class Initialized
DEBUG - 2019-07-04 16:10:44 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:10:44 --> Helper loaded: url_helper
INFO - 2019-07-04 16:10:44 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:10:44 --> Helper loaded: string_helper
INFO - 2019-07-04 16:10:44 --> Helper loaded: array_helper
INFO - 2019-07-04 16:10:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:10:44 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:10:44 --> Database Driver Class Initialized
INFO - 2019-07-04 16:10:44 --> Controller Class Initialized
INFO - 2019-07-04 22:10:44 --> Helper loaded: language_helper
INFO - 2019-07-04 22:10:44 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:10:44 --> Model Class Initialized
INFO - 2019-07-04 22:10:44 --> Model Class Initialized
INFO - 2019-07-04 22:10:44 --> Model Class Initialized
INFO - 2019-07-04 22:10:44 --> Model Class Initialized
INFO - 2019-07-04 22:10:44 --> Final output sent to browser
DEBUG - 2019-07-04 22:10:44 --> Total execution time: 0.3204
INFO - 2019-07-04 16:10:52 --> Config Class Initialized
INFO - 2019-07-04 16:10:52 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:10:52 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:10:52 --> Utf8 Class Initialized
INFO - 2019-07-04 16:10:52 --> URI Class Initialized
INFO - 2019-07-04 16:10:52 --> Router Class Initialized
INFO - 2019-07-04 16:10:52 --> Output Class Initialized
INFO - 2019-07-04 16:10:52 --> Security Class Initialized
DEBUG - 2019-07-04 16:10:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:10:52 --> Input Class Initialized
INFO - 2019-07-04 16:10:52 --> Language Class Initialized
INFO - 2019-07-04 16:10:52 --> Language Class Initialized
INFO - 2019-07-04 16:10:52 --> Config Class Initialized
INFO - 2019-07-04 16:10:52 --> Loader Class Initialized
DEBUG - 2019-07-04 16:10:52 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:10:52 --> Helper loaded: url_helper
INFO - 2019-07-04 16:10:52 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:10:52 --> Helper loaded: string_helper
INFO - 2019-07-04 16:10:52 --> Helper loaded: array_helper
INFO - 2019-07-04 16:10:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:10:52 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:10:52 --> Database Driver Class Initialized
INFO - 2019-07-04 16:10:52 --> Controller Class Initialized
INFO - 2019-07-04 22:10:52 --> Helper loaded: language_helper
INFO - 2019-07-04 22:10:52 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:10:52 --> Model Class Initialized
INFO - 2019-07-04 22:10:52 --> Model Class Initialized
INFO - 2019-07-04 22:10:52 --> Model Class Initialized
INFO - 2019-07-04 22:10:52 --> Model Class Initialized
INFO - 2019-07-04 22:10:52 --> Final output sent to browser
DEBUG - 2019-07-04 22:10:52 --> Total execution time: 0.3831
INFO - 2019-07-04 16:19:50 --> Config Class Initialized
INFO - 2019-07-04 16:19:50 --> Config Class Initialized
INFO - 2019-07-04 16:19:50 --> Hooks Class Initialized
INFO - 2019-07-04 16:19:50 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:19:50 --> UTF-8 Support Enabled
DEBUG - 2019-07-04 16:19:50 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:19:50 --> Utf8 Class Initialized
INFO - 2019-07-04 16:19:50 --> Utf8 Class Initialized
INFO - 2019-07-04 16:19:50 --> URI Class Initialized
INFO - 2019-07-04 16:19:50 --> URI Class Initialized
INFO - 2019-07-04 16:19:50 --> Router Class Initialized
INFO - 2019-07-04 16:19:50 --> Router Class Initialized
INFO - 2019-07-04 16:19:50 --> Output Class Initialized
INFO - 2019-07-04 16:19:50 --> Output Class Initialized
INFO - 2019-07-04 16:19:50 --> Security Class Initialized
INFO - 2019-07-04 16:19:50 --> Security Class Initialized
DEBUG - 2019-07-04 16:19:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-04 16:19:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:19:50 --> Input Class Initialized
INFO - 2019-07-04 16:19:50 --> Input Class Initialized
INFO - 2019-07-04 16:19:50 --> Language Class Initialized
INFO - 2019-07-04 16:19:50 --> Language Class Initialized
INFO - 2019-07-04 16:19:50 --> Language Class Initialized
INFO - 2019-07-04 16:19:50 --> Language Class Initialized
INFO - 2019-07-04 16:19:50 --> Config Class Initialized
INFO - 2019-07-04 16:19:50 --> Loader Class Initialized
INFO - 2019-07-04 16:19:50 --> Config Class Initialized
INFO - 2019-07-04 16:19:50 --> Loader Class Initialized
DEBUG - 2019-07-04 16:19:50 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-04 16:19:50 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:19:50 --> Helper loaded: url_helper
INFO - 2019-07-04 16:19:50 --> Helper loaded: url_helper
INFO - 2019-07-04 16:19:50 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:19:50 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:19:50 --> Helper loaded: string_helper
INFO - 2019-07-04 16:19:50 --> Helper loaded: string_helper
INFO - 2019-07-04 16:19:50 --> Helper loaded: array_helper
INFO - 2019-07-04 16:19:50 --> Helper loaded: array_helper
INFO - 2019-07-04 16:19:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:19:50 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:19:50 --> Database Driver Class Initialized
INFO - 2019-07-04 16:19:50 --> Controller Class Initialized
INFO - 2019-07-04 22:19:50 --> Helper loaded: language_helper
INFO - 2019-07-04 22:19:50 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:19:50 --> Model Class Initialized
INFO - 2019-07-04 22:19:50 --> Model Class Initialized
INFO - 2019-07-04 22:19:50 --> Model Class Initialized
INFO - 2019-07-04 22:19:50 --> Model Class Initialized
INFO - 2019-07-04 22:19:50 --> Helper loaded: form_helper
INFO - 2019-07-04 22:19:50 --> Form Validation Class Initialized
DEBUG - 2019-07-04 22:19:50 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 22:19:50 --> Model Class Initialized
INFO - 2019-07-04 22:19:50 --> Model Class Initialized
INFO - 2019-07-04 22:19:50 --> Final output sent to browser
DEBUG - 2019-07-04 22:19:50 --> Total execution time: 0.6011
INFO - 2019-07-04 16:19:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:19:50 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:19:50 --> Database Driver Class Initialized
INFO - 2019-07-04 16:19:50 --> Controller Class Initialized
INFO - 2019-07-04 22:19:50 --> Helper loaded: language_helper
INFO - 2019-07-04 22:19:50 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:19:50 --> Model Class Initialized
INFO - 2019-07-04 22:19:50 --> Model Class Initialized
INFO - 2019-07-04 22:19:50 --> Model Class Initialized
INFO - 2019-07-04 22:19:50 --> Model Class Initialized
INFO - 2019-07-04 22:19:50 --> Model Class Initialized
INFO - 2019-07-04 22:19:50 --> Final output sent to browser
DEBUG - 2019-07-04 22:19:50 --> Total execution time: 0.7735
INFO - 2019-07-04 16:19:56 --> Config Class Initialized
INFO - 2019-07-04 16:19:56 --> Config Class Initialized
INFO - 2019-07-04 16:19:56 --> Hooks Class Initialized
INFO - 2019-07-04 16:19:56 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:19:56 --> UTF-8 Support Enabled
DEBUG - 2019-07-04 16:19:56 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:19:56 --> Utf8 Class Initialized
INFO - 2019-07-04 16:19:56 --> Utf8 Class Initialized
INFO - 2019-07-04 16:19:56 --> URI Class Initialized
INFO - 2019-07-04 16:19:56 --> URI Class Initialized
INFO - 2019-07-04 16:19:56 --> Router Class Initialized
INFO - 2019-07-04 16:19:56 --> Router Class Initialized
INFO - 2019-07-04 16:19:56 --> Output Class Initialized
INFO - 2019-07-04 16:19:56 --> Output Class Initialized
INFO - 2019-07-04 16:19:56 --> Security Class Initialized
INFO - 2019-07-04 16:19:56 --> Security Class Initialized
DEBUG - 2019-07-04 16:19:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-04 16:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:19:56 --> Input Class Initialized
INFO - 2019-07-04 16:19:56 --> Input Class Initialized
INFO - 2019-07-04 16:19:56 --> Language Class Initialized
INFO - 2019-07-04 16:19:56 --> Language Class Initialized
INFO - 2019-07-04 16:19:56 --> Language Class Initialized
INFO - 2019-07-04 16:19:56 --> Language Class Initialized
INFO - 2019-07-04 16:19:56 --> Config Class Initialized
INFO - 2019-07-04 16:19:56 --> Config Class Initialized
INFO - 2019-07-04 16:19:56 --> Loader Class Initialized
INFO - 2019-07-04 16:19:56 --> Loader Class Initialized
DEBUG - 2019-07-04 16:19:56 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-04 16:19:56 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:19:56 --> Helper loaded: url_helper
INFO - 2019-07-04 16:19:56 --> Helper loaded: url_helper
INFO - 2019-07-04 16:19:56 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:19:56 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:19:56 --> Helper loaded: string_helper
INFO - 2019-07-04 16:19:56 --> Helper loaded: string_helper
INFO - 2019-07-04 16:19:56 --> Helper loaded: array_helper
INFO - 2019-07-04 16:19:56 --> Helper loaded: array_helper
INFO - 2019-07-04 16:19:56 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:19:56 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:19:56 --> Database Driver Class Initialized
INFO - 2019-07-04 16:19:56 --> Controller Class Initialized
INFO - 2019-07-04 22:19:56 --> Helper loaded: language_helper
INFO - 2019-07-04 22:19:56 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:19:56 --> Model Class Initialized
INFO - 2019-07-04 22:19:56 --> Model Class Initialized
INFO - 2019-07-04 22:19:56 --> Model Class Initialized
INFO - 2019-07-04 22:19:56 --> Model Class Initialized
INFO - 2019-07-04 22:19:56 --> Model Class Initialized
INFO - 2019-07-04 22:19:56 --> Final output sent to browser
DEBUG - 2019-07-04 22:19:56 --> Total execution time: 0.5971
INFO - 2019-07-04 16:19:56 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:19:56 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:19:56 --> Database Driver Class Initialized
INFO - 2019-07-04 16:19:56 --> Controller Class Initialized
INFO - 2019-07-04 22:19:56 --> Helper loaded: language_helper
INFO - 2019-07-04 22:19:56 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:19:56 --> Model Class Initialized
INFO - 2019-07-04 22:19:56 --> Model Class Initialized
INFO - 2019-07-04 22:19:56 --> Model Class Initialized
INFO - 2019-07-04 22:19:57 --> Model Class Initialized
INFO - 2019-07-04 22:19:57 --> Helper loaded: form_helper
INFO - 2019-07-04 22:19:57 --> Form Validation Class Initialized
DEBUG - 2019-07-04 22:19:57 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 22:19:57 --> Model Class Initialized
INFO - 2019-07-04 22:19:57 --> Model Class Initialized
INFO - 2019-07-04 22:19:57 --> Final output sent to browser
DEBUG - 2019-07-04 22:19:57 --> Total execution time: 0.8045
INFO - 2019-07-04 16:20:05 --> Config Class Initialized
INFO - 2019-07-04 16:20:05 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:20:05 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:20:05 --> Utf8 Class Initialized
INFO - 2019-07-04 16:20:05 --> URI Class Initialized
INFO - 2019-07-04 16:20:05 --> Router Class Initialized
INFO - 2019-07-04 16:20:05 --> Output Class Initialized
INFO - 2019-07-04 16:20:05 --> Security Class Initialized
DEBUG - 2019-07-04 16:20:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:20:05 --> Input Class Initialized
INFO - 2019-07-04 16:20:05 --> Language Class Initialized
INFO - 2019-07-04 16:20:05 --> Language Class Initialized
INFO - 2019-07-04 16:20:05 --> Config Class Initialized
INFO - 2019-07-04 16:20:05 --> Loader Class Initialized
DEBUG - 2019-07-04 16:20:05 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:20:05 --> Helper loaded: url_helper
INFO - 2019-07-04 16:20:05 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:20:05 --> Helper loaded: string_helper
INFO - 2019-07-04 16:20:05 --> Helper loaded: array_helper
INFO - 2019-07-04 16:20:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:20:05 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:20:05 --> Database Driver Class Initialized
INFO - 2019-07-04 16:20:05 --> Controller Class Initialized
INFO - 2019-07-04 22:20:05 --> Helper loaded: language_helper
INFO - 2019-07-04 22:20:05 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:20:05 --> Model Class Initialized
INFO - 2019-07-04 22:20:05 --> Model Class Initialized
INFO - 2019-07-04 22:20:05 --> Model Class Initialized
INFO - 2019-07-04 22:20:05 --> Model Class Initialized
INFO - 2019-07-04 22:20:05 --> Final output sent to browser
DEBUG - 2019-07-04 22:20:05 --> Total execution time: 0.3855
INFO - 2019-07-04 16:20:06 --> Config Class Initialized
INFO - 2019-07-04 16:20:06 --> Config Class Initialized
INFO - 2019-07-04 16:20:06 --> Hooks Class Initialized
INFO - 2019-07-04 16:20:06 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:20:06 --> UTF-8 Support Enabled
DEBUG - 2019-07-04 16:20:06 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:20:06 --> Utf8 Class Initialized
INFO - 2019-07-04 16:20:06 --> Utf8 Class Initialized
INFO - 2019-07-04 16:20:06 --> URI Class Initialized
INFO - 2019-07-04 16:20:06 --> URI Class Initialized
INFO - 2019-07-04 16:20:06 --> Router Class Initialized
INFO - 2019-07-04 16:20:06 --> Router Class Initialized
INFO - 2019-07-04 16:20:06 --> Output Class Initialized
INFO - 2019-07-04 16:20:06 --> Output Class Initialized
INFO - 2019-07-04 16:20:06 --> Security Class Initialized
INFO - 2019-07-04 16:20:06 --> Security Class Initialized
DEBUG - 2019-07-04 16:20:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-04 16:20:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:20:06 --> Input Class Initialized
INFO - 2019-07-04 16:20:06 --> Input Class Initialized
INFO - 2019-07-04 16:20:06 --> Language Class Initialized
INFO - 2019-07-04 16:20:06 --> Language Class Initialized
INFO - 2019-07-04 16:20:06 --> Language Class Initialized
INFO - 2019-07-04 16:20:06 --> Config Class Initialized
INFO - 2019-07-04 16:20:06 --> Language Class Initialized
INFO - 2019-07-04 16:20:06 --> Loader Class Initialized
INFO - 2019-07-04 16:20:06 --> Config Class Initialized
INFO - 2019-07-04 16:20:06 --> Loader Class Initialized
DEBUG - 2019-07-04 16:20:06 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-04 16:20:06 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:20:06 --> Helper loaded: url_helper
INFO - 2019-07-04 16:20:06 --> Helper loaded: url_helper
INFO - 2019-07-04 16:20:06 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:20:06 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:20:06 --> Helper loaded: string_helper
INFO - 2019-07-04 16:20:06 --> Helper loaded: string_helper
INFO - 2019-07-04 16:20:06 --> Helper loaded: array_helper
INFO - 2019-07-04 16:20:06 --> Helper loaded: array_helper
INFO - 2019-07-04 16:20:06 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:20:06 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:20:06 --> Database Driver Class Initialized
INFO - 2019-07-04 16:20:06 --> Controller Class Initialized
INFO - 2019-07-04 22:20:06 --> Helper loaded: language_helper
INFO - 2019-07-04 22:20:06 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:20:06 --> Model Class Initialized
INFO - 2019-07-04 22:20:06 --> Model Class Initialized
INFO - 2019-07-04 22:20:06 --> Model Class Initialized
INFO - 2019-07-04 22:20:06 --> Model Class Initialized
INFO - 2019-07-04 22:20:06 --> Final output sent to browser
DEBUG - 2019-07-04 22:20:06 --> Total execution time: 0.4548
INFO - 2019-07-04 16:20:06 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:20:06 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:20:06 --> Database Driver Class Initialized
INFO - 2019-07-04 16:20:06 --> Controller Class Initialized
INFO - 2019-07-04 22:20:06 --> Helper loaded: language_helper
INFO - 2019-07-04 22:20:06 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:20:06 --> Model Class Initialized
INFO - 2019-07-04 22:20:06 --> Model Class Initialized
INFO - 2019-07-04 22:20:06 --> Model Class Initialized
INFO - 2019-07-04 22:20:06 --> Model Class Initialized
INFO - 2019-07-04 22:20:06 --> Model Class Initialized
INFO - 2019-07-04 22:20:06 --> Final output sent to browser
DEBUG - 2019-07-04 22:20:06 --> Total execution time: 0.6018
INFO - 2019-07-04 16:20:12 --> Config Class Initialized
INFO - 2019-07-04 16:20:12 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:20:12 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:20:12 --> Utf8 Class Initialized
INFO - 2019-07-04 16:20:12 --> URI Class Initialized
INFO - 2019-07-04 16:20:12 --> Router Class Initialized
INFO - 2019-07-04 16:20:12 --> Output Class Initialized
INFO - 2019-07-04 16:20:13 --> Security Class Initialized
DEBUG - 2019-07-04 16:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:20:13 --> Input Class Initialized
INFO - 2019-07-04 16:20:13 --> Language Class Initialized
INFO - 2019-07-04 16:20:13 --> Language Class Initialized
INFO - 2019-07-04 16:20:13 --> Config Class Initialized
INFO - 2019-07-04 16:20:13 --> Loader Class Initialized
DEBUG - 2019-07-04 16:20:13 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:20:13 --> Helper loaded: url_helper
INFO - 2019-07-04 16:20:13 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:20:13 --> Helper loaded: string_helper
INFO - 2019-07-04 16:20:13 --> Helper loaded: array_helper
INFO - 2019-07-04 16:20:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:20:13 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:20:13 --> Database Driver Class Initialized
INFO - 2019-07-04 16:20:13 --> Controller Class Initialized
INFO - 2019-07-04 22:20:13 --> Helper loaded: language_helper
INFO - 2019-07-04 22:20:13 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:20:13 --> Model Class Initialized
INFO - 2019-07-04 22:20:13 --> Model Class Initialized
INFO - 2019-07-04 22:20:13 --> Model Class Initialized
INFO - 2019-07-04 22:20:13 --> Model Class Initialized
INFO - 2019-07-04 22:20:13 --> Model Class Initialized
INFO - 2019-07-04 22:20:13 --> Final output sent to browser
DEBUG - 2019-07-04 22:20:13 --> Total execution time: 0.3456
INFO - 2019-07-04 16:20:13 --> Config Class Initialized
INFO - 2019-07-04 16:20:13 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:20:13 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:20:13 --> Utf8 Class Initialized
INFO - 2019-07-04 16:20:13 --> URI Class Initialized
INFO - 2019-07-04 16:20:13 --> Router Class Initialized
INFO - 2019-07-04 16:20:13 --> Output Class Initialized
INFO - 2019-07-04 16:20:13 --> Security Class Initialized
DEBUG - 2019-07-04 16:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:20:13 --> Input Class Initialized
INFO - 2019-07-04 16:20:13 --> Language Class Initialized
INFO - 2019-07-04 16:20:13 --> Language Class Initialized
INFO - 2019-07-04 16:20:13 --> Config Class Initialized
INFO - 2019-07-04 16:20:13 --> Loader Class Initialized
DEBUG - 2019-07-04 16:20:13 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:20:13 --> Helper loaded: url_helper
INFO - 2019-07-04 16:20:13 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:20:13 --> Helper loaded: string_helper
INFO - 2019-07-04 16:20:13 --> Helper loaded: array_helper
INFO - 2019-07-04 16:20:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:20:13 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:20:13 --> Database Driver Class Initialized
INFO - 2019-07-04 16:20:13 --> Controller Class Initialized
INFO - 2019-07-04 22:20:13 --> Helper loaded: language_helper
INFO - 2019-07-04 22:20:13 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:20:13 --> Model Class Initialized
INFO - 2019-07-04 22:20:13 --> Model Class Initialized
INFO - 2019-07-04 22:20:13 --> Model Class Initialized
INFO - 2019-07-04 22:20:13 --> Model Class Initialized
INFO - 2019-07-04 22:20:13 --> Helper loaded: form_helper
INFO - 2019-07-04 22:20:13 --> Form Validation Class Initialized
DEBUG - 2019-07-04 22:20:13 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 22:20:13 --> Model Class Initialized
INFO - 2019-07-04 22:20:13 --> Model Class Initialized
INFO - 2019-07-04 22:20:13 --> Final output sent to browser
DEBUG - 2019-07-04 22:20:13 --> Total execution time: 0.3972
INFO - 2019-07-04 16:20:14 --> Config Class Initialized
INFO - 2019-07-04 16:20:14 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:20:14 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:20:14 --> Utf8 Class Initialized
INFO - 2019-07-04 16:20:14 --> URI Class Initialized
INFO - 2019-07-04 16:20:14 --> Router Class Initialized
INFO - 2019-07-04 16:20:14 --> Output Class Initialized
INFO - 2019-07-04 16:20:14 --> Security Class Initialized
DEBUG - 2019-07-04 16:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:20:14 --> Input Class Initialized
INFO - 2019-07-04 16:20:14 --> Language Class Initialized
INFO - 2019-07-04 16:20:14 --> Language Class Initialized
INFO - 2019-07-04 16:20:14 --> Config Class Initialized
INFO - 2019-07-04 16:20:14 --> Loader Class Initialized
DEBUG - 2019-07-04 16:20:14 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:20:14 --> Helper loaded: url_helper
INFO - 2019-07-04 16:20:14 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:20:14 --> Helper loaded: string_helper
INFO - 2019-07-04 16:20:14 --> Helper loaded: array_helper
INFO - 2019-07-04 16:20:14 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:20:14 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:20:14 --> Database Driver Class Initialized
INFO - 2019-07-04 16:20:14 --> Controller Class Initialized
INFO - 2019-07-04 22:20:14 --> Helper loaded: language_helper
INFO - 2019-07-04 22:20:14 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:20:14 --> Model Class Initialized
INFO - 2019-07-04 22:20:14 --> Model Class Initialized
INFO - 2019-07-04 22:20:14 --> Model Class Initialized
INFO - 2019-07-04 22:20:14 --> Model Class Initialized
INFO - 2019-07-04 22:20:14 --> Helper loaded: form_helper
INFO - 2019-07-04 22:20:14 --> Form Validation Class Initialized
DEBUG - 2019-07-04 22:20:14 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 22:20:14 --> Model Class Initialized
INFO - 2019-07-04 22:20:14 --> Model Class Initialized
INFO - 2019-07-04 22:20:14 --> Final output sent to browser
DEBUG - 2019-07-04 22:20:14 --> Total execution time: 0.4071
INFO - 2019-07-04 16:21:53 --> Config Class Initialized
INFO - 2019-07-04 16:21:53 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:21:53 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:21:53 --> Utf8 Class Initialized
INFO - 2019-07-04 16:21:53 --> URI Class Initialized
INFO - 2019-07-04 16:21:53 --> Router Class Initialized
INFO - 2019-07-04 16:21:53 --> Output Class Initialized
INFO - 2019-07-04 16:21:53 --> Security Class Initialized
DEBUG - 2019-07-04 16:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:21:53 --> Input Class Initialized
INFO - 2019-07-04 16:21:53 --> Language Class Initialized
INFO - 2019-07-04 16:21:53 --> Language Class Initialized
INFO - 2019-07-04 16:21:53 --> Config Class Initialized
INFO - 2019-07-04 16:21:53 --> Loader Class Initialized
DEBUG - 2019-07-04 16:21:53 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:21:53 --> Helper loaded: url_helper
INFO - 2019-07-04 16:21:53 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:21:53 --> Helper loaded: string_helper
INFO - 2019-07-04 16:21:53 --> Helper loaded: array_helper
INFO - 2019-07-04 16:21:53 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:21:53 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:21:53 --> Database Driver Class Initialized
INFO - 2019-07-04 16:21:53 --> Controller Class Initialized
INFO - 2019-07-04 22:21:53 --> Helper loaded: language_helper
INFO - 2019-07-04 22:21:53 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:21:53 --> Model Class Initialized
INFO - 2019-07-04 22:21:53 --> Model Class Initialized
INFO - 2019-07-04 22:21:53 --> Model Class Initialized
INFO - 2019-07-04 22:21:53 --> Model Class Initialized
INFO - 2019-07-04 22:21:53 --> Model Class Initialized
INFO - 2019-07-04 22:21:53 --> Final output sent to browser
DEBUG - 2019-07-04 22:21:53 --> Total execution time: 0.3781
INFO - 2019-07-04 16:25:41 --> Config Class Initialized
INFO - 2019-07-04 16:25:41 --> Config Class Initialized
INFO - 2019-07-04 16:25:41 --> Hooks Class Initialized
INFO - 2019-07-04 16:25:41 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:25:41 --> UTF-8 Support Enabled
DEBUG - 2019-07-04 16:25:41 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:25:41 --> Utf8 Class Initialized
INFO - 2019-07-04 16:25:41 --> Utf8 Class Initialized
INFO - 2019-07-04 16:25:41 --> URI Class Initialized
INFO - 2019-07-04 16:25:41 --> URI Class Initialized
INFO - 2019-07-04 16:25:41 --> Router Class Initialized
INFO - 2019-07-04 16:25:41 --> Router Class Initialized
INFO - 2019-07-04 16:25:41 --> Output Class Initialized
INFO - 2019-07-04 16:25:41 --> Output Class Initialized
INFO - 2019-07-04 16:25:41 --> Security Class Initialized
INFO - 2019-07-04 16:25:41 --> Security Class Initialized
DEBUG - 2019-07-04 16:25:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-04 16:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:25:41 --> Input Class Initialized
INFO - 2019-07-04 16:25:41 --> Input Class Initialized
INFO - 2019-07-04 16:25:41 --> Language Class Initialized
INFO - 2019-07-04 16:25:41 --> Language Class Initialized
INFO - 2019-07-04 16:25:41 --> Language Class Initialized
INFO - 2019-07-04 16:25:41 --> Language Class Initialized
INFO - 2019-07-04 16:25:41 --> Config Class Initialized
INFO - 2019-07-04 16:25:41 --> Config Class Initialized
INFO - 2019-07-04 16:25:41 --> Loader Class Initialized
INFO - 2019-07-04 16:25:41 --> Loader Class Initialized
DEBUG - 2019-07-04 16:25:41 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-04 16:25:41 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:25:41 --> Helper loaded: url_helper
INFO - 2019-07-04 16:25:41 --> Helper loaded: url_helper
INFO - 2019-07-04 16:25:41 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:25:41 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:25:41 --> Helper loaded: string_helper
INFO - 2019-07-04 16:25:41 --> Helper loaded: string_helper
INFO - 2019-07-04 16:25:41 --> Helper loaded: array_helper
INFO - 2019-07-04 16:25:41 --> Helper loaded: array_helper
INFO - 2019-07-04 16:25:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:25:41 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:25:41 --> Database Driver Class Initialized
INFO - 2019-07-04 16:25:41 --> Controller Class Initialized
INFO - 2019-07-04 22:25:41 --> Helper loaded: language_helper
INFO - 2019-07-04 22:25:41 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:25:41 --> Model Class Initialized
INFO - 2019-07-04 22:25:41 --> Model Class Initialized
INFO - 2019-07-04 22:25:41 --> Model Class Initialized
INFO - 2019-07-04 22:25:41 --> Model Class Initialized
INFO - 2019-07-04 22:25:41 --> Model Class Initialized
INFO - 2019-07-04 22:25:41 --> Final output sent to browser
DEBUG - 2019-07-04 22:25:41 --> Total execution time: 0.5435
INFO - 2019-07-04 16:25:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:25:41 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:25:41 --> Database Driver Class Initialized
INFO - 2019-07-04 16:25:41 --> Controller Class Initialized
INFO - 2019-07-04 22:25:41 --> Helper loaded: language_helper
INFO - 2019-07-04 22:25:41 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:25:41 --> Model Class Initialized
INFO - 2019-07-04 22:25:41 --> Model Class Initialized
INFO - 2019-07-04 22:25:41 --> Model Class Initialized
INFO - 2019-07-04 22:25:41 --> Model Class Initialized
INFO - 2019-07-04 22:25:42 --> Helper loaded: form_helper
INFO - 2019-07-04 22:25:42 --> Form Validation Class Initialized
DEBUG - 2019-07-04 22:25:42 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 22:25:42 --> Model Class Initialized
INFO - 2019-07-04 22:25:42 --> Model Class Initialized
INFO - 2019-07-04 22:25:42 --> Final output sent to browser
DEBUG - 2019-07-04 22:25:42 --> Total execution time: 0.7446
INFO - 2019-07-04 16:25:43 --> Config Class Initialized
INFO - 2019-07-04 16:25:43 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:25:43 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:25:43 --> Utf8 Class Initialized
INFO - 2019-07-04 16:25:43 --> URI Class Initialized
INFO - 2019-07-04 16:25:43 --> Router Class Initialized
INFO - 2019-07-04 16:25:43 --> Output Class Initialized
INFO - 2019-07-04 16:25:43 --> Security Class Initialized
DEBUG - 2019-07-04 16:25:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:25:43 --> Input Class Initialized
INFO - 2019-07-04 16:25:43 --> Language Class Initialized
INFO - 2019-07-04 16:25:43 --> Language Class Initialized
INFO - 2019-07-04 16:25:43 --> Config Class Initialized
INFO - 2019-07-04 16:25:43 --> Loader Class Initialized
DEBUG - 2019-07-04 16:25:43 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:25:43 --> Helper loaded: url_helper
INFO - 2019-07-04 16:25:43 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:25:43 --> Helper loaded: string_helper
INFO - 2019-07-04 16:25:43 --> Helper loaded: array_helper
INFO - 2019-07-04 16:25:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:25:43 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:25:43 --> Database Driver Class Initialized
INFO - 2019-07-04 16:25:43 --> Controller Class Initialized
INFO - 2019-07-04 22:25:43 --> Helper loaded: language_helper
INFO - 2019-07-04 22:25:43 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:25:43 --> Model Class Initialized
INFO - 2019-07-04 22:25:43 --> Model Class Initialized
INFO - 2019-07-04 22:25:43 --> Model Class Initialized
INFO - 2019-07-04 22:25:43 --> Model Class Initialized
INFO - 2019-07-04 22:25:43 --> Model Class Initialized
INFO - 2019-07-04 22:25:43 --> Final output sent to browser
DEBUG - 2019-07-04 22:25:43 --> Total execution time: 0.3466
INFO - 2019-07-04 16:25:43 --> Config Class Initialized
INFO - 2019-07-04 16:25:43 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:25:43 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:25:43 --> Utf8 Class Initialized
INFO - 2019-07-04 16:25:43 --> URI Class Initialized
INFO - 2019-07-04 16:25:43 --> Router Class Initialized
INFO - 2019-07-04 16:25:43 --> Output Class Initialized
INFO - 2019-07-04 16:25:43 --> Security Class Initialized
DEBUG - 2019-07-04 16:25:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:25:43 --> Input Class Initialized
INFO - 2019-07-04 16:25:43 --> Language Class Initialized
INFO - 2019-07-04 16:25:43 --> Language Class Initialized
INFO - 2019-07-04 16:25:43 --> Config Class Initialized
INFO - 2019-07-04 16:25:43 --> Loader Class Initialized
DEBUG - 2019-07-04 16:25:43 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:25:43 --> Helper loaded: url_helper
INFO - 2019-07-04 16:25:43 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:25:43 --> Helper loaded: string_helper
INFO - 2019-07-04 16:25:43 --> Helper loaded: array_helper
INFO - 2019-07-04 16:25:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:25:43 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:25:43 --> Database Driver Class Initialized
INFO - 2019-07-04 16:25:43 --> Controller Class Initialized
INFO - 2019-07-04 22:25:43 --> Helper loaded: language_helper
INFO - 2019-07-04 22:25:43 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:25:43 --> Model Class Initialized
INFO - 2019-07-04 22:25:43 --> Model Class Initialized
INFO - 2019-07-04 22:25:43 --> Model Class Initialized
INFO - 2019-07-04 22:25:43 --> Model Class Initialized
INFO - 2019-07-04 22:25:43 --> Helper loaded: form_helper
INFO - 2019-07-04 22:25:43 --> Form Validation Class Initialized
DEBUG - 2019-07-04 22:25:43 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 22:25:43 --> Model Class Initialized
INFO - 2019-07-04 22:25:43 --> Model Class Initialized
INFO - 2019-07-04 22:25:43 --> Final output sent to browser
DEBUG - 2019-07-04 22:25:43 --> Total execution time: 0.4046
INFO - 2019-07-04 16:26:29 --> Config Class Initialized
INFO - 2019-07-04 16:26:29 --> Config Class Initialized
INFO - 2019-07-04 16:26:29 --> Hooks Class Initialized
INFO - 2019-07-04 16:26:29 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:26:29 --> UTF-8 Support Enabled
DEBUG - 2019-07-04 16:26:29 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:26:29 --> Utf8 Class Initialized
INFO - 2019-07-04 16:26:29 --> Utf8 Class Initialized
INFO - 2019-07-04 16:26:29 --> URI Class Initialized
INFO - 2019-07-04 16:26:29 --> URI Class Initialized
INFO - 2019-07-04 16:26:29 --> Router Class Initialized
INFO - 2019-07-04 16:26:29 --> Router Class Initialized
INFO - 2019-07-04 16:26:29 --> Output Class Initialized
INFO - 2019-07-04 16:26:29 --> Output Class Initialized
INFO - 2019-07-04 16:26:29 --> Security Class Initialized
INFO - 2019-07-04 16:26:29 --> Security Class Initialized
DEBUG - 2019-07-04 16:26:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-04 16:26:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:26:29 --> Input Class Initialized
INFO - 2019-07-04 16:26:29 --> Input Class Initialized
INFO - 2019-07-04 16:26:29 --> Language Class Initialized
INFO - 2019-07-04 16:26:29 --> Language Class Initialized
INFO - 2019-07-04 16:26:29 --> Language Class Initialized
INFO - 2019-07-04 16:26:29 --> Language Class Initialized
INFO - 2019-07-04 16:26:29 --> Config Class Initialized
INFO - 2019-07-04 16:26:29 --> Loader Class Initialized
INFO - 2019-07-04 16:26:29 --> Config Class Initialized
INFO - 2019-07-04 16:26:29 --> Loader Class Initialized
DEBUG - 2019-07-04 16:26:29 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-04 16:26:29 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:26:29 --> Helper loaded: url_helper
INFO - 2019-07-04 16:26:29 --> Helper loaded: url_helper
INFO - 2019-07-04 16:26:29 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:26:29 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:26:29 --> Helper loaded: string_helper
INFO - 2019-07-04 16:26:29 --> Helper loaded: string_helper
INFO - 2019-07-04 16:26:30 --> Helper loaded: array_helper
INFO - 2019-07-04 16:26:30 --> Helper loaded: array_helper
INFO - 2019-07-04 16:26:30 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:26:30 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:26:30 --> Database Driver Class Initialized
INFO - 2019-07-04 16:26:30 --> Controller Class Initialized
INFO - 2019-07-04 22:26:30 --> Helper loaded: language_helper
INFO - 2019-07-04 22:26:30 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:26:30 --> Model Class Initialized
INFO - 2019-07-04 22:26:30 --> Model Class Initialized
INFO - 2019-07-04 22:26:30 --> Model Class Initialized
INFO - 2019-07-04 22:26:30 --> Model Class Initialized
INFO - 2019-07-04 22:26:30 --> Helper loaded: form_helper
INFO - 2019-07-04 22:26:30 --> Form Validation Class Initialized
DEBUG - 2019-07-04 22:26:30 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 22:26:30 --> Model Class Initialized
INFO - 2019-07-04 22:26:30 --> Model Class Initialized
INFO - 2019-07-04 22:26:30 --> Final output sent to browser
DEBUG - 2019-07-04 22:26:30 --> Total execution time: 0.6892
INFO - 2019-07-04 16:26:30 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:26:30 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:26:30 --> Database Driver Class Initialized
INFO - 2019-07-04 16:26:30 --> Controller Class Initialized
INFO - 2019-07-04 22:26:30 --> Helper loaded: language_helper
INFO - 2019-07-04 22:26:30 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:26:30 --> Model Class Initialized
INFO - 2019-07-04 22:26:30 --> Model Class Initialized
INFO - 2019-07-04 22:26:30 --> Model Class Initialized
INFO - 2019-07-04 22:26:30 --> Model Class Initialized
INFO - 2019-07-04 22:26:30 --> Model Class Initialized
INFO - 2019-07-04 22:26:30 --> Final output sent to browser
DEBUG - 2019-07-04 22:26:30 --> Total execution time: 0.8636
INFO - 2019-07-04 16:26:31 --> Config Class Initialized
INFO - 2019-07-04 16:26:31 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:26:31 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:26:31 --> Utf8 Class Initialized
INFO - 2019-07-04 16:26:31 --> URI Class Initialized
INFO - 2019-07-04 16:26:31 --> Router Class Initialized
INFO - 2019-07-04 16:26:31 --> Output Class Initialized
INFO - 2019-07-04 16:26:31 --> Security Class Initialized
DEBUG - 2019-07-04 16:26:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:26:31 --> Input Class Initialized
INFO - 2019-07-04 16:26:31 --> Language Class Initialized
INFO - 2019-07-04 16:26:31 --> Language Class Initialized
INFO - 2019-07-04 16:26:31 --> Config Class Initialized
INFO - 2019-07-04 16:26:31 --> Loader Class Initialized
DEBUG - 2019-07-04 16:26:31 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:26:31 --> Helper loaded: url_helper
INFO - 2019-07-04 16:26:31 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:26:31 --> Helper loaded: string_helper
INFO - 2019-07-04 16:26:31 --> Helper loaded: array_helper
INFO - 2019-07-04 16:26:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:26:31 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:26:31 --> Database Driver Class Initialized
INFO - 2019-07-04 16:26:31 --> Controller Class Initialized
INFO - 2019-07-04 22:26:31 --> Helper loaded: language_helper
INFO - 2019-07-04 22:26:31 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:26:31 --> Model Class Initialized
INFO - 2019-07-04 22:26:31 --> Model Class Initialized
INFO - 2019-07-04 22:26:31 --> Model Class Initialized
INFO - 2019-07-04 22:26:31 --> Model Class Initialized
INFO - 2019-07-04 22:26:31 --> Model Class Initialized
INFO - 2019-07-04 22:26:31 --> Final output sent to browser
DEBUG - 2019-07-04 22:26:31 --> Total execution time: 0.3610
INFO - 2019-07-04 16:26:31 --> Config Class Initialized
INFO - 2019-07-04 16:26:31 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:26:31 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:26:31 --> Utf8 Class Initialized
INFO - 2019-07-04 16:26:31 --> URI Class Initialized
INFO - 2019-07-04 16:26:31 --> Router Class Initialized
INFO - 2019-07-04 16:26:31 --> Output Class Initialized
INFO - 2019-07-04 16:26:31 --> Security Class Initialized
DEBUG - 2019-07-04 16:26:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:26:31 --> Input Class Initialized
INFO - 2019-07-04 16:26:31 --> Language Class Initialized
INFO - 2019-07-04 16:26:31 --> Language Class Initialized
INFO - 2019-07-04 16:26:31 --> Config Class Initialized
INFO - 2019-07-04 16:26:31 --> Loader Class Initialized
DEBUG - 2019-07-04 16:26:31 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:26:31 --> Helper loaded: url_helper
INFO - 2019-07-04 16:26:31 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:26:31 --> Helper loaded: string_helper
INFO - 2019-07-04 16:26:31 --> Helper loaded: array_helper
INFO - 2019-07-04 16:26:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:26:31 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:26:31 --> Database Driver Class Initialized
INFO - 2019-07-04 16:26:31 --> Controller Class Initialized
INFO - 2019-07-04 22:26:31 --> Helper loaded: language_helper
INFO - 2019-07-04 22:26:31 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:26:31 --> Model Class Initialized
INFO - 2019-07-04 22:26:31 --> Model Class Initialized
INFO - 2019-07-04 22:26:31 --> Model Class Initialized
INFO - 2019-07-04 22:26:31 --> Model Class Initialized
INFO - 2019-07-04 22:26:31 --> Helper loaded: form_helper
INFO - 2019-07-04 22:26:31 --> Form Validation Class Initialized
DEBUG - 2019-07-04 22:26:31 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 22:26:31 --> Model Class Initialized
INFO - 2019-07-04 22:26:31 --> Model Class Initialized
INFO - 2019-07-04 22:26:31 --> Final output sent to browser
DEBUG - 2019-07-04 22:26:31 --> Total execution time: 0.4190
INFO - 2019-07-04 16:26:41 --> Config Class Initialized
INFO - 2019-07-04 16:26:41 --> Hooks Class Initialized
INFO - 2019-07-04 16:26:41 --> Config Class Initialized
INFO - 2019-07-04 16:26:41 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:26:41 --> UTF-8 Support Enabled
DEBUG - 2019-07-04 16:26:41 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:26:41 --> Utf8 Class Initialized
INFO - 2019-07-04 16:26:41 --> Utf8 Class Initialized
INFO - 2019-07-04 16:26:41 --> URI Class Initialized
INFO - 2019-07-04 16:26:41 --> URI Class Initialized
INFO - 2019-07-04 16:26:41 --> Router Class Initialized
INFO - 2019-07-04 16:26:41 --> Router Class Initialized
INFO - 2019-07-04 16:26:41 --> Output Class Initialized
INFO - 2019-07-04 16:26:41 --> Output Class Initialized
INFO - 2019-07-04 16:26:41 --> Security Class Initialized
INFO - 2019-07-04 16:26:41 --> Security Class Initialized
DEBUG - 2019-07-04 16:26:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-04 16:26:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:26:41 --> Input Class Initialized
INFO - 2019-07-04 16:26:41 --> Input Class Initialized
INFO - 2019-07-04 16:26:41 --> Language Class Initialized
INFO - 2019-07-04 16:26:41 --> Language Class Initialized
INFO - 2019-07-04 16:26:41 --> Language Class Initialized
INFO - 2019-07-04 16:26:41 --> Language Class Initialized
INFO - 2019-07-04 16:26:41 --> Config Class Initialized
INFO - 2019-07-04 16:26:41 --> Loader Class Initialized
INFO - 2019-07-04 16:26:41 --> Config Class Initialized
INFO - 2019-07-04 16:26:41 --> Loader Class Initialized
DEBUG - 2019-07-04 16:26:41 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-04 16:26:41 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:26:41 --> Helper loaded: url_helper
INFO - 2019-07-04 16:26:41 --> Helper loaded: url_helper
INFO - 2019-07-04 16:26:41 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:26:42 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:26:42 --> Helper loaded: string_helper
INFO - 2019-07-04 16:26:42 --> Helper loaded: string_helper
INFO - 2019-07-04 16:26:42 --> Helper loaded: array_helper
INFO - 2019-07-04 16:26:42 --> Helper loaded: array_helper
INFO - 2019-07-04 16:26:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:26:42 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:26:42 --> Database Driver Class Initialized
INFO - 2019-07-04 16:26:42 --> Controller Class Initialized
INFO - 2019-07-04 22:26:42 --> Helper loaded: language_helper
INFO - 2019-07-04 22:26:42 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:26:42 --> Model Class Initialized
INFO - 2019-07-04 22:26:42 --> Model Class Initialized
INFO - 2019-07-04 22:26:42 --> Model Class Initialized
INFO - 2019-07-04 22:26:42 --> Model Class Initialized
INFO - 2019-07-04 22:26:42 --> Model Class Initialized
INFO - 2019-07-04 22:26:42 --> Final output sent to browser
DEBUG - 2019-07-04 22:26:42 --> Total execution time: 0.5138
INFO - 2019-07-04 16:26:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:26:42 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:26:42 --> Database Driver Class Initialized
INFO - 2019-07-04 16:26:42 --> Controller Class Initialized
INFO - 2019-07-04 22:26:42 --> Helper loaded: language_helper
INFO - 2019-07-04 22:26:42 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:26:42 --> Model Class Initialized
INFO - 2019-07-04 22:26:42 --> Model Class Initialized
INFO - 2019-07-04 22:26:42 --> Model Class Initialized
INFO - 2019-07-04 22:26:42 --> Model Class Initialized
INFO - 2019-07-04 22:26:42 --> Helper loaded: form_helper
INFO - 2019-07-04 22:26:42 --> Form Validation Class Initialized
DEBUG - 2019-07-04 22:26:42 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 22:26:42 --> Model Class Initialized
INFO - 2019-07-04 22:26:42 --> Model Class Initialized
INFO - 2019-07-04 22:26:42 --> Final output sent to browser
DEBUG - 2019-07-04 22:26:42 --> Total execution time: 0.7146
INFO - 2019-07-04 16:26:43 --> Config Class Initialized
INFO - 2019-07-04 16:26:43 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:26:43 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:26:43 --> Utf8 Class Initialized
INFO - 2019-07-04 16:26:43 --> URI Class Initialized
INFO - 2019-07-04 16:26:43 --> Router Class Initialized
INFO - 2019-07-04 16:26:43 --> Output Class Initialized
INFO - 2019-07-04 16:26:43 --> Security Class Initialized
DEBUG - 2019-07-04 16:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:26:43 --> Input Class Initialized
INFO - 2019-07-04 16:26:43 --> Language Class Initialized
INFO - 2019-07-04 16:26:43 --> Language Class Initialized
INFO - 2019-07-04 16:26:43 --> Config Class Initialized
INFO - 2019-07-04 16:26:43 --> Loader Class Initialized
DEBUG - 2019-07-04 16:26:43 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:26:43 --> Helper loaded: url_helper
INFO - 2019-07-04 16:26:43 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:26:43 --> Helper loaded: string_helper
INFO - 2019-07-04 16:26:43 --> Helper loaded: array_helper
INFO - 2019-07-04 16:26:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:26:43 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:26:43 --> Database Driver Class Initialized
INFO - 2019-07-04 16:26:43 --> Controller Class Initialized
INFO - 2019-07-04 22:26:43 --> Helper loaded: language_helper
INFO - 2019-07-04 22:26:43 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:26:43 --> Model Class Initialized
INFO - 2019-07-04 22:26:43 --> Model Class Initialized
INFO - 2019-07-04 22:26:43 --> Model Class Initialized
INFO - 2019-07-04 22:26:43 --> Model Class Initialized
INFO - 2019-07-04 22:26:43 --> Model Class Initialized
INFO - 2019-07-04 22:26:43 --> Final output sent to browser
DEBUG - 2019-07-04 22:26:43 --> Total execution time: 0.3487
INFO - 2019-07-04 16:26:43 --> Config Class Initialized
INFO - 2019-07-04 16:26:43 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:26:43 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:26:43 --> Utf8 Class Initialized
INFO - 2019-07-04 16:26:43 --> URI Class Initialized
INFO - 2019-07-04 16:26:43 --> Router Class Initialized
INFO - 2019-07-04 16:26:43 --> Output Class Initialized
INFO - 2019-07-04 16:26:43 --> Security Class Initialized
DEBUG - 2019-07-04 16:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:26:43 --> Input Class Initialized
INFO - 2019-07-04 16:26:43 --> Language Class Initialized
INFO - 2019-07-04 16:26:43 --> Language Class Initialized
INFO - 2019-07-04 16:26:43 --> Config Class Initialized
INFO - 2019-07-04 16:26:43 --> Loader Class Initialized
DEBUG - 2019-07-04 16:26:43 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:26:43 --> Helper loaded: url_helper
INFO - 2019-07-04 16:26:43 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:26:43 --> Helper loaded: string_helper
INFO - 2019-07-04 16:26:43 --> Helper loaded: array_helper
INFO - 2019-07-04 16:26:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:26:43 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:26:43 --> Database Driver Class Initialized
INFO - 2019-07-04 16:26:43 --> Controller Class Initialized
INFO - 2019-07-04 22:26:43 --> Helper loaded: language_helper
INFO - 2019-07-04 22:26:43 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:26:43 --> Model Class Initialized
INFO - 2019-07-04 22:26:43 --> Model Class Initialized
INFO - 2019-07-04 22:26:43 --> Model Class Initialized
INFO - 2019-07-04 22:26:44 --> Model Class Initialized
INFO - 2019-07-04 22:26:44 --> Helper loaded: form_helper
INFO - 2019-07-04 22:26:44 --> Form Validation Class Initialized
DEBUG - 2019-07-04 22:26:44 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 22:26:44 --> Model Class Initialized
INFO - 2019-07-04 22:26:44 --> Model Class Initialized
INFO - 2019-07-04 22:26:44 --> Final output sent to browser
DEBUG - 2019-07-04 22:26:44 --> Total execution time: 0.4081
INFO - 2019-07-04 16:26:45 --> Config Class Initialized
INFO - 2019-07-04 16:26:45 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:26:45 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:26:45 --> Utf8 Class Initialized
INFO - 2019-07-04 16:26:45 --> URI Class Initialized
INFO - 2019-07-04 16:26:45 --> Router Class Initialized
INFO - 2019-07-04 16:26:45 --> Output Class Initialized
INFO - 2019-07-04 16:26:45 --> Security Class Initialized
DEBUG - 2019-07-04 16:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:26:45 --> Input Class Initialized
INFO - 2019-07-04 16:26:45 --> Language Class Initialized
INFO - 2019-07-04 16:26:45 --> Language Class Initialized
INFO - 2019-07-04 16:26:45 --> Config Class Initialized
INFO - 2019-07-04 16:26:45 --> Loader Class Initialized
DEBUG - 2019-07-04 16:26:45 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:26:45 --> Helper loaded: url_helper
INFO - 2019-07-04 16:26:45 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:26:45 --> Helper loaded: string_helper
INFO - 2019-07-04 16:26:45 --> Helper loaded: array_helper
INFO - 2019-07-04 16:26:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:26:45 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:26:45 --> Database Driver Class Initialized
INFO - 2019-07-04 16:26:45 --> Controller Class Initialized
INFO - 2019-07-04 22:26:45 --> Helper loaded: language_helper
INFO - 2019-07-04 22:26:45 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:26:45 --> Model Class Initialized
INFO - 2019-07-04 22:26:45 --> Model Class Initialized
INFO - 2019-07-04 22:26:45 --> Model Class Initialized
INFO - 2019-07-04 22:26:45 --> Model Class Initialized
INFO - 2019-07-04 22:26:45 --> Model Class Initialized
INFO - 2019-07-04 22:26:45 --> Final output sent to browser
DEBUG - 2019-07-04 22:26:45 --> Total execution time: 0.3644
INFO - 2019-07-04 16:27:22 --> Config Class Initialized
INFO - 2019-07-04 16:27:22 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:27:22 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:27:22 --> Utf8 Class Initialized
INFO - 2019-07-04 16:27:22 --> URI Class Initialized
INFO - 2019-07-04 16:27:22 --> Router Class Initialized
INFO - 2019-07-04 16:27:22 --> Output Class Initialized
INFO - 2019-07-04 16:27:22 --> Security Class Initialized
DEBUG - 2019-07-04 16:27:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:27:22 --> Input Class Initialized
INFO - 2019-07-04 16:27:22 --> Language Class Initialized
INFO - 2019-07-04 16:27:22 --> Language Class Initialized
INFO - 2019-07-04 16:27:22 --> Config Class Initialized
INFO - 2019-07-04 16:27:22 --> Loader Class Initialized
DEBUG - 2019-07-04 16:27:22 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:27:22 --> Helper loaded: url_helper
INFO - 2019-07-04 16:27:22 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:27:22 --> Helper loaded: string_helper
INFO - 2019-07-04 16:27:22 --> Helper loaded: array_helper
INFO - 2019-07-04 16:27:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:27:22 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:27:22 --> Database Driver Class Initialized
INFO - 2019-07-04 16:27:22 --> Controller Class Initialized
INFO - 2019-07-04 22:27:22 --> Helper loaded: language_helper
INFO - 2019-07-04 22:27:22 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:27:22 --> Model Class Initialized
INFO - 2019-07-04 22:27:22 --> Model Class Initialized
INFO - 2019-07-04 22:27:22 --> Model Class Initialized
INFO - 2019-07-04 22:27:22 --> Model Class Initialized
INFO - 2019-07-04 22:27:22 --> Model Class Initialized
INFO - 2019-07-04 22:27:22 --> Final output sent to browser
DEBUG - 2019-07-04 22:27:22 --> Total execution time: 0.3726
INFO - 2019-07-04 16:27:22 --> Config Class Initialized
INFO - 2019-07-04 16:27:22 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:27:22 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:27:22 --> Utf8 Class Initialized
INFO - 2019-07-04 16:27:22 --> URI Class Initialized
INFO - 2019-07-04 16:27:22 --> Router Class Initialized
INFO - 2019-07-04 16:27:22 --> Output Class Initialized
INFO - 2019-07-04 16:27:22 --> Security Class Initialized
DEBUG - 2019-07-04 16:27:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:27:22 --> Input Class Initialized
INFO - 2019-07-04 16:27:22 --> Language Class Initialized
INFO - 2019-07-04 16:27:22 --> Language Class Initialized
INFO - 2019-07-04 16:27:22 --> Config Class Initialized
INFO - 2019-07-04 16:27:22 --> Loader Class Initialized
DEBUG - 2019-07-04 16:27:22 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:27:22 --> Helper loaded: url_helper
INFO - 2019-07-04 16:27:22 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:27:22 --> Helper loaded: string_helper
INFO - 2019-07-04 16:27:23 --> Helper loaded: array_helper
INFO - 2019-07-04 16:27:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:27:23 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:27:23 --> Database Driver Class Initialized
INFO - 2019-07-04 16:27:23 --> Controller Class Initialized
INFO - 2019-07-04 22:27:23 --> Helper loaded: language_helper
INFO - 2019-07-04 22:27:23 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:27:23 --> Model Class Initialized
INFO - 2019-07-04 22:27:23 --> Model Class Initialized
INFO - 2019-07-04 22:27:23 --> Model Class Initialized
INFO - 2019-07-04 22:27:23 --> Model Class Initialized
INFO - 2019-07-04 22:27:23 --> Helper loaded: form_helper
INFO - 2019-07-04 22:27:23 --> Form Validation Class Initialized
DEBUG - 2019-07-04 22:27:23 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 22:27:23 --> Model Class Initialized
INFO - 2019-07-04 22:27:23 --> Model Class Initialized
INFO - 2019-07-04 22:27:23 --> Final output sent to browser
DEBUG - 2019-07-04 22:27:23 --> Total execution time: 0.4241
INFO - 2019-07-04 16:27:23 --> Config Class Initialized
INFO - 2019-07-04 16:27:23 --> Hooks Class Initialized
INFO - 2019-07-04 16:27:23 --> Config Class Initialized
INFO - 2019-07-04 16:27:23 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:27:23 --> UTF-8 Support Enabled
DEBUG - 2019-07-04 16:27:23 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:27:23 --> Utf8 Class Initialized
INFO - 2019-07-04 16:27:23 --> Utf8 Class Initialized
INFO - 2019-07-04 16:27:23 --> URI Class Initialized
INFO - 2019-07-04 16:27:23 --> URI Class Initialized
INFO - 2019-07-04 16:27:23 --> Router Class Initialized
INFO - 2019-07-04 16:27:23 --> Router Class Initialized
INFO - 2019-07-04 16:27:23 --> Output Class Initialized
INFO - 2019-07-04 16:27:23 --> Output Class Initialized
INFO - 2019-07-04 16:27:23 --> Security Class Initialized
INFO - 2019-07-04 16:27:23 --> Security Class Initialized
DEBUG - 2019-07-04 16:27:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-04 16:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:27:24 --> Input Class Initialized
INFO - 2019-07-04 16:27:24 --> Input Class Initialized
INFO - 2019-07-04 16:27:24 --> Language Class Initialized
INFO - 2019-07-04 16:27:24 --> Language Class Initialized
INFO - 2019-07-04 16:27:24 --> Language Class Initialized
INFO - 2019-07-04 16:27:24 --> Language Class Initialized
INFO - 2019-07-04 16:27:24 --> Config Class Initialized
INFO - 2019-07-04 16:27:24 --> Config Class Initialized
INFO - 2019-07-04 16:27:24 --> Loader Class Initialized
INFO - 2019-07-04 16:27:24 --> Loader Class Initialized
DEBUG - 2019-07-04 16:27:24 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-04 16:27:24 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:27:24 --> Helper loaded: url_helper
INFO - 2019-07-04 16:27:24 --> Helper loaded: url_helper
INFO - 2019-07-04 16:27:24 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:27:24 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:27:24 --> Helper loaded: string_helper
INFO - 2019-07-04 16:27:24 --> Helper loaded: string_helper
INFO - 2019-07-04 16:27:24 --> Helper loaded: array_helper
INFO - 2019-07-04 16:27:24 --> Helper loaded: array_helper
INFO - 2019-07-04 16:27:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:27:24 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:27:24 --> Database Driver Class Initialized
INFO - 2019-07-04 16:27:24 --> Controller Class Initialized
INFO - 2019-07-04 22:27:24 --> Helper loaded: language_helper
INFO - 2019-07-04 22:27:24 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:27:24 --> Model Class Initialized
INFO - 2019-07-04 22:27:24 --> Model Class Initialized
INFO - 2019-07-04 22:27:24 --> Model Class Initialized
INFO - 2019-07-04 22:27:24 --> Model Class Initialized
INFO - 2019-07-04 22:27:24 --> Helper loaded: form_helper
INFO - 2019-07-04 22:27:24 --> Form Validation Class Initialized
DEBUG - 2019-07-04 22:27:24 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 22:27:24 --> Model Class Initialized
INFO - 2019-07-04 22:27:24 --> Model Class Initialized
INFO - 2019-07-04 22:27:24 --> Final output sent to browser
DEBUG - 2019-07-04 22:27:24 --> Total execution time: 0.5928
INFO - 2019-07-04 16:27:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:27:24 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:27:24 --> Database Driver Class Initialized
INFO - 2019-07-04 16:27:24 --> Controller Class Initialized
INFO - 2019-07-04 22:27:24 --> Helper loaded: language_helper
INFO - 2019-07-04 22:27:24 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:27:24 --> Model Class Initialized
INFO - 2019-07-04 22:27:24 --> Model Class Initialized
INFO - 2019-07-04 22:27:24 --> Model Class Initialized
INFO - 2019-07-04 22:27:24 --> Model Class Initialized
INFO - 2019-07-04 22:27:24 --> Model Class Initialized
INFO - 2019-07-04 22:27:24 --> Final output sent to browser
DEBUG - 2019-07-04 22:27:24 --> Total execution time: 0.7626
INFO - 2019-07-04 16:27:32 --> Config Class Initialized
INFO - 2019-07-04 16:27:32 --> Config Class Initialized
INFO - 2019-07-04 16:27:32 --> Hooks Class Initialized
INFO - 2019-07-04 16:27:32 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:27:32 --> UTF-8 Support Enabled
DEBUG - 2019-07-04 16:27:32 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:27:32 --> Utf8 Class Initialized
INFO - 2019-07-04 16:27:32 --> Utf8 Class Initialized
INFO - 2019-07-04 16:27:32 --> URI Class Initialized
INFO - 2019-07-04 16:27:32 --> URI Class Initialized
INFO - 2019-07-04 16:27:32 --> Router Class Initialized
INFO - 2019-07-04 16:27:32 --> Router Class Initialized
INFO - 2019-07-04 16:27:32 --> Output Class Initialized
INFO - 2019-07-04 16:27:32 --> Output Class Initialized
INFO - 2019-07-04 16:27:32 --> Security Class Initialized
INFO - 2019-07-04 16:27:32 --> Security Class Initialized
DEBUG - 2019-07-04 16:27:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-04 16:27:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:27:33 --> Input Class Initialized
INFO - 2019-07-04 16:27:33 --> Input Class Initialized
INFO - 2019-07-04 16:27:33 --> Language Class Initialized
INFO - 2019-07-04 16:27:33 --> Language Class Initialized
INFO - 2019-07-04 16:27:33 --> Language Class Initialized
INFO - 2019-07-04 16:27:33 --> Language Class Initialized
INFO - 2019-07-04 16:27:33 --> Config Class Initialized
INFO - 2019-07-04 16:27:33 --> Config Class Initialized
INFO - 2019-07-04 16:27:33 --> Loader Class Initialized
INFO - 2019-07-04 16:27:33 --> Loader Class Initialized
DEBUG - 2019-07-04 16:27:33 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-04 16:27:33 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:27:33 --> Helper loaded: url_helper
INFO - 2019-07-04 16:27:33 --> Helper loaded: url_helper
INFO - 2019-07-04 16:27:33 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:27:33 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:27:33 --> Helper loaded: string_helper
INFO - 2019-07-04 16:27:33 --> Helper loaded: string_helper
INFO - 2019-07-04 16:27:33 --> Helper loaded: array_helper
INFO - 2019-07-04 16:27:33 --> Helper loaded: array_helper
INFO - 2019-07-04 16:27:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:27:33 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:27:33 --> Database Driver Class Initialized
INFO - 2019-07-04 16:27:33 --> Controller Class Initialized
INFO - 2019-07-04 22:27:33 --> Helper loaded: language_helper
INFO - 2019-07-04 22:27:33 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:27:33 --> Model Class Initialized
INFO - 2019-07-04 22:27:33 --> Model Class Initialized
INFO - 2019-07-04 22:27:33 --> Model Class Initialized
INFO - 2019-07-04 22:27:33 --> Model Class Initialized
INFO - 2019-07-04 22:27:33 --> Helper loaded: form_helper
INFO - 2019-07-04 22:27:33 --> Form Validation Class Initialized
DEBUG - 2019-07-04 22:27:33 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 22:27:33 --> Model Class Initialized
INFO - 2019-07-04 22:27:33 --> Model Class Initialized
INFO - 2019-07-04 22:27:33 --> Final output sent to browser
DEBUG - 2019-07-04 22:27:33 --> Total execution time: 0.6247
INFO - 2019-07-04 16:27:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:27:33 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:27:33 --> Database Driver Class Initialized
INFO - 2019-07-04 16:27:33 --> Controller Class Initialized
INFO - 2019-07-04 22:27:33 --> Helper loaded: language_helper
INFO - 2019-07-04 22:27:33 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:27:33 --> Model Class Initialized
INFO - 2019-07-04 22:27:33 --> Model Class Initialized
INFO - 2019-07-04 22:27:33 --> Model Class Initialized
INFO - 2019-07-04 22:27:33 --> Model Class Initialized
INFO - 2019-07-04 22:27:33 --> Model Class Initialized
INFO - 2019-07-04 22:27:33 --> Final output sent to browser
DEBUG - 2019-07-04 22:27:33 --> Total execution time: 0.8094
INFO - 2019-07-04 16:27:34 --> Config Class Initialized
INFO - 2019-07-04 16:27:34 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:27:34 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:27:34 --> Utf8 Class Initialized
INFO - 2019-07-04 16:27:34 --> URI Class Initialized
INFO - 2019-07-04 16:27:34 --> Router Class Initialized
INFO - 2019-07-04 16:27:34 --> Output Class Initialized
INFO - 2019-07-04 16:27:34 --> Security Class Initialized
DEBUG - 2019-07-04 16:27:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:27:34 --> Input Class Initialized
INFO - 2019-07-04 16:27:34 --> Language Class Initialized
INFO - 2019-07-04 16:27:34 --> Language Class Initialized
INFO - 2019-07-04 16:27:34 --> Config Class Initialized
INFO - 2019-07-04 16:27:34 --> Loader Class Initialized
DEBUG - 2019-07-04 16:27:34 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:27:34 --> Helper loaded: url_helper
INFO - 2019-07-04 16:27:34 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:27:34 --> Helper loaded: string_helper
INFO - 2019-07-04 16:27:34 --> Helper loaded: array_helper
INFO - 2019-07-04 16:27:34 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:27:34 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:27:34 --> Database Driver Class Initialized
INFO - 2019-07-04 16:27:34 --> Controller Class Initialized
INFO - 2019-07-04 22:27:34 --> Helper loaded: language_helper
INFO - 2019-07-04 22:27:34 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:27:34 --> Model Class Initialized
INFO - 2019-07-04 22:27:34 --> Model Class Initialized
INFO - 2019-07-04 22:27:34 --> Model Class Initialized
INFO - 2019-07-04 22:27:34 --> Model Class Initialized
INFO - 2019-07-04 22:27:34 --> Model Class Initialized
INFO - 2019-07-04 22:27:34 --> Final output sent to browser
DEBUG - 2019-07-04 22:27:34 --> Total execution time: 0.3475
INFO - 2019-07-04 16:27:34 --> Config Class Initialized
INFO - 2019-07-04 16:27:34 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:27:34 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:27:34 --> Utf8 Class Initialized
INFO - 2019-07-04 16:27:34 --> URI Class Initialized
INFO - 2019-07-04 16:27:34 --> Router Class Initialized
INFO - 2019-07-04 16:27:34 --> Output Class Initialized
INFO - 2019-07-04 16:27:34 --> Security Class Initialized
DEBUG - 2019-07-04 16:27:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:27:35 --> Input Class Initialized
INFO - 2019-07-04 16:27:35 --> Language Class Initialized
INFO - 2019-07-04 16:27:35 --> Language Class Initialized
INFO - 2019-07-04 16:27:35 --> Config Class Initialized
INFO - 2019-07-04 16:27:35 --> Loader Class Initialized
DEBUG - 2019-07-04 16:27:35 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:27:35 --> Helper loaded: url_helper
INFO - 2019-07-04 16:27:35 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:27:35 --> Helper loaded: string_helper
INFO - 2019-07-04 16:27:35 --> Helper loaded: array_helper
INFO - 2019-07-04 16:27:35 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:27:35 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:27:35 --> Database Driver Class Initialized
INFO - 2019-07-04 16:27:35 --> Controller Class Initialized
INFO - 2019-07-04 22:27:35 --> Helper loaded: language_helper
INFO - 2019-07-04 22:27:35 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:27:35 --> Model Class Initialized
INFO - 2019-07-04 22:27:35 --> Model Class Initialized
INFO - 2019-07-04 22:27:35 --> Model Class Initialized
INFO - 2019-07-04 22:27:35 --> Model Class Initialized
INFO - 2019-07-04 22:27:35 --> Helper loaded: form_helper
INFO - 2019-07-04 22:27:35 --> Form Validation Class Initialized
DEBUG - 2019-07-04 22:27:35 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 22:27:35 --> Model Class Initialized
INFO - 2019-07-04 22:27:35 --> Model Class Initialized
INFO - 2019-07-04 22:27:35 --> Final output sent to browser
DEBUG - 2019-07-04 22:27:35 --> Total execution time: 0.4061
INFO - 2019-07-04 16:27:35 --> Config Class Initialized
INFO - 2019-07-04 16:27:35 --> Config Class Initialized
INFO - 2019-07-04 16:27:35 --> Hooks Class Initialized
INFO - 2019-07-04 16:27:35 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:27:35 --> UTF-8 Support Enabled
DEBUG - 2019-07-04 16:27:36 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:27:36 --> Utf8 Class Initialized
INFO - 2019-07-04 16:27:36 --> Utf8 Class Initialized
INFO - 2019-07-04 16:27:36 --> URI Class Initialized
INFO - 2019-07-04 16:27:36 --> URI Class Initialized
INFO - 2019-07-04 16:27:36 --> Router Class Initialized
INFO - 2019-07-04 16:27:36 --> Router Class Initialized
INFO - 2019-07-04 16:27:36 --> Output Class Initialized
INFO - 2019-07-04 16:27:36 --> Output Class Initialized
INFO - 2019-07-04 16:27:36 --> Security Class Initialized
INFO - 2019-07-04 16:27:36 --> Security Class Initialized
DEBUG - 2019-07-04 16:27:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-04 16:27:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:27:36 --> Input Class Initialized
INFO - 2019-07-04 16:27:36 --> Input Class Initialized
INFO - 2019-07-04 16:27:36 --> Language Class Initialized
INFO - 2019-07-04 16:27:36 --> Language Class Initialized
INFO - 2019-07-04 16:27:36 --> Language Class Initialized
INFO - 2019-07-04 16:27:36 --> Config Class Initialized
INFO - 2019-07-04 16:27:36 --> Language Class Initialized
INFO - 2019-07-04 16:27:36 --> Loader Class Initialized
DEBUG - 2019-07-04 16:27:36 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:27:36 --> Config Class Initialized
INFO - 2019-07-04 16:27:36 --> Loader Class Initialized
INFO - 2019-07-04 16:27:36 --> Helper loaded: url_helper
DEBUG - 2019-07-04 16:27:36 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:27:36 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:27:36 --> Helper loaded: url_helper
INFO - 2019-07-04 16:27:36 --> Helper loaded: string_helper
INFO - 2019-07-04 16:27:36 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:27:36 --> Helper loaded: array_helper
INFO - 2019-07-04 16:27:36 --> Helper loaded: string_helper
INFO - 2019-07-04 16:27:36 --> Session: Class initialized using 'files' driver.
INFO - 2019-07-04 16:27:36 --> Helper loaded: array_helper
DEBUG - 2019-07-04 16:27:36 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:27:36 --> Database Driver Class Initialized
INFO - 2019-07-04 16:27:36 --> Controller Class Initialized
INFO - 2019-07-04 22:27:36 --> Helper loaded: language_helper
INFO - 2019-07-04 22:27:36 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:27:36 --> Model Class Initialized
INFO - 2019-07-04 22:27:36 --> Model Class Initialized
INFO - 2019-07-04 22:27:36 --> Model Class Initialized
INFO - 2019-07-04 22:27:36 --> Model Class Initialized
INFO - 2019-07-04 22:27:36 --> Model Class Initialized
INFO - 2019-07-04 22:27:36 --> Final output sent to browser
DEBUG - 2019-07-04 22:27:36 --> Total execution time: 0.5535
INFO - 2019-07-04 16:27:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:27:36 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:27:36 --> Database Driver Class Initialized
INFO - 2019-07-04 16:27:36 --> Controller Class Initialized
INFO - 2019-07-04 22:27:36 --> Helper loaded: language_helper
INFO - 2019-07-04 22:27:36 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:27:36 --> Model Class Initialized
INFO - 2019-07-04 22:27:36 --> Model Class Initialized
INFO - 2019-07-04 22:27:36 --> Model Class Initialized
INFO - 2019-07-04 22:27:36 --> Model Class Initialized
INFO - 2019-07-04 22:27:36 --> Helper loaded: form_helper
INFO - 2019-07-04 22:27:36 --> Form Validation Class Initialized
DEBUG - 2019-07-04 22:27:36 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 22:27:36 --> Model Class Initialized
INFO - 2019-07-04 22:27:36 --> Model Class Initialized
INFO - 2019-07-04 22:27:36 --> Final output sent to browser
DEBUG - 2019-07-04 22:27:36 --> Total execution time: 0.7666
INFO - 2019-07-04 16:27:37 --> Config Class Initialized
INFO - 2019-07-04 16:27:37 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:27:37 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:27:37 --> Utf8 Class Initialized
INFO - 2019-07-04 16:27:37 --> URI Class Initialized
INFO - 2019-07-04 16:27:37 --> Router Class Initialized
INFO - 2019-07-04 16:27:37 --> Output Class Initialized
INFO - 2019-07-04 16:27:37 --> Security Class Initialized
DEBUG - 2019-07-04 16:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:27:37 --> Input Class Initialized
INFO - 2019-07-04 16:27:37 --> Language Class Initialized
INFO - 2019-07-04 16:27:37 --> Language Class Initialized
INFO - 2019-07-04 16:27:37 --> Config Class Initialized
INFO - 2019-07-04 16:27:37 --> Loader Class Initialized
DEBUG - 2019-07-04 16:27:37 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:27:37 --> Helper loaded: url_helper
INFO - 2019-07-04 16:27:37 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:27:37 --> Helper loaded: string_helper
INFO - 2019-07-04 16:27:37 --> Helper loaded: array_helper
INFO - 2019-07-04 16:27:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:27:37 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:27:37 --> Database Driver Class Initialized
INFO - 2019-07-04 16:27:37 --> Controller Class Initialized
INFO - 2019-07-04 22:27:37 --> Helper loaded: language_helper
INFO - 2019-07-04 22:27:37 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:27:37 --> Model Class Initialized
INFO - 2019-07-04 22:27:37 --> Model Class Initialized
INFO - 2019-07-04 22:27:37 --> Model Class Initialized
INFO - 2019-07-04 22:27:37 --> Model Class Initialized
INFO - 2019-07-04 22:27:37 --> Model Class Initialized
INFO - 2019-07-04 22:27:37 --> Final output sent to browser
DEBUG - 2019-07-04 22:27:37 --> Total execution time: 0.3547
INFO - 2019-07-04 16:27:38 --> Config Class Initialized
INFO - 2019-07-04 16:27:38 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:27:38 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:27:38 --> Utf8 Class Initialized
INFO - 2019-07-04 16:27:38 --> URI Class Initialized
INFO - 2019-07-04 16:27:38 --> Router Class Initialized
INFO - 2019-07-04 16:27:38 --> Output Class Initialized
INFO - 2019-07-04 16:27:38 --> Security Class Initialized
DEBUG - 2019-07-04 16:27:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:27:38 --> Input Class Initialized
INFO - 2019-07-04 16:27:38 --> Language Class Initialized
INFO - 2019-07-04 16:27:38 --> Language Class Initialized
INFO - 2019-07-04 16:27:38 --> Config Class Initialized
INFO - 2019-07-04 16:27:38 --> Loader Class Initialized
DEBUG - 2019-07-04 16:27:38 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:27:38 --> Helper loaded: url_helper
INFO - 2019-07-04 16:27:38 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:27:38 --> Helper loaded: string_helper
INFO - 2019-07-04 16:27:38 --> Helper loaded: array_helper
INFO - 2019-07-04 16:27:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:27:38 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:27:38 --> Database Driver Class Initialized
INFO - 2019-07-04 16:27:38 --> Controller Class Initialized
INFO - 2019-07-04 22:27:38 --> Helper loaded: language_helper
INFO - 2019-07-04 22:27:38 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:27:38 --> Model Class Initialized
INFO - 2019-07-04 22:27:38 --> Model Class Initialized
INFO - 2019-07-04 22:27:38 --> Model Class Initialized
INFO - 2019-07-04 22:27:38 --> Model Class Initialized
INFO - 2019-07-04 22:27:38 --> Helper loaded: form_helper
INFO - 2019-07-04 22:27:38 --> Form Validation Class Initialized
DEBUG - 2019-07-04 22:27:38 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 22:27:38 --> Model Class Initialized
INFO - 2019-07-04 22:27:38 --> Model Class Initialized
INFO - 2019-07-04 22:27:38 --> Final output sent to browser
DEBUG - 2019-07-04 22:27:38 --> Total execution time: 0.4181
INFO - 2019-07-04 16:27:40 --> Config Class Initialized
INFO - 2019-07-04 16:27:40 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:27:40 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:27:40 --> Utf8 Class Initialized
INFO - 2019-07-04 16:27:40 --> URI Class Initialized
INFO - 2019-07-04 16:27:40 --> Router Class Initialized
INFO - 2019-07-04 16:27:40 --> Output Class Initialized
INFO - 2019-07-04 16:27:40 --> Security Class Initialized
DEBUG - 2019-07-04 16:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:27:40 --> Input Class Initialized
INFO - 2019-07-04 16:27:40 --> Language Class Initialized
INFO - 2019-07-04 16:27:40 --> Language Class Initialized
INFO - 2019-07-04 16:27:40 --> Config Class Initialized
INFO - 2019-07-04 16:27:40 --> Loader Class Initialized
DEBUG - 2019-07-04 16:27:40 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:27:40 --> Helper loaded: url_helper
INFO - 2019-07-04 16:27:40 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:27:40 --> Helper loaded: string_helper
INFO - 2019-07-04 16:27:40 --> Helper loaded: array_helper
INFO - 2019-07-04 16:27:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:27:40 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:27:41 --> Database Driver Class Initialized
INFO - 2019-07-04 16:27:41 --> Controller Class Initialized
INFO - 2019-07-04 22:27:41 --> Helper loaded: language_helper
INFO - 2019-07-04 22:27:41 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:27:41 --> Model Class Initialized
INFO - 2019-07-04 22:27:41 --> Model Class Initialized
INFO - 2019-07-04 22:27:41 --> Model Class Initialized
INFO - 2019-07-04 22:27:41 --> Model Class Initialized
INFO - 2019-07-04 22:27:41 --> Model Class Initialized
INFO - 2019-07-04 22:27:41 --> Final output sent to browser
DEBUG - 2019-07-04 22:27:41 --> Total execution time: 0.3609
INFO - 2019-07-04 16:27:41 --> Config Class Initialized
INFO - 2019-07-04 16:27:41 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:27:41 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:27:41 --> Utf8 Class Initialized
INFO - 2019-07-04 16:27:41 --> URI Class Initialized
INFO - 2019-07-04 16:27:41 --> Router Class Initialized
INFO - 2019-07-04 16:27:41 --> Output Class Initialized
INFO - 2019-07-04 16:27:41 --> Security Class Initialized
DEBUG - 2019-07-04 16:27:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:27:41 --> Input Class Initialized
INFO - 2019-07-04 16:27:41 --> Language Class Initialized
INFO - 2019-07-04 16:27:41 --> Language Class Initialized
INFO - 2019-07-04 16:27:41 --> Config Class Initialized
INFO - 2019-07-04 16:27:41 --> Loader Class Initialized
DEBUG - 2019-07-04 16:27:41 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:27:41 --> Helper loaded: url_helper
INFO - 2019-07-04 16:27:41 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:27:41 --> Helper loaded: string_helper
INFO - 2019-07-04 16:27:41 --> Helper loaded: array_helper
INFO - 2019-07-04 16:27:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:27:41 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:27:41 --> Database Driver Class Initialized
INFO - 2019-07-04 16:27:41 --> Controller Class Initialized
INFO - 2019-07-04 22:27:41 --> Helper loaded: language_helper
INFO - 2019-07-04 22:27:41 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:27:41 --> Model Class Initialized
INFO - 2019-07-04 22:27:41 --> Model Class Initialized
INFO - 2019-07-04 22:27:41 --> Model Class Initialized
INFO - 2019-07-04 22:27:41 --> Model Class Initialized
INFO - 2019-07-04 22:27:41 --> Helper loaded: form_helper
INFO - 2019-07-04 22:27:41 --> Form Validation Class Initialized
DEBUG - 2019-07-04 22:27:41 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 22:27:41 --> Model Class Initialized
INFO - 2019-07-04 22:27:41 --> Model Class Initialized
INFO - 2019-07-04 22:27:41 --> Final output sent to browser
DEBUG - 2019-07-04 22:27:41 --> Total execution time: 0.4293
INFO - 2019-07-04 16:27:42 --> Config Class Initialized
INFO - 2019-07-04 16:27:42 --> Config Class Initialized
INFO - 2019-07-04 16:27:42 --> Hooks Class Initialized
INFO - 2019-07-04 16:27:42 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:27:42 --> UTF-8 Support Enabled
DEBUG - 2019-07-04 16:27:42 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:27:42 --> Utf8 Class Initialized
INFO - 2019-07-04 16:27:42 --> Utf8 Class Initialized
INFO - 2019-07-04 16:27:42 --> URI Class Initialized
INFO - 2019-07-04 16:27:42 --> URI Class Initialized
INFO - 2019-07-04 16:27:42 --> Router Class Initialized
INFO - 2019-07-04 16:27:42 --> Router Class Initialized
INFO - 2019-07-04 16:27:42 --> Output Class Initialized
INFO - 2019-07-04 16:27:42 --> Output Class Initialized
INFO - 2019-07-04 16:27:42 --> Security Class Initialized
INFO - 2019-07-04 16:27:42 --> Security Class Initialized
DEBUG - 2019-07-04 16:27:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-04 16:27:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:27:42 --> Input Class Initialized
INFO - 2019-07-04 16:27:42 --> Input Class Initialized
INFO - 2019-07-04 16:27:42 --> Language Class Initialized
INFO - 2019-07-04 16:27:42 --> Language Class Initialized
INFO - 2019-07-04 16:27:42 --> Language Class Initialized
INFO - 2019-07-04 16:27:42 --> Language Class Initialized
INFO - 2019-07-04 16:27:42 --> Config Class Initialized
INFO - 2019-07-04 16:27:42 --> Config Class Initialized
INFO - 2019-07-04 16:27:42 --> Loader Class Initialized
INFO - 2019-07-04 16:27:42 --> Loader Class Initialized
DEBUG - 2019-07-04 16:27:42 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-04 16:27:42 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:27:42 --> Helper loaded: url_helper
INFO - 2019-07-04 16:27:42 --> Helper loaded: url_helper
INFO - 2019-07-04 16:27:42 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:27:42 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:27:42 --> Helper loaded: string_helper
INFO - 2019-07-04 16:27:42 --> Helper loaded: string_helper
INFO - 2019-07-04 16:27:42 --> Helper loaded: array_helper
INFO - 2019-07-04 16:27:42 --> Helper loaded: array_helper
INFO - 2019-07-04 16:27:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:27:42 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:27:42 --> Database Driver Class Initialized
INFO - 2019-07-04 16:27:42 --> Controller Class Initialized
INFO - 2019-07-04 22:27:42 --> Helper loaded: language_helper
INFO - 2019-07-04 22:27:42 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:27:42 --> Model Class Initialized
INFO - 2019-07-04 22:27:42 --> Model Class Initialized
INFO - 2019-07-04 22:27:42 --> Model Class Initialized
INFO - 2019-07-04 22:27:42 --> Model Class Initialized
INFO - 2019-07-04 22:27:42 --> Model Class Initialized
INFO - 2019-07-04 22:27:42 --> Final output sent to browser
DEBUG - 2019-07-04 22:27:42 --> Total execution time: 0.5777
INFO - 2019-07-04 16:27:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:27:42 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:27:42 --> Database Driver Class Initialized
INFO - 2019-07-04 16:27:42 --> Controller Class Initialized
INFO - 2019-07-04 22:27:42 --> Helper loaded: language_helper
INFO - 2019-07-04 22:27:42 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:27:42 --> Model Class Initialized
INFO - 2019-07-04 22:27:42 --> Model Class Initialized
INFO - 2019-07-04 22:27:42 --> Model Class Initialized
INFO - 2019-07-04 22:27:42 --> Model Class Initialized
INFO - 2019-07-04 22:27:42 --> Helper loaded: form_helper
INFO - 2019-07-04 22:27:42 --> Form Validation Class Initialized
DEBUG - 2019-07-04 22:27:42 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 22:27:42 --> Model Class Initialized
INFO - 2019-07-04 22:27:42 --> Model Class Initialized
INFO - 2019-07-04 22:27:42 --> Final output sent to browser
DEBUG - 2019-07-04 22:27:42 --> Total execution time: 0.7894
INFO - 2019-07-04 16:27:48 --> Config Class Initialized
INFO - 2019-07-04 16:27:48 --> Config Class Initialized
INFO - 2019-07-04 16:27:48 --> Hooks Class Initialized
INFO - 2019-07-04 16:27:48 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:27:48 --> UTF-8 Support Enabled
DEBUG - 2019-07-04 16:27:48 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:27:48 --> Utf8 Class Initialized
INFO - 2019-07-04 16:27:48 --> Utf8 Class Initialized
INFO - 2019-07-04 16:27:48 --> URI Class Initialized
INFO - 2019-07-04 16:27:48 --> URI Class Initialized
INFO - 2019-07-04 16:27:48 --> Router Class Initialized
INFO - 2019-07-04 16:27:48 --> Router Class Initialized
INFO - 2019-07-04 16:27:48 --> Output Class Initialized
INFO - 2019-07-04 16:27:48 --> Output Class Initialized
INFO - 2019-07-04 16:27:48 --> Security Class Initialized
INFO - 2019-07-04 16:27:48 --> Security Class Initialized
DEBUG - 2019-07-04 16:27:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-04 16:27:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:27:48 --> Input Class Initialized
INFO - 2019-07-04 16:27:48 --> Input Class Initialized
INFO - 2019-07-04 16:27:48 --> Language Class Initialized
INFO - 2019-07-04 16:27:48 --> Language Class Initialized
INFO - 2019-07-04 16:27:48 --> Language Class Initialized
INFO - 2019-07-04 16:27:48 --> Language Class Initialized
INFO - 2019-07-04 16:27:48 --> Config Class Initialized
INFO - 2019-07-04 16:27:48 --> Loader Class Initialized
INFO - 2019-07-04 16:27:48 --> Config Class Initialized
INFO - 2019-07-04 16:27:48 --> Loader Class Initialized
DEBUG - 2019-07-04 16:27:48 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-04 16:27:48 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:27:48 --> Helper loaded: url_helper
INFO - 2019-07-04 16:27:48 --> Helper loaded: url_helper
INFO - 2019-07-04 16:27:48 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:27:48 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:27:48 --> Helper loaded: string_helper
INFO - 2019-07-04 16:27:48 --> Helper loaded: string_helper
INFO - 2019-07-04 16:27:48 --> Helper loaded: array_helper
INFO - 2019-07-04 16:27:48 --> Helper loaded: array_helper
INFO - 2019-07-04 16:27:48 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:27:48 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:27:48 --> Database Driver Class Initialized
INFO - 2019-07-04 16:27:48 --> Controller Class Initialized
INFO - 2019-07-04 22:27:48 --> Helper loaded: language_helper
INFO - 2019-07-04 22:27:48 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:27:48 --> Model Class Initialized
INFO - 2019-07-04 22:27:48 --> Model Class Initialized
INFO - 2019-07-04 22:27:48 --> Model Class Initialized
INFO - 2019-07-04 22:27:48 --> Model Class Initialized
INFO - 2019-07-04 22:27:48 --> Model Class Initialized
INFO - 2019-07-04 22:27:48 --> Final output sent to browser
DEBUG - 2019-07-04 22:27:48 --> Total execution time: 0.5692
INFO - 2019-07-04 16:27:48 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:27:48 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:27:48 --> Database Driver Class Initialized
INFO - 2019-07-04 16:27:48 --> Controller Class Initialized
INFO - 2019-07-04 22:27:48 --> Helper loaded: language_helper
INFO - 2019-07-04 22:27:48 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:27:48 --> Model Class Initialized
INFO - 2019-07-04 22:27:48 --> Model Class Initialized
INFO - 2019-07-04 22:27:48 --> Model Class Initialized
INFO - 2019-07-04 22:27:48 --> Model Class Initialized
INFO - 2019-07-04 22:27:48 --> Helper loaded: form_helper
INFO - 2019-07-04 22:27:48 --> Form Validation Class Initialized
DEBUG - 2019-07-04 22:27:49 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 22:27:49 --> Model Class Initialized
INFO - 2019-07-04 22:27:49 --> Model Class Initialized
INFO - 2019-07-04 22:27:49 --> Final output sent to browser
DEBUG - 2019-07-04 22:27:49 --> Total execution time: 0.8038
INFO - 2019-07-04 16:27:49 --> Config Class Initialized
INFO - 2019-07-04 16:27:49 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:27:49 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:27:49 --> Utf8 Class Initialized
INFO - 2019-07-04 16:27:49 --> URI Class Initialized
INFO - 2019-07-04 16:27:49 --> Router Class Initialized
INFO - 2019-07-04 16:27:49 --> Output Class Initialized
INFO - 2019-07-04 16:27:49 --> Security Class Initialized
DEBUG - 2019-07-04 16:27:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:27:49 --> Input Class Initialized
INFO - 2019-07-04 16:27:49 --> Language Class Initialized
INFO - 2019-07-04 16:27:49 --> Language Class Initialized
INFO - 2019-07-04 16:27:49 --> Config Class Initialized
INFO - 2019-07-04 16:27:50 --> Loader Class Initialized
DEBUG - 2019-07-04 16:27:50 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:27:50 --> Helper loaded: url_helper
INFO - 2019-07-04 16:27:50 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:27:50 --> Helper loaded: string_helper
INFO - 2019-07-04 16:27:50 --> Helper loaded: array_helper
INFO - 2019-07-04 16:27:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:27:50 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:27:50 --> Database Driver Class Initialized
INFO - 2019-07-04 16:27:50 --> Controller Class Initialized
INFO - 2019-07-04 22:27:50 --> Helper loaded: language_helper
INFO - 2019-07-04 22:27:50 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:27:50 --> Model Class Initialized
INFO - 2019-07-04 22:27:50 --> Model Class Initialized
INFO - 2019-07-04 22:27:50 --> Model Class Initialized
INFO - 2019-07-04 22:27:50 --> Model Class Initialized
INFO - 2019-07-04 22:27:50 --> Model Class Initialized
INFO - 2019-07-04 22:27:50 --> Final output sent to browser
DEBUG - 2019-07-04 22:27:50 --> Total execution time: 0.3602
INFO - 2019-07-04 16:27:50 --> Config Class Initialized
INFO - 2019-07-04 16:27:50 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:27:50 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:27:50 --> Utf8 Class Initialized
INFO - 2019-07-04 16:27:50 --> URI Class Initialized
INFO - 2019-07-04 16:27:50 --> Router Class Initialized
INFO - 2019-07-04 16:27:50 --> Output Class Initialized
INFO - 2019-07-04 16:27:50 --> Security Class Initialized
DEBUG - 2019-07-04 16:27:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:27:50 --> Input Class Initialized
INFO - 2019-07-04 16:27:50 --> Language Class Initialized
INFO - 2019-07-04 16:27:50 --> Language Class Initialized
INFO - 2019-07-04 16:27:50 --> Config Class Initialized
INFO - 2019-07-04 16:27:50 --> Loader Class Initialized
DEBUG - 2019-07-04 16:27:50 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:27:50 --> Helper loaded: url_helper
INFO - 2019-07-04 16:27:50 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:27:50 --> Helper loaded: string_helper
INFO - 2019-07-04 16:27:50 --> Helper loaded: array_helper
INFO - 2019-07-04 16:27:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:27:50 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:27:50 --> Database Driver Class Initialized
INFO - 2019-07-04 16:27:50 --> Controller Class Initialized
INFO - 2019-07-04 22:27:50 --> Helper loaded: language_helper
INFO - 2019-07-04 22:27:50 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:27:50 --> Model Class Initialized
INFO - 2019-07-04 22:27:50 --> Model Class Initialized
INFO - 2019-07-04 22:27:50 --> Model Class Initialized
INFO - 2019-07-04 22:27:50 --> Model Class Initialized
INFO - 2019-07-04 22:27:50 --> Helper loaded: form_helper
INFO - 2019-07-04 22:27:50 --> Form Validation Class Initialized
DEBUG - 2019-07-04 22:27:50 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 22:27:50 --> Model Class Initialized
INFO - 2019-07-04 22:27:50 --> Model Class Initialized
INFO - 2019-07-04 22:27:50 --> Final output sent to browser
DEBUG - 2019-07-04 22:27:50 --> Total execution time: 0.4314
INFO - 2019-07-04 16:28:23 --> Config Class Initialized
INFO - 2019-07-04 16:28:23 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:28:23 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:28:23 --> Utf8 Class Initialized
INFO - 2019-07-04 16:28:23 --> URI Class Initialized
INFO - 2019-07-04 16:28:23 --> Router Class Initialized
INFO - 2019-07-04 16:28:23 --> Output Class Initialized
INFO - 2019-07-04 16:28:23 --> Security Class Initialized
DEBUG - 2019-07-04 16:28:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:28:23 --> Input Class Initialized
INFO - 2019-07-04 16:28:23 --> Language Class Initialized
INFO - 2019-07-04 16:28:23 --> Language Class Initialized
INFO - 2019-07-04 16:28:23 --> Config Class Initialized
INFO - 2019-07-04 16:28:23 --> Loader Class Initialized
DEBUG - 2019-07-04 16:28:23 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:28:23 --> Helper loaded: url_helper
INFO - 2019-07-04 16:28:23 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:28:23 --> Helper loaded: string_helper
INFO - 2019-07-04 16:28:23 --> Helper loaded: array_helper
INFO - 2019-07-04 16:28:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:28:23 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:28:23 --> Database Driver Class Initialized
INFO - 2019-07-04 16:28:23 --> Controller Class Initialized
INFO - 2019-07-04 22:28:23 --> Helper loaded: language_helper
INFO - 2019-07-04 22:28:23 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:28:23 --> Model Class Initialized
INFO - 2019-07-04 22:28:23 --> Model Class Initialized
INFO - 2019-07-04 22:28:23 --> Model Class Initialized
INFO - 2019-07-04 22:28:23 --> Model Class Initialized
INFO - 2019-07-04 22:28:23 --> Model Class Initialized
INFO - 2019-07-04 22:28:23 --> Final output sent to browser
DEBUG - 2019-07-04 22:28:23 --> Total execution time: 0.3855
INFO - 2019-07-04 16:28:23 --> Config Class Initialized
INFO - 2019-07-04 16:28:23 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:28:23 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:28:23 --> Utf8 Class Initialized
INFO - 2019-07-04 16:28:23 --> URI Class Initialized
INFO - 2019-07-04 16:28:23 --> Router Class Initialized
INFO - 2019-07-04 16:28:23 --> Output Class Initialized
INFO - 2019-07-04 16:28:23 --> Security Class Initialized
DEBUG - 2019-07-04 16:28:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:28:23 --> Input Class Initialized
INFO - 2019-07-04 16:28:23 --> Language Class Initialized
INFO - 2019-07-04 16:28:23 --> Language Class Initialized
INFO - 2019-07-04 16:28:23 --> Config Class Initialized
INFO - 2019-07-04 16:28:23 --> Loader Class Initialized
DEBUG - 2019-07-04 16:28:23 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:28:23 --> Helper loaded: url_helper
INFO - 2019-07-04 16:28:23 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:28:23 --> Helper loaded: string_helper
INFO - 2019-07-04 16:28:23 --> Helper loaded: array_helper
INFO - 2019-07-04 16:28:23 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:28:23 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:28:23 --> Database Driver Class Initialized
INFO - 2019-07-04 16:28:23 --> Controller Class Initialized
INFO - 2019-07-04 22:28:23 --> Helper loaded: language_helper
INFO - 2019-07-04 22:28:23 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:28:23 --> Model Class Initialized
INFO - 2019-07-04 22:28:23 --> Model Class Initialized
INFO - 2019-07-04 22:28:23 --> Model Class Initialized
INFO - 2019-07-04 22:28:23 --> Model Class Initialized
INFO - 2019-07-04 22:28:23 --> Helper loaded: form_helper
INFO - 2019-07-04 22:28:23 --> Form Validation Class Initialized
DEBUG - 2019-07-04 22:28:24 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 22:28:24 --> Model Class Initialized
INFO - 2019-07-04 22:28:24 --> Model Class Initialized
INFO - 2019-07-04 22:28:24 --> Final output sent to browser
DEBUG - 2019-07-04 22:28:24 --> Total execution time: 0.4600
INFO - 2019-07-04 16:28:24 --> Config Class Initialized
INFO - 2019-07-04 16:28:24 --> Config Class Initialized
INFO - 2019-07-04 16:28:24 --> Hooks Class Initialized
INFO - 2019-07-04 16:28:24 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:28:24 --> UTF-8 Support Enabled
DEBUG - 2019-07-04 16:28:24 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:28:24 --> Utf8 Class Initialized
INFO - 2019-07-04 16:28:24 --> Utf8 Class Initialized
INFO - 2019-07-04 16:28:24 --> URI Class Initialized
INFO - 2019-07-04 16:28:24 --> URI Class Initialized
INFO - 2019-07-04 16:28:24 --> Router Class Initialized
INFO - 2019-07-04 16:28:24 --> Router Class Initialized
INFO - 2019-07-04 16:28:24 --> Output Class Initialized
INFO - 2019-07-04 16:28:24 --> Output Class Initialized
INFO - 2019-07-04 16:28:24 --> Security Class Initialized
INFO - 2019-07-04 16:28:24 --> Security Class Initialized
DEBUG - 2019-07-04 16:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:28:24 --> Input Class Initialized
DEBUG - 2019-07-04 16:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:28:24 --> Input Class Initialized
INFO - 2019-07-04 16:28:24 --> Language Class Initialized
INFO - 2019-07-04 16:28:24 --> Config Class Initialized
INFO - 2019-07-04 16:28:24 --> Config Class Initialized
INFO - 2019-07-04 16:28:24 --> Hooks Class Initialized
INFO - 2019-07-04 16:28:24 --> Language Class Initialized
INFO - 2019-07-04 16:28:24 --> Hooks Class Initialized
INFO - 2019-07-04 16:28:24 --> Language Class Initialized
DEBUG - 2019-07-04 16:28:24 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:28:24 --> Language Class Initialized
DEBUG - 2019-07-04 16:28:24 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:28:24 --> Config Class Initialized
INFO - 2019-07-04 16:28:24 --> Utf8 Class Initialized
INFO - 2019-07-04 16:28:24 --> Utf8 Class Initialized
INFO - 2019-07-04 16:28:24 --> Config Class Initialized
INFO - 2019-07-04 16:28:24 --> Loader Class Initialized
INFO - 2019-07-04 16:28:24 --> URI Class Initialized
DEBUG - 2019-07-04 16:28:24 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:28:24 --> Loader Class Initialized
DEBUG - 2019-07-04 16:28:24 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:28:24 --> URI Class Initialized
INFO - 2019-07-04 16:28:24 --> Router Class Initialized
INFO - 2019-07-04 16:28:24 --> Helper loaded: url_helper
INFO - 2019-07-04 16:28:24 --> Router Class Initialized
INFO - 2019-07-04 16:28:24 --> Helper loaded: url_helper
INFO - 2019-07-04 16:28:24 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:28:24 --> Output Class Initialized
INFO - 2019-07-04 16:28:24 --> Output Class Initialized
INFO - 2019-07-04 16:28:24 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:28:24 --> Helper loaded: string_helper
INFO - 2019-07-04 16:28:24 --> Security Class Initialized
INFO - 2019-07-04 16:28:24 --> Helper loaded: string_helper
INFO - 2019-07-04 16:28:24 --> Security Class Initialized
INFO - 2019-07-04 16:28:24 --> Helper loaded: array_helper
DEBUG - 2019-07-04 16:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:28:24 --> Helper loaded: array_helper
DEBUG - 2019-07-04 16:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:28:24 --> Input Class Initialized
INFO - 2019-07-04 16:28:24 --> Session: Class initialized using 'files' driver.
INFO - 2019-07-04 16:28:24 --> Input Class Initialized
INFO - 2019-07-04 16:28:24 --> Language Class Initialized
DEBUG - 2019-07-04 16:28:24 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:28:24 --> Language Class Initialized
INFO - 2019-07-04 16:28:24 --> Language Class Initialized
INFO - 2019-07-04 16:28:24 --> Language Class Initialized
INFO - 2019-07-04 16:28:24 --> Database Driver Class Initialized
INFO - 2019-07-04 16:28:24 --> Config Class Initialized
INFO - 2019-07-04 16:28:24 --> Config Class Initialized
INFO - 2019-07-04 16:28:24 --> Loader Class Initialized
INFO - 2019-07-04 16:28:25 --> Controller Class Initialized
INFO - 2019-07-04 16:28:25 --> Loader Class Initialized
DEBUG - 2019-07-04 16:28:25 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 22:28:25 --> Helper loaded: language_helper
INFO - 2019-07-04 16:28:25 --> Helper loaded: url_helper
DEBUG - 2019-07-04 16:28:25 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 22:28:25 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 16:28:25 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:28:25 --> Helper loaded: url_helper
INFO - 2019-07-04 22:28:25 --> Model Class Initialized
INFO - 2019-07-04 16:28:25 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:28:25 --> Helper loaded: string_helper
INFO - 2019-07-04 22:28:25 --> Model Class Initialized
INFO - 2019-07-04 16:28:25 --> Helper loaded: string_helper
INFO - 2019-07-04 16:28:25 --> Helper loaded: array_helper
INFO - 2019-07-04 22:28:25 --> Model Class Initialized
INFO - 2019-07-04 16:28:25 --> Helper loaded: array_helper
INFO - 2019-07-04 22:28:25 --> Model Class Initialized
INFO - 2019-07-04 22:28:25 --> Helper loaded: form_helper
INFO - 2019-07-04 22:28:25 --> Form Validation Class Initialized
DEBUG - 2019-07-04 22:28:25 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 22:28:25 --> Model Class Initialized
INFO - 2019-07-04 22:28:25 --> Model Class Initialized
INFO - 2019-07-04 22:28:25 --> Final output sent to browser
DEBUG - 2019-07-04 22:28:25 --> Total execution time: 0.8484
INFO - 2019-07-04 16:28:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:28:25 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:28:25 --> Database Driver Class Initialized
INFO - 2019-07-04 16:28:25 --> Controller Class Initialized
INFO - 2019-07-04 22:28:25 --> Helper loaded: language_helper
INFO - 2019-07-04 22:28:25 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:28:25 --> Model Class Initialized
INFO - 2019-07-04 22:28:25 --> Model Class Initialized
INFO - 2019-07-04 22:28:25 --> Model Class Initialized
INFO - 2019-07-04 22:28:25 --> Model Class Initialized
INFO - 2019-07-04 22:28:25 --> Model Class Initialized
INFO - 2019-07-04 22:28:25 --> Final output sent to browser
DEBUG - 2019-07-04 22:28:25 --> Total execution time: 1.0322
INFO - 2019-07-04 16:28:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:28:25 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:28:25 --> Database Driver Class Initialized
INFO - 2019-07-04 16:28:25 --> Controller Class Initialized
INFO - 2019-07-04 22:28:25 --> Helper loaded: language_helper
INFO - 2019-07-04 22:28:25 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:28:25 --> Model Class Initialized
INFO - 2019-07-04 22:28:25 --> Model Class Initialized
INFO - 2019-07-04 22:28:25 --> Model Class Initialized
INFO - 2019-07-04 22:28:25 --> Model Class Initialized
INFO - 2019-07-04 22:28:25 --> Helper loaded: form_helper
INFO - 2019-07-04 22:28:25 --> Form Validation Class Initialized
DEBUG - 2019-07-04 22:28:25 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 22:28:25 --> Model Class Initialized
INFO - 2019-07-04 22:28:25 --> Model Class Initialized
INFO - 2019-07-04 22:28:25 --> Final output sent to browser
DEBUG - 2019-07-04 22:28:25 --> Total execution time: 0.9463
INFO - 2019-07-04 16:28:25 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:28:25 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:28:25 --> Database Driver Class Initialized
INFO - 2019-07-04 16:28:25 --> Controller Class Initialized
INFO - 2019-07-04 22:28:25 --> Helper loaded: language_helper
INFO - 2019-07-04 22:28:25 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:28:25 --> Model Class Initialized
INFO - 2019-07-04 22:28:25 --> Model Class Initialized
INFO - 2019-07-04 22:28:25 --> Model Class Initialized
INFO - 2019-07-04 22:28:25 --> Model Class Initialized
INFO - 2019-07-04 22:28:25 --> Model Class Initialized
INFO - 2019-07-04 22:28:25 --> Final output sent to browser
DEBUG - 2019-07-04 22:28:25 --> Total execution time: 1.1344
INFO - 2019-07-04 16:31:56 --> Config Class Initialized
INFO - 2019-07-04 16:31:56 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:31:56 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:31:56 --> Utf8 Class Initialized
INFO - 2019-07-04 16:31:56 --> URI Class Initialized
INFO - 2019-07-04 16:31:56 --> Router Class Initialized
INFO - 2019-07-04 16:31:56 --> Output Class Initialized
INFO - 2019-07-04 16:31:56 --> Security Class Initialized
DEBUG - 2019-07-04 16:31:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:31:56 --> Input Class Initialized
INFO - 2019-07-04 16:31:56 --> Language Class Initialized
INFO - 2019-07-04 16:31:56 --> Language Class Initialized
INFO - 2019-07-04 16:31:56 --> Config Class Initialized
INFO - 2019-07-04 16:31:56 --> Loader Class Initialized
DEBUG - 2019-07-04 16:31:56 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:31:56 --> Helper loaded: url_helper
INFO - 2019-07-04 16:31:56 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:31:56 --> Helper loaded: string_helper
INFO - 2019-07-04 16:31:56 --> Helper loaded: array_helper
INFO - 2019-07-04 16:31:56 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:31:56 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:31:56 --> Database Driver Class Initialized
INFO - 2019-07-04 16:31:56 --> Controller Class Initialized
INFO - 2019-07-04 22:31:56 --> Helper loaded: language_helper
INFO - 2019-07-04 22:31:56 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:31:56 --> Model Class Initialized
INFO - 2019-07-04 22:31:56 --> Model Class Initialized
INFO - 2019-07-04 22:31:56 --> Model Class Initialized
INFO - 2019-07-04 22:31:56 --> Model Class Initialized
INFO - 2019-07-04 22:31:56 --> Model Class Initialized
INFO - 2019-07-04 22:31:56 --> Final output sent to browser
DEBUG - 2019-07-04 22:31:56 --> Total execution time: 0.3911
INFO - 2019-07-04 16:31:56 --> Config Class Initialized
INFO - 2019-07-04 16:31:56 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:31:56 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:31:56 --> Utf8 Class Initialized
INFO - 2019-07-04 16:31:56 --> URI Class Initialized
INFO - 2019-07-04 16:31:56 --> Router Class Initialized
INFO - 2019-07-04 16:31:56 --> Output Class Initialized
INFO - 2019-07-04 16:31:56 --> Security Class Initialized
DEBUG - 2019-07-04 16:31:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:31:56 --> Input Class Initialized
INFO - 2019-07-04 16:31:56 --> Language Class Initialized
INFO - 2019-07-04 16:31:56 --> Language Class Initialized
INFO - 2019-07-04 16:31:56 --> Config Class Initialized
INFO - 2019-07-04 16:31:56 --> Loader Class Initialized
DEBUG - 2019-07-04 16:31:56 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:31:56 --> Helper loaded: url_helper
INFO - 2019-07-04 16:31:56 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:31:56 --> Helper loaded: string_helper
INFO - 2019-07-04 16:31:56 --> Helper loaded: array_helper
INFO - 2019-07-04 16:31:56 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:31:56 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:31:56 --> Database Driver Class Initialized
INFO - 2019-07-04 16:31:56 --> Controller Class Initialized
INFO - 2019-07-04 22:31:57 --> Helper loaded: language_helper
INFO - 2019-07-04 22:31:57 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:31:57 --> Model Class Initialized
INFO - 2019-07-04 22:31:57 --> Model Class Initialized
INFO - 2019-07-04 22:31:57 --> Model Class Initialized
INFO - 2019-07-04 22:31:57 --> Model Class Initialized
INFO - 2019-07-04 22:31:57 --> Helper loaded: form_helper
INFO - 2019-07-04 22:31:57 --> Form Validation Class Initialized
DEBUG - 2019-07-04 22:31:57 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 22:31:57 --> Model Class Initialized
INFO - 2019-07-04 22:31:57 --> Model Class Initialized
INFO - 2019-07-04 22:31:57 --> Final output sent to browser
DEBUG - 2019-07-04 22:31:57 --> Total execution time: 0.4377
INFO - 2019-07-04 16:31:57 --> Config Class Initialized
INFO - 2019-07-04 16:31:57 --> Hooks Class Initialized
INFO - 2019-07-04 16:31:57 --> Config Class Initialized
INFO - 2019-07-04 16:31:57 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:31:57 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:31:57 --> Utf8 Class Initialized
DEBUG - 2019-07-04 16:31:57 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:31:57 --> Utf8 Class Initialized
INFO - 2019-07-04 16:31:57 --> URI Class Initialized
INFO - 2019-07-04 16:31:57 --> URI Class Initialized
INFO - 2019-07-04 16:31:57 --> Router Class Initialized
INFO - 2019-07-04 16:31:57 --> Router Class Initialized
INFO - 2019-07-04 16:31:57 --> Output Class Initialized
INFO - 2019-07-04 16:31:58 --> Output Class Initialized
INFO - 2019-07-04 16:31:58 --> Security Class Initialized
INFO - 2019-07-04 16:31:58 --> Security Class Initialized
DEBUG - 2019-07-04 16:31:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-04 16:31:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:31:58 --> Input Class Initialized
INFO - 2019-07-04 16:31:58 --> Input Class Initialized
INFO - 2019-07-04 16:31:58 --> Language Class Initialized
INFO - 2019-07-04 16:31:58 --> Language Class Initialized
INFO - 2019-07-04 16:31:58 --> Language Class Initialized
INFO - 2019-07-04 16:31:58 --> Language Class Initialized
INFO - 2019-07-04 16:31:58 --> Config Class Initialized
INFO - 2019-07-04 16:31:58 --> Config Class Initialized
INFO - 2019-07-04 16:31:58 --> Loader Class Initialized
INFO - 2019-07-04 16:31:58 --> Loader Class Initialized
DEBUG - 2019-07-04 16:31:58 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-04 16:31:58 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:31:58 --> Helper loaded: url_helper
INFO - 2019-07-04 16:31:58 --> Helper loaded: url_helper
INFO - 2019-07-04 16:31:58 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:31:58 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:31:58 --> Helper loaded: string_helper
INFO - 2019-07-04 16:31:58 --> Helper loaded: string_helper
INFO - 2019-07-04 16:31:58 --> Helper loaded: array_helper
INFO - 2019-07-04 16:31:58 --> Helper loaded: array_helper
INFO - 2019-07-04 16:31:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:31:58 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:31:58 --> Database Driver Class Initialized
INFO - 2019-07-04 16:31:58 --> Controller Class Initialized
INFO - 2019-07-04 22:31:58 --> Helper loaded: language_helper
INFO - 2019-07-04 22:31:58 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:31:58 --> Model Class Initialized
INFO - 2019-07-04 22:31:58 --> Model Class Initialized
INFO - 2019-07-04 22:31:58 --> Model Class Initialized
INFO - 2019-07-04 22:31:58 --> Model Class Initialized
INFO - 2019-07-04 22:31:58 --> Model Class Initialized
INFO - 2019-07-04 22:31:58 --> Final output sent to browser
DEBUG - 2019-07-04 22:31:58 --> Total execution time: 0.6227
INFO - 2019-07-04 16:31:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:31:58 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:31:58 --> Database Driver Class Initialized
INFO - 2019-07-04 16:31:58 --> Controller Class Initialized
INFO - 2019-07-04 22:31:58 --> Helper loaded: language_helper
INFO - 2019-07-04 22:31:58 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:31:58 --> Model Class Initialized
INFO - 2019-07-04 22:31:58 --> Model Class Initialized
INFO - 2019-07-04 22:31:58 --> Model Class Initialized
INFO - 2019-07-04 22:31:58 --> Model Class Initialized
INFO - 2019-07-04 22:31:58 --> Helper loaded: form_helper
INFO - 2019-07-04 22:31:58 --> Form Validation Class Initialized
DEBUG - 2019-07-04 22:31:58 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 22:31:58 --> Model Class Initialized
INFO - 2019-07-04 22:31:58 --> Model Class Initialized
INFO - 2019-07-04 22:31:58 --> Final output sent to browser
DEBUG - 2019-07-04 22:31:58 --> Total execution time: 0.8403
INFO - 2019-07-04 16:32:33 --> Config Class Initialized
INFO - 2019-07-04 16:32:33 --> Config Class Initialized
INFO - 2019-07-04 16:32:33 --> Hooks Class Initialized
INFO - 2019-07-04 16:32:33 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:32:33 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:32:33 --> Utf8 Class Initialized
DEBUG - 2019-07-04 16:32:33 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:32:34 --> Utf8 Class Initialized
INFO - 2019-07-04 16:32:34 --> URI Class Initialized
INFO - 2019-07-04 16:32:34 --> URI Class Initialized
INFO - 2019-07-04 16:32:34 --> Router Class Initialized
INFO - 2019-07-04 16:32:34 --> Router Class Initialized
INFO - 2019-07-04 16:32:34 --> Output Class Initialized
INFO - 2019-07-04 16:32:34 --> Output Class Initialized
INFO - 2019-07-04 16:32:34 --> Security Class Initialized
INFO - 2019-07-04 16:32:34 --> Security Class Initialized
DEBUG - 2019-07-04 16:32:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-04 16:32:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:32:34 --> Input Class Initialized
INFO - 2019-07-04 16:32:34 --> Input Class Initialized
INFO - 2019-07-04 16:32:34 --> Language Class Initialized
INFO - 2019-07-04 16:32:34 --> Language Class Initialized
INFO - 2019-07-04 16:32:34 --> Language Class Initialized
INFO - 2019-07-04 16:32:34 --> Language Class Initialized
INFO - 2019-07-04 16:32:34 --> Config Class Initialized
INFO - 2019-07-04 16:32:34 --> Config Class Initialized
INFO - 2019-07-04 16:32:34 --> Loader Class Initialized
INFO - 2019-07-04 16:32:34 --> Loader Class Initialized
DEBUG - 2019-07-04 16:32:34 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-04 16:32:34 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:32:34 --> Helper loaded: url_helper
INFO - 2019-07-04 16:32:34 --> Helper loaded: url_helper
INFO - 2019-07-04 16:32:34 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:32:34 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:32:34 --> Helper loaded: string_helper
INFO - 2019-07-04 16:32:34 --> Helper loaded: string_helper
INFO - 2019-07-04 16:32:34 --> Helper loaded: array_helper
INFO - 2019-07-04 16:32:34 --> Helper loaded: array_helper
INFO - 2019-07-04 16:32:34 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:32:34 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:32:34 --> Database Driver Class Initialized
INFO - 2019-07-04 16:32:34 --> Controller Class Initialized
INFO - 2019-07-04 22:32:34 --> Helper loaded: language_helper
INFO - 2019-07-04 22:32:34 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:32:34 --> Model Class Initialized
INFO - 2019-07-04 22:32:34 --> Model Class Initialized
INFO - 2019-07-04 22:32:34 --> Model Class Initialized
INFO - 2019-07-04 22:32:34 --> Model Class Initialized
INFO - 2019-07-04 22:32:34 --> Model Class Initialized
INFO - 2019-07-04 22:32:34 --> Final output sent to browser
DEBUG - 2019-07-04 22:32:34 --> Total execution time: 0.5778
INFO - 2019-07-04 16:32:34 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:32:34 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:32:34 --> Database Driver Class Initialized
INFO - 2019-07-04 16:32:34 --> Controller Class Initialized
INFO - 2019-07-04 22:32:34 --> Helper loaded: language_helper
INFO - 2019-07-04 22:32:34 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:32:34 --> Model Class Initialized
INFO - 2019-07-04 22:32:34 --> Model Class Initialized
INFO - 2019-07-04 22:32:34 --> Model Class Initialized
INFO - 2019-07-04 22:32:34 --> Model Class Initialized
INFO - 2019-07-04 22:32:34 --> Helper loaded: form_helper
INFO - 2019-07-04 22:32:34 --> Form Validation Class Initialized
DEBUG - 2019-07-04 22:32:34 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 22:32:34 --> Model Class Initialized
INFO - 2019-07-04 22:32:34 --> Model Class Initialized
INFO - 2019-07-04 22:32:34 --> Final output sent to browser
DEBUG - 2019-07-04 22:32:34 --> Total execution time: 0.7952
INFO - 2019-07-04 16:32:35 --> Config Class Initialized
INFO - 2019-07-04 16:32:35 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:32:35 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:32:35 --> Utf8 Class Initialized
INFO - 2019-07-04 16:32:35 --> URI Class Initialized
INFO - 2019-07-04 16:32:35 --> Router Class Initialized
INFO - 2019-07-04 16:32:35 --> Output Class Initialized
INFO - 2019-07-04 16:32:35 --> Security Class Initialized
DEBUG - 2019-07-04 16:32:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:32:35 --> Input Class Initialized
INFO - 2019-07-04 16:32:35 --> Language Class Initialized
INFO - 2019-07-04 16:32:35 --> Language Class Initialized
INFO - 2019-07-04 16:32:35 --> Config Class Initialized
INFO - 2019-07-04 16:32:35 --> Loader Class Initialized
DEBUG - 2019-07-04 16:32:35 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:32:35 --> Helper loaded: url_helper
INFO - 2019-07-04 16:32:35 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:32:35 --> Helper loaded: string_helper
INFO - 2019-07-04 16:32:35 --> Helper loaded: array_helper
INFO - 2019-07-04 16:32:35 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:32:35 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:32:35 --> Database Driver Class Initialized
INFO - 2019-07-04 16:32:35 --> Controller Class Initialized
INFO - 2019-07-04 22:32:35 --> Helper loaded: language_helper
INFO - 2019-07-04 22:32:35 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:32:35 --> Model Class Initialized
INFO - 2019-07-04 22:32:35 --> Model Class Initialized
INFO - 2019-07-04 22:32:35 --> Model Class Initialized
INFO - 2019-07-04 22:32:35 --> Model Class Initialized
INFO - 2019-07-04 22:32:35 --> Model Class Initialized
INFO - 2019-07-04 22:32:35 --> Final output sent to browser
DEBUG - 2019-07-04 22:32:35 --> Total execution time: 0.3837
INFO - 2019-07-04 16:32:35 --> Config Class Initialized
INFO - 2019-07-04 16:32:35 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:32:35 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:32:35 --> Utf8 Class Initialized
INFO - 2019-07-04 16:32:35 --> URI Class Initialized
INFO - 2019-07-04 16:32:35 --> Router Class Initialized
INFO - 2019-07-04 16:32:35 --> Output Class Initialized
INFO - 2019-07-04 16:32:35 --> Security Class Initialized
DEBUG - 2019-07-04 16:32:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:32:35 --> Input Class Initialized
INFO - 2019-07-04 16:32:35 --> Language Class Initialized
INFO - 2019-07-04 16:32:35 --> Language Class Initialized
INFO - 2019-07-04 16:32:36 --> Config Class Initialized
INFO - 2019-07-04 16:32:36 --> Loader Class Initialized
DEBUG - 2019-07-04 16:32:36 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:32:36 --> Helper loaded: url_helper
INFO - 2019-07-04 16:32:36 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:32:36 --> Helper loaded: string_helper
INFO - 2019-07-04 16:32:36 --> Helper loaded: array_helper
INFO - 2019-07-04 16:32:36 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:32:36 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:32:36 --> Database Driver Class Initialized
INFO - 2019-07-04 16:32:36 --> Controller Class Initialized
INFO - 2019-07-04 22:32:36 --> Helper loaded: language_helper
INFO - 2019-07-04 22:32:36 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:32:36 --> Model Class Initialized
INFO - 2019-07-04 22:32:36 --> Model Class Initialized
INFO - 2019-07-04 22:32:36 --> Model Class Initialized
INFO - 2019-07-04 22:32:36 --> Model Class Initialized
INFO - 2019-07-04 22:32:36 --> Helper loaded: form_helper
INFO - 2019-07-04 22:32:36 --> Form Validation Class Initialized
DEBUG - 2019-07-04 22:32:36 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 22:32:36 --> Model Class Initialized
INFO - 2019-07-04 22:32:36 --> Model Class Initialized
INFO - 2019-07-04 22:32:36 --> Final output sent to browser
DEBUG - 2019-07-04 22:32:36 --> Total execution time: 0.4555
INFO - 2019-07-04 16:33:03 --> Config Class Initialized
INFO - 2019-07-04 16:33:03 --> Config Class Initialized
INFO - 2019-07-04 16:33:03 --> Hooks Class Initialized
INFO - 2019-07-04 16:33:03 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:33:04 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:33:04 --> Utf8 Class Initialized
DEBUG - 2019-07-04 16:33:04 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:33:04 --> Utf8 Class Initialized
INFO - 2019-07-04 16:33:04 --> URI Class Initialized
INFO - 2019-07-04 16:33:04 --> URI Class Initialized
INFO - 2019-07-04 16:33:04 --> Router Class Initialized
INFO - 2019-07-04 16:33:04 --> Router Class Initialized
INFO - 2019-07-04 16:33:04 --> Output Class Initialized
INFO - 2019-07-04 16:33:04 --> Output Class Initialized
INFO - 2019-07-04 16:33:04 --> Security Class Initialized
INFO - 2019-07-04 16:33:04 --> Security Class Initialized
DEBUG - 2019-07-04 16:33:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-04 16:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:33:04 --> Input Class Initialized
INFO - 2019-07-04 16:33:04 --> Input Class Initialized
INFO - 2019-07-04 16:33:04 --> Language Class Initialized
INFO - 2019-07-04 16:33:04 --> Language Class Initialized
INFO - 2019-07-04 16:33:04 --> Language Class Initialized
INFO - 2019-07-04 16:33:04 --> Language Class Initialized
INFO - 2019-07-04 16:33:04 --> Config Class Initialized
INFO - 2019-07-04 16:33:04 --> Config Class Initialized
INFO - 2019-07-04 16:33:04 --> Loader Class Initialized
INFO - 2019-07-04 16:33:04 --> Loader Class Initialized
DEBUG - 2019-07-04 16:33:04 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-04 16:33:04 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:33:04 --> Helper loaded: url_helper
INFO - 2019-07-04 16:33:04 --> Helper loaded: url_helper
INFO - 2019-07-04 16:33:04 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:33:04 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:33:04 --> Helper loaded: string_helper
INFO - 2019-07-04 16:33:04 --> Helper loaded: string_helper
INFO - 2019-07-04 16:33:04 --> Helper loaded: array_helper
INFO - 2019-07-04 16:33:04 --> Helper loaded: array_helper
INFO - 2019-07-04 16:33:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:33:04 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:33:04 --> Database Driver Class Initialized
INFO - 2019-07-04 16:33:04 --> Controller Class Initialized
INFO - 2019-07-04 22:33:04 --> Helper loaded: language_helper
INFO - 2019-07-04 22:33:04 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:33:04 --> Model Class Initialized
INFO - 2019-07-04 22:33:04 --> Model Class Initialized
INFO - 2019-07-04 22:33:04 --> Model Class Initialized
INFO - 2019-07-04 22:33:04 --> Model Class Initialized
INFO - 2019-07-04 22:33:04 --> Helper loaded: form_helper
INFO - 2019-07-04 22:33:04 --> Form Validation Class Initialized
DEBUG - 2019-07-04 22:33:04 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 22:33:04 --> Model Class Initialized
INFO - 2019-07-04 22:33:04 --> Model Class Initialized
INFO - 2019-07-04 22:33:04 --> Final output sent to browser
DEBUG - 2019-07-04 22:33:04 --> Total execution time: 0.6676
INFO - 2019-07-04 16:33:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:33:04 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:33:04 --> Database Driver Class Initialized
INFO - 2019-07-04 16:33:04 --> Controller Class Initialized
INFO - 2019-07-04 22:33:04 --> Helper loaded: language_helper
INFO - 2019-07-04 22:33:04 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:33:04 --> Model Class Initialized
INFO - 2019-07-04 22:33:04 --> Model Class Initialized
INFO - 2019-07-04 22:33:04 --> Model Class Initialized
INFO - 2019-07-04 22:33:04 --> Model Class Initialized
INFO - 2019-07-04 22:33:04 --> Model Class Initialized
INFO - 2019-07-04 22:33:04 --> Final output sent to browser
DEBUG - 2019-07-04 22:33:04 --> Total execution time: 0.8543
INFO - 2019-07-04 16:33:05 --> Config Class Initialized
INFO - 2019-07-04 16:33:05 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:33:05 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:33:05 --> Utf8 Class Initialized
INFO - 2019-07-04 16:33:05 --> URI Class Initialized
INFO - 2019-07-04 16:33:05 --> Router Class Initialized
INFO - 2019-07-04 16:33:05 --> Output Class Initialized
INFO - 2019-07-04 16:33:05 --> Security Class Initialized
DEBUG - 2019-07-04 16:33:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:33:05 --> Input Class Initialized
INFO - 2019-07-04 16:33:05 --> Language Class Initialized
INFO - 2019-07-04 16:33:05 --> Language Class Initialized
INFO - 2019-07-04 16:33:05 --> Config Class Initialized
INFO - 2019-07-04 16:33:05 --> Loader Class Initialized
DEBUG - 2019-07-04 16:33:05 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:33:05 --> Helper loaded: url_helper
INFO - 2019-07-04 16:33:05 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:33:05 --> Helper loaded: string_helper
INFO - 2019-07-04 16:33:05 --> Helper loaded: array_helper
INFO - 2019-07-04 16:33:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:33:05 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:33:05 --> Database Driver Class Initialized
INFO - 2019-07-04 16:33:05 --> Controller Class Initialized
INFO - 2019-07-04 22:33:05 --> Helper loaded: language_helper
INFO - 2019-07-04 22:33:05 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:33:05 --> Model Class Initialized
INFO - 2019-07-04 22:33:05 --> Model Class Initialized
INFO - 2019-07-04 22:33:05 --> Model Class Initialized
INFO - 2019-07-04 22:33:05 --> Model Class Initialized
INFO - 2019-07-04 22:33:05 --> Model Class Initialized
INFO - 2019-07-04 22:33:05 --> Final output sent to browser
DEBUG - 2019-07-04 22:33:05 --> Total execution time: 0.4018
INFO - 2019-07-04 16:33:05 --> Config Class Initialized
INFO - 2019-07-04 16:33:05 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:33:06 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:33:06 --> Utf8 Class Initialized
INFO - 2019-07-04 16:33:06 --> URI Class Initialized
INFO - 2019-07-04 16:33:06 --> Router Class Initialized
INFO - 2019-07-04 16:33:06 --> Output Class Initialized
INFO - 2019-07-04 16:33:06 --> Security Class Initialized
DEBUG - 2019-07-04 16:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:33:06 --> Input Class Initialized
INFO - 2019-07-04 16:33:06 --> Language Class Initialized
INFO - 2019-07-04 16:33:06 --> Language Class Initialized
INFO - 2019-07-04 16:33:06 --> Config Class Initialized
INFO - 2019-07-04 16:33:06 --> Loader Class Initialized
DEBUG - 2019-07-04 16:33:06 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:33:06 --> Helper loaded: url_helper
INFO - 2019-07-04 16:33:06 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:33:06 --> Helper loaded: string_helper
INFO - 2019-07-04 16:33:06 --> Helper loaded: array_helper
INFO - 2019-07-04 16:33:06 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:33:06 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:33:06 --> Database Driver Class Initialized
INFO - 2019-07-04 16:33:06 --> Controller Class Initialized
INFO - 2019-07-04 22:33:06 --> Helper loaded: language_helper
INFO - 2019-07-04 22:33:06 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:33:06 --> Model Class Initialized
INFO - 2019-07-04 22:33:06 --> Model Class Initialized
INFO - 2019-07-04 22:33:06 --> Model Class Initialized
INFO - 2019-07-04 22:33:06 --> Model Class Initialized
INFO - 2019-07-04 22:33:06 --> Helper loaded: form_helper
INFO - 2019-07-04 22:33:06 --> Form Validation Class Initialized
DEBUG - 2019-07-04 22:33:06 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 22:33:06 --> Model Class Initialized
INFO - 2019-07-04 22:33:06 --> Model Class Initialized
INFO - 2019-07-04 22:33:06 --> Final output sent to browser
DEBUG - 2019-07-04 22:33:06 --> Total execution time: 0.4701
INFO - 2019-07-04 16:34:28 --> Config Class Initialized
INFO - 2019-07-04 16:34:28 --> Config Class Initialized
INFO - 2019-07-04 16:34:28 --> Hooks Class Initialized
INFO - 2019-07-04 16:34:28 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:34:28 --> UTF-8 Support Enabled
DEBUG - 2019-07-04 16:34:28 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:34:28 --> Utf8 Class Initialized
INFO - 2019-07-04 16:34:28 --> Utf8 Class Initialized
INFO - 2019-07-04 16:34:28 --> URI Class Initialized
INFO - 2019-07-04 16:34:28 --> URI Class Initialized
INFO - 2019-07-04 16:34:28 --> Router Class Initialized
INFO - 2019-07-04 16:34:28 --> Router Class Initialized
INFO - 2019-07-04 16:34:28 --> Output Class Initialized
INFO - 2019-07-04 16:34:28 --> Output Class Initialized
INFO - 2019-07-04 16:34:28 --> Security Class Initialized
INFO - 2019-07-04 16:34:28 --> Security Class Initialized
DEBUG - 2019-07-04 16:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:34:28 --> Input Class Initialized
DEBUG - 2019-07-04 16:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:34:28 --> Language Class Initialized
INFO - 2019-07-04 16:34:28 --> Input Class Initialized
INFO - 2019-07-04 16:34:28 --> Language Class Initialized
INFO - 2019-07-04 16:34:28 --> Language Class Initialized
INFO - 2019-07-04 16:34:28 --> Language Class Initialized
INFO - 2019-07-04 16:34:28 --> Config Class Initialized
INFO - 2019-07-04 16:34:28 --> Loader Class Initialized
INFO - 2019-07-04 16:34:28 --> Config Class Initialized
INFO - 2019-07-04 16:34:28 --> Loader Class Initialized
DEBUG - 2019-07-04 16:34:28 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-04 16:34:28 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:34:28 --> Helper loaded: url_helper
INFO - 2019-07-04 16:34:28 --> Helper loaded: url_helper
INFO - 2019-07-04 16:34:28 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:34:28 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:34:28 --> Helper loaded: string_helper
INFO - 2019-07-04 16:34:28 --> Helper loaded: string_helper
INFO - 2019-07-04 16:34:28 --> Helper loaded: array_helper
INFO - 2019-07-04 16:34:28 --> Helper loaded: array_helper
INFO - 2019-07-04 16:34:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:34:28 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:34:28 --> Database Driver Class Initialized
INFO - 2019-07-04 16:34:28 --> Controller Class Initialized
INFO - 2019-07-04 22:34:28 --> Helper loaded: language_helper
INFO - 2019-07-04 22:34:28 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:34:28 --> Model Class Initialized
INFO - 2019-07-04 22:34:28 --> Model Class Initialized
INFO - 2019-07-04 22:34:28 --> Model Class Initialized
INFO - 2019-07-04 22:34:28 --> Model Class Initialized
INFO - 2019-07-04 22:34:28 --> Model Class Initialized
INFO - 2019-07-04 22:34:28 --> Final output sent to browser
DEBUG - 2019-07-04 22:34:28 --> Total execution time: 0.6932
INFO - 2019-07-04 16:34:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:34:28 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:34:28 --> Database Driver Class Initialized
INFO - 2019-07-04 16:34:28 --> Controller Class Initialized
INFO - 2019-07-04 22:34:28 --> Helper loaded: language_helper
INFO - 2019-07-04 22:34:28 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:34:28 --> Model Class Initialized
INFO - 2019-07-04 22:34:28 --> Model Class Initialized
INFO - 2019-07-04 22:34:28 --> Model Class Initialized
INFO - 2019-07-04 22:34:28 --> Model Class Initialized
INFO - 2019-07-04 22:34:29 --> Helper loaded: form_helper
INFO - 2019-07-04 22:34:29 --> Form Validation Class Initialized
DEBUG - 2019-07-04 22:34:29 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 22:34:29 --> Model Class Initialized
INFO - 2019-07-04 22:34:29 --> Model Class Initialized
INFO - 2019-07-04 22:34:29 --> Final output sent to browser
DEBUG - 2019-07-04 22:34:29 --> Total execution time: 0.9418
INFO - 2019-07-04 16:34:29 --> Config Class Initialized
INFO - 2019-07-04 16:34:29 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:34:29 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:34:29 --> Utf8 Class Initialized
INFO - 2019-07-04 16:34:29 --> URI Class Initialized
INFO - 2019-07-04 16:34:29 --> Router Class Initialized
INFO - 2019-07-04 16:34:29 --> Output Class Initialized
INFO - 2019-07-04 16:34:29 --> Security Class Initialized
DEBUG - 2019-07-04 16:34:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:34:29 --> Input Class Initialized
INFO - 2019-07-04 16:34:29 --> Language Class Initialized
INFO - 2019-07-04 16:34:29 --> Language Class Initialized
INFO - 2019-07-04 16:34:29 --> Config Class Initialized
INFO - 2019-07-04 16:34:29 --> Loader Class Initialized
DEBUG - 2019-07-04 16:34:29 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:34:29 --> Helper loaded: url_helper
INFO - 2019-07-04 16:34:29 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:34:29 --> Helper loaded: string_helper
INFO - 2019-07-04 16:34:29 --> Helper loaded: array_helper
INFO - 2019-07-04 16:34:29 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:34:29 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:34:29 --> Database Driver Class Initialized
INFO - 2019-07-04 16:34:29 --> Controller Class Initialized
INFO - 2019-07-04 22:34:29 --> Helper loaded: language_helper
INFO - 2019-07-04 22:34:30 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:34:30 --> Model Class Initialized
INFO - 2019-07-04 22:34:30 --> Model Class Initialized
INFO - 2019-07-04 22:34:30 --> Model Class Initialized
INFO - 2019-07-04 22:34:30 --> Model Class Initialized
INFO - 2019-07-04 22:34:30 --> Model Class Initialized
INFO - 2019-07-04 22:34:30 --> Final output sent to browser
DEBUG - 2019-07-04 22:34:30 --> Total execution time: 0.4239
INFO - 2019-07-04 16:34:30 --> Config Class Initialized
INFO - 2019-07-04 16:34:30 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:34:30 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:34:30 --> Utf8 Class Initialized
INFO - 2019-07-04 16:34:30 --> URI Class Initialized
INFO - 2019-07-04 16:34:30 --> Router Class Initialized
INFO - 2019-07-04 16:34:30 --> Output Class Initialized
INFO - 2019-07-04 16:34:30 --> Security Class Initialized
DEBUG - 2019-07-04 16:34:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:34:30 --> Input Class Initialized
INFO - 2019-07-04 16:34:30 --> Language Class Initialized
INFO - 2019-07-04 16:34:30 --> Language Class Initialized
INFO - 2019-07-04 16:34:30 --> Config Class Initialized
INFO - 2019-07-04 16:34:30 --> Loader Class Initialized
DEBUG - 2019-07-04 16:34:30 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:34:30 --> Helper loaded: url_helper
INFO - 2019-07-04 16:34:30 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:34:30 --> Helper loaded: string_helper
INFO - 2019-07-04 16:34:30 --> Helper loaded: array_helper
INFO - 2019-07-04 16:34:30 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:34:30 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:34:30 --> Database Driver Class Initialized
INFO - 2019-07-04 16:34:30 --> Controller Class Initialized
INFO - 2019-07-04 22:34:30 --> Helper loaded: language_helper
INFO - 2019-07-04 22:34:30 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:34:30 --> Model Class Initialized
INFO - 2019-07-04 22:34:30 --> Model Class Initialized
INFO - 2019-07-04 22:34:30 --> Model Class Initialized
INFO - 2019-07-04 22:34:30 --> Model Class Initialized
INFO - 2019-07-04 22:34:30 --> Helper loaded: form_helper
INFO - 2019-07-04 22:34:30 --> Form Validation Class Initialized
DEBUG - 2019-07-04 22:34:30 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 22:34:30 --> Model Class Initialized
INFO - 2019-07-04 22:34:30 --> Model Class Initialized
INFO - 2019-07-04 22:34:30 --> Final output sent to browser
DEBUG - 2019-07-04 22:34:30 --> Total execution time: 0.4960
INFO - 2019-07-04 16:38:02 --> Config Class Initialized
INFO - 2019-07-04 16:38:02 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:38:02 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:38:02 --> Utf8 Class Initialized
INFO - 2019-07-04 16:38:02 --> URI Class Initialized
INFO - 2019-07-04 16:38:02 --> Router Class Initialized
INFO - 2019-07-04 16:38:02 --> Output Class Initialized
INFO - 2019-07-04 16:38:02 --> Security Class Initialized
DEBUG - 2019-07-04 16:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:38:02 --> Config Class Initialized
INFO - 2019-07-04 16:38:02 --> Input Class Initialized
INFO - 2019-07-04 16:38:02 --> Config Class Initialized
INFO - 2019-07-04 16:38:02 --> Hooks Class Initialized
INFO - 2019-07-04 16:38:02 --> Language Class Initialized
INFO - 2019-07-04 16:38:02 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:38:02 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:38:03 --> Language Class Initialized
DEBUG - 2019-07-04 16:38:03 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:38:03 --> Utf8 Class Initialized
INFO - 2019-07-04 16:38:03 --> Config Class Initialized
INFO - 2019-07-04 16:38:03 --> Utf8 Class Initialized
INFO - 2019-07-04 16:38:03 --> URI Class Initialized
INFO - 2019-07-04 16:38:03 --> Loader Class Initialized
DEBUG - 2019-07-04 16:38:03 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:38:03 --> Router Class Initialized
INFO - 2019-07-04 16:38:03 --> URI Class Initialized
INFO - 2019-07-04 16:38:03 --> Helper loaded: url_helper
INFO - 2019-07-04 16:38:03 --> Router Class Initialized
INFO - 2019-07-04 16:38:03 --> Output Class Initialized
INFO - 2019-07-04 16:38:03 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:38:03 --> Output Class Initialized
INFO - 2019-07-04 16:38:03 --> Security Class Initialized
INFO - 2019-07-04 16:38:03 --> Helper loaded: string_helper
INFO - 2019-07-04 16:38:03 --> Security Class Initialized
DEBUG - 2019-07-04 16:38:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:38:03 --> Helper loaded: array_helper
INFO - 2019-07-04 16:38:03 --> Input Class Initialized
DEBUG - 2019-07-04 16:38:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:38:03 --> Session: Class initialized using 'files' driver.
INFO - 2019-07-04 16:38:03 --> Input Class Initialized
INFO - 2019-07-04 16:38:03 --> Language Class Initialized
DEBUG - 2019-07-04 16:38:03 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:38:03 --> Language Class Initialized
INFO - 2019-07-04 16:38:03 --> Language Class Initialized
INFO - 2019-07-04 16:38:03 --> Database Driver Class Initialized
INFO - 2019-07-04 16:38:03 --> Config Class Initialized
INFO - 2019-07-04 16:38:03 --> Language Class Initialized
INFO - 2019-07-04 16:38:03 --> Loader Class Initialized
INFO - 2019-07-04 16:38:03 --> Config Class Initialized
INFO - 2019-07-04 16:38:03 --> Controller Class Initialized
INFO - 2019-07-04 16:38:03 --> Loader Class Initialized
DEBUG - 2019-07-04 16:38:03 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 22:38:03 --> Helper loaded: language_helper
DEBUG - 2019-07-04 16:38:03 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:38:03 --> Helper loaded: url_helper
INFO - 2019-07-04 22:38:03 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 16:38:03 --> Helper loaded: url_helper
INFO - 2019-07-04 16:38:03 --> Helper loaded: inflector_helper
INFO - 2019-07-04 22:38:03 --> Model Class Initialized
INFO - 2019-07-04 16:38:03 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:38:03 --> Helper loaded: string_helper
INFO - 2019-07-04 22:38:03 --> Model Class Initialized
INFO - 2019-07-04 16:38:03 --> Helper loaded: string_helper
INFO - 2019-07-04 16:38:03 --> Helper loaded: array_helper
INFO - 2019-07-04 16:38:03 --> Helper loaded: array_helper
INFO - 2019-07-04 22:38:03 --> Model Class Initialized
INFO - 2019-07-04 16:38:03 --> Session: Class initialized using 'files' driver.
INFO - 2019-07-04 22:38:03 --> Model Class Initialized
DEBUG - 2019-07-04 16:38:03 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 22:38:03 --> Model Class Initialized
INFO - 2019-07-04 16:38:03 --> Database Driver Class Initialized
INFO - 2019-07-04 22:38:03 --> Final output sent to browser
DEBUG - 2019-07-04 22:38:03 --> Total execution time: 0.5553
INFO - 2019-07-04 16:38:03 --> Controller Class Initialized
INFO - 2019-07-04 22:38:03 --> Helper loaded: language_helper
INFO - 2019-07-04 22:38:03 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 16:38:03 --> Config Class Initialized
INFO - 2019-07-04 22:38:03 --> Model Class Initialized
INFO - 2019-07-04 16:38:03 --> Hooks Class Initialized
INFO - 2019-07-04 22:38:03 --> Model Class Initialized
DEBUG - 2019-07-04 16:38:03 --> UTF-8 Support Enabled
INFO - 2019-07-04 22:38:03 --> Model Class Initialized
INFO - 2019-07-04 16:38:03 --> Utf8 Class Initialized
INFO - 2019-07-04 16:38:03 --> URI Class Initialized
INFO - 2019-07-04 22:38:03 --> Model Class Initialized
INFO - 2019-07-04 22:38:03 --> Model Class Initialized
INFO - 2019-07-04 16:38:03 --> Router Class Initialized
INFO - 2019-07-04 22:38:03 --> Final output sent to browser
INFO - 2019-07-04 16:38:03 --> Output Class Initialized
DEBUG - 2019-07-04 22:38:03 --> Total execution time: 0.6142
INFO - 2019-07-04 16:38:03 --> Session: Class initialized using 'files' driver.
INFO - 2019-07-04 16:38:03 --> Security Class Initialized
DEBUG - 2019-07-04 16:38:03 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
DEBUG - 2019-07-04 16:38:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:38:03 --> Database Driver Class Initialized
INFO - 2019-07-04 16:38:03 --> Input Class Initialized
INFO - 2019-07-04 16:38:03 --> Language Class Initialized
INFO - 2019-07-04 16:38:03 --> Controller Class Initialized
INFO - 2019-07-04 16:38:03 --> Language Class Initialized
INFO - 2019-07-04 22:38:03 --> Helper loaded: language_helper
INFO - 2019-07-04 16:38:03 --> Config Class Initialized
INFO - 2019-07-04 16:38:03 --> Loader Class Initialized
INFO - 2019-07-04 22:38:03 --> Language file loaded: language/english/general_lang.php
DEBUG - 2019-07-04 16:38:03 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 22:38:03 --> Model Class Initialized
INFO - 2019-07-04 16:38:03 --> Helper loaded: url_helper
INFO - 2019-07-04 22:38:03 --> Model Class Initialized
INFO - 2019-07-04 16:38:03 --> Helper loaded: inflector_helper
INFO - 2019-07-04 22:38:03 --> Model Class Initialized
INFO - 2019-07-04 16:38:03 --> Helper loaded: string_helper
INFO - 2019-07-04 22:38:03 --> Model Class Initialized
INFO - 2019-07-04 16:38:03 --> Helper loaded: array_helper
INFO - 2019-07-04 22:38:03 --> Helper loaded: form_helper
INFO - 2019-07-04 16:38:03 --> Session: Class initialized using 'files' driver.
INFO - 2019-07-04 22:38:03 --> Form Validation Class Initialized
DEBUG - 2019-07-04 16:38:03 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
DEBUG - 2019-07-04 22:38:03 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 16:38:03 --> Database Driver Class Initialized
INFO - 2019-07-04 22:38:03 --> Model Class Initialized
INFO - 2019-07-04 16:38:03 --> Controller Class Initialized
INFO - 2019-07-04 22:38:03 --> Model Class Initialized
INFO - 2019-07-04 22:38:03 --> Helper loaded: language_helper
INFO - 2019-07-04 22:38:03 --> Final output sent to browser
INFO - 2019-07-04 22:38:03 --> Language file loaded: language/english/general_lang.php
DEBUG - 2019-07-04 22:38:03 --> Total execution time: 0.9899
INFO - 2019-07-04 22:38:03 --> Model Class Initialized
INFO - 2019-07-04 22:38:03 --> Model Class Initialized
INFO - 2019-07-04 22:38:04 --> Model Class Initialized
INFO - 2019-07-04 22:38:04 --> Model Class Initialized
INFO - 2019-07-04 22:38:04 --> Helper loaded: form_helper
INFO - 2019-07-04 22:38:04 --> Form Validation Class Initialized
DEBUG - 2019-07-04 22:38:04 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 22:38:04 --> Model Class Initialized
INFO - 2019-07-04 22:38:04 --> Model Class Initialized
INFO - 2019-07-04 22:38:04 --> Final output sent to browser
DEBUG - 2019-07-04 22:38:04 --> Total execution time: 0.6390
INFO - 2019-07-04 16:38:11 --> Config Class Initialized
INFO - 2019-07-04 16:38:11 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:38:11 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:38:11 --> Utf8 Class Initialized
INFO - 2019-07-04 16:38:11 --> URI Class Initialized
INFO - 2019-07-04 16:38:12 --> Router Class Initialized
INFO - 2019-07-04 16:38:12 --> Output Class Initialized
INFO - 2019-07-04 16:38:12 --> Security Class Initialized
DEBUG - 2019-07-04 16:38:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:38:12 --> Input Class Initialized
INFO - 2019-07-04 16:38:12 --> Language Class Initialized
INFO - 2019-07-04 16:38:12 --> Language Class Initialized
INFO - 2019-07-04 16:38:12 --> Config Class Initialized
INFO - 2019-07-04 16:38:12 --> Loader Class Initialized
DEBUG - 2019-07-04 16:38:12 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:38:12 --> Helper loaded: url_helper
INFO - 2019-07-04 16:38:12 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:38:12 --> Helper loaded: string_helper
INFO - 2019-07-04 16:38:12 --> Helper loaded: array_helper
INFO - 2019-07-04 16:38:12 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:38:12 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:38:12 --> Database Driver Class Initialized
INFO - 2019-07-04 16:38:12 --> Controller Class Initialized
INFO - 2019-07-04 22:38:12 --> Helper loaded: language_helper
INFO - 2019-07-04 22:38:12 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:38:12 --> Model Class Initialized
INFO - 2019-07-04 22:38:12 --> Model Class Initialized
INFO - 2019-07-04 22:38:12 --> Model Class Initialized
INFO - 2019-07-04 22:38:12 --> Model Class Initialized
INFO - 2019-07-04 22:38:12 --> Model Class Initialized
INFO - 2019-07-04 22:38:12 --> Final output sent to browser
DEBUG - 2019-07-04 22:38:12 --> Total execution time: 0.4613
INFO - 2019-07-04 16:38:12 --> Config Class Initialized
INFO - 2019-07-04 16:38:12 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:38:12 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:38:12 --> Utf8 Class Initialized
INFO - 2019-07-04 16:38:12 --> URI Class Initialized
INFO - 2019-07-04 16:38:12 --> Router Class Initialized
INFO - 2019-07-04 16:38:12 --> Output Class Initialized
INFO - 2019-07-04 16:38:12 --> Security Class Initialized
DEBUG - 2019-07-04 16:38:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:38:12 --> Input Class Initialized
INFO - 2019-07-04 16:38:12 --> Language Class Initialized
INFO - 2019-07-04 16:38:12 --> Language Class Initialized
INFO - 2019-07-04 16:38:12 --> Config Class Initialized
INFO - 2019-07-04 16:38:12 --> Loader Class Initialized
DEBUG - 2019-07-04 16:38:12 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:38:12 --> Helper loaded: url_helper
INFO - 2019-07-04 16:38:12 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:38:12 --> Helper loaded: string_helper
INFO - 2019-07-04 16:38:12 --> Helper loaded: array_helper
INFO - 2019-07-04 16:38:12 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:38:12 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:38:12 --> Database Driver Class Initialized
INFO - 2019-07-04 16:38:12 --> Controller Class Initialized
INFO - 2019-07-04 22:38:12 --> Helper loaded: language_helper
INFO - 2019-07-04 22:38:12 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:38:12 --> Model Class Initialized
INFO - 2019-07-04 22:38:12 --> Model Class Initialized
INFO - 2019-07-04 22:38:12 --> Model Class Initialized
INFO - 2019-07-04 22:38:12 --> Model Class Initialized
INFO - 2019-07-04 22:38:12 --> Helper loaded: form_helper
INFO - 2019-07-04 22:38:12 --> Form Validation Class Initialized
DEBUG - 2019-07-04 22:38:12 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 22:38:12 --> Model Class Initialized
INFO - 2019-07-04 22:38:12 --> Model Class Initialized
INFO - 2019-07-04 22:38:12 --> Final output sent to browser
DEBUG - 2019-07-04 22:38:12 --> Total execution time: 0.4556
INFO - 2019-07-04 16:38:12 --> Config Class Initialized
INFO - 2019-07-04 16:38:12 --> Config Class Initialized
INFO - 2019-07-04 16:38:12 --> Hooks Class Initialized
INFO - 2019-07-04 16:38:12 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:38:12 --> UTF-8 Support Enabled
DEBUG - 2019-07-04 16:38:13 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:38:13 --> Utf8 Class Initialized
INFO - 2019-07-04 16:38:13 --> Utf8 Class Initialized
INFO - 2019-07-04 16:38:13 --> URI Class Initialized
INFO - 2019-07-04 16:38:13 --> URI Class Initialized
INFO - 2019-07-04 16:38:13 --> Router Class Initialized
INFO - 2019-07-04 16:38:13 --> Router Class Initialized
INFO - 2019-07-04 16:38:13 --> Output Class Initialized
INFO - 2019-07-04 16:38:13 --> Output Class Initialized
INFO - 2019-07-04 16:38:13 --> Security Class Initialized
INFO - 2019-07-04 16:38:13 --> Security Class Initialized
DEBUG - 2019-07-04 16:38:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-04 16:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:38:13 --> Input Class Initialized
INFO - 2019-07-04 16:38:13 --> Input Class Initialized
INFO - 2019-07-04 16:38:13 --> Language Class Initialized
INFO - 2019-07-04 16:38:13 --> Language Class Initialized
INFO - 2019-07-04 16:38:13 --> Language Class Initialized
INFO - 2019-07-04 16:38:13 --> Language Class Initialized
INFO - 2019-07-04 16:38:13 --> Config Class Initialized
INFO - 2019-07-04 16:38:13 --> Config Class Initialized
INFO - 2019-07-04 16:38:13 --> Loader Class Initialized
INFO - 2019-07-04 16:38:13 --> Loader Class Initialized
DEBUG - 2019-07-04 16:38:13 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-04 16:38:13 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:38:13 --> Helper loaded: url_helper
INFO - 2019-07-04 16:38:13 --> Helper loaded: url_helper
INFO - 2019-07-04 16:38:13 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:38:13 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:38:13 --> Helper loaded: string_helper
INFO - 2019-07-04 16:38:13 --> Helper loaded: string_helper
INFO - 2019-07-04 16:38:13 --> Helper loaded: array_helper
INFO - 2019-07-04 16:38:13 --> Helper loaded: array_helper
INFO - 2019-07-04 16:38:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:38:13 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:38:13 --> Database Driver Class Initialized
INFO - 2019-07-04 16:38:13 --> Controller Class Initialized
INFO - 2019-07-04 22:38:13 --> Helper loaded: language_helper
INFO - 2019-07-04 22:38:13 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:38:13 --> Model Class Initialized
INFO - 2019-07-04 22:38:13 --> Model Class Initialized
INFO - 2019-07-04 22:38:13 --> Model Class Initialized
INFO - 2019-07-04 22:38:13 --> Model Class Initialized
INFO - 2019-07-04 22:38:13 --> Model Class Initialized
INFO - 2019-07-04 22:38:13 --> Final output sent to browser
DEBUG - 2019-07-04 22:38:13 --> Total execution time: 0.5345
INFO - 2019-07-04 16:38:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:38:13 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:38:13 --> Database Driver Class Initialized
INFO - 2019-07-04 16:38:13 --> Controller Class Initialized
INFO - 2019-07-04 22:38:13 --> Helper loaded: language_helper
INFO - 2019-07-04 22:38:13 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:38:13 --> Model Class Initialized
INFO - 2019-07-04 22:38:13 --> Model Class Initialized
INFO - 2019-07-04 22:38:13 --> Model Class Initialized
INFO - 2019-07-04 22:38:13 --> Model Class Initialized
INFO - 2019-07-04 22:38:13 --> Helper loaded: form_helper
INFO - 2019-07-04 22:38:13 --> Form Validation Class Initialized
DEBUG - 2019-07-04 22:38:13 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 22:38:13 --> Model Class Initialized
INFO - 2019-07-04 22:38:13 --> Model Class Initialized
INFO - 2019-07-04 22:38:13 --> Final output sent to browser
DEBUG - 2019-07-04 22:38:13 --> Total execution time: 0.7510
INFO - 2019-07-04 16:38:20 --> Config Class Initialized
INFO - 2019-07-04 16:38:20 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:38:20 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:38:20 --> Utf8 Class Initialized
INFO - 2019-07-04 16:38:21 --> URI Class Initialized
INFO - 2019-07-04 16:38:21 --> Router Class Initialized
INFO - 2019-07-04 16:38:21 --> Config Class Initialized
INFO - 2019-07-04 16:38:21 --> Hooks Class Initialized
INFO - 2019-07-04 16:38:21 --> Config Class Initialized
INFO - 2019-07-04 16:38:21 --> Output Class Initialized
DEBUG - 2019-07-04 16:38:21 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:38:21 --> Hooks Class Initialized
INFO - 2019-07-04 16:38:21 --> Utf8 Class Initialized
INFO - 2019-07-04 16:38:21 --> Security Class Initialized
DEBUG - 2019-07-04 16:38:21 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:38:21 --> URI Class Initialized
DEBUG - 2019-07-04 16:38:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:38:21 --> Utf8 Class Initialized
INFO - 2019-07-04 16:38:21 --> Router Class Initialized
INFO - 2019-07-04 16:38:21 --> Input Class Initialized
INFO - 2019-07-04 16:38:21 --> URI Class Initialized
INFO - 2019-07-04 16:38:21 --> Output Class Initialized
INFO - 2019-07-04 16:38:21 --> Language Class Initialized
INFO - 2019-07-04 16:38:21 --> Router Class Initialized
INFO - 2019-07-04 16:38:21 --> Security Class Initialized
INFO - 2019-07-04 16:38:21 --> Language Class Initialized
INFO - 2019-07-04 16:38:21 --> Output Class Initialized
INFO - 2019-07-04 16:38:21 --> Config Class Initialized
DEBUG - 2019-07-04 16:38:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:38:21 --> Loader Class Initialized
INFO - 2019-07-04 16:38:21 --> Security Class Initialized
INFO - 2019-07-04 16:38:21 --> Input Class Initialized
DEBUG - 2019-07-04 16:38:21 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-04 16:38:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:38:21 --> Language Class Initialized
INFO - 2019-07-04 16:38:21 --> Helper loaded: url_helper
INFO - 2019-07-04 16:38:21 --> Input Class Initialized
INFO - 2019-07-04 16:38:21 --> Language Class Initialized
INFO - 2019-07-04 16:38:21 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:38:21 --> Language Class Initialized
INFO - 2019-07-04 16:38:21 --> Config Class Initialized
INFO - 2019-07-04 16:38:21 --> Loader Class Initialized
INFO - 2019-07-04 16:38:21 --> Language Class Initialized
INFO - 2019-07-04 16:38:21 --> Helper loaded: string_helper
DEBUG - 2019-07-04 16:38:21 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:38:21 --> Config Class Initialized
INFO - 2019-07-04 16:38:21 --> Helper loaded: array_helper
INFO - 2019-07-04 16:38:21 --> Loader Class Initialized
INFO - 2019-07-04 16:38:21 --> Helper loaded: url_helper
INFO - 2019-07-04 16:38:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:38:21 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:38:21 --> Helper loaded: inflector_helper
DEBUG - 2019-07-04 16:38:21 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:38:21 --> Helper loaded: string_helper
INFO - 2019-07-04 16:38:21 --> Helper loaded: url_helper
INFO - 2019-07-04 16:38:21 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:38:21 --> Database Driver Class Initialized
INFO - 2019-07-04 16:38:21 --> Helper loaded: array_helper
INFO - 2019-07-04 16:38:21 --> Helper loaded: string_helper
INFO - 2019-07-04 16:38:21 --> Session: Class initialized using 'files' driver.
INFO - 2019-07-04 16:38:21 --> Controller Class Initialized
INFO - 2019-07-04 16:38:21 --> Helper loaded: array_helper
DEBUG - 2019-07-04 16:38:21 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 22:38:21 --> Helper loaded: language_helper
INFO - 2019-07-04 16:38:21 --> Database Driver Class Initialized
INFO - 2019-07-04 22:38:21 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 16:38:21 --> Controller Class Initialized
INFO - 2019-07-04 22:38:21 --> Model Class Initialized
INFO - 2019-07-04 22:38:21 --> Helper loaded: language_helper
INFO - 2019-07-04 22:38:21 --> Model Class Initialized
INFO - 2019-07-04 22:38:21 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:38:21 --> Model Class Initialized
INFO - 2019-07-04 22:38:21 --> Model Class Initialized
INFO - 2019-07-04 22:38:21 --> Model Class Initialized
INFO - 2019-07-04 22:38:21 --> Model Class Initialized
INFO - 2019-07-04 22:38:21 --> Model Class Initialized
INFO - 2019-07-04 22:38:21 --> Model Class Initialized
INFO - 2019-07-04 22:38:21 --> Final output sent to browser
INFO - 2019-07-04 22:38:21 --> Model Class Initialized
DEBUG - 2019-07-04 22:38:21 --> Total execution time: 0.9587
INFO - 2019-07-04 16:38:21 --> Session: Class initialized using 'files' driver.
INFO - 2019-07-04 22:38:21 --> Model Class Initialized
DEBUG - 2019-07-04 16:38:21 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 22:38:21 --> Final output sent to browser
INFO - 2019-07-04 16:38:21 --> Database Driver Class Initialized
DEBUG - 2019-07-04 22:38:21 --> Total execution time: 0.7861
INFO - 2019-07-04 16:38:21 --> Controller Class Initialized
INFO - 2019-07-04 22:38:21 --> Helper loaded: language_helper
INFO - 2019-07-04 16:38:21 --> Config Class Initialized
INFO - 2019-07-04 16:38:22 --> Hooks Class Initialized
INFO - 2019-07-04 22:38:22 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:38:22 --> Model Class Initialized
DEBUG - 2019-07-04 16:38:22 --> UTF-8 Support Enabled
INFO - 2019-07-04 22:38:22 --> Model Class Initialized
INFO - 2019-07-04 16:38:22 --> Utf8 Class Initialized
INFO - 2019-07-04 16:38:22 --> URI Class Initialized
INFO - 2019-07-04 22:38:22 --> Model Class Initialized
INFO - 2019-07-04 22:38:22 --> Model Class Initialized
INFO - 2019-07-04 16:38:22 --> Router Class Initialized
INFO - 2019-07-04 22:38:22 --> Helper loaded: form_helper
INFO - 2019-07-04 16:38:22 --> Output Class Initialized
INFO - 2019-07-04 22:38:22 --> Form Validation Class Initialized
INFO - 2019-07-04 16:38:22 --> Security Class Initialized
DEBUG - 2019-07-04 22:38:22 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
DEBUG - 2019-07-04 16:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 22:38:22 --> Model Class Initialized
INFO - 2019-07-04 16:38:22 --> Input Class Initialized
INFO - 2019-07-04 16:38:22 --> Language Class Initialized
INFO - 2019-07-04 22:38:22 --> Model Class Initialized
INFO - 2019-07-04 16:38:22 --> Language Class Initialized
INFO - 2019-07-04 22:38:22 --> Final output sent to browser
INFO - 2019-07-04 16:38:22 --> Config Class Initialized
DEBUG - 2019-07-04 22:38:22 --> Total execution time: 1.3740
INFO - 2019-07-04 16:38:22 --> Loader Class Initialized
DEBUG - 2019-07-04 16:38:22 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:38:22 --> Helper loaded: url_helper
INFO - 2019-07-04 16:38:22 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:38:22 --> Helper loaded: string_helper
INFO - 2019-07-04 16:38:22 --> Helper loaded: array_helper
INFO - 2019-07-04 16:38:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:38:22 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:38:22 --> Database Driver Class Initialized
INFO - 2019-07-04 16:38:22 --> Controller Class Initialized
INFO - 2019-07-04 22:38:22 --> Helper loaded: language_helper
INFO - 2019-07-04 22:38:22 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:38:22 --> Model Class Initialized
INFO - 2019-07-04 22:38:22 --> Model Class Initialized
INFO - 2019-07-04 22:38:22 --> Model Class Initialized
INFO - 2019-07-04 22:38:22 --> Model Class Initialized
INFO - 2019-07-04 22:38:22 --> Helper loaded: form_helper
INFO - 2019-07-04 22:38:22 --> Form Validation Class Initialized
DEBUG - 2019-07-04 22:38:22 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 22:38:22 --> Model Class Initialized
INFO - 2019-07-04 22:38:22 --> Model Class Initialized
INFO - 2019-07-04 22:38:22 --> Final output sent to browser
DEBUG - 2019-07-04 22:38:22 --> Total execution time: 0.6093
INFO - 2019-07-04 16:38:25 --> Config Class Initialized
INFO - 2019-07-04 16:38:25 --> Config Class Initialized
INFO - 2019-07-04 16:38:25 --> Hooks Class Initialized
INFO - 2019-07-04 16:38:25 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:38:25 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:38:25 --> Utf8 Class Initialized
INFO - 2019-07-04 16:38:25 --> URI Class Initialized
DEBUG - 2019-07-04 16:38:25 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:38:25 --> Utf8 Class Initialized
INFO - 2019-07-04 16:38:25 --> Router Class Initialized
INFO - 2019-07-04 16:38:25 --> URI Class Initialized
INFO - 2019-07-04 16:38:25 --> Output Class Initialized
INFO - 2019-07-04 16:38:25 --> Router Class Initialized
INFO - 2019-07-04 16:38:25 --> Security Class Initialized
INFO - 2019-07-04 16:38:25 --> Output Class Initialized
DEBUG - 2019-07-04 16:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:38:25 --> Security Class Initialized
INFO - 2019-07-04 16:38:25 --> Input Class Initialized
INFO - 2019-07-04 16:38:25 --> Language Class Initialized
DEBUG - 2019-07-04 16:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:38:25 --> Language Class Initialized
INFO - 2019-07-04 16:38:25 --> Input Class Initialized
INFO - 2019-07-04 16:38:25 --> Config Class Initialized
INFO - 2019-07-04 16:38:25 --> Language Class Initialized
INFO - 2019-07-04 16:38:25 --> Loader Class Initialized
DEBUG - 2019-07-04 16:38:25 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:38:25 --> Language Class Initialized
INFO - 2019-07-04 16:38:25 --> Helper loaded: url_helper
INFO - 2019-07-04 16:38:25 --> Config Class Initialized
INFO - 2019-07-04 16:38:25 --> Loader Class Initialized
INFO - 2019-07-04 16:38:25 --> Helper loaded: inflector_helper
DEBUG - 2019-07-04 16:38:25 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:38:25 --> Helper loaded: url_helper
INFO - 2019-07-04 16:38:25 --> Helper loaded: string_helper
INFO - 2019-07-04 16:38:25 --> Helper loaded: array_helper
INFO - 2019-07-04 16:38:25 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:38:25 --> Helper loaded: string_helper
INFO - 2019-07-04 16:38:25 --> Session: Class initialized using 'files' driver.
INFO - 2019-07-04 16:38:25 --> Helper loaded: array_helper
DEBUG - 2019-07-04 16:38:25 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:38:25 --> Database Driver Class Initialized
INFO - 2019-07-04 16:38:25 --> Controller Class Initialized
INFO - 2019-07-04 22:38:26 --> Helper loaded: language_helper
INFO - 2019-07-04 22:38:26 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:38:26 --> Model Class Initialized
INFO - 2019-07-04 22:38:26 --> Model Class Initialized
INFO - 2019-07-04 22:38:26 --> Model Class Initialized
INFO - 2019-07-04 22:38:26 --> Model Class Initialized
INFO - 2019-07-04 22:38:26 --> Model Class Initialized
INFO - 2019-07-04 22:38:26 --> Final output sent to browser
DEBUG - 2019-07-04 22:38:26 --> Total execution time: 0.7344
INFO - 2019-07-04 16:38:26 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:38:26 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:38:26 --> Database Driver Class Initialized
INFO - 2019-07-04 16:38:26 --> Controller Class Initialized
INFO - 2019-07-04 22:38:26 --> Helper loaded: language_helper
INFO - 2019-07-04 22:38:26 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:38:26 --> Model Class Initialized
INFO - 2019-07-04 22:38:26 --> Model Class Initialized
INFO - 2019-07-04 22:38:26 --> Model Class Initialized
INFO - 2019-07-04 22:38:26 --> Model Class Initialized
INFO - 2019-07-04 22:38:26 --> Helper loaded: form_helper
INFO - 2019-07-04 22:38:26 --> Form Validation Class Initialized
DEBUG - 2019-07-04 22:38:26 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 22:38:26 --> Model Class Initialized
INFO - 2019-07-04 22:38:26 --> Model Class Initialized
INFO - 2019-07-04 22:38:26 --> Final output sent to browser
DEBUG - 2019-07-04 22:38:26 --> Total execution time: 0.9714
INFO - 2019-07-04 16:38:27 --> Config Class Initialized
INFO - 2019-07-04 16:38:27 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:38:27 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:38:27 --> Utf8 Class Initialized
INFO - 2019-07-04 16:38:27 --> URI Class Initialized
INFO - 2019-07-04 16:38:27 --> Router Class Initialized
INFO - 2019-07-04 16:38:27 --> Output Class Initialized
INFO - 2019-07-04 16:38:27 --> Security Class Initialized
DEBUG - 2019-07-04 16:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:38:27 --> Input Class Initialized
INFO - 2019-07-04 16:38:27 --> Language Class Initialized
INFO - 2019-07-04 16:38:27 --> Language Class Initialized
INFO - 2019-07-04 16:38:27 --> Config Class Initialized
INFO - 2019-07-04 16:38:27 --> Loader Class Initialized
DEBUG - 2019-07-04 16:38:27 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:38:27 --> Helper loaded: url_helper
INFO - 2019-07-04 16:38:27 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:38:27 --> Helper loaded: string_helper
INFO - 2019-07-04 16:38:27 --> Helper loaded: array_helper
INFO - 2019-07-04 16:38:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:38:27 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:38:27 --> Database Driver Class Initialized
INFO - 2019-07-04 16:38:27 --> Controller Class Initialized
INFO - 2019-07-04 22:38:27 --> Helper loaded: language_helper
INFO - 2019-07-04 22:38:27 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:38:27 --> Model Class Initialized
INFO - 2019-07-04 22:38:27 --> Model Class Initialized
INFO - 2019-07-04 22:38:27 --> Model Class Initialized
INFO - 2019-07-04 22:38:27 --> Model Class Initialized
INFO - 2019-07-04 22:38:27 --> Model Class Initialized
INFO - 2019-07-04 22:38:27 --> Final output sent to browser
DEBUG - 2019-07-04 22:38:27 --> Total execution time: 0.4363
INFO - 2019-07-04 16:38:27 --> Config Class Initialized
INFO - 2019-07-04 16:38:27 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:38:27 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:38:27 --> Utf8 Class Initialized
INFO - 2019-07-04 16:38:27 --> URI Class Initialized
INFO - 2019-07-04 16:38:27 --> Router Class Initialized
INFO - 2019-07-04 16:38:27 --> Output Class Initialized
INFO - 2019-07-04 16:38:27 --> Security Class Initialized
DEBUG - 2019-07-04 16:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:38:27 --> Input Class Initialized
INFO - 2019-07-04 16:38:27 --> Language Class Initialized
INFO - 2019-07-04 16:38:27 --> Language Class Initialized
INFO - 2019-07-04 16:38:27 --> Config Class Initialized
INFO - 2019-07-04 16:38:28 --> Loader Class Initialized
DEBUG - 2019-07-04 16:38:28 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:38:28 --> Helper loaded: url_helper
INFO - 2019-07-04 16:38:28 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:38:28 --> Helper loaded: string_helper
INFO - 2019-07-04 16:38:28 --> Helper loaded: array_helper
INFO - 2019-07-04 16:38:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:38:28 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:38:28 --> Database Driver Class Initialized
INFO - 2019-07-04 16:38:28 --> Controller Class Initialized
INFO - 2019-07-04 22:38:28 --> Helper loaded: language_helper
INFO - 2019-07-04 22:38:28 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:38:28 --> Model Class Initialized
INFO - 2019-07-04 22:38:28 --> Model Class Initialized
INFO - 2019-07-04 22:38:28 --> Model Class Initialized
INFO - 2019-07-04 22:38:28 --> Model Class Initialized
INFO - 2019-07-04 22:38:28 --> Helper loaded: form_helper
INFO - 2019-07-04 22:38:28 --> Form Validation Class Initialized
DEBUG - 2019-07-04 22:38:28 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 22:38:28 --> Model Class Initialized
INFO - 2019-07-04 22:38:28 --> Model Class Initialized
INFO - 2019-07-04 22:38:28 --> Final output sent to browser
DEBUG - 2019-07-04 22:38:28 --> Total execution time: 0.7050
INFO - 2019-07-04 16:38:43 --> Config Class Initialized
INFO - 2019-07-04 16:38:43 --> Config Class Initialized
INFO - 2019-07-04 16:38:43 --> Hooks Class Initialized
INFO - 2019-07-04 16:38:43 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:38:43 --> UTF-8 Support Enabled
DEBUG - 2019-07-04 16:38:43 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:38:43 --> Utf8 Class Initialized
INFO - 2019-07-04 16:38:43 --> Utf8 Class Initialized
INFO - 2019-07-04 16:38:43 --> URI Class Initialized
INFO - 2019-07-04 16:38:43 --> URI Class Initialized
INFO - 2019-07-04 16:38:43 --> Router Class Initialized
INFO - 2019-07-04 16:38:43 --> Router Class Initialized
INFO - 2019-07-04 16:38:43 --> Output Class Initialized
INFO - 2019-07-04 16:38:43 --> Output Class Initialized
INFO - 2019-07-04 16:38:43 --> Security Class Initialized
INFO - 2019-07-04 16:38:43 --> Security Class Initialized
DEBUG - 2019-07-04 16:38:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-04 16:38:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:38:43 --> Input Class Initialized
INFO - 2019-07-04 16:38:43 --> Input Class Initialized
INFO - 2019-07-04 16:38:43 --> Language Class Initialized
INFO - 2019-07-04 16:38:43 --> Language Class Initialized
INFO - 2019-07-04 16:38:43 --> Language Class Initialized
INFO - 2019-07-04 16:38:43 --> Language Class Initialized
INFO - 2019-07-04 16:38:43 --> Config Class Initialized
INFO - 2019-07-04 16:38:43 --> Config Class Initialized
INFO - 2019-07-04 16:38:43 --> Loader Class Initialized
INFO - 2019-07-04 16:38:43 --> Loader Class Initialized
DEBUG - 2019-07-04 16:38:44 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-04 16:38:44 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:38:44 --> Helper loaded: url_helper
INFO - 2019-07-04 16:38:44 --> Helper loaded: url_helper
INFO - 2019-07-04 16:38:44 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:38:44 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:38:44 --> Helper loaded: string_helper
INFO - 2019-07-04 16:38:44 --> Helper loaded: string_helper
INFO - 2019-07-04 16:38:44 --> Helper loaded: array_helper
INFO - 2019-07-04 16:38:44 --> Helper loaded: array_helper
INFO - 2019-07-04 16:38:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:38:44 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:38:44 --> Database Driver Class Initialized
INFO - 2019-07-04 16:38:44 --> Controller Class Initialized
INFO - 2019-07-04 22:38:44 --> Helper loaded: language_helper
INFO - 2019-07-04 22:38:44 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:38:44 --> Model Class Initialized
INFO - 2019-07-04 22:38:44 --> Model Class Initialized
INFO - 2019-07-04 22:38:44 --> Model Class Initialized
INFO - 2019-07-04 22:38:44 --> Model Class Initialized
INFO - 2019-07-04 22:38:44 --> Model Class Initialized
INFO - 2019-07-04 22:38:44 --> Final output sent to browser
DEBUG - 2019-07-04 22:38:44 --> Total execution time: 0.5950
INFO - 2019-07-04 16:38:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:38:44 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:38:44 --> Database Driver Class Initialized
INFO - 2019-07-04 16:38:44 --> Controller Class Initialized
INFO - 2019-07-04 22:38:44 --> Helper loaded: language_helper
INFO - 2019-07-04 22:38:44 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:38:44 --> Model Class Initialized
INFO - 2019-07-04 22:38:44 --> Model Class Initialized
INFO - 2019-07-04 22:38:44 --> Model Class Initialized
INFO - 2019-07-04 22:38:44 --> Model Class Initialized
INFO - 2019-07-04 22:38:44 --> Helper loaded: form_helper
INFO - 2019-07-04 22:38:44 --> Form Validation Class Initialized
DEBUG - 2019-07-04 22:38:44 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 22:38:44 --> Model Class Initialized
INFO - 2019-07-04 22:38:44 --> Model Class Initialized
INFO - 2019-07-04 22:38:44 --> Final output sent to browser
DEBUG - 2019-07-04 22:38:44 --> Total execution time: 0.8304
INFO - 2019-07-04 16:38:45 --> Config Class Initialized
INFO - 2019-07-04 16:38:45 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:38:45 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:38:45 --> Utf8 Class Initialized
INFO - 2019-07-04 16:38:45 --> URI Class Initialized
INFO - 2019-07-04 16:38:45 --> Router Class Initialized
INFO - 2019-07-04 16:38:45 --> Output Class Initialized
INFO - 2019-07-04 16:38:45 --> Security Class Initialized
DEBUG - 2019-07-04 16:38:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:38:45 --> Input Class Initialized
INFO - 2019-07-04 16:38:45 --> Language Class Initialized
INFO - 2019-07-04 16:38:45 --> Language Class Initialized
INFO - 2019-07-04 16:38:45 --> Config Class Initialized
INFO - 2019-07-04 16:38:45 --> Loader Class Initialized
DEBUG - 2019-07-04 16:38:45 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:38:45 --> Helper loaded: url_helper
INFO - 2019-07-04 16:38:45 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:38:45 --> Helper loaded: string_helper
INFO - 2019-07-04 16:38:45 --> Helper loaded: array_helper
INFO - 2019-07-04 16:38:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:38:45 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:38:45 --> Database Driver Class Initialized
INFO - 2019-07-04 16:38:45 --> Controller Class Initialized
INFO - 2019-07-04 22:38:45 --> Helper loaded: language_helper
INFO - 2019-07-04 22:38:45 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:38:45 --> Model Class Initialized
INFO - 2019-07-04 22:38:45 --> Model Class Initialized
INFO - 2019-07-04 22:38:45 --> Model Class Initialized
INFO - 2019-07-04 22:38:45 --> Model Class Initialized
INFO - 2019-07-04 22:38:45 --> Model Class Initialized
INFO - 2019-07-04 22:38:45 --> Final output sent to browser
DEBUG - 2019-07-04 22:38:45 --> Total execution time: 0.4445
INFO - 2019-07-04 16:38:45 --> Config Class Initialized
INFO - 2019-07-04 16:38:45 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:38:45 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:38:45 --> Utf8 Class Initialized
INFO - 2019-07-04 16:38:45 --> URI Class Initialized
INFO - 2019-07-04 16:38:45 --> Router Class Initialized
INFO - 2019-07-04 16:38:45 --> Output Class Initialized
INFO - 2019-07-04 16:38:45 --> Security Class Initialized
DEBUG - 2019-07-04 16:38:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:38:45 --> Input Class Initialized
INFO - 2019-07-04 16:38:45 --> Language Class Initialized
INFO - 2019-07-04 16:38:45 --> Language Class Initialized
INFO - 2019-07-04 16:38:45 --> Config Class Initialized
INFO - 2019-07-04 16:38:46 --> Loader Class Initialized
DEBUG - 2019-07-04 16:38:46 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:38:46 --> Helper loaded: url_helper
INFO - 2019-07-04 16:38:46 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:38:46 --> Helper loaded: string_helper
INFO - 2019-07-04 16:38:46 --> Helper loaded: array_helper
INFO - 2019-07-04 16:38:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:38:46 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:38:46 --> Database Driver Class Initialized
INFO - 2019-07-04 16:38:46 --> Controller Class Initialized
INFO - 2019-07-04 22:38:46 --> Helper loaded: language_helper
INFO - 2019-07-04 22:38:46 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:38:46 --> Model Class Initialized
INFO - 2019-07-04 22:38:46 --> Model Class Initialized
INFO - 2019-07-04 22:38:46 --> Model Class Initialized
INFO - 2019-07-04 22:38:46 --> Model Class Initialized
INFO - 2019-07-04 22:38:46 --> Helper loaded: form_helper
INFO - 2019-07-04 22:38:46 --> Form Validation Class Initialized
DEBUG - 2019-07-04 22:38:46 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 22:38:46 --> Model Class Initialized
INFO - 2019-07-04 22:38:46 --> Model Class Initialized
INFO - 2019-07-04 22:38:46 --> Final output sent to browser
DEBUG - 2019-07-04 22:38:46 --> Total execution time: 0.5141
INFO - 2019-07-04 16:38:52 --> Config Class Initialized
INFO - 2019-07-04 16:38:52 --> Config Class Initialized
INFO - 2019-07-04 16:38:52 --> Hooks Class Initialized
INFO - 2019-07-04 16:38:52 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:38:52 --> UTF-8 Support Enabled
DEBUG - 2019-07-04 16:38:52 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:38:52 --> Utf8 Class Initialized
INFO - 2019-07-04 16:38:52 --> Utf8 Class Initialized
INFO - 2019-07-04 16:38:52 --> URI Class Initialized
INFO - 2019-07-04 16:38:52 --> URI Class Initialized
INFO - 2019-07-04 16:38:52 --> Router Class Initialized
INFO - 2019-07-04 16:38:52 --> Router Class Initialized
INFO - 2019-07-04 16:38:52 --> Output Class Initialized
INFO - 2019-07-04 16:38:52 --> Output Class Initialized
INFO - 2019-07-04 16:38:52 --> Security Class Initialized
INFO - 2019-07-04 16:38:52 --> Security Class Initialized
DEBUG - 2019-07-04 16:38:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-04 16:38:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:38:52 --> Input Class Initialized
INFO - 2019-07-04 16:38:52 --> Input Class Initialized
INFO - 2019-07-04 16:38:52 --> Language Class Initialized
INFO - 2019-07-04 16:38:52 --> Language Class Initialized
INFO - 2019-07-04 16:38:52 --> Language Class Initialized
INFO - 2019-07-04 16:38:53 --> Language Class Initialized
INFO - 2019-07-04 16:38:53 --> Config Class Initialized
INFO - 2019-07-04 16:38:53 --> Config Class Initialized
INFO - 2019-07-04 16:38:53 --> Loader Class Initialized
INFO - 2019-07-04 16:38:53 --> Loader Class Initialized
DEBUG - 2019-07-04 16:38:53 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-04 16:38:53 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:38:53 --> Helper loaded: url_helper
INFO - 2019-07-04 16:38:53 --> Helper loaded: url_helper
INFO - 2019-07-04 16:38:53 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:38:53 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:38:53 --> Helper loaded: string_helper
INFO - 2019-07-04 16:38:53 --> Helper loaded: string_helper
INFO - 2019-07-04 16:38:53 --> Helper loaded: array_helper
INFO - 2019-07-04 16:38:53 --> Helper loaded: array_helper
INFO - 2019-07-04 16:38:53 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:38:53 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:38:53 --> Database Driver Class Initialized
INFO - 2019-07-04 16:38:53 --> Controller Class Initialized
INFO - 2019-07-04 22:38:53 --> Helper loaded: language_helper
INFO - 2019-07-04 22:38:53 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:38:53 --> Model Class Initialized
INFO - 2019-07-04 22:38:53 --> Model Class Initialized
INFO - 2019-07-04 22:38:53 --> Model Class Initialized
INFO - 2019-07-04 22:38:53 --> Model Class Initialized
INFO - 2019-07-04 22:38:53 --> Model Class Initialized
INFO - 2019-07-04 22:38:53 --> Final output sent to browser
DEBUG - 2019-07-04 22:38:53 --> Total execution time: 0.5979
INFO - 2019-07-04 16:38:53 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:38:53 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:38:53 --> Database Driver Class Initialized
INFO - 2019-07-04 16:38:53 --> Controller Class Initialized
INFO - 2019-07-04 22:38:53 --> Helper loaded: language_helper
INFO - 2019-07-04 22:38:53 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:38:53 --> Model Class Initialized
INFO - 2019-07-04 22:38:53 --> Model Class Initialized
INFO - 2019-07-04 22:38:53 --> Model Class Initialized
INFO - 2019-07-04 22:38:53 --> Model Class Initialized
INFO - 2019-07-04 22:38:53 --> Helper loaded: form_helper
INFO - 2019-07-04 22:38:53 --> Form Validation Class Initialized
DEBUG - 2019-07-04 22:38:53 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 22:38:53 --> Model Class Initialized
INFO - 2019-07-04 22:38:53 --> Model Class Initialized
INFO - 2019-07-04 22:38:53 --> Final output sent to browser
DEBUG - 2019-07-04 22:38:53 --> Total execution time: 0.8482
INFO - 2019-07-04 16:38:54 --> Config Class Initialized
INFO - 2019-07-04 16:38:54 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:38:54 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:38:54 --> Utf8 Class Initialized
INFO - 2019-07-04 16:38:54 --> URI Class Initialized
INFO - 2019-07-04 16:38:54 --> Router Class Initialized
INFO - 2019-07-04 16:38:54 --> Output Class Initialized
INFO - 2019-07-04 16:38:54 --> Security Class Initialized
DEBUG - 2019-07-04 16:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:38:54 --> Input Class Initialized
INFO - 2019-07-04 16:38:54 --> Language Class Initialized
INFO - 2019-07-04 16:38:54 --> Language Class Initialized
INFO - 2019-07-04 16:38:54 --> Config Class Initialized
INFO - 2019-07-04 16:38:54 --> Loader Class Initialized
DEBUG - 2019-07-04 16:38:54 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:38:54 --> Helper loaded: url_helper
INFO - 2019-07-04 16:38:54 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:38:54 --> Helper loaded: string_helper
INFO - 2019-07-04 16:38:54 --> Helper loaded: array_helper
INFO - 2019-07-04 16:38:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:38:54 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:38:54 --> Database Driver Class Initialized
INFO - 2019-07-04 16:38:54 --> Controller Class Initialized
INFO - 2019-07-04 22:38:54 --> Helper loaded: language_helper
INFO - 2019-07-04 22:38:54 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:38:54 --> Model Class Initialized
INFO - 2019-07-04 22:38:54 --> Model Class Initialized
INFO - 2019-07-04 22:38:54 --> Model Class Initialized
INFO - 2019-07-04 22:38:54 --> Model Class Initialized
INFO - 2019-07-04 22:38:54 --> Model Class Initialized
INFO - 2019-07-04 22:38:54 --> Final output sent to browser
DEBUG - 2019-07-04 22:38:54 --> Total execution time: 0.4562
INFO - 2019-07-04 16:38:54 --> Config Class Initialized
INFO - 2019-07-04 16:38:54 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:38:54 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:38:54 --> Utf8 Class Initialized
INFO - 2019-07-04 16:38:55 --> URI Class Initialized
INFO - 2019-07-04 16:38:55 --> Router Class Initialized
INFO - 2019-07-04 16:38:55 --> Output Class Initialized
INFO - 2019-07-04 16:38:55 --> Security Class Initialized
DEBUG - 2019-07-04 16:38:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:38:55 --> Input Class Initialized
INFO - 2019-07-04 16:38:55 --> Language Class Initialized
INFO - 2019-07-04 16:38:55 --> Language Class Initialized
INFO - 2019-07-04 16:38:55 --> Config Class Initialized
INFO - 2019-07-04 16:38:55 --> Loader Class Initialized
DEBUG - 2019-07-04 16:38:55 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:38:55 --> Helper loaded: url_helper
INFO - 2019-07-04 16:38:55 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:38:55 --> Helper loaded: string_helper
INFO - 2019-07-04 16:38:55 --> Helper loaded: array_helper
INFO - 2019-07-04 16:38:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:38:55 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:38:55 --> Database Driver Class Initialized
INFO - 2019-07-04 16:38:55 --> Controller Class Initialized
INFO - 2019-07-04 22:38:55 --> Helper loaded: language_helper
INFO - 2019-07-04 22:38:55 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:38:55 --> Model Class Initialized
INFO - 2019-07-04 22:38:55 --> Model Class Initialized
INFO - 2019-07-04 22:38:55 --> Model Class Initialized
INFO - 2019-07-04 22:38:55 --> Model Class Initialized
INFO - 2019-07-04 22:38:55 --> Helper loaded: form_helper
INFO - 2019-07-04 22:38:55 --> Form Validation Class Initialized
DEBUG - 2019-07-04 22:38:55 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 22:38:55 --> Model Class Initialized
INFO - 2019-07-04 22:38:55 --> Model Class Initialized
INFO - 2019-07-04 22:38:55 --> Final output sent to browser
DEBUG - 2019-07-04 22:38:55 --> Total execution time: 0.5253
INFO - 2019-07-04 16:40:33 --> Config Class Initialized
INFO - 2019-07-04 16:40:33 --> Config Class Initialized
INFO - 2019-07-04 16:40:33 --> Hooks Class Initialized
INFO - 2019-07-04 16:40:33 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:40:33 --> UTF-8 Support Enabled
DEBUG - 2019-07-04 16:40:33 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:40:33 --> Utf8 Class Initialized
INFO - 2019-07-04 16:40:33 --> Utf8 Class Initialized
INFO - 2019-07-04 16:40:33 --> URI Class Initialized
INFO - 2019-07-04 16:40:33 --> URI Class Initialized
INFO - 2019-07-04 16:40:34 --> Router Class Initialized
INFO - 2019-07-04 16:40:34 --> Router Class Initialized
INFO - 2019-07-04 16:40:34 --> Output Class Initialized
INFO - 2019-07-04 16:40:34 --> Output Class Initialized
INFO - 2019-07-04 16:40:34 --> Security Class Initialized
INFO - 2019-07-04 16:40:34 --> Security Class Initialized
DEBUG - 2019-07-04 16:40:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-04 16:40:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:40:34 --> Input Class Initialized
INFO - 2019-07-04 16:40:34 --> Input Class Initialized
INFO - 2019-07-04 16:40:34 --> Language Class Initialized
INFO - 2019-07-04 16:40:34 --> Language Class Initialized
INFO - 2019-07-04 16:40:34 --> Language Class Initialized
INFO - 2019-07-04 16:40:34 --> Language Class Initialized
INFO - 2019-07-04 16:40:34 --> Config Class Initialized
INFO - 2019-07-04 16:40:34 --> Config Class Initialized
INFO - 2019-07-04 16:40:34 --> Loader Class Initialized
INFO - 2019-07-04 16:40:34 --> Loader Class Initialized
DEBUG - 2019-07-04 16:40:34 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-04 16:40:34 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:40:34 --> Helper loaded: url_helper
INFO - 2019-07-04 16:40:34 --> Helper loaded: url_helper
INFO - 2019-07-04 16:40:34 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:40:34 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:40:34 --> Helper loaded: string_helper
INFO - 2019-07-04 16:40:34 --> Helper loaded: string_helper
INFO - 2019-07-04 16:40:34 --> Helper loaded: array_helper
INFO - 2019-07-04 16:40:34 --> Helper loaded: array_helper
INFO - 2019-07-04 16:40:34 --> Session: Class initialized using 'files' driver.
INFO - 2019-07-04 16:40:34 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:40:34 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
DEBUG - 2019-07-04 16:40:34 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:40:34 --> Database Driver Class Initialized
INFO - 2019-07-04 16:40:34 --> Database Driver Class Initialized
INFO - 2019-07-04 16:40:34 --> Controller Class Initialized
INFO - 2019-07-04 16:40:34 --> Controller Class Initialized
INFO - 2019-07-04 22:40:34 --> Helper loaded: language_helper
INFO - 2019-07-04 22:40:34 --> Helper loaded: language_helper
INFO - 2019-07-04 22:40:34 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:40:34 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:40:34 --> Model Class Initialized
INFO - 2019-07-04 22:40:34 --> Model Class Initialized
INFO - 2019-07-04 22:40:34 --> Model Class Initialized
INFO - 2019-07-04 22:40:34 --> Model Class Initialized
INFO - 2019-07-04 22:40:34 --> Model Class Initialized
INFO - 2019-07-04 22:40:34 --> Model Class Initialized
INFO - 2019-07-04 22:40:34 --> Model Class Initialized
INFO - 2019-07-04 22:40:34 --> Model Class Initialized
INFO - 2019-07-04 22:40:34 --> Helper loaded: form_helper
INFO - 2019-07-04 22:40:34 --> Model Class Initialized
INFO - 2019-07-04 22:40:34 --> Form Validation Class Initialized
INFO - 2019-07-04 22:40:34 --> Final output sent to browser
DEBUG - 2019-07-04 22:40:34 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
DEBUG - 2019-07-04 22:40:34 --> Total execution time: 0.8179
INFO - 2019-07-04 22:40:34 --> Model Class Initialized
INFO - 2019-07-04 22:40:34 --> Model Class Initialized
INFO - 2019-07-04 22:40:34 --> Final output sent to browser
DEBUG - 2019-07-04 22:40:34 --> Total execution time: 0.8605
INFO - 2019-07-04 16:40:49 --> Config Class Initialized
INFO - 2019-07-04 16:40:49 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:40:49 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:40:49 --> Utf8 Class Initialized
INFO - 2019-07-04 16:40:49 --> URI Class Initialized
INFO - 2019-07-04 16:40:49 --> Router Class Initialized
INFO - 2019-07-04 16:40:49 --> Output Class Initialized
INFO - 2019-07-04 16:40:49 --> Security Class Initialized
DEBUG - 2019-07-04 16:40:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:40:49 --> Input Class Initialized
INFO - 2019-07-04 16:40:49 --> Language Class Initialized
INFO - 2019-07-04 16:40:49 --> Language Class Initialized
INFO - 2019-07-04 16:40:49 --> Config Class Initialized
INFO - 2019-07-04 16:40:49 --> Loader Class Initialized
DEBUG - 2019-07-04 16:40:49 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:40:49 --> Helper loaded: url_helper
INFO - 2019-07-04 16:40:49 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:40:49 --> Helper loaded: string_helper
INFO - 2019-07-04 16:40:49 --> Helper loaded: array_helper
INFO - 2019-07-04 16:40:49 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:40:49 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:40:50 --> Database Driver Class Initialized
INFO - 2019-07-04 16:40:50 --> Controller Class Initialized
INFO - 2019-07-04 22:40:50 --> Helper loaded: language_helper
INFO - 2019-07-04 22:40:50 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:40:50 --> Model Class Initialized
INFO - 2019-07-04 22:40:50 --> Model Class Initialized
INFO - 2019-07-04 22:40:50 --> Model Class Initialized
INFO - 2019-07-04 22:40:50 --> Model Class Initialized
INFO - 2019-07-04 22:40:50 --> Final output sent to browser
DEBUG - 2019-07-04 22:40:50 --> Total execution time: 0.4576
INFO - 2019-07-04 16:40:50 --> Config Class Initialized
INFO - 2019-07-04 16:40:50 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:40:50 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:40:50 --> Utf8 Class Initialized
INFO - 2019-07-04 16:40:50 --> URI Class Initialized
INFO - 2019-07-04 16:40:50 --> Router Class Initialized
INFO - 2019-07-04 16:40:50 --> Output Class Initialized
INFO - 2019-07-04 16:40:50 --> Security Class Initialized
DEBUG - 2019-07-04 16:40:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:40:50 --> Input Class Initialized
INFO - 2019-07-04 16:40:50 --> Language Class Initialized
INFO - 2019-07-04 16:40:50 --> Language Class Initialized
INFO - 2019-07-04 16:40:50 --> Config Class Initialized
INFO - 2019-07-04 16:40:50 --> Loader Class Initialized
DEBUG - 2019-07-04 16:40:50 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:40:50 --> Helper loaded: url_helper
INFO - 2019-07-04 16:40:50 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:40:50 --> Helper loaded: string_helper
INFO - 2019-07-04 16:40:50 --> Helper loaded: array_helper
INFO - 2019-07-04 16:40:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:40:50 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:40:50 --> Database Driver Class Initialized
INFO - 2019-07-04 16:40:50 --> Controller Class Initialized
INFO - 2019-07-04 22:40:50 --> Helper loaded: language_helper
INFO - 2019-07-04 22:40:50 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:40:50 --> Model Class Initialized
INFO - 2019-07-04 22:40:50 --> Model Class Initialized
INFO - 2019-07-04 22:40:50 --> Model Class Initialized
INFO - 2019-07-04 22:40:50 --> Model Class Initialized
INFO - 2019-07-04 22:40:50 --> Model Class Initialized
INFO - 2019-07-04 22:40:50 --> Final output sent to browser
DEBUG - 2019-07-04 22:40:50 --> Total execution time: 0.4719
INFO - 2019-07-04 16:41:01 --> Config Class Initialized
INFO - 2019-07-04 16:41:01 --> Config Class Initialized
INFO - 2019-07-04 16:41:01 --> Hooks Class Initialized
INFO - 2019-07-04 16:41:01 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:41:01 --> UTF-8 Support Enabled
DEBUG - 2019-07-04 16:41:01 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:41:01 --> Utf8 Class Initialized
INFO - 2019-07-04 16:41:01 --> Utf8 Class Initialized
INFO - 2019-07-04 16:41:01 --> URI Class Initialized
INFO - 2019-07-04 16:41:01 --> URI Class Initialized
INFO - 2019-07-04 16:41:01 --> Router Class Initialized
INFO - 2019-07-04 16:41:01 --> Router Class Initialized
INFO - 2019-07-04 16:41:01 --> Output Class Initialized
INFO - 2019-07-04 16:41:01 --> Output Class Initialized
INFO - 2019-07-04 16:41:01 --> Security Class Initialized
INFO - 2019-07-04 16:41:01 --> Security Class Initialized
DEBUG - 2019-07-04 16:41:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-04 16:41:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:41:01 --> Input Class Initialized
INFO - 2019-07-04 16:41:01 --> Input Class Initialized
INFO - 2019-07-04 16:41:01 --> Language Class Initialized
INFO - 2019-07-04 16:41:01 --> Language Class Initialized
INFO - 2019-07-04 16:41:01 --> Language Class Initialized
INFO - 2019-07-04 16:41:01 --> Language Class Initialized
INFO - 2019-07-04 16:41:01 --> Config Class Initialized
INFO - 2019-07-04 16:41:01 --> Loader Class Initialized
INFO - 2019-07-04 16:41:01 --> Config Class Initialized
INFO - 2019-07-04 16:41:01 --> Loader Class Initialized
DEBUG - 2019-07-04 16:41:01 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-04 16:41:01 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:41:01 --> Helper loaded: url_helper
INFO - 2019-07-04 16:41:01 --> Helper loaded: url_helper
INFO - 2019-07-04 16:41:01 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:41:01 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:41:01 --> Helper loaded: string_helper
INFO - 2019-07-04 16:41:01 --> Helper loaded: string_helper
INFO - 2019-07-04 16:41:01 --> Helper loaded: array_helper
INFO - 2019-07-04 16:41:01 --> Helper loaded: array_helper
INFO - 2019-07-04 16:41:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:41:01 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:41:01 --> Database Driver Class Initialized
INFO - 2019-07-04 16:41:01 --> Controller Class Initialized
INFO - 2019-07-04 22:41:01 --> Helper loaded: language_helper
INFO - 2019-07-04 22:41:01 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:41:01 --> Model Class Initialized
INFO - 2019-07-04 22:41:01 --> Model Class Initialized
INFO - 2019-07-04 22:41:01 --> Model Class Initialized
INFO - 2019-07-04 22:41:01 --> Model Class Initialized
INFO - 2019-07-04 22:41:01 --> Model Class Initialized
INFO - 2019-07-04 22:41:01 --> Final output sent to browser
DEBUG - 2019-07-04 22:41:01 --> Total execution time: 0.6779
INFO - 2019-07-04 16:41:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:41:01 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:41:01 --> Database Driver Class Initialized
INFO - 2019-07-04 16:41:01 --> Controller Class Initialized
INFO - 2019-07-04 22:41:01 --> Helper loaded: language_helper
INFO - 2019-07-04 22:41:01 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:41:01 --> Model Class Initialized
INFO - 2019-07-04 22:41:02 --> Model Class Initialized
INFO - 2019-07-04 22:41:02 --> Model Class Initialized
INFO - 2019-07-04 22:41:02 --> Model Class Initialized
INFO - 2019-07-04 22:41:02 --> Helper loaded: form_helper
INFO - 2019-07-04 22:41:02 --> Form Validation Class Initialized
DEBUG - 2019-07-04 22:41:02 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 22:41:02 --> Model Class Initialized
INFO - 2019-07-04 22:41:02 --> Model Class Initialized
INFO - 2019-07-04 22:41:02 --> Final output sent to browser
DEBUG - 2019-07-04 22:41:02 --> Total execution time: 0.9264
INFO - 2019-07-04 16:44:41 --> Config Class Initialized
INFO - 2019-07-04 16:44:41 --> Hooks Class Initialized
INFO - 2019-07-04 16:44:41 --> Config Class Initialized
INFO - 2019-07-04 16:44:41 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:44:41 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:44:41 --> Utf8 Class Initialized
INFO - 2019-07-04 16:44:41 --> URI Class Initialized
DEBUG - 2019-07-04 16:44:41 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:44:41 --> Router Class Initialized
INFO - 2019-07-04 16:44:41 --> Utf8 Class Initialized
INFO - 2019-07-04 16:44:41 --> URI Class Initialized
INFO - 2019-07-04 16:44:41 --> Output Class Initialized
INFO - 2019-07-04 16:44:41 --> Router Class Initialized
INFO - 2019-07-04 16:44:41 --> Security Class Initialized
INFO - 2019-07-04 16:44:41 --> Output Class Initialized
DEBUG - 2019-07-04 16:44:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:44:41 --> Security Class Initialized
INFO - 2019-07-04 16:44:41 --> Input Class Initialized
DEBUG - 2019-07-04 16:44:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:44:41 --> Language Class Initialized
INFO - 2019-07-04 16:44:41 --> Input Class Initialized
INFO - 2019-07-04 16:44:41 --> Language Class Initialized
INFO - 2019-07-04 16:44:41 --> Language Class Initialized
INFO - 2019-07-04 16:44:41 --> Language Class Initialized
INFO - 2019-07-04 16:44:41 --> Config Class Initialized
INFO - 2019-07-04 16:44:41 --> Loader Class Initialized
INFO - 2019-07-04 16:44:41 --> Config Class Initialized
INFO - 2019-07-04 16:44:41 --> Loader Class Initialized
DEBUG - 2019-07-04 16:44:41 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-04 16:44:41 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:44:41 --> Helper loaded: url_helper
INFO - 2019-07-04 16:44:41 --> Helper loaded: url_helper
INFO - 2019-07-04 16:44:41 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:44:41 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:44:41 --> Helper loaded: string_helper
INFO - 2019-07-04 16:44:41 --> Helper loaded: string_helper
INFO - 2019-07-04 16:44:41 --> Helper loaded: array_helper
INFO - 2019-07-04 16:44:41 --> Helper loaded: array_helper
INFO - 2019-07-04 16:44:41 --> Session: Class initialized using 'files' driver.
INFO - 2019-07-04 16:44:41 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:44:41 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
DEBUG - 2019-07-04 16:44:41 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:44:41 --> Database Driver Class Initialized
INFO - 2019-07-04 16:44:41 --> Database Driver Class Initialized
INFO - 2019-07-04 16:44:42 --> Controller Class Initialized
INFO - 2019-07-04 16:44:42 --> Controller Class Initialized
INFO - 2019-07-04 22:44:42 --> Helper loaded: language_helper
INFO - 2019-07-04 22:44:42 --> Helper loaded: language_helper
INFO - 2019-07-04 22:44:42 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:44:42 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:44:42 --> Model Class Initialized
INFO - 2019-07-04 22:44:42 --> Model Class Initialized
INFO - 2019-07-04 22:44:42 --> Model Class Initialized
INFO - 2019-07-04 22:44:42 --> Model Class Initialized
INFO - 2019-07-04 22:44:42 --> Model Class Initialized
INFO - 2019-07-04 22:44:42 --> Model Class Initialized
INFO - 2019-07-04 22:44:42 --> Model Class Initialized
INFO - 2019-07-04 22:44:42 --> Model Class Initialized
INFO - 2019-07-04 22:44:42 --> Helper loaded: form_helper
INFO - 2019-07-04 22:44:42 --> Model Class Initialized
INFO - 2019-07-04 22:44:42 --> Form Validation Class Initialized
INFO - 2019-07-04 22:44:42 --> Final output sent to browser
DEBUG - 2019-07-04 22:44:42 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
DEBUG - 2019-07-04 22:44:42 --> Total execution time: 0.9047
INFO - 2019-07-04 22:44:42 --> Model Class Initialized
INFO - 2019-07-04 22:44:42 --> Model Class Initialized
INFO - 2019-07-04 22:44:42 --> Final output sent to browser
DEBUG - 2019-07-04 22:44:42 --> Total execution time: 0.9598
INFO - 2019-07-04 16:45:09 --> Config Class Initialized
INFO - 2019-07-04 16:45:09 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:45:09 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:45:09 --> Utf8 Class Initialized
INFO - 2019-07-04 16:45:09 --> URI Class Initialized
INFO - 2019-07-04 16:45:09 --> Router Class Initialized
INFO - 2019-07-04 16:45:09 --> Output Class Initialized
INFO - 2019-07-04 16:45:09 --> Security Class Initialized
DEBUG - 2019-07-04 16:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:45:09 --> Input Class Initialized
INFO - 2019-07-04 16:45:09 --> Language Class Initialized
INFO - 2019-07-04 16:45:09 --> Language Class Initialized
INFO - 2019-07-04 16:45:09 --> Config Class Initialized
INFO - 2019-07-04 16:45:09 --> Loader Class Initialized
DEBUG - 2019-07-04 16:45:09 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:45:09 --> Helper loaded: url_helper
INFO - 2019-07-04 16:45:09 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:45:09 --> Helper loaded: string_helper
INFO - 2019-07-04 16:45:09 --> Helper loaded: array_helper
INFO - 2019-07-04 16:45:09 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:45:09 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:45:09 --> Database Driver Class Initialized
INFO - 2019-07-04 16:45:09 --> Controller Class Initialized
INFO - 2019-07-04 22:45:09 --> Helper loaded: language_helper
INFO - 2019-07-04 22:45:09 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:45:09 --> Model Class Initialized
INFO - 2019-07-04 22:45:09 --> Model Class Initialized
INFO - 2019-07-04 22:45:09 --> Model Class Initialized
INFO - 2019-07-04 22:45:09 --> Model Class Initialized
INFO - 2019-07-04 22:45:09 --> Final output sent to browser
DEBUG - 2019-07-04 22:45:09 --> Total execution time: 0.4847
INFO - 2019-07-04 16:45:09 --> Config Class Initialized
INFO - 2019-07-04 16:45:09 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:45:09 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:45:09 --> Utf8 Class Initialized
INFO - 2019-07-04 16:45:09 --> URI Class Initialized
INFO - 2019-07-04 16:45:09 --> Router Class Initialized
INFO - 2019-07-04 16:45:09 --> Output Class Initialized
INFO - 2019-07-04 16:45:09 --> Security Class Initialized
DEBUG - 2019-07-04 16:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:45:10 --> Input Class Initialized
INFO - 2019-07-04 16:45:10 --> Language Class Initialized
INFO - 2019-07-04 16:45:10 --> Language Class Initialized
INFO - 2019-07-04 16:45:10 --> Config Class Initialized
INFO - 2019-07-04 16:45:10 --> Loader Class Initialized
DEBUG - 2019-07-04 16:45:10 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:45:10 --> Helper loaded: url_helper
INFO - 2019-07-04 16:45:10 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:45:10 --> Helper loaded: string_helper
INFO - 2019-07-04 16:45:10 --> Helper loaded: array_helper
INFO - 2019-07-04 16:45:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:45:10 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:45:10 --> Database Driver Class Initialized
INFO - 2019-07-04 16:45:10 --> Controller Class Initialized
INFO - 2019-07-04 22:45:10 --> Helper loaded: language_helper
INFO - 2019-07-04 22:45:10 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:45:10 --> Model Class Initialized
INFO - 2019-07-04 22:45:10 --> Model Class Initialized
INFO - 2019-07-04 22:45:10 --> Model Class Initialized
INFO - 2019-07-04 22:45:10 --> Model Class Initialized
INFO - 2019-07-04 22:45:10 --> Model Class Initialized
INFO - 2019-07-04 22:45:10 --> Final output sent to browser
DEBUG - 2019-07-04 22:45:10 --> Total execution time: 0.4770
INFO - 2019-07-04 16:45:11 --> Config Class Initialized
INFO - 2019-07-04 16:45:11 --> Config Class Initialized
INFO - 2019-07-04 16:45:11 --> Hooks Class Initialized
INFO - 2019-07-04 16:45:11 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:45:11 --> UTF-8 Support Enabled
DEBUG - 2019-07-04 16:45:11 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:45:11 --> Utf8 Class Initialized
INFO - 2019-07-04 16:45:11 --> Utf8 Class Initialized
INFO - 2019-07-04 16:45:11 --> URI Class Initialized
INFO - 2019-07-04 16:45:11 --> URI Class Initialized
INFO - 2019-07-04 16:45:11 --> Router Class Initialized
INFO - 2019-07-04 16:45:11 --> Router Class Initialized
INFO - 2019-07-04 16:45:11 --> Output Class Initialized
INFO - 2019-07-04 16:45:11 --> Output Class Initialized
INFO - 2019-07-04 16:45:11 --> Security Class Initialized
INFO - 2019-07-04 16:45:11 --> Security Class Initialized
DEBUG - 2019-07-04 16:45:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-04 16:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:45:11 --> Input Class Initialized
INFO - 2019-07-04 16:45:11 --> Input Class Initialized
INFO - 2019-07-04 16:45:11 --> Language Class Initialized
INFO - 2019-07-04 16:45:11 --> Language Class Initialized
INFO - 2019-07-04 16:45:11 --> Language Class Initialized
INFO - 2019-07-04 16:45:11 --> Language Class Initialized
INFO - 2019-07-04 16:45:11 --> Config Class Initialized
INFO - 2019-07-04 16:45:11 --> Loader Class Initialized
INFO - 2019-07-04 16:45:11 --> Config Class Initialized
INFO - 2019-07-04 16:45:11 --> Loader Class Initialized
DEBUG - 2019-07-04 16:45:11 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-04 16:45:11 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:45:11 --> Helper loaded: url_helper
INFO - 2019-07-04 16:45:11 --> Helper loaded: url_helper
INFO - 2019-07-04 16:45:11 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:45:11 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:45:11 --> Helper loaded: string_helper
INFO - 2019-07-04 16:45:11 --> Helper loaded: string_helper
INFO - 2019-07-04 16:45:11 --> Helper loaded: array_helper
INFO - 2019-07-04 16:45:11 --> Helper loaded: array_helper
INFO - 2019-07-04 16:45:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:45:11 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:45:11 --> Database Driver Class Initialized
INFO - 2019-07-04 16:45:12 --> Controller Class Initialized
INFO - 2019-07-04 22:45:12 --> Helper loaded: language_helper
INFO - 2019-07-04 22:45:12 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:45:12 --> Model Class Initialized
INFO - 2019-07-04 22:45:12 --> Model Class Initialized
INFO - 2019-07-04 22:45:12 --> Model Class Initialized
INFO - 2019-07-04 22:45:12 --> Model Class Initialized
INFO - 2019-07-04 22:45:12 --> Model Class Initialized
INFO - 2019-07-04 22:45:12 --> Final output sent to browser
DEBUG - 2019-07-04 22:45:12 --> Total execution time: 0.6295
INFO - 2019-07-04 16:45:12 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:45:12 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:45:12 --> Database Driver Class Initialized
INFO - 2019-07-04 16:45:12 --> Controller Class Initialized
INFO - 2019-07-04 22:45:12 --> Helper loaded: language_helper
INFO - 2019-07-04 22:45:12 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:45:12 --> Model Class Initialized
INFO - 2019-07-04 22:45:12 --> Model Class Initialized
INFO - 2019-07-04 22:45:12 --> Model Class Initialized
INFO - 2019-07-04 22:45:12 --> Model Class Initialized
INFO - 2019-07-04 22:45:12 --> Helper loaded: form_helper
INFO - 2019-07-04 22:45:12 --> Form Validation Class Initialized
DEBUG - 2019-07-04 22:45:12 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 22:45:12 --> Model Class Initialized
INFO - 2019-07-04 22:45:12 --> Model Class Initialized
INFO - 2019-07-04 22:45:12 --> Final output sent to browser
DEBUG - 2019-07-04 22:45:12 --> Total execution time: 0.8932
INFO - 2019-07-04 16:45:26 --> Config Class Initialized
INFO - 2019-07-04 16:45:26 --> Config Class Initialized
INFO - 2019-07-04 16:45:26 --> Hooks Class Initialized
INFO - 2019-07-04 16:45:26 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:45:26 --> UTF-8 Support Enabled
DEBUG - 2019-07-04 16:45:26 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:45:26 --> Utf8 Class Initialized
INFO - 2019-07-04 16:45:26 --> Utf8 Class Initialized
INFO - 2019-07-04 16:45:26 --> URI Class Initialized
INFO - 2019-07-04 16:45:26 --> URI Class Initialized
INFO - 2019-07-04 16:45:26 --> Router Class Initialized
INFO - 2019-07-04 16:45:26 --> Router Class Initialized
INFO - 2019-07-04 16:45:26 --> Output Class Initialized
INFO - 2019-07-04 16:45:26 --> Output Class Initialized
INFO - 2019-07-04 16:45:26 --> Security Class Initialized
INFO - 2019-07-04 16:45:26 --> Security Class Initialized
DEBUG - 2019-07-04 16:45:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-04 16:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:45:26 --> Input Class Initialized
INFO - 2019-07-04 16:45:26 --> Input Class Initialized
INFO - 2019-07-04 16:45:26 --> Language Class Initialized
INFO - 2019-07-04 16:45:26 --> Language Class Initialized
INFO - 2019-07-04 16:45:26 --> Language Class Initialized
INFO - 2019-07-04 16:45:26 --> Language Class Initialized
INFO - 2019-07-04 16:45:26 --> Config Class Initialized
INFO - 2019-07-04 16:45:26 --> Config Class Initialized
INFO - 2019-07-04 16:45:26 --> Loader Class Initialized
INFO - 2019-07-04 16:45:26 --> Loader Class Initialized
DEBUG - 2019-07-04 16:45:26 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-04 16:45:26 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:45:26 --> Helper loaded: url_helper
INFO - 2019-07-04 16:45:26 --> Helper loaded: url_helper
INFO - 2019-07-04 16:45:26 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:45:26 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:45:26 --> Helper loaded: string_helper
INFO - 2019-07-04 16:45:27 --> Helper loaded: string_helper
INFO - 2019-07-04 16:45:27 --> Helper loaded: array_helper
INFO - 2019-07-04 16:45:27 --> Helper loaded: array_helper
INFO - 2019-07-04 16:45:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:45:27 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:45:27 --> Database Driver Class Initialized
INFO - 2019-07-04 16:45:27 --> Controller Class Initialized
INFO - 2019-07-04 22:45:27 --> Helper loaded: language_helper
INFO - 2019-07-04 22:45:27 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:45:27 --> Model Class Initialized
INFO - 2019-07-04 22:45:27 --> Model Class Initialized
INFO - 2019-07-04 22:45:27 --> Model Class Initialized
INFO - 2019-07-04 22:45:27 --> Model Class Initialized
INFO - 2019-07-04 22:45:27 --> Helper loaded: form_helper
INFO - 2019-07-04 22:45:27 --> Form Validation Class Initialized
DEBUG - 2019-07-04 22:45:27 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 22:45:27 --> Model Class Initialized
INFO - 2019-07-04 22:45:27 --> Model Class Initialized
INFO - 2019-07-04 22:45:27 --> Final output sent to browser
DEBUG - 2019-07-04 22:45:27 --> Total execution time: 0.6882
INFO - 2019-07-04 16:45:27 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:45:27 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:45:27 --> Database Driver Class Initialized
INFO - 2019-07-04 16:45:27 --> Controller Class Initialized
INFO - 2019-07-04 22:45:27 --> Helper loaded: language_helper
INFO - 2019-07-04 22:45:27 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:45:27 --> Model Class Initialized
INFO - 2019-07-04 22:45:27 --> Model Class Initialized
INFO - 2019-07-04 22:45:27 --> Model Class Initialized
INFO - 2019-07-04 22:45:27 --> Model Class Initialized
INFO - 2019-07-04 22:45:27 --> Model Class Initialized
INFO - 2019-07-04 22:45:27 --> Final output sent to browser
DEBUG - 2019-07-04 22:45:27 --> Total execution time: 0.8817
INFO - 2019-07-04 16:45:41 --> Config Class Initialized
INFO - 2019-07-04 16:45:41 --> Config Class Initialized
INFO - 2019-07-04 16:45:41 --> Hooks Class Initialized
INFO - 2019-07-04 16:45:41 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:45:41 --> UTF-8 Support Enabled
DEBUG - 2019-07-04 16:45:41 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:45:41 --> Utf8 Class Initialized
INFO - 2019-07-04 16:45:41 --> Utf8 Class Initialized
INFO - 2019-07-04 16:45:41 --> URI Class Initialized
INFO - 2019-07-04 16:45:41 --> URI Class Initialized
INFO - 2019-07-04 16:45:41 --> Router Class Initialized
INFO - 2019-07-04 16:45:41 --> Router Class Initialized
INFO - 2019-07-04 16:45:41 --> Output Class Initialized
INFO - 2019-07-04 16:45:41 --> Output Class Initialized
INFO - 2019-07-04 16:45:41 --> Security Class Initialized
INFO - 2019-07-04 16:45:41 --> Security Class Initialized
DEBUG - 2019-07-04 16:45:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-04 16:45:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:45:41 --> Input Class Initialized
INFO - 2019-07-04 16:45:41 --> Input Class Initialized
INFO - 2019-07-04 16:45:41 --> Language Class Initialized
INFO - 2019-07-04 16:45:41 --> Language Class Initialized
INFO - 2019-07-04 16:45:41 --> Language Class Initialized
INFO - 2019-07-04 16:45:41 --> Language Class Initialized
INFO - 2019-07-04 16:45:41 --> Config Class Initialized
INFO - 2019-07-04 16:45:41 --> Config Class Initialized
INFO - 2019-07-04 16:45:41 --> Loader Class Initialized
INFO - 2019-07-04 16:45:42 --> Loader Class Initialized
DEBUG - 2019-07-04 16:45:42 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-04 16:45:42 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:45:42 --> Helper loaded: url_helper
INFO - 2019-07-04 16:45:42 --> Helper loaded: url_helper
INFO - 2019-07-04 16:45:42 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:45:42 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:45:42 --> Helper loaded: string_helper
INFO - 2019-07-04 16:45:42 --> Helper loaded: string_helper
INFO - 2019-07-04 16:45:42 --> Helper loaded: array_helper
INFO - 2019-07-04 16:45:42 --> Helper loaded: array_helper
INFO - 2019-07-04 16:45:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:45:42 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:45:42 --> Database Driver Class Initialized
INFO - 2019-07-04 16:45:42 --> Controller Class Initialized
INFO - 2019-07-04 22:45:42 --> Helper loaded: language_helper
INFO - 2019-07-04 22:45:42 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:45:42 --> Model Class Initialized
INFO - 2019-07-04 22:45:42 --> Model Class Initialized
INFO - 2019-07-04 22:45:42 --> Model Class Initialized
INFO - 2019-07-04 22:45:42 --> Model Class Initialized
INFO - 2019-07-04 22:45:42 --> Helper loaded: form_helper
INFO - 2019-07-04 22:45:42 --> Form Validation Class Initialized
DEBUG - 2019-07-04 22:45:42 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 22:45:42 --> Model Class Initialized
INFO - 2019-07-04 22:45:42 --> Model Class Initialized
INFO - 2019-07-04 22:45:42 --> Final output sent to browser
DEBUG - 2019-07-04 22:45:42 --> Total execution time: 0.6934
INFO - 2019-07-04 16:45:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:45:42 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:45:42 --> Database Driver Class Initialized
INFO - 2019-07-04 16:45:42 --> Controller Class Initialized
INFO - 2019-07-04 22:45:42 --> Helper loaded: language_helper
INFO - 2019-07-04 22:45:42 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:45:42 --> Model Class Initialized
INFO - 2019-07-04 22:45:42 --> Model Class Initialized
INFO - 2019-07-04 22:45:42 --> Model Class Initialized
INFO - 2019-07-04 22:45:42 --> Model Class Initialized
INFO - 2019-07-04 22:45:42 --> Model Class Initialized
INFO - 2019-07-04 22:45:42 --> Final output sent to browser
DEBUG - 2019-07-04 22:45:42 --> Total execution time: 0.8855
INFO - 2019-07-04 16:45:47 --> Config Class Initialized
INFO - 2019-07-04 16:45:47 --> Hooks Class Initialized
INFO - 2019-07-04 16:45:47 --> Config Class Initialized
DEBUG - 2019-07-04 16:45:47 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:45:47 --> Hooks Class Initialized
INFO - 2019-07-04 16:45:47 --> Utf8 Class Initialized
DEBUG - 2019-07-04 16:45:47 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:45:47 --> URI Class Initialized
INFO - 2019-07-04 16:45:47 --> Utf8 Class Initialized
INFO - 2019-07-04 16:45:47 --> Router Class Initialized
INFO - 2019-07-04 16:45:47 --> URI Class Initialized
INFO - 2019-07-04 16:45:47 --> Output Class Initialized
INFO - 2019-07-04 16:45:47 --> Router Class Initialized
INFO - 2019-07-04 16:45:47 --> Security Class Initialized
INFO - 2019-07-04 16:45:47 --> Output Class Initialized
DEBUG - 2019-07-04 16:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:45:47 --> Security Class Initialized
INFO - 2019-07-04 16:45:47 --> Input Class Initialized
INFO - 2019-07-04 16:45:47 --> Language Class Initialized
DEBUG - 2019-07-04 16:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:45:47 --> Language Class Initialized
INFO - 2019-07-04 16:45:47 --> Input Class Initialized
INFO - 2019-07-04 16:45:47 --> Config Class Initialized
INFO - 2019-07-04 16:45:47 --> Language Class Initialized
INFO - 2019-07-04 16:45:47 --> Loader Class Initialized
DEBUG - 2019-07-04 16:45:48 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:45:48 --> Language Class Initialized
INFO - 2019-07-04 16:45:48 --> Helper loaded: url_helper
INFO - 2019-07-04 16:45:48 --> Config Class Initialized
INFO - 2019-07-04 16:45:48 --> Loader Class Initialized
INFO - 2019-07-04 16:45:48 --> Helper loaded: inflector_helper
DEBUG - 2019-07-04 16:45:48 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:45:48 --> Helper loaded: string_helper
INFO - 2019-07-04 16:45:48 --> Helper loaded: url_helper
INFO - 2019-07-04 16:45:48 --> Helper loaded: array_helper
INFO - 2019-07-04 16:45:48 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:45:48 --> Session: Class initialized using 'files' driver.
INFO - 2019-07-04 16:45:48 --> Helper loaded: string_helper
DEBUG - 2019-07-04 16:45:48 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:45:48 --> Helper loaded: array_helper
INFO - 2019-07-04 16:45:48 --> Database Driver Class Initialized
INFO - 2019-07-04 16:45:48 --> Controller Class Initialized
INFO - 2019-07-04 22:45:48 --> Helper loaded: language_helper
INFO - 2019-07-04 22:45:48 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:45:48 --> Model Class Initialized
INFO - 2019-07-04 22:45:48 --> Model Class Initialized
INFO - 2019-07-04 22:45:48 --> Model Class Initialized
INFO - 2019-07-04 22:45:48 --> Model Class Initialized
INFO - 2019-07-04 22:45:48 --> Model Class Initialized
INFO - 2019-07-04 22:45:48 --> Final output sent to browser
DEBUG - 2019-07-04 22:45:48 --> Total execution time: 0.6168
INFO - 2019-07-04 16:45:48 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:45:48 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:45:48 --> Database Driver Class Initialized
INFO - 2019-07-04 16:45:48 --> Controller Class Initialized
INFO - 2019-07-04 22:45:48 --> Helper loaded: language_helper
INFO - 2019-07-04 22:45:48 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:45:48 --> Model Class Initialized
INFO - 2019-07-04 22:45:48 --> Model Class Initialized
INFO - 2019-07-04 22:45:48 --> Model Class Initialized
INFO - 2019-07-04 22:45:48 --> Model Class Initialized
INFO - 2019-07-04 22:45:48 --> Helper loaded: form_helper
INFO - 2019-07-04 22:45:48 --> Form Validation Class Initialized
DEBUG - 2019-07-04 22:45:48 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 22:45:48 --> Model Class Initialized
INFO - 2019-07-04 22:45:48 --> Model Class Initialized
INFO - 2019-07-04 22:45:48 --> Final output sent to browser
DEBUG - 2019-07-04 22:45:48 --> Total execution time: 0.8762
INFO - 2019-07-04 16:46:52 --> Config Class Initialized
INFO - 2019-07-04 16:46:52 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:46:52 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:46:52 --> Utf8 Class Initialized
INFO - 2019-07-04 16:46:52 --> URI Class Initialized
INFO - 2019-07-04 16:46:52 --> Router Class Initialized
INFO - 2019-07-04 16:46:52 --> Output Class Initialized
INFO - 2019-07-04 16:46:52 --> Security Class Initialized
DEBUG - 2019-07-04 16:46:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:46:52 --> Input Class Initialized
INFO - 2019-07-04 16:46:52 --> Language Class Initialized
INFO - 2019-07-04 16:46:52 --> Language Class Initialized
INFO - 2019-07-04 16:46:52 --> Config Class Initialized
INFO - 2019-07-04 16:46:52 --> Loader Class Initialized
DEBUG - 2019-07-04 16:46:52 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:46:52 --> Helper loaded: url_helper
INFO - 2019-07-04 16:46:52 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:46:52 --> Helper loaded: string_helper
INFO - 2019-07-04 16:46:52 --> Helper loaded: array_helper
INFO - 2019-07-04 16:46:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:46:52 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:46:52 --> Database Driver Class Initialized
INFO - 2019-07-04 16:46:52 --> Controller Class Initialized
INFO - 2019-07-04 22:46:52 --> Helper loaded: language_helper
INFO - 2019-07-04 22:46:52 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:46:52 --> Model Class Initialized
INFO - 2019-07-04 22:46:52 --> Model Class Initialized
INFO - 2019-07-04 22:46:52 --> Model Class Initialized
INFO - 2019-07-04 22:46:52 --> Model Class Initialized
INFO - 2019-07-04 22:46:52 --> Helper loaded: form_helper
INFO - 2019-07-04 22:46:52 --> Form Validation Class Initialized
DEBUG - 2019-07-04 22:46:52 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 22:46:52 --> Model Class Initialized
INFO - 2019-07-04 22:46:52 --> Model Class Initialized
INFO - 2019-07-04 22:46:52 --> Final output sent to browser
DEBUG - 2019-07-04 22:46:52 --> Total execution time: 0.5211
INFO - 2019-07-04 16:46:54 --> Config Class Initialized
INFO - 2019-07-04 16:46:54 --> Hooks Class Initialized
INFO - 2019-07-04 16:46:54 --> Config Class Initialized
INFO - 2019-07-04 16:46:54 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:46:54 --> UTF-8 Support Enabled
DEBUG - 2019-07-04 16:46:54 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:46:54 --> Utf8 Class Initialized
INFO - 2019-07-04 16:46:54 --> Utf8 Class Initialized
INFO - 2019-07-04 16:46:54 --> URI Class Initialized
INFO - 2019-07-04 16:46:54 --> URI Class Initialized
INFO - 2019-07-04 16:46:54 --> Router Class Initialized
INFO - 2019-07-04 16:46:55 --> Router Class Initialized
INFO - 2019-07-04 16:46:55 --> Output Class Initialized
INFO - 2019-07-04 16:46:55 --> Output Class Initialized
INFO - 2019-07-04 16:46:55 --> Security Class Initialized
INFO - 2019-07-04 16:46:55 --> Security Class Initialized
DEBUG - 2019-07-04 16:46:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-04 16:46:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:46:55 --> Input Class Initialized
INFO - 2019-07-04 16:46:55 --> Input Class Initialized
INFO - 2019-07-04 16:46:55 --> Language Class Initialized
INFO - 2019-07-04 16:46:55 --> Language Class Initialized
INFO - 2019-07-04 16:46:55 --> Language Class Initialized
INFO - 2019-07-04 16:46:55 --> Language Class Initialized
INFO - 2019-07-04 16:46:55 --> Config Class Initialized
INFO - 2019-07-04 16:46:55 --> Config Class Initialized
INFO - 2019-07-04 16:46:55 --> Loader Class Initialized
INFO - 2019-07-04 16:46:55 --> Loader Class Initialized
DEBUG - 2019-07-04 16:46:55 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-04 16:46:55 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:46:55 --> Helper loaded: url_helper
INFO - 2019-07-04 16:46:55 --> Helper loaded: url_helper
INFO - 2019-07-04 16:46:55 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:46:55 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:46:55 --> Helper loaded: string_helper
INFO - 2019-07-04 16:46:55 --> Helper loaded: string_helper
INFO - 2019-07-04 16:46:55 --> Helper loaded: array_helper
INFO - 2019-07-04 16:46:55 --> Helper loaded: array_helper
INFO - 2019-07-04 16:46:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:46:55 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:46:55 --> Database Driver Class Initialized
INFO - 2019-07-04 16:46:55 --> Controller Class Initialized
INFO - 2019-07-04 22:46:55 --> Helper loaded: language_helper
INFO - 2019-07-04 22:46:55 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:46:55 --> Model Class Initialized
INFO - 2019-07-04 22:46:55 --> Model Class Initialized
INFO - 2019-07-04 22:46:55 --> Model Class Initialized
INFO - 2019-07-04 22:46:55 --> Model Class Initialized
INFO - 2019-07-04 22:46:55 --> Model Class Initialized
INFO - 2019-07-04 22:46:55 --> Final output sent to browser
DEBUG - 2019-07-04 22:46:55 --> Total execution time: 0.6550
INFO - 2019-07-04 16:46:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:46:55 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:46:55 --> Database Driver Class Initialized
INFO - 2019-07-04 16:46:55 --> Controller Class Initialized
INFO - 2019-07-04 22:46:55 --> Helper loaded: language_helper
INFO - 2019-07-04 22:46:55 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:46:55 --> Model Class Initialized
INFO - 2019-07-04 22:46:55 --> Model Class Initialized
INFO - 2019-07-04 22:46:55 --> Model Class Initialized
INFO - 2019-07-04 22:46:55 --> Model Class Initialized
INFO - 2019-07-04 22:46:55 --> Helper loaded: form_helper
INFO - 2019-07-04 22:46:55 --> Form Validation Class Initialized
DEBUG - 2019-07-04 22:46:55 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 22:46:55 --> Model Class Initialized
INFO - 2019-07-04 22:46:55 --> Model Class Initialized
INFO - 2019-07-04 22:46:55 --> Final output sent to browser
DEBUG - 2019-07-04 22:46:55 --> Total execution time: 0.9051
INFO - 2019-07-04 16:55:00 --> Config Class Initialized
INFO - 2019-07-04 16:55:00 --> Hooks Class Initialized
INFO - 2019-07-04 16:55:00 --> Config Class Initialized
DEBUG - 2019-07-04 16:55:00 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:55:00 --> Hooks Class Initialized
INFO - 2019-07-04 16:55:00 --> Utf8 Class Initialized
DEBUG - 2019-07-04 16:55:01 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:55:01 --> URI Class Initialized
INFO - 2019-07-04 16:55:01 --> Utf8 Class Initialized
INFO - 2019-07-04 16:55:01 --> URI Class Initialized
INFO - 2019-07-04 16:55:01 --> Router Class Initialized
INFO - 2019-07-04 16:55:01 --> Router Class Initialized
INFO - 2019-07-04 16:55:01 --> Output Class Initialized
INFO - 2019-07-04 16:55:01 --> Output Class Initialized
INFO - 2019-07-04 16:55:01 --> Security Class Initialized
INFO - 2019-07-04 16:55:01 --> Security Class Initialized
DEBUG - 2019-07-04 16:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:55:01 --> Input Class Initialized
DEBUG - 2019-07-04 16:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:55:01 --> Language Class Initialized
INFO - 2019-07-04 16:55:01 --> Input Class Initialized
INFO - 2019-07-04 16:55:01 --> Language Class Initialized
INFO - 2019-07-04 16:55:01 --> Config Class Initialized
INFO - 2019-07-04 16:55:01 --> Language Class Initialized
INFO - 2019-07-04 16:55:01 --> Loader Class Initialized
INFO - 2019-07-04 16:55:01 --> Language Class Initialized
DEBUG - 2019-07-04 16:55:01 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:55:01 --> Config Class Initialized
INFO - 2019-07-04 16:55:01 --> Loader Class Initialized
INFO - 2019-07-04 16:55:01 --> Helper loaded: url_helper
DEBUG - 2019-07-04 16:55:01 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:55:01 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:55:01 --> Helper loaded: url_helper
INFO - 2019-07-04 16:55:01 --> Helper loaded: string_helper
INFO - 2019-07-04 16:55:01 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:55:01 --> Helper loaded: array_helper
INFO - 2019-07-04 16:55:01 --> Helper loaded: string_helper
INFO - 2019-07-04 16:55:01 --> Session: Class initialized using 'files' driver.
INFO - 2019-07-04 16:55:01 --> Helper loaded: array_helper
DEBUG - 2019-07-04 16:55:01 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:55:01 --> Database Driver Class Initialized
INFO - 2019-07-04 16:55:01 --> Controller Class Initialized
INFO - 2019-07-04 22:55:01 --> Helper loaded: language_helper
INFO - 2019-07-04 22:55:01 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:55:01 --> Model Class Initialized
INFO - 2019-07-04 22:55:01 --> Model Class Initialized
INFO - 2019-07-04 22:55:01 --> Model Class Initialized
INFO - 2019-07-04 22:55:01 --> Model Class Initialized
INFO - 2019-07-04 22:55:01 --> Model Class Initialized
INFO - 2019-07-04 22:55:01 --> Final output sent to browser
DEBUG - 2019-07-04 22:55:01 --> Total execution time: 0.8393
INFO - 2019-07-04 16:55:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:55:01 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:55:01 --> Database Driver Class Initialized
INFO - 2019-07-04 16:55:01 --> Controller Class Initialized
INFO - 2019-07-04 22:55:01 --> Helper loaded: language_helper
INFO - 2019-07-04 22:55:01 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:55:01 --> Model Class Initialized
INFO - 2019-07-04 22:55:01 --> Model Class Initialized
INFO - 2019-07-04 22:55:01 --> Model Class Initialized
INFO - 2019-07-04 22:55:01 --> Model Class Initialized
INFO - 2019-07-04 22:55:01 --> Helper loaded: form_helper
INFO - 2019-07-04 22:55:01 --> Form Validation Class Initialized
DEBUG - 2019-07-04 22:55:01 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 22:55:02 --> Model Class Initialized
INFO - 2019-07-04 22:55:02 --> Model Class Initialized
INFO - 2019-07-04 22:55:02 --> Final output sent to browser
DEBUG - 2019-07-04 22:55:02 --> Total execution time: 1.1415
INFO - 2019-07-04 16:55:05 --> Config Class Initialized
INFO - 2019-07-04 16:55:05 --> Hooks Class Initialized
INFO - 2019-07-04 16:55:05 --> Config Class Initialized
INFO - 2019-07-04 16:55:05 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:55:05 --> UTF-8 Support Enabled
DEBUG - 2019-07-04 16:55:05 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:55:05 --> Utf8 Class Initialized
INFO - 2019-07-04 16:55:05 --> Utf8 Class Initialized
INFO - 2019-07-04 16:55:05 --> URI Class Initialized
INFO - 2019-07-04 16:55:05 --> URI Class Initialized
INFO - 2019-07-04 16:55:05 --> Router Class Initialized
INFO - 2019-07-04 16:55:05 --> Router Class Initialized
INFO - 2019-07-04 16:55:05 --> Output Class Initialized
INFO - 2019-07-04 16:55:05 --> Output Class Initialized
INFO - 2019-07-04 16:55:05 --> Security Class Initialized
INFO - 2019-07-04 16:55:05 --> Security Class Initialized
DEBUG - 2019-07-04 16:55:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-04 16:55:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:55:05 --> Input Class Initialized
INFO - 2019-07-04 16:55:05 --> Input Class Initialized
INFO - 2019-07-04 16:55:05 --> Language Class Initialized
INFO - 2019-07-04 16:55:05 --> Language Class Initialized
INFO - 2019-07-04 16:55:05 --> Language Class Initialized
INFO - 2019-07-04 16:55:05 --> Language Class Initialized
INFO - 2019-07-04 16:55:05 --> Config Class Initialized
INFO - 2019-07-04 16:55:05 --> Config Class Initialized
INFO - 2019-07-04 16:55:05 --> Loader Class Initialized
INFO - 2019-07-04 16:55:05 --> Loader Class Initialized
DEBUG - 2019-07-04 16:55:05 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-04 16:55:05 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:55:05 --> Helper loaded: url_helper
INFO - 2019-07-04 16:55:05 --> Helper loaded: url_helper
INFO - 2019-07-04 16:55:05 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:55:05 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:55:05 --> Helper loaded: string_helper
INFO - 2019-07-04 16:55:05 --> Helper loaded: string_helper
INFO - 2019-07-04 16:55:05 --> Helper loaded: array_helper
INFO - 2019-07-04 16:55:05 --> Helper loaded: array_helper
INFO - 2019-07-04 16:55:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:55:06 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:55:06 --> Database Driver Class Initialized
INFO - 2019-07-04 16:55:06 --> Controller Class Initialized
INFO - 2019-07-04 22:55:06 --> Helper loaded: language_helper
INFO - 2019-07-04 22:55:06 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:55:06 --> Model Class Initialized
INFO - 2019-07-04 22:55:06 --> Model Class Initialized
INFO - 2019-07-04 22:55:06 --> Model Class Initialized
INFO - 2019-07-04 22:55:06 --> Model Class Initialized
INFO - 2019-07-04 22:55:06 --> Helper loaded: form_helper
INFO - 2019-07-04 22:55:06 --> Form Validation Class Initialized
DEBUG - 2019-07-04 22:55:06 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 22:55:06 --> Model Class Initialized
INFO - 2019-07-04 22:55:06 --> Model Class Initialized
INFO - 2019-07-04 22:55:06 --> Final output sent to browser
DEBUG - 2019-07-04 22:55:06 --> Total execution time: 0.6531
INFO - 2019-07-04 16:55:06 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:55:06 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:55:06 --> Database Driver Class Initialized
INFO - 2019-07-04 16:55:06 --> Controller Class Initialized
INFO - 2019-07-04 22:55:06 --> Helper loaded: language_helper
INFO - 2019-07-04 22:55:06 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:55:06 --> Model Class Initialized
INFO - 2019-07-04 22:55:06 --> Model Class Initialized
INFO - 2019-07-04 22:55:06 --> Model Class Initialized
INFO - 2019-07-04 22:55:06 --> Model Class Initialized
INFO - 2019-07-04 22:55:06 --> Model Class Initialized
INFO - 2019-07-04 22:55:06 --> Final output sent to browser
DEBUG - 2019-07-04 22:55:06 --> Total execution time: 0.8880
INFO - 2019-07-04 16:56:36 --> Config Class Initialized
INFO - 2019-07-04 16:56:36 --> Config Class Initialized
INFO - 2019-07-04 16:56:36 --> Hooks Class Initialized
INFO - 2019-07-04 16:56:36 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:56:36 --> UTF-8 Support Enabled
DEBUG - 2019-07-04 16:56:36 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:56:36 --> Utf8 Class Initialized
INFO - 2019-07-04 16:56:36 --> Utf8 Class Initialized
INFO - 2019-07-04 16:56:36 --> URI Class Initialized
INFO - 2019-07-04 16:56:36 --> URI Class Initialized
INFO - 2019-07-04 16:56:36 --> Router Class Initialized
INFO - 2019-07-04 16:56:36 --> Router Class Initialized
INFO - 2019-07-04 16:56:36 --> Output Class Initialized
INFO - 2019-07-04 16:56:36 --> Output Class Initialized
INFO - 2019-07-04 16:56:36 --> Security Class Initialized
INFO - 2019-07-04 16:56:36 --> Security Class Initialized
DEBUG - 2019-07-04 16:56:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-04 16:56:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:56:36 --> Input Class Initialized
INFO - 2019-07-04 16:56:36 --> Input Class Initialized
INFO - 2019-07-04 16:56:36 --> Language Class Initialized
INFO - 2019-07-04 16:56:36 --> Language Class Initialized
INFO - 2019-07-04 16:56:36 --> Language Class Initialized
INFO - 2019-07-04 16:56:36 --> Language Class Initialized
INFO - 2019-07-04 16:56:36 --> Config Class Initialized
INFO - 2019-07-04 16:56:36 --> Config Class Initialized
INFO - 2019-07-04 16:56:36 --> Loader Class Initialized
INFO - 2019-07-04 16:56:36 --> Loader Class Initialized
DEBUG - 2019-07-04 16:56:36 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-04 16:56:36 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:56:36 --> Helper loaded: url_helper
INFO - 2019-07-04 16:56:36 --> Helper loaded: url_helper
INFO - 2019-07-04 16:56:36 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:56:36 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:56:36 --> Helper loaded: string_helper
INFO - 2019-07-04 16:56:36 --> Helper loaded: string_helper
INFO - 2019-07-04 16:56:36 --> Helper loaded: array_helper
INFO - 2019-07-04 16:56:37 --> Helper loaded: array_helper
INFO - 2019-07-04 16:56:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:56:37 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:56:37 --> Database Driver Class Initialized
INFO - 2019-07-04 16:56:37 --> Controller Class Initialized
INFO - 2019-07-04 22:56:37 --> Helper loaded: language_helper
INFO - 2019-07-04 22:56:37 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:56:37 --> Model Class Initialized
INFO - 2019-07-04 22:56:37 --> Model Class Initialized
INFO - 2019-07-04 22:56:37 --> Model Class Initialized
INFO - 2019-07-04 22:56:37 --> Model Class Initialized
INFO - 2019-07-04 22:56:37 --> Helper loaded: form_helper
INFO - 2019-07-04 22:56:37 --> Form Validation Class Initialized
DEBUG - 2019-07-04 22:56:37 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 22:56:37 --> Model Class Initialized
INFO - 2019-07-04 22:56:37 --> Model Class Initialized
INFO - 2019-07-04 22:56:37 --> Final output sent to browser
DEBUG - 2019-07-04 22:56:37 --> Total execution time: 0.7323
INFO - 2019-07-04 16:56:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:56:37 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:56:37 --> Database Driver Class Initialized
INFO - 2019-07-04 16:56:37 --> Controller Class Initialized
INFO - 2019-07-04 22:56:37 --> Helper loaded: language_helper
INFO - 2019-07-04 22:56:37 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:56:37 --> Model Class Initialized
INFO - 2019-07-04 22:56:37 --> Model Class Initialized
INFO - 2019-07-04 22:56:37 --> Model Class Initialized
INFO - 2019-07-04 22:56:37 --> Model Class Initialized
INFO - 2019-07-04 22:56:37 --> Model Class Initialized
INFO - 2019-07-04 22:56:37 --> Final output sent to browser
DEBUG - 2019-07-04 22:56:37 --> Total execution time: 0.9587
INFO - 2019-07-04 16:56:38 --> Config Class Initialized
INFO - 2019-07-04 16:56:38 --> Config Class Initialized
INFO - 2019-07-04 16:56:38 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:56:38 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:56:38 --> Utf8 Class Initialized
INFO - 2019-07-04 16:56:38 --> Hooks Class Initialized
INFO - 2019-07-04 16:56:38 --> URI Class Initialized
DEBUG - 2019-07-04 16:56:39 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:56:39 --> Router Class Initialized
INFO - 2019-07-04 16:56:39 --> Utf8 Class Initialized
INFO - 2019-07-04 16:56:39 --> URI Class Initialized
INFO - 2019-07-04 16:56:39 --> Output Class Initialized
INFO - 2019-07-04 16:56:39 --> Router Class Initialized
INFO - 2019-07-04 16:56:39 --> Security Class Initialized
INFO - 2019-07-04 16:56:39 --> Output Class Initialized
DEBUG - 2019-07-04 16:56:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:56:39 --> Security Class Initialized
INFO - 2019-07-04 16:56:39 --> Input Class Initialized
INFO - 2019-07-04 16:56:39 --> Language Class Initialized
DEBUG - 2019-07-04 16:56:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:56:39 --> Language Class Initialized
INFO - 2019-07-04 16:56:39 --> Input Class Initialized
INFO - 2019-07-04 16:56:39 --> Config Class Initialized
INFO - 2019-07-04 16:56:39 --> Language Class Initialized
INFO - 2019-07-04 16:56:39 --> Loader Class Initialized
DEBUG - 2019-07-04 16:56:39 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:56:39 --> Language Class Initialized
INFO - 2019-07-04 16:56:39 --> Helper loaded: url_helper
INFO - 2019-07-04 16:56:39 --> Config Class Initialized
INFO - 2019-07-04 16:56:39 --> Loader Class Initialized
INFO - 2019-07-04 16:56:39 --> Helper loaded: inflector_helper
DEBUG - 2019-07-04 16:56:39 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:56:39 --> Helper loaded: string_helper
INFO - 2019-07-04 16:56:39 --> Helper loaded: url_helper
INFO - 2019-07-04 16:56:39 --> Helper loaded: array_helper
INFO - 2019-07-04 16:56:39 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:56:39 --> Session: Class initialized using 'files' driver.
INFO - 2019-07-04 16:56:39 --> Helper loaded: string_helper
DEBUG - 2019-07-04 16:56:39 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:56:39 --> Helper loaded: array_helper
INFO - 2019-07-04 16:56:39 --> Database Driver Class Initialized
INFO - 2019-07-04 16:56:39 --> Controller Class Initialized
INFO - 2019-07-04 22:56:39 --> Helper loaded: language_helper
INFO - 2019-07-04 22:56:39 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:56:39 --> Model Class Initialized
INFO - 2019-07-04 22:56:39 --> Model Class Initialized
INFO - 2019-07-04 22:56:39 --> Model Class Initialized
INFO - 2019-07-04 22:56:39 --> Model Class Initialized
INFO - 2019-07-04 22:56:39 --> Model Class Initialized
INFO - 2019-07-04 22:56:39 --> Final output sent to browser
DEBUG - 2019-07-04 22:56:39 --> Total execution time: 0.6999
INFO - 2019-07-04 16:56:39 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:56:39 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:56:39 --> Database Driver Class Initialized
INFO - 2019-07-04 16:56:39 --> Controller Class Initialized
INFO - 2019-07-04 22:56:39 --> Helper loaded: language_helper
INFO - 2019-07-04 22:56:39 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:56:39 --> Model Class Initialized
INFO - 2019-07-04 22:56:39 --> Model Class Initialized
INFO - 2019-07-04 22:56:39 --> Model Class Initialized
INFO - 2019-07-04 22:56:39 --> Model Class Initialized
INFO - 2019-07-04 22:56:39 --> Helper loaded: form_helper
INFO - 2019-07-04 22:56:39 --> Form Validation Class Initialized
DEBUG - 2019-07-04 22:56:39 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 22:56:39 --> Model Class Initialized
INFO - 2019-07-04 22:56:39 --> Model Class Initialized
INFO - 2019-07-04 22:56:39 --> Final output sent to browser
DEBUG - 2019-07-04 22:56:39 --> Total execution time: 0.9577
INFO - 2019-07-04 16:56:59 --> Config Class Initialized
INFO - 2019-07-04 16:56:59 --> Config Class Initialized
INFO - 2019-07-04 16:56:59 --> Hooks Class Initialized
INFO - 2019-07-04 16:56:59 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:56:59 --> UTF-8 Support Enabled
DEBUG - 2019-07-04 16:56:59 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:56:59 --> Utf8 Class Initialized
INFO - 2019-07-04 16:56:59 --> Utf8 Class Initialized
INFO - 2019-07-04 16:56:59 --> URI Class Initialized
INFO - 2019-07-04 16:56:59 --> URI Class Initialized
INFO - 2019-07-04 16:56:59 --> Router Class Initialized
INFO - 2019-07-04 16:56:59 --> Router Class Initialized
INFO - 2019-07-04 16:56:59 --> Output Class Initialized
INFO - 2019-07-04 16:56:59 --> Output Class Initialized
INFO - 2019-07-04 16:56:59 --> Security Class Initialized
INFO - 2019-07-04 16:56:59 --> Security Class Initialized
DEBUG - 2019-07-04 16:56:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-04 16:56:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:56:59 --> Input Class Initialized
INFO - 2019-07-04 16:56:59 --> Input Class Initialized
INFO - 2019-07-04 16:56:59 --> Language Class Initialized
INFO - 2019-07-04 16:56:59 --> Language Class Initialized
INFO - 2019-07-04 16:56:59 --> Language Class Initialized
INFO - 2019-07-04 16:56:59 --> Language Class Initialized
INFO - 2019-07-04 16:56:59 --> Config Class Initialized
INFO - 2019-07-04 16:56:59 --> Config Class Initialized
INFO - 2019-07-04 16:56:59 --> Loader Class Initialized
INFO - 2019-07-04 16:56:59 --> Loader Class Initialized
DEBUG - 2019-07-04 16:56:59 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-04 16:56:59 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:56:59 --> Helper loaded: url_helper
INFO - 2019-07-04 16:56:59 --> Helper loaded: url_helper
INFO - 2019-07-04 16:56:59 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:56:59 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:56:59 --> Helper loaded: string_helper
INFO - 2019-07-04 16:56:59 --> Helper loaded: string_helper
INFO - 2019-07-04 16:56:59 --> Helper loaded: array_helper
INFO - 2019-07-04 16:56:59 --> Helper loaded: array_helper
INFO - 2019-07-04 16:56:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:56:59 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:56:59 --> Database Driver Class Initialized
INFO - 2019-07-04 16:56:59 --> Controller Class Initialized
INFO - 2019-07-04 22:57:00 --> Helper loaded: language_helper
INFO - 2019-07-04 22:57:00 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:57:00 --> Model Class Initialized
INFO - 2019-07-04 22:57:00 --> Model Class Initialized
INFO - 2019-07-04 22:57:00 --> Model Class Initialized
INFO - 2019-07-04 22:57:00 --> Model Class Initialized
INFO - 2019-07-04 22:57:00 --> Model Class Initialized
INFO - 2019-07-04 22:57:00 --> Final output sent to browser
DEBUG - 2019-07-04 22:57:00 --> Total execution time: 0.6817
INFO - 2019-07-04 16:57:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:57:00 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:57:00 --> Database Driver Class Initialized
INFO - 2019-07-04 16:57:00 --> Controller Class Initialized
INFO - 2019-07-04 22:57:00 --> Helper loaded: language_helper
INFO - 2019-07-04 22:57:00 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:57:00 --> Model Class Initialized
INFO - 2019-07-04 22:57:00 --> Model Class Initialized
INFO - 2019-07-04 22:57:00 --> Model Class Initialized
INFO - 2019-07-04 22:57:00 --> Model Class Initialized
INFO - 2019-07-04 22:57:00 --> Helper loaded: form_helper
INFO - 2019-07-04 22:57:00 --> Form Validation Class Initialized
DEBUG - 2019-07-04 22:57:00 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 22:57:00 --> Model Class Initialized
INFO - 2019-07-04 22:57:00 --> Model Class Initialized
INFO - 2019-07-04 22:57:00 --> Final output sent to browser
DEBUG - 2019-07-04 22:57:00 --> Total execution time: 0.9509
INFO - 2019-07-04 16:57:02 --> Config Class Initialized
INFO - 2019-07-04 16:57:02 --> Config Class Initialized
INFO - 2019-07-04 16:57:02 --> Hooks Class Initialized
INFO - 2019-07-04 16:57:02 --> Hooks Class Initialized
DEBUG - 2019-07-04 16:57:02 --> UTF-8 Support Enabled
DEBUG - 2019-07-04 16:57:02 --> UTF-8 Support Enabled
INFO - 2019-07-04 16:57:02 --> Utf8 Class Initialized
INFO - 2019-07-04 16:57:02 --> Utf8 Class Initialized
INFO - 2019-07-04 16:57:02 --> URI Class Initialized
INFO - 2019-07-04 16:57:02 --> URI Class Initialized
INFO - 2019-07-04 16:57:02 --> Router Class Initialized
INFO - 2019-07-04 16:57:02 --> Router Class Initialized
INFO - 2019-07-04 16:57:02 --> Output Class Initialized
INFO - 2019-07-04 16:57:02 --> Output Class Initialized
INFO - 2019-07-04 16:57:02 --> Security Class Initialized
INFO - 2019-07-04 16:57:02 --> Security Class Initialized
DEBUG - 2019-07-04 16:57:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-04 16:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 16:57:02 --> Input Class Initialized
INFO - 2019-07-04 16:57:02 --> Input Class Initialized
INFO - 2019-07-04 16:57:02 --> Language Class Initialized
INFO - 2019-07-04 16:57:02 --> Language Class Initialized
INFO - 2019-07-04 16:57:02 --> Language Class Initialized
INFO - 2019-07-04 16:57:02 --> Language Class Initialized
INFO - 2019-07-04 16:57:02 --> Config Class Initialized
INFO - 2019-07-04 16:57:02 --> Loader Class Initialized
INFO - 2019-07-04 16:57:02 --> Config Class Initialized
INFO - 2019-07-04 16:57:02 --> Loader Class Initialized
DEBUG - 2019-07-04 16:57:02 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-04 16:57:02 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 16:57:02 --> Helper loaded: url_helper
INFO - 2019-07-04 16:57:02 --> Helper loaded: url_helper
INFO - 2019-07-04 16:57:02 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:57:02 --> Helper loaded: inflector_helper
INFO - 2019-07-04 16:57:02 --> Helper loaded: string_helper
INFO - 2019-07-04 16:57:02 --> Helper loaded: string_helper
INFO - 2019-07-04 16:57:03 --> Helper loaded: array_helper
INFO - 2019-07-04 16:57:03 --> Helper loaded: array_helper
INFO - 2019-07-04 16:57:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:57:03 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:57:03 --> Database Driver Class Initialized
INFO - 2019-07-04 16:57:03 --> Controller Class Initialized
INFO - 2019-07-04 22:57:03 --> Helper loaded: language_helper
INFO - 2019-07-04 22:57:03 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:57:03 --> Model Class Initialized
INFO - 2019-07-04 22:57:03 --> Model Class Initialized
INFO - 2019-07-04 22:57:03 --> Model Class Initialized
INFO - 2019-07-04 22:57:03 --> Model Class Initialized
INFO - 2019-07-04 22:57:03 --> Helper loaded: form_helper
INFO - 2019-07-04 22:57:03 --> Form Validation Class Initialized
DEBUG - 2019-07-04 22:57:03 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 22:57:03 --> Model Class Initialized
INFO - 2019-07-04 22:57:03 --> Model Class Initialized
INFO - 2019-07-04 22:57:03 --> Final output sent to browser
DEBUG - 2019-07-04 22:57:03 --> Total execution time: 0.7147
INFO - 2019-07-04 16:57:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 16:57:03 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 16:57:03 --> Database Driver Class Initialized
INFO - 2019-07-04 16:57:03 --> Controller Class Initialized
INFO - 2019-07-04 22:57:03 --> Helper loaded: language_helper
INFO - 2019-07-04 22:57:03 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 22:57:03 --> Model Class Initialized
INFO - 2019-07-04 22:57:03 --> Model Class Initialized
INFO - 2019-07-04 22:57:03 --> Model Class Initialized
INFO - 2019-07-04 22:57:03 --> Model Class Initialized
INFO - 2019-07-04 22:57:03 --> Model Class Initialized
INFO - 2019-07-04 22:57:03 --> Final output sent to browser
DEBUG - 2019-07-04 22:57:03 --> Total execution time: 0.9203
INFO - 2019-07-04 17:03:47 --> Config Class Initialized
INFO - 2019-07-04 17:03:47 --> Config Class Initialized
INFO - 2019-07-04 17:03:47 --> Hooks Class Initialized
INFO - 2019-07-04 17:03:47 --> Hooks Class Initialized
DEBUG - 2019-07-04 17:03:47 --> UTF-8 Support Enabled
DEBUG - 2019-07-04 17:03:47 --> UTF-8 Support Enabled
INFO - 2019-07-04 17:03:47 --> Utf8 Class Initialized
INFO - 2019-07-04 17:03:47 --> Utf8 Class Initialized
INFO - 2019-07-04 17:03:47 --> URI Class Initialized
INFO - 2019-07-04 17:03:47 --> URI Class Initialized
INFO - 2019-07-04 17:03:47 --> Router Class Initialized
INFO - 2019-07-04 17:03:47 --> Router Class Initialized
INFO - 2019-07-04 17:03:47 --> Output Class Initialized
INFO - 2019-07-04 17:03:47 --> Output Class Initialized
INFO - 2019-07-04 17:03:47 --> Security Class Initialized
INFO - 2019-07-04 17:03:47 --> Security Class Initialized
DEBUG - 2019-07-04 17:03:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-04 17:03:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 17:03:47 --> Input Class Initialized
INFO - 2019-07-04 17:03:47 --> Input Class Initialized
INFO - 2019-07-04 17:03:47 --> Language Class Initialized
INFO - 2019-07-04 17:03:47 --> Language Class Initialized
INFO - 2019-07-04 17:03:47 --> Language Class Initialized
INFO - 2019-07-04 17:03:47 --> Language Class Initialized
INFO - 2019-07-04 17:03:47 --> Config Class Initialized
INFO - 2019-07-04 17:03:47 --> Config Class Initialized
INFO - 2019-07-04 17:03:47 --> Loader Class Initialized
INFO - 2019-07-04 17:03:47 --> Loader Class Initialized
DEBUG - 2019-07-04 17:03:47 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-04 17:03:47 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 17:03:47 --> Helper loaded: url_helper
INFO - 2019-07-04 17:03:47 --> Helper loaded: url_helper
INFO - 2019-07-04 17:03:47 --> Helper loaded: inflector_helper
INFO - 2019-07-04 17:03:47 --> Helper loaded: inflector_helper
INFO - 2019-07-04 17:03:47 --> Helper loaded: string_helper
INFO - 2019-07-04 17:03:47 --> Helper loaded: string_helper
INFO - 2019-07-04 17:03:47 --> Helper loaded: array_helper
INFO - 2019-07-04 17:03:47 --> Helper loaded: array_helper
INFO - 2019-07-04 17:03:47 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 17:03:47 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 17:03:47 --> Database Driver Class Initialized
INFO - 2019-07-04 17:03:47 --> Controller Class Initialized
INFO - 2019-07-04 23:03:47 --> Helper loaded: language_helper
INFO - 2019-07-04 23:03:47 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 23:03:47 --> Model Class Initialized
INFO - 2019-07-04 23:03:47 --> Model Class Initialized
INFO - 2019-07-04 23:03:47 --> Model Class Initialized
INFO - 2019-07-04 23:03:47 --> Model Class Initialized
INFO - 2019-07-04 23:03:47 --> Helper loaded: form_helper
INFO - 2019-07-04 23:03:47 --> Form Validation Class Initialized
DEBUG - 2019-07-04 23:03:47 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 23:03:48 --> Model Class Initialized
INFO - 2019-07-04 23:03:48 --> Model Class Initialized
INFO - 2019-07-04 23:03:48 --> Final output sent to browser
DEBUG - 2019-07-04 23:03:48 --> Total execution time: 0.6890
INFO - 2019-07-04 17:03:48 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 17:03:48 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 17:03:48 --> Database Driver Class Initialized
INFO - 2019-07-04 17:03:48 --> Controller Class Initialized
INFO - 2019-07-04 23:03:48 --> Helper loaded: language_helper
INFO - 2019-07-04 23:03:48 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 23:03:48 --> Model Class Initialized
INFO - 2019-07-04 23:03:48 --> Model Class Initialized
INFO - 2019-07-04 23:03:48 --> Model Class Initialized
INFO - 2019-07-04 23:03:48 --> Model Class Initialized
INFO - 2019-07-04 23:03:48 --> Model Class Initialized
INFO - 2019-07-04 23:03:48 --> Final output sent to browser
DEBUG - 2019-07-04 23:03:48 --> Total execution time: 0.8839
INFO - 2019-07-04 17:04:48 --> Config Class Initialized
INFO - 2019-07-04 17:04:48 --> Config Class Initialized
INFO - 2019-07-04 17:04:48 --> Hooks Class Initialized
INFO - 2019-07-04 17:04:48 --> Hooks Class Initialized
DEBUG - 2019-07-04 17:04:48 --> UTF-8 Support Enabled
DEBUG - 2019-07-04 17:04:48 --> UTF-8 Support Enabled
INFO - 2019-07-04 17:04:48 --> Utf8 Class Initialized
INFO - 2019-07-04 17:04:48 --> Utf8 Class Initialized
INFO - 2019-07-04 17:04:48 --> URI Class Initialized
INFO - 2019-07-04 17:04:48 --> URI Class Initialized
INFO - 2019-07-04 17:04:48 --> Router Class Initialized
INFO - 2019-07-04 17:04:48 --> Router Class Initialized
INFO - 2019-07-04 17:04:48 --> Output Class Initialized
INFO - 2019-07-04 17:04:48 --> Output Class Initialized
INFO - 2019-07-04 17:04:48 --> Security Class Initialized
INFO - 2019-07-04 17:04:48 --> Security Class Initialized
DEBUG - 2019-07-04 17:04:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-04 17:04:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 17:04:48 --> Input Class Initialized
INFO - 2019-07-04 17:04:48 --> Input Class Initialized
INFO - 2019-07-04 17:04:48 --> Language Class Initialized
INFO - 2019-07-04 17:04:48 --> Language Class Initialized
INFO - 2019-07-04 17:04:48 --> Language Class Initialized
INFO - 2019-07-04 17:04:48 --> Language Class Initialized
INFO - 2019-07-04 17:04:48 --> Config Class Initialized
INFO - 2019-07-04 17:04:48 --> Loader Class Initialized
INFO - 2019-07-04 17:04:48 --> Config Class Initialized
INFO - 2019-07-04 17:04:48 --> Loader Class Initialized
DEBUG - 2019-07-04 17:04:48 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-04 17:04:48 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 17:04:48 --> Helper loaded: url_helper
INFO - 2019-07-04 17:04:48 --> Helper loaded: url_helper
INFO - 2019-07-04 17:04:48 --> Helper loaded: inflector_helper
INFO - 2019-07-04 17:04:48 --> Helper loaded: inflector_helper
INFO - 2019-07-04 17:04:48 --> Helper loaded: string_helper
INFO - 2019-07-04 17:04:48 --> Helper loaded: string_helper
INFO - 2019-07-04 17:04:48 --> Helper loaded: array_helper
INFO - 2019-07-04 17:04:48 --> Helper loaded: array_helper
INFO - 2019-07-04 17:04:48 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 17:04:48 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 17:04:48 --> Database Driver Class Initialized
INFO - 2019-07-04 17:04:48 --> Controller Class Initialized
INFO - 2019-07-04 23:04:48 --> Helper loaded: language_helper
INFO - 2019-07-04 23:04:48 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 23:04:48 --> Model Class Initialized
INFO - 2019-07-04 23:04:48 --> Model Class Initialized
INFO - 2019-07-04 23:04:48 --> Model Class Initialized
INFO - 2019-07-04 23:04:48 --> Model Class Initialized
INFO - 2019-07-04 23:04:48 --> Model Class Initialized
INFO - 2019-07-04 23:04:48 --> Final output sent to browser
DEBUG - 2019-07-04 23:04:48 --> Total execution time: 0.6612
INFO - 2019-07-04 17:04:48 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 17:04:48 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 17:04:48 --> Database Driver Class Initialized
INFO - 2019-07-04 17:04:48 --> Controller Class Initialized
INFO - 2019-07-04 23:04:48 --> Helper loaded: language_helper
INFO - 2019-07-04 23:04:48 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 23:04:48 --> Model Class Initialized
INFO - 2019-07-04 23:04:48 --> Model Class Initialized
INFO - 2019-07-04 23:04:48 --> Model Class Initialized
INFO - 2019-07-04 23:04:48 --> Model Class Initialized
INFO - 2019-07-04 23:04:48 --> Helper loaded: form_helper
INFO - 2019-07-04 23:04:48 --> Form Validation Class Initialized
DEBUG - 2019-07-04 23:04:48 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 23:04:48 --> Model Class Initialized
INFO - 2019-07-04 23:04:48 --> Model Class Initialized
INFO - 2019-07-04 23:04:48 --> Final output sent to browser
DEBUG - 2019-07-04 23:04:48 --> Total execution time: 0.9096
INFO - 2019-07-04 17:09:10 --> Config Class Initialized
INFO - 2019-07-04 17:09:10 --> Config Class Initialized
INFO - 2019-07-04 17:09:10 --> Hooks Class Initialized
INFO - 2019-07-04 17:09:10 --> Hooks Class Initialized
DEBUG - 2019-07-04 17:09:10 --> UTF-8 Support Enabled
DEBUG - 2019-07-04 17:09:10 --> UTF-8 Support Enabled
INFO - 2019-07-04 17:09:10 --> Utf8 Class Initialized
INFO - 2019-07-04 17:09:10 --> Utf8 Class Initialized
INFO - 2019-07-04 17:09:10 --> URI Class Initialized
INFO - 2019-07-04 17:09:10 --> URI Class Initialized
INFO - 2019-07-04 17:09:10 --> Router Class Initialized
INFO - 2019-07-04 17:09:10 --> Router Class Initialized
INFO - 2019-07-04 17:09:10 --> Output Class Initialized
INFO - 2019-07-04 17:09:10 --> Output Class Initialized
INFO - 2019-07-04 17:09:10 --> Security Class Initialized
INFO - 2019-07-04 17:09:10 --> Security Class Initialized
DEBUG - 2019-07-04 17:09:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-04 17:09:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 17:09:10 --> Input Class Initialized
INFO - 2019-07-04 17:09:10 --> Input Class Initialized
INFO - 2019-07-04 17:09:10 --> Language Class Initialized
INFO - 2019-07-04 17:09:10 --> Language Class Initialized
INFO - 2019-07-04 17:09:10 --> Language Class Initialized
INFO - 2019-07-04 17:09:10 --> Language Class Initialized
INFO - 2019-07-04 17:09:10 --> Config Class Initialized
INFO - 2019-07-04 17:09:10 --> Config Class Initialized
INFO - 2019-07-04 17:09:10 --> Loader Class Initialized
INFO - 2019-07-04 17:09:10 --> Loader Class Initialized
DEBUG - 2019-07-04 17:09:10 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-04 17:09:10 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 17:09:10 --> Helper loaded: url_helper
INFO - 2019-07-04 17:09:10 --> Helper loaded: url_helper
INFO - 2019-07-04 17:09:10 --> Helper loaded: inflector_helper
INFO - 2019-07-04 17:09:10 --> Helper loaded: inflector_helper
INFO - 2019-07-04 17:09:10 --> Helper loaded: string_helper
INFO - 2019-07-04 17:09:10 --> Helper loaded: string_helper
INFO - 2019-07-04 17:09:10 --> Helper loaded: array_helper
INFO - 2019-07-04 17:09:10 --> Helper loaded: array_helper
INFO - 2019-07-04 17:09:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 17:09:10 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 17:09:10 --> Database Driver Class Initialized
INFO - 2019-07-04 17:09:10 --> Controller Class Initialized
INFO - 2019-07-04 23:09:10 --> Helper loaded: language_helper
INFO - 2019-07-04 23:09:10 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 23:09:10 --> Model Class Initialized
INFO - 2019-07-04 23:09:10 --> Model Class Initialized
INFO - 2019-07-04 23:09:10 --> Model Class Initialized
INFO - 2019-07-04 23:09:10 --> Model Class Initialized
INFO - 2019-07-04 23:09:10 --> Model Class Initialized
INFO - 2019-07-04 23:09:10 --> Final output sent to browser
DEBUG - 2019-07-04 23:09:10 --> Total execution time: 0.6942
INFO - 2019-07-04 17:09:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 17:09:10 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 17:09:10 --> Database Driver Class Initialized
INFO - 2019-07-04 17:09:10 --> Controller Class Initialized
INFO - 2019-07-04 23:09:11 --> Helper loaded: language_helper
INFO - 2019-07-04 23:09:11 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 23:09:11 --> Model Class Initialized
INFO - 2019-07-04 23:09:11 --> Model Class Initialized
INFO - 2019-07-04 23:09:11 --> Model Class Initialized
INFO - 2019-07-04 23:09:11 --> Model Class Initialized
INFO - 2019-07-04 23:09:11 --> Helper loaded: form_helper
INFO - 2019-07-04 23:09:11 --> Form Validation Class Initialized
DEBUG - 2019-07-04 23:09:11 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 23:09:11 --> Model Class Initialized
INFO - 2019-07-04 23:09:11 --> Model Class Initialized
INFO - 2019-07-04 23:09:11 --> Final output sent to browser
DEBUG - 2019-07-04 23:09:11 --> Total execution time: 0.9554
INFO - 2019-07-04 17:09:13 --> Config Class Initialized
INFO - 2019-07-04 17:09:13 --> Config Class Initialized
INFO - 2019-07-04 17:09:13 --> Hooks Class Initialized
INFO - 2019-07-04 17:09:13 --> Hooks Class Initialized
DEBUG - 2019-07-04 17:09:13 --> UTF-8 Support Enabled
DEBUG - 2019-07-04 17:09:13 --> UTF-8 Support Enabled
INFO - 2019-07-04 17:09:13 --> Utf8 Class Initialized
INFO - 2019-07-04 17:09:13 --> Utf8 Class Initialized
INFO - 2019-07-04 17:09:13 --> URI Class Initialized
INFO - 2019-07-04 17:09:13 --> URI Class Initialized
INFO - 2019-07-04 17:09:13 --> Router Class Initialized
INFO - 2019-07-04 17:09:13 --> Router Class Initialized
INFO - 2019-07-04 17:09:13 --> Output Class Initialized
INFO - 2019-07-04 17:09:13 --> Output Class Initialized
INFO - 2019-07-04 17:09:13 --> Security Class Initialized
INFO - 2019-07-04 17:09:13 --> Security Class Initialized
DEBUG - 2019-07-04 17:09:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 17:09:13 --> Input Class Initialized
DEBUG - 2019-07-04 17:09:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 17:09:13 --> Input Class Initialized
INFO - 2019-07-04 17:09:13 --> Language Class Initialized
INFO - 2019-07-04 17:09:13 --> Language Class Initialized
INFO - 2019-07-04 17:09:13 --> Language Class Initialized
INFO - 2019-07-04 17:09:13 --> Language Class Initialized
INFO - 2019-07-04 17:09:13 --> Config Class Initialized
INFO - 2019-07-04 17:09:13 --> Config Class Initialized
INFO - 2019-07-04 17:09:13 --> Loader Class Initialized
INFO - 2019-07-04 17:09:13 --> Loader Class Initialized
DEBUG - 2019-07-04 17:09:13 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-04 17:09:13 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 17:09:13 --> Helper loaded: url_helper
INFO - 2019-07-04 17:09:13 --> Helper loaded: url_helper
INFO - 2019-07-04 17:09:13 --> Helper loaded: inflector_helper
INFO - 2019-07-04 17:09:13 --> Helper loaded: inflector_helper
INFO - 2019-07-04 17:09:13 --> Helper loaded: string_helper
INFO - 2019-07-04 17:09:13 --> Helper loaded: string_helper
INFO - 2019-07-04 17:09:13 --> Helper loaded: array_helper
INFO - 2019-07-04 17:09:13 --> Helper loaded: array_helper
INFO - 2019-07-04 17:09:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 17:09:13 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 17:09:13 --> Database Driver Class Initialized
INFO - 2019-07-04 17:09:13 --> Controller Class Initialized
INFO - 2019-07-04 23:09:13 --> Helper loaded: language_helper
INFO - 2019-07-04 23:09:13 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 23:09:13 --> Model Class Initialized
INFO - 2019-07-04 23:09:13 --> Model Class Initialized
INFO - 2019-07-04 23:09:13 --> Model Class Initialized
INFO - 2019-07-04 23:09:13 --> Model Class Initialized
INFO - 2019-07-04 23:09:13 --> Model Class Initialized
INFO - 2019-07-04 23:09:13 --> Final output sent to browser
DEBUG - 2019-07-04 23:09:13 --> Total execution time: 0.6602
INFO - 2019-07-04 17:09:13 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 17:09:13 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 17:09:13 --> Database Driver Class Initialized
INFO - 2019-07-04 17:09:13 --> Controller Class Initialized
INFO - 2019-07-04 23:09:14 --> Helper loaded: language_helper
INFO - 2019-07-04 23:09:14 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 23:09:14 --> Model Class Initialized
INFO - 2019-07-04 23:09:14 --> Model Class Initialized
INFO - 2019-07-04 23:09:14 --> Model Class Initialized
INFO - 2019-07-04 23:09:14 --> Model Class Initialized
INFO - 2019-07-04 23:09:14 --> Helper loaded: form_helper
INFO - 2019-07-04 23:09:14 --> Form Validation Class Initialized
DEBUG - 2019-07-04 23:09:14 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 23:09:14 --> Model Class Initialized
INFO - 2019-07-04 23:09:14 --> Model Class Initialized
INFO - 2019-07-04 23:09:14 --> Final output sent to browser
DEBUG - 2019-07-04 23:09:14 --> Total execution time: 0.9347
INFO - 2019-07-04 17:13:14 --> Config Class Initialized
INFO - 2019-07-04 17:13:14 --> Config Class Initialized
INFO - 2019-07-04 17:13:14 --> Hooks Class Initialized
INFO - 2019-07-04 17:13:14 --> Hooks Class Initialized
DEBUG - 2019-07-04 17:13:14 --> UTF-8 Support Enabled
DEBUG - 2019-07-04 17:13:14 --> UTF-8 Support Enabled
INFO - 2019-07-04 17:13:14 --> Utf8 Class Initialized
INFO - 2019-07-04 17:13:14 --> Utf8 Class Initialized
INFO - 2019-07-04 17:13:14 --> URI Class Initialized
INFO - 2019-07-04 17:13:14 --> URI Class Initialized
INFO - 2019-07-04 17:13:14 --> Router Class Initialized
INFO - 2019-07-04 17:13:14 --> Router Class Initialized
INFO - 2019-07-04 17:13:14 --> Output Class Initialized
INFO - 2019-07-04 17:13:14 --> Output Class Initialized
INFO - 2019-07-04 17:13:14 --> Security Class Initialized
INFO - 2019-07-04 17:13:14 --> Security Class Initialized
DEBUG - 2019-07-04 17:13:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-04 17:13:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 17:13:14 --> Input Class Initialized
INFO - 2019-07-04 17:13:14 --> Input Class Initialized
INFO - 2019-07-04 17:13:14 --> Language Class Initialized
INFO - 2019-07-04 17:13:14 --> Language Class Initialized
INFO - 2019-07-04 17:13:14 --> Language Class Initialized
INFO - 2019-07-04 17:13:14 --> Config Class Initialized
INFO - 2019-07-04 17:13:14 --> Language Class Initialized
INFO - 2019-07-04 17:13:14 --> Config Class Initialized
INFO - 2019-07-04 17:13:14 --> Loader Class Initialized
INFO - 2019-07-04 17:13:14 --> Loader Class Initialized
DEBUG - 2019-07-04 17:13:14 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-04 17:13:15 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 17:13:15 --> Helper loaded: url_helper
INFO - 2019-07-04 17:13:15 --> Helper loaded: url_helper
INFO - 2019-07-04 17:13:15 --> Helper loaded: inflector_helper
INFO - 2019-07-04 17:13:15 --> Helper loaded: inflector_helper
INFO - 2019-07-04 17:13:15 --> Helper loaded: string_helper
INFO - 2019-07-04 17:13:15 --> Helper loaded: string_helper
INFO - 2019-07-04 17:13:15 --> Helper loaded: array_helper
INFO - 2019-07-04 17:13:15 --> Helper loaded: array_helper
INFO - 2019-07-04 17:13:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 17:13:15 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 17:13:15 --> Database Driver Class Initialized
INFO - 2019-07-04 17:13:15 --> Controller Class Initialized
INFO - 2019-07-04 23:13:15 --> Helper loaded: language_helper
INFO - 2019-07-04 23:13:15 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 23:13:15 --> Model Class Initialized
INFO - 2019-07-04 23:13:15 --> Model Class Initialized
INFO - 2019-07-04 23:13:15 --> Model Class Initialized
INFO - 2019-07-04 23:13:15 --> Model Class Initialized
INFO - 2019-07-04 23:13:15 --> Helper loaded: form_helper
INFO - 2019-07-04 23:13:15 --> Form Validation Class Initialized
DEBUG - 2019-07-04 23:13:15 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 23:13:15 --> Model Class Initialized
INFO - 2019-07-04 23:13:15 --> Model Class Initialized
INFO - 2019-07-04 23:13:15 --> Final output sent to browser
DEBUG - 2019-07-04 23:13:15 --> Total execution time: 0.7583
INFO - 2019-07-04 17:13:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 17:13:15 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 17:13:15 --> Database Driver Class Initialized
INFO - 2019-07-04 17:13:15 --> Controller Class Initialized
INFO - 2019-07-04 23:13:15 --> Helper loaded: language_helper
INFO - 2019-07-04 23:13:15 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 23:13:15 --> Model Class Initialized
INFO - 2019-07-04 23:13:15 --> Model Class Initialized
INFO - 2019-07-04 23:13:15 --> Model Class Initialized
INFO - 2019-07-04 23:13:15 --> Model Class Initialized
INFO - 2019-07-04 23:13:15 --> Model Class Initialized
INFO - 2019-07-04 23:13:15 --> Final output sent to browser
DEBUG - 2019-07-04 23:13:15 --> Total execution time: 0.9603
INFO - 2019-07-04 17:13:38 --> Config Class Initialized
INFO - 2019-07-04 17:13:38 --> Config Class Initialized
INFO - 2019-07-04 17:13:38 --> Hooks Class Initialized
INFO - 2019-07-04 17:13:38 --> Hooks Class Initialized
DEBUG - 2019-07-04 17:13:38 --> UTF-8 Support Enabled
DEBUG - 2019-07-04 17:13:38 --> UTF-8 Support Enabled
INFO - 2019-07-04 17:13:38 --> Utf8 Class Initialized
INFO - 2019-07-04 17:13:38 --> Utf8 Class Initialized
INFO - 2019-07-04 17:13:38 --> URI Class Initialized
INFO - 2019-07-04 17:13:38 --> URI Class Initialized
INFO - 2019-07-04 17:13:38 --> Router Class Initialized
INFO - 2019-07-04 17:13:38 --> Router Class Initialized
INFO - 2019-07-04 17:13:38 --> Output Class Initialized
INFO - 2019-07-04 17:13:38 --> Output Class Initialized
INFO - 2019-07-04 17:13:38 --> Security Class Initialized
INFO - 2019-07-04 17:13:38 --> Security Class Initialized
DEBUG - 2019-07-04 17:13:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-04 17:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 17:13:38 --> Input Class Initialized
INFO - 2019-07-04 17:13:38 --> Input Class Initialized
INFO - 2019-07-04 17:13:38 --> Language Class Initialized
INFO - 2019-07-04 17:13:38 --> Language Class Initialized
INFO - 2019-07-04 17:13:38 --> Language Class Initialized
INFO - 2019-07-04 17:13:38 --> Language Class Initialized
INFO - 2019-07-04 17:13:38 --> Config Class Initialized
INFO - 2019-07-04 17:13:38 --> Loader Class Initialized
INFO - 2019-07-04 17:13:38 --> Config Class Initialized
INFO - 2019-07-04 17:13:38 --> Loader Class Initialized
DEBUG - 2019-07-04 17:13:38 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-04 17:13:38 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 17:13:38 --> Helper loaded: url_helper
INFO - 2019-07-04 17:13:38 --> Helper loaded: url_helper
INFO - 2019-07-04 17:13:38 --> Helper loaded: inflector_helper
INFO - 2019-07-04 17:13:38 --> Helper loaded: inflector_helper
INFO - 2019-07-04 17:13:38 --> Helper loaded: string_helper
INFO - 2019-07-04 17:13:38 --> Helper loaded: string_helper
INFO - 2019-07-04 17:13:38 --> Helper loaded: array_helper
INFO - 2019-07-04 17:13:38 --> Helper loaded: array_helper
INFO - 2019-07-04 17:13:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 17:13:38 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 17:13:38 --> Database Driver Class Initialized
INFO - 2019-07-04 17:13:38 --> Controller Class Initialized
INFO - 2019-07-04 23:13:38 --> Helper loaded: language_helper
INFO - 2019-07-04 23:13:38 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 23:13:38 --> Model Class Initialized
INFO - 2019-07-04 23:13:38 --> Model Class Initialized
INFO - 2019-07-04 23:13:38 --> Model Class Initialized
INFO - 2019-07-04 23:13:38 --> Model Class Initialized
INFO - 2019-07-04 23:13:38 --> Helper loaded: form_helper
INFO - 2019-07-04 23:13:38 --> Form Validation Class Initialized
DEBUG - 2019-07-04 23:13:38 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 23:13:38 --> Model Class Initialized
INFO - 2019-07-04 23:13:38 --> Model Class Initialized
INFO - 2019-07-04 23:13:38 --> Final output sent to browser
DEBUG - 2019-07-04 23:13:38 --> Total execution time: 0.7444
INFO - 2019-07-04 17:13:39 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 17:13:39 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 17:13:39 --> Database Driver Class Initialized
INFO - 2019-07-04 17:13:39 --> Controller Class Initialized
INFO - 2019-07-04 23:13:39 --> Helper loaded: language_helper
INFO - 2019-07-04 23:13:39 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 23:13:39 --> Model Class Initialized
INFO - 2019-07-04 23:13:39 --> Model Class Initialized
INFO - 2019-07-04 23:13:39 --> Model Class Initialized
INFO - 2019-07-04 23:13:39 --> Model Class Initialized
INFO - 2019-07-04 23:13:39 --> Model Class Initialized
INFO - 2019-07-04 23:13:39 --> Final output sent to browser
DEBUG - 2019-07-04 23:13:39 --> Total execution time: 0.9653
INFO - 2019-07-04 17:14:49 --> Config Class Initialized
INFO - 2019-07-04 17:14:49 --> Hooks Class Initialized
INFO - 2019-07-04 17:14:49 --> Config Class Initialized
INFO - 2019-07-04 17:14:50 --> Hooks Class Initialized
DEBUG - 2019-07-04 17:14:50 --> UTF-8 Support Enabled
DEBUG - 2019-07-04 17:14:50 --> UTF-8 Support Enabled
INFO - 2019-07-04 17:14:50 --> Utf8 Class Initialized
INFO - 2019-07-04 17:14:50 --> Utf8 Class Initialized
INFO - 2019-07-04 17:14:50 --> URI Class Initialized
INFO - 2019-07-04 17:14:50 --> URI Class Initialized
INFO - 2019-07-04 17:14:50 --> Router Class Initialized
INFO - 2019-07-04 17:14:50 --> Router Class Initialized
INFO - 2019-07-04 17:14:50 --> Output Class Initialized
INFO - 2019-07-04 17:14:50 --> Output Class Initialized
INFO - 2019-07-04 17:14:50 --> Security Class Initialized
INFO - 2019-07-04 17:14:50 --> Security Class Initialized
DEBUG - 2019-07-04 17:14:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-04 17:14:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 17:14:50 --> Input Class Initialized
INFO - 2019-07-04 17:14:50 --> Input Class Initialized
INFO - 2019-07-04 17:14:50 --> Language Class Initialized
INFO - 2019-07-04 17:14:50 --> Language Class Initialized
INFO - 2019-07-04 17:14:50 --> Language Class Initialized
INFO - 2019-07-04 17:14:50 --> Language Class Initialized
INFO - 2019-07-04 17:14:50 --> Config Class Initialized
INFO - 2019-07-04 17:14:50 --> Loader Class Initialized
INFO - 2019-07-04 17:14:50 --> Config Class Initialized
INFO - 2019-07-04 17:14:50 --> Loader Class Initialized
DEBUG - 2019-07-04 17:14:50 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-04 17:14:50 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 17:14:50 --> Helper loaded: url_helper
INFO - 2019-07-04 17:14:50 --> Helper loaded: url_helper
INFO - 2019-07-04 17:14:50 --> Helper loaded: inflector_helper
INFO - 2019-07-04 17:14:50 --> Helper loaded: inflector_helper
INFO - 2019-07-04 17:14:50 --> Helper loaded: string_helper
INFO - 2019-07-04 17:14:50 --> Helper loaded: string_helper
INFO - 2019-07-04 17:14:50 --> Helper loaded: array_helper
INFO - 2019-07-04 17:14:50 --> Helper loaded: array_helper
INFO - 2019-07-04 17:14:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 17:14:50 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 17:14:50 --> Database Driver Class Initialized
INFO - 2019-07-04 17:14:50 --> Controller Class Initialized
INFO - 2019-07-04 23:14:50 --> Helper loaded: language_helper
INFO - 2019-07-04 23:14:50 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 23:14:50 --> Model Class Initialized
INFO - 2019-07-04 23:14:50 --> Model Class Initialized
INFO - 2019-07-04 23:14:50 --> Model Class Initialized
INFO - 2019-07-04 23:14:50 --> Model Class Initialized
INFO - 2019-07-04 23:14:50 --> Helper loaded: form_helper
INFO - 2019-07-04 23:14:50 --> Form Validation Class Initialized
DEBUG - 2019-07-04 23:14:50 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 23:14:50 --> Model Class Initialized
INFO - 2019-07-04 23:14:50 --> Model Class Initialized
INFO - 2019-07-04 23:14:50 --> Final output sent to browser
DEBUG - 2019-07-04 23:14:50 --> Total execution time: 0.7151
INFO - 2019-07-04 17:14:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 17:14:50 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 17:14:50 --> Database Driver Class Initialized
INFO - 2019-07-04 17:14:50 --> Controller Class Initialized
INFO - 2019-07-04 23:14:50 --> Helper loaded: language_helper
INFO - 2019-07-04 23:14:50 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 23:14:50 --> Model Class Initialized
INFO - 2019-07-04 23:14:50 --> Model Class Initialized
INFO - 2019-07-04 23:14:50 --> Model Class Initialized
INFO - 2019-07-04 23:14:50 --> Model Class Initialized
INFO - 2019-07-04 23:14:50 --> Model Class Initialized
INFO - 2019-07-04 23:14:50 --> Final output sent to browser
DEBUG - 2019-07-04 23:14:50 --> Total execution time: 0.9261
INFO - 2019-07-04 17:15:48 --> Config Class Initialized
INFO - 2019-07-04 17:15:48 --> Config Class Initialized
INFO - 2019-07-04 17:15:48 --> Hooks Class Initialized
INFO - 2019-07-04 17:15:48 --> Hooks Class Initialized
DEBUG - 2019-07-04 17:15:48 --> UTF-8 Support Enabled
INFO - 2019-07-04 17:15:48 --> Utf8 Class Initialized
DEBUG - 2019-07-04 17:15:48 --> UTF-8 Support Enabled
INFO - 2019-07-04 17:15:48 --> URI Class Initialized
INFO - 2019-07-04 17:15:48 --> Utf8 Class Initialized
INFO - 2019-07-04 17:15:48 --> URI Class Initialized
INFO - 2019-07-04 17:15:48 --> Router Class Initialized
INFO - 2019-07-04 17:15:48 --> Router Class Initialized
INFO - 2019-07-04 17:15:48 --> Output Class Initialized
INFO - 2019-07-04 17:15:48 --> Output Class Initialized
INFO - 2019-07-04 17:15:48 --> Security Class Initialized
INFO - 2019-07-04 17:15:48 --> Security Class Initialized
DEBUG - 2019-07-04 17:15:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-04 17:15:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 17:15:48 --> Input Class Initialized
INFO - 2019-07-04 17:15:48 --> Input Class Initialized
INFO - 2019-07-04 17:15:48 --> Language Class Initialized
INFO - 2019-07-04 17:15:48 --> Language Class Initialized
INFO - 2019-07-04 17:15:48 --> Language Class Initialized
INFO - 2019-07-04 17:15:48 --> Language Class Initialized
INFO - 2019-07-04 17:15:48 --> Config Class Initialized
INFO - 2019-07-04 17:15:48 --> Config Class Initialized
INFO - 2019-07-04 17:15:48 --> Loader Class Initialized
INFO - 2019-07-04 17:15:48 --> Loader Class Initialized
DEBUG - 2019-07-04 17:15:48 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-04 17:15:48 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 17:15:48 --> Helper loaded: url_helper
INFO - 2019-07-04 17:15:48 --> Helper loaded: url_helper
INFO - 2019-07-04 17:15:48 --> Helper loaded: inflector_helper
INFO - 2019-07-04 17:15:48 --> Helper loaded: inflector_helper
INFO - 2019-07-04 17:15:48 --> Helper loaded: string_helper
INFO - 2019-07-04 17:15:48 --> Helper loaded: string_helper
INFO - 2019-07-04 17:15:48 --> Helper loaded: array_helper
INFO - 2019-07-04 17:15:48 --> Helper loaded: array_helper
INFO - 2019-07-04 17:15:48 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 17:15:48 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 17:15:48 --> Database Driver Class Initialized
INFO - 2019-07-04 17:15:48 --> Controller Class Initialized
INFO - 2019-07-04 23:15:48 --> Helper loaded: language_helper
INFO - 2019-07-04 23:15:48 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 23:15:48 --> Model Class Initialized
INFO - 2019-07-04 23:15:48 --> Model Class Initialized
INFO - 2019-07-04 23:15:48 --> Model Class Initialized
INFO - 2019-07-04 23:15:48 --> Model Class Initialized
INFO - 2019-07-04 23:15:48 --> Model Class Initialized
INFO - 2019-07-04 23:15:48 --> Final output sent to browser
DEBUG - 2019-07-04 23:15:48 --> Total execution time: 0.7528
INFO - 2019-07-04 17:15:48 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 17:15:48 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 17:15:48 --> Database Driver Class Initialized
INFO - 2019-07-04 17:15:49 --> Controller Class Initialized
INFO - 2019-07-04 23:15:49 --> Helper loaded: language_helper
INFO - 2019-07-04 23:15:49 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 23:15:49 --> Model Class Initialized
INFO - 2019-07-04 23:15:49 --> Model Class Initialized
INFO - 2019-07-04 23:15:49 --> Model Class Initialized
INFO - 2019-07-04 23:15:49 --> Model Class Initialized
INFO - 2019-07-04 23:15:49 --> Helper loaded: form_helper
INFO - 2019-07-04 23:15:49 --> Form Validation Class Initialized
DEBUG - 2019-07-04 23:15:49 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 23:15:49 --> Model Class Initialized
INFO - 2019-07-04 23:15:49 --> Model Class Initialized
INFO - 2019-07-04 23:15:49 --> Final output sent to browser
DEBUG - 2019-07-04 23:15:49 --> Total execution time: 1.0237
INFO - 2019-07-04 17:18:09 --> Config Class Initialized
INFO - 2019-07-04 17:18:09 --> Hooks Class Initialized
DEBUG - 2019-07-04 17:18:09 --> UTF-8 Support Enabled
INFO - 2019-07-04 17:18:09 --> Utf8 Class Initialized
INFO - 2019-07-04 17:18:09 --> URI Class Initialized
INFO - 2019-07-04 17:18:09 --> Router Class Initialized
INFO - 2019-07-04 17:18:09 --> Output Class Initialized
INFO - 2019-07-04 17:18:09 --> Security Class Initialized
DEBUG - 2019-07-04 17:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 17:18:09 --> Input Class Initialized
INFO - 2019-07-04 17:18:09 --> Language Class Initialized
INFO - 2019-07-04 17:18:09 --> Language Class Initialized
INFO - 2019-07-04 17:18:09 --> Config Class Initialized
INFO - 2019-07-04 17:18:09 --> Loader Class Initialized
DEBUG - 2019-07-04 17:18:09 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 17:18:09 --> Helper loaded: url_helper
INFO - 2019-07-04 17:18:09 --> Helper loaded: inflector_helper
INFO - 2019-07-04 17:18:09 --> Helper loaded: string_helper
INFO - 2019-07-04 17:18:09 --> Helper loaded: array_helper
INFO - 2019-07-04 17:18:09 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 17:18:09 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 17:18:09 --> Database Driver Class Initialized
INFO - 2019-07-04 17:18:09 --> Controller Class Initialized
INFO - 2019-07-04 23:18:09 --> Helper loaded: language_helper
INFO - 2019-07-04 23:18:09 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 23:18:09 --> Model Class Initialized
INFO - 2019-07-04 23:18:09 --> Model Class Initialized
INFO - 2019-07-04 23:18:09 --> Model Class Initialized
INFO - 2019-07-04 23:18:09 --> Model Class Initialized
INFO - 2019-07-04 23:18:09 --> Helper loaded: form_helper
INFO - 2019-07-04 23:18:09 --> Form Validation Class Initialized
DEBUG - 2019-07-04 23:18:09 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 23:18:09 --> Model Class Initialized
INFO - 2019-07-04 23:18:09 --> Model Class Initialized
INFO - 2019-07-04 23:18:09 --> Final output sent to browser
DEBUG - 2019-07-04 23:18:09 --> Total execution time: 0.5500
INFO - 2019-07-04 17:18:11 --> Config Class Initialized
INFO - 2019-07-04 17:18:11 --> Config Class Initialized
INFO - 2019-07-04 17:18:11 --> Hooks Class Initialized
INFO - 2019-07-04 17:18:11 --> Hooks Class Initialized
DEBUG - 2019-07-04 17:18:11 --> UTF-8 Support Enabled
DEBUG - 2019-07-04 17:18:11 --> UTF-8 Support Enabled
INFO - 2019-07-04 17:18:11 --> Utf8 Class Initialized
INFO - 2019-07-04 17:18:11 --> Utf8 Class Initialized
INFO - 2019-07-04 17:18:11 --> URI Class Initialized
INFO - 2019-07-04 17:18:11 --> URI Class Initialized
INFO - 2019-07-04 17:18:11 --> Router Class Initialized
INFO - 2019-07-04 17:18:11 --> Router Class Initialized
INFO - 2019-07-04 17:18:11 --> Output Class Initialized
INFO - 2019-07-04 17:18:11 --> Output Class Initialized
INFO - 2019-07-04 17:18:11 --> Security Class Initialized
INFO - 2019-07-04 17:18:11 --> Security Class Initialized
DEBUG - 2019-07-04 17:18:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-04 17:18:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 17:18:11 --> Input Class Initialized
INFO - 2019-07-04 17:18:11 --> Input Class Initialized
INFO - 2019-07-04 17:18:11 --> Language Class Initialized
INFO - 2019-07-04 17:18:11 --> Language Class Initialized
INFO - 2019-07-04 17:18:11 --> Language Class Initialized
INFO - 2019-07-04 17:18:11 --> Language Class Initialized
INFO - 2019-07-04 17:18:11 --> Config Class Initialized
INFO - 2019-07-04 17:18:11 --> Config Class Initialized
INFO - 2019-07-04 17:18:11 --> Loader Class Initialized
INFO - 2019-07-04 17:18:11 --> Loader Class Initialized
DEBUG - 2019-07-04 17:18:11 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-04 17:18:11 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 17:18:11 --> Helper loaded: url_helper
INFO - 2019-07-04 17:18:11 --> Helper loaded: url_helper
INFO - 2019-07-04 17:18:11 --> Helper loaded: inflector_helper
INFO - 2019-07-04 17:18:11 --> Helper loaded: inflector_helper
INFO - 2019-07-04 17:18:11 --> Helper loaded: string_helper
INFO - 2019-07-04 17:18:11 --> Helper loaded: string_helper
INFO - 2019-07-04 17:18:11 --> Helper loaded: array_helper
INFO - 2019-07-04 17:18:11 --> Helper loaded: array_helper
INFO - 2019-07-04 17:18:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 17:18:11 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 17:18:11 --> Database Driver Class Initialized
INFO - 2019-07-04 17:18:11 --> Controller Class Initialized
INFO - 2019-07-04 23:18:11 --> Helper loaded: language_helper
INFO - 2019-07-04 23:18:11 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 23:18:11 --> Model Class Initialized
INFO - 2019-07-04 23:18:11 --> Model Class Initialized
INFO - 2019-07-04 23:18:11 --> Model Class Initialized
INFO - 2019-07-04 23:18:11 --> Model Class Initialized
INFO - 2019-07-04 23:18:11 --> Model Class Initialized
INFO - 2019-07-04 23:18:11 --> Final output sent to browser
DEBUG - 2019-07-04 23:18:11 --> Total execution time: 0.7334
INFO - 2019-07-04 17:18:11 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 17:18:11 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 17:18:11 --> Database Driver Class Initialized
INFO - 2019-07-04 17:18:11 --> Controller Class Initialized
INFO - 2019-07-04 23:18:11 --> Helper loaded: language_helper
INFO - 2019-07-04 23:18:11 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 23:18:11 --> Model Class Initialized
INFO - 2019-07-04 23:18:11 --> Model Class Initialized
INFO - 2019-07-04 23:18:11 --> Model Class Initialized
INFO - 2019-07-04 23:18:11 --> Model Class Initialized
INFO - 2019-07-04 23:18:11 --> Helper loaded: form_helper
INFO - 2019-07-04 23:18:11 --> Form Validation Class Initialized
DEBUG - 2019-07-04 23:18:11 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 23:18:11 --> Model Class Initialized
INFO - 2019-07-04 23:18:12 --> Model Class Initialized
INFO - 2019-07-04 23:18:12 --> Final output sent to browser
DEBUG - 2019-07-04 23:18:12 --> Total execution time: 1.0219
INFO - 2019-07-04 17:19:17 --> Config Class Initialized
INFO - 2019-07-04 17:19:17 --> Config Class Initialized
INFO - 2019-07-04 17:19:17 --> Hooks Class Initialized
INFO - 2019-07-04 17:19:17 --> Hooks Class Initialized
DEBUG - 2019-07-04 17:19:17 --> UTF-8 Support Enabled
DEBUG - 2019-07-04 17:19:17 --> UTF-8 Support Enabled
INFO - 2019-07-04 17:19:17 --> Utf8 Class Initialized
INFO - 2019-07-04 17:19:17 --> Utf8 Class Initialized
INFO - 2019-07-04 17:19:17 --> URI Class Initialized
INFO - 2019-07-04 17:19:17 --> URI Class Initialized
INFO - 2019-07-04 17:19:17 --> Router Class Initialized
INFO - 2019-07-04 17:19:17 --> Router Class Initialized
INFO - 2019-07-04 17:19:17 --> Output Class Initialized
INFO - 2019-07-04 17:19:17 --> Output Class Initialized
INFO - 2019-07-04 17:19:17 --> Security Class Initialized
INFO - 2019-07-04 17:19:17 --> Security Class Initialized
DEBUG - 2019-07-04 17:19:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-04 17:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 17:19:17 --> Input Class Initialized
INFO - 2019-07-04 17:19:18 --> Input Class Initialized
INFO - 2019-07-04 17:19:18 --> Language Class Initialized
INFO - 2019-07-04 17:19:18 --> Language Class Initialized
INFO - 2019-07-04 17:19:18 --> Language Class Initialized
INFO - 2019-07-04 17:19:18 --> Language Class Initialized
INFO - 2019-07-04 17:19:18 --> Config Class Initialized
INFO - 2019-07-04 17:19:18 --> Loader Class Initialized
INFO - 2019-07-04 17:19:18 --> Config Class Initialized
INFO - 2019-07-04 17:19:18 --> Loader Class Initialized
DEBUG - 2019-07-04 17:19:18 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-04 17:19:18 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 17:19:18 --> Helper loaded: url_helper
INFO - 2019-07-04 17:19:18 --> Helper loaded: url_helper
INFO - 2019-07-04 17:19:18 --> Helper loaded: inflector_helper
INFO - 2019-07-04 17:19:18 --> Helper loaded: inflector_helper
INFO - 2019-07-04 17:19:18 --> Helper loaded: string_helper
INFO - 2019-07-04 17:19:18 --> Helper loaded: string_helper
INFO - 2019-07-04 17:19:18 --> Helper loaded: array_helper
INFO - 2019-07-04 17:19:18 --> Helper loaded: array_helper
INFO - 2019-07-04 17:19:18 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 17:19:18 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 17:19:18 --> Database Driver Class Initialized
INFO - 2019-07-04 17:19:18 --> Controller Class Initialized
INFO - 2019-07-04 23:19:18 --> Helper loaded: language_helper
INFO - 2019-07-04 23:19:18 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 23:19:18 --> Model Class Initialized
INFO - 2019-07-04 23:19:18 --> Model Class Initialized
INFO - 2019-07-04 23:19:18 --> Model Class Initialized
INFO - 2019-07-04 23:19:18 --> Model Class Initialized
INFO - 2019-07-04 23:19:18 --> Helper loaded: form_helper
INFO - 2019-07-04 23:19:18 --> Form Validation Class Initialized
DEBUG - 2019-07-04 23:19:18 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 23:19:18 --> Model Class Initialized
INFO - 2019-07-04 23:19:18 --> Model Class Initialized
INFO - 2019-07-04 23:19:18 --> Final output sent to browser
DEBUG - 2019-07-04 23:19:18 --> Total execution time: 0.7796
INFO - 2019-07-04 17:19:18 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 17:19:18 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 17:19:18 --> Database Driver Class Initialized
INFO - 2019-07-04 17:19:18 --> Controller Class Initialized
INFO - 2019-07-04 23:19:18 --> Helper loaded: language_helper
INFO - 2019-07-04 23:19:18 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 23:19:18 --> Model Class Initialized
INFO - 2019-07-04 23:19:18 --> Model Class Initialized
INFO - 2019-07-04 23:19:18 --> Model Class Initialized
INFO - 2019-07-04 23:19:18 --> Model Class Initialized
INFO - 2019-07-04 23:19:18 --> Model Class Initialized
INFO - 2019-07-04 23:19:18 --> Final output sent to browser
DEBUG - 2019-07-04 23:19:18 --> Total execution time: 1.0079
INFO - 2019-07-04 17:20:51 --> Config Class Initialized
INFO - 2019-07-04 17:20:51 --> Hooks Class Initialized
DEBUG - 2019-07-04 17:20:51 --> UTF-8 Support Enabled
INFO - 2019-07-04 17:20:51 --> Utf8 Class Initialized
INFO - 2019-07-04 17:20:51 --> URI Class Initialized
INFO - 2019-07-04 17:20:51 --> Config Class Initialized
INFO - 2019-07-04 17:20:51 --> Router Class Initialized
INFO - 2019-07-04 17:20:51 --> Hooks Class Initialized
INFO - 2019-07-04 17:20:51 --> Output Class Initialized
DEBUG - 2019-07-04 17:20:51 --> UTF-8 Support Enabled
INFO - 2019-07-04 17:20:51 --> Security Class Initialized
INFO - 2019-07-04 17:20:51 --> Utf8 Class Initialized
INFO - 2019-07-04 17:20:51 --> URI Class Initialized
DEBUG - 2019-07-04 17:20:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 17:20:51 --> Router Class Initialized
INFO - 2019-07-04 17:20:51 --> Input Class Initialized
INFO - 2019-07-04 17:20:51 --> Language Class Initialized
INFO - 2019-07-04 17:20:51 --> Output Class Initialized
INFO - 2019-07-04 17:20:51 --> Language Class Initialized
INFO - 2019-07-04 17:20:51 --> Security Class Initialized
INFO - 2019-07-04 17:20:51 --> Config Class Initialized
INFO - 2019-07-04 17:20:51 --> Loader Class Initialized
DEBUG - 2019-07-04 17:20:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-04 17:20:51 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 17:20:51 --> Input Class Initialized
INFO - 2019-07-04 17:20:51 --> Language Class Initialized
INFO - 2019-07-04 17:20:51 --> Helper loaded: url_helper
INFO - 2019-07-04 17:20:51 --> Language Class Initialized
INFO - 2019-07-04 17:20:51 --> Helper loaded: inflector_helper
INFO - 2019-07-04 17:20:51 --> Config Class Initialized
INFO - 2019-07-04 17:20:51 --> Loader Class Initialized
INFO - 2019-07-04 17:20:51 --> Helper loaded: string_helper
DEBUG - 2019-07-04 17:20:51 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 17:20:51 --> Helper loaded: array_helper
INFO - 2019-07-04 17:20:51 --> Helper loaded: url_helper
INFO - 2019-07-04 17:20:51 --> Session: Class initialized using 'files' driver.
INFO - 2019-07-04 17:20:51 --> Helper loaded: inflector_helper
DEBUG - 2019-07-04 17:20:51 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 17:20:51 --> Helper loaded: string_helper
INFO - 2019-07-04 17:20:51 --> Database Driver Class Initialized
INFO - 2019-07-04 17:20:51 --> Helper loaded: array_helper
INFO - 2019-07-04 17:20:51 --> Controller Class Initialized
INFO - 2019-07-04 23:20:51 --> Helper loaded: language_helper
INFO - 2019-07-04 23:20:51 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 23:20:51 --> Model Class Initialized
INFO - 2019-07-04 23:20:51 --> Model Class Initialized
INFO - 2019-07-04 23:20:51 --> Model Class Initialized
INFO - 2019-07-04 23:20:52 --> Model Class Initialized
INFO - 2019-07-04 23:20:52 --> Model Class Initialized
INFO - 2019-07-04 23:20:52 --> Final output sent to browser
DEBUG - 2019-07-04 23:20:52 --> Total execution time: 0.7300
INFO - 2019-07-04 17:20:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 17:20:52 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 17:20:52 --> Database Driver Class Initialized
INFO - 2019-07-04 17:20:52 --> Controller Class Initialized
INFO - 2019-07-04 23:20:52 --> Helper loaded: language_helper
INFO - 2019-07-04 23:20:52 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 23:20:52 --> Model Class Initialized
INFO - 2019-07-04 23:20:52 --> Model Class Initialized
INFO - 2019-07-04 23:20:52 --> Model Class Initialized
INFO - 2019-07-04 23:20:52 --> Model Class Initialized
INFO - 2019-07-04 23:20:52 --> Helper loaded: form_helper
INFO - 2019-07-04 23:20:52 --> Form Validation Class Initialized
DEBUG - 2019-07-04 23:20:52 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 23:20:52 --> Model Class Initialized
INFO - 2019-07-04 23:20:52 --> Model Class Initialized
INFO - 2019-07-04 23:20:52 --> Final output sent to browser
DEBUG - 2019-07-04 23:20:52 --> Total execution time: 1.0026
INFO - 2019-07-04 17:21:11 --> Config Class Initialized
INFO - 2019-07-04 17:21:11 --> Config Class Initialized
INFO - 2019-07-04 17:21:11 --> Hooks Class Initialized
INFO - 2019-07-04 17:21:11 --> Hooks Class Initialized
DEBUG - 2019-07-04 17:21:11 --> UTF-8 Support Enabled
DEBUG - 2019-07-04 17:21:11 --> UTF-8 Support Enabled
INFO - 2019-07-04 17:21:11 --> Utf8 Class Initialized
INFO - 2019-07-04 17:21:11 --> Utf8 Class Initialized
INFO - 2019-07-04 17:21:11 --> URI Class Initialized
INFO - 2019-07-04 17:21:11 --> URI Class Initialized
INFO - 2019-07-04 17:21:11 --> Router Class Initialized
INFO - 2019-07-04 17:21:11 --> Router Class Initialized
INFO - 2019-07-04 17:21:12 --> Output Class Initialized
INFO - 2019-07-04 17:21:12 --> Output Class Initialized
INFO - 2019-07-04 17:21:12 --> Security Class Initialized
INFO - 2019-07-04 17:21:12 --> Security Class Initialized
DEBUG - 2019-07-04 17:21:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-04 17:21:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 17:21:12 --> Input Class Initialized
INFO - 2019-07-04 17:21:12 --> Input Class Initialized
INFO - 2019-07-04 17:21:12 --> Language Class Initialized
INFO - 2019-07-04 17:21:12 --> Language Class Initialized
INFO - 2019-07-04 17:21:12 --> Language Class Initialized
INFO - 2019-07-04 17:21:12 --> Language Class Initialized
INFO - 2019-07-04 17:21:12 --> Config Class Initialized
INFO - 2019-07-04 17:21:12 --> Config Class Initialized
INFO - 2019-07-04 17:21:12 --> Loader Class Initialized
INFO - 2019-07-04 17:21:12 --> Loader Class Initialized
DEBUG - 2019-07-04 17:21:12 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-04 17:21:12 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 17:21:12 --> Helper loaded: url_helper
INFO - 2019-07-04 17:21:12 --> Helper loaded: url_helper
INFO - 2019-07-04 17:21:12 --> Helper loaded: inflector_helper
INFO - 2019-07-04 17:21:12 --> Helper loaded: inflector_helper
INFO - 2019-07-04 17:21:12 --> Helper loaded: string_helper
INFO - 2019-07-04 17:21:12 --> Helper loaded: string_helper
INFO - 2019-07-04 17:21:12 --> Helper loaded: array_helper
INFO - 2019-07-04 17:21:12 --> Helper loaded: array_helper
INFO - 2019-07-04 17:21:12 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 17:21:12 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 17:21:12 --> Database Driver Class Initialized
INFO - 2019-07-04 17:21:12 --> Controller Class Initialized
INFO - 2019-07-04 23:21:12 --> Helper loaded: language_helper
INFO - 2019-07-04 23:21:12 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 23:21:12 --> Model Class Initialized
INFO - 2019-07-04 23:21:12 --> Model Class Initialized
INFO - 2019-07-04 23:21:12 --> Model Class Initialized
INFO - 2019-07-04 23:21:12 --> Model Class Initialized
INFO - 2019-07-04 23:21:12 --> Helper loaded: form_helper
INFO - 2019-07-04 23:21:12 --> Form Validation Class Initialized
DEBUG - 2019-07-04 23:21:12 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 23:21:12 --> Model Class Initialized
INFO - 2019-07-04 23:21:12 --> Model Class Initialized
INFO - 2019-07-04 23:21:12 --> Final output sent to browser
DEBUG - 2019-07-04 23:21:12 --> Total execution time: 0.7963
INFO - 2019-07-04 17:21:12 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 17:21:12 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 17:21:12 --> Database Driver Class Initialized
INFO - 2019-07-04 17:21:12 --> Controller Class Initialized
INFO - 2019-07-04 23:21:12 --> Helper loaded: language_helper
INFO - 2019-07-04 23:21:12 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 23:21:12 --> Model Class Initialized
INFO - 2019-07-04 23:21:12 --> Model Class Initialized
INFO - 2019-07-04 23:21:12 --> Model Class Initialized
INFO - 2019-07-04 23:21:12 --> Model Class Initialized
INFO - 2019-07-04 23:21:12 --> Model Class Initialized
INFO - 2019-07-04 23:21:12 --> Final output sent to browser
DEBUG - 2019-07-04 23:21:12 --> Total execution time: 1.0237
INFO - 2019-07-04 17:21:14 --> Config Class Initialized
INFO - 2019-07-04 17:21:14 --> Config Class Initialized
INFO - 2019-07-04 17:21:14 --> Hooks Class Initialized
INFO - 2019-07-04 17:21:14 --> Hooks Class Initialized
DEBUG - 2019-07-04 17:21:14 --> UTF-8 Support Enabled
DEBUG - 2019-07-04 17:21:14 --> UTF-8 Support Enabled
INFO - 2019-07-04 17:21:14 --> Utf8 Class Initialized
INFO - 2019-07-04 17:21:14 --> Utf8 Class Initialized
INFO - 2019-07-04 17:21:15 --> URI Class Initialized
INFO - 2019-07-04 17:21:15 --> URI Class Initialized
INFO - 2019-07-04 17:21:15 --> Router Class Initialized
INFO - 2019-07-04 17:21:15 --> Router Class Initialized
INFO - 2019-07-04 17:21:15 --> Output Class Initialized
INFO - 2019-07-04 17:21:15 --> Output Class Initialized
INFO - 2019-07-04 17:21:15 --> Security Class Initialized
INFO - 2019-07-04 17:21:15 --> Security Class Initialized
DEBUG - 2019-07-04 17:21:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-04 17:21:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 17:21:15 --> Input Class Initialized
INFO - 2019-07-04 17:21:15 --> Input Class Initialized
INFO - 2019-07-04 17:21:15 --> Language Class Initialized
INFO - 2019-07-04 17:21:15 --> Language Class Initialized
INFO - 2019-07-04 17:21:15 --> Language Class Initialized
INFO - 2019-07-04 17:21:15 --> Language Class Initialized
INFO - 2019-07-04 17:21:15 --> Config Class Initialized
INFO - 2019-07-04 17:21:15 --> Config Class Initialized
INFO - 2019-07-04 17:21:15 --> Loader Class Initialized
INFO - 2019-07-04 17:21:15 --> Loader Class Initialized
DEBUG - 2019-07-04 17:21:15 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-04 17:21:15 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 17:21:15 --> Helper loaded: url_helper
INFO - 2019-07-04 17:21:15 --> Helper loaded: url_helper
INFO - 2019-07-04 17:21:15 --> Helper loaded: inflector_helper
INFO - 2019-07-04 17:21:15 --> Helper loaded: inflector_helper
INFO - 2019-07-04 17:21:15 --> Helper loaded: string_helper
INFO - 2019-07-04 17:21:15 --> Helper loaded: string_helper
INFO - 2019-07-04 17:21:15 --> Helper loaded: array_helper
INFO - 2019-07-04 17:21:15 --> Helper loaded: array_helper
INFO - 2019-07-04 17:21:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 17:21:15 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 17:21:15 --> Database Driver Class Initialized
INFO - 2019-07-04 17:21:15 --> Controller Class Initialized
INFO - 2019-07-04 23:21:15 --> Helper loaded: language_helper
INFO - 2019-07-04 23:21:15 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 23:21:15 --> Model Class Initialized
INFO - 2019-07-04 23:21:15 --> Model Class Initialized
INFO - 2019-07-04 23:21:15 --> Model Class Initialized
INFO - 2019-07-04 23:21:15 --> Model Class Initialized
INFO - 2019-07-04 23:21:15 --> Model Class Initialized
INFO - 2019-07-04 23:21:15 --> Final output sent to browser
DEBUG - 2019-07-04 23:21:15 --> Total execution time: 0.7062
INFO - 2019-07-04 17:21:15 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 17:21:15 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 17:21:15 --> Database Driver Class Initialized
INFO - 2019-07-04 17:21:15 --> Controller Class Initialized
INFO - 2019-07-04 23:21:15 --> Helper loaded: language_helper
INFO - 2019-07-04 23:21:15 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 23:21:15 --> Model Class Initialized
INFO - 2019-07-04 23:21:15 --> Model Class Initialized
INFO - 2019-07-04 23:21:15 --> Model Class Initialized
INFO - 2019-07-04 23:21:15 --> Model Class Initialized
INFO - 2019-07-04 23:21:15 --> Helper loaded: form_helper
INFO - 2019-07-04 23:21:15 --> Form Validation Class Initialized
DEBUG - 2019-07-04 23:21:15 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 23:21:15 --> Model Class Initialized
INFO - 2019-07-04 23:21:15 --> Model Class Initialized
INFO - 2019-07-04 23:21:15 --> Final output sent to browser
DEBUG - 2019-07-04 23:21:15 --> Total execution time: 0.9869
INFO - 2019-07-04 17:23:54 --> Config Class Initialized
INFO - 2019-07-04 17:23:54 --> Config Class Initialized
INFO - 2019-07-04 17:23:54 --> Hooks Class Initialized
INFO - 2019-07-04 17:23:54 --> Hooks Class Initialized
DEBUG - 2019-07-04 17:23:54 --> UTF-8 Support Enabled
DEBUG - 2019-07-04 17:23:54 --> UTF-8 Support Enabled
INFO - 2019-07-04 17:23:54 --> Utf8 Class Initialized
INFO - 2019-07-04 17:23:54 --> Utf8 Class Initialized
INFO - 2019-07-04 17:23:54 --> URI Class Initialized
INFO - 2019-07-04 17:23:54 --> URI Class Initialized
INFO - 2019-07-04 17:23:54 --> Router Class Initialized
INFO - 2019-07-04 17:23:54 --> Router Class Initialized
INFO - 2019-07-04 17:23:55 --> Output Class Initialized
INFO - 2019-07-04 17:23:55 --> Output Class Initialized
INFO - 2019-07-04 17:23:55 --> Security Class Initialized
INFO - 2019-07-04 17:23:55 --> Security Class Initialized
DEBUG - 2019-07-04 17:23:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-04 17:23:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 17:23:55 --> Input Class Initialized
INFO - 2019-07-04 17:23:55 --> Input Class Initialized
INFO - 2019-07-04 17:23:55 --> Language Class Initialized
INFO - 2019-07-04 17:23:55 --> Language Class Initialized
INFO - 2019-07-04 17:23:55 --> Language Class Initialized
INFO - 2019-07-04 17:23:55 --> Language Class Initialized
INFO - 2019-07-04 17:23:55 --> Config Class Initialized
INFO - 2019-07-04 17:23:55 --> Loader Class Initialized
INFO - 2019-07-04 17:23:55 --> Config Class Initialized
INFO - 2019-07-04 17:23:55 --> Loader Class Initialized
DEBUG - 2019-07-04 17:23:55 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-04 17:23:55 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 17:23:55 --> Helper loaded: url_helper
INFO - 2019-07-04 17:23:55 --> Helper loaded: url_helper
INFO - 2019-07-04 17:23:55 --> Helper loaded: inflector_helper
INFO - 2019-07-04 17:23:55 --> Helper loaded: inflector_helper
INFO - 2019-07-04 17:23:55 --> Helper loaded: string_helper
INFO - 2019-07-04 17:23:55 --> Helper loaded: string_helper
INFO - 2019-07-04 17:23:55 --> Helper loaded: array_helper
INFO - 2019-07-04 17:23:55 --> Helper loaded: array_helper
INFO - 2019-07-04 17:23:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 17:23:55 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 17:23:55 --> Database Driver Class Initialized
INFO - 2019-07-04 17:23:55 --> Controller Class Initialized
INFO - 2019-07-04 23:23:55 --> Helper loaded: language_helper
INFO - 2019-07-04 23:23:55 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 23:23:55 --> Model Class Initialized
INFO - 2019-07-04 23:23:55 --> Model Class Initialized
INFO - 2019-07-04 23:23:55 --> Model Class Initialized
INFO - 2019-07-04 23:23:55 --> Model Class Initialized
INFO - 2019-07-04 23:23:55 --> Model Class Initialized
INFO - 2019-07-04 23:23:55 --> Final output sent to browser
DEBUG - 2019-07-04 23:23:55 --> Total execution time: 0.7368
INFO - 2019-07-04 17:23:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 17:23:55 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 17:23:55 --> Database Driver Class Initialized
INFO - 2019-07-04 17:23:55 --> Controller Class Initialized
INFO - 2019-07-04 23:23:55 --> Helper loaded: language_helper
INFO - 2019-07-04 23:23:55 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 23:23:55 --> Model Class Initialized
INFO - 2019-07-04 23:23:55 --> Model Class Initialized
INFO - 2019-07-04 23:23:55 --> Model Class Initialized
INFO - 2019-07-04 23:23:55 --> Model Class Initialized
INFO - 2019-07-04 23:23:55 --> Helper loaded: form_helper
INFO - 2019-07-04 23:23:55 --> Form Validation Class Initialized
DEBUG - 2019-07-04 23:23:55 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 23:23:55 --> Model Class Initialized
INFO - 2019-07-04 23:23:55 --> Model Class Initialized
INFO - 2019-07-04 23:23:55 --> Final output sent to browser
DEBUG - 2019-07-04 23:23:55 --> Total execution time: 0.9949
INFO - 2019-07-04 17:32:57 --> Config Class Initialized
INFO - 2019-07-04 17:32:57 --> Hooks Class Initialized
INFO - 2019-07-04 17:32:57 --> Config Class Initialized
DEBUG - 2019-07-04 17:32:57 --> UTF-8 Support Enabled
INFO - 2019-07-04 17:32:57 --> Hooks Class Initialized
INFO - 2019-07-04 17:32:57 --> Utf8 Class Initialized
DEBUG - 2019-07-04 17:32:57 --> UTF-8 Support Enabled
INFO - 2019-07-04 17:32:57 --> URI Class Initialized
INFO - 2019-07-04 17:32:57 --> Utf8 Class Initialized
INFO - 2019-07-04 17:32:57 --> URI Class Initialized
INFO - 2019-07-04 17:32:57 --> Config Class Initialized
INFO - 2019-07-04 17:32:57 --> Config Class Initialized
INFO - 2019-07-04 17:32:57 --> Router Class Initialized
INFO - 2019-07-04 17:32:57 --> Hooks Class Initialized
INFO - 2019-07-04 17:32:57 --> Hooks Class Initialized
INFO - 2019-07-04 17:32:57 --> Router Class Initialized
INFO - 2019-07-04 17:32:57 --> Output Class Initialized
DEBUG - 2019-07-04 17:32:57 --> UTF-8 Support Enabled
DEBUG - 2019-07-04 17:32:57 --> UTF-8 Support Enabled
INFO - 2019-07-04 17:32:57 --> Security Class Initialized
INFO - 2019-07-04 17:32:57 --> Output Class Initialized
INFO - 2019-07-04 17:32:57 --> Utf8 Class Initialized
INFO - 2019-07-04 17:32:57 --> Utf8 Class Initialized
INFO - 2019-07-04 17:32:58 --> URI Class Initialized
INFO - 2019-07-04 17:32:58 --> Security Class Initialized
DEBUG - 2019-07-04 17:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 17:32:58 --> URI Class Initialized
INFO - 2019-07-04 17:32:58 --> Input Class Initialized
INFO - 2019-07-04 17:32:58 --> Router Class Initialized
DEBUG - 2019-07-04 17:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 17:32:58 --> Router Class Initialized
INFO - 2019-07-04 17:32:58 --> Input Class Initialized
INFO - 2019-07-04 17:32:58 --> Language Class Initialized
INFO - 2019-07-04 17:32:58 --> Output Class Initialized
INFO - 2019-07-04 17:32:58 --> Language Class Initialized
INFO - 2019-07-04 17:32:58 --> Config Class Initialized
INFO - 2019-07-04 17:32:58 --> Output Class Initialized
INFO - 2019-07-04 17:32:58 --> Language Class Initialized
INFO - 2019-07-04 17:32:58 --> Security Class Initialized
INFO - 2019-07-04 17:32:58 --> Loader Class Initialized
INFO - 2019-07-04 17:32:58 --> Language Class Initialized
DEBUG - 2019-07-04 17:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 17:32:58 --> Security Class Initialized
DEBUG - 2019-07-04 17:32:58 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 17:32:58 --> Input Class Initialized
INFO - 2019-07-04 17:32:58 --> Config Class Initialized
DEBUG - 2019-07-04 17:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 17:32:58 --> Helper loaded: url_helper
INFO - 2019-07-04 17:32:58 --> Language Class Initialized
INFO - 2019-07-04 17:32:58 --> Loader Class Initialized
INFO - 2019-07-04 17:32:58 --> Input Class Initialized
INFO - 2019-07-04 17:32:58 --> Language Class Initialized
DEBUG - 2019-07-04 17:32:58 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 17:32:58 --> Helper loaded: inflector_helper
INFO - 2019-07-04 17:32:58 --> Language Class Initialized
INFO - 2019-07-04 17:32:58 --> Config Class Initialized
INFO - 2019-07-04 17:32:58 --> Helper loaded: url_helper
INFO - 2019-07-04 17:32:58 --> Loader Class Initialized
INFO - 2019-07-04 17:32:58 --> Helper loaded: string_helper
INFO - 2019-07-04 17:32:58 --> Language Class Initialized
INFO - 2019-07-04 17:32:58 --> Helper loaded: inflector_helper
INFO - 2019-07-04 17:32:58 --> Config Class Initialized
DEBUG - 2019-07-04 17:32:58 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 17:32:58 --> Loader Class Initialized
INFO - 2019-07-04 17:32:58 --> Helper loaded: array_helper
INFO - 2019-07-04 17:32:58 --> Helper loaded: string_helper
INFO - 2019-07-04 17:32:58 --> Helper loaded: url_helper
DEBUG - 2019-07-04 17:32:58 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 17:32:58 --> Session: Class initialized using 'files' driver.
INFO - 2019-07-04 17:32:58 --> Helper loaded: array_helper
INFO - 2019-07-04 17:32:58 --> Helper loaded: inflector_helper
DEBUG - 2019-07-04 17:32:58 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 17:32:58 --> Helper loaded: url_helper
INFO - 2019-07-04 17:32:58 --> Helper loaded: inflector_helper
INFO - 2019-07-04 17:32:58 --> Helper loaded: string_helper
INFO - 2019-07-04 17:32:58 --> Database Driver Class Initialized
INFO - 2019-07-04 17:32:58 --> Helper loaded: string_helper
INFO - 2019-07-04 17:32:58 --> Helper loaded: array_helper
INFO - 2019-07-04 17:32:58 --> Controller Class Initialized
INFO - 2019-07-04 17:32:58 --> Helper loaded: array_helper
INFO - 2019-07-04 17:32:58 --> Session: Class initialized using 'files' driver.
INFO - 2019-07-04 23:32:58 --> Helper loaded: language_helper
DEBUG - 2019-07-04 17:32:58 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 17:32:58 --> Session: Class initialized using 'files' driver.
INFO - 2019-07-04 23:32:58 --> Language file loaded: language/english/general_lang.php
DEBUG - 2019-07-04 17:32:58 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 23:32:58 --> Model Class Initialized
INFO - 2019-07-04 17:32:58 --> Database Driver Class Initialized
INFO - 2019-07-04 17:32:58 --> Database Driver Class Initialized
INFO - 2019-07-04 17:32:58 --> Controller Class Initialized
INFO - 2019-07-04 23:32:58 --> Model Class Initialized
INFO - 2019-07-04 17:32:58 --> Controller Class Initialized
INFO - 2019-07-04 23:32:58 --> Helper loaded: language_helper
INFO - 2019-07-04 23:32:58 --> Model Class Initialized
INFO - 2019-07-04 23:32:58 --> Helper loaded: language_helper
INFO - 2019-07-04 23:32:58 --> Model Class Initialized
INFO - 2019-07-04 23:32:58 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 23:32:58 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 23:32:58 --> Model Class Initialized
INFO - 2019-07-04 23:32:58 --> Model Class Initialized
INFO - 2019-07-04 23:32:58 --> Model Class Initialized
INFO - 2019-07-04 23:32:58 --> Model Class Initialized
INFO - 2019-07-04 23:32:58 --> Final output sent to browser
INFO - 2019-07-04 23:32:58 --> Model Class Initialized
DEBUG - 2019-07-04 23:32:58 --> Total execution time: 1.0628
INFO - 2019-07-04 23:32:58 --> Model Class Initialized
INFO - 2019-07-04 17:32:58 --> Session: Class initialized using 'files' driver.
INFO - 2019-07-04 23:32:58 --> Model Class Initialized
INFO - 2019-07-04 23:32:58 --> Model Class Initialized
DEBUG - 2019-07-04 17:32:58 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 23:32:58 --> Model Class Initialized
INFO - 2019-07-04 23:32:58 --> Helper loaded: form_helper
INFO - 2019-07-04 23:32:58 --> Model Class Initialized
INFO - 2019-07-04 17:32:58 --> Database Driver Class Initialized
INFO - 2019-07-04 23:32:58 --> Form Validation Class Initialized
INFO - 2019-07-04 17:32:58 --> Controller Class Initialized
INFO - 2019-07-04 23:32:58 --> Final output sent to browser
DEBUG - 2019-07-04 23:32:58 --> Total execution time: 0.9735
DEBUG - 2019-07-04 23:32:58 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 23:32:58 --> Helper loaded: language_helper
INFO - 2019-07-04 23:32:58 --> Model Class Initialized
INFO - 2019-07-04 23:32:58 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 23:32:58 --> Model Class Initialized
INFO - 2019-07-04 23:32:58 --> Model Class Initialized
INFO - 2019-07-04 23:32:58 --> Final output sent to browser
INFO - 2019-07-04 23:32:58 --> Model Class Initialized
DEBUG - 2019-07-04 23:32:58 --> Total execution time: 1.0616
INFO - 2019-07-04 23:32:58 --> Model Class Initialized
INFO - 2019-07-04 23:32:58 --> Model Class Initialized
INFO - 2019-07-04 23:32:58 --> Helper loaded: form_helper
INFO - 2019-07-04 23:32:58 --> Form Validation Class Initialized
DEBUG - 2019-07-04 23:32:58 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-04 23:32:59 --> Model Class Initialized
INFO - 2019-07-04 23:32:59 --> Model Class Initialized
INFO - 2019-07-04 23:32:59 --> Final output sent to browser
DEBUG - 2019-07-04 23:32:59 --> Total execution time: 1.4415
INFO - 2019-07-04 17:33:04 --> Config Class Initialized
INFO - 2019-07-04 17:33:04 --> Config Class Initialized
INFO - 2019-07-04 17:33:04 --> Hooks Class Initialized
INFO - 2019-07-04 17:33:04 --> Hooks Class Initialized
DEBUG - 2019-07-04 17:33:04 --> UTF-8 Support Enabled
DEBUG - 2019-07-04 17:33:04 --> UTF-8 Support Enabled
INFO - 2019-07-04 17:33:04 --> Utf8 Class Initialized
INFO - 2019-07-04 17:33:04 --> Utf8 Class Initialized
INFO - 2019-07-04 17:33:04 --> URI Class Initialized
INFO - 2019-07-04 17:33:04 --> URI Class Initialized
INFO - 2019-07-04 17:33:04 --> Router Class Initialized
INFO - 2019-07-04 17:33:04 --> Router Class Initialized
INFO - 2019-07-04 17:33:04 --> Output Class Initialized
INFO - 2019-07-04 17:33:04 --> Output Class Initialized
INFO - 2019-07-04 17:33:04 --> Security Class Initialized
INFO - 2019-07-04 17:33:04 --> Security Class Initialized
DEBUG - 2019-07-04 17:33:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-04 17:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 17:33:04 --> Input Class Initialized
INFO - 2019-07-04 17:33:04 --> Input Class Initialized
INFO - 2019-07-04 17:33:04 --> Language Class Initialized
INFO - 2019-07-04 17:33:04 --> Language Class Initialized
INFO - 2019-07-04 17:33:04 --> Language Class Initialized
INFO - 2019-07-04 17:33:04 --> Language Class Initialized
INFO - 2019-07-04 17:33:04 --> Config Class Initialized
INFO - 2019-07-04 17:33:04 --> Config Class Initialized
INFO - 2019-07-04 17:33:04 --> Loader Class Initialized
INFO - 2019-07-04 17:33:04 --> Loader Class Initialized
DEBUG - 2019-07-04 17:33:04 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-04 17:33:04 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 17:33:04 --> Helper loaded: url_helper
INFO - 2019-07-04 17:33:04 --> Helper loaded: url_helper
INFO - 2019-07-04 17:33:04 --> Helper loaded: inflector_helper
INFO - 2019-07-04 17:33:04 --> Helper loaded: inflector_helper
INFO - 2019-07-04 17:33:04 --> Helper loaded: string_helper
INFO - 2019-07-04 17:33:04 --> Helper loaded: string_helper
INFO - 2019-07-04 17:33:04 --> Helper loaded: array_helper
INFO - 2019-07-04 17:33:04 --> Helper loaded: array_helper
INFO - 2019-07-04 17:33:04 --> Session: Class initialized using 'files' driver.
INFO - 2019-07-04 17:33:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 17:33:04 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
DEBUG - 2019-07-04 17:33:04 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 17:33:04 --> Database Driver Class Initialized
INFO - 2019-07-04 17:33:04 --> Database Driver Class Initialized
INFO - 2019-07-04 17:33:04 --> Controller Class Initialized
INFO - 2019-07-04 17:33:04 --> Controller Class Initialized
INFO - 2019-07-04 23:33:04 --> Helper loaded: language_helper
INFO - 2019-07-04 23:33:04 --> Helper loaded: language_helper
INFO - 2019-07-04 23:33:04 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 23:33:04 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-04 23:33:04 --> Model Class Initialized
INFO - 2019-07-04 23:33:04 --> Model Class Initialized
INFO - 2019-07-04 23:33:04 --> Model Class Initialized
INFO - 2019-07-04 23:33:04 --> Model Class Initialized
INFO - 2019-07-04 23:33:04 --> Model Class Initialized
INFO - 2019-07-04 23:33:04 --> Model Class Initialized
INFO - 2019-07-04 23:33:04 --> Model Class Initialized
INFO - 2019-07-04 23:33:04 --> Model Class Initialized
INFO - 2019-07-04 23:33:04 --> Helper loaded: form_helper
INFO - 2019-07-04 23:33:04 --> Model Class Initialized
INFO - 2019-07-04 23:33:04 --> Form Validation Class Initialized
INFO - 2019-07-04 23:33:04 --> Final output sent to browser
DEBUG - 2019-07-04 23:33:04 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
DEBUG - 2019-07-04 23:33:04 --> Total execution time: 0.8204
INFO - 2019-07-04 23:33:04 --> Model Class Initialized
INFO - 2019-07-04 23:33:04 --> Model Class Initialized
INFO - 2019-07-04 23:33:04 --> Final output sent to browser
DEBUG - 2019-07-04 23:33:04 --> Total execution time: 0.8883
INFO - 2019-07-04 18:56:23 --> Config Class Initialized
INFO - 2019-07-04 18:56:23 --> Config Class Initialized
INFO - 2019-07-04 18:56:23 --> Hooks Class Initialized
INFO - 2019-07-04 18:56:23 --> Hooks Class Initialized
DEBUG - 2019-07-04 18:56:23 --> UTF-8 Support Enabled
DEBUG - 2019-07-04 18:56:23 --> UTF-8 Support Enabled
INFO - 2019-07-04 18:56:23 --> Utf8 Class Initialized
INFO - 2019-07-04 18:56:23 --> Utf8 Class Initialized
INFO - 2019-07-04 18:56:23 --> URI Class Initialized
INFO - 2019-07-04 18:56:23 --> URI Class Initialized
INFO - 2019-07-04 18:56:24 --> Router Class Initialized
INFO - 2019-07-04 18:56:24 --> Router Class Initialized
INFO - 2019-07-04 18:56:24 --> Output Class Initialized
INFO - 2019-07-04 18:56:24 --> Output Class Initialized
INFO - 2019-07-04 18:56:24 --> Security Class Initialized
INFO - 2019-07-04 18:56:24 --> Security Class Initialized
DEBUG - 2019-07-04 18:56:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-04 18:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-04 18:56:24 --> Input Class Initialized
INFO - 2019-07-04 18:56:24 --> Input Class Initialized
INFO - 2019-07-04 18:56:24 --> Language Class Initialized
INFO - 2019-07-04 18:56:24 --> Language Class Initialized
INFO - 2019-07-04 18:56:24 --> Language Class Initialized
INFO - 2019-07-04 18:56:24 --> Language Class Initialized
INFO - 2019-07-04 18:56:24 --> Config Class Initialized
INFO - 2019-07-04 18:56:24 --> Config Class Initialized
INFO - 2019-07-04 18:56:24 --> Loader Class Initialized
INFO - 2019-07-04 18:56:24 --> Loader Class Initialized
DEBUG - 2019-07-04 18:56:24 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
DEBUG - 2019-07-04 18:56:24 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-04 18:56:24 --> Helper loaded: url_helper
INFO - 2019-07-04 18:56:24 --> Helper loaded: url_helper
INFO - 2019-07-04 18:56:24 --> Helper loaded: inflector_helper
INFO - 2019-07-04 18:56:24 --> Helper loaded: inflector_helper
INFO - 2019-07-04 18:56:24 --> Helper loaded: string_helper
INFO - 2019-07-04 18:56:24 --> Helper loaded: string_helper
INFO - 2019-07-04 18:56:24 --> Helper loaded: array_helper
INFO - 2019-07-04 18:56:24 --> Helper loaded: array_helper
INFO - 2019-07-04 18:56:24 --> Session: Class initialized using 'files' driver.
INFO - 2019-07-04 18:56:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-04 18:56:24 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
DEBUG - 2019-07-04 18:56:24 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-04 18:56:24 --> Database Driver Class Initialized
INFO - 2019-07-04 18:56:24 --> Database Driver Class Initialized
INFO - 2019-07-04 18:56:24 --> Controller Class Initialized
INFO - 2019-07-04 18:56:24 --> Controller Class Initialized
