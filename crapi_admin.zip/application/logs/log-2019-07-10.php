<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-07-10 00:03:00 --> Helper loaded: language_helper
INFO - 2019-07-10 00:03:00 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:03:00 --> Model Class Initialized
INFO - 2019-07-10 00:03:00 --> Model Class Initialized
INFO - 2019-07-10 00:03:00 --> Model Class Initialized
INFO - 2019-07-10 00:03:00 --> Model Class Initialized
INFO - 2019-07-10 00:03:00 --> Final output sent to browser
DEBUG - 2019-07-10 00:03:00 --> Total execution time: 0.5402
INFO - 2019-07-10 00:03:01 --> Helper loaded: language_helper
INFO - 2019-07-10 00:03:01 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:03:01 --> Model Class Initialized
INFO - 2019-07-10 00:03:01 --> Model Class Initialized
INFO - 2019-07-10 00:03:01 --> Model Class Initialized
INFO - 2019-07-10 00:03:01 --> Model Class Initialized
INFO - 2019-07-10 00:03:01 --> Model Class Initialized
INFO - 2019-07-10 00:03:01 --> Final output sent to browser
DEBUG - 2019-07-10 00:03:01 --> Total execution time: 0.5239
INFO - 2019-07-10 00:07:23 --> Helper loaded: language_helper
INFO - 2019-07-10 00:07:23 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:07:23 --> Model Class Initialized
INFO - 2019-07-10 00:07:23 --> Model Class Initialized
INFO - 2019-07-10 00:07:23 --> Model Class Initialized
INFO - 2019-07-10 00:07:23 --> Model Class Initialized
INFO - 2019-07-10 00:07:23 --> Helper loaded: form_helper
INFO - 2019-07-10 00:07:23 --> Form Validation Class Initialized
DEBUG - 2019-07-10 00:07:23 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 00:07:23 --> Model Class Initialized
INFO - 2019-07-10 00:07:23 --> Model Class Initialized
INFO - 2019-07-10 00:07:23 --> Final output sent to browser
DEBUG - 2019-07-10 00:07:23 --> Total execution time: 0.7879
INFO - 2019-07-10 00:07:23 --> Helper loaded: language_helper
INFO - 2019-07-10 00:07:23 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:07:23 --> Model Class Initialized
INFO - 2019-07-10 00:07:23 --> Model Class Initialized
INFO - 2019-07-10 00:07:23 --> Model Class Initialized
INFO - 2019-07-10 00:07:23 --> Model Class Initialized
INFO - 2019-07-10 00:07:23 --> Model Class Initialized
INFO - 2019-07-10 00:07:23 --> Final output sent to browser
DEBUG - 2019-07-10 00:07:23 --> Total execution time: 0.9255
INFO - 2019-07-10 00:17:36 --> Helper loaded: language_helper
INFO - 2019-07-10 00:17:36 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:17:36 --> Model Class Initialized
INFO - 2019-07-10 00:17:36 --> Model Class Initialized
INFO - 2019-07-10 00:17:36 --> Model Class Initialized
INFO - 2019-07-10 00:17:36 --> Model Class Initialized
INFO - 2019-07-10 00:17:36 --> Model Class Initialized
INFO - 2019-07-10 00:17:36 --> Final output sent to browser
DEBUG - 2019-07-10 00:17:36 --> Total execution time: 0.5277
INFO - 2019-07-10 00:21:10 --> Helper loaded: language_helper
INFO - 2019-07-10 00:21:10 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:21:10 --> Model Class Initialized
INFO - 2019-07-10 00:21:10 --> Model Class Initialized
INFO - 2019-07-10 00:21:10 --> Model Class Initialized
INFO - 2019-07-10 00:21:10 --> Model Class Initialized
INFO - 2019-07-10 00:21:10 --> Model Class Initialized
INFO - 2019-07-10 00:21:10 --> Final output sent to browser
DEBUG - 2019-07-10 00:21:10 --> Total execution time: 0.6109
INFO - 2019-07-10 00:21:13 --> Helper loaded: language_helper
INFO - 2019-07-10 00:21:13 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:21:13 --> Model Class Initialized
INFO - 2019-07-10 00:21:13 --> Model Class Initialized
INFO - 2019-07-10 00:21:13 --> Model Class Initialized
INFO - 2019-07-10 00:21:13 --> Model Class Initialized
INFO - 2019-07-10 00:21:13 --> Model Class Initialized
INFO - 2019-07-10 00:21:13 --> Final output sent to browser
DEBUG - 2019-07-10 00:21:13 --> Total execution time: 0.5887
INFO - 2019-07-10 00:21:46 --> Helper loaded: language_helper
INFO - 2019-07-10 00:21:46 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:21:46 --> Model Class Initialized
INFO - 2019-07-10 00:21:46 --> Model Class Initialized
INFO - 2019-07-10 00:21:46 --> Model Class Initialized
INFO - 2019-07-10 00:21:46 --> Model Class Initialized
INFO - 2019-07-10 00:21:46 --> Model Class Initialized
INFO - 2019-07-10 00:21:46 --> Final output sent to browser
DEBUG - 2019-07-10 00:21:46 --> Total execution time: 0.5439
INFO - 2019-07-10 00:22:52 --> Helper loaded: language_helper
INFO - 2019-07-10 00:22:52 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:22:52 --> Model Class Initialized
INFO - 2019-07-10 00:22:52 --> Model Class Initialized
INFO - 2019-07-10 00:22:52 --> Model Class Initialized
INFO - 2019-07-10 00:22:52 --> Model Class Initialized
INFO - 2019-07-10 00:22:52 --> Model Class Initialized
INFO - 2019-07-10 00:22:52 --> Final output sent to browser
DEBUG - 2019-07-10 00:22:52 --> Total execution time: 0.5635
INFO - 2019-07-10 00:23:19 --> Helper loaded: language_helper
INFO - 2019-07-10 00:23:19 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:23:19 --> Model Class Initialized
INFO - 2019-07-10 00:23:19 --> Model Class Initialized
INFO - 2019-07-10 00:23:19 --> Model Class Initialized
INFO - 2019-07-10 00:23:19 --> Model Class Initialized
INFO - 2019-07-10 00:23:19 --> Model Class Initialized
INFO - 2019-07-10 00:23:19 --> Final output sent to browser
DEBUG - 2019-07-10 00:23:19 --> Total execution time: 0.5761
INFO - 2019-07-10 00:23:25 --> Helper loaded: language_helper
INFO - 2019-07-10 00:23:25 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:23:26 --> Model Class Initialized
INFO - 2019-07-10 00:23:26 --> Model Class Initialized
INFO - 2019-07-10 00:23:26 --> Model Class Initialized
INFO - 2019-07-10 00:23:26 --> Model Class Initialized
INFO - 2019-07-10 00:23:26 --> Model Class Initialized
INFO - 2019-07-10 00:23:26 --> Final output sent to browser
DEBUG - 2019-07-10 00:23:26 --> Total execution time: 0.5872
INFO - 2019-07-10 00:23:34 --> Helper loaded: language_helper
INFO - 2019-07-10 00:23:34 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:23:34 --> Model Class Initialized
INFO - 2019-07-10 00:23:34 --> Model Class Initialized
INFO - 2019-07-10 00:23:34 --> Model Class Initialized
INFO - 2019-07-10 00:23:34 --> Model Class Initialized
INFO - 2019-07-10 00:23:34 --> Model Class Initialized
INFO - 2019-07-10 00:23:34 --> Final output sent to browser
DEBUG - 2019-07-10 00:23:34 --> Total execution time: 0.6223
INFO - 2019-07-10 00:24:01 --> Helper loaded: language_helper
INFO - 2019-07-10 00:24:01 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:24:01 --> Model Class Initialized
INFO - 2019-07-10 00:24:01 --> Model Class Initialized
INFO - 2019-07-10 00:24:01 --> Model Class Initialized
INFO - 2019-07-10 00:24:01 --> Model Class Initialized
INFO - 2019-07-10 00:24:01 --> Model Class Initialized
INFO - 2019-07-10 00:24:01 --> Final output sent to browser
DEBUG - 2019-07-10 00:24:01 --> Total execution time: 0.6133
INFO - 2019-07-10 00:24:05 --> Helper loaded: language_helper
INFO - 2019-07-10 00:24:05 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:24:05 --> Model Class Initialized
INFO - 2019-07-10 00:24:05 --> Model Class Initialized
INFO - 2019-07-10 00:24:05 --> Model Class Initialized
INFO - 2019-07-10 00:24:05 --> Model Class Initialized
INFO - 2019-07-10 00:24:05 --> Model Class Initialized
INFO - 2019-07-10 00:24:05 --> Final output sent to browser
DEBUG - 2019-07-10 00:24:05 --> Total execution time: 0.5731
INFO - 2019-07-10 00:24:09 --> Helper loaded: language_helper
INFO - 2019-07-10 00:24:09 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:24:09 --> Model Class Initialized
INFO - 2019-07-10 00:24:09 --> Model Class Initialized
INFO - 2019-07-10 00:24:09 --> Model Class Initialized
INFO - 2019-07-10 00:24:09 --> Model Class Initialized
INFO - 2019-07-10 00:24:09 --> Model Class Initialized
INFO - 2019-07-10 00:24:09 --> Final output sent to browser
DEBUG - 2019-07-10 00:24:09 --> Total execution time: 0.5108
INFO - 2019-07-10 00:24:15 --> Helper loaded: language_helper
INFO - 2019-07-10 00:24:15 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:24:15 --> Model Class Initialized
INFO - 2019-07-10 00:24:15 --> Model Class Initialized
INFO - 2019-07-10 00:24:15 --> Model Class Initialized
INFO - 2019-07-10 00:24:15 --> Model Class Initialized
INFO - 2019-07-10 00:24:15 --> Model Class Initialized
INFO - 2019-07-10 00:24:15 --> Final output sent to browser
DEBUG - 2019-07-10 00:24:15 --> Total execution time: 0.5311
INFO - 2019-07-10 00:24:16 --> Helper loaded: language_helper
INFO - 2019-07-10 00:24:16 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:24:16 --> Model Class Initialized
INFO - 2019-07-10 00:24:16 --> Model Class Initialized
INFO - 2019-07-10 00:24:16 --> Model Class Initialized
INFO - 2019-07-10 00:24:16 --> Model Class Initialized
INFO - 2019-07-10 00:24:16 --> Model Class Initialized
INFO - 2019-07-10 00:24:16 --> Final output sent to browser
DEBUG - 2019-07-10 00:24:16 --> Total execution time: 0.5793
INFO - 2019-07-10 00:24:17 --> Helper loaded: language_helper
INFO - 2019-07-10 00:24:17 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:24:17 --> Model Class Initialized
INFO - 2019-07-10 00:24:17 --> Model Class Initialized
INFO - 2019-07-10 00:24:17 --> Model Class Initialized
INFO - 2019-07-10 00:24:17 --> Model Class Initialized
INFO - 2019-07-10 00:24:17 --> Model Class Initialized
INFO - 2019-07-10 00:24:17 --> Final output sent to browser
DEBUG - 2019-07-10 00:24:17 --> Total execution time: 0.5178
INFO - 2019-07-10 00:24:18 --> Helper loaded: language_helper
INFO - 2019-07-10 00:24:18 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:24:18 --> Model Class Initialized
INFO - 2019-07-10 00:24:18 --> Model Class Initialized
INFO - 2019-07-10 00:24:18 --> Model Class Initialized
INFO - 2019-07-10 00:24:18 --> Model Class Initialized
INFO - 2019-07-10 00:24:18 --> Model Class Initialized
INFO - 2019-07-10 00:24:18 --> Final output sent to browser
DEBUG - 2019-07-10 00:24:18 --> Total execution time: 0.6381
INFO - 2019-07-10 00:26:11 --> Helper loaded: language_helper
INFO - 2019-07-10 00:26:11 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:26:11 --> Model Class Initialized
INFO - 2019-07-10 00:26:11 --> Model Class Initialized
INFO - 2019-07-10 00:26:11 --> Model Class Initialized
INFO - 2019-07-10 00:26:11 --> Model Class Initialized
INFO - 2019-07-10 00:26:11 --> Model Class Initialized
INFO - 2019-07-10 00:26:11 --> Final output sent to browser
DEBUG - 2019-07-10 00:26:11 --> Total execution time: 0.8078
INFO - 2019-07-10 00:26:11 --> Helper loaded: language_helper
INFO - 2019-07-10 00:26:11 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:26:11 --> Model Class Initialized
INFO - 2019-07-10 00:26:11 --> Model Class Initialized
INFO - 2019-07-10 00:26:11 --> Model Class Initialized
INFO - 2019-07-10 00:26:11 --> Model Class Initialized
INFO - 2019-07-10 00:26:11 --> Helper loaded: form_helper
INFO - 2019-07-10 00:26:11 --> Form Validation Class Initialized
DEBUG - 2019-07-10 00:26:11 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 00:26:11 --> Model Class Initialized
INFO - 2019-07-10 00:26:11 --> Model Class Initialized
INFO - 2019-07-10 00:26:11 --> Final output sent to browser
DEBUG - 2019-07-10 00:26:11 --> Total execution time: 1.0417
INFO - 2019-07-10 00:27:08 --> Helper loaded: language_helper
INFO - 2019-07-10 00:27:08 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:27:08 --> Model Class Initialized
INFO - 2019-07-10 00:27:08 --> Model Class Initialized
INFO - 2019-07-10 00:27:08 --> Model Class Initialized
INFO - 2019-07-10 00:27:08 --> Model Class Initialized
INFO - 2019-07-10 00:27:08 --> Helper loaded: form_helper
INFO - 2019-07-10 00:27:08 --> Form Validation Class Initialized
DEBUG - 2019-07-10 00:27:08 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 00:27:08 --> Model Class Initialized
INFO - 2019-07-10 00:27:08 --> Model Class Initialized
INFO - 2019-07-10 00:27:08 --> Final output sent to browser
DEBUG - 2019-07-10 00:27:08 --> Total execution time: 0.5821
INFO - 2019-07-10 00:27:33 --> Helper loaded: language_helper
INFO - 2019-07-10 00:27:33 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:27:33 --> Model Class Initialized
INFO - 2019-07-10 00:27:33 --> Model Class Initialized
INFO - 2019-07-10 00:27:33 --> Model Class Initialized
INFO - 2019-07-10 00:27:33 --> Model Class Initialized
INFO - 2019-07-10 00:27:33 --> Helper loaded: form_helper
INFO - 2019-07-10 00:27:34 --> Form Validation Class Initialized
DEBUG - 2019-07-10 00:27:34 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 00:27:34 --> Model Class Initialized
INFO - 2019-07-10 00:27:34 --> Model Class Initialized
INFO - 2019-07-10 00:27:34 --> Final output sent to browser
DEBUG - 2019-07-10 00:27:34 --> Total execution time: 0.5727
INFO - 2019-07-10 00:28:47 --> Helper loaded: language_helper
INFO - 2019-07-10 00:28:47 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:28:47 --> Model Class Initialized
INFO - 2019-07-10 00:28:47 --> Model Class Initialized
INFO - 2019-07-10 00:28:47 --> Model Class Initialized
INFO - 2019-07-10 00:28:47 --> Model Class Initialized
INFO - 2019-07-10 00:28:47 --> Helper loaded: form_helper
INFO - 2019-07-10 00:28:47 --> Form Validation Class Initialized
DEBUG - 2019-07-10 00:28:47 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 00:28:47 --> Model Class Initialized
INFO - 2019-07-10 00:28:47 --> Model Class Initialized
INFO - 2019-07-10 00:28:47 --> Final output sent to browser
DEBUG - 2019-07-10 00:28:47 --> Total execution time: 0.6337
INFO - 2019-07-10 00:28:48 --> Helper loaded: language_helper
INFO - 2019-07-10 00:28:48 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:28:49 --> Model Class Initialized
INFO - 2019-07-10 00:28:49 --> Model Class Initialized
INFO - 2019-07-10 00:28:49 --> Model Class Initialized
INFO - 2019-07-10 00:28:49 --> Model Class Initialized
INFO - 2019-07-10 00:28:49 --> Helper loaded: form_helper
INFO - 2019-07-10 00:28:49 --> Form Validation Class Initialized
DEBUG - 2019-07-10 00:28:49 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 00:28:49 --> Model Class Initialized
INFO - 2019-07-10 00:28:49 --> Model Class Initialized
INFO - 2019-07-10 00:28:49 --> Final output sent to browser
DEBUG - 2019-07-10 00:28:49 --> Total execution time: 0.5905
INFO - 2019-07-10 00:29:20 --> Helper loaded: language_helper
INFO - 2019-07-10 00:29:20 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:29:20 --> Model Class Initialized
INFO - 2019-07-10 00:29:20 --> Model Class Initialized
INFO - 2019-07-10 00:29:20 --> Model Class Initialized
INFO - 2019-07-10 00:29:20 --> Model Class Initialized
INFO - 2019-07-10 00:29:20 --> Helper loaded: form_helper
INFO - 2019-07-10 00:29:20 --> Form Validation Class Initialized
DEBUG - 2019-07-10 00:29:20 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 00:29:20 --> Model Class Initialized
INFO - 2019-07-10 00:29:20 --> Model Class Initialized
INFO - 2019-07-10 00:29:20 --> Final output sent to browser
DEBUG - 2019-07-10 00:29:20 --> Total execution time: 0.6078
INFO - 2019-07-10 00:29:23 --> Helper loaded: language_helper
INFO - 2019-07-10 00:29:23 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:29:23 --> Model Class Initialized
INFO - 2019-07-10 00:29:23 --> Model Class Initialized
INFO - 2019-07-10 00:29:23 --> Model Class Initialized
INFO - 2019-07-10 00:29:23 --> Model Class Initialized
INFO - 2019-07-10 00:29:23 --> Helper loaded: form_helper
INFO - 2019-07-10 00:29:23 --> Form Validation Class Initialized
DEBUG - 2019-07-10 00:29:23 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 00:29:23 --> Model Class Initialized
INFO - 2019-07-10 00:29:23 --> Model Class Initialized
INFO - 2019-07-10 00:29:23 --> Final output sent to browser
DEBUG - 2019-07-10 00:29:23 --> Total execution time: 0.6013
INFO - 2019-07-10 00:29:29 --> Helper loaded: language_helper
INFO - 2019-07-10 00:29:29 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:29:29 --> Model Class Initialized
INFO - 2019-07-10 00:29:29 --> Model Class Initialized
INFO - 2019-07-10 00:29:29 --> Model Class Initialized
INFO - 2019-07-10 00:29:29 --> Model Class Initialized
INFO - 2019-07-10 00:29:29 --> Helper loaded: form_helper
INFO - 2019-07-10 00:29:29 --> Form Validation Class Initialized
DEBUG - 2019-07-10 00:29:29 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 00:29:29 --> Model Class Initialized
INFO - 2019-07-10 00:29:29 --> Model Class Initialized
INFO - 2019-07-10 00:29:29 --> Final output sent to browser
DEBUG - 2019-07-10 00:29:29 --> Total execution time: 0.6097
INFO - 2019-07-10 00:29:35 --> Helper loaded: language_helper
INFO - 2019-07-10 00:29:35 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:29:35 --> Model Class Initialized
INFO - 2019-07-10 00:29:35 --> Model Class Initialized
INFO - 2019-07-10 00:29:35 --> Model Class Initialized
INFO - 2019-07-10 00:29:35 --> Model Class Initialized
INFO - 2019-07-10 00:29:35 --> Helper loaded: form_helper
INFO - 2019-07-10 00:29:35 --> Form Validation Class Initialized
DEBUG - 2019-07-10 00:29:35 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 00:29:35 --> Model Class Initialized
INFO - 2019-07-10 00:29:35 --> Model Class Initialized
INFO - 2019-07-10 00:29:35 --> Final output sent to browser
DEBUG - 2019-07-10 00:29:35 --> Total execution time: 0.6562
INFO - 2019-07-10 00:29:53 --> Helper loaded: language_helper
INFO - 2019-07-10 00:29:53 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:29:53 --> Model Class Initialized
INFO - 2019-07-10 00:29:53 --> Model Class Initialized
INFO - 2019-07-10 00:29:53 --> Model Class Initialized
INFO - 2019-07-10 00:29:53 --> Model Class Initialized
INFO - 2019-07-10 00:29:53 --> Helper loaded: form_helper
INFO - 2019-07-10 00:29:53 --> Form Validation Class Initialized
DEBUG - 2019-07-10 00:29:53 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 00:29:53 --> Model Class Initialized
INFO - 2019-07-10 00:29:53 --> Model Class Initialized
INFO - 2019-07-10 00:29:53 --> Final output sent to browser
DEBUG - 2019-07-10 00:29:53 --> Total execution time: 0.6189
INFO - 2019-07-10 00:29:55 --> Helper loaded: language_helper
INFO - 2019-07-10 00:29:55 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:29:55 --> Model Class Initialized
INFO - 2019-07-10 00:29:55 --> Model Class Initialized
INFO - 2019-07-10 00:29:55 --> Model Class Initialized
INFO - 2019-07-10 00:29:55 --> Model Class Initialized
INFO - 2019-07-10 00:29:55 --> Helper loaded: form_helper
INFO - 2019-07-10 00:29:55 --> Form Validation Class Initialized
DEBUG - 2019-07-10 00:29:55 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 00:29:55 --> Model Class Initialized
INFO - 2019-07-10 00:29:55 --> Model Class Initialized
INFO - 2019-07-10 00:29:55 --> Final output sent to browser
DEBUG - 2019-07-10 00:29:55 --> Total execution time: 0.5860
INFO - 2019-07-10 00:30:20 --> Helper loaded: language_helper
INFO - 2019-07-10 00:30:21 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:30:21 --> Model Class Initialized
INFO - 2019-07-10 00:30:21 --> Model Class Initialized
INFO - 2019-07-10 00:30:21 --> Model Class Initialized
INFO - 2019-07-10 00:30:21 --> Model Class Initialized
INFO - 2019-07-10 00:30:21 --> Helper loaded: form_helper
INFO - 2019-07-10 00:30:21 --> Form Validation Class Initialized
DEBUG - 2019-07-10 00:30:21 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 00:30:21 --> Model Class Initialized
INFO - 2019-07-10 00:30:21 --> Model Class Initialized
INFO - 2019-07-10 00:30:21 --> Final output sent to browser
DEBUG - 2019-07-10 00:30:21 --> Total execution time: 0.6467
INFO - 2019-07-10 00:30:22 --> Helper loaded: language_helper
INFO - 2019-07-10 00:30:22 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:30:22 --> Model Class Initialized
INFO - 2019-07-10 00:30:22 --> Model Class Initialized
INFO - 2019-07-10 00:30:22 --> Model Class Initialized
INFO - 2019-07-10 00:30:22 --> Model Class Initialized
INFO - 2019-07-10 00:30:22 --> Helper loaded: form_helper
INFO - 2019-07-10 00:30:22 --> Form Validation Class Initialized
DEBUG - 2019-07-10 00:30:22 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 00:30:22 --> Model Class Initialized
INFO - 2019-07-10 00:30:22 --> Model Class Initialized
INFO - 2019-07-10 00:30:22 --> Final output sent to browser
DEBUG - 2019-07-10 00:30:22 --> Total execution time: 0.5805
INFO - 2019-07-10 00:30:35 --> Helper loaded: language_helper
INFO - 2019-07-10 00:30:35 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:30:35 --> Model Class Initialized
INFO - 2019-07-10 00:30:35 --> Model Class Initialized
INFO - 2019-07-10 00:30:35 --> Model Class Initialized
INFO - 2019-07-10 00:30:35 --> Model Class Initialized
INFO - 2019-07-10 00:30:35 --> Helper loaded: form_helper
INFO - 2019-07-10 00:30:35 --> Form Validation Class Initialized
DEBUG - 2019-07-10 00:30:35 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 00:30:35 --> Model Class Initialized
INFO - 2019-07-10 00:30:35 --> Model Class Initialized
INFO - 2019-07-10 00:30:35 --> Final output sent to browser
DEBUG - 2019-07-10 00:30:36 --> Total execution time: 0.6068
INFO - 2019-07-10 00:30:37 --> Helper loaded: language_helper
INFO - 2019-07-10 00:30:37 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:30:37 --> Model Class Initialized
INFO - 2019-07-10 00:30:37 --> Model Class Initialized
INFO - 2019-07-10 00:30:37 --> Model Class Initialized
INFO - 2019-07-10 00:30:37 --> Model Class Initialized
INFO - 2019-07-10 00:30:37 --> Helper loaded: form_helper
INFO - 2019-07-10 00:30:37 --> Form Validation Class Initialized
DEBUG - 2019-07-10 00:30:37 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 00:30:37 --> Model Class Initialized
INFO - 2019-07-10 00:30:37 --> Model Class Initialized
INFO - 2019-07-10 00:30:37 --> Final output sent to browser
DEBUG - 2019-07-10 00:30:37 --> Total execution time: 0.5880
INFO - 2019-07-10 00:30:39 --> Helper loaded: language_helper
INFO - 2019-07-10 00:30:39 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:30:39 --> Model Class Initialized
INFO - 2019-07-10 00:30:39 --> Model Class Initialized
INFO - 2019-07-10 00:30:39 --> Model Class Initialized
INFO - 2019-07-10 00:30:39 --> Model Class Initialized
INFO - 2019-07-10 00:30:39 --> Helper loaded: form_helper
INFO - 2019-07-10 00:30:39 --> Form Validation Class Initialized
DEBUG - 2019-07-10 00:30:39 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 00:30:39 --> Model Class Initialized
INFO - 2019-07-10 00:30:39 --> Model Class Initialized
INFO - 2019-07-10 00:30:39 --> Final output sent to browser
DEBUG - 2019-07-10 00:30:39 --> Total execution time: 0.6097
INFO - 2019-07-10 00:30:45 --> Helper loaded: language_helper
INFO - 2019-07-10 00:30:45 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:30:45 --> Model Class Initialized
INFO - 2019-07-10 00:30:45 --> Model Class Initialized
INFO - 2019-07-10 00:30:45 --> Model Class Initialized
INFO - 2019-07-10 00:30:45 --> Model Class Initialized
INFO - 2019-07-10 00:30:45 --> Helper loaded: form_helper
INFO - 2019-07-10 00:30:45 --> Form Validation Class Initialized
DEBUG - 2019-07-10 00:30:45 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 00:30:45 --> Model Class Initialized
INFO - 2019-07-10 00:30:45 --> Model Class Initialized
INFO - 2019-07-10 00:30:45 --> Final output sent to browser
DEBUG - 2019-07-10 00:30:45 --> Total execution time: 0.7744
INFO - 2019-07-10 00:30:46 --> Helper loaded: language_helper
INFO - 2019-07-10 00:30:46 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:30:46 --> Model Class Initialized
INFO - 2019-07-10 00:30:46 --> Model Class Initialized
INFO - 2019-07-10 00:30:46 --> Model Class Initialized
INFO - 2019-07-10 00:30:46 --> Model Class Initialized
INFO - 2019-07-10 00:30:46 --> Helper loaded: form_helper
INFO - 2019-07-10 00:30:46 --> Form Validation Class Initialized
DEBUG - 2019-07-10 00:30:46 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 00:30:46 --> Model Class Initialized
INFO - 2019-07-10 00:30:46 --> Model Class Initialized
INFO - 2019-07-10 00:30:46 --> Final output sent to browser
DEBUG - 2019-07-10 00:30:46 --> Total execution time: 0.6126
INFO - 2019-07-10 00:30:47 --> Helper loaded: language_helper
INFO - 2019-07-10 00:30:47 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:30:47 --> Model Class Initialized
INFO - 2019-07-10 00:30:47 --> Model Class Initialized
INFO - 2019-07-10 00:30:47 --> Model Class Initialized
INFO - 2019-07-10 00:30:47 --> Model Class Initialized
INFO - 2019-07-10 00:30:47 --> Helper loaded: form_helper
INFO - 2019-07-10 00:30:47 --> Form Validation Class Initialized
DEBUG - 2019-07-10 00:30:47 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 00:30:47 --> Model Class Initialized
INFO - 2019-07-10 00:30:47 --> Model Class Initialized
INFO - 2019-07-10 00:30:47 --> Final output sent to browser
DEBUG - 2019-07-10 00:30:47 --> Total execution time: 0.5818
INFO - 2019-07-10 00:31:46 --> Helper loaded: language_helper
INFO - 2019-07-10 00:31:46 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:31:46 --> Model Class Initialized
INFO - 2019-07-10 00:31:46 --> Model Class Initialized
INFO - 2019-07-10 00:31:46 --> Model Class Initialized
INFO - 2019-07-10 00:31:46 --> Model Class Initialized
INFO - 2019-07-10 00:31:46 --> Helper loaded: form_helper
INFO - 2019-07-10 00:31:46 --> Form Validation Class Initialized
DEBUG - 2019-07-10 00:31:46 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 00:31:46 --> Model Class Initialized
INFO - 2019-07-10 00:31:46 --> Model Class Initialized
INFO - 2019-07-10 00:31:46 --> Final output sent to browser
DEBUG - 2019-07-10 00:31:46 --> Total execution time: 0.7010
INFO - 2019-07-10 00:32:25 --> Helper loaded: language_helper
INFO - 2019-07-10 00:32:25 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:32:25 --> Model Class Initialized
INFO - 2019-07-10 00:32:25 --> Model Class Initialized
INFO - 2019-07-10 00:32:25 --> Model Class Initialized
INFO - 2019-07-10 00:32:25 --> Model Class Initialized
INFO - 2019-07-10 00:32:25 --> Helper loaded: form_helper
INFO - 2019-07-10 00:32:25 --> Form Validation Class Initialized
DEBUG - 2019-07-10 00:32:25 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 00:32:25 --> Model Class Initialized
INFO - 2019-07-10 00:32:25 --> Model Class Initialized
INFO - 2019-07-10 00:32:25 --> Final output sent to browser
DEBUG - 2019-07-10 00:32:25 --> Total execution time: 0.6488
INFO - 2019-07-10 00:34:33 --> Helper loaded: language_helper
INFO - 2019-07-10 00:34:33 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:34:33 --> Model Class Initialized
INFO - 2019-07-10 00:34:33 --> Model Class Initialized
INFO - 2019-07-10 00:34:33 --> Model Class Initialized
INFO - 2019-07-10 00:34:33 --> Model Class Initialized
INFO - 2019-07-10 00:34:33 --> Helper loaded: form_helper
INFO - 2019-07-10 00:34:33 --> Form Validation Class Initialized
DEBUG - 2019-07-10 00:34:33 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 00:34:33 --> Model Class Initialized
INFO - 2019-07-10 00:34:33 --> Model Class Initialized
INFO - 2019-07-10 00:34:33 --> Final output sent to browser
DEBUG - 2019-07-10 00:34:33 --> Total execution time: 0.5892
INFO - 2019-07-10 00:35:36 --> Helper loaded: language_helper
INFO - 2019-07-10 00:35:36 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:35:36 --> Model Class Initialized
INFO - 2019-07-10 00:35:36 --> Model Class Initialized
INFO - 2019-07-10 00:35:36 --> Model Class Initialized
INFO - 2019-07-10 00:35:36 --> Model Class Initialized
INFO - 2019-07-10 00:35:36 --> Helper loaded: form_helper
INFO - 2019-07-10 00:35:36 --> Form Validation Class Initialized
DEBUG - 2019-07-10 00:35:36 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 00:35:36 --> Model Class Initialized
INFO - 2019-07-10 00:35:36 --> Model Class Initialized
INFO - 2019-07-10 00:35:36 --> Final output sent to browser
DEBUG - 2019-07-10 00:35:36 --> Total execution time: 0.6516
INFO - 2019-07-10 00:35:38 --> Helper loaded: language_helper
INFO - 2019-07-10 00:35:38 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:35:38 --> Model Class Initialized
INFO - 2019-07-10 00:35:38 --> Model Class Initialized
INFO - 2019-07-10 00:35:38 --> Model Class Initialized
INFO - 2019-07-10 00:35:38 --> Model Class Initialized
INFO - 2019-07-10 00:35:38 --> Helper loaded: form_helper
INFO - 2019-07-10 00:35:38 --> Form Validation Class Initialized
DEBUG - 2019-07-10 00:35:38 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 00:35:38 --> Model Class Initialized
INFO - 2019-07-10 00:35:38 --> Model Class Initialized
INFO - 2019-07-10 00:35:38 --> Final output sent to browser
DEBUG - 2019-07-10 00:35:38 --> Total execution time: 0.6139
INFO - 2019-07-10 00:35:39 --> Helper loaded: language_helper
INFO - 2019-07-10 00:35:39 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:35:39 --> Model Class Initialized
INFO - 2019-07-10 00:35:39 --> Model Class Initialized
INFO - 2019-07-10 00:35:39 --> Model Class Initialized
INFO - 2019-07-10 00:35:39 --> Model Class Initialized
INFO - 2019-07-10 00:35:39 --> Helper loaded: form_helper
INFO - 2019-07-10 00:35:39 --> Form Validation Class Initialized
DEBUG - 2019-07-10 00:35:39 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 00:35:39 --> Model Class Initialized
INFO - 2019-07-10 00:35:39 --> Model Class Initialized
INFO - 2019-07-10 00:35:39 --> Final output sent to browser
DEBUG - 2019-07-10 00:35:39 --> Total execution time: 0.6229
INFO - 2019-07-10 00:35:41 --> Helper loaded: language_helper
INFO - 2019-07-10 00:35:41 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:35:41 --> Model Class Initialized
INFO - 2019-07-10 00:35:41 --> Model Class Initialized
INFO - 2019-07-10 00:35:41 --> Model Class Initialized
INFO - 2019-07-10 00:35:41 --> Model Class Initialized
INFO - 2019-07-10 00:35:41 --> Helper loaded: form_helper
INFO - 2019-07-10 00:35:41 --> Form Validation Class Initialized
DEBUG - 2019-07-10 00:35:41 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 00:35:41 --> Model Class Initialized
INFO - 2019-07-10 00:35:41 --> Model Class Initialized
INFO - 2019-07-10 00:35:41 --> Final output sent to browser
DEBUG - 2019-07-10 00:35:41 --> Total execution time: 0.6057
INFO - 2019-07-10 00:35:57 --> Helper loaded: language_helper
INFO - 2019-07-10 00:35:57 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:35:57 --> Model Class Initialized
INFO - 2019-07-10 00:35:58 --> Model Class Initialized
INFO - 2019-07-10 00:35:58 --> Model Class Initialized
INFO - 2019-07-10 00:35:58 --> Model Class Initialized
INFO - 2019-07-10 00:35:58 --> Helper loaded: form_helper
INFO - 2019-07-10 00:35:58 --> Form Validation Class Initialized
DEBUG - 2019-07-10 00:35:58 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 00:35:58 --> Model Class Initialized
INFO - 2019-07-10 00:35:58 --> Model Class Initialized
INFO - 2019-07-10 00:35:58 --> Final output sent to browser
DEBUG - 2019-07-10 00:35:58 --> Total execution time: 0.6179
INFO - 2019-07-10 00:36:22 --> Helper loaded: language_helper
INFO - 2019-07-10 00:36:22 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:36:22 --> Model Class Initialized
INFO - 2019-07-10 00:36:22 --> Model Class Initialized
INFO - 2019-07-10 00:36:22 --> Model Class Initialized
INFO - 2019-07-10 00:36:22 --> Model Class Initialized
INFO - 2019-07-10 00:36:22 --> Helper loaded: form_helper
INFO - 2019-07-10 00:36:22 --> Form Validation Class Initialized
DEBUG - 2019-07-10 00:36:22 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 00:36:22 --> Model Class Initialized
INFO - 2019-07-10 00:36:22 --> Model Class Initialized
INFO - 2019-07-10 00:36:22 --> Final output sent to browser
DEBUG - 2019-07-10 00:36:22 --> Total execution time: 0.6565
INFO - 2019-07-10 00:36:31 --> Helper loaded: language_helper
INFO - 2019-07-10 00:36:31 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:36:31 --> Model Class Initialized
INFO - 2019-07-10 00:36:31 --> Model Class Initialized
INFO - 2019-07-10 00:36:31 --> Model Class Initialized
INFO - 2019-07-10 00:36:31 --> Model Class Initialized
INFO - 2019-07-10 00:36:31 --> Helper loaded: form_helper
INFO - 2019-07-10 00:36:31 --> Form Validation Class Initialized
DEBUG - 2019-07-10 00:36:31 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 00:36:31 --> Model Class Initialized
INFO - 2019-07-10 00:36:31 --> Model Class Initialized
INFO - 2019-07-10 00:36:31 --> Final output sent to browser
DEBUG - 2019-07-10 00:36:31 --> Total execution time: 0.7041
INFO - 2019-07-10 00:37:22 --> Helper loaded: language_helper
INFO - 2019-07-10 00:37:22 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:37:22 --> Model Class Initialized
INFO - 2019-07-10 00:37:22 --> Model Class Initialized
INFO - 2019-07-10 00:37:22 --> Model Class Initialized
INFO - 2019-07-10 00:37:22 --> Model Class Initialized
INFO - 2019-07-10 00:37:22 --> Helper loaded: form_helper
INFO - 2019-07-10 00:37:22 --> Form Validation Class Initialized
DEBUG - 2019-07-10 00:37:22 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 00:37:22 --> Model Class Initialized
INFO - 2019-07-10 00:37:22 --> Model Class Initialized
INFO - 2019-07-10 00:37:22 --> Final output sent to browser
DEBUG - 2019-07-10 00:37:22 --> Total execution time: 0.6279
INFO - 2019-07-10 00:37:46 --> Helper loaded: language_helper
INFO - 2019-07-10 00:37:46 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:37:46 --> Model Class Initialized
INFO - 2019-07-10 00:37:46 --> Model Class Initialized
INFO - 2019-07-10 00:37:46 --> Model Class Initialized
INFO - 2019-07-10 00:37:46 --> Model Class Initialized
INFO - 2019-07-10 00:37:46 --> Helper loaded: form_helper
INFO - 2019-07-10 00:37:46 --> Form Validation Class Initialized
DEBUG - 2019-07-10 00:37:46 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 00:37:46 --> Model Class Initialized
INFO - 2019-07-10 00:37:46 --> Model Class Initialized
INFO - 2019-07-10 00:37:46 --> Final output sent to browser
DEBUG - 2019-07-10 00:37:46 --> Total execution time: 0.6244
INFO - 2019-07-10 00:38:28 --> Helper loaded: language_helper
INFO - 2019-07-10 00:38:28 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:38:28 --> Model Class Initialized
INFO - 2019-07-10 00:38:28 --> Model Class Initialized
INFO - 2019-07-10 00:38:28 --> Model Class Initialized
INFO - 2019-07-10 00:38:28 --> Model Class Initialized
INFO - 2019-07-10 00:38:28 --> Helper loaded: form_helper
INFO - 2019-07-10 00:38:28 --> Form Validation Class Initialized
DEBUG - 2019-07-10 00:38:28 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 00:38:28 --> Model Class Initialized
INFO - 2019-07-10 00:38:28 --> Model Class Initialized
INFO - 2019-07-10 00:38:28 --> Final output sent to browser
DEBUG - 2019-07-10 00:38:28 --> Total execution time: 0.6216
INFO - 2019-07-10 00:38:35 --> Helper loaded: language_helper
INFO - 2019-07-10 00:38:35 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:38:35 --> Model Class Initialized
INFO - 2019-07-10 00:38:35 --> Model Class Initialized
INFO - 2019-07-10 00:38:35 --> Model Class Initialized
INFO - 2019-07-10 00:38:35 --> Model Class Initialized
INFO - 2019-07-10 00:38:35 --> Helper loaded: form_helper
INFO - 2019-07-10 00:38:35 --> Form Validation Class Initialized
DEBUG - 2019-07-10 00:38:35 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 00:38:35 --> Model Class Initialized
INFO - 2019-07-10 00:38:35 --> Model Class Initialized
INFO - 2019-07-10 00:38:35 --> Final output sent to browser
DEBUG - 2019-07-10 00:38:35 --> Total execution time: 0.8859
INFO - 2019-07-10 00:38:35 --> Helper loaded: language_helper
INFO - 2019-07-10 00:38:35 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:38:35 --> Model Class Initialized
INFO - 2019-07-10 00:38:35 --> Model Class Initialized
INFO - 2019-07-10 00:38:35 --> Model Class Initialized
INFO - 2019-07-10 00:38:35 --> Model Class Initialized
INFO - 2019-07-10 00:38:35 --> Helper loaded: form_helper
INFO - 2019-07-10 00:38:35 --> Form Validation Class Initialized
DEBUG - 2019-07-10 00:38:35 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 00:38:35 --> Model Class Initialized
INFO - 2019-07-10 00:38:35 --> Model Class Initialized
INFO - 2019-07-10 00:38:35 --> Final output sent to browser
DEBUG - 2019-07-10 00:38:35 --> Total execution time: 0.7164
INFO - 2019-07-10 00:38:37 --> Helper loaded: language_helper
INFO - 2019-07-10 00:38:37 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:38:37 --> Model Class Initialized
INFO - 2019-07-10 00:38:37 --> Model Class Initialized
INFO - 2019-07-10 00:38:37 --> Model Class Initialized
INFO - 2019-07-10 00:38:37 --> Model Class Initialized
INFO - 2019-07-10 00:38:37 --> Helper loaded: form_helper
INFO - 2019-07-10 00:38:37 --> Form Validation Class Initialized
DEBUG - 2019-07-10 00:38:37 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 00:38:37 --> Model Class Initialized
INFO - 2019-07-10 00:38:37 --> Model Class Initialized
INFO - 2019-07-10 00:38:37 --> Final output sent to browser
DEBUG - 2019-07-10 00:38:37 --> Total execution time: 0.6462
INFO - 2019-07-10 00:38:43 --> Helper loaded: language_helper
INFO - 2019-07-10 00:38:43 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:38:43 --> Model Class Initialized
INFO - 2019-07-10 00:38:43 --> Model Class Initialized
INFO - 2019-07-10 00:38:43 --> Model Class Initialized
INFO - 2019-07-10 00:38:43 --> Model Class Initialized
INFO - 2019-07-10 00:38:43 --> Helper loaded: form_helper
INFO - 2019-07-10 00:38:43 --> Form Validation Class Initialized
DEBUG - 2019-07-10 00:38:43 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 00:38:43 --> Model Class Initialized
INFO - 2019-07-10 00:38:43 --> Model Class Initialized
INFO - 2019-07-10 00:38:43 --> Final output sent to browser
DEBUG - 2019-07-10 00:38:43 --> Total execution time: 0.6158
INFO - 2019-07-10 00:39:11 --> Helper loaded: language_helper
INFO - 2019-07-10 00:39:11 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:39:11 --> Model Class Initialized
INFO - 2019-07-10 00:39:11 --> Model Class Initialized
INFO - 2019-07-10 00:39:11 --> Model Class Initialized
INFO - 2019-07-10 00:39:11 --> Model Class Initialized
INFO - 2019-07-10 00:39:11 --> Helper loaded: form_helper
INFO - 2019-07-10 00:39:11 --> Form Validation Class Initialized
DEBUG - 2019-07-10 00:39:11 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 00:39:11 --> Model Class Initialized
INFO - 2019-07-10 00:39:11 --> Model Class Initialized
INFO - 2019-07-10 00:39:11 --> Final output sent to browser
DEBUG - 2019-07-10 00:39:11 --> Total execution time: 0.6733
INFO - 2019-07-10 00:39:17 --> Helper loaded: language_helper
INFO - 2019-07-10 00:39:17 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:39:17 --> Model Class Initialized
INFO - 2019-07-10 00:39:17 --> Model Class Initialized
INFO - 2019-07-10 00:39:17 --> Model Class Initialized
INFO - 2019-07-10 00:39:17 --> Model Class Initialized
INFO - 2019-07-10 00:39:17 --> Helper loaded: form_helper
INFO - 2019-07-10 00:39:17 --> Form Validation Class Initialized
DEBUG - 2019-07-10 00:39:17 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 00:39:17 --> Model Class Initialized
INFO - 2019-07-10 00:39:17 --> Model Class Initialized
INFO - 2019-07-10 00:39:17 --> Final output sent to browser
DEBUG - 2019-07-10 00:39:17 --> Total execution time: 0.6536
INFO - 2019-07-10 00:39:31 --> Helper loaded: language_helper
INFO - 2019-07-10 00:39:31 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:39:31 --> Model Class Initialized
INFO - 2019-07-10 00:39:31 --> Model Class Initialized
INFO - 2019-07-10 00:39:31 --> Model Class Initialized
INFO - 2019-07-10 00:39:31 --> Model Class Initialized
INFO - 2019-07-10 00:39:31 --> Model Class Initialized
INFO - 2019-07-10 00:39:31 --> Final output sent to browser
DEBUG - 2019-07-10 00:39:31 --> Total execution time: 0.5672
INFO - 2019-07-10 00:39:42 --> Helper loaded: language_helper
INFO - 2019-07-10 00:39:42 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:39:42 --> Model Class Initialized
INFO - 2019-07-10 00:39:42 --> Model Class Initialized
INFO - 2019-07-10 00:39:42 --> Model Class Initialized
INFO - 2019-07-10 00:39:42 --> Model Class Initialized
INFO - 2019-07-10 00:39:42 --> Model Class Initialized
INFO - 2019-07-10 00:39:42 --> Final output sent to browser
DEBUG - 2019-07-10 00:39:42 --> Total execution time: 0.5733
INFO - 2019-07-10 00:39:46 --> Helper loaded: language_helper
INFO - 2019-07-10 00:39:46 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:39:46 --> Model Class Initialized
INFO - 2019-07-10 00:39:46 --> Model Class Initialized
INFO - 2019-07-10 00:39:46 --> Model Class Initialized
INFO - 2019-07-10 00:39:46 --> Model Class Initialized
INFO - 2019-07-10 00:39:46 --> Helper loaded: form_helper
INFO - 2019-07-10 00:39:46 --> Form Validation Class Initialized
DEBUG - 2019-07-10 00:39:46 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 00:39:46 --> Model Class Initialized
INFO - 2019-07-10 00:39:46 --> Model Class Initialized
INFO - 2019-07-10 00:39:46 --> Final output sent to browser
DEBUG - 2019-07-10 00:39:46 --> Total execution time: 0.6498
INFO - 2019-07-10 00:41:04 --> Helper loaded: language_helper
INFO - 2019-07-10 00:41:04 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:41:04 --> Model Class Initialized
INFO - 2019-07-10 00:41:04 --> Model Class Initialized
INFO - 2019-07-10 00:41:04 --> Model Class Initialized
INFO - 2019-07-10 00:41:04 --> Model Class Initialized
INFO - 2019-07-10 00:41:04 --> Helper loaded: form_helper
INFO - 2019-07-10 00:41:04 --> Form Validation Class Initialized
DEBUG - 2019-07-10 00:41:04 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 00:41:04 --> Model Class Initialized
INFO - 2019-07-10 00:41:04 --> Model Class Initialized
INFO - 2019-07-10 00:41:04 --> Final output sent to browser
DEBUG - 2019-07-10 00:41:04 --> Total execution time: 0.6383
INFO - 2019-07-10 00:41:06 --> Helper loaded: language_helper
INFO - 2019-07-10 00:41:06 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:41:06 --> Model Class Initialized
INFO - 2019-07-10 00:41:06 --> Model Class Initialized
INFO - 2019-07-10 00:41:06 --> Model Class Initialized
INFO - 2019-07-10 00:41:06 --> Model Class Initialized
INFO - 2019-07-10 00:41:06 --> Helper loaded: form_helper
INFO - 2019-07-10 00:41:06 --> Form Validation Class Initialized
DEBUG - 2019-07-10 00:41:06 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 00:41:06 --> Model Class Initialized
INFO - 2019-07-10 00:41:06 --> Model Class Initialized
INFO - 2019-07-10 00:41:06 --> Final output sent to browser
DEBUG - 2019-07-10 00:41:06 --> Total execution time: 0.6162
INFO - 2019-07-10 00:41:15 --> Helper loaded: language_helper
INFO - 2019-07-10 00:41:15 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:41:15 --> Model Class Initialized
INFO - 2019-07-10 00:41:15 --> Model Class Initialized
INFO - 2019-07-10 00:41:15 --> Model Class Initialized
INFO - 2019-07-10 00:41:15 --> Model Class Initialized
INFO - 2019-07-10 00:41:15 --> Helper loaded: form_helper
INFO - 2019-07-10 00:41:15 --> Form Validation Class Initialized
DEBUG - 2019-07-10 00:41:15 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 00:41:15 --> Model Class Initialized
INFO - 2019-07-10 00:41:15 --> Model Class Initialized
INFO - 2019-07-10 00:41:15 --> Final output sent to browser
DEBUG - 2019-07-10 00:41:15 --> Total execution time: 0.6553
INFO - 2019-07-10 00:41:16 --> Helper loaded: language_helper
INFO - 2019-07-10 00:41:16 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:41:16 --> Model Class Initialized
INFO - 2019-07-10 00:41:16 --> Model Class Initialized
INFO - 2019-07-10 00:41:16 --> Model Class Initialized
INFO - 2019-07-10 00:41:16 --> Model Class Initialized
INFO - 2019-07-10 00:41:16 --> Helper loaded: form_helper
INFO - 2019-07-10 00:41:16 --> Form Validation Class Initialized
DEBUG - 2019-07-10 00:41:16 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 00:41:16 --> Model Class Initialized
INFO - 2019-07-10 00:41:16 --> Model Class Initialized
INFO - 2019-07-10 00:41:16 --> Final output sent to browser
DEBUG - 2019-07-10 00:41:16 --> Total execution time: 0.6071
INFO - 2019-07-10 00:41:18 --> Helper loaded: language_helper
INFO - 2019-07-10 00:41:18 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:41:18 --> Model Class Initialized
INFO - 2019-07-10 00:41:18 --> Model Class Initialized
INFO - 2019-07-10 00:41:18 --> Model Class Initialized
INFO - 2019-07-10 00:41:18 --> Model Class Initialized
INFO - 2019-07-10 00:41:18 --> Helper loaded: form_helper
INFO - 2019-07-10 00:41:18 --> Form Validation Class Initialized
DEBUG - 2019-07-10 00:41:18 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 00:41:18 --> Model Class Initialized
INFO - 2019-07-10 00:41:18 --> Model Class Initialized
INFO - 2019-07-10 00:41:18 --> Final output sent to browser
DEBUG - 2019-07-10 00:41:18 --> Total execution time: 0.6732
INFO - 2019-07-10 00:41:24 --> Helper loaded: language_helper
INFO - 2019-07-10 00:41:24 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:41:24 --> Model Class Initialized
INFO - 2019-07-10 00:41:24 --> Model Class Initialized
INFO - 2019-07-10 00:41:24 --> Model Class Initialized
INFO - 2019-07-10 00:41:24 --> Model Class Initialized
INFO - 2019-07-10 00:41:24 --> Helper loaded: form_helper
INFO - 2019-07-10 00:41:24 --> Form Validation Class Initialized
DEBUG - 2019-07-10 00:41:24 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 00:41:24 --> Model Class Initialized
INFO - 2019-07-10 00:41:24 --> Model Class Initialized
INFO - 2019-07-10 00:41:24 --> Final output sent to browser
DEBUG - 2019-07-10 00:41:24 --> Total execution time: 0.6456
INFO - 2019-07-10 00:41:27 --> Helper loaded: language_helper
INFO - 2019-07-10 00:41:27 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:41:27 --> Model Class Initialized
INFO - 2019-07-10 00:41:27 --> Model Class Initialized
INFO - 2019-07-10 00:41:27 --> Model Class Initialized
INFO - 2019-07-10 00:41:27 --> Model Class Initialized
INFO - 2019-07-10 00:41:27 --> Helper loaded: form_helper
INFO - 2019-07-10 00:41:27 --> Form Validation Class Initialized
DEBUG - 2019-07-10 00:41:27 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 00:41:27 --> Model Class Initialized
INFO - 2019-07-10 00:41:27 --> Model Class Initialized
INFO - 2019-07-10 00:41:27 --> Final output sent to browser
DEBUG - 2019-07-10 00:41:27 --> Total execution time: 0.6432
INFO - 2019-07-10 00:41:43 --> Helper loaded: language_helper
INFO - 2019-07-10 00:41:43 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:41:43 --> Model Class Initialized
INFO - 2019-07-10 00:41:43 --> Model Class Initialized
INFO - 2019-07-10 00:41:43 --> Model Class Initialized
INFO - 2019-07-10 00:41:43 --> Model Class Initialized
INFO - 2019-07-10 00:41:43 --> Helper loaded: form_helper
INFO - 2019-07-10 00:41:43 --> Form Validation Class Initialized
DEBUG - 2019-07-10 00:41:43 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 00:41:43 --> Model Class Initialized
INFO - 2019-07-10 00:41:43 --> Model Class Initialized
INFO - 2019-07-10 00:41:43 --> Final output sent to browser
DEBUG - 2019-07-10 00:41:43 --> Total execution time: 0.6440
INFO - 2019-07-10 00:42:04 --> Helper loaded: language_helper
INFO - 2019-07-10 00:42:04 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:42:04 --> Model Class Initialized
INFO - 2019-07-10 00:42:04 --> Model Class Initialized
INFO - 2019-07-10 00:42:04 --> Model Class Initialized
INFO - 2019-07-10 00:42:04 --> Model Class Initialized
INFO - 2019-07-10 00:42:04 --> Helper loaded: form_helper
INFO - 2019-07-10 00:42:04 --> Form Validation Class Initialized
DEBUG - 2019-07-10 00:42:04 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 00:42:04 --> Model Class Initialized
INFO - 2019-07-10 00:42:04 --> Model Class Initialized
INFO - 2019-07-10 00:42:04 --> Final output sent to browser
DEBUG - 2019-07-10 00:42:04 --> Total execution time: 0.6496
INFO - 2019-07-10 00:42:09 --> Helper loaded: language_helper
INFO - 2019-07-10 00:42:09 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:42:09 --> Model Class Initialized
INFO - 2019-07-10 00:42:09 --> Model Class Initialized
INFO - 2019-07-10 00:42:09 --> Model Class Initialized
INFO - 2019-07-10 00:42:09 --> Model Class Initialized
INFO - 2019-07-10 00:42:09 --> Helper loaded: form_helper
INFO - 2019-07-10 00:42:09 --> Form Validation Class Initialized
DEBUG - 2019-07-10 00:42:09 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 00:42:09 --> Model Class Initialized
INFO - 2019-07-10 00:42:09 --> Model Class Initialized
INFO - 2019-07-10 00:42:09 --> Final output sent to browser
DEBUG - 2019-07-10 00:42:09 --> Total execution time: 0.6213
INFO - 2019-07-10 00:42:10 --> Helper loaded: language_helper
INFO - 2019-07-10 00:42:10 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:42:10 --> Model Class Initialized
INFO - 2019-07-10 00:42:11 --> Model Class Initialized
INFO - 2019-07-10 00:42:11 --> Model Class Initialized
INFO - 2019-07-10 00:42:11 --> Model Class Initialized
INFO - 2019-07-10 00:42:11 --> Helper loaded: form_helper
INFO - 2019-07-10 00:42:11 --> Form Validation Class Initialized
DEBUG - 2019-07-10 00:42:11 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 00:42:11 --> Model Class Initialized
INFO - 2019-07-10 00:42:11 --> Model Class Initialized
INFO - 2019-07-10 00:42:11 --> Final output sent to browser
DEBUG - 2019-07-10 00:42:11 --> Total execution time: 0.6160
INFO - 2019-07-10 00:42:11 --> Helper loaded: language_helper
INFO - 2019-07-10 00:42:11 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:42:11 --> Model Class Initialized
INFO - 2019-07-10 00:42:11 --> Model Class Initialized
INFO - 2019-07-10 00:42:11 --> Model Class Initialized
INFO - 2019-07-10 00:42:11 --> Model Class Initialized
INFO - 2019-07-10 00:42:11 --> Helper loaded: form_helper
INFO - 2019-07-10 00:42:11 --> Form Validation Class Initialized
DEBUG - 2019-07-10 00:42:11 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 00:42:11 --> Model Class Initialized
INFO - 2019-07-10 00:42:11 --> Model Class Initialized
INFO - 2019-07-10 00:42:11 --> Final output sent to browser
DEBUG - 2019-07-10 00:42:11 --> Total execution time: 0.6499
INFO - 2019-07-10 00:42:38 --> Helper loaded: language_helper
INFO - 2019-07-10 00:42:38 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:42:38 --> Model Class Initialized
INFO - 2019-07-10 00:42:38 --> Model Class Initialized
INFO - 2019-07-10 00:42:38 --> Model Class Initialized
INFO - 2019-07-10 00:42:38 --> Model Class Initialized
INFO - 2019-07-10 00:42:38 --> Helper loaded: form_helper
INFO - 2019-07-10 00:42:38 --> Form Validation Class Initialized
DEBUG - 2019-07-10 00:42:38 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 00:42:38 --> Model Class Initialized
INFO - 2019-07-10 00:42:38 --> Model Class Initialized
INFO - 2019-07-10 00:42:38 --> Final output sent to browser
DEBUG - 2019-07-10 00:42:38 --> Total execution time: 0.6243
INFO - 2019-07-10 00:42:39 --> Helper loaded: language_helper
INFO - 2019-07-10 00:42:39 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:42:39 --> Model Class Initialized
INFO - 2019-07-10 00:42:39 --> Model Class Initialized
INFO - 2019-07-10 00:42:39 --> Model Class Initialized
INFO - 2019-07-10 00:42:39 --> Model Class Initialized
INFO - 2019-07-10 00:42:39 --> Helper loaded: form_helper
INFO - 2019-07-10 00:42:39 --> Form Validation Class Initialized
DEBUG - 2019-07-10 00:42:39 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 00:42:39 --> Model Class Initialized
INFO - 2019-07-10 00:42:39 --> Model Class Initialized
INFO - 2019-07-10 00:42:39 --> Final output sent to browser
DEBUG - 2019-07-10 00:42:39 --> Total execution time: 0.6355
INFO - 2019-07-10 00:42:41 --> Helper loaded: language_helper
INFO - 2019-07-10 00:42:41 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:42:41 --> Model Class Initialized
INFO - 2019-07-10 00:42:41 --> Model Class Initialized
INFO - 2019-07-10 00:42:41 --> Model Class Initialized
INFO - 2019-07-10 00:42:41 --> Model Class Initialized
INFO - 2019-07-10 00:42:41 --> Helper loaded: form_helper
INFO - 2019-07-10 00:42:41 --> Form Validation Class Initialized
DEBUG - 2019-07-10 00:42:41 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 00:42:41 --> Model Class Initialized
INFO - 2019-07-10 00:42:41 --> Model Class Initialized
INFO - 2019-07-10 00:42:41 --> Final output sent to browser
DEBUG - 2019-07-10 00:42:41 --> Total execution time: 0.6367
INFO - 2019-07-10 00:42:43 --> Helper loaded: language_helper
INFO - 2019-07-10 00:42:43 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:42:43 --> Model Class Initialized
INFO - 2019-07-10 00:42:43 --> Model Class Initialized
INFO - 2019-07-10 00:42:43 --> Model Class Initialized
INFO - 2019-07-10 00:42:43 --> Model Class Initialized
INFO - 2019-07-10 00:42:43 --> Helper loaded: form_helper
INFO - 2019-07-10 00:42:43 --> Form Validation Class Initialized
DEBUG - 2019-07-10 00:42:43 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 00:42:43 --> Model Class Initialized
INFO - 2019-07-10 00:42:43 --> Model Class Initialized
INFO - 2019-07-10 00:42:43 --> Final output sent to browser
DEBUG - 2019-07-10 00:42:43 --> Total execution time: 0.6211
INFO - 2019-07-10 00:42:45 --> Helper loaded: language_helper
INFO - 2019-07-10 00:42:45 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:42:45 --> Model Class Initialized
INFO - 2019-07-10 00:42:45 --> Model Class Initialized
INFO - 2019-07-10 00:42:45 --> Model Class Initialized
INFO - 2019-07-10 00:42:45 --> Model Class Initialized
INFO - 2019-07-10 00:42:45 --> Helper loaded: form_helper
INFO - 2019-07-10 00:42:45 --> Form Validation Class Initialized
DEBUG - 2019-07-10 00:42:45 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 00:42:45 --> Model Class Initialized
INFO - 2019-07-10 00:42:45 --> Model Class Initialized
INFO - 2019-07-10 00:42:45 --> Final output sent to browser
DEBUG - 2019-07-10 00:42:45 --> Total execution time: 0.6740
INFO - 2019-07-10 00:43:42 --> Helper loaded: language_helper
INFO - 2019-07-10 00:43:42 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:43:42 --> Model Class Initialized
INFO - 2019-07-10 00:43:42 --> Model Class Initialized
INFO - 2019-07-10 00:43:42 --> Model Class Initialized
INFO - 2019-07-10 00:43:42 --> Model Class Initialized
INFO - 2019-07-10 00:43:42 --> Helper loaded: form_helper
INFO - 2019-07-10 00:43:42 --> Form Validation Class Initialized
DEBUG - 2019-07-10 00:43:42 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 00:43:42 --> Model Class Initialized
INFO - 2019-07-10 00:43:42 --> Model Class Initialized
INFO - 2019-07-10 00:43:42 --> Final output sent to browser
DEBUG - 2019-07-10 00:43:42 --> Total execution time: 0.6444
INFO - 2019-07-10 00:43:47 --> Helper loaded: language_helper
INFO - 2019-07-10 00:43:47 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:43:47 --> Model Class Initialized
INFO - 2019-07-10 00:43:47 --> Model Class Initialized
INFO - 2019-07-10 00:43:47 --> Model Class Initialized
INFO - 2019-07-10 00:43:47 --> Model Class Initialized
INFO - 2019-07-10 00:43:47 --> Helper loaded: form_helper
INFO - 2019-07-10 00:43:47 --> Form Validation Class Initialized
DEBUG - 2019-07-10 00:43:47 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 00:43:48 --> Model Class Initialized
INFO - 2019-07-10 00:43:48 --> Model Class Initialized
INFO - 2019-07-10 00:43:48 --> Final output sent to browser
DEBUG - 2019-07-10 00:43:48 --> Total execution time: 0.6140
INFO - 2019-07-10 00:45:11 --> Helper loaded: language_helper
INFO - 2019-07-10 00:45:11 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:45:11 --> Model Class Initialized
INFO - 2019-07-10 00:45:11 --> Model Class Initialized
INFO - 2019-07-10 00:45:11 --> Model Class Initialized
INFO - 2019-07-10 00:45:11 --> Model Class Initialized
INFO - 2019-07-10 00:45:11 --> Helper loaded: form_helper
INFO - 2019-07-10 00:45:12 --> Form Validation Class Initialized
DEBUG - 2019-07-10 00:45:12 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 00:45:12 --> Model Class Initialized
INFO - 2019-07-10 00:45:12 --> Model Class Initialized
INFO - 2019-07-10 00:45:12 --> Final output sent to browser
DEBUG - 2019-07-10 00:45:12 --> Total execution time: 0.6542
INFO - 2019-07-10 00:45:16 --> Helper loaded: language_helper
INFO - 2019-07-10 00:45:16 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:45:16 --> Model Class Initialized
INFO - 2019-07-10 00:45:16 --> Model Class Initialized
INFO - 2019-07-10 00:45:16 --> Model Class Initialized
INFO - 2019-07-10 00:45:16 --> Model Class Initialized
INFO - 2019-07-10 00:45:16 --> Model Class Initialized
INFO - 2019-07-10 00:45:16 --> Final output sent to browser
DEBUG - 2019-07-10 00:45:16 --> Total execution time: 0.6186
INFO - 2019-07-10 00:45:19 --> Helper loaded: language_helper
INFO - 2019-07-10 00:45:19 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:45:19 --> Model Class Initialized
INFO - 2019-07-10 00:45:19 --> Model Class Initialized
INFO - 2019-07-10 00:45:19 --> Model Class Initialized
INFO - 2019-07-10 00:45:19 --> Model Class Initialized
INFO - 2019-07-10 00:45:19 --> Model Class Initialized
INFO - 2019-07-10 00:45:19 --> Final output sent to browser
DEBUG - 2019-07-10 00:45:19 --> Total execution time: 0.7317
INFO - 2019-07-10 00:45:24 --> Helper loaded: language_helper
INFO - 2019-07-10 00:45:24 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:45:24 --> Model Class Initialized
INFO - 2019-07-10 00:45:24 --> Model Class Initialized
INFO - 2019-07-10 00:45:24 --> Model Class Initialized
INFO - 2019-07-10 00:45:24 --> Model Class Initialized
INFO - 2019-07-10 00:45:24 --> Model Class Initialized
INFO - 2019-07-10 00:45:24 --> Final output sent to browser
DEBUG - 2019-07-10 00:45:24 --> Total execution time: 0.8708
INFO - 2019-07-10 00:45:24 --> Helper loaded: language_helper
INFO - 2019-07-10 00:45:24 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:45:24 --> Model Class Initialized
INFO - 2019-07-10 00:45:24 --> Model Class Initialized
INFO - 2019-07-10 00:45:24 --> Model Class Initialized
INFO - 2019-07-10 00:45:24 --> Model Class Initialized
INFO - 2019-07-10 00:45:24 --> Helper loaded: form_helper
INFO - 2019-07-10 00:45:24 --> Form Validation Class Initialized
DEBUG - 2019-07-10 00:45:24 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 00:45:24 --> Model Class Initialized
INFO - 2019-07-10 00:45:24 --> Model Class Initialized
INFO - 2019-07-10 00:45:24 --> Final output sent to browser
DEBUG - 2019-07-10 00:45:24 --> Total execution time: 1.1432
INFO - 2019-07-10 00:45:34 --> Helper loaded: language_helper
INFO - 2019-07-10 00:45:34 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:45:34 --> Model Class Initialized
INFO - 2019-07-10 00:45:34 --> Model Class Initialized
INFO - 2019-07-10 00:45:34 --> Model Class Initialized
INFO - 2019-07-10 00:45:34 --> Model Class Initialized
INFO - 2019-07-10 00:45:34 --> Model Class Initialized
INFO - 2019-07-10 00:45:36 --> Final output sent to browser
DEBUG - 2019-07-10 00:45:36 --> Total execution time: 2.2713
INFO - 2019-07-10 00:46:47 --> Helper loaded: language_helper
INFO - 2019-07-10 00:46:47 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:46:47 --> Model Class Initialized
INFO - 2019-07-10 00:46:47 --> Model Class Initialized
INFO - 2019-07-10 00:46:47 --> Model Class Initialized
INFO - 2019-07-10 00:46:47 --> Model Class Initialized
INFO - 2019-07-10 00:46:47 --> Helper loaded: form_helper
INFO - 2019-07-10 00:46:47 --> Form Validation Class Initialized
DEBUG - 2019-07-10 00:46:47 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 00:46:47 --> Model Class Initialized
INFO - 2019-07-10 00:46:47 --> Model Class Initialized
INFO - 2019-07-10 00:46:47 --> Final output sent to browser
DEBUG - 2019-07-10 00:46:47 --> Total execution time: 0.6610
INFO - 2019-07-10 00:46:50 --> Helper loaded: language_helper
INFO - 2019-07-10 00:46:50 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:46:50 --> Model Class Initialized
INFO - 2019-07-10 00:46:50 --> Model Class Initialized
INFO - 2019-07-10 00:46:50 --> Model Class Initialized
INFO - 2019-07-10 00:46:50 --> Model Class Initialized
INFO - 2019-07-10 00:46:50 --> Helper loaded: form_helper
INFO - 2019-07-10 00:46:50 --> Form Validation Class Initialized
DEBUG - 2019-07-10 00:46:50 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 00:46:50 --> Model Class Initialized
INFO - 2019-07-10 00:46:50 --> Model Class Initialized
INFO - 2019-07-10 00:46:50 --> Final output sent to browser
DEBUG - 2019-07-10 00:46:50 --> Total execution time: 0.6478
INFO - 2019-07-10 00:46:53 --> Helper loaded: language_helper
INFO - 2019-07-10 00:46:53 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:46:53 --> Model Class Initialized
INFO - 2019-07-10 00:46:53 --> Model Class Initialized
INFO - 2019-07-10 00:46:53 --> Model Class Initialized
INFO - 2019-07-10 00:46:53 --> Model Class Initialized
INFO - 2019-07-10 00:46:53 --> Helper loaded: form_helper
INFO - 2019-07-10 00:46:53 --> Form Validation Class Initialized
DEBUG - 2019-07-10 00:46:53 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 00:46:53 --> Model Class Initialized
INFO - 2019-07-10 00:46:53 --> Model Class Initialized
INFO - 2019-07-10 00:46:53 --> Final output sent to browser
DEBUG - 2019-07-10 00:46:53 --> Total execution time: 0.6432
INFO - 2019-07-10 00:46:56 --> Helper loaded: language_helper
INFO - 2019-07-10 00:46:56 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:46:56 --> Model Class Initialized
INFO - 2019-07-10 00:46:56 --> Model Class Initialized
INFO - 2019-07-10 00:46:56 --> Model Class Initialized
INFO - 2019-07-10 00:46:56 --> Model Class Initialized
INFO - 2019-07-10 00:46:56 --> Helper loaded: form_helper
INFO - 2019-07-10 00:46:56 --> Form Validation Class Initialized
DEBUG - 2019-07-10 00:46:56 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 00:46:56 --> Model Class Initialized
INFO - 2019-07-10 00:46:56 --> Model Class Initialized
INFO - 2019-07-10 00:46:56 --> Final output sent to browser
DEBUG - 2019-07-10 00:46:56 --> Total execution time: 0.6455
INFO - 2019-07-10 00:46:57 --> Helper loaded: language_helper
INFO - 2019-07-10 00:46:58 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:46:58 --> Model Class Initialized
INFO - 2019-07-10 00:46:58 --> Model Class Initialized
INFO - 2019-07-10 00:46:58 --> Model Class Initialized
INFO - 2019-07-10 00:46:58 --> Model Class Initialized
INFO - 2019-07-10 00:46:58 --> Helper loaded: form_helper
INFO - 2019-07-10 00:46:58 --> Form Validation Class Initialized
DEBUG - 2019-07-10 00:46:58 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 00:46:58 --> Model Class Initialized
INFO - 2019-07-10 00:46:58 --> Model Class Initialized
INFO - 2019-07-10 00:46:58 --> Final output sent to browser
DEBUG - 2019-07-10 00:46:58 --> Total execution time: 0.6487
INFO - 2019-07-10 00:47:01 --> Helper loaded: language_helper
INFO - 2019-07-10 00:47:01 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:47:01 --> Model Class Initialized
INFO - 2019-07-10 00:47:01 --> Model Class Initialized
INFO - 2019-07-10 00:47:01 --> Model Class Initialized
INFO - 2019-07-10 00:47:01 --> Model Class Initialized
INFO - 2019-07-10 00:47:01 --> Helper loaded: form_helper
INFO - 2019-07-10 00:47:01 --> Form Validation Class Initialized
DEBUG - 2019-07-10 00:47:01 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 00:47:01 --> Model Class Initialized
INFO - 2019-07-10 00:47:01 --> Model Class Initialized
INFO - 2019-07-10 00:47:01 --> Final output sent to browser
DEBUG - 2019-07-10 00:47:01 --> Total execution time: 0.6654
INFO - 2019-07-10 00:47:08 --> Helper loaded: language_helper
INFO - 2019-07-10 00:47:08 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:47:08 --> Model Class Initialized
INFO - 2019-07-10 00:47:08 --> Model Class Initialized
INFO - 2019-07-10 00:47:08 --> Model Class Initialized
INFO - 2019-07-10 00:47:08 --> Model Class Initialized
INFO - 2019-07-10 00:47:08 --> Helper loaded: form_helper
INFO - 2019-07-10 00:47:08 --> Form Validation Class Initialized
DEBUG - 2019-07-10 00:47:08 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 00:47:08 --> Model Class Initialized
INFO - 2019-07-10 00:47:08 --> Model Class Initialized
INFO - 2019-07-10 00:47:08 --> Final output sent to browser
DEBUG - 2019-07-10 00:47:08 --> Total execution time: 0.6467
INFO - 2019-07-10 00:48:14 --> Helper loaded: language_helper
INFO - 2019-07-10 00:48:14 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:48:14 --> Model Class Initialized
INFO - 2019-07-10 00:48:14 --> Model Class Initialized
INFO - 2019-07-10 00:48:15 --> Model Class Initialized
INFO - 2019-07-10 00:48:15 --> Model Class Initialized
INFO - 2019-07-10 00:48:15 --> Helper loaded: form_helper
INFO - 2019-07-10 00:48:15 --> Form Validation Class Initialized
DEBUG - 2019-07-10 00:48:15 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 00:48:15 --> Model Class Initialized
INFO - 2019-07-10 00:48:15 --> Model Class Initialized
INFO - 2019-07-10 00:48:15 --> Final output sent to browser
DEBUG - 2019-07-10 00:48:15 --> Total execution time: 0.6486
INFO - 2019-07-10 00:48:16 --> Helper loaded: language_helper
INFO - 2019-07-10 00:48:16 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:48:16 --> Model Class Initialized
INFO - 2019-07-10 00:48:16 --> Model Class Initialized
INFO - 2019-07-10 00:48:16 --> Model Class Initialized
INFO - 2019-07-10 00:48:16 --> Model Class Initialized
INFO - 2019-07-10 00:48:16 --> Helper loaded: form_helper
INFO - 2019-07-10 00:48:16 --> Form Validation Class Initialized
DEBUG - 2019-07-10 00:48:16 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 00:48:16 --> Model Class Initialized
INFO - 2019-07-10 00:48:16 --> Model Class Initialized
INFO - 2019-07-10 00:48:16 --> Final output sent to browser
DEBUG - 2019-07-10 00:48:16 --> Total execution time: 0.6574
INFO - 2019-07-10 00:48:17 --> Helper loaded: language_helper
INFO - 2019-07-10 00:48:17 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:48:17 --> Model Class Initialized
INFO - 2019-07-10 00:48:17 --> Model Class Initialized
INFO - 2019-07-10 00:48:17 --> Model Class Initialized
INFO - 2019-07-10 00:48:17 --> Model Class Initialized
INFO - 2019-07-10 00:48:17 --> Helper loaded: form_helper
INFO - 2019-07-10 00:48:17 --> Form Validation Class Initialized
DEBUG - 2019-07-10 00:48:18 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 00:48:18 --> Model Class Initialized
INFO - 2019-07-10 00:48:18 --> Model Class Initialized
INFO - 2019-07-10 00:48:18 --> Final output sent to browser
DEBUG - 2019-07-10 00:48:18 --> Total execution time: 0.6693
INFO - 2019-07-10 00:48:19 --> Helper loaded: language_helper
INFO - 2019-07-10 00:48:19 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:48:19 --> Model Class Initialized
INFO - 2019-07-10 00:48:19 --> Model Class Initialized
INFO - 2019-07-10 00:48:19 --> Model Class Initialized
INFO - 2019-07-10 00:48:19 --> Model Class Initialized
INFO - 2019-07-10 00:48:19 --> Helper loaded: form_helper
INFO - 2019-07-10 00:48:19 --> Form Validation Class Initialized
DEBUG - 2019-07-10 00:48:19 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 00:48:19 --> Model Class Initialized
INFO - 2019-07-10 00:48:19 --> Model Class Initialized
INFO - 2019-07-10 00:48:19 --> Final output sent to browser
DEBUG - 2019-07-10 00:48:19 --> Total execution time: 0.6643
INFO - 2019-07-10 00:48:25 --> Helper loaded: language_helper
INFO - 2019-07-10 00:48:25 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:48:25 --> Model Class Initialized
INFO - 2019-07-10 00:48:25 --> Model Class Initialized
INFO - 2019-07-10 00:48:25 --> Model Class Initialized
INFO - 2019-07-10 00:48:25 --> Model Class Initialized
INFO - 2019-07-10 00:48:25 --> Helper loaded: form_helper
INFO - 2019-07-10 00:48:25 --> Form Validation Class Initialized
DEBUG - 2019-07-10 00:48:25 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 00:48:25 --> Model Class Initialized
INFO - 2019-07-10 00:48:25 --> Model Class Initialized
INFO - 2019-07-10 00:48:25 --> Final output sent to browser
DEBUG - 2019-07-10 00:48:25 --> Total execution time: 0.6753
INFO - 2019-07-10 00:49:03 --> Helper loaded: language_helper
INFO - 2019-07-10 00:49:03 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:49:03 --> Model Class Initialized
INFO - 2019-07-10 00:49:03 --> Model Class Initialized
INFO - 2019-07-10 00:49:03 --> Model Class Initialized
INFO - 2019-07-10 00:49:03 --> Model Class Initialized
INFO - 2019-07-10 00:49:03 --> Helper loaded: form_helper
INFO - 2019-07-10 00:49:03 --> Form Validation Class Initialized
DEBUG - 2019-07-10 00:49:03 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 00:49:03 --> Model Class Initialized
INFO - 2019-07-10 00:49:03 --> Model Class Initialized
INFO - 2019-07-10 00:49:03 --> Final output sent to browser
DEBUG - 2019-07-10 00:49:03 --> Total execution time: 0.6610
INFO - 2019-07-10 00:58:37 --> Helper loaded: language_helper
INFO - 2019-07-10 00:58:37 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:58:37 --> Model Class Initialized
INFO - 2019-07-10 00:58:37 --> Model Class Initialized
INFO - 2019-07-10 00:58:37 --> Model Class Initialized
INFO - 2019-07-10 00:58:37 --> Model Class Initialized
INFO - 2019-07-10 00:58:37 --> Helper loaded: form_helper
INFO - 2019-07-10 00:58:37 --> Form Validation Class Initialized
DEBUG - 2019-07-10 00:58:37 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 00:58:37 --> Model Class Initialized
INFO - 2019-07-10 00:58:37 --> Model Class Initialized
INFO - 2019-07-10 00:58:37 --> Final output sent to browser
DEBUG - 2019-07-10 00:58:37 --> Total execution time: 0.6504
INFO - 2019-07-10 00:59:48 --> Helper loaded: language_helper
INFO - 2019-07-10 00:59:48 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:59:48 --> Model Class Initialized
INFO - 2019-07-10 00:59:48 --> Model Class Initialized
INFO - 2019-07-10 00:59:48 --> Model Class Initialized
INFO - 2019-07-10 00:59:48 --> Model Class Initialized
INFO - 2019-07-10 00:59:48 --> Helper loaded: form_helper
INFO - 2019-07-10 00:59:48 --> Form Validation Class Initialized
DEBUG - 2019-07-10 00:59:48 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 00:59:48 --> Model Class Initialized
INFO - 2019-07-10 00:59:48 --> Model Class Initialized
INFO - 2019-07-10 00:59:48 --> Final output sent to browser
DEBUG - 2019-07-10 00:59:48 --> Total execution time: 0.6704
INFO - 2019-07-10 00:59:52 --> Helper loaded: language_helper
INFO - 2019-07-10 00:59:52 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 00:59:52 --> Model Class Initialized
INFO - 2019-07-10 00:59:52 --> Model Class Initialized
INFO - 2019-07-10 00:59:52 --> Model Class Initialized
INFO - 2019-07-10 00:59:52 --> Model Class Initialized
INFO - 2019-07-10 00:59:52 --> Helper loaded: form_helper
INFO - 2019-07-10 00:59:52 --> Form Validation Class Initialized
DEBUG - 2019-07-10 00:59:52 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 00:59:52 --> Model Class Initialized
INFO - 2019-07-10 00:59:52 --> Model Class Initialized
INFO - 2019-07-10 00:59:52 --> Final output sent to browser
DEBUG - 2019-07-10 00:59:52 --> Total execution time: 0.6394
INFO - 2019-07-10 01:00:14 --> Helper loaded: language_helper
INFO - 2019-07-10 01:00:14 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:00:14 --> Model Class Initialized
INFO - 2019-07-10 01:00:14 --> Model Class Initialized
INFO - 2019-07-10 01:00:14 --> Model Class Initialized
INFO - 2019-07-10 01:00:14 --> Model Class Initialized
INFO - 2019-07-10 01:00:14 --> Helper loaded: form_helper
INFO - 2019-07-10 01:00:14 --> Form Validation Class Initialized
DEBUG - 2019-07-10 01:00:14 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 01:00:14 --> Model Class Initialized
INFO - 2019-07-10 01:00:14 --> Model Class Initialized
INFO - 2019-07-10 01:00:14 --> Final output sent to browser
DEBUG - 2019-07-10 01:00:14 --> Total execution time: 0.6509
INFO - 2019-07-10 01:00:22 --> Helper loaded: language_helper
INFO - 2019-07-10 01:00:22 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:00:22 --> Model Class Initialized
INFO - 2019-07-10 01:00:23 --> Model Class Initialized
INFO - 2019-07-10 01:00:23 --> Model Class Initialized
INFO - 2019-07-10 01:00:23 --> Model Class Initialized
INFO - 2019-07-10 01:00:23 --> Helper loaded: form_helper
INFO - 2019-07-10 01:00:23 --> Form Validation Class Initialized
DEBUG - 2019-07-10 01:00:23 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 01:00:23 --> Model Class Initialized
INFO - 2019-07-10 01:00:23 --> Model Class Initialized
INFO - 2019-07-10 01:00:23 --> Final output sent to browser
DEBUG - 2019-07-10 01:00:23 --> Total execution time: 0.6445
INFO - 2019-07-10 01:00:45 --> Helper loaded: language_helper
INFO - 2019-07-10 01:00:45 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:00:45 --> Model Class Initialized
INFO - 2019-07-10 01:00:45 --> Model Class Initialized
INFO - 2019-07-10 01:00:45 --> Model Class Initialized
INFO - 2019-07-10 01:00:45 --> Model Class Initialized
INFO - 2019-07-10 01:00:45 --> Helper loaded: form_helper
INFO - 2019-07-10 01:00:45 --> Form Validation Class Initialized
DEBUG - 2019-07-10 01:00:45 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 01:00:45 --> Model Class Initialized
INFO - 2019-07-10 01:00:45 --> Model Class Initialized
INFO - 2019-07-10 01:00:45 --> Final output sent to browser
DEBUG - 2019-07-10 01:00:45 --> Total execution time: 0.8177
INFO - 2019-07-10 01:00:46 --> Helper loaded: language_helper
INFO - 2019-07-10 01:00:46 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:00:46 --> Model Class Initialized
INFO - 2019-07-10 01:00:46 --> Model Class Initialized
INFO - 2019-07-10 01:00:46 --> Model Class Initialized
INFO - 2019-07-10 01:00:46 --> Model Class Initialized
INFO - 2019-07-10 01:00:46 --> Helper loaded: form_helper
INFO - 2019-07-10 01:00:46 --> Form Validation Class Initialized
DEBUG - 2019-07-10 01:00:46 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 01:00:46 --> Model Class Initialized
INFO - 2019-07-10 01:00:46 --> Model Class Initialized
INFO - 2019-07-10 01:00:46 --> Final output sent to browser
DEBUG - 2019-07-10 01:00:46 --> Total execution time: 0.6794
INFO - 2019-07-10 01:00:47 --> Helper loaded: language_helper
INFO - 2019-07-10 01:00:47 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:00:47 --> Model Class Initialized
INFO - 2019-07-10 01:00:47 --> Model Class Initialized
INFO - 2019-07-10 01:00:47 --> Model Class Initialized
INFO - 2019-07-10 01:00:47 --> Model Class Initialized
INFO - 2019-07-10 01:00:47 --> Helper loaded: form_helper
INFO - 2019-07-10 01:00:47 --> Form Validation Class Initialized
DEBUG - 2019-07-10 01:00:47 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 01:00:47 --> Model Class Initialized
INFO - 2019-07-10 01:00:47 --> Model Class Initialized
INFO - 2019-07-10 01:00:47 --> Final output sent to browser
DEBUG - 2019-07-10 01:00:47 --> Total execution time: 0.6607
INFO - 2019-07-10 01:00:51 --> Helper loaded: language_helper
INFO - 2019-07-10 01:00:51 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:00:51 --> Model Class Initialized
INFO - 2019-07-10 01:00:51 --> Model Class Initialized
INFO - 2019-07-10 01:00:51 --> Model Class Initialized
INFO - 2019-07-10 01:00:51 --> Model Class Initialized
INFO - 2019-07-10 01:00:51 --> Helper loaded: form_helper
INFO - 2019-07-10 01:00:51 --> Form Validation Class Initialized
DEBUG - 2019-07-10 01:00:51 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 01:00:51 --> Model Class Initialized
INFO - 2019-07-10 01:00:51 --> Model Class Initialized
INFO - 2019-07-10 01:00:51 --> Final output sent to browser
DEBUG - 2019-07-10 01:00:51 --> Total execution time: 0.6647
INFO - 2019-07-10 01:00:52 --> Helper loaded: language_helper
INFO - 2019-07-10 01:00:52 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:00:52 --> Model Class Initialized
INFO - 2019-07-10 01:00:52 --> Model Class Initialized
INFO - 2019-07-10 01:00:52 --> Model Class Initialized
INFO - 2019-07-10 01:00:52 --> Model Class Initialized
INFO - 2019-07-10 01:00:52 --> Model Class Initialized
INFO - 2019-07-10 01:00:52 --> Final output sent to browser
DEBUG - 2019-07-10 01:00:52 --> Total execution time: 0.6059
INFO - 2019-07-10 01:02:39 --> Helper loaded: language_helper
INFO - 2019-07-10 01:02:39 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:02:39 --> Model Class Initialized
INFO - 2019-07-10 01:02:39 --> Model Class Initialized
INFO - 2019-07-10 01:02:39 --> Model Class Initialized
INFO - 2019-07-10 01:02:39 --> Model Class Initialized
INFO - 2019-07-10 01:02:39 --> Helper loaded: form_helper
INFO - 2019-07-10 01:02:39 --> Form Validation Class Initialized
DEBUG - 2019-07-10 01:02:39 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 01:02:39 --> Model Class Initialized
INFO - 2019-07-10 01:02:39 --> Model Class Initialized
INFO - 2019-07-10 01:02:39 --> Final output sent to browser
DEBUG - 2019-07-10 01:02:39 --> Total execution time: 0.6661
INFO - 2019-07-10 01:02:42 --> Helper loaded: language_helper
INFO - 2019-07-10 01:02:42 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:02:42 --> Model Class Initialized
INFO - 2019-07-10 01:02:42 --> Model Class Initialized
INFO - 2019-07-10 01:02:42 --> Model Class Initialized
INFO - 2019-07-10 01:02:42 --> Model Class Initialized
INFO - 2019-07-10 01:02:42 --> Helper loaded: form_helper
INFO - 2019-07-10 01:02:42 --> Form Validation Class Initialized
DEBUG - 2019-07-10 01:02:42 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 01:02:42 --> Model Class Initialized
INFO - 2019-07-10 01:02:42 --> Model Class Initialized
INFO - 2019-07-10 01:02:42 --> Final output sent to browser
DEBUG - 2019-07-10 01:02:42 --> Total execution time: 0.6559
INFO - 2019-07-10 01:02:48 --> Helper loaded: language_helper
INFO - 2019-07-10 01:02:48 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:02:48 --> Model Class Initialized
INFO - 2019-07-10 01:02:48 --> Model Class Initialized
INFO - 2019-07-10 01:02:48 --> Model Class Initialized
INFO - 2019-07-10 01:02:48 --> Model Class Initialized
INFO - 2019-07-10 01:02:48 --> Helper loaded: form_helper
INFO - 2019-07-10 01:02:48 --> Form Validation Class Initialized
DEBUG - 2019-07-10 01:02:48 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 01:02:48 --> Model Class Initialized
INFO - 2019-07-10 01:02:48 --> Model Class Initialized
INFO - 2019-07-10 01:02:48 --> Final output sent to browser
DEBUG - 2019-07-10 01:02:48 --> Total execution time: 0.6758
INFO - 2019-07-10 01:02:52 --> Helper loaded: language_helper
INFO - 2019-07-10 01:02:52 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:02:52 --> Model Class Initialized
INFO - 2019-07-10 01:02:52 --> Model Class Initialized
INFO - 2019-07-10 01:02:52 --> Model Class Initialized
INFO - 2019-07-10 01:02:52 --> Model Class Initialized
INFO - 2019-07-10 01:02:52 --> Helper loaded: form_helper
INFO - 2019-07-10 01:02:52 --> Form Validation Class Initialized
DEBUG - 2019-07-10 01:02:52 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 01:02:52 --> Model Class Initialized
INFO - 2019-07-10 01:02:52 --> Model Class Initialized
INFO - 2019-07-10 01:02:52 --> Final output sent to browser
DEBUG - 2019-07-10 01:02:52 --> Total execution time: 0.6853
INFO - 2019-07-10 01:02:55 --> Helper loaded: language_helper
INFO - 2019-07-10 01:02:55 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:02:55 --> Model Class Initialized
INFO - 2019-07-10 01:02:55 --> Model Class Initialized
INFO - 2019-07-10 01:02:55 --> Model Class Initialized
INFO - 2019-07-10 01:02:55 --> Model Class Initialized
INFO - 2019-07-10 01:02:55 --> Helper loaded: form_helper
INFO - 2019-07-10 01:02:55 --> Form Validation Class Initialized
DEBUG - 2019-07-10 01:02:55 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 01:02:55 --> Model Class Initialized
INFO - 2019-07-10 01:02:55 --> Model Class Initialized
INFO - 2019-07-10 01:02:55 --> Final output sent to browser
DEBUG - 2019-07-10 01:02:55 --> Total execution time: 0.6785
INFO - 2019-07-10 01:02:58 --> Helper loaded: language_helper
INFO - 2019-07-10 01:02:58 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:02:58 --> Model Class Initialized
INFO - 2019-07-10 01:02:58 --> Model Class Initialized
INFO - 2019-07-10 01:02:58 --> Model Class Initialized
INFO - 2019-07-10 01:02:58 --> Model Class Initialized
INFO - 2019-07-10 01:02:58 --> Helper loaded: form_helper
INFO - 2019-07-10 01:02:58 --> Form Validation Class Initialized
DEBUG - 2019-07-10 01:02:58 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 01:02:58 --> Model Class Initialized
INFO - 2019-07-10 01:02:58 --> Model Class Initialized
INFO - 2019-07-10 01:02:58 --> Final output sent to browser
DEBUG - 2019-07-10 01:02:58 --> Total execution time: 0.6698
INFO - 2019-07-10 01:03:24 --> Helper loaded: language_helper
INFO - 2019-07-10 01:03:24 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:03:24 --> Model Class Initialized
INFO - 2019-07-10 01:03:24 --> Model Class Initialized
INFO - 2019-07-10 01:03:24 --> Model Class Initialized
INFO - 2019-07-10 01:03:24 --> Model Class Initialized
INFO - 2019-07-10 01:03:24 --> Helper loaded: form_helper
INFO - 2019-07-10 01:03:24 --> Form Validation Class Initialized
DEBUG - 2019-07-10 01:03:24 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 01:03:24 --> Model Class Initialized
INFO - 2019-07-10 01:03:24 --> Model Class Initialized
INFO - 2019-07-10 01:03:24 --> Final output sent to browser
DEBUG - 2019-07-10 01:03:24 --> Total execution time: 0.6516
INFO - 2019-07-10 01:03:26 --> Helper loaded: language_helper
INFO - 2019-07-10 01:03:26 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:03:26 --> Model Class Initialized
INFO - 2019-07-10 01:03:26 --> Model Class Initialized
INFO - 2019-07-10 01:03:26 --> Model Class Initialized
INFO - 2019-07-10 01:03:26 --> Model Class Initialized
INFO - 2019-07-10 01:03:26 --> Helper loaded: form_helper
INFO - 2019-07-10 01:03:26 --> Form Validation Class Initialized
DEBUG - 2019-07-10 01:03:26 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 01:03:26 --> Model Class Initialized
INFO - 2019-07-10 01:03:26 --> Model Class Initialized
INFO - 2019-07-10 01:03:26 --> Final output sent to browser
DEBUG - 2019-07-10 01:03:26 --> Total execution time: 0.6830
INFO - 2019-07-10 01:03:27 --> Helper loaded: language_helper
INFO - 2019-07-10 01:03:27 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:03:27 --> Model Class Initialized
INFO - 2019-07-10 01:03:27 --> Model Class Initialized
INFO - 2019-07-10 01:03:27 --> Model Class Initialized
INFO - 2019-07-10 01:03:27 --> Model Class Initialized
INFO - 2019-07-10 01:03:27 --> Helper loaded: form_helper
INFO - 2019-07-10 01:03:27 --> Form Validation Class Initialized
DEBUG - 2019-07-10 01:03:27 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 01:03:27 --> Model Class Initialized
INFO - 2019-07-10 01:03:27 --> Model Class Initialized
INFO - 2019-07-10 01:03:27 --> Final output sent to browser
DEBUG - 2019-07-10 01:03:27 --> Total execution time: 0.6863
INFO - 2019-07-10 01:03:48 --> Helper loaded: language_helper
INFO - 2019-07-10 01:03:49 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:03:49 --> Model Class Initialized
INFO - 2019-07-10 01:03:49 --> Model Class Initialized
INFO - 2019-07-10 01:03:49 --> Model Class Initialized
INFO - 2019-07-10 01:03:49 --> Model Class Initialized
INFO - 2019-07-10 01:03:49 --> Helper loaded: form_helper
INFO - 2019-07-10 01:03:49 --> Form Validation Class Initialized
DEBUG - 2019-07-10 01:03:49 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 01:03:49 --> Model Class Initialized
INFO - 2019-07-10 01:03:49 --> Model Class Initialized
INFO - 2019-07-10 01:03:49 --> Final output sent to browser
DEBUG - 2019-07-10 01:03:49 --> Total execution time: 0.8243
INFO - 2019-07-10 01:03:49 --> Helper loaded: language_helper
INFO - 2019-07-10 01:03:49 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:03:49 --> Model Class Initialized
INFO - 2019-07-10 01:03:49 --> Model Class Initialized
INFO - 2019-07-10 01:03:49 --> Model Class Initialized
INFO - 2019-07-10 01:03:49 --> Model Class Initialized
INFO - 2019-07-10 01:03:49 --> Helper loaded: form_helper
INFO - 2019-07-10 01:03:49 --> Form Validation Class Initialized
DEBUG - 2019-07-10 01:03:49 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 01:03:49 --> Model Class Initialized
INFO - 2019-07-10 01:03:49 --> Model Class Initialized
INFO - 2019-07-10 01:03:49 --> Final output sent to browser
DEBUG - 2019-07-10 01:03:49 --> Total execution time: 0.6826
INFO - 2019-07-10 01:03:53 --> Helper loaded: language_helper
INFO - 2019-07-10 01:03:53 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:03:53 --> Model Class Initialized
INFO - 2019-07-10 01:03:53 --> Model Class Initialized
INFO - 2019-07-10 01:03:53 --> Model Class Initialized
INFO - 2019-07-10 01:03:53 --> Model Class Initialized
INFO - 2019-07-10 01:03:53 --> Helper loaded: form_helper
INFO - 2019-07-10 01:03:53 --> Form Validation Class Initialized
DEBUG - 2019-07-10 01:03:53 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 01:03:53 --> Model Class Initialized
INFO - 2019-07-10 01:03:53 --> Model Class Initialized
INFO - 2019-07-10 01:03:53 --> Final output sent to browser
DEBUG - 2019-07-10 01:03:53 --> Total execution time: 0.6707
INFO - 2019-07-10 01:03:54 --> Helper loaded: language_helper
INFO - 2019-07-10 01:03:54 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:03:54 --> Model Class Initialized
INFO - 2019-07-10 01:03:54 --> Model Class Initialized
INFO - 2019-07-10 01:03:54 --> Model Class Initialized
INFO - 2019-07-10 01:03:54 --> Model Class Initialized
INFO - 2019-07-10 01:03:54 --> Helper loaded: form_helper
INFO - 2019-07-10 01:03:54 --> Form Validation Class Initialized
DEBUG - 2019-07-10 01:03:54 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 01:03:54 --> Model Class Initialized
INFO - 2019-07-10 01:03:54 --> Model Class Initialized
INFO - 2019-07-10 01:03:54 --> Final output sent to browser
DEBUG - 2019-07-10 01:03:54 --> Total execution time: 0.6924
INFO - 2019-07-10 01:03:57 --> Helper loaded: language_helper
INFO - 2019-07-10 01:03:57 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:03:57 --> Model Class Initialized
INFO - 2019-07-10 01:03:57 --> Model Class Initialized
INFO - 2019-07-10 01:03:57 --> Model Class Initialized
INFO - 2019-07-10 01:03:57 --> Model Class Initialized
INFO - 2019-07-10 01:03:57 --> Helper loaded: form_helper
INFO - 2019-07-10 01:03:57 --> Form Validation Class Initialized
DEBUG - 2019-07-10 01:03:57 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 01:03:57 --> Model Class Initialized
INFO - 2019-07-10 01:03:57 --> Model Class Initialized
INFO - 2019-07-10 01:03:57 --> Final output sent to browser
DEBUG - 2019-07-10 01:03:57 --> Total execution time: 0.7360
INFO - 2019-07-10 01:03:58 --> Helper loaded: language_helper
INFO - 2019-07-10 01:03:58 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:03:58 --> Model Class Initialized
INFO - 2019-07-10 01:03:58 --> Model Class Initialized
INFO - 2019-07-10 01:03:58 --> Model Class Initialized
INFO - 2019-07-10 01:03:58 --> Model Class Initialized
INFO - 2019-07-10 01:03:59 --> Helper loaded: form_helper
INFO - 2019-07-10 01:03:59 --> Form Validation Class Initialized
DEBUG - 2019-07-10 01:03:59 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 01:03:59 --> Model Class Initialized
INFO - 2019-07-10 01:03:59 --> Model Class Initialized
INFO - 2019-07-10 01:03:59 --> Final output sent to browser
DEBUG - 2019-07-10 01:03:59 --> Total execution time: 0.6935
INFO - 2019-07-10 01:04:02 --> Helper loaded: language_helper
INFO - 2019-07-10 01:04:02 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:04:02 --> Model Class Initialized
INFO - 2019-07-10 01:04:02 --> Model Class Initialized
INFO - 2019-07-10 01:04:02 --> Model Class Initialized
INFO - 2019-07-10 01:04:02 --> Model Class Initialized
INFO - 2019-07-10 01:04:02 --> Helper loaded: form_helper
INFO - 2019-07-10 01:04:02 --> Form Validation Class Initialized
DEBUG - 2019-07-10 01:04:02 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 01:04:02 --> Model Class Initialized
INFO - 2019-07-10 01:04:02 --> Model Class Initialized
INFO - 2019-07-10 01:04:02 --> Final output sent to browser
DEBUG - 2019-07-10 01:04:02 --> Total execution time: 0.6525
INFO - 2019-07-10 01:05:46 --> Helper loaded: language_helper
INFO - 2019-07-10 01:05:46 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:05:46 --> Model Class Initialized
INFO - 2019-07-10 01:05:46 --> Model Class Initialized
INFO - 2019-07-10 01:05:46 --> Model Class Initialized
INFO - 2019-07-10 01:05:46 --> Model Class Initialized
INFO - 2019-07-10 01:05:46 --> Helper loaded: form_helper
INFO - 2019-07-10 01:05:46 --> Form Validation Class Initialized
DEBUG - 2019-07-10 01:05:46 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 01:05:46 --> Model Class Initialized
INFO - 2019-07-10 01:05:46 --> Model Class Initialized
INFO - 2019-07-10 01:05:46 --> Final output sent to browser
DEBUG - 2019-07-10 01:05:47 --> Total execution time: 0.6904
INFO - 2019-07-10 01:05:53 --> Helper loaded: language_helper
INFO - 2019-07-10 01:05:53 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:05:53 --> Model Class Initialized
INFO - 2019-07-10 01:05:53 --> Model Class Initialized
INFO - 2019-07-10 01:05:53 --> Model Class Initialized
INFO - 2019-07-10 01:05:53 --> Model Class Initialized
INFO - 2019-07-10 01:05:53 --> Helper loaded: form_helper
INFO - 2019-07-10 01:05:53 --> Form Validation Class Initialized
DEBUG - 2019-07-10 01:05:53 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 01:05:53 --> Model Class Initialized
INFO - 2019-07-10 01:05:53 --> Model Class Initialized
INFO - 2019-07-10 01:05:53 --> Final output sent to browser
DEBUG - 2019-07-10 01:05:53 --> Total execution time: 0.6918
INFO - 2019-07-10 01:06:00 --> Helper loaded: language_helper
INFO - 2019-07-10 01:06:00 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:06:00 --> Model Class Initialized
INFO - 2019-07-10 01:06:00 --> Model Class Initialized
INFO - 2019-07-10 01:06:00 --> Model Class Initialized
INFO - 2019-07-10 01:06:00 --> Model Class Initialized
INFO - 2019-07-10 01:06:00 --> Helper loaded: form_helper
INFO - 2019-07-10 01:06:00 --> Form Validation Class Initialized
DEBUG - 2019-07-10 01:06:00 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 01:06:00 --> Model Class Initialized
INFO - 2019-07-10 01:06:00 --> Model Class Initialized
INFO - 2019-07-10 01:06:00 --> Final output sent to browser
DEBUG - 2019-07-10 01:06:00 --> Total execution time: 0.6863
INFO - 2019-07-10 01:06:24 --> Helper loaded: language_helper
INFO - 2019-07-10 01:06:24 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:06:24 --> Model Class Initialized
INFO - 2019-07-10 01:06:24 --> Model Class Initialized
INFO - 2019-07-10 01:06:24 --> Model Class Initialized
INFO - 2019-07-10 01:06:24 --> Model Class Initialized
INFO - 2019-07-10 01:06:24 --> Helper loaded: form_helper
INFO - 2019-07-10 01:06:24 --> Form Validation Class Initialized
DEBUG - 2019-07-10 01:06:24 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 01:06:24 --> Model Class Initialized
INFO - 2019-07-10 01:06:24 --> Model Class Initialized
INFO - 2019-07-10 01:06:24 --> Final output sent to browser
DEBUG - 2019-07-10 01:06:24 --> Total execution time: 0.6691
INFO - 2019-07-10 01:06:31 --> Helper loaded: language_helper
INFO - 2019-07-10 01:06:31 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:06:31 --> Model Class Initialized
INFO - 2019-07-10 01:06:31 --> Model Class Initialized
INFO - 2019-07-10 01:06:31 --> Model Class Initialized
INFO - 2019-07-10 01:06:31 --> Model Class Initialized
INFO - 2019-07-10 01:06:31 --> Helper loaded: form_helper
INFO - 2019-07-10 01:06:32 --> Form Validation Class Initialized
DEBUG - 2019-07-10 01:06:32 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 01:06:32 --> Model Class Initialized
INFO - 2019-07-10 01:06:32 --> Model Class Initialized
INFO - 2019-07-10 01:06:32 --> Final output sent to browser
DEBUG - 2019-07-10 01:06:32 --> Total execution time: 0.6631
INFO - 2019-07-10 01:06:47 --> Helper loaded: language_helper
INFO - 2019-07-10 01:06:47 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:06:47 --> Model Class Initialized
INFO - 2019-07-10 01:06:47 --> Model Class Initialized
INFO - 2019-07-10 01:06:47 --> Model Class Initialized
INFO - 2019-07-10 01:06:47 --> Model Class Initialized
INFO - 2019-07-10 01:06:47 --> Helper loaded: form_helper
INFO - 2019-07-10 01:06:47 --> Form Validation Class Initialized
DEBUG - 2019-07-10 01:06:47 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 01:06:47 --> Model Class Initialized
INFO - 2019-07-10 01:06:47 --> Model Class Initialized
INFO - 2019-07-10 01:06:47 --> Final output sent to browser
DEBUG - 2019-07-10 01:06:47 --> Total execution time: 0.6828
INFO - 2019-07-10 01:06:49 --> Helper loaded: language_helper
INFO - 2019-07-10 01:06:49 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:06:49 --> Model Class Initialized
INFO - 2019-07-10 01:06:49 --> Model Class Initialized
INFO - 2019-07-10 01:06:49 --> Model Class Initialized
INFO - 2019-07-10 01:06:49 --> Model Class Initialized
INFO - 2019-07-10 01:06:49 --> Helper loaded: form_helper
INFO - 2019-07-10 01:06:49 --> Form Validation Class Initialized
DEBUG - 2019-07-10 01:06:49 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 01:06:49 --> Model Class Initialized
INFO - 2019-07-10 01:06:49 --> Model Class Initialized
INFO - 2019-07-10 01:06:49 --> Final output sent to browser
DEBUG - 2019-07-10 01:06:49 --> Total execution time: 0.6507
INFO - 2019-07-10 01:07:11 --> Helper loaded: language_helper
INFO - 2019-07-10 01:07:11 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:07:11 --> Model Class Initialized
INFO - 2019-07-10 01:07:11 --> Model Class Initialized
INFO - 2019-07-10 01:07:11 --> Model Class Initialized
INFO - 2019-07-10 01:07:11 --> Model Class Initialized
INFO - 2019-07-10 01:07:11 --> Helper loaded: form_helper
INFO - 2019-07-10 01:07:11 --> Form Validation Class Initialized
DEBUG - 2019-07-10 01:07:11 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 01:07:11 --> Model Class Initialized
INFO - 2019-07-10 01:07:11 --> Model Class Initialized
INFO - 2019-07-10 01:07:11 --> Final output sent to browser
DEBUG - 2019-07-10 01:07:11 --> Total execution time: 0.6744
INFO - 2019-07-10 01:07:47 --> Helper loaded: language_helper
INFO - 2019-07-10 01:07:47 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:07:47 --> Model Class Initialized
INFO - 2019-07-10 01:07:47 --> Model Class Initialized
INFO - 2019-07-10 01:07:47 --> Model Class Initialized
INFO - 2019-07-10 01:07:47 --> Model Class Initialized
INFO - 2019-07-10 01:07:47 --> Helper loaded: form_helper
INFO - 2019-07-10 01:07:47 --> Form Validation Class Initialized
DEBUG - 2019-07-10 01:07:47 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 01:07:47 --> Model Class Initialized
INFO - 2019-07-10 01:07:47 --> Model Class Initialized
INFO - 2019-07-10 01:07:47 --> Final output sent to browser
DEBUG - 2019-07-10 01:07:47 --> Total execution time: 0.7022
INFO - 2019-07-10 01:08:05 --> Helper loaded: language_helper
INFO - 2019-07-10 01:08:05 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:08:05 --> Model Class Initialized
INFO - 2019-07-10 01:08:05 --> Model Class Initialized
INFO - 2019-07-10 01:08:05 --> Model Class Initialized
INFO - 2019-07-10 01:08:05 --> Model Class Initialized
INFO - 2019-07-10 01:08:05 --> Helper loaded: form_helper
INFO - 2019-07-10 01:08:05 --> Form Validation Class Initialized
DEBUG - 2019-07-10 01:08:05 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 01:08:05 --> Model Class Initialized
INFO - 2019-07-10 01:08:05 --> Model Class Initialized
INFO - 2019-07-10 01:08:05 --> Final output sent to browser
DEBUG - 2019-07-10 01:08:05 --> Total execution time: 0.7133
INFO - 2019-07-10 01:08:38 --> Helper loaded: language_helper
INFO - 2019-07-10 01:08:38 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:08:38 --> Model Class Initialized
INFO - 2019-07-10 01:08:38 --> Model Class Initialized
INFO - 2019-07-10 01:08:38 --> Model Class Initialized
INFO - 2019-07-10 01:08:38 --> Model Class Initialized
INFO - 2019-07-10 01:08:38 --> Helper loaded: form_helper
INFO - 2019-07-10 01:08:38 --> Form Validation Class Initialized
DEBUG - 2019-07-10 01:08:38 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 01:08:38 --> Model Class Initialized
INFO - 2019-07-10 01:08:38 --> Model Class Initialized
INFO - 2019-07-10 01:08:38 --> Final output sent to browser
DEBUG - 2019-07-10 01:08:38 --> Total execution time: 0.6869
INFO - 2019-07-10 01:09:09 --> Helper loaded: language_helper
INFO - 2019-07-10 01:09:09 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:09:09 --> Model Class Initialized
INFO - 2019-07-10 01:09:09 --> Model Class Initialized
INFO - 2019-07-10 01:09:09 --> Model Class Initialized
INFO - 2019-07-10 01:09:09 --> Model Class Initialized
INFO - 2019-07-10 01:09:09 --> Helper loaded: form_helper
INFO - 2019-07-10 01:09:09 --> Form Validation Class Initialized
DEBUG - 2019-07-10 01:09:09 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 01:09:09 --> Model Class Initialized
INFO - 2019-07-10 01:09:09 --> Model Class Initialized
INFO - 2019-07-10 01:09:09 --> Final output sent to browser
DEBUG - 2019-07-10 01:09:09 --> Total execution time: 0.7902
INFO - 2019-07-10 01:09:11 --> Helper loaded: language_helper
INFO - 2019-07-10 01:09:11 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:09:11 --> Model Class Initialized
INFO - 2019-07-10 01:09:11 --> Model Class Initialized
INFO - 2019-07-10 01:09:11 --> Model Class Initialized
INFO - 2019-07-10 01:09:11 --> Model Class Initialized
INFO - 2019-07-10 01:09:11 --> Helper loaded: form_helper
INFO - 2019-07-10 01:09:11 --> Form Validation Class Initialized
DEBUG - 2019-07-10 01:09:11 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 01:09:11 --> Model Class Initialized
INFO - 2019-07-10 01:09:11 --> Model Class Initialized
INFO - 2019-07-10 01:09:11 --> Final output sent to browser
DEBUG - 2019-07-10 01:09:11 --> Total execution time: 0.6703
INFO - 2019-07-10 01:09:14 --> Helper loaded: language_helper
INFO - 2019-07-10 01:09:14 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:09:14 --> Model Class Initialized
INFO - 2019-07-10 01:09:14 --> Model Class Initialized
INFO - 2019-07-10 01:09:14 --> Model Class Initialized
INFO - 2019-07-10 01:09:14 --> Model Class Initialized
INFO - 2019-07-10 01:09:14 --> Helper loaded: form_helper
INFO - 2019-07-10 01:09:14 --> Form Validation Class Initialized
DEBUG - 2019-07-10 01:09:14 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 01:09:14 --> Model Class Initialized
INFO - 2019-07-10 01:09:14 --> Model Class Initialized
INFO - 2019-07-10 01:09:14 --> Final output sent to browser
DEBUG - 2019-07-10 01:09:14 --> Total execution time: 0.6866
INFO - 2019-07-10 01:11:07 --> Helper loaded: language_helper
INFO - 2019-07-10 01:11:07 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:11:07 --> Model Class Initialized
INFO - 2019-07-10 01:11:07 --> Model Class Initialized
INFO - 2019-07-10 01:11:07 --> Model Class Initialized
INFO - 2019-07-10 01:11:07 --> Model Class Initialized
INFO - 2019-07-10 01:11:07 --> Helper loaded: form_helper
INFO - 2019-07-10 01:11:07 --> Form Validation Class Initialized
DEBUG - 2019-07-10 01:11:07 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 01:11:07 --> Model Class Initialized
INFO - 2019-07-10 01:11:07 --> Model Class Initialized
INFO - 2019-07-10 01:11:07 --> Final output sent to browser
DEBUG - 2019-07-10 01:11:07 --> Total execution time: 0.6372
INFO - 2019-07-10 01:11:20 --> Helper loaded: language_helper
INFO - 2019-07-10 01:11:20 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:11:20 --> Model Class Initialized
INFO - 2019-07-10 01:11:20 --> Model Class Initialized
INFO - 2019-07-10 01:11:20 --> Model Class Initialized
INFO - 2019-07-10 01:11:20 --> Model Class Initialized
INFO - 2019-07-10 01:11:20 --> Helper loaded: form_helper
INFO - 2019-07-10 01:11:20 --> Form Validation Class Initialized
DEBUG - 2019-07-10 01:11:20 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 01:11:20 --> Model Class Initialized
INFO - 2019-07-10 01:11:20 --> Model Class Initialized
INFO - 2019-07-10 01:11:20 --> Final output sent to browser
DEBUG - 2019-07-10 01:11:20 --> Total execution time: 0.7104
INFO - 2019-07-10 01:11:36 --> Helper loaded: language_helper
INFO - 2019-07-10 01:11:36 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:11:36 --> Model Class Initialized
INFO - 2019-07-10 01:11:36 --> Model Class Initialized
INFO - 2019-07-10 01:11:36 --> Model Class Initialized
INFO - 2019-07-10 01:11:36 --> Model Class Initialized
INFO - 2019-07-10 01:11:36 --> Helper loaded: form_helper
INFO - 2019-07-10 01:11:36 --> Form Validation Class Initialized
DEBUG - 2019-07-10 01:11:36 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 01:11:36 --> Model Class Initialized
INFO - 2019-07-10 01:11:36 --> Model Class Initialized
INFO - 2019-07-10 01:11:36 --> Final output sent to browser
DEBUG - 2019-07-10 01:11:36 --> Total execution time: 0.7161
INFO - 2019-07-10 01:11:41 --> Helper loaded: language_helper
INFO - 2019-07-10 01:11:41 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:11:41 --> Model Class Initialized
INFO - 2019-07-10 01:11:41 --> Model Class Initialized
INFO - 2019-07-10 01:11:41 --> Model Class Initialized
INFO - 2019-07-10 01:11:41 --> Model Class Initialized
INFO - 2019-07-10 01:11:41 --> Model Class Initialized
INFO - 2019-07-10 01:11:41 --> Final output sent to browser
DEBUG - 2019-07-10 01:11:41 --> Total execution time: 0.6428
INFO - 2019-07-10 01:11:43 --> Helper loaded: language_helper
INFO - 2019-07-10 01:11:43 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:11:43 --> Model Class Initialized
INFO - 2019-07-10 01:11:43 --> Model Class Initialized
INFO - 2019-07-10 01:11:43 --> Model Class Initialized
INFO - 2019-07-10 01:11:43 --> Model Class Initialized
INFO - 2019-07-10 01:11:43 --> Model Class Initialized
INFO - 2019-07-10 01:11:43 --> Final output sent to browser
DEBUG - 2019-07-10 01:11:43 --> Total execution time: 0.7862
INFO - 2019-07-10 01:11:49 --> Helper loaded: language_helper
INFO - 2019-07-10 01:11:49 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:11:49 --> Model Class Initialized
INFO - 2019-07-10 01:11:49 --> Model Class Initialized
INFO - 2019-07-10 01:11:49 --> Model Class Initialized
INFO - 2019-07-10 01:11:49 --> Model Class Initialized
INFO - 2019-07-10 01:11:49 --> Model Class Initialized
INFO - 2019-07-10 01:11:49 --> Final output sent to browser
DEBUG - 2019-07-10 01:11:49 --> Total execution time: 0.9463
INFO - 2019-07-10 01:11:50 --> Helper loaded: language_helper
INFO - 2019-07-10 01:11:50 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:11:50 --> Model Class Initialized
INFO - 2019-07-10 01:11:50 --> Model Class Initialized
INFO - 2019-07-10 01:11:50 --> Model Class Initialized
INFO - 2019-07-10 01:11:50 --> Model Class Initialized
INFO - 2019-07-10 01:11:50 --> Helper loaded: form_helper
INFO - 2019-07-10 01:11:50 --> Form Validation Class Initialized
DEBUG - 2019-07-10 01:11:50 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 01:11:50 --> Model Class Initialized
INFO - 2019-07-10 01:11:50 --> Model Class Initialized
INFO - 2019-07-10 01:11:50 --> Final output sent to browser
DEBUG - 2019-07-10 01:11:50 --> Total execution time: 1.2508
INFO - 2019-07-10 01:11:56 --> Helper loaded: language_helper
INFO - 2019-07-10 01:11:56 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:11:56 --> Model Class Initialized
INFO - 2019-07-10 01:11:56 --> Model Class Initialized
INFO - 2019-07-10 01:11:56 --> Model Class Initialized
INFO - 2019-07-10 01:11:56 --> Model Class Initialized
INFO - 2019-07-10 01:11:56 --> Model Class Initialized
INFO - 2019-07-10 01:11:56 --> Final output sent to browser
DEBUG - 2019-07-10 01:11:56 --> Total execution time: 0.6458
INFO - 2019-07-10 01:11:59 --> Helper loaded: language_helper
INFO - 2019-07-10 01:11:59 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:11:59 --> Model Class Initialized
INFO - 2019-07-10 01:11:59 --> Model Class Initialized
INFO - 2019-07-10 01:11:59 --> Model Class Initialized
INFO - 2019-07-10 01:11:59 --> Model Class Initialized
INFO - 2019-07-10 01:11:59 --> Helper loaded: form_helper
INFO - 2019-07-10 01:11:59 --> Form Validation Class Initialized
DEBUG - 2019-07-10 01:11:59 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 01:11:59 --> Model Class Initialized
INFO - 2019-07-10 01:11:59 --> Model Class Initialized
INFO - 2019-07-10 01:11:59 --> Final output sent to browser
DEBUG - 2019-07-10 01:11:59 --> Total execution time: 0.7108
INFO - 2019-07-10 01:12:00 --> Helper loaded: language_helper
INFO - 2019-07-10 01:12:00 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:12:00 --> Model Class Initialized
INFO - 2019-07-10 01:12:00 --> Model Class Initialized
INFO - 2019-07-10 01:12:00 --> Model Class Initialized
INFO - 2019-07-10 01:12:00 --> Model Class Initialized
INFO - 2019-07-10 01:12:00 --> Helper loaded: form_helper
INFO - 2019-07-10 01:12:00 --> Form Validation Class Initialized
DEBUG - 2019-07-10 01:12:00 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 01:12:00 --> Model Class Initialized
INFO - 2019-07-10 01:12:00 --> Model Class Initialized
INFO - 2019-07-10 01:12:00 --> Final output sent to browser
DEBUG - 2019-07-10 01:12:00 --> Total execution time: 0.6957
INFO - 2019-07-10 01:12:02 --> Helper loaded: language_helper
INFO - 2019-07-10 01:12:02 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:12:02 --> Model Class Initialized
INFO - 2019-07-10 01:12:02 --> Model Class Initialized
INFO - 2019-07-10 01:12:02 --> Model Class Initialized
INFO - 2019-07-10 01:12:02 --> Model Class Initialized
INFO - 2019-07-10 01:12:02 --> Helper loaded: form_helper
INFO - 2019-07-10 01:12:02 --> Form Validation Class Initialized
DEBUG - 2019-07-10 01:12:02 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 01:12:02 --> Model Class Initialized
INFO - 2019-07-10 01:12:02 --> Model Class Initialized
INFO - 2019-07-10 01:12:02 --> Final output sent to browser
DEBUG - 2019-07-10 01:12:02 --> Total execution time: 0.6729
INFO - 2019-07-10 01:12:02 --> Helper loaded: language_helper
INFO - 2019-07-10 01:12:02 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:12:02 --> Model Class Initialized
INFO - 2019-07-10 01:12:03 --> Model Class Initialized
INFO - 2019-07-10 01:12:03 --> Model Class Initialized
INFO - 2019-07-10 01:12:03 --> Model Class Initialized
INFO - 2019-07-10 01:12:03 --> Helper loaded: form_helper
INFO - 2019-07-10 01:12:03 --> Form Validation Class Initialized
DEBUG - 2019-07-10 01:12:03 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 01:12:03 --> Model Class Initialized
INFO - 2019-07-10 01:12:03 --> Model Class Initialized
INFO - 2019-07-10 01:12:03 --> Final output sent to browser
DEBUG - 2019-07-10 01:12:03 --> Total execution time: 0.6707
INFO - 2019-07-10 01:14:04 --> Helper loaded: language_helper
INFO - 2019-07-10 01:14:04 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:14:04 --> Model Class Initialized
INFO - 2019-07-10 01:14:04 --> Model Class Initialized
INFO - 2019-07-10 01:14:04 --> Model Class Initialized
INFO - 2019-07-10 01:14:04 --> Model Class Initialized
INFO - 2019-07-10 01:14:04 --> Helper loaded: form_helper
INFO - 2019-07-10 01:14:04 --> Form Validation Class Initialized
DEBUG - 2019-07-10 01:14:05 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 01:14:05 --> Model Class Initialized
INFO - 2019-07-10 01:14:05 --> Model Class Initialized
INFO - 2019-07-10 01:14:05 --> Final output sent to browser
DEBUG - 2019-07-10 01:14:05 --> Total execution time: 0.9673
INFO - 2019-07-10 01:14:05 --> Helper loaded: language_helper
INFO - 2019-07-10 01:14:05 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:14:05 --> Model Class Initialized
INFO - 2019-07-10 01:14:05 --> Model Class Initialized
INFO - 2019-07-10 01:14:05 --> Model Class Initialized
INFO - 2019-07-10 01:14:05 --> Model Class Initialized
INFO - 2019-07-10 01:14:05 --> Model Class Initialized
INFO - 2019-07-10 01:14:05 --> Final output sent to browser
DEBUG - 2019-07-10 01:14:05 --> Total execution time: 1.1658
INFO - 2019-07-10 01:16:53 --> Helper loaded: language_helper
INFO - 2019-07-10 01:16:53 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:16:53 --> Model Class Initialized
INFO - 2019-07-10 01:16:53 --> Model Class Initialized
INFO - 2019-07-10 01:16:54 --> Model Class Initialized
INFO - 2019-07-10 01:16:54 --> Model Class Initialized
INFO - 2019-07-10 01:16:54 --> Model Class Initialized
INFO - 2019-07-10 01:16:54 --> Final output sent to browser
DEBUG - 2019-07-10 01:16:54 --> Total execution time: 0.8598
INFO - 2019-07-10 01:16:54 --> Helper loaded: language_helper
INFO - 2019-07-10 01:16:54 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:16:54 --> Model Class Initialized
INFO - 2019-07-10 01:16:54 --> Model Class Initialized
INFO - 2019-07-10 01:16:54 --> Model Class Initialized
INFO - 2019-07-10 01:16:54 --> Model Class Initialized
INFO - 2019-07-10 01:16:54 --> Helper loaded: form_helper
INFO - 2019-07-10 01:16:54 --> Form Validation Class Initialized
DEBUG - 2019-07-10 01:16:54 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 01:16:54 --> Model Class Initialized
INFO - 2019-07-10 01:16:54 --> Model Class Initialized
INFO - 2019-07-10 01:16:54 --> Final output sent to browser
DEBUG - 2019-07-10 01:16:54 --> Total execution time: 1.0548
INFO - 2019-07-10 01:17:00 --> Helper loaded: language_helper
INFO - 2019-07-10 01:17:00 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:17:01 --> Model Class Initialized
INFO - 2019-07-10 01:17:01 --> Model Class Initialized
INFO - 2019-07-10 01:17:01 --> Model Class Initialized
INFO - 2019-07-10 01:17:01 --> Model Class Initialized
INFO - 2019-07-10 01:17:01 --> Model Class Initialized
INFO - 2019-07-10 01:17:01 --> Final output sent to browser
DEBUG - 2019-07-10 01:17:01 --> Total execution time: 0.8814
INFO - 2019-07-10 01:17:01 --> Helper loaded: language_helper
INFO - 2019-07-10 01:17:01 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:17:01 --> Model Class Initialized
INFO - 2019-07-10 01:17:01 --> Model Class Initialized
INFO - 2019-07-10 01:17:01 --> Model Class Initialized
INFO - 2019-07-10 01:17:01 --> Model Class Initialized
INFO - 2019-07-10 01:17:01 --> Helper loaded: form_helper
INFO - 2019-07-10 01:17:01 --> Form Validation Class Initialized
DEBUG - 2019-07-10 01:17:01 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 01:17:01 --> Model Class Initialized
INFO - 2019-07-10 01:17:01 --> Model Class Initialized
INFO - 2019-07-10 01:17:01 --> Final output sent to browser
DEBUG - 2019-07-10 01:17:01 --> Total execution time: 1.1218
INFO - 2019-07-10 01:17:31 --> Helper loaded: language_helper
INFO - 2019-07-10 01:17:31 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:17:31 --> Model Class Initialized
INFO - 2019-07-10 01:17:32 --> Model Class Initialized
INFO - 2019-07-10 01:17:32 --> Model Class Initialized
INFO - 2019-07-10 01:17:32 --> Model Class Initialized
INFO - 2019-07-10 01:17:32 --> Model Class Initialized
INFO - 2019-07-10 01:17:32 --> Final output sent to browser
DEBUG - 2019-07-10 01:17:32 --> Total execution time: 0.8693
INFO - 2019-07-10 01:17:32 --> Helper loaded: language_helper
INFO - 2019-07-10 01:17:32 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:17:32 --> Model Class Initialized
INFO - 2019-07-10 01:17:32 --> Model Class Initialized
INFO - 2019-07-10 01:17:32 --> Model Class Initialized
INFO - 2019-07-10 01:17:32 --> Model Class Initialized
INFO - 2019-07-10 01:17:32 --> Helper loaded: form_helper
INFO - 2019-07-10 01:17:32 --> Form Validation Class Initialized
DEBUG - 2019-07-10 01:17:32 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 01:17:32 --> Model Class Initialized
INFO - 2019-07-10 01:17:32 --> Model Class Initialized
INFO - 2019-07-10 01:17:32 --> Final output sent to browser
DEBUG - 2019-07-10 01:17:32 --> Total execution time: 1.1111
INFO - 2019-07-10 01:17:50 --> Helper loaded: language_helper
INFO - 2019-07-10 01:17:50 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:17:50 --> Model Class Initialized
INFO - 2019-07-10 01:17:50 --> Model Class Initialized
INFO - 2019-07-10 01:17:50 --> Model Class Initialized
INFO - 2019-07-10 01:17:50 --> Model Class Initialized
INFO - 2019-07-10 01:17:50 --> Helper loaded: form_helper
INFO - 2019-07-10 01:17:50 --> Form Validation Class Initialized
DEBUG - 2019-07-10 01:17:50 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 01:17:51 --> Model Class Initialized
INFO - 2019-07-10 01:17:51 --> Model Class Initialized
INFO - 2019-07-10 01:17:51 --> Final output sent to browser
DEBUG - 2019-07-10 01:17:51 --> Total execution time: 0.8362
INFO - 2019-07-10 01:17:51 --> Helper loaded: language_helper
INFO - 2019-07-10 01:17:51 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:17:51 --> Model Class Initialized
INFO - 2019-07-10 01:17:51 --> Model Class Initialized
INFO - 2019-07-10 01:17:51 --> Model Class Initialized
INFO - 2019-07-10 01:17:51 --> Model Class Initialized
INFO - 2019-07-10 01:17:51 --> Model Class Initialized
INFO - 2019-07-10 01:17:51 --> Final output sent to browser
DEBUG - 2019-07-10 01:17:51 --> Total execution time: 1.0413
INFO - 2019-07-10 01:18:00 --> Helper loaded: language_helper
INFO - 2019-07-10 01:18:00 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:18:00 --> Model Class Initialized
INFO - 2019-07-10 01:18:00 --> Model Class Initialized
INFO - 2019-07-10 01:18:00 --> Model Class Initialized
INFO - 2019-07-10 01:18:00 --> Model Class Initialized
INFO - 2019-07-10 01:18:00 --> Helper loaded: form_helper
INFO - 2019-07-10 01:18:00 --> Form Validation Class Initialized
DEBUG - 2019-07-10 01:18:00 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 01:18:00 --> Model Class Initialized
INFO - 2019-07-10 01:18:00 --> Model Class Initialized
INFO - 2019-07-10 01:18:00 --> Final output sent to browser
DEBUG - 2019-07-10 01:18:00 --> Total execution time: 1.0486
INFO - 2019-07-10 01:18:00 --> Helper loaded: language_helper
INFO - 2019-07-10 01:18:00 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:18:00 --> Model Class Initialized
INFO - 2019-07-10 01:18:00 --> Model Class Initialized
INFO - 2019-07-10 01:18:00 --> Model Class Initialized
INFO - 2019-07-10 01:18:00 --> Model Class Initialized
INFO - 2019-07-10 01:18:00 --> Model Class Initialized
INFO - 2019-07-10 01:18:00 --> Final output sent to browser
DEBUG - 2019-07-10 01:18:00 --> Total execution time: 1.2496
INFO - 2019-07-10 01:19:06 --> Helper loaded: language_helper
INFO - 2019-07-10 01:19:06 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:19:06 --> Model Class Initialized
INFO - 2019-07-10 01:19:06 --> Model Class Initialized
INFO - 2019-07-10 01:19:06 --> Model Class Initialized
INFO - 2019-07-10 01:19:06 --> Model Class Initialized
INFO - 2019-07-10 01:19:06 --> Model Class Initialized
INFO - 2019-07-10 01:19:06 --> Final output sent to browser
DEBUG - 2019-07-10 01:19:06 --> Total execution time: 0.9640
INFO - 2019-07-10 01:19:06 --> Helper loaded: language_helper
INFO - 2019-07-10 01:19:06 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:19:06 --> Model Class Initialized
INFO - 2019-07-10 01:19:06 --> Model Class Initialized
INFO - 2019-07-10 01:19:06 --> Model Class Initialized
INFO - 2019-07-10 01:19:06 --> Model Class Initialized
INFO - 2019-07-10 01:19:06 --> Helper loaded: form_helper
INFO - 2019-07-10 01:19:06 --> Form Validation Class Initialized
DEBUG - 2019-07-10 01:19:06 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 01:19:06 --> Model Class Initialized
INFO - 2019-07-10 01:19:06 --> Model Class Initialized
INFO - 2019-07-10 01:19:06 --> Final output sent to browser
DEBUG - 2019-07-10 01:19:06 --> Total execution time: 1.2535
INFO - 2019-07-10 01:19:36 --> Helper loaded: language_helper
INFO - 2019-07-10 01:19:36 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:19:36 --> Model Class Initialized
INFO - 2019-07-10 01:19:36 --> Model Class Initialized
INFO - 2019-07-10 01:19:36 --> Model Class Initialized
INFO - 2019-07-10 01:19:36 --> Model Class Initialized
INFO - 2019-07-10 01:19:36 --> Model Class Initialized
INFO - 2019-07-10 01:19:36 --> Final output sent to browser
DEBUG - 2019-07-10 01:19:36 --> Total execution time: 0.9895
INFO - 2019-07-10 01:19:36 --> Helper loaded: language_helper
INFO - 2019-07-10 01:19:36 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:19:36 --> Model Class Initialized
INFO - 2019-07-10 01:19:36 --> Model Class Initialized
INFO - 2019-07-10 01:19:36 --> Model Class Initialized
INFO - 2019-07-10 01:19:36 --> Model Class Initialized
INFO - 2019-07-10 01:19:36 --> Helper loaded: form_helper
INFO - 2019-07-10 01:19:36 --> Form Validation Class Initialized
DEBUG - 2019-07-10 01:19:36 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 01:19:36 --> Model Class Initialized
INFO - 2019-07-10 01:19:36 --> Model Class Initialized
INFO - 2019-07-10 01:19:36 --> Final output sent to browser
DEBUG - 2019-07-10 01:19:36 --> Total execution time: 1.3038
INFO - 2019-07-10 01:19:48 --> Helper loaded: language_helper
INFO - 2019-07-10 01:19:48 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:19:48 --> Model Class Initialized
INFO - 2019-07-10 01:19:48 --> Model Class Initialized
INFO - 2019-07-10 01:19:48 --> Model Class Initialized
INFO - 2019-07-10 01:19:48 --> Model Class Initialized
INFO - 2019-07-10 01:19:48 --> Model Class Initialized
INFO - 2019-07-10 01:19:48 --> Final output sent to browser
DEBUG - 2019-07-10 01:19:48 --> Total execution time: 0.8697
INFO - 2019-07-10 01:19:48 --> Helper loaded: language_helper
INFO - 2019-07-10 01:19:48 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:19:48 --> Model Class Initialized
INFO - 2019-07-10 01:19:48 --> Model Class Initialized
INFO - 2019-07-10 01:19:48 --> Model Class Initialized
INFO - 2019-07-10 01:19:48 --> Model Class Initialized
INFO - 2019-07-10 01:19:48 --> Helper loaded: form_helper
INFO - 2019-07-10 01:19:48 --> Form Validation Class Initialized
DEBUG - 2019-07-10 01:19:48 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 01:19:48 --> Model Class Initialized
INFO - 2019-07-10 01:19:48 --> Model Class Initialized
INFO - 2019-07-10 01:19:48 --> Final output sent to browser
DEBUG - 2019-07-10 01:19:48 --> Total execution time: 1.1683
INFO - 2019-07-10 01:20:07 --> Helper loaded: language_helper
INFO - 2019-07-10 01:20:07 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:20:07 --> Model Class Initialized
INFO - 2019-07-10 01:20:07 --> Model Class Initialized
INFO - 2019-07-10 01:20:07 --> Model Class Initialized
INFO - 2019-07-10 01:20:07 --> Model Class Initialized
INFO - 2019-07-10 01:20:07 --> Helper loaded: form_helper
INFO - 2019-07-10 01:20:07 --> Form Validation Class Initialized
DEBUG - 2019-07-10 01:20:07 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 01:20:07 --> Model Class Initialized
INFO - 2019-07-10 01:20:07 --> Model Class Initialized
INFO - 2019-07-10 01:20:07 --> Final output sent to browser
DEBUG - 2019-07-10 01:20:07 --> Total execution time: 0.6897
INFO - 2019-07-10 01:20:42 --> Helper loaded: language_helper
INFO - 2019-07-10 01:20:42 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:20:42 --> Model Class Initialized
INFO - 2019-07-10 01:20:42 --> Model Class Initialized
INFO - 2019-07-10 01:20:42 --> Model Class Initialized
INFO - 2019-07-10 01:20:42 --> Model Class Initialized
INFO - 2019-07-10 01:20:42 --> Model Class Initialized
INFO - 2019-07-10 01:20:42 --> Final output sent to browser
DEBUG - 2019-07-10 01:20:42 --> Total execution time: 0.9308
INFO - 2019-07-10 01:20:42 --> Helper loaded: language_helper
INFO - 2019-07-10 01:20:43 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:20:43 --> Model Class Initialized
INFO - 2019-07-10 01:20:43 --> Model Class Initialized
INFO - 2019-07-10 01:20:43 --> Model Class Initialized
INFO - 2019-07-10 01:20:43 --> Model Class Initialized
INFO - 2019-07-10 01:20:43 --> Helper loaded: form_helper
INFO - 2019-07-10 01:20:43 --> Form Validation Class Initialized
DEBUG - 2019-07-10 01:20:43 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 01:20:43 --> Model Class Initialized
INFO - 2019-07-10 01:20:43 --> Model Class Initialized
INFO - 2019-07-10 01:20:43 --> Final output sent to browser
DEBUG - 2019-07-10 01:20:43 --> Total execution time: 1.2002
INFO - 2019-07-10 01:20:47 --> Helper loaded: language_helper
INFO - 2019-07-10 01:20:47 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:20:47 --> Model Class Initialized
INFO - 2019-07-10 01:20:47 --> Model Class Initialized
INFO - 2019-07-10 01:20:47 --> Model Class Initialized
INFO - 2019-07-10 01:20:47 --> Model Class Initialized
INFO - 2019-07-10 01:20:47 --> Helper loaded: form_helper
INFO - 2019-07-10 01:20:47 --> Form Validation Class Initialized
DEBUG - 2019-07-10 01:20:47 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 01:20:47 --> Model Class Initialized
INFO - 2019-07-10 01:20:47 --> Model Class Initialized
INFO - 2019-07-10 01:20:47 --> Final output sent to browser
DEBUG - 2019-07-10 01:20:47 --> Total execution time: 0.9876
INFO - 2019-07-10 01:20:47 --> Helper loaded: language_helper
INFO - 2019-07-10 01:20:47 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:20:47 --> Model Class Initialized
INFO - 2019-07-10 01:20:47 --> Model Class Initialized
INFO - 2019-07-10 01:20:47 --> Model Class Initialized
INFO - 2019-07-10 01:20:47 --> Model Class Initialized
INFO - 2019-07-10 01:20:47 --> Model Class Initialized
INFO - 2019-07-10 01:20:47 --> Final output sent to browser
DEBUG - 2019-07-10 01:20:47 --> Total execution time: 1.2053
INFO - 2019-07-10 01:20:50 --> Helper loaded: language_helper
INFO - 2019-07-10 01:20:50 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:20:50 --> Model Class Initialized
INFO - 2019-07-10 01:20:50 --> Model Class Initialized
INFO - 2019-07-10 01:20:50 --> Model Class Initialized
INFO - 2019-07-10 01:20:50 --> Model Class Initialized
INFO - 2019-07-10 01:20:50 --> Model Class Initialized
INFO - 2019-07-10 01:20:50 --> Final output sent to browser
DEBUG - 2019-07-10 01:20:50 --> Total execution time: 0.8148
INFO - 2019-07-10 01:20:50 --> Helper loaded: language_helper
INFO - 2019-07-10 01:20:50 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:20:50 --> Model Class Initialized
INFO - 2019-07-10 01:20:50 --> Model Class Initialized
INFO - 2019-07-10 01:20:50 --> Model Class Initialized
INFO - 2019-07-10 01:20:50 --> Model Class Initialized
INFO - 2019-07-10 01:20:50 --> Helper loaded: form_helper
INFO - 2019-07-10 01:20:50 --> Form Validation Class Initialized
DEBUG - 2019-07-10 01:20:50 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 01:20:50 --> Model Class Initialized
INFO - 2019-07-10 01:20:50 --> Model Class Initialized
INFO - 2019-07-10 01:20:50 --> Final output sent to browser
DEBUG - 2019-07-10 01:20:50 --> Total execution time: 1.1164
INFO - 2019-07-10 01:20:51 --> Helper loaded: language_helper
INFO - 2019-07-10 01:20:51 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:20:51 --> Model Class Initialized
INFO - 2019-07-10 01:20:51 --> Model Class Initialized
INFO - 2019-07-10 01:20:51 --> Model Class Initialized
INFO - 2019-07-10 01:20:51 --> Model Class Initialized
INFO - 2019-07-10 01:20:51 --> Model Class Initialized
INFO - 2019-07-10 01:20:52 --> Final output sent to browser
DEBUG - 2019-07-10 01:20:52 --> Total execution time: 0.6552
INFO - 2019-07-10 01:20:55 --> Helper loaded: language_helper
INFO - 2019-07-10 01:20:55 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:20:55 --> Model Class Initialized
INFO - 2019-07-10 01:20:55 --> Model Class Initialized
INFO - 2019-07-10 01:20:55 --> Model Class Initialized
INFO - 2019-07-10 01:20:55 --> Model Class Initialized
INFO - 2019-07-10 01:20:55 --> Helper loaded: form_helper
INFO - 2019-07-10 01:20:55 --> Form Validation Class Initialized
DEBUG - 2019-07-10 01:20:55 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 01:20:55 --> Model Class Initialized
INFO - 2019-07-10 01:20:55 --> Model Class Initialized
INFO - 2019-07-10 01:20:55 --> Final output sent to browser
DEBUG - 2019-07-10 01:20:55 --> Total execution time: 0.6843
INFO - 2019-07-10 01:20:55 --> Helper loaded: language_helper
INFO - 2019-07-10 01:20:55 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:20:55 --> Model Class Initialized
INFO - 2019-07-10 01:20:55 --> Model Class Initialized
INFO - 2019-07-10 01:20:56 --> Model Class Initialized
INFO - 2019-07-10 01:20:56 --> Model Class Initialized
INFO - 2019-07-10 01:20:56 --> Helper loaded: form_helper
INFO - 2019-07-10 01:20:56 --> Form Validation Class Initialized
DEBUG - 2019-07-10 01:20:56 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 01:20:56 --> Model Class Initialized
INFO - 2019-07-10 01:20:56 --> Model Class Initialized
INFO - 2019-07-10 01:20:56 --> Final output sent to browser
DEBUG - 2019-07-10 01:20:56 --> Total execution time: 0.7066
INFO - 2019-07-10 01:21:25 --> Helper loaded: language_helper
INFO - 2019-07-10 01:21:25 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:21:25 --> Model Class Initialized
INFO - 2019-07-10 01:21:25 --> Model Class Initialized
INFO - 2019-07-10 01:21:25 --> Model Class Initialized
INFO - 2019-07-10 01:21:25 --> Model Class Initialized
INFO - 2019-07-10 01:21:25 --> Helper loaded: form_helper
INFO - 2019-07-10 01:21:25 --> Form Validation Class Initialized
DEBUG - 2019-07-10 01:21:25 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 01:21:25 --> Model Class Initialized
INFO - 2019-07-10 01:21:25 --> Model Class Initialized
INFO - 2019-07-10 01:21:25 --> Final output sent to browser
DEBUG - 2019-07-10 01:21:25 --> Total execution time: 0.7050
INFO - 2019-07-10 01:22:17 --> Helper loaded: language_helper
INFO - 2019-07-10 01:22:17 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:22:17 --> Model Class Initialized
INFO - 2019-07-10 01:22:17 --> Model Class Initialized
INFO - 2019-07-10 01:22:17 --> Model Class Initialized
INFO - 2019-07-10 01:22:17 --> Model Class Initialized
INFO - 2019-07-10 01:22:17 --> Helper loaded: form_helper
INFO - 2019-07-10 01:22:17 --> Form Validation Class Initialized
DEBUG - 2019-07-10 01:22:17 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 01:22:17 --> Model Class Initialized
INFO - 2019-07-10 01:22:17 --> Model Class Initialized
INFO - 2019-07-10 01:22:17 --> Final output sent to browser
DEBUG - 2019-07-10 01:22:17 --> Total execution time: 0.9969
INFO - 2019-07-10 01:22:17 --> Helper loaded: language_helper
INFO - 2019-07-10 01:22:17 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:22:17 --> Model Class Initialized
INFO - 2019-07-10 01:22:17 --> Model Class Initialized
INFO - 2019-07-10 01:22:17 --> Model Class Initialized
INFO - 2019-07-10 01:22:17 --> Model Class Initialized
INFO - 2019-07-10 01:22:17 --> Model Class Initialized
INFO - 2019-07-10 01:22:18 --> Final output sent to browser
DEBUG - 2019-07-10 01:22:18 --> Total execution time: 1.2009
INFO - 2019-07-10 01:22:44 --> Helper loaded: language_helper
INFO - 2019-07-10 01:22:44 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:22:44 --> Model Class Initialized
INFO - 2019-07-10 01:22:44 --> Model Class Initialized
INFO - 2019-07-10 01:22:44 --> Model Class Initialized
INFO - 2019-07-10 01:22:44 --> Model Class Initialized
INFO - 2019-07-10 01:22:44 --> Helper loaded: form_helper
INFO - 2019-07-10 01:22:44 --> Form Validation Class Initialized
DEBUG - 2019-07-10 01:22:44 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 01:22:44 --> Model Class Initialized
INFO - 2019-07-10 01:22:44 --> Model Class Initialized
INFO - 2019-07-10 01:22:44 --> Final output sent to browser
DEBUG - 2019-07-10 01:22:44 --> Total execution time: 0.6657
INFO - 2019-07-10 01:23:11 --> Helper loaded: language_helper
INFO - 2019-07-10 01:23:11 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:23:11 --> Model Class Initialized
INFO - 2019-07-10 01:23:11 --> Model Class Initialized
INFO - 2019-07-10 01:23:11 --> Model Class Initialized
INFO - 2019-07-10 01:23:11 --> Model Class Initialized
INFO - 2019-07-10 01:23:11 --> Model Class Initialized
INFO - 2019-07-10 01:23:11 --> Final output sent to browser
DEBUG - 2019-07-10 01:23:11 --> Total execution time: 0.6621
INFO - 2019-07-10 01:23:14 --> Helper loaded: language_helper
INFO - 2019-07-10 01:23:14 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:23:14 --> Model Class Initialized
INFO - 2019-07-10 01:23:14 --> Model Class Initialized
INFO - 2019-07-10 01:23:14 --> Model Class Initialized
INFO - 2019-07-10 01:23:14 --> Model Class Initialized
INFO - 2019-07-10 01:23:14 --> Helper loaded: form_helper
INFO - 2019-07-10 01:23:14 --> Form Validation Class Initialized
DEBUG - 2019-07-10 01:23:14 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 01:23:14 --> Model Class Initialized
INFO - 2019-07-10 01:23:14 --> Model Class Initialized
INFO - 2019-07-10 01:23:14 --> Final output sent to browser
DEBUG - 2019-07-10 01:23:14 --> Total execution time: 0.6910
INFO - 2019-07-10 01:23:14 --> Helper loaded: language_helper
INFO - 2019-07-10 01:23:14 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:23:14 --> Model Class Initialized
INFO - 2019-07-10 01:23:14 --> Model Class Initialized
INFO - 2019-07-10 01:23:14 --> Model Class Initialized
INFO - 2019-07-10 01:23:14 --> Model Class Initialized
INFO - 2019-07-10 01:23:15 --> Helper loaded: form_helper
INFO - 2019-07-10 01:23:15 --> Form Validation Class Initialized
DEBUG - 2019-07-10 01:23:15 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 01:23:15 --> Model Class Initialized
INFO - 2019-07-10 01:23:15 --> Model Class Initialized
INFO - 2019-07-10 01:23:15 --> Final output sent to browser
DEBUG - 2019-07-10 01:23:15 --> Total execution time: 0.7014
INFO - 2019-07-10 01:23:16 --> Helper loaded: language_helper
INFO - 2019-07-10 01:23:16 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:23:16 --> Model Class Initialized
INFO - 2019-07-10 01:23:16 --> Model Class Initialized
INFO - 2019-07-10 01:23:16 --> Model Class Initialized
INFO - 2019-07-10 01:23:16 --> Model Class Initialized
INFO - 2019-07-10 01:23:16 --> Helper loaded: form_helper
INFO - 2019-07-10 01:23:16 --> Form Validation Class Initialized
DEBUG - 2019-07-10 01:23:16 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 01:23:16 --> Model Class Initialized
INFO - 2019-07-10 01:23:16 --> Model Class Initialized
INFO - 2019-07-10 01:23:16 --> Final output sent to browser
DEBUG - 2019-07-10 01:23:16 --> Total execution time: 0.7153
INFO - 2019-07-10 01:23:17 --> Helper loaded: language_helper
INFO - 2019-07-10 01:23:17 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:23:17 --> Model Class Initialized
INFO - 2019-07-10 01:23:17 --> Model Class Initialized
INFO - 2019-07-10 01:23:17 --> Model Class Initialized
INFO - 2019-07-10 01:23:17 --> Model Class Initialized
INFO - 2019-07-10 01:23:17 --> Helper loaded: form_helper
INFO - 2019-07-10 01:23:17 --> Form Validation Class Initialized
DEBUG - 2019-07-10 01:23:17 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 01:23:17 --> Model Class Initialized
INFO - 2019-07-10 01:23:17 --> Model Class Initialized
INFO - 2019-07-10 01:23:17 --> Final output sent to browser
DEBUG - 2019-07-10 01:23:17 --> Total execution time: 0.7226
INFO - 2019-07-10 01:25:14 --> Helper loaded: language_helper
INFO - 2019-07-10 01:25:14 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:25:14 --> Model Class Initialized
INFO - 2019-07-10 01:25:14 --> Model Class Initialized
INFO - 2019-07-10 01:25:14 --> Model Class Initialized
INFO - 2019-07-10 01:25:14 --> Model Class Initialized
INFO - 2019-07-10 01:25:14 --> Model Class Initialized
INFO - 2019-07-10 01:25:14 --> Final output sent to browser
DEBUG - 2019-07-10 01:25:14 --> Total execution time: 0.9532
INFO - 2019-07-10 01:25:15 --> Helper loaded: language_helper
INFO - 2019-07-10 01:25:15 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:25:15 --> Model Class Initialized
INFO - 2019-07-10 01:25:15 --> Model Class Initialized
INFO - 2019-07-10 01:25:15 --> Model Class Initialized
INFO - 2019-07-10 01:25:15 --> Model Class Initialized
INFO - 2019-07-10 01:25:15 --> Helper loaded: form_helper
INFO - 2019-07-10 01:25:15 --> Form Validation Class Initialized
DEBUG - 2019-07-10 01:25:15 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 01:25:15 --> Model Class Initialized
INFO - 2019-07-10 01:25:15 --> Model Class Initialized
INFO - 2019-07-10 01:25:15 --> Final output sent to browser
DEBUG - 2019-07-10 01:25:15 --> Total execution time: 1.2456
INFO - 2019-07-10 01:25:38 --> Helper loaded: language_helper
INFO - 2019-07-10 01:25:38 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:25:38 --> Model Class Initialized
INFO - 2019-07-10 01:25:38 --> Model Class Initialized
INFO - 2019-07-10 01:25:38 --> Model Class Initialized
INFO - 2019-07-10 01:25:38 --> Model Class Initialized
INFO - 2019-07-10 01:25:38 --> Model Class Initialized
INFO - 2019-07-10 01:25:38 --> Final output sent to browser
DEBUG - 2019-07-10 01:25:38 --> Total execution time: 0.8049
INFO - 2019-07-10 01:25:39 --> Helper loaded: language_helper
INFO - 2019-07-10 01:25:39 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:25:39 --> Model Class Initialized
INFO - 2019-07-10 01:25:39 --> Model Class Initialized
INFO - 2019-07-10 01:25:39 --> Model Class Initialized
INFO - 2019-07-10 01:25:39 --> Model Class Initialized
INFO - 2019-07-10 01:25:39 --> Helper loaded: form_helper
INFO - 2019-07-10 01:25:39 --> Form Validation Class Initialized
DEBUG - 2019-07-10 01:25:39 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 01:25:39 --> Model Class Initialized
INFO - 2019-07-10 01:25:39 --> Model Class Initialized
INFO - 2019-07-10 01:25:39 --> Final output sent to browser
DEBUG - 2019-07-10 01:25:39 --> Total execution time: 1.1058
INFO - 2019-07-10 01:25:48 --> Helper loaded: language_helper
INFO - 2019-07-10 01:25:48 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:25:48 --> Model Class Initialized
INFO - 2019-07-10 01:25:48 --> Model Class Initialized
INFO - 2019-07-10 01:25:48 --> Model Class Initialized
INFO - 2019-07-10 01:25:48 --> Model Class Initialized
INFO - 2019-07-10 01:25:48 --> Model Class Initialized
INFO - 2019-07-10 01:25:48 --> Final output sent to browser
DEBUG - 2019-07-10 01:25:48 --> Total execution time: 0.9634
INFO - 2019-07-10 01:25:48 --> Helper loaded: language_helper
INFO - 2019-07-10 01:25:48 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:25:48 --> Model Class Initialized
INFO - 2019-07-10 01:25:48 --> Model Class Initialized
INFO - 2019-07-10 01:25:48 --> Model Class Initialized
INFO - 2019-07-10 01:25:48 --> Model Class Initialized
INFO - 2019-07-10 01:25:48 --> Helper loaded: form_helper
INFO - 2019-07-10 01:25:48 --> Form Validation Class Initialized
DEBUG - 2019-07-10 01:25:48 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 01:25:48 --> Model Class Initialized
INFO - 2019-07-10 01:25:48 --> Model Class Initialized
INFO - 2019-07-10 01:25:48 --> Final output sent to browser
DEBUG - 2019-07-10 01:25:48 --> Total execution time: 1.2632
INFO - 2019-07-10 01:26:00 --> Helper loaded: language_helper
INFO - 2019-07-10 01:26:00 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:26:00 --> Model Class Initialized
INFO - 2019-07-10 01:26:00 --> Model Class Initialized
INFO - 2019-07-10 01:26:00 --> Model Class Initialized
INFO - 2019-07-10 01:26:00 --> Model Class Initialized
INFO - 2019-07-10 01:26:00 --> Model Class Initialized
INFO - 2019-07-10 01:26:00 --> Final output sent to browser
DEBUG - 2019-07-10 01:26:00 --> Total execution time: 0.9472
INFO - 2019-07-10 01:26:00 --> Helper loaded: language_helper
INFO - 2019-07-10 01:26:00 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:26:00 --> Model Class Initialized
INFO - 2019-07-10 01:26:00 --> Model Class Initialized
INFO - 2019-07-10 01:26:00 --> Model Class Initialized
INFO - 2019-07-10 01:26:00 --> Model Class Initialized
INFO - 2019-07-10 01:26:00 --> Helper loaded: form_helper
INFO - 2019-07-10 01:26:00 --> Form Validation Class Initialized
DEBUG - 2019-07-10 01:26:00 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 01:26:00 --> Model Class Initialized
INFO - 2019-07-10 01:26:00 --> Model Class Initialized
INFO - 2019-07-10 01:26:00 --> Final output sent to browser
DEBUG - 2019-07-10 01:26:00 --> Total execution time: 1.2391
INFO - 2019-07-10 01:26:15 --> Helper loaded: language_helper
INFO - 2019-07-10 01:26:15 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:26:15 --> Model Class Initialized
INFO - 2019-07-10 01:26:15 --> Model Class Initialized
INFO - 2019-07-10 01:26:15 --> Model Class Initialized
INFO - 2019-07-10 01:26:15 --> Model Class Initialized
INFO - 2019-07-10 01:26:15 --> Helper loaded: form_helper
INFO - 2019-07-10 01:26:15 --> Form Validation Class Initialized
DEBUG - 2019-07-10 01:26:15 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 01:26:15 --> Model Class Initialized
INFO - 2019-07-10 01:26:15 --> Model Class Initialized
INFO - 2019-07-10 01:26:15 --> Final output sent to browser
DEBUG - 2019-07-10 01:26:15 --> Total execution time: 0.6874
INFO - 2019-07-10 01:26:16 --> Helper loaded: language_helper
INFO - 2019-07-10 01:26:16 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:26:16 --> Model Class Initialized
INFO - 2019-07-10 01:26:16 --> Model Class Initialized
INFO - 2019-07-10 01:26:16 --> Model Class Initialized
INFO - 2019-07-10 01:26:16 --> Model Class Initialized
INFO - 2019-07-10 01:26:16 --> Helper loaded: form_helper
INFO - 2019-07-10 01:26:16 --> Form Validation Class Initialized
DEBUG - 2019-07-10 01:26:16 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 01:26:16 --> Model Class Initialized
INFO - 2019-07-10 01:26:16 --> Model Class Initialized
INFO - 2019-07-10 01:26:16 --> Final output sent to browser
DEBUG - 2019-07-10 01:26:16 --> Total execution time: 0.7000
INFO - 2019-07-10 01:26:46 --> Helper loaded: language_helper
INFO - 2019-07-10 01:26:46 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:26:46 --> Model Class Initialized
INFO - 2019-07-10 01:26:46 --> Model Class Initialized
INFO - 2019-07-10 01:26:46 --> Model Class Initialized
INFO - 2019-07-10 01:26:46 --> Model Class Initialized
INFO - 2019-07-10 01:26:46 --> Helper loaded: form_helper
INFO - 2019-07-10 01:26:46 --> Form Validation Class Initialized
DEBUG - 2019-07-10 01:26:46 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 01:26:46 --> Model Class Initialized
INFO - 2019-07-10 01:26:46 --> Model Class Initialized
INFO - 2019-07-10 01:26:46 --> Final output sent to browser
DEBUG - 2019-07-10 01:26:46 --> Total execution time: 0.7152
INFO - 2019-07-10 01:27:02 --> Helper loaded: language_helper
INFO - 2019-07-10 01:27:02 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:27:02 --> Model Class Initialized
INFO - 2019-07-10 01:27:02 --> Model Class Initialized
INFO - 2019-07-10 01:27:02 --> Model Class Initialized
INFO - 2019-07-10 01:27:02 --> Model Class Initialized
INFO - 2019-07-10 01:27:02 --> Helper loaded: form_helper
INFO - 2019-07-10 01:27:02 --> Form Validation Class Initialized
DEBUG - 2019-07-10 01:27:02 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 01:27:02 --> Model Class Initialized
INFO - 2019-07-10 01:27:02 --> Model Class Initialized
INFO - 2019-07-10 01:27:02 --> Final output sent to browser
DEBUG - 2019-07-10 01:27:02 --> Total execution time: 0.7011
INFO - 2019-07-10 01:27:10 --> Helper loaded: language_helper
INFO - 2019-07-10 01:27:10 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:27:10 --> Model Class Initialized
INFO - 2019-07-10 01:27:10 --> Model Class Initialized
INFO - 2019-07-10 01:27:10 --> Model Class Initialized
INFO - 2019-07-10 01:27:10 --> Model Class Initialized
INFO - 2019-07-10 01:27:10 --> Helper loaded: form_helper
INFO - 2019-07-10 01:27:10 --> Form Validation Class Initialized
DEBUG - 2019-07-10 01:27:10 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 01:27:10 --> Model Class Initialized
INFO - 2019-07-10 01:27:10 --> Model Class Initialized
INFO - 2019-07-10 01:27:10 --> Final output sent to browser
DEBUG - 2019-07-10 01:27:10 --> Total execution time: 0.7137
INFO - 2019-07-10 01:27:13 --> Helper loaded: language_helper
INFO - 2019-07-10 01:27:13 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:27:13 --> Model Class Initialized
INFO - 2019-07-10 01:27:13 --> Model Class Initialized
INFO - 2019-07-10 01:27:13 --> Model Class Initialized
INFO - 2019-07-10 01:27:13 --> Model Class Initialized
INFO - 2019-07-10 01:27:13 --> Helper loaded: form_helper
INFO - 2019-07-10 01:27:13 --> Form Validation Class Initialized
DEBUG - 2019-07-10 01:27:13 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 01:27:13 --> Model Class Initialized
INFO - 2019-07-10 01:27:13 --> Model Class Initialized
INFO - 2019-07-10 01:27:13 --> Final output sent to browser
DEBUG - 2019-07-10 01:27:13 --> Total execution time: 0.7138
INFO - 2019-07-10 01:28:42 --> Helper loaded: language_helper
INFO - 2019-07-10 01:28:42 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:28:42 --> Model Class Initialized
INFO - 2019-07-10 01:28:42 --> Model Class Initialized
INFO - 2019-07-10 01:28:42 --> Model Class Initialized
INFO - 2019-07-10 01:28:42 --> Model Class Initialized
INFO - 2019-07-10 01:28:42 --> Final output sent to browser
DEBUG - 2019-07-10 01:28:42 --> Total execution time: 0.6720
INFO - 2019-07-10 01:28:43 --> Helper loaded: language_helper
INFO - 2019-07-10 01:28:43 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:28:43 --> Model Class Initialized
INFO - 2019-07-10 01:28:43 --> Model Class Initialized
INFO - 2019-07-10 01:28:43 --> Model Class Initialized
INFO - 2019-07-10 01:28:43 --> Model Class Initialized
INFO - 2019-07-10 01:28:43 --> Model Class Initialized
INFO - 2019-07-10 01:28:43 --> Final output sent to browser
DEBUG - 2019-07-10 01:28:43 --> Total execution time: 0.7099
INFO - 2019-07-10 01:29:06 --> Helper loaded: language_helper
INFO - 2019-07-10 01:29:06 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:29:06 --> Model Class Initialized
INFO - 2019-07-10 01:29:06 --> Model Class Initialized
INFO - 2019-07-10 01:29:06 --> Model Class Initialized
INFO - 2019-07-10 01:29:06 --> Model Class Initialized
INFO - 2019-07-10 01:29:06 --> Final output sent to browser
DEBUG - 2019-07-10 01:29:06 --> Total execution time: 0.6854
INFO - 2019-07-10 01:29:07 --> Helper loaded: language_helper
INFO - 2019-07-10 01:29:07 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:29:07 --> Model Class Initialized
INFO - 2019-07-10 01:29:07 --> Model Class Initialized
INFO - 2019-07-10 01:29:07 --> Model Class Initialized
INFO - 2019-07-10 01:29:07 --> Model Class Initialized
INFO - 2019-07-10 01:29:07 --> Model Class Initialized
INFO - 2019-07-10 01:29:07 --> Final output sent to browser
DEBUG - 2019-07-10 01:29:07 --> Total execution time: 0.6965
INFO - 2019-07-10 01:29:48 --> Helper loaded: language_helper
INFO - 2019-07-10 01:29:48 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:29:48 --> Model Class Initialized
INFO - 2019-07-10 01:29:48 --> Model Class Initialized
INFO - 2019-07-10 01:29:48 --> Model Class Initialized
INFO - 2019-07-10 01:29:48 --> Model Class Initialized
INFO - 2019-07-10 01:29:49 --> Final output sent to browser
DEBUG - 2019-07-10 01:29:49 --> Total execution time: 0.6947
INFO - 2019-07-10 01:29:50 --> Helper loaded: language_helper
INFO - 2019-07-10 01:29:50 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:29:50 --> Model Class Initialized
INFO - 2019-07-10 01:29:50 --> Model Class Initialized
INFO - 2019-07-10 01:29:50 --> Model Class Initialized
INFO - 2019-07-10 01:29:50 --> Model Class Initialized
INFO - 2019-07-10 01:29:50 --> Model Class Initialized
INFO - 2019-07-10 01:29:50 --> Final output sent to browser
DEBUG - 2019-07-10 01:29:50 --> Total execution time: 0.9979
INFO - 2019-07-10 01:29:50 --> Helper loaded: language_helper
INFO - 2019-07-10 01:29:50 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:29:50 --> Model Class Initialized
INFO - 2019-07-10 01:29:50 --> Model Class Initialized
INFO - 2019-07-10 01:29:50 --> Model Class Initialized
INFO - 2019-07-10 01:29:50 --> Model Class Initialized
INFO - 2019-07-10 01:29:50 --> Final output sent to browser
DEBUG - 2019-07-10 01:29:50 --> Total execution time: 1.1732
INFO - 2019-07-10 01:47:05 --> Helper loaded: language_helper
INFO - 2019-07-10 01:47:05 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:47:05 --> Model Class Initialized
INFO - 2019-07-10 01:47:05 --> Model Class Initialized
INFO - 2019-07-10 01:47:05 --> Model Class Initialized
INFO - 2019-07-10 01:47:05 --> Model Class Initialized
INFO - 2019-07-10 01:47:05 --> Final output sent to browser
DEBUG - 2019-07-10 01:47:05 --> Total execution time: 0.6171
INFO - 2019-07-10 01:47:29 --> Helper loaded: language_helper
INFO - 2019-07-10 01:47:29 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:47:29 --> Model Class Initialized
INFO - 2019-07-10 01:47:29 --> Model Class Initialized
INFO - 2019-07-10 01:47:29 --> Model Class Initialized
INFO - 2019-07-10 01:47:29 --> Model Class Initialized
INFO - 2019-07-10 01:47:29 --> Final output sent to browser
DEBUG - 2019-07-10 01:47:29 --> Total execution time: 0.6598
INFO - 2019-07-10 01:47:36 --> Helper loaded: language_helper
INFO - 2019-07-10 01:47:36 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:47:36 --> Model Class Initialized
INFO - 2019-07-10 01:47:36 --> Model Class Initialized
INFO - 2019-07-10 01:47:36 --> Model Class Initialized
INFO - 2019-07-10 01:47:36 --> Model Class Initialized
INFO - 2019-07-10 01:47:36 --> Final output sent to browser
DEBUG - 2019-07-10 01:47:36 --> Total execution time: 0.6478
INFO - 2019-07-10 01:48:12 --> Helper loaded: language_helper
INFO - 2019-07-10 01:48:12 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:48:12 --> Model Class Initialized
INFO - 2019-07-10 01:48:12 --> Model Class Initialized
INFO - 2019-07-10 01:48:12 --> Model Class Initialized
INFO - 2019-07-10 01:48:12 --> Model Class Initialized
INFO - 2019-07-10 01:48:12 --> Final output sent to browser
DEBUG - 2019-07-10 01:48:12 --> Total execution time: 0.6913
INFO - 2019-07-10 01:48:14 --> Helper loaded: language_helper
INFO - 2019-07-10 01:48:14 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:48:14 --> Model Class Initialized
INFO - 2019-07-10 01:48:14 --> Model Class Initialized
INFO - 2019-07-10 01:48:14 --> Model Class Initialized
INFO - 2019-07-10 01:48:14 --> Model Class Initialized
INFO - 2019-07-10 01:48:14 --> Final output sent to browser
DEBUG - 2019-07-10 01:48:14 --> Total execution time: 0.6600
INFO - 2019-07-10 01:48:16 --> Helper loaded: language_helper
INFO - 2019-07-10 01:48:16 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:48:16 --> Model Class Initialized
INFO - 2019-07-10 01:48:16 --> Model Class Initialized
INFO - 2019-07-10 01:48:16 --> Model Class Initialized
INFO - 2019-07-10 01:48:16 --> Model Class Initialized
INFO - 2019-07-10 01:48:16 --> Final output sent to browser
DEBUG - 2019-07-10 01:48:16 --> Total execution time: 0.6547
INFO - 2019-07-10 01:48:50 --> Helper loaded: language_helper
INFO - 2019-07-10 01:48:50 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:48:50 --> Model Class Initialized
INFO - 2019-07-10 01:48:50 --> Model Class Initialized
INFO - 2019-07-10 01:48:50 --> Model Class Initialized
INFO - 2019-07-10 01:48:50 --> Model Class Initialized
INFO - 2019-07-10 01:48:50 --> Final output sent to browser
DEBUG - 2019-07-10 01:48:50 --> Total execution time: 0.6809
INFO - 2019-07-10 01:49:54 --> Helper loaded: language_helper
INFO - 2019-07-10 01:49:54 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:49:54 --> Model Class Initialized
INFO - 2019-07-10 01:49:54 --> Model Class Initialized
INFO - 2019-07-10 01:49:54 --> Model Class Initialized
INFO - 2019-07-10 01:49:54 --> Model Class Initialized
INFO - 2019-07-10 01:49:54 --> Final output sent to browser
DEBUG - 2019-07-10 01:49:54 --> Total execution time: 0.6833
INFO - 2019-07-10 01:51:08 --> Helper loaded: language_helper
INFO - 2019-07-10 01:51:08 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:51:08 --> Model Class Initialized
INFO - 2019-07-10 01:51:08 --> Model Class Initialized
INFO - 2019-07-10 01:51:08 --> Model Class Initialized
INFO - 2019-07-10 01:51:08 --> Model Class Initialized
INFO - 2019-07-10 01:51:08 --> Final output sent to browser
DEBUG - 2019-07-10 01:51:08 --> Total execution time: 0.6698
INFO - 2019-07-10 01:51:38 --> Helper loaded: language_helper
INFO - 2019-07-10 01:51:38 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:51:38 --> Model Class Initialized
INFO - 2019-07-10 01:51:38 --> Model Class Initialized
INFO - 2019-07-10 01:51:38 --> Model Class Initialized
INFO - 2019-07-10 01:51:38 --> Model Class Initialized
INFO - 2019-07-10 01:51:38 --> Final output sent to browser
DEBUG - 2019-07-10 01:51:38 --> Total execution time: 0.6668
INFO - 2019-07-10 01:53:19 --> Helper loaded: language_helper
INFO - 2019-07-10 01:53:19 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:53:19 --> Model Class Initialized
INFO - 2019-07-10 01:53:19 --> Model Class Initialized
INFO - 2019-07-10 01:53:19 --> Model Class Initialized
INFO - 2019-07-10 01:53:19 --> Model Class Initialized
INFO - 2019-07-10 01:53:19 --> Final output sent to browser
DEBUG - 2019-07-10 01:53:19 --> Total execution time: 0.6388
INFO - 2019-07-10 01:53:39 --> Helper loaded: language_helper
INFO - 2019-07-10 01:53:39 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:53:39 --> Model Class Initialized
INFO - 2019-07-10 01:53:39 --> Model Class Initialized
INFO - 2019-07-10 01:53:39 --> Model Class Initialized
INFO - 2019-07-10 01:53:39 --> Model Class Initialized
INFO - 2019-07-10 01:53:39 --> Final output sent to browser
DEBUG - 2019-07-10 01:53:39 --> Total execution time: 0.6539
INFO - 2019-07-10 01:54:13 --> Helper loaded: language_helper
INFO - 2019-07-10 01:54:13 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:54:13 --> Model Class Initialized
INFO - 2019-07-10 01:54:13 --> Model Class Initialized
INFO - 2019-07-10 01:54:13 --> Model Class Initialized
INFO - 2019-07-10 01:54:13 --> Model Class Initialized
INFO - 2019-07-10 01:54:13 --> Final output sent to browser
DEBUG - 2019-07-10 01:54:13 --> Total execution time: 0.6557
INFO - 2019-07-10 01:54:56 --> Helper loaded: language_helper
INFO - 2019-07-10 01:54:56 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:54:56 --> Model Class Initialized
INFO - 2019-07-10 01:54:56 --> Model Class Initialized
INFO - 2019-07-10 01:54:56 --> Model Class Initialized
INFO - 2019-07-10 01:54:56 --> Model Class Initialized
INFO - 2019-07-10 01:54:56 --> Final output sent to browser
DEBUG - 2019-07-10 01:54:56 --> Total execution time: 0.6502
INFO - 2019-07-10 01:56:21 --> Helper loaded: language_helper
INFO - 2019-07-10 01:56:21 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:56:21 --> Model Class Initialized
INFO - 2019-07-10 01:56:21 --> Model Class Initialized
INFO - 2019-07-10 01:56:21 --> Model Class Initialized
INFO - 2019-07-10 01:56:21 --> Model Class Initialized
INFO - 2019-07-10 01:56:21 --> Model Class Initialized
INFO - 2019-07-10 01:56:21 --> Final output sent to browser
DEBUG - 2019-07-10 01:56:21 --> Total execution time: 0.6516
INFO - 2019-07-10 01:56:32 --> Helper loaded: language_helper
INFO - 2019-07-10 01:56:32 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:56:32 --> Model Class Initialized
INFO - 2019-07-10 01:56:32 --> Model Class Initialized
INFO - 2019-07-10 01:56:32 --> Model Class Initialized
INFO - 2019-07-10 01:56:32 --> Model Class Initialized
INFO - 2019-07-10 01:56:32 --> Model Class Initialized
INFO - 2019-07-10 01:56:32 --> Final output sent to browser
DEBUG - 2019-07-10 01:56:32 --> Total execution time: 0.6933
INFO - 2019-07-10 01:57:31 --> Helper loaded: language_helper
INFO - 2019-07-10 01:57:32 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:57:32 --> Model Class Initialized
INFO - 2019-07-10 01:57:32 --> Model Class Initialized
INFO - 2019-07-10 01:57:32 --> Model Class Initialized
INFO - 2019-07-10 01:57:32 --> Model Class Initialized
INFO - 2019-07-10 01:57:32 --> Model Class Initialized
INFO - 2019-07-10 01:57:32 --> Final output sent to browser
DEBUG - 2019-07-10 01:57:32 --> Total execution time: 0.6834
INFO - 2019-07-10 01:59:33 --> Helper loaded: language_helper
INFO - 2019-07-10 01:59:33 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 01:59:33 --> Model Class Initialized
INFO - 2019-07-10 01:59:33 --> Model Class Initialized
INFO - 2019-07-10 01:59:33 --> Model Class Initialized
INFO - 2019-07-10 01:59:33 --> Model Class Initialized
INFO - 2019-07-10 01:59:33 --> Model Class Initialized
INFO - 2019-07-10 01:59:33 --> Final output sent to browser
DEBUG - 2019-07-10 01:59:33 --> Total execution time: 0.6610
INFO - 2019-07-10 02:00:11 --> Helper loaded: language_helper
INFO - 2019-07-10 02:00:11 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 02:00:11 --> Model Class Initialized
INFO - 2019-07-10 02:00:11 --> Model Class Initialized
INFO - 2019-07-10 02:00:11 --> Model Class Initialized
INFO - 2019-07-10 02:00:11 --> Model Class Initialized
INFO - 2019-07-10 02:00:11 --> Model Class Initialized
INFO - 2019-07-10 02:00:11 --> Final output sent to browser
DEBUG - 2019-07-10 02:00:11 --> Total execution time: 0.6620
INFO - 2019-07-10 02:00:44 --> Helper loaded: language_helper
INFO - 2019-07-10 02:00:44 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 02:00:44 --> Model Class Initialized
INFO - 2019-07-10 02:00:44 --> Model Class Initialized
INFO - 2019-07-10 02:00:44 --> Model Class Initialized
INFO - 2019-07-10 02:00:44 --> Model Class Initialized
INFO - 2019-07-10 02:00:44 --> Model Class Initialized
INFO - 2019-07-10 02:00:44 --> Final output sent to browser
DEBUG - 2019-07-10 02:00:44 --> Total execution time: 0.6808
INFO - 2019-07-10 02:01:05 --> Helper loaded: language_helper
INFO - 2019-07-10 02:01:05 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 02:01:05 --> Model Class Initialized
INFO - 2019-07-10 02:01:05 --> Model Class Initialized
INFO - 2019-07-10 02:01:05 --> Model Class Initialized
INFO - 2019-07-10 02:01:05 --> Model Class Initialized
INFO - 2019-07-10 02:01:05 --> Model Class Initialized
INFO - 2019-07-10 02:01:05 --> Final output sent to browser
DEBUG - 2019-07-10 02:01:05 --> Total execution time: 0.6525
INFO - 2019-07-10 02:01:07 --> Helper loaded: language_helper
INFO - 2019-07-10 02:01:07 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 02:01:07 --> Model Class Initialized
INFO - 2019-07-10 02:01:07 --> Model Class Initialized
INFO - 2019-07-10 02:01:07 --> Model Class Initialized
INFO - 2019-07-10 02:01:07 --> Model Class Initialized
INFO - 2019-07-10 02:01:07 --> Model Class Initialized
INFO - 2019-07-10 02:01:07 --> Final output sent to browser
DEBUG - 2019-07-10 02:01:07 --> Total execution time: 0.6632
INFO - 2019-07-10 02:01:08 --> Helper loaded: language_helper
INFO - 2019-07-10 02:01:08 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 02:01:08 --> Model Class Initialized
INFO - 2019-07-10 02:01:08 --> Model Class Initialized
INFO - 2019-07-10 02:01:08 --> Model Class Initialized
INFO - 2019-07-10 02:01:08 --> Model Class Initialized
INFO - 2019-07-10 02:01:08 --> Model Class Initialized
INFO - 2019-07-10 02:01:08 --> Final output sent to browser
DEBUG - 2019-07-10 02:01:08 --> Total execution time: 0.6966
INFO - 2019-07-10 02:01:20 --> Helper loaded: language_helper
INFO - 2019-07-10 02:01:20 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 02:01:20 --> Model Class Initialized
INFO - 2019-07-10 02:01:20 --> Model Class Initialized
INFO - 2019-07-10 02:01:20 --> Model Class Initialized
INFO - 2019-07-10 02:01:20 --> Model Class Initialized
INFO - 2019-07-10 02:01:20 --> Model Class Initialized
INFO - 2019-07-10 02:01:20 --> Final output sent to browser
DEBUG - 2019-07-10 02:01:20 --> Total execution time: 0.7264
INFO - 2019-07-10 02:01:31 --> Helper loaded: language_helper
INFO - 2019-07-10 02:01:32 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 02:01:32 --> Model Class Initialized
INFO - 2019-07-10 02:01:32 --> Model Class Initialized
INFO - 2019-07-10 02:01:32 --> Model Class Initialized
INFO - 2019-07-10 02:01:32 --> Model Class Initialized
INFO - 2019-07-10 02:01:32 --> Model Class Initialized
INFO - 2019-07-10 02:01:32 --> Final output sent to browser
DEBUG - 2019-07-10 02:01:32 --> Total execution time: 0.6697
INFO - 2019-07-10 02:01:42 --> Helper loaded: language_helper
INFO - 2019-07-10 02:01:43 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 02:01:43 --> Model Class Initialized
INFO - 2019-07-10 02:01:43 --> Model Class Initialized
INFO - 2019-07-10 02:01:43 --> Model Class Initialized
INFO - 2019-07-10 02:01:43 --> Model Class Initialized
INFO - 2019-07-10 02:01:43 --> Model Class Initialized
INFO - 2019-07-10 02:01:43 --> Final output sent to browser
DEBUG - 2019-07-10 02:01:43 --> Total execution time: 0.7324
INFO - 2019-07-10 02:03:00 --> Helper loaded: language_helper
INFO - 2019-07-10 02:03:00 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 02:03:00 --> Model Class Initialized
INFO - 2019-07-10 02:03:00 --> Model Class Initialized
INFO - 2019-07-10 02:03:00 --> Model Class Initialized
INFO - 2019-07-10 02:03:00 --> Model Class Initialized
INFO - 2019-07-10 02:03:00 --> Model Class Initialized
INFO - 2019-07-10 02:03:00 --> Final output sent to browser
DEBUG - 2019-07-10 02:03:00 --> Total execution time: 0.7434
INFO - 2019-07-10 02:04:17 --> Helper loaded: language_helper
INFO - 2019-07-10 02:04:17 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 02:04:17 --> Model Class Initialized
INFO - 2019-07-10 02:04:17 --> Model Class Initialized
INFO - 2019-07-10 02:04:17 --> Model Class Initialized
INFO - 2019-07-10 02:04:17 --> Model Class Initialized
INFO - 2019-07-10 02:04:17 --> Final output sent to browser
DEBUG - 2019-07-10 02:04:17 --> Total execution time: 0.7181
INFO - 2019-07-10 02:04:18 --> Helper loaded: language_helper
INFO - 2019-07-10 02:04:18 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 02:04:18 --> Model Class Initialized
INFO - 2019-07-10 02:04:18 --> Model Class Initialized
INFO - 2019-07-10 02:04:18 --> Model Class Initialized
INFO - 2019-07-10 02:04:18 --> Model Class Initialized
INFO - 2019-07-10 02:04:18 --> Model Class Initialized
INFO - 2019-07-10 02:04:18 --> Final output sent to browser
DEBUG - 2019-07-10 02:04:18 --> Total execution time: 0.6993
INFO - 2019-07-10 02:06:27 --> Helper loaded: language_helper
INFO - 2019-07-10 02:06:27 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 02:06:27 --> Model Class Initialized
INFO - 2019-07-10 02:06:27 --> Model Class Initialized
INFO - 2019-07-10 02:06:27 --> Model Class Initialized
INFO - 2019-07-10 02:06:27 --> Model Class Initialized
INFO - 2019-07-10 02:06:27 --> Model Class Initialized
INFO - 2019-07-10 02:06:27 --> Final output sent to browser
DEBUG - 2019-07-10 02:06:27 --> Total execution time: 0.6892
INFO - 2019-07-10 02:06:54 --> Helper loaded: language_helper
INFO - 2019-07-10 02:06:54 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 02:06:54 --> Model Class Initialized
INFO - 2019-07-10 02:06:54 --> Model Class Initialized
INFO - 2019-07-10 02:06:54 --> Model Class Initialized
INFO - 2019-07-10 02:06:54 --> Model Class Initialized
INFO - 2019-07-10 02:06:54 --> Model Class Initialized
INFO - 2019-07-10 02:06:54 --> Final output sent to browser
DEBUG - 2019-07-10 02:06:54 --> Total execution time: 0.7103
INFO - 2019-07-10 02:07:33 --> Helper loaded: language_helper
INFO - 2019-07-10 02:07:33 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 02:07:33 --> Model Class Initialized
INFO - 2019-07-10 02:07:33 --> Model Class Initialized
INFO - 2019-07-10 02:07:33 --> Model Class Initialized
INFO - 2019-07-10 02:07:33 --> Model Class Initialized
INFO - 2019-07-10 02:07:33 --> Model Class Initialized
INFO - 2019-07-10 02:07:33 --> Final output sent to browser
DEBUG - 2019-07-10 02:07:33 --> Total execution time: 0.6912
INFO - 2019-07-10 02:11:23 --> Helper loaded: language_helper
INFO - 2019-07-10 02:11:23 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 02:11:23 --> Model Class Initialized
INFO - 2019-07-10 02:11:23 --> Model Class Initialized
INFO - 2019-07-10 02:11:23 --> Model Class Initialized
INFO - 2019-07-10 02:11:23 --> Model Class Initialized
INFO - 2019-07-10 02:11:23 --> Model Class Initialized
INFO - 2019-07-10 02:11:23 --> Final output sent to browser
DEBUG - 2019-07-10 02:11:23 --> Total execution time: 0.6660
INFO - 2019-07-10 02:11:34 --> Helper loaded: language_helper
INFO - 2019-07-10 02:11:34 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 02:11:34 --> Model Class Initialized
INFO - 2019-07-10 02:11:34 --> Model Class Initialized
INFO - 2019-07-10 02:11:34 --> Model Class Initialized
INFO - 2019-07-10 02:11:34 --> Model Class Initialized
INFO - 2019-07-10 02:11:34 --> Model Class Initialized
INFO - 2019-07-10 02:11:34 --> Final output sent to browser
DEBUG - 2019-07-10 02:11:34 --> Total execution time: 0.7287
INFO - 2019-07-10 02:12:15 --> Helper loaded: language_helper
INFO - 2019-07-10 02:12:15 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 02:12:15 --> Model Class Initialized
INFO - 2019-07-10 02:12:15 --> Model Class Initialized
INFO - 2019-07-10 02:12:15 --> Model Class Initialized
INFO - 2019-07-10 02:12:15 --> Model Class Initialized
INFO - 2019-07-10 02:12:15 --> Model Class Initialized
INFO - 2019-07-10 02:12:15 --> Final output sent to browser
DEBUG - 2019-07-10 02:12:15 --> Total execution time: 0.6568
INFO - 2019-07-10 02:12:19 --> Helper loaded: language_helper
INFO - 2019-07-10 02:12:19 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 02:12:19 --> Model Class Initialized
INFO - 2019-07-10 02:12:19 --> Model Class Initialized
INFO - 2019-07-10 02:12:19 --> Model Class Initialized
INFO - 2019-07-10 02:12:19 --> Model Class Initialized
INFO - 2019-07-10 02:12:19 --> Model Class Initialized
INFO - 2019-07-10 02:12:19 --> Final output sent to browser
DEBUG - 2019-07-10 02:12:19 --> Total execution time: 0.7381
INFO - 2019-07-10 02:21:10 --> Helper loaded: language_helper
INFO - 2019-07-10 02:21:10 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 02:21:10 --> Model Class Initialized
INFO - 2019-07-10 02:21:10 --> Model Class Initialized
INFO - 2019-07-10 02:21:10 --> Model Class Initialized
INFO - 2019-07-10 02:21:10 --> Model Class Initialized
INFO - 2019-07-10 02:21:10 --> Final output sent to browser
DEBUG - 2019-07-10 02:21:10 --> Total execution time: 0.7137
INFO - 2019-07-10 02:21:11 --> Helper loaded: language_helper
INFO - 2019-07-10 02:21:11 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 02:21:11 --> Model Class Initialized
INFO - 2019-07-10 02:21:11 --> Model Class Initialized
INFO - 2019-07-10 02:21:11 --> Model Class Initialized
INFO - 2019-07-10 02:21:11 --> Model Class Initialized
INFO - 2019-07-10 02:21:11 --> Model Class Initialized
INFO - 2019-07-10 02:21:11 --> Final output sent to browser
DEBUG - 2019-07-10 02:21:11 --> Total execution time: 0.6744
INFO - 2019-07-10 02:21:12 --> Helper loaded: language_helper
INFO - 2019-07-10 02:21:12 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 02:21:12 --> Model Class Initialized
INFO - 2019-07-10 02:21:12 --> Model Class Initialized
INFO - 2019-07-10 02:21:12 --> Model Class Initialized
INFO - 2019-07-10 02:21:12 --> Model Class Initialized
INFO - 2019-07-10 02:21:12 --> Helper loaded: form_helper
INFO - 2019-07-10 02:21:12 --> Form Validation Class Initialized
DEBUG - 2019-07-10 02:21:12 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 02:21:12 --> Model Class Initialized
INFO - 2019-07-10 02:21:12 --> Model Class Initialized
INFO - 2019-07-10 02:21:12 --> Final output sent to browser
DEBUG - 2019-07-10 02:21:12 --> Total execution time: 0.7192
INFO - 2019-07-10 02:21:14 --> Helper loaded: language_helper
INFO - 2019-07-10 02:21:14 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 02:21:14 --> Model Class Initialized
INFO - 2019-07-10 02:21:14 --> Model Class Initialized
INFO - 2019-07-10 02:21:14 --> Model Class Initialized
INFO - 2019-07-10 02:21:14 --> Model Class Initialized
INFO - 2019-07-10 02:21:14 --> Model Class Initialized
INFO - 2019-07-10 02:21:14 --> Final output sent to browser
DEBUG - 2019-07-10 02:21:14 --> Total execution time: 0.6786
INFO - 2019-07-10 02:21:15 --> Helper loaded: language_helper
INFO - 2019-07-10 02:21:15 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 02:21:15 --> Model Class Initialized
INFO - 2019-07-10 02:21:15 --> Model Class Initialized
INFO - 2019-07-10 02:21:15 --> Model Class Initialized
INFO - 2019-07-10 02:21:15 --> Model Class Initialized
INFO - 2019-07-10 02:21:15 --> Model Class Initialized
INFO - 2019-07-10 02:21:15 --> Final output sent to browser
DEBUG - 2019-07-10 02:21:15 --> Total execution time: 0.6820
INFO - 2019-07-10 02:21:18 --> Helper loaded: language_helper
INFO - 2019-07-10 02:21:18 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 02:21:18 --> Model Class Initialized
INFO - 2019-07-10 02:21:18 --> Model Class Initialized
INFO - 2019-07-10 02:21:18 --> Model Class Initialized
INFO - 2019-07-10 02:21:18 --> Model Class Initialized
INFO - 2019-07-10 02:21:18 --> Model Class Initialized
INFO - 2019-07-10 02:21:18 --> Final output sent to browser
DEBUG - 2019-07-10 02:21:18 --> Total execution time: 0.6570
INFO - 2019-07-10 02:21:19 --> Helper loaded: language_helper
INFO - 2019-07-10 02:21:19 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 02:21:19 --> Model Class Initialized
INFO - 2019-07-10 02:21:19 --> Model Class Initialized
INFO - 2019-07-10 02:21:19 --> Model Class Initialized
INFO - 2019-07-10 02:21:19 --> Model Class Initialized
INFO - 2019-07-10 02:21:19 --> Helper loaded: form_helper
INFO - 2019-07-10 02:21:19 --> Form Validation Class Initialized
DEBUG - 2019-07-10 02:21:19 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/form_validation.php
INFO - 2019-07-10 02:21:19 --> Model Class Initialized
INFO - 2019-07-10 02:21:19 --> Model Class Initialized
INFO - 2019-07-10 02:21:19 --> Final output sent to browser
DEBUG - 2019-07-10 02:21:19 --> Total execution time: 0.7463
INFO - 2019-07-10 15:58:49 --> Config Class Initialized
INFO - 2019-07-10 15:58:50 --> Hooks Class Initialized
DEBUG - 2019-07-10 15:58:50 --> UTF-8 Support Enabled
INFO - 2019-07-10 15:58:50 --> Utf8 Class Initialized
INFO - 2019-07-10 15:58:50 --> URI Class Initialized
DEBUG - 2019-07-10 15:58:50 --> No URI present. Default controller set.
INFO - 2019-07-10 15:58:50 --> Router Class Initialized
INFO - 2019-07-10 15:58:50 --> Output Class Initialized
INFO - 2019-07-10 15:58:50 --> Security Class Initialized
DEBUG - 2019-07-10 15:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-10 15:58:50 --> Input Class Initialized
INFO - 2019-07-10 15:58:50 --> Language Class Initialized
INFO - 2019-07-10 15:58:52 --> Final output sent to browser
DEBUG - 2019-07-10 15:58:52 --> Total execution time: 2.6795
INFO - 2019-07-10 16:00:01 --> Config Class Initialized
INFO - 2019-07-10 16:00:01 --> Hooks Class Initialized
DEBUG - 2019-07-10 16:00:01 --> UTF-8 Support Enabled
INFO - 2019-07-10 16:00:01 --> Utf8 Class Initialized
INFO - 2019-07-10 16:00:01 --> URI Class Initialized
DEBUG - 2019-07-10 16:00:01 --> No URI present. Default controller set.
INFO - 2019-07-10 16:00:01 --> Router Class Initialized
INFO - 2019-07-10 16:00:02 --> Output Class Initialized
INFO - 2019-07-10 16:00:02 --> Security Class Initialized
DEBUG - 2019-07-10 16:00:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-10 16:00:02 --> Input Class Initialized
INFO - 2019-07-10 16:00:02 --> Language Class Initialized
INFO - 2019-07-10 16:00:02 --> Final output sent to browser
DEBUG - 2019-07-10 16:00:02 --> Total execution time: 0.1433
INFO - 2019-07-10 16:00:09 --> Config Class Initialized
INFO - 2019-07-10 16:00:09 --> Hooks Class Initialized
DEBUG - 2019-07-10 16:00:09 --> UTF-8 Support Enabled
INFO - 2019-07-10 16:00:09 --> Utf8 Class Initialized
INFO - 2019-07-10 16:00:09 --> URI Class Initialized
DEBUG - 2019-07-10 16:00:09 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/routes.php
INFO - 2019-07-10 16:00:09 --> Router Class Initialized
INFO - 2019-07-10 16:00:09 --> Output Class Initialized
INFO - 2019-07-10 16:00:09 --> Security Class Initialized
DEBUG - 2019-07-10 16:00:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-10 16:00:09 --> Input Class Initialized
INFO - 2019-07-10 16:00:09 --> Language Class Initialized
INFO - 2019-07-10 16:00:10 --> Language Class Initialized
INFO - 2019-07-10 16:00:10 --> Config Class Initialized
INFO - 2019-07-10 16:00:10 --> Loader Class Initialized
DEBUG - 2019-07-10 16:00:10 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/site.php
INFO - 2019-07-10 16:00:10 --> Helper loaded: url_helper
INFO - 2019-07-10 16:00:10 --> Helper loaded: inflector_helper
INFO - 2019-07-10 16:00:10 --> Helper loaded: string_helper
INFO - 2019-07-10 16:00:10 --> Helper loaded: array_helper
INFO - 2019-07-10 16:00:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-10 16:00:10 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/autoload.php
DEBUG - 2019-07-10 16:00:10 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/helpers/adminlte_helper.php
INFO - 2019-07-10 16:00:10 --> Database Driver Class Initialized
ERROR - 2019-07-10 16:00:12 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\crapi_admin\system\database\drivers\mysqli\mysqli_driver.php 161
ERROR - 2019-07-10 16:00:12 --> Unable to connect to the database
INFO - 2019-07-10 16:00:12 --> Language file loaded: language/english/db_lang.php
INFO - 2019-07-10 16:00:33 --> Config Class Initialized
INFO - 2019-07-10 16:00:33 --> Hooks Class Initialized
DEBUG - 2019-07-10 16:00:33 --> UTF-8 Support Enabled
INFO - 2019-07-10 16:00:33 --> Utf8 Class Initialized
INFO - 2019-07-10 16:00:33 --> URI Class Initialized
DEBUG - 2019-07-10 16:00:33 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/routes.php
INFO - 2019-07-10 16:00:33 --> Router Class Initialized
INFO - 2019-07-10 16:00:33 --> Output Class Initialized
INFO - 2019-07-10 16:00:33 --> Security Class Initialized
DEBUG - 2019-07-10 16:00:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-10 16:00:33 --> Input Class Initialized
INFO - 2019-07-10 16:00:33 --> Language Class Initialized
INFO - 2019-07-10 16:00:33 --> Language Class Initialized
INFO - 2019-07-10 16:00:33 --> Config Class Initialized
INFO - 2019-07-10 16:00:33 --> Loader Class Initialized
DEBUG - 2019-07-10 16:00:33 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/site.php
INFO - 2019-07-10 16:00:33 --> Helper loaded: url_helper
INFO - 2019-07-10 16:00:33 --> Helper loaded: inflector_helper
INFO - 2019-07-10 16:00:33 --> Helper loaded: string_helper
INFO - 2019-07-10 16:00:33 --> Helper loaded: array_helper
INFO - 2019-07-10 16:00:33 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-10 16:00:33 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/autoload.php
DEBUG - 2019-07-10 16:00:33 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/helpers/adminlte_helper.php
INFO - 2019-07-10 16:00:33 --> Database Driver Class Initialized
DEBUG - 2019-07-10 16:00:33 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/libraries/Crud.php
INFO - 2019-07-10 16:00:33 --> Helper loaded: form_helper
DEBUG - 2019-07-10 16:00:33 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-07-10 16:00:33 --> Form Validation Class Initialized
DEBUG - 2019-07-10 16:00:33 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-07-10 16:00:33 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-07-10 16:00:33 --> Pagination Class Initialized
INFO - 2019-07-10 16:00:33 --> Controller Class Initialized
INFO - 2019-07-10 16:00:33 --> Config Class Initialized
INFO - 2019-07-10 16:00:33 --> Hooks Class Initialized
DEBUG - 2019-07-10 16:00:33 --> UTF-8 Support Enabled
INFO - 2019-07-10 16:00:33 --> Utf8 Class Initialized
INFO - 2019-07-10 16:00:33 --> URI Class Initialized
DEBUG - 2019-07-10 16:00:33 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/routes.php
INFO - 2019-07-10 16:00:33 --> Router Class Initialized
INFO - 2019-07-10 16:00:33 --> Output Class Initialized
INFO - 2019-07-10 16:00:33 --> Security Class Initialized
DEBUG - 2019-07-10 16:00:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-10 16:00:33 --> Input Class Initialized
INFO - 2019-07-10 16:00:34 --> Language Class Initialized
INFO - 2019-07-10 16:00:34 --> Language Class Initialized
INFO - 2019-07-10 16:00:34 --> Config Class Initialized
INFO - 2019-07-10 16:00:34 --> Loader Class Initialized
DEBUG - 2019-07-10 16:00:34 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/site.php
INFO - 2019-07-10 16:00:34 --> Helper loaded: url_helper
INFO - 2019-07-10 16:00:34 --> Helper loaded: inflector_helper
INFO - 2019-07-10 16:00:34 --> Helper loaded: string_helper
INFO - 2019-07-10 16:00:34 --> Helper loaded: array_helper
INFO - 2019-07-10 16:00:34 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-10 16:00:34 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/autoload.php
DEBUG - 2019-07-10 16:00:34 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/helpers/adminlte_helper.php
INFO - 2019-07-10 16:00:34 --> Database Driver Class Initialized
DEBUG - 2019-07-10 16:00:34 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/libraries/Crud.php
INFO - 2019-07-10 16:00:34 --> Helper loaded: form_helper
DEBUG - 2019-07-10 16:00:34 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-07-10 16:00:34 --> Form Validation Class Initialized
DEBUG - 2019-07-10 16:00:34 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-07-10 16:00:34 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-07-10 16:00:34 --> Pagination Class Initialized
INFO - 2019-07-10 16:00:34 --> Controller Class Initialized
INFO - 2019-07-10 22:00:34 --> Final output sent to browser
DEBUG - 2019-07-10 22:00:34 --> Total execution time: 0.4964
INFO - 2019-07-10 16:00:43 --> Config Class Initialized
INFO - 2019-07-10 16:00:43 --> Hooks Class Initialized
DEBUG - 2019-07-10 16:00:43 --> UTF-8 Support Enabled
INFO - 2019-07-10 16:00:43 --> Utf8 Class Initialized
INFO - 2019-07-10 16:00:43 --> URI Class Initialized
DEBUG - 2019-07-10 16:00:43 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/routes.php
INFO - 2019-07-10 16:00:43 --> Router Class Initialized
INFO - 2019-07-10 16:00:43 --> Output Class Initialized
INFO - 2019-07-10 16:00:43 --> Security Class Initialized
DEBUG - 2019-07-10 16:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-10 16:00:43 --> Input Class Initialized
INFO - 2019-07-10 16:00:43 --> Language Class Initialized
INFO - 2019-07-10 16:00:43 --> Language Class Initialized
INFO - 2019-07-10 16:00:43 --> Config Class Initialized
INFO - 2019-07-10 16:00:43 --> Loader Class Initialized
DEBUG - 2019-07-10 16:00:43 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/site.php
INFO - 2019-07-10 16:00:43 --> Helper loaded: url_helper
INFO - 2019-07-10 16:00:43 --> Helper loaded: inflector_helper
INFO - 2019-07-10 16:00:43 --> Helper loaded: string_helper
INFO - 2019-07-10 16:00:43 --> Helper loaded: array_helper
INFO - 2019-07-10 16:00:43 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-10 16:00:43 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/autoload.php
DEBUG - 2019-07-10 16:00:43 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/helpers/adminlte_helper.php
INFO - 2019-07-10 16:00:43 --> Database Driver Class Initialized
DEBUG - 2019-07-10 16:00:43 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/libraries/Crud.php
INFO - 2019-07-10 16:00:43 --> Helper loaded: form_helper
DEBUG - 2019-07-10 16:00:43 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-07-10 16:00:43 --> Form Validation Class Initialized
DEBUG - 2019-07-10 16:00:43 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-07-10 16:00:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-07-10 16:00:44 --> Pagination Class Initialized
INFO - 2019-07-10 16:00:44 --> Controller Class Initialized
INFO - 2019-07-10 22:00:44 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-07-10 22:00:44 --> Model Class Initialized
INFO - 2019-07-10 22:00:44 --> Model Class Initialized
INFO - 2019-07-10 16:00:44 --> Config Class Initialized
INFO - 2019-07-10 16:00:44 --> Hooks Class Initialized
DEBUG - 2019-07-10 16:00:44 --> UTF-8 Support Enabled
INFO - 2019-07-10 16:00:44 --> Utf8 Class Initialized
INFO - 2019-07-10 16:00:44 --> URI Class Initialized
DEBUG - 2019-07-10 16:00:44 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/routes.php
INFO - 2019-07-10 16:00:44 --> Router Class Initialized
INFO - 2019-07-10 16:00:44 --> Output Class Initialized
INFO - 2019-07-10 16:00:44 --> Security Class Initialized
DEBUG - 2019-07-10 16:00:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-10 16:00:44 --> Input Class Initialized
INFO - 2019-07-10 16:00:44 --> Language Class Initialized
INFO - 2019-07-10 16:00:44 --> Language Class Initialized
INFO - 2019-07-10 16:00:44 --> Config Class Initialized
INFO - 2019-07-10 16:00:44 --> Loader Class Initialized
DEBUG - 2019-07-10 16:00:44 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/site.php
INFO - 2019-07-10 16:00:44 --> Helper loaded: url_helper
INFO - 2019-07-10 16:00:44 --> Helper loaded: inflector_helper
INFO - 2019-07-10 16:00:44 --> Helper loaded: string_helper
INFO - 2019-07-10 16:00:44 --> Helper loaded: array_helper
INFO - 2019-07-10 16:00:44 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-10 16:00:44 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/autoload.php
DEBUG - 2019-07-10 16:00:44 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/helpers/adminlte_helper.php
INFO - 2019-07-10 16:00:44 --> Database Driver Class Initialized
DEBUG - 2019-07-10 16:00:44 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/libraries/Crud.php
INFO - 2019-07-10 16:00:44 --> Helper loaded: form_helper
DEBUG - 2019-07-10 16:00:44 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-07-10 16:00:44 --> Form Validation Class Initialized
DEBUG - 2019-07-10 16:00:44 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-07-10 16:00:44 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-07-10 16:00:44 --> Pagination Class Initialized
INFO - 2019-07-10 16:00:44 --> Controller Class Initialized
INFO - 2019-07-10 22:00:44 --> Final output sent to browser
DEBUG - 2019-07-10 22:00:44 --> Total execution time: 0.4406
INFO - 2019-07-10 16:00:50 --> Config Class Initialized
INFO - 2019-07-10 16:00:50 --> Hooks Class Initialized
DEBUG - 2019-07-10 16:00:50 --> UTF-8 Support Enabled
INFO - 2019-07-10 16:00:50 --> Utf8 Class Initialized
INFO - 2019-07-10 16:00:50 --> URI Class Initialized
DEBUG - 2019-07-10 16:00:50 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/routes.php
INFO - 2019-07-10 16:00:50 --> Router Class Initialized
INFO - 2019-07-10 16:00:50 --> Output Class Initialized
INFO - 2019-07-10 16:00:50 --> Security Class Initialized
DEBUG - 2019-07-10 16:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-10 16:00:50 --> Input Class Initialized
INFO - 2019-07-10 16:00:50 --> Language Class Initialized
INFO - 2019-07-10 16:00:50 --> Language Class Initialized
INFO - 2019-07-10 16:00:50 --> Config Class Initialized
INFO - 2019-07-10 16:00:50 --> Loader Class Initialized
DEBUG - 2019-07-10 16:00:50 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/site.php
INFO - 2019-07-10 16:00:50 --> Helper loaded: url_helper
INFO - 2019-07-10 16:00:50 --> Helper loaded: inflector_helper
INFO - 2019-07-10 16:00:50 --> Helper loaded: string_helper
INFO - 2019-07-10 16:00:50 --> Helper loaded: array_helper
INFO - 2019-07-10 16:00:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-10 16:00:50 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/autoload.php
DEBUG - 2019-07-10 16:00:50 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/helpers/adminlte_helper.php
INFO - 2019-07-10 16:00:50 --> Database Driver Class Initialized
DEBUG - 2019-07-10 16:00:50 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/libraries/Crud.php
INFO - 2019-07-10 16:00:50 --> Helper loaded: form_helper
DEBUG - 2019-07-10 16:00:50 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-07-10 16:00:50 --> Form Validation Class Initialized
DEBUG - 2019-07-10 16:00:50 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-07-10 16:00:50 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-07-10 16:00:50 --> Pagination Class Initialized
INFO - 2019-07-10 16:00:50 --> Controller Class Initialized
INFO - 2019-07-10 22:00:50 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2019-07-10 22:00:50 --> Model Class Initialized
INFO - 2019-07-10 22:00:50 --> Model Class Initialized
INFO - 2019-07-10 16:00:50 --> Config Class Initialized
INFO - 2019-07-10 16:00:50 --> Hooks Class Initialized
DEBUG - 2019-07-10 16:00:50 --> UTF-8 Support Enabled
INFO - 2019-07-10 16:00:50 --> Utf8 Class Initialized
INFO - 2019-07-10 16:00:50 --> URI Class Initialized
DEBUG - 2019-07-10 16:00:50 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/routes.php
INFO - 2019-07-10 16:00:50 --> Router Class Initialized
INFO - 2019-07-10 16:00:50 --> Output Class Initialized
INFO - 2019-07-10 16:00:50 --> Security Class Initialized
DEBUG - 2019-07-10 16:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-10 16:00:50 --> Input Class Initialized
INFO - 2019-07-10 16:00:50 --> Language Class Initialized
INFO - 2019-07-10 16:00:50 --> Language Class Initialized
INFO - 2019-07-10 16:00:50 --> Config Class Initialized
INFO - 2019-07-10 16:00:50 --> Loader Class Initialized
DEBUG - 2019-07-10 16:00:50 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/site.php
INFO - 2019-07-10 16:00:50 --> Helper loaded: url_helper
INFO - 2019-07-10 16:00:50 --> Helper loaded: inflector_helper
INFO - 2019-07-10 16:00:50 --> Helper loaded: string_helper
INFO - 2019-07-10 16:00:50 --> Helper loaded: array_helper
INFO - 2019-07-10 16:00:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-10 16:00:50 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/autoload.php
DEBUG - 2019-07-10 16:00:50 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/helpers/adminlte_helper.php
INFO - 2019-07-10 16:00:51 --> Database Driver Class Initialized
DEBUG - 2019-07-10 16:00:51 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/libraries/Crud.php
INFO - 2019-07-10 16:00:51 --> Helper loaded: form_helper
DEBUG - 2019-07-10 16:00:51 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-07-10 16:00:51 --> Form Validation Class Initialized
DEBUG - 2019-07-10 16:00:51 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-07-10 16:00:51 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-07-10 16:00:51 --> Pagination Class Initialized
INFO - 2019-07-10 16:00:51 --> Controller Class Initialized
INFO - 2019-07-10 22:00:51 --> Final output sent to browser
DEBUG - 2019-07-10 22:00:51 --> Total execution time: 0.4843
INFO - 2019-07-10 16:00:57 --> Config Class Initialized
INFO - 2019-07-10 16:00:57 --> Hooks Class Initialized
DEBUG - 2019-07-10 16:00:57 --> UTF-8 Support Enabled
INFO - 2019-07-10 16:00:57 --> Utf8 Class Initialized
INFO - 2019-07-10 16:00:57 --> URI Class Initialized
DEBUG - 2019-07-10 16:00:57 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/routes.php
INFO - 2019-07-10 16:00:57 --> Router Class Initialized
INFO - 2019-07-10 16:00:57 --> Output Class Initialized
INFO - 2019-07-10 16:00:57 --> Security Class Initialized
DEBUG - 2019-07-10 16:00:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-10 16:00:57 --> Input Class Initialized
INFO - 2019-07-10 16:00:57 --> Language Class Initialized
INFO - 2019-07-10 16:00:58 --> Language Class Initialized
INFO - 2019-07-10 16:00:58 --> Config Class Initialized
INFO - 2019-07-10 16:00:58 --> Loader Class Initialized
DEBUG - 2019-07-10 16:00:58 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/site.php
INFO - 2019-07-10 16:00:58 --> Helper loaded: url_helper
INFO - 2019-07-10 16:00:58 --> Helper loaded: inflector_helper
INFO - 2019-07-10 16:00:58 --> Helper loaded: string_helper
INFO - 2019-07-10 16:00:58 --> Helper loaded: array_helper
INFO - 2019-07-10 16:00:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-10 16:00:58 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/autoload.php
DEBUG - 2019-07-10 16:00:58 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/helpers/adminlte_helper.php
INFO - 2019-07-10 16:00:58 --> Database Driver Class Initialized
DEBUG - 2019-07-10 16:00:58 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/libraries/Crud.php
INFO - 2019-07-10 16:00:58 --> Helper loaded: form_helper
DEBUG - 2019-07-10 16:00:58 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-07-10 16:00:58 --> Form Validation Class Initialized
DEBUG - 2019-07-10 16:00:58 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-07-10 16:00:58 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-07-10 16:00:58 --> Pagination Class Initialized
INFO - 2019-07-10 16:00:58 --> Controller Class Initialized
INFO - 2019-07-10 22:00:58 --> Model Class Initialized
INFO - 2019-07-10 22:00:58 --> Model Class Initialized
INFO - 2019-07-10 22:00:58 --> Final output sent to browser
DEBUG - 2019-07-10 22:00:58 --> Total execution time: 1.1337
INFO - 2019-07-10 16:01:00 --> Config Class Initialized
INFO - 2019-07-10 16:01:00 --> Hooks Class Initialized
DEBUG - 2019-07-10 16:01:00 --> UTF-8 Support Enabled
INFO - 2019-07-10 16:01:00 --> Utf8 Class Initialized
INFO - 2019-07-10 16:01:00 --> URI Class Initialized
DEBUG - 2019-07-10 16:01:00 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/routes.php
INFO - 2019-07-10 16:01:00 --> Router Class Initialized
INFO - 2019-07-10 16:01:00 --> Output Class Initialized
INFO - 2019-07-10 16:01:00 --> Security Class Initialized
DEBUG - 2019-07-10 16:01:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-10 16:01:00 --> Input Class Initialized
INFO - 2019-07-10 16:01:00 --> Language Class Initialized
INFO - 2019-07-10 16:01:00 --> Language Class Initialized
INFO - 2019-07-10 16:01:00 --> Config Class Initialized
INFO - 2019-07-10 16:01:00 --> Loader Class Initialized
DEBUG - 2019-07-10 16:01:00 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/site.php
INFO - 2019-07-10 16:01:00 --> Helper loaded: url_helper
INFO - 2019-07-10 16:01:00 --> Helper loaded: inflector_helper
INFO - 2019-07-10 16:01:00 --> Helper loaded: string_helper
INFO - 2019-07-10 16:01:00 --> Helper loaded: array_helper
INFO - 2019-07-10 16:01:00 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-10 16:01:00 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/autoload.php
DEBUG - 2019-07-10 16:01:00 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/helpers/adminlte_helper.php
INFO - 2019-07-10 16:01:00 --> Database Driver Class Initialized
DEBUG - 2019-07-10 16:01:00 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/libraries/Crud.php
INFO - 2019-07-10 16:01:00 --> Helper loaded: form_helper
DEBUG - 2019-07-10 16:01:00 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-07-10 16:01:00 --> Form Validation Class Initialized
DEBUG - 2019-07-10 16:01:00 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-07-10 16:01:00 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-07-10 16:01:00 --> Pagination Class Initialized
INFO - 2019-07-10 16:01:00 --> Controller Class Initialized
INFO - 2019-07-10 22:01:00 --> Model Class Initialized
INFO - 2019-07-10 22:01:00 --> Model Class Initialized
INFO - 2019-07-10 22:01:00 --> Model Class Initialized
INFO - 2019-07-10 22:01:00 --> Final output sent to browser
DEBUG - 2019-07-10 22:01:01 --> Total execution time: 0.8220
INFO - 2019-07-10 16:01:01 --> Config Class Initialized
INFO - 2019-07-10 16:01:01 --> Hooks Class Initialized
DEBUG - 2019-07-10 16:01:01 --> UTF-8 Support Enabled
INFO - 2019-07-10 16:01:01 --> Utf8 Class Initialized
INFO - 2019-07-10 16:01:01 --> URI Class Initialized
DEBUG - 2019-07-10 16:01:01 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/routes.php
INFO - 2019-07-10 16:01:01 --> Router Class Initialized
INFO - 2019-07-10 16:01:01 --> Output Class Initialized
INFO - 2019-07-10 16:01:01 --> Security Class Initialized
DEBUG - 2019-07-10 16:01:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-10 16:01:01 --> Input Class Initialized
INFO - 2019-07-10 16:01:01 --> Language Class Initialized
INFO - 2019-07-10 16:01:01 --> Language Class Initialized
INFO - 2019-07-10 16:01:01 --> Config Class Initialized
INFO - 2019-07-10 16:01:01 --> Loader Class Initialized
DEBUG - 2019-07-10 16:01:01 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/site.php
INFO - 2019-07-10 16:01:01 --> Helper loaded: url_helper
INFO - 2019-07-10 16:01:01 --> Helper loaded: inflector_helper
INFO - 2019-07-10 16:01:01 --> Helper loaded: string_helper
INFO - 2019-07-10 16:01:01 --> Helper loaded: array_helper
INFO - 2019-07-10 16:01:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-10 16:01:01 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/autoload.php
DEBUG - 2019-07-10 16:01:01 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/helpers/adminlte_helper.php
INFO - 2019-07-10 16:01:01 --> Database Driver Class Initialized
DEBUG - 2019-07-10 16:01:01 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/libraries/Crud.php
INFO - 2019-07-10 16:01:01 --> Helper loaded: form_helper
DEBUG - 2019-07-10 16:01:01 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-07-10 16:01:01 --> Form Validation Class Initialized
DEBUG - 2019-07-10 16:01:01 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-07-10 16:01:01 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-07-10 16:01:01 --> Pagination Class Initialized
INFO - 2019-07-10 16:01:01 --> Controller Class Initialized
INFO - 2019-07-10 22:01:01 --> Model Class Initialized
INFO - 2019-07-10 22:01:01 --> Model Class Initialized
INFO - 2019-07-10 22:01:02 --> Final output sent to browser
DEBUG - 2019-07-10 22:01:02 --> Total execution time: 0.5264
INFO - 2019-07-10 16:01:02 --> Config Class Initialized
INFO - 2019-07-10 16:01:02 --> Hooks Class Initialized
DEBUG - 2019-07-10 16:01:02 --> UTF-8 Support Enabled
INFO - 2019-07-10 16:01:02 --> Utf8 Class Initialized
INFO - 2019-07-10 16:01:02 --> URI Class Initialized
DEBUG - 2019-07-10 16:01:02 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/routes.php
INFO - 2019-07-10 16:01:02 --> Router Class Initialized
INFO - 2019-07-10 16:01:02 --> Output Class Initialized
INFO - 2019-07-10 16:01:02 --> Security Class Initialized
DEBUG - 2019-07-10 16:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-10 16:01:02 --> Input Class Initialized
INFO - 2019-07-10 16:01:02 --> Language Class Initialized
INFO - 2019-07-10 16:01:02 --> Language Class Initialized
INFO - 2019-07-10 16:01:02 --> Config Class Initialized
INFO - 2019-07-10 16:01:02 --> Loader Class Initialized
DEBUG - 2019-07-10 16:01:02 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/site.php
INFO - 2019-07-10 16:01:02 --> Helper loaded: url_helper
INFO - 2019-07-10 16:01:02 --> Helper loaded: inflector_helper
INFO - 2019-07-10 16:01:03 --> Helper loaded: string_helper
INFO - 2019-07-10 16:01:03 --> Helper loaded: array_helper
INFO - 2019-07-10 16:01:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-10 16:01:03 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/autoload.php
DEBUG - 2019-07-10 16:01:03 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/helpers/adminlte_helper.php
INFO - 2019-07-10 16:01:03 --> Database Driver Class Initialized
DEBUG - 2019-07-10 16:01:03 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/libraries/Crud.php
INFO - 2019-07-10 16:01:03 --> Helper loaded: form_helper
DEBUG - 2019-07-10 16:01:03 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-07-10 16:01:03 --> Form Validation Class Initialized
DEBUG - 2019-07-10 16:01:03 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-07-10 16:01:03 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-07-10 16:01:03 --> Pagination Class Initialized
INFO - 2019-07-10 16:01:03 --> Controller Class Initialized
INFO - 2019-07-10 22:01:03 --> Model Class Initialized
INFO - 2019-07-10 22:01:03 --> Model Class Initialized
INFO - 2019-07-10 22:01:03 --> Model Class Initialized
INFO - 2019-07-10 22:01:03 --> Final output sent to browser
DEBUG - 2019-07-10 22:01:03 --> Total execution time: 0.5351
INFO - 2019-07-10 16:01:05 --> Config Class Initialized
INFO - 2019-07-10 16:01:05 --> Hooks Class Initialized
DEBUG - 2019-07-10 16:01:05 --> UTF-8 Support Enabled
INFO - 2019-07-10 16:01:05 --> Utf8 Class Initialized
INFO - 2019-07-10 16:01:05 --> URI Class Initialized
DEBUG - 2019-07-10 16:01:05 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/routes.php
INFO - 2019-07-10 16:01:05 --> Router Class Initialized
INFO - 2019-07-10 16:01:05 --> Output Class Initialized
INFO - 2019-07-10 16:01:05 --> Security Class Initialized
DEBUG - 2019-07-10 16:01:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-10 16:01:05 --> Input Class Initialized
INFO - 2019-07-10 16:01:05 --> Language Class Initialized
INFO - 2019-07-10 16:01:05 --> Language Class Initialized
INFO - 2019-07-10 16:01:05 --> Config Class Initialized
INFO - 2019-07-10 16:01:05 --> Loader Class Initialized
DEBUG - 2019-07-10 16:01:05 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/site.php
INFO - 2019-07-10 16:01:05 --> Helper loaded: url_helper
INFO - 2019-07-10 16:01:05 --> Helper loaded: inflector_helper
INFO - 2019-07-10 16:01:05 --> Helper loaded: string_helper
INFO - 2019-07-10 16:01:05 --> Helper loaded: array_helper
INFO - 2019-07-10 16:01:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-10 16:01:05 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/autoload.php
DEBUG - 2019-07-10 16:01:05 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/helpers/adminlte_helper.php
INFO - 2019-07-10 16:01:05 --> Database Driver Class Initialized
DEBUG - 2019-07-10 16:01:05 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/libraries/Crud.php
INFO - 2019-07-10 16:01:05 --> Helper loaded: form_helper
DEBUG - 2019-07-10 16:01:05 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-07-10 16:01:05 --> Form Validation Class Initialized
DEBUG - 2019-07-10 16:01:05 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-07-10 16:01:05 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-07-10 16:01:05 --> Pagination Class Initialized
INFO - 2019-07-10 16:01:06 --> Controller Class Initialized
INFO - 2019-07-10 22:01:06 --> Model Class Initialized
INFO - 2019-07-10 22:01:06 --> Model Class Initialized
INFO - 2019-07-10 22:01:06 --> Model Class Initialized
INFO - 2019-07-10 22:01:06 --> Final output sent to browser
DEBUG - 2019-07-10 22:01:06 --> Total execution time: 0.5400
INFO - 2019-07-10 16:01:08 --> Config Class Initialized
INFO - 2019-07-10 16:01:08 --> Hooks Class Initialized
DEBUG - 2019-07-10 16:01:08 --> UTF-8 Support Enabled
INFO - 2019-07-10 16:01:08 --> Utf8 Class Initialized
INFO - 2019-07-10 16:01:08 --> URI Class Initialized
DEBUG - 2019-07-10 16:01:08 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/routes.php
INFO - 2019-07-10 16:01:08 --> Router Class Initialized
INFO - 2019-07-10 16:01:08 --> Output Class Initialized
INFO - 2019-07-10 16:01:08 --> Security Class Initialized
DEBUG - 2019-07-10 16:01:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-10 16:01:08 --> Input Class Initialized
INFO - 2019-07-10 16:01:08 --> Language Class Initialized
INFO - 2019-07-10 16:01:08 --> Language Class Initialized
INFO - 2019-07-10 16:01:08 --> Config Class Initialized
INFO - 2019-07-10 16:01:08 --> Loader Class Initialized
DEBUG - 2019-07-10 16:01:08 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/site.php
INFO - 2019-07-10 16:01:08 --> Helper loaded: url_helper
INFO - 2019-07-10 16:01:08 --> Helper loaded: inflector_helper
INFO - 2019-07-10 16:01:08 --> Helper loaded: string_helper
INFO - 2019-07-10 16:01:08 --> Helper loaded: array_helper
INFO - 2019-07-10 16:01:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-10 16:01:08 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/autoload.php
DEBUG - 2019-07-10 16:01:08 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/helpers/adminlte_helper.php
INFO - 2019-07-10 16:01:08 --> Database Driver Class Initialized
DEBUG - 2019-07-10 16:01:09 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/libraries/Crud.php
INFO - 2019-07-10 16:01:09 --> Helper loaded: form_helper
DEBUG - 2019-07-10 16:01:09 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-07-10 16:01:09 --> Form Validation Class Initialized
DEBUG - 2019-07-10 16:01:09 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-07-10 16:01:09 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-07-10 16:01:09 --> Pagination Class Initialized
INFO - 2019-07-10 16:01:09 --> Controller Class Initialized
INFO - 2019-07-10 22:01:09 --> Model Class Initialized
INFO - 2019-07-10 22:01:09 --> Model Class Initialized
INFO - 2019-07-10 22:01:09 --> Final output sent to browser
DEBUG - 2019-07-10 22:01:09 --> Total execution time: 0.4773
INFO - 2019-07-10 16:01:10 --> Config Class Initialized
INFO - 2019-07-10 16:01:10 --> Hooks Class Initialized
DEBUG - 2019-07-10 16:01:10 --> UTF-8 Support Enabled
INFO - 2019-07-10 16:01:10 --> Utf8 Class Initialized
INFO - 2019-07-10 16:01:10 --> URI Class Initialized
DEBUG - 2019-07-10 16:01:10 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/routes.php
INFO - 2019-07-10 16:01:10 --> Router Class Initialized
INFO - 2019-07-10 16:01:10 --> Output Class Initialized
INFO - 2019-07-10 16:01:10 --> Security Class Initialized
DEBUG - 2019-07-10 16:01:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-10 16:01:10 --> Input Class Initialized
INFO - 2019-07-10 16:01:10 --> Language Class Initialized
INFO - 2019-07-10 16:01:10 --> Language Class Initialized
INFO - 2019-07-10 16:01:10 --> Config Class Initialized
INFO - 2019-07-10 16:01:10 --> Loader Class Initialized
DEBUG - 2019-07-10 16:01:10 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/site.php
INFO - 2019-07-10 16:01:10 --> Helper loaded: url_helper
INFO - 2019-07-10 16:01:10 --> Helper loaded: inflector_helper
INFO - 2019-07-10 16:01:10 --> Helper loaded: string_helper
INFO - 2019-07-10 16:01:10 --> Helper loaded: array_helper
INFO - 2019-07-10 16:01:10 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-10 16:01:10 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/autoload.php
DEBUG - 2019-07-10 16:01:10 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/helpers/adminlte_helper.php
INFO - 2019-07-10 16:01:10 --> Database Driver Class Initialized
DEBUG - 2019-07-10 16:01:10 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/libraries/Crud.php
INFO - 2019-07-10 16:01:10 --> Helper loaded: form_helper
DEBUG - 2019-07-10 16:01:10 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-07-10 16:01:10 --> Form Validation Class Initialized
DEBUG - 2019-07-10 16:01:10 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-07-10 16:01:10 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-07-10 16:01:10 --> Pagination Class Initialized
INFO - 2019-07-10 16:01:10 --> Controller Class Initialized
INFO - 2019-07-10 22:01:10 --> Model Class Initialized
INFO - 2019-07-10 22:01:10 --> Model Class Initialized
INFO - 2019-07-10 22:01:10 --> Model Class Initialized
INFO - 2019-07-10 22:01:10 --> Final output sent to browser
DEBUG - 2019-07-10 22:01:10 --> Total execution time: 0.4989
INFO - 2019-07-10 16:01:54 --> Config Class Initialized
INFO - 2019-07-10 16:01:54 --> Hooks Class Initialized
DEBUG - 2019-07-10 16:01:54 --> UTF-8 Support Enabled
INFO - 2019-07-10 16:01:54 --> Utf8 Class Initialized
INFO - 2019-07-10 16:01:54 --> URI Class Initialized
DEBUG - 2019-07-10 16:01:54 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/routes.php
INFO - 2019-07-10 16:01:54 --> Router Class Initialized
INFO - 2019-07-10 16:01:54 --> Output Class Initialized
INFO - 2019-07-10 16:01:54 --> Security Class Initialized
DEBUG - 2019-07-10 16:01:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-10 16:01:54 --> Input Class Initialized
INFO - 2019-07-10 16:01:54 --> Language Class Initialized
INFO - 2019-07-10 16:01:54 --> Language Class Initialized
INFO - 2019-07-10 16:01:54 --> Config Class Initialized
INFO - 2019-07-10 16:01:54 --> Loader Class Initialized
DEBUG - 2019-07-10 16:01:54 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/site.php
INFO - 2019-07-10 16:01:54 --> Helper loaded: url_helper
INFO - 2019-07-10 16:01:54 --> Helper loaded: inflector_helper
INFO - 2019-07-10 16:01:54 --> Helper loaded: string_helper
INFO - 2019-07-10 16:01:54 --> Helper loaded: array_helper
INFO - 2019-07-10 16:01:54 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-10 16:01:54 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/autoload.php
DEBUG - 2019-07-10 16:01:55 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/helpers/adminlte_helper.php
INFO - 2019-07-10 16:01:55 --> Database Driver Class Initialized
DEBUG - 2019-07-10 16:01:55 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/libraries/Crud.php
INFO - 2019-07-10 16:01:55 --> Helper loaded: form_helper
DEBUG - 2019-07-10 16:01:55 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-07-10 16:01:55 --> Form Validation Class Initialized
DEBUG - 2019-07-10 16:01:55 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-07-10 16:01:55 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-07-10 16:01:55 --> Pagination Class Initialized
INFO - 2019-07-10 16:01:55 --> Controller Class Initialized
INFO - 2019-07-10 22:01:55 --> Model Class Initialized
INFO - 2019-07-10 22:01:55 --> Model Class Initialized
INFO - 2019-07-10 22:01:55 --> Final output sent to browser
DEBUG - 2019-07-10 22:01:55 --> Total execution time: 0.4756
INFO - 2019-07-10 16:01:55 --> Config Class Initialized
INFO - 2019-07-10 16:01:55 --> Hooks Class Initialized
DEBUG - 2019-07-10 16:01:55 --> UTF-8 Support Enabled
INFO - 2019-07-10 16:01:55 --> Utf8 Class Initialized
INFO - 2019-07-10 16:01:55 --> URI Class Initialized
DEBUG - 2019-07-10 16:01:55 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/routes.php
INFO - 2019-07-10 16:01:55 --> Router Class Initialized
INFO - 2019-07-10 16:01:55 --> Output Class Initialized
INFO - 2019-07-10 16:01:55 --> Security Class Initialized
DEBUG - 2019-07-10 16:01:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-10 16:01:56 --> Input Class Initialized
INFO - 2019-07-10 16:01:56 --> Language Class Initialized
INFO - 2019-07-10 16:01:56 --> Language Class Initialized
INFO - 2019-07-10 16:01:56 --> Config Class Initialized
INFO - 2019-07-10 16:01:56 --> Loader Class Initialized
DEBUG - 2019-07-10 16:01:56 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/site.php
INFO - 2019-07-10 16:01:56 --> Helper loaded: url_helper
INFO - 2019-07-10 16:01:56 --> Helper loaded: inflector_helper
INFO - 2019-07-10 16:01:56 --> Helper loaded: string_helper
INFO - 2019-07-10 16:01:56 --> Helper loaded: array_helper
INFO - 2019-07-10 16:01:56 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-10 16:01:56 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/autoload.php
DEBUG - 2019-07-10 16:01:56 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/helpers/adminlte_helper.php
INFO - 2019-07-10 16:01:56 --> Database Driver Class Initialized
DEBUG - 2019-07-10 16:01:56 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/libraries/Crud.php
INFO - 2019-07-10 16:01:56 --> Helper loaded: form_helper
DEBUG - 2019-07-10 16:01:56 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-07-10 16:01:56 --> Form Validation Class Initialized
DEBUG - 2019-07-10 16:01:56 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-07-10 16:01:56 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-07-10 16:01:56 --> Pagination Class Initialized
INFO - 2019-07-10 16:01:56 --> Controller Class Initialized
INFO - 2019-07-10 22:01:56 --> Model Class Initialized
INFO - 2019-07-10 22:01:56 --> Model Class Initialized
INFO - 2019-07-10 22:01:56 --> Final output sent to browser
DEBUG - 2019-07-10 22:01:56 --> Total execution time: 0.4828
INFO - 2019-07-10 16:07:37 --> Config Class Initialized
INFO - 2019-07-10 16:07:37 --> Hooks Class Initialized
DEBUG - 2019-07-10 16:07:37 --> UTF-8 Support Enabled
INFO - 2019-07-10 16:07:37 --> Utf8 Class Initialized
INFO - 2019-07-10 16:07:37 --> URI Class Initialized
DEBUG - 2019-07-10 16:07:37 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/routes.php
INFO - 2019-07-10 16:07:37 --> Router Class Initialized
INFO - 2019-07-10 16:07:37 --> Output Class Initialized
INFO - 2019-07-10 16:07:37 --> Security Class Initialized
DEBUG - 2019-07-10 16:07:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-10 16:07:37 --> Input Class Initialized
INFO - 2019-07-10 16:07:37 --> Language Class Initialized
INFO - 2019-07-10 16:07:37 --> Language Class Initialized
INFO - 2019-07-10 16:07:37 --> Config Class Initialized
INFO - 2019-07-10 16:07:37 --> Loader Class Initialized
DEBUG - 2019-07-10 16:07:37 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/site.php
INFO - 2019-07-10 16:07:37 --> Helper loaded: url_helper
INFO - 2019-07-10 16:07:37 --> Helper loaded: inflector_helper
INFO - 2019-07-10 16:07:37 --> Helper loaded: string_helper
INFO - 2019-07-10 16:07:37 --> Helper loaded: array_helper
INFO - 2019-07-10 16:07:37 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-10 16:07:37 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/autoload.php
DEBUG - 2019-07-10 16:07:37 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/helpers/adminlte_helper.php
INFO - 2019-07-10 16:07:37 --> Database Driver Class Initialized
DEBUG - 2019-07-10 16:07:37 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/libraries/Crud.php
INFO - 2019-07-10 16:07:37 --> Helper loaded: form_helper
DEBUG - 2019-07-10 16:07:37 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-07-10 16:07:37 --> Form Validation Class Initialized
DEBUG - 2019-07-10 16:07:37 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-07-10 16:07:37 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-07-10 16:07:37 --> Pagination Class Initialized
INFO - 2019-07-10 16:07:37 --> Controller Class Initialized
INFO - 2019-07-10 22:07:37 --> Model Class Initialized
INFO - 2019-07-10 22:07:37 --> Model Class Initialized
INFO - 2019-07-10 22:07:37 --> Model Class Initialized
INFO - 2019-07-10 22:07:37 --> Final output sent to browser
DEBUG - 2019-07-10 22:07:37 --> Total execution time: 0.5135
INFO - 2019-07-10 16:07:38 --> Config Class Initialized
INFO - 2019-07-10 16:07:38 --> Hooks Class Initialized
DEBUG - 2019-07-10 16:07:38 --> UTF-8 Support Enabled
INFO - 2019-07-10 16:07:38 --> Utf8 Class Initialized
INFO - 2019-07-10 16:07:38 --> URI Class Initialized
DEBUG - 2019-07-10 16:07:38 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/routes.php
INFO - 2019-07-10 16:07:38 --> Router Class Initialized
INFO - 2019-07-10 16:07:38 --> Output Class Initialized
INFO - 2019-07-10 16:07:38 --> Security Class Initialized
DEBUG - 2019-07-10 16:07:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-10 16:07:38 --> Input Class Initialized
INFO - 2019-07-10 16:07:38 --> Language Class Initialized
INFO - 2019-07-10 16:07:38 --> Language Class Initialized
INFO - 2019-07-10 16:07:38 --> Config Class Initialized
INFO - 2019-07-10 16:07:38 --> Loader Class Initialized
DEBUG - 2019-07-10 16:07:38 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/site.php
INFO - 2019-07-10 16:07:38 --> Helper loaded: url_helper
INFO - 2019-07-10 16:07:38 --> Helper loaded: inflector_helper
INFO - 2019-07-10 16:07:38 --> Helper loaded: string_helper
INFO - 2019-07-10 16:07:38 --> Helper loaded: array_helper
INFO - 2019-07-10 16:07:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-10 16:07:38 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/autoload.php
DEBUG - 2019-07-10 16:07:38 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/helpers/adminlte_helper.php
INFO - 2019-07-10 16:07:39 --> Database Driver Class Initialized
DEBUG - 2019-07-10 16:07:39 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/libraries/Crud.php
INFO - 2019-07-10 16:07:39 --> Helper loaded: form_helper
DEBUG - 2019-07-10 16:07:39 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-07-10 16:07:39 --> Form Validation Class Initialized
DEBUG - 2019-07-10 16:07:39 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-07-10 16:07:39 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-07-10 16:07:39 --> Pagination Class Initialized
INFO - 2019-07-10 16:07:39 --> Controller Class Initialized
INFO - 2019-07-10 22:07:39 --> Model Class Initialized
INFO - 2019-07-10 22:07:39 --> Model Class Initialized
INFO - 2019-07-10 22:07:39 --> Model Class Initialized
INFO - 2019-07-10 22:07:39 --> Final output sent to browser
DEBUG - 2019-07-10 22:07:39 --> Total execution time: 0.5118
INFO - 2019-07-10 16:08:14 --> Config Class Initialized
INFO - 2019-07-10 16:08:19 --> Config Class Initialized
INFO - 2019-07-10 16:08:19 --> Config Class Initialized
INFO - 2019-07-10 16:08:19 --> Config Class Initialized
INFO - 2019-07-10 16:08:19 --> Hooks Class Initialized
INFO - 2019-07-10 16:08:19 --> Config Class Initialized
INFO - 2019-07-10 16:08:19 --> Hooks Class Initialized
INFO - 2019-07-10 16:08:19 --> Hooks Class Initialized
DEBUG - 2019-07-10 16:08:19 --> UTF-8 Support Enabled
INFO - 2019-07-10 16:08:19 --> Hooks Class Initialized
INFO - 2019-07-10 16:08:19 --> Hooks Class Initialized
DEBUG - 2019-07-10 16:08:19 --> UTF-8 Support Enabled
DEBUG - 2019-07-10 16:08:19 --> UTF-8 Support Enabled
INFO - 2019-07-10 16:08:19 --> Utf8 Class Initialized
DEBUG - 2019-07-10 16:08:19 --> UTF-8 Support Enabled
DEBUG - 2019-07-10 16:08:19 --> UTF-8 Support Enabled
INFO - 2019-07-10 16:08:19 --> Utf8 Class Initialized
INFO - 2019-07-10 16:08:19 --> Utf8 Class Initialized
INFO - 2019-07-10 16:08:19 --> URI Class Initialized
INFO - 2019-07-10 16:08:19 --> Utf8 Class Initialized
INFO - 2019-07-10 16:08:19 --> Utf8 Class Initialized
INFO - 2019-07-10 16:08:19 --> URI Class Initialized
INFO - 2019-07-10 16:08:19 --> URI Class Initialized
INFO - 2019-07-10 16:08:19 --> URI Class Initialized
DEBUG - 2019-07-10 16:08:19 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/routes.php
DEBUG - 2019-07-10 16:08:19 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/routes.php
INFO - 2019-07-10 16:08:19 --> URI Class Initialized
DEBUG - 2019-07-10 16:08:19 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/routes.php
DEBUG - 2019-07-10 16:08:19 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/routes.php
INFO - 2019-07-10 16:08:19 --> Router Class Initialized
DEBUG - 2019-07-10 16:08:19 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/routes.php
INFO - 2019-07-10 16:08:19 --> Router Class Initialized
INFO - 2019-07-10 16:08:19 --> Output Class Initialized
INFO - 2019-07-10 16:08:19 --> Router Class Initialized
INFO - 2019-07-10 16:08:19 --> Router Class Initialized
INFO - 2019-07-10 16:08:19 --> Router Class Initialized
INFO - 2019-07-10 16:08:19 --> Output Class Initialized
INFO - 2019-07-10 16:08:19 --> Output Class Initialized
INFO - 2019-07-10 16:08:19 --> Output Class Initialized
INFO - 2019-07-10 16:08:19 --> Security Class Initialized
INFO - 2019-07-10 16:08:19 --> Output Class Initialized
INFO - 2019-07-10 16:08:19 --> Security Class Initialized
DEBUG - 2019-07-10 16:08:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-10 16:08:19 --> Security Class Initialized
INFO - 2019-07-10 16:08:19 --> Security Class Initialized
INFO - 2019-07-10 16:08:19 --> Security Class Initialized
DEBUG - 2019-07-10 16:08:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-10 16:08:19 --> Input Class Initialized
DEBUG - 2019-07-10 16:08:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2019-07-10 16:08:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-10 16:08:19 --> Language Class Initialized
DEBUG - 2019-07-10 16:08:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-10 16:08:19 --> Input Class Initialized
INFO - 2019-07-10 16:08:19 --> Input Class Initialized
INFO - 2019-07-10 16:08:19 --> Input Class Initialized
INFO - 2019-07-10 16:08:19 --> Input Class Initialized
INFO - 2019-07-10 16:08:19 --> Language Class Initialized
INFO - 2019-07-10 16:08:19 --> Language Class Initialized
INFO - 2019-07-10 16:08:19 --> Language Class Initialized
INFO - 2019-07-10 16:08:19 --> Language Class Initialized
INFO - 2019-07-10 16:08:19 --> Language Class Initialized
INFO - 2019-07-10 16:08:19 --> Config Class Initialized
INFO - 2019-07-10 16:08:19 --> Language Class Initialized
INFO - 2019-07-10 16:08:19 --> Language Class Initialized
INFO - 2019-07-10 16:08:19 --> Loader Class Initialized
INFO - 2019-07-10 16:08:19 --> Language Class Initialized
INFO - 2019-07-10 16:08:19 --> Language Class Initialized
INFO - 2019-07-10 16:08:19 --> Config Class Initialized
INFO - 2019-07-10 16:08:19 --> Config Class Initialized
INFO - 2019-07-10 16:08:19 --> Config Class Initialized
DEBUG - 2019-07-10 16:08:19 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/site.php
INFO - 2019-07-10 16:08:19 --> Loader Class Initialized
INFO - 2019-07-10 16:08:19 --> Loader Class Initialized
INFO - 2019-07-10 16:08:19 --> Config Class Initialized
INFO - 2019-07-10 16:08:19 --> Loader Class Initialized
INFO - 2019-07-10 16:08:19 --> Loader Class Initialized
INFO - 2019-07-10 16:08:19 --> Helper loaded: url_helper
DEBUG - 2019-07-10 16:08:19 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/site.php
DEBUG - 2019-07-10 16:08:19 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/site.php
DEBUG - 2019-07-10 16:08:19 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/site.php
DEBUG - 2019-07-10 16:08:19 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/site.php
INFO - 2019-07-10 16:08:19 --> Helper loaded: inflector_helper
INFO - 2019-07-10 16:08:19 --> Helper loaded: url_helper
INFO - 2019-07-10 16:08:19 --> Helper loaded: url_helper
INFO - 2019-07-10 16:08:19 --> Helper loaded: url_helper
INFO - 2019-07-10 16:08:19 --> Helper loaded: url_helper
INFO - 2019-07-10 16:08:19 --> Helper loaded: inflector_helper
INFO - 2019-07-10 16:08:19 --> Helper loaded: inflector_helper
INFO - 2019-07-10 16:08:19 --> Helper loaded: string_helper
INFO - 2019-07-10 16:08:19 --> Helper loaded: inflector_helper
INFO - 2019-07-10 16:08:19 --> Helper loaded: inflector_helper
INFO - 2019-07-10 16:08:19 --> Helper loaded: string_helper
INFO - 2019-07-10 16:08:19 --> Helper loaded: string_helper
INFO - 2019-07-10 16:08:19 --> Helper loaded: string_helper
INFO - 2019-07-10 16:08:19 --> Helper loaded: array_helper
INFO - 2019-07-10 16:08:19 --> Helper loaded: string_helper
INFO - 2019-07-10 16:08:19 --> Helper loaded: array_helper
INFO - 2019-07-10 16:08:19 --> Helper loaded: array_helper
INFO - 2019-07-10 16:08:19 --> Session: Class initialized using 'files' driver.
INFO - 2019-07-10 16:08:19 --> Helper loaded: array_helper
INFO - 2019-07-10 16:08:19 --> Helper loaded: array_helper
DEBUG - 2019-07-10 16:08:19 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/autoload.php
DEBUG - 2019-07-10 16:08:19 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/helpers/adminlte_helper.php
INFO - 2019-07-10 16:08:19 --> Database Driver Class Initialized
DEBUG - 2019-07-10 16:08:19 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/libraries/Crud.php
INFO - 2019-07-10 16:08:19 --> Helper loaded: form_helper
DEBUG - 2019-07-10 16:08:19 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-07-10 16:08:19 --> Form Validation Class Initialized
DEBUG - 2019-07-10 16:08:19 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-07-10 16:08:19 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-07-10 16:08:19 --> Pagination Class Initialized
INFO - 2019-07-10 16:08:19 --> Controller Class Initialized
INFO - 2019-07-10 22:08:19 --> Model Class Initialized
INFO - 2019-07-10 22:08:19 --> Model Class Initialized
INFO - 2019-07-10 22:08:19 --> Model Class Initialized
INFO - 2019-07-10 16:08:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-10 16:08:20 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/autoload.php
DEBUG - 2019-07-10 16:08:20 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/helpers/adminlte_helper.php
INFO - 2019-07-10 16:08:20 --> Database Driver Class Initialized
DEBUG - 2019-07-10 16:08:20 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/libraries/Crud.php
INFO - 2019-07-10 16:08:20 --> Helper loaded: form_helper
DEBUG - 2019-07-10 16:08:20 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-07-10 16:08:20 --> Form Validation Class Initialized
DEBUG - 2019-07-10 16:08:20 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-07-10 16:08:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-07-10 16:08:20 --> Pagination Class Initialized
INFO - 2019-07-10 16:08:20 --> Controller Class Initialized
INFO - 2019-07-10 22:08:20 --> Model Class Initialized
INFO - 2019-07-10 22:08:20 --> Model Class Initialized
INFO - 2019-07-10 22:08:20 --> Model Class Initialized
INFO - 2019-07-10 16:08:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-10 16:08:20 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/autoload.php
DEBUG - 2019-07-10 16:08:20 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/helpers/adminlte_helper.php
INFO - 2019-07-10 16:08:20 --> Database Driver Class Initialized
DEBUG - 2019-07-10 16:08:20 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/libraries/Crud.php
INFO - 2019-07-10 16:08:20 --> Helper loaded: form_helper
DEBUG - 2019-07-10 16:08:20 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-07-10 16:08:20 --> Form Validation Class Initialized
DEBUG - 2019-07-10 16:08:20 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-07-10 16:08:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-07-10 16:08:20 --> Pagination Class Initialized
INFO - 2019-07-10 16:08:20 --> Controller Class Initialized
INFO - 2019-07-10 22:08:20 --> Model Class Initialized
INFO - 2019-07-10 22:08:20 --> Model Class Initialized
INFO - 2019-07-10 22:08:20 --> Model Class Initialized
INFO - 2019-07-10 16:08:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-10 16:08:20 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/autoload.php
DEBUG - 2019-07-10 16:08:20 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/helpers/adminlte_helper.php
INFO - 2019-07-10 16:08:20 --> Database Driver Class Initialized
DEBUG - 2019-07-10 16:08:20 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/libraries/Crud.php
INFO - 2019-07-10 16:08:20 --> Helper loaded: form_helper
DEBUG - 2019-07-10 16:08:20 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-07-10 16:08:20 --> Form Validation Class Initialized
DEBUG - 2019-07-10 16:08:20 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-07-10 16:08:20 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-07-10 16:08:20 --> Pagination Class Initialized
INFO - 2019-07-10 16:08:20 --> Controller Class Initialized
INFO - 2019-07-10 22:08:20 --> Model Class Initialized
INFO - 2019-07-10 22:08:20 --> Model Class Initialized
INFO - 2019-07-10 22:08:20 --> Model Class Initialized
INFO - 2019-07-10 16:08:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-10 16:08:20 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/autoload.php
DEBUG - 2019-07-10 16:08:20 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/helpers/adminlte_helper.php
INFO - 2019-07-10 16:08:20 --> Database Driver Class Initialized
DEBUG - 2019-07-10 16:08:20 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/libraries/Crud.php
INFO - 2019-07-10 16:08:21 --> Helper loaded: form_helper
DEBUG - 2019-07-10 16:08:21 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-07-10 16:08:21 --> Form Validation Class Initialized
DEBUG - 2019-07-10 16:08:21 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-07-10 16:08:21 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-07-10 16:08:21 --> Pagination Class Initialized
INFO - 2019-07-10 16:08:21 --> Controller Class Initialized
INFO - 2019-07-10 22:08:21 --> Model Class Initialized
INFO - 2019-07-10 22:08:21 --> Model Class Initialized
INFO - 2019-07-10 22:08:21 --> Model Class Initialized
INFO - 2019-07-10 16:08:37 --> Config Class Initialized
INFO - 2019-07-10 16:08:37 --> Hooks Class Initialized
DEBUG - 2019-07-10 16:08:37 --> UTF-8 Support Enabled
INFO - 2019-07-10 16:08:37 --> Utf8 Class Initialized
INFO - 2019-07-10 16:08:37 --> URI Class Initialized
DEBUG - 2019-07-10 16:08:37 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/routes.php
INFO - 2019-07-10 16:08:37 --> Router Class Initialized
INFO - 2019-07-10 16:08:37 --> Output Class Initialized
INFO - 2019-07-10 16:08:37 --> Security Class Initialized
DEBUG - 2019-07-10 16:08:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-10 16:08:37 --> Input Class Initialized
INFO - 2019-07-10 16:08:37 --> Language Class Initialized
ERROR - 2019-07-10 16:08:37 --> Severity: Parsing Error --> syntax error, unexpected 'var_dump' (T_STRING), expecting ',' or ';' C:\xampp\htdocs\crapi_admin\application\modules\admin\controllers\Employees.php 238
INFO - 2019-07-10 16:08:42 --> Config Class Initialized
INFO - 2019-07-10 16:08:42 --> Hooks Class Initialized
DEBUG - 2019-07-10 16:08:42 --> UTF-8 Support Enabled
INFO - 2019-07-10 16:08:42 --> Utf8 Class Initialized
INFO - 2019-07-10 16:08:42 --> URI Class Initialized
DEBUG - 2019-07-10 16:08:42 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/routes.php
INFO - 2019-07-10 16:08:42 --> Router Class Initialized
INFO - 2019-07-10 16:08:42 --> Output Class Initialized
INFO - 2019-07-10 16:08:42 --> Security Class Initialized
DEBUG - 2019-07-10 16:08:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-10 16:08:42 --> Input Class Initialized
INFO - 2019-07-10 16:08:42 --> Language Class Initialized
INFO - 2019-07-10 16:08:42 --> Language Class Initialized
INFO - 2019-07-10 16:08:42 --> Config Class Initialized
INFO - 2019-07-10 16:08:42 --> Loader Class Initialized
DEBUG - 2019-07-10 16:08:42 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/site.php
INFO - 2019-07-10 16:08:42 --> Helper loaded: url_helper
INFO - 2019-07-10 16:08:42 --> Helper loaded: inflector_helper
INFO - 2019-07-10 16:08:42 --> Helper loaded: string_helper
INFO - 2019-07-10 16:08:42 --> Helper loaded: array_helper
INFO - 2019-07-10 16:08:42 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-10 16:08:42 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/autoload.php
DEBUG - 2019-07-10 16:08:42 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/helpers/adminlte_helper.php
INFO - 2019-07-10 16:08:42 --> Database Driver Class Initialized
DEBUG - 2019-07-10 16:08:42 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/libraries/Crud.php
INFO - 2019-07-10 16:08:43 --> Helper loaded: form_helper
DEBUG - 2019-07-10 16:08:43 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-07-10 16:08:43 --> Form Validation Class Initialized
DEBUG - 2019-07-10 16:08:43 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-07-10 16:08:43 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-07-10 16:08:43 --> Pagination Class Initialized
INFO - 2019-07-10 16:08:43 --> Controller Class Initialized
INFO - 2019-07-10 22:08:43 --> Model Class Initialized
INFO - 2019-07-10 22:08:43 --> Model Class Initialized
INFO - 2019-07-10 22:08:43 --> Model Class Initialized
INFO - 2019-07-10 16:09:47 --> Config Class Initialized
INFO - 2019-07-10 16:09:47 --> Hooks Class Initialized
DEBUG - 2019-07-10 16:09:47 --> UTF-8 Support Enabled
INFO - 2019-07-10 16:09:47 --> Utf8 Class Initialized
INFO - 2019-07-10 16:09:47 --> URI Class Initialized
DEBUG - 2019-07-10 16:09:47 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/routes.php
INFO - 2019-07-10 16:09:47 --> Router Class Initialized
INFO - 2019-07-10 16:09:47 --> Output Class Initialized
INFO - 2019-07-10 16:09:47 --> Security Class Initialized
DEBUG - 2019-07-10 16:09:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-10 16:09:47 --> Input Class Initialized
INFO - 2019-07-10 16:09:48 --> Language Class Initialized
INFO - 2019-07-10 16:09:48 --> Language Class Initialized
INFO - 2019-07-10 16:09:48 --> Config Class Initialized
INFO - 2019-07-10 16:09:48 --> Loader Class Initialized
DEBUG - 2019-07-10 16:09:48 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/site.php
INFO - 2019-07-10 16:09:48 --> Helper loaded: url_helper
INFO - 2019-07-10 16:09:48 --> Helper loaded: inflector_helper
INFO - 2019-07-10 16:09:48 --> Helper loaded: string_helper
INFO - 2019-07-10 16:09:48 --> Helper loaded: array_helper
INFO - 2019-07-10 16:09:48 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-10 16:09:48 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/autoload.php
DEBUG - 2019-07-10 16:09:48 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/helpers/adminlte_helper.php
INFO - 2019-07-10 16:09:48 --> Database Driver Class Initialized
DEBUG - 2019-07-10 16:09:48 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/libraries/Crud.php
INFO - 2019-07-10 16:09:48 --> Helper loaded: form_helper
DEBUG - 2019-07-10 16:09:48 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-07-10 16:09:48 --> Form Validation Class Initialized
DEBUG - 2019-07-10 16:09:48 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-07-10 16:09:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-07-10 16:09:48 --> Pagination Class Initialized
INFO - 2019-07-10 16:09:48 --> Controller Class Initialized
INFO - 2019-07-10 22:09:48 --> Model Class Initialized
INFO - 2019-07-10 22:09:48 --> Model Class Initialized
INFO - 2019-07-10 22:09:48 --> Model Class Initialized
INFO - 2019-07-10 16:09:48 --> Config Class Initialized
INFO - 2019-07-10 16:09:48 --> Hooks Class Initialized
DEBUG - 2019-07-10 16:09:48 --> UTF-8 Support Enabled
INFO - 2019-07-10 16:09:48 --> Utf8 Class Initialized
INFO - 2019-07-10 16:09:48 --> URI Class Initialized
DEBUG - 2019-07-10 16:09:48 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/routes.php
INFO - 2019-07-10 16:09:48 --> Router Class Initialized
INFO - 2019-07-10 16:09:48 --> Output Class Initialized
INFO - 2019-07-10 16:09:48 --> Security Class Initialized
DEBUG - 2019-07-10 16:09:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-10 16:09:48 --> Input Class Initialized
INFO - 2019-07-10 16:09:48 --> Language Class Initialized
INFO - 2019-07-10 16:09:48 --> Language Class Initialized
INFO - 2019-07-10 16:09:48 --> Config Class Initialized
INFO - 2019-07-10 16:09:48 --> Loader Class Initialized
DEBUG - 2019-07-10 16:09:48 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/site.php
INFO - 2019-07-10 16:09:48 --> Helper loaded: url_helper
INFO - 2019-07-10 16:09:48 --> Helper loaded: inflector_helper
INFO - 2019-07-10 16:09:48 --> Helper loaded: string_helper
INFO - 2019-07-10 16:09:48 --> Helper loaded: array_helper
INFO - 2019-07-10 16:09:48 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-10 16:09:48 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/autoload.php
DEBUG - 2019-07-10 16:09:48 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/helpers/adminlte_helper.php
INFO - 2019-07-10 16:09:48 --> Database Driver Class Initialized
DEBUG - 2019-07-10 16:09:48 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/libraries/Crud.php
INFO - 2019-07-10 16:09:48 --> Helper loaded: form_helper
DEBUG - 2019-07-10 16:09:48 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-07-10 16:09:48 --> Form Validation Class Initialized
DEBUG - 2019-07-10 16:09:48 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/admin/config/form_validation.php
INFO - 2019-07-10 16:09:48 --> Language file loaded: language/english/pagination_lang.php
INFO - 2019-07-10 16:09:48 --> Pagination Class Initialized
INFO - 2019-07-10 16:09:48 --> Controller Class Initialized
INFO - 2019-07-10 22:09:49 --> Model Class Initialized
INFO - 2019-07-10 22:09:49 --> Model Class Initialized
INFO - 2019-07-10 22:09:49 --> Model Class Initialized
INFO - 2019-07-10 22:09:49 --> Final output sent to browser
DEBUG - 2019-07-10 22:09:49 --> Total execution time: 0.6039
INFO - 2019-07-10 16:09:49 --> Config Class Initialized
INFO - 2019-07-10 16:09:49 --> Hooks Class Initialized
DEBUG - 2019-07-10 16:09:49 --> UTF-8 Support Enabled
INFO - 2019-07-10 16:09:49 --> Utf8 Class Initialized
INFO - 2019-07-10 16:09:49 --> URI Class Initialized
INFO - 2019-07-10 16:09:49 --> Router Class Initialized
INFO - 2019-07-10 16:09:49 --> Output Class Initialized
INFO - 2019-07-10 16:09:49 --> Security Class Initialized
DEBUG - 2019-07-10 16:09:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-10 16:09:49 --> Input Class Initialized
INFO - 2019-07-10 16:09:49 --> Language Class Initialized
INFO - 2019-07-10 16:09:50 --> Language Class Initialized
INFO - 2019-07-10 16:09:50 --> Config Class Initialized
INFO - 2019-07-10 16:09:50 --> Loader Class Initialized
DEBUG - 2019-07-10 16:09:51 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-10 16:09:51 --> Helper loaded: url_helper
INFO - 2019-07-10 16:09:51 --> Helper loaded: inflector_helper
INFO - 2019-07-10 16:09:51 --> Helper loaded: string_helper
INFO - 2019-07-10 16:09:51 --> Helper loaded: array_helper
INFO - 2019-07-10 16:09:51 --> Session: Class initialized using 'files' driver.
INFO - 2019-07-10 16:09:51 --> Controller Class Initialized
INFO - 2019-07-10 22:09:51 --> Helper loaded: language_helper
INFO - 2019-07-10 22:09:51 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 22:09:52 --> Final output sent to browser
DEBUG - 2019-07-10 22:09:52 --> Total execution time: 2.9383
INFO - 2019-07-10 16:23:04 --> Config Class Initialized
INFO - 2019-07-10 16:23:04 --> Hooks Class Initialized
DEBUG - 2019-07-10 16:23:04 --> UTF-8 Support Enabled
INFO - 2019-07-10 16:23:04 --> Utf8 Class Initialized
INFO - 2019-07-10 16:23:04 --> URI Class Initialized
DEBUG - 2019-07-10 16:23:04 --> No URI present. Default controller set.
INFO - 2019-07-10 16:23:04 --> Router Class Initialized
INFO - 2019-07-10 16:23:04 --> Output Class Initialized
INFO - 2019-07-10 16:23:04 --> Security Class Initialized
DEBUG - 2019-07-10 16:23:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-10 16:23:04 --> Input Class Initialized
INFO - 2019-07-10 16:23:04 --> Language Class Initialized
INFO - 2019-07-10 16:23:04 --> Final output sent to browser
DEBUG - 2019-07-10 16:23:04 --> Total execution time: 0.1785
INFO - 2019-07-10 17:25:50 --> Config Class Initialized
INFO - 2019-07-10 17:25:50 --> Hooks Class Initialized
DEBUG - 2019-07-10 17:25:50 --> UTF-8 Support Enabled
INFO - 2019-07-10 17:25:50 --> Utf8 Class Initialized
INFO - 2019-07-10 17:25:50 --> URI Class Initialized
INFO - 2019-07-10 17:25:50 --> Router Class Initialized
INFO - 2019-07-10 17:25:50 --> Output Class Initialized
INFO - 2019-07-10 17:25:51 --> Security Class Initialized
DEBUG - 2019-07-10 17:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-10 17:25:51 --> Input Class Initialized
INFO - 2019-07-10 17:25:51 --> Language Class Initialized
INFO - 2019-07-10 17:25:51 --> Language Class Initialized
INFO - 2019-07-10 17:25:51 --> Config Class Initialized
INFO - 2019-07-10 17:25:51 --> Loader Class Initialized
DEBUG - 2019-07-10 17:25:51 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-10 17:25:51 --> Helper loaded: url_helper
INFO - 2019-07-10 17:25:51 --> Helper loaded: inflector_helper
INFO - 2019-07-10 17:25:51 --> Helper loaded: string_helper
INFO - 2019-07-10 17:25:51 --> Helper loaded: array_helper
INFO - 2019-07-10 17:25:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-10 17:25:51 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-10 17:25:51 --> Database Driver Class Initialized
INFO - 2019-07-10 17:25:51 --> Controller Class Initialized
INFO - 2019-07-10 23:25:51 --> Helper loaded: language_helper
INFO - 2019-07-10 23:25:51 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 23:25:51 --> Model Class Initialized
INFO - 2019-07-10 23:25:51 --> Model Class Initialized
INFO - 2019-07-10 23:25:51 --> Model Class Initialized
INFO - 2019-07-10 23:25:51 --> Model Class Initialized
INFO - 2019-07-10 23:25:51 --> Final output sent to browser
DEBUG - 2019-07-10 23:25:51 --> Total execution time: 0.4153
INFO - 2019-07-10 17:25:58 --> Config Class Initialized
INFO - 2019-07-10 17:25:58 --> Hooks Class Initialized
DEBUG - 2019-07-10 17:25:58 --> UTF-8 Support Enabled
INFO - 2019-07-10 17:25:58 --> Utf8 Class Initialized
INFO - 2019-07-10 17:25:58 --> URI Class Initialized
INFO - 2019-07-10 17:25:58 --> Router Class Initialized
INFO - 2019-07-10 17:25:58 --> Output Class Initialized
INFO - 2019-07-10 17:25:58 --> Security Class Initialized
DEBUG - 2019-07-10 17:25:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-10 17:25:58 --> Input Class Initialized
INFO - 2019-07-10 17:25:58 --> Language Class Initialized
INFO - 2019-07-10 17:25:59 --> Language Class Initialized
INFO - 2019-07-10 17:25:59 --> Config Class Initialized
INFO - 2019-07-10 17:25:59 --> Loader Class Initialized
DEBUG - 2019-07-10 17:25:59 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-10 17:25:59 --> Helper loaded: url_helper
INFO - 2019-07-10 17:25:59 --> Helper loaded: inflector_helper
INFO - 2019-07-10 17:25:59 --> Helper loaded: string_helper
INFO - 2019-07-10 17:25:59 --> Helper loaded: array_helper
INFO - 2019-07-10 17:25:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-10 17:25:59 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-10 17:25:59 --> Database Driver Class Initialized
INFO - 2019-07-10 17:25:59 --> Controller Class Initialized
INFO - 2019-07-10 23:25:59 --> Helper loaded: language_helper
INFO - 2019-07-10 23:25:59 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 23:25:59 --> Model Class Initialized
INFO - 2019-07-10 23:25:59 --> Model Class Initialized
INFO - 2019-07-10 23:25:59 --> Model Class Initialized
INFO - 2019-07-10 23:25:59 --> Model Class Initialized
INFO - 2019-07-10 23:25:59 --> Final output sent to browser
DEBUG - 2019-07-10 23:25:59 --> Total execution time: 0.3807
INFO - 2019-07-10 17:26:27 --> Config Class Initialized
INFO - 2019-07-10 17:26:27 --> Hooks Class Initialized
DEBUG - 2019-07-10 17:26:27 --> UTF-8 Support Enabled
INFO - 2019-07-10 17:26:27 --> Utf8 Class Initialized
INFO - 2019-07-10 17:26:27 --> URI Class Initialized
INFO - 2019-07-10 17:26:27 --> Router Class Initialized
INFO - 2019-07-10 17:26:27 --> Output Class Initialized
INFO - 2019-07-10 17:26:27 --> Security Class Initialized
DEBUG - 2019-07-10 17:26:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-10 17:26:27 --> Input Class Initialized
INFO - 2019-07-10 17:26:27 --> Language Class Initialized
INFO - 2019-07-10 17:26:27 --> Language Class Initialized
INFO - 2019-07-10 17:26:27 --> Config Class Initialized
INFO - 2019-07-10 17:26:27 --> Loader Class Initialized
DEBUG - 2019-07-10 17:26:27 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-10 17:26:28 --> Helper loaded: url_helper
INFO - 2019-07-10 17:26:28 --> Helper loaded: inflector_helper
INFO - 2019-07-10 17:26:28 --> Helper loaded: string_helper
INFO - 2019-07-10 17:26:28 --> Helper loaded: array_helper
INFO - 2019-07-10 17:26:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-10 17:26:28 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-10 17:26:28 --> Database Driver Class Initialized
INFO - 2019-07-10 17:26:28 --> Controller Class Initialized
INFO - 2019-07-10 23:26:28 --> Helper loaded: language_helper
INFO - 2019-07-10 23:26:28 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 23:26:28 --> Model Class Initialized
INFO - 2019-07-10 23:26:28 --> Model Class Initialized
INFO - 2019-07-10 23:26:28 --> Model Class Initialized
INFO - 2019-07-10 23:26:28 --> Model Class Initialized
INFO - 2019-07-10 23:26:28 --> Final output sent to browser
DEBUG - 2019-07-10 23:26:28 --> Total execution time: 0.4146
INFO - 2019-07-10 17:27:11 --> Config Class Initialized
INFO - 2019-07-10 17:27:11 --> Hooks Class Initialized
DEBUG - 2019-07-10 17:27:11 --> UTF-8 Support Enabled
INFO - 2019-07-10 17:27:11 --> Utf8 Class Initialized
INFO - 2019-07-10 17:27:11 --> URI Class Initialized
INFO - 2019-07-10 17:27:11 --> Router Class Initialized
INFO - 2019-07-10 17:27:11 --> Output Class Initialized
INFO - 2019-07-10 17:27:11 --> Security Class Initialized
DEBUG - 2019-07-10 17:27:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-10 17:27:11 --> Input Class Initialized
INFO - 2019-07-10 17:27:11 --> Language Class Initialized
INFO - 2019-07-10 17:27:11 --> Language Class Initialized
INFO - 2019-07-10 17:27:11 --> Config Class Initialized
INFO - 2019-07-10 17:27:11 --> Loader Class Initialized
DEBUG - 2019-07-10 17:27:11 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-10 17:27:11 --> Helper loaded: url_helper
INFO - 2019-07-10 17:27:11 --> Helper loaded: inflector_helper
INFO - 2019-07-10 17:27:11 --> Helper loaded: string_helper
INFO - 2019-07-10 17:27:11 --> Helper loaded: array_helper
INFO - 2019-07-10 17:27:12 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-10 17:27:12 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-10 17:27:12 --> Database Driver Class Initialized
INFO - 2019-07-10 17:27:12 --> Controller Class Initialized
INFO - 2019-07-10 23:27:12 --> Helper loaded: language_helper
INFO - 2019-07-10 23:27:12 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 23:27:12 --> Model Class Initialized
INFO - 2019-07-10 23:27:12 --> Model Class Initialized
INFO - 2019-07-10 23:27:12 --> Model Class Initialized
INFO - 2019-07-10 23:27:12 --> Model Class Initialized
INFO - 2019-07-10 23:27:12 --> Model Class Initialized
INFO - 2019-07-10 23:27:12 --> Final output sent to browser
DEBUG - 2019-07-10 23:27:12 --> Total execution time: 0.5108
INFO - 2019-07-10 17:27:21 --> Config Class Initialized
INFO - 2019-07-10 17:27:21 --> Hooks Class Initialized
DEBUG - 2019-07-10 17:27:21 --> UTF-8 Support Enabled
INFO - 2019-07-10 17:27:21 --> Utf8 Class Initialized
INFO - 2019-07-10 17:27:21 --> URI Class Initialized
INFO - 2019-07-10 17:27:21 --> Router Class Initialized
INFO - 2019-07-10 17:27:21 --> Output Class Initialized
INFO - 2019-07-10 17:27:21 --> Security Class Initialized
DEBUG - 2019-07-10 17:27:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-10 17:27:21 --> Input Class Initialized
INFO - 2019-07-10 17:27:21 --> Language Class Initialized
INFO - 2019-07-10 17:27:21 --> Language Class Initialized
INFO - 2019-07-10 17:27:21 --> Config Class Initialized
INFO - 2019-07-10 17:27:21 --> Loader Class Initialized
DEBUG - 2019-07-10 17:27:21 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-10 17:27:21 --> Helper loaded: url_helper
INFO - 2019-07-10 17:27:21 --> Helper loaded: inflector_helper
INFO - 2019-07-10 17:27:21 --> Helper loaded: string_helper
INFO - 2019-07-10 17:27:21 --> Helper loaded: array_helper
INFO - 2019-07-10 17:27:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-10 17:27:21 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-10 17:27:21 --> Database Driver Class Initialized
INFO - 2019-07-10 17:27:21 --> Controller Class Initialized
INFO - 2019-07-10 23:27:21 --> Helper loaded: language_helper
INFO - 2019-07-10 23:27:21 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 23:27:21 --> Model Class Initialized
INFO - 2019-07-10 23:27:21 --> Model Class Initialized
INFO - 2019-07-10 23:27:21 --> Model Class Initialized
INFO - 2019-07-10 23:27:21 --> Model Class Initialized
INFO - 2019-07-10 23:27:21 --> Final output sent to browser
DEBUG - 2019-07-10 23:27:21 --> Total execution time: 0.4710
INFO - 2019-07-10 17:27:22 --> Config Class Initialized
INFO - 2019-07-10 17:27:22 --> Hooks Class Initialized
DEBUG - 2019-07-10 17:27:22 --> UTF-8 Support Enabled
INFO - 2019-07-10 17:27:22 --> Utf8 Class Initialized
INFO - 2019-07-10 17:27:22 --> URI Class Initialized
INFO - 2019-07-10 17:27:22 --> Router Class Initialized
INFO - 2019-07-10 17:27:22 --> Output Class Initialized
INFO - 2019-07-10 17:27:22 --> Security Class Initialized
DEBUG - 2019-07-10 17:27:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-10 17:27:22 --> Input Class Initialized
INFO - 2019-07-10 17:27:22 --> Language Class Initialized
INFO - 2019-07-10 17:27:22 --> Language Class Initialized
INFO - 2019-07-10 17:27:22 --> Config Class Initialized
INFO - 2019-07-10 17:27:22 --> Loader Class Initialized
DEBUG - 2019-07-10 17:27:22 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-10 17:27:22 --> Helper loaded: url_helper
INFO - 2019-07-10 17:27:22 --> Helper loaded: inflector_helper
INFO - 2019-07-10 17:27:22 --> Helper loaded: string_helper
INFO - 2019-07-10 17:27:22 --> Helper loaded: array_helper
INFO - 2019-07-10 17:27:22 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-10 17:27:22 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-10 17:27:22 --> Database Driver Class Initialized
INFO - 2019-07-10 17:27:22 --> Controller Class Initialized
INFO - 2019-07-10 23:27:22 --> Helper loaded: language_helper
INFO - 2019-07-10 23:27:22 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 23:27:22 --> Model Class Initialized
INFO - 2019-07-10 23:27:22 --> Model Class Initialized
INFO - 2019-07-10 23:27:22 --> Model Class Initialized
INFO - 2019-07-10 23:27:22 --> Model Class Initialized
INFO - 2019-07-10 23:27:22 --> Model Class Initialized
INFO - 2019-07-10 23:27:22 --> Final output sent to browser
DEBUG - 2019-07-10 23:27:22 --> Total execution time: 0.4756
INFO - 2019-07-10 17:27:23 --> Config Class Initialized
INFO - 2019-07-10 17:27:23 --> Hooks Class Initialized
DEBUG - 2019-07-10 17:27:23 --> UTF-8 Support Enabled
INFO - 2019-07-10 17:27:23 --> Utf8 Class Initialized
INFO - 2019-07-10 17:27:23 --> URI Class Initialized
INFO - 2019-07-10 17:27:23 --> Router Class Initialized
INFO - 2019-07-10 17:27:23 --> Output Class Initialized
INFO - 2019-07-10 17:27:23 --> Security Class Initialized
DEBUG - 2019-07-10 17:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-10 17:27:23 --> Input Class Initialized
INFO - 2019-07-10 17:27:23 --> Language Class Initialized
INFO - 2019-07-10 17:27:24 --> Language Class Initialized
INFO - 2019-07-10 17:27:24 --> Config Class Initialized
INFO - 2019-07-10 17:27:24 --> Loader Class Initialized
DEBUG - 2019-07-10 17:27:24 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-10 17:27:24 --> Helper loaded: url_helper
INFO - 2019-07-10 17:27:24 --> Helper loaded: inflector_helper
INFO - 2019-07-10 17:27:24 --> Helper loaded: string_helper
INFO - 2019-07-10 17:27:24 --> Helper loaded: array_helper
INFO - 2019-07-10 17:27:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-10 17:27:24 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-10 17:27:24 --> Database Driver Class Initialized
INFO - 2019-07-10 17:27:24 --> Controller Class Initialized
INFO - 2019-07-10 23:27:24 --> Helper loaded: language_helper
INFO - 2019-07-10 23:27:24 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 23:27:24 --> Model Class Initialized
INFO - 2019-07-10 23:27:24 --> Model Class Initialized
INFO - 2019-07-10 23:27:24 --> Model Class Initialized
INFO - 2019-07-10 23:27:24 --> Model Class Initialized
INFO - 2019-07-10 23:27:24 --> Model Class Initialized
INFO - 2019-07-10 23:27:24 --> Final output sent to browser
DEBUG - 2019-07-10 23:27:24 --> Total execution time: 0.6004
INFO - 2019-07-10 17:27:58 --> Config Class Initialized
INFO - 2019-07-10 17:27:58 --> Hooks Class Initialized
DEBUG - 2019-07-10 17:27:58 --> UTF-8 Support Enabled
INFO - 2019-07-10 17:27:58 --> Utf8 Class Initialized
INFO - 2019-07-10 17:27:58 --> URI Class Initialized
INFO - 2019-07-10 17:27:58 --> Router Class Initialized
INFO - 2019-07-10 17:27:58 --> Output Class Initialized
INFO - 2019-07-10 17:27:58 --> Security Class Initialized
DEBUG - 2019-07-10 17:27:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-10 17:27:58 --> Input Class Initialized
INFO - 2019-07-10 17:27:58 --> Language Class Initialized
INFO - 2019-07-10 17:27:58 --> Language Class Initialized
INFO - 2019-07-10 17:27:58 --> Config Class Initialized
INFO - 2019-07-10 17:27:58 --> Loader Class Initialized
DEBUG - 2019-07-10 17:27:58 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-10 17:27:58 --> Helper loaded: url_helper
INFO - 2019-07-10 17:27:58 --> Helper loaded: inflector_helper
INFO - 2019-07-10 17:27:58 --> Helper loaded: string_helper
INFO - 2019-07-10 17:27:58 --> Helper loaded: array_helper
INFO - 2019-07-10 17:27:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-10 17:27:58 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-10 17:27:58 --> Database Driver Class Initialized
INFO - 2019-07-10 17:27:58 --> Controller Class Initialized
INFO - 2019-07-10 23:27:58 --> Helper loaded: language_helper
INFO - 2019-07-10 23:27:58 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 23:27:58 --> Model Class Initialized
INFO - 2019-07-10 23:27:58 --> Model Class Initialized
INFO - 2019-07-10 23:27:58 --> Model Class Initialized
INFO - 2019-07-10 23:27:58 --> Model Class Initialized
INFO - 2019-07-10 23:27:58 --> Final output sent to browser
DEBUG - 2019-07-10 23:27:58 --> Total execution time: 0.4626
INFO - 2019-07-10 17:27:58 --> Config Class Initialized
INFO - 2019-07-10 17:27:58 --> Hooks Class Initialized
DEBUG - 2019-07-10 17:27:58 --> UTF-8 Support Enabled
INFO - 2019-07-10 17:27:58 --> Utf8 Class Initialized
INFO - 2019-07-10 17:27:58 --> URI Class Initialized
INFO - 2019-07-10 17:27:59 --> Router Class Initialized
INFO - 2019-07-10 17:27:59 --> Output Class Initialized
INFO - 2019-07-10 17:27:59 --> Security Class Initialized
DEBUG - 2019-07-10 17:27:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-10 17:27:59 --> Input Class Initialized
INFO - 2019-07-10 17:27:59 --> Language Class Initialized
INFO - 2019-07-10 17:27:59 --> Language Class Initialized
INFO - 2019-07-10 17:27:59 --> Config Class Initialized
INFO - 2019-07-10 17:27:59 --> Loader Class Initialized
DEBUG - 2019-07-10 17:27:59 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-10 17:27:59 --> Helper loaded: url_helper
INFO - 2019-07-10 17:27:59 --> Helper loaded: inflector_helper
INFO - 2019-07-10 17:27:59 --> Helper loaded: string_helper
INFO - 2019-07-10 17:27:59 --> Helper loaded: array_helper
INFO - 2019-07-10 17:27:59 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-10 17:27:59 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-10 17:27:59 --> Database Driver Class Initialized
INFO - 2019-07-10 17:27:59 --> Controller Class Initialized
INFO - 2019-07-10 23:27:59 --> Helper loaded: language_helper
INFO - 2019-07-10 23:27:59 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 23:27:59 --> Model Class Initialized
INFO - 2019-07-10 23:27:59 --> Model Class Initialized
INFO - 2019-07-10 23:27:59 --> Model Class Initialized
INFO - 2019-07-10 23:27:59 --> Model Class Initialized
INFO - 2019-07-10 23:27:59 --> Model Class Initialized
INFO - 2019-07-10 23:27:59 --> Final output sent to browser
DEBUG - 2019-07-10 23:27:59 --> Total execution time: 0.4577
INFO - 2019-07-10 17:53:21 --> Config Class Initialized
INFO - 2019-07-10 17:53:21 --> Hooks Class Initialized
DEBUG - 2019-07-10 17:53:21 --> UTF-8 Support Enabled
INFO - 2019-07-10 17:53:21 --> Utf8 Class Initialized
INFO - 2019-07-10 17:53:21 --> URI Class Initialized
INFO - 2019-07-10 17:53:21 --> Router Class Initialized
INFO - 2019-07-10 17:53:21 --> Output Class Initialized
INFO - 2019-07-10 17:53:21 --> Security Class Initialized
DEBUG - 2019-07-10 17:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-10 17:53:21 --> Input Class Initialized
INFO - 2019-07-10 17:53:21 --> Language Class Initialized
INFO - 2019-07-10 17:53:21 --> Language Class Initialized
INFO - 2019-07-10 17:53:21 --> Config Class Initialized
INFO - 2019-07-10 17:53:21 --> Loader Class Initialized
DEBUG - 2019-07-10 17:53:21 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-10 17:53:21 --> Helper loaded: url_helper
INFO - 2019-07-10 17:53:21 --> Helper loaded: inflector_helper
INFO - 2019-07-10 17:53:21 --> Helper loaded: string_helper
INFO - 2019-07-10 17:53:21 --> Helper loaded: array_helper
INFO - 2019-07-10 17:53:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-10 17:53:21 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-10 17:53:21 --> Database Driver Class Initialized
INFO - 2019-07-10 17:53:21 --> Controller Class Initialized
INFO - 2019-07-10 23:53:21 --> Helper loaded: language_helper
INFO - 2019-07-10 23:53:22 --> Language file loaded: language/english/general_lang.php
INFO - 2019-07-10 23:53:22 --> Model Class Initialized
INFO - 2019-07-10 23:53:22 --> Model Class Initialized
INFO - 2019-07-10 23:53:22 --> Model Class Initialized
INFO - 2019-07-10 23:53:22 --> Model Class Initialized
INFO - 2019-07-10 23:53:22 --> Model Class Initialized
INFO - 2019-07-10 23:53:22 --> Final output sent to browser
DEBUG - 2019-07-10 23:53:22 --> Total execution time: 0.4518
INFO - 2019-07-10 18:56:04 --> Config Class Initialized
INFO - 2019-07-10 18:56:04 --> Hooks Class Initialized
DEBUG - 2019-07-10 18:56:04 --> UTF-8 Support Enabled
INFO - 2019-07-10 18:56:05 --> Utf8 Class Initialized
INFO - 2019-07-10 18:56:05 --> URI Class Initialized
INFO - 2019-07-10 18:56:05 --> Router Class Initialized
INFO - 2019-07-10 18:56:05 --> Output Class Initialized
INFO - 2019-07-10 18:56:05 --> Security Class Initialized
DEBUG - 2019-07-10 18:56:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-10 18:56:05 --> Input Class Initialized
INFO - 2019-07-10 18:56:05 --> Language Class Initialized
INFO - 2019-07-10 18:56:05 --> Language Class Initialized
INFO - 2019-07-10 18:56:05 --> Config Class Initialized
INFO - 2019-07-10 18:56:05 --> Loader Class Initialized
DEBUG - 2019-07-10 18:56:05 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-10 18:56:05 --> Helper loaded: url_helper
INFO - 2019-07-10 18:56:05 --> Helper loaded: inflector_helper
INFO - 2019-07-10 18:56:05 --> Helper loaded: string_helper
INFO - 2019-07-10 18:56:05 --> Helper loaded: array_helper
INFO - 2019-07-10 18:56:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-10 18:56:05 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-10 18:56:05 --> Database Driver Class Initialized
INFO - 2019-07-10 18:56:05 --> Controller Class Initialized
INFO - 2019-07-10 18:56:53 --> Config Class Initialized
INFO - 2019-07-10 18:56:53 --> Hooks Class Initialized
DEBUG - 2019-07-10 18:56:53 --> UTF-8 Support Enabled
INFO - 2019-07-10 18:56:53 --> Utf8 Class Initialized
INFO - 2019-07-10 18:56:53 --> URI Class Initialized
INFO - 2019-07-10 18:56:53 --> Router Class Initialized
INFO - 2019-07-10 18:56:53 --> Output Class Initialized
INFO - 2019-07-10 18:56:53 --> Security Class Initialized
DEBUG - 2019-07-10 18:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-10 18:56:53 --> Input Class Initialized
INFO - 2019-07-10 18:56:53 --> Language Class Initialized
INFO - 2019-07-10 18:56:53 --> Language Class Initialized
INFO - 2019-07-10 18:56:53 --> Config Class Initialized
INFO - 2019-07-10 18:56:53 --> Loader Class Initialized
DEBUG - 2019-07-10 18:56:53 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-10 18:56:53 --> Helper loaded: url_helper
INFO - 2019-07-10 18:56:53 --> Helper loaded: inflector_helper
INFO - 2019-07-10 18:56:53 --> Helper loaded: string_helper
INFO - 2019-07-10 18:56:53 --> Helper loaded: array_helper
INFO - 2019-07-10 18:56:53 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-10 18:56:53 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-10 18:56:53 --> Database Driver Class Initialized
INFO - 2019-07-10 18:56:53 --> Controller Class Initialized
INFO - 2019-07-10 18:57:51 --> Config Class Initialized
INFO - 2019-07-10 18:57:51 --> Hooks Class Initialized
DEBUG - 2019-07-10 18:57:51 --> UTF-8 Support Enabled
INFO - 2019-07-10 18:57:51 --> Utf8 Class Initialized
INFO - 2019-07-10 18:57:51 --> URI Class Initialized
INFO - 2019-07-10 18:57:51 --> Router Class Initialized
INFO - 2019-07-10 18:57:51 --> Output Class Initialized
INFO - 2019-07-10 18:57:51 --> Security Class Initialized
DEBUG - 2019-07-10 18:57:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-10 18:57:51 --> Input Class Initialized
INFO - 2019-07-10 18:57:51 --> Language Class Initialized
INFO - 2019-07-10 18:57:51 --> Language Class Initialized
INFO - 2019-07-10 18:57:51 --> Config Class Initialized
INFO - 2019-07-10 18:57:51 --> Loader Class Initialized
DEBUG - 2019-07-10 18:57:51 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-10 18:57:51 --> Helper loaded: url_helper
INFO - 2019-07-10 18:57:51 --> Helper loaded: inflector_helper
INFO - 2019-07-10 18:57:51 --> Helper loaded: string_helper
INFO - 2019-07-10 18:57:51 --> Helper loaded: array_helper
INFO - 2019-07-10 18:57:51 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-10 18:57:51 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-10 18:57:51 --> Database Driver Class Initialized
INFO - 2019-07-10 18:57:51 --> Controller Class Initialized
INFO - 2019-07-10 18:58:46 --> Config Class Initialized
INFO - 2019-07-10 18:58:46 --> Hooks Class Initialized
DEBUG - 2019-07-10 18:58:46 --> UTF-8 Support Enabled
INFO - 2019-07-10 18:58:46 --> Utf8 Class Initialized
INFO - 2019-07-10 18:58:46 --> URI Class Initialized
INFO - 2019-07-10 18:58:46 --> Router Class Initialized
INFO - 2019-07-10 18:58:46 --> Output Class Initialized
INFO - 2019-07-10 18:58:46 --> Security Class Initialized
DEBUG - 2019-07-10 18:58:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-10 18:58:46 --> Input Class Initialized
INFO - 2019-07-10 18:58:46 --> Language Class Initialized
INFO - 2019-07-10 18:58:46 --> Language Class Initialized
INFO - 2019-07-10 18:58:46 --> Config Class Initialized
INFO - 2019-07-10 18:58:46 --> Loader Class Initialized
DEBUG - 2019-07-10 18:58:46 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-10 18:58:46 --> Helper loaded: url_helper
INFO - 2019-07-10 18:58:46 --> Helper loaded: inflector_helper
INFO - 2019-07-10 18:58:46 --> Helper loaded: string_helper
INFO - 2019-07-10 18:58:46 --> Helper loaded: array_helper
INFO - 2019-07-10 18:58:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-10 18:58:46 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-10 18:58:46 --> Database Driver Class Initialized
INFO - 2019-07-10 18:58:46 --> Controller Class Initialized
INFO - 2019-07-10 18:59:35 --> Config Class Initialized
INFO - 2019-07-10 18:59:35 --> Hooks Class Initialized
DEBUG - 2019-07-10 18:59:35 --> UTF-8 Support Enabled
INFO - 2019-07-10 18:59:35 --> Utf8 Class Initialized
INFO - 2019-07-10 18:59:35 --> URI Class Initialized
INFO - 2019-07-10 18:59:35 --> Router Class Initialized
INFO - 2019-07-10 18:59:35 --> Output Class Initialized
INFO - 2019-07-10 18:59:35 --> Security Class Initialized
DEBUG - 2019-07-10 18:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-10 18:59:35 --> Input Class Initialized
INFO - 2019-07-10 18:59:35 --> Language Class Initialized
INFO - 2019-07-10 18:59:35 --> Language Class Initialized
INFO - 2019-07-10 18:59:35 --> Config Class Initialized
INFO - 2019-07-10 18:59:35 --> Loader Class Initialized
DEBUG - 2019-07-10 18:59:35 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-10 18:59:35 --> Helper loaded: url_helper
INFO - 2019-07-10 18:59:35 --> Helper loaded: inflector_helper
INFO - 2019-07-10 18:59:35 --> Helper loaded: string_helper
INFO - 2019-07-10 18:59:35 --> Helper loaded: array_helper
INFO - 2019-07-10 18:59:35 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-10 18:59:35 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-10 18:59:35 --> Database Driver Class Initialized
INFO - 2019-07-10 18:59:35 --> Controller Class Initialized
INFO - 2019-07-10 19:00:06 --> Config Class Initialized
INFO - 2019-07-10 19:00:06 --> Hooks Class Initialized
DEBUG - 2019-07-10 19:00:06 --> UTF-8 Support Enabled
INFO - 2019-07-10 19:00:06 --> Utf8 Class Initialized
INFO - 2019-07-10 19:00:06 --> URI Class Initialized
INFO - 2019-07-10 19:00:06 --> Router Class Initialized
INFO - 2019-07-10 19:00:06 --> Output Class Initialized
INFO - 2019-07-10 19:00:06 --> Security Class Initialized
DEBUG - 2019-07-10 19:00:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-10 19:00:06 --> Input Class Initialized
INFO - 2019-07-10 19:00:06 --> Language Class Initialized
INFO - 2019-07-10 19:00:06 --> Language Class Initialized
INFO - 2019-07-10 19:00:06 --> Config Class Initialized
INFO - 2019-07-10 19:00:06 --> Loader Class Initialized
DEBUG - 2019-07-10 19:00:06 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-10 19:00:06 --> Helper loaded: url_helper
INFO - 2019-07-10 19:00:06 --> Helper loaded: inflector_helper
INFO - 2019-07-10 19:00:06 --> Helper loaded: string_helper
INFO - 2019-07-10 19:00:06 --> Helper loaded: array_helper
INFO - 2019-07-10 19:00:06 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-10 19:00:06 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-10 19:00:06 --> Database Driver Class Initialized
INFO - 2019-07-10 19:00:06 --> Controller Class Initialized
INFO - 2019-07-10 19:01:16 --> Config Class Initialized
INFO - 2019-07-10 19:01:16 --> Hooks Class Initialized
DEBUG - 2019-07-10 19:01:16 --> UTF-8 Support Enabled
INFO - 2019-07-10 19:01:16 --> Utf8 Class Initialized
INFO - 2019-07-10 19:01:16 --> URI Class Initialized
INFO - 2019-07-10 19:01:16 --> Router Class Initialized
INFO - 2019-07-10 19:01:16 --> Output Class Initialized
INFO - 2019-07-10 19:01:16 --> Security Class Initialized
DEBUG - 2019-07-10 19:01:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-10 19:01:16 --> Input Class Initialized
INFO - 2019-07-10 19:01:16 --> Language Class Initialized
INFO - 2019-07-10 19:01:16 --> Language Class Initialized
INFO - 2019-07-10 19:01:16 --> Config Class Initialized
INFO - 2019-07-10 19:01:16 --> Loader Class Initialized
DEBUG - 2019-07-10 19:01:16 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-10 19:01:16 --> Helper loaded: url_helper
INFO - 2019-07-10 19:01:16 --> Helper loaded: inflector_helper
INFO - 2019-07-10 19:01:16 --> Helper loaded: string_helper
INFO - 2019-07-10 19:01:16 --> Helper loaded: array_helper
INFO - 2019-07-10 19:01:16 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-10 19:01:16 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-10 19:01:16 --> Database Driver Class Initialized
INFO - 2019-07-10 19:01:16 --> Controller Class Initialized
INFO - 2019-07-10 19:21:49 --> Config Class Initialized
INFO - 2019-07-10 19:21:49 --> Hooks Class Initialized
DEBUG - 2019-07-10 19:21:49 --> UTF-8 Support Enabled
INFO - 2019-07-10 19:21:49 --> Utf8 Class Initialized
INFO - 2019-07-10 19:21:49 --> URI Class Initialized
INFO - 2019-07-10 19:21:49 --> Router Class Initialized
INFO - 2019-07-10 19:21:49 --> Output Class Initialized
INFO - 2019-07-10 19:21:49 --> Security Class Initialized
DEBUG - 2019-07-10 19:21:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-10 19:21:49 --> Input Class Initialized
INFO - 2019-07-10 19:21:49 --> Language Class Initialized
INFO - 2019-07-10 19:21:49 --> Language Class Initialized
INFO - 2019-07-10 19:21:49 --> Config Class Initialized
INFO - 2019-07-10 19:21:49 --> Loader Class Initialized
DEBUG - 2019-07-10 19:21:49 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-10 19:21:50 --> Helper loaded: url_helper
INFO - 2019-07-10 19:21:50 --> Helper loaded: inflector_helper
INFO - 2019-07-10 19:21:50 --> Helper loaded: string_helper
INFO - 2019-07-10 19:21:50 --> Helper loaded: array_helper
INFO - 2019-07-10 19:21:50 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-10 19:21:50 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-10 19:21:50 --> Database Driver Class Initialized
INFO - 2019-07-10 19:21:50 --> Controller Class Initialized
INFO - 2019-07-10 19:21:52 --> Config Class Initialized
INFO - 2019-07-10 19:21:52 --> Hooks Class Initialized
DEBUG - 2019-07-10 19:21:52 --> UTF-8 Support Enabled
INFO - 2019-07-10 19:21:52 --> Utf8 Class Initialized
INFO - 2019-07-10 19:21:52 --> URI Class Initialized
INFO - 2019-07-10 19:21:52 --> Router Class Initialized
INFO - 2019-07-10 19:21:52 --> Output Class Initialized
INFO - 2019-07-10 19:21:52 --> Security Class Initialized
DEBUG - 2019-07-10 19:21:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-10 19:21:52 --> Input Class Initialized
INFO - 2019-07-10 19:21:52 --> Language Class Initialized
INFO - 2019-07-10 19:21:52 --> Language Class Initialized
INFO - 2019-07-10 19:21:52 --> Config Class Initialized
INFO - 2019-07-10 19:21:52 --> Loader Class Initialized
DEBUG - 2019-07-10 19:21:52 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-10 19:21:52 --> Helper loaded: url_helper
INFO - 2019-07-10 19:21:52 --> Helper loaded: inflector_helper
INFO - 2019-07-10 19:21:52 --> Helper loaded: string_helper
INFO - 2019-07-10 19:21:52 --> Helper loaded: array_helper
INFO - 2019-07-10 19:21:52 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-10 19:21:52 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-10 19:21:52 --> Database Driver Class Initialized
INFO - 2019-07-10 19:21:52 --> Controller Class Initialized
INFO - 2019-07-10 19:21:55 --> Config Class Initialized
INFO - 2019-07-10 19:21:55 --> Hooks Class Initialized
DEBUG - 2019-07-10 19:21:55 --> UTF-8 Support Enabled
INFO - 2019-07-10 19:21:55 --> Utf8 Class Initialized
INFO - 2019-07-10 19:21:55 --> URI Class Initialized
INFO - 2019-07-10 19:21:55 --> Router Class Initialized
INFO - 2019-07-10 19:21:55 --> Output Class Initialized
INFO - 2019-07-10 19:21:55 --> Security Class Initialized
DEBUG - 2019-07-10 19:21:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-10 19:21:55 --> Input Class Initialized
INFO - 2019-07-10 19:21:55 --> Language Class Initialized
INFO - 2019-07-10 19:21:55 --> Language Class Initialized
INFO - 2019-07-10 19:21:55 --> Config Class Initialized
INFO - 2019-07-10 19:21:55 --> Loader Class Initialized
DEBUG - 2019-07-10 19:21:55 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-10 19:21:55 --> Helper loaded: url_helper
INFO - 2019-07-10 19:21:55 --> Helper loaded: inflector_helper
INFO - 2019-07-10 19:21:55 --> Helper loaded: string_helper
INFO - 2019-07-10 19:21:55 --> Helper loaded: array_helper
INFO - 2019-07-10 19:21:55 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-10 19:21:55 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-10 19:21:55 --> Database Driver Class Initialized
INFO - 2019-07-10 19:21:55 --> Controller Class Initialized
INFO - 2019-07-10 19:22:02 --> Config Class Initialized
INFO - 2019-07-10 19:22:02 --> Hooks Class Initialized
DEBUG - 2019-07-10 19:22:02 --> UTF-8 Support Enabled
INFO - 2019-07-10 19:22:02 --> Utf8 Class Initialized
INFO - 2019-07-10 19:22:02 --> URI Class Initialized
INFO - 2019-07-10 19:22:02 --> Router Class Initialized
INFO - 2019-07-10 19:22:02 --> Output Class Initialized
INFO - 2019-07-10 19:22:02 --> Security Class Initialized
DEBUG - 2019-07-10 19:22:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-10 19:22:03 --> Input Class Initialized
INFO - 2019-07-10 19:22:03 --> Language Class Initialized
INFO - 2019-07-10 19:22:03 --> Language Class Initialized
INFO - 2019-07-10 19:22:03 --> Config Class Initialized
INFO - 2019-07-10 19:22:03 --> Loader Class Initialized
DEBUG - 2019-07-10 19:22:03 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-10 19:22:03 --> Helper loaded: url_helper
INFO - 2019-07-10 19:22:03 --> Helper loaded: inflector_helper
INFO - 2019-07-10 19:22:03 --> Helper loaded: string_helper
INFO - 2019-07-10 19:22:03 --> Helper loaded: array_helper
INFO - 2019-07-10 19:22:03 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-10 19:22:03 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-10 19:22:03 --> Database Driver Class Initialized
INFO - 2019-07-10 19:22:03 --> Controller Class Initialized
INFO - 2019-07-10 19:22:08 --> Config Class Initialized
INFO - 2019-07-10 19:22:08 --> Hooks Class Initialized
DEBUG - 2019-07-10 19:22:08 --> UTF-8 Support Enabled
INFO - 2019-07-10 19:22:08 --> Utf8 Class Initialized
INFO - 2019-07-10 19:22:08 --> URI Class Initialized
INFO - 2019-07-10 19:22:08 --> Router Class Initialized
INFO - 2019-07-10 19:22:08 --> Output Class Initialized
INFO - 2019-07-10 19:22:08 --> Security Class Initialized
DEBUG - 2019-07-10 19:22:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-10 19:22:08 --> Input Class Initialized
INFO - 2019-07-10 19:22:08 --> Language Class Initialized
INFO - 2019-07-10 19:22:08 --> Language Class Initialized
INFO - 2019-07-10 19:22:08 --> Config Class Initialized
INFO - 2019-07-10 19:22:08 --> Loader Class Initialized
DEBUG - 2019-07-10 19:22:08 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-10 19:22:08 --> Helper loaded: url_helper
INFO - 2019-07-10 19:22:08 --> Helper loaded: inflector_helper
INFO - 2019-07-10 19:22:08 --> Helper loaded: string_helper
INFO - 2019-07-10 19:22:08 --> Helper loaded: array_helper
INFO - 2019-07-10 19:22:08 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-10 19:22:08 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-10 19:22:08 --> Database Driver Class Initialized
INFO - 2019-07-10 19:22:08 --> Controller Class Initialized
INFO - 2019-07-10 19:24:04 --> Config Class Initialized
INFO - 2019-07-10 19:24:04 --> Hooks Class Initialized
DEBUG - 2019-07-10 19:24:04 --> UTF-8 Support Enabled
INFO - 2019-07-10 19:24:04 --> Utf8 Class Initialized
INFO - 2019-07-10 19:24:04 --> URI Class Initialized
INFO - 2019-07-10 19:24:04 --> Router Class Initialized
INFO - 2019-07-10 19:24:04 --> Output Class Initialized
INFO - 2019-07-10 19:24:04 --> Security Class Initialized
DEBUG - 2019-07-10 19:24:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-10 19:24:04 --> Input Class Initialized
INFO - 2019-07-10 19:24:04 --> Language Class Initialized
INFO - 2019-07-10 19:24:04 --> Language Class Initialized
INFO - 2019-07-10 19:24:04 --> Config Class Initialized
INFO - 2019-07-10 19:24:04 --> Loader Class Initialized
DEBUG - 2019-07-10 19:24:04 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-10 19:24:04 --> Helper loaded: url_helper
INFO - 2019-07-10 19:24:04 --> Helper loaded: inflector_helper
INFO - 2019-07-10 19:24:05 --> Helper loaded: string_helper
INFO - 2019-07-10 19:24:05 --> Helper loaded: array_helper
INFO - 2019-07-10 19:24:05 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-10 19:24:05 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-10 19:24:05 --> Database Driver Class Initialized
INFO - 2019-07-10 19:24:05 --> Controller Class Initialized
INFO - 2019-07-10 19:28:24 --> Config Class Initialized
INFO - 2019-07-10 19:28:24 --> Hooks Class Initialized
DEBUG - 2019-07-10 19:28:24 --> UTF-8 Support Enabled
INFO - 2019-07-10 19:28:24 --> Utf8 Class Initialized
INFO - 2019-07-10 19:28:24 --> URI Class Initialized
INFO - 2019-07-10 19:28:24 --> Router Class Initialized
INFO - 2019-07-10 19:28:24 --> Output Class Initialized
INFO - 2019-07-10 19:28:24 --> Security Class Initialized
DEBUG - 2019-07-10 19:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-10 19:28:24 --> Input Class Initialized
INFO - 2019-07-10 19:28:24 --> Language Class Initialized
INFO - 2019-07-10 19:28:24 --> Language Class Initialized
INFO - 2019-07-10 19:28:24 --> Config Class Initialized
INFO - 2019-07-10 19:28:24 --> Loader Class Initialized
DEBUG - 2019-07-10 19:28:24 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-10 19:28:24 --> Helper loaded: url_helper
INFO - 2019-07-10 19:28:24 --> Helper loaded: inflector_helper
INFO - 2019-07-10 19:28:24 --> Helper loaded: string_helper
INFO - 2019-07-10 19:28:24 --> Helper loaded: array_helper
INFO - 2019-07-10 19:28:24 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-10 19:28:24 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-10 19:28:24 --> Database Driver Class Initialized
INFO - 2019-07-10 19:28:24 --> Controller Class Initialized
INFO - 2019-07-10 19:28:35 --> Config Class Initialized
INFO - 2019-07-10 19:28:35 --> Hooks Class Initialized
DEBUG - 2019-07-10 19:28:35 --> UTF-8 Support Enabled
INFO - 2019-07-10 19:28:35 --> Utf8 Class Initialized
INFO - 2019-07-10 19:28:35 --> URI Class Initialized
INFO - 2019-07-10 19:28:35 --> Router Class Initialized
INFO - 2019-07-10 19:28:35 --> Output Class Initialized
INFO - 2019-07-10 19:28:35 --> Security Class Initialized
DEBUG - 2019-07-10 19:28:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-10 19:28:35 --> Input Class Initialized
INFO - 2019-07-10 19:28:35 --> Language Class Initialized
INFO - 2019-07-10 19:28:35 --> Language Class Initialized
INFO - 2019-07-10 19:28:35 --> Config Class Initialized
INFO - 2019-07-10 19:28:35 --> Loader Class Initialized
DEBUG - 2019-07-10 19:28:35 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-10 19:28:35 --> Helper loaded: url_helper
INFO - 2019-07-10 19:28:35 --> Helper loaded: inflector_helper
INFO - 2019-07-10 19:28:35 --> Helper loaded: string_helper
INFO - 2019-07-10 19:28:35 --> Helper loaded: array_helper
INFO - 2019-07-10 19:28:35 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-10 19:28:35 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-10 19:28:35 --> Database Driver Class Initialized
INFO - 2019-07-10 19:28:35 --> Controller Class Initialized
INFO - 2019-07-10 19:28:46 --> Config Class Initialized
INFO - 2019-07-10 19:28:46 --> Hooks Class Initialized
DEBUG - 2019-07-10 19:28:46 --> UTF-8 Support Enabled
INFO - 2019-07-10 19:28:46 --> Utf8 Class Initialized
INFO - 2019-07-10 19:28:46 --> URI Class Initialized
INFO - 2019-07-10 19:28:46 --> Router Class Initialized
INFO - 2019-07-10 19:28:46 --> Output Class Initialized
INFO - 2019-07-10 19:28:46 --> Security Class Initialized
DEBUG - 2019-07-10 19:28:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-10 19:28:46 --> Input Class Initialized
INFO - 2019-07-10 19:28:46 --> Language Class Initialized
INFO - 2019-07-10 19:28:46 --> Language Class Initialized
INFO - 2019-07-10 19:28:46 --> Config Class Initialized
INFO - 2019-07-10 19:28:46 --> Loader Class Initialized
DEBUG - 2019-07-10 19:28:46 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-10 19:28:46 --> Helper loaded: url_helper
INFO - 2019-07-10 19:28:46 --> Helper loaded: inflector_helper
INFO - 2019-07-10 19:28:46 --> Helper loaded: string_helper
INFO - 2019-07-10 19:28:46 --> Helper loaded: array_helper
INFO - 2019-07-10 19:28:46 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-10 19:28:46 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-10 19:28:46 --> Database Driver Class Initialized
INFO - 2019-07-10 19:28:46 --> Controller Class Initialized
INFO - 2019-07-10 19:31:17 --> Config Class Initialized
INFO - 2019-07-10 19:31:17 --> Hooks Class Initialized
DEBUG - 2019-07-10 19:31:17 --> UTF-8 Support Enabled
INFO - 2019-07-10 19:31:17 --> Utf8 Class Initialized
INFO - 2019-07-10 19:31:17 --> URI Class Initialized
INFO - 2019-07-10 19:31:17 --> Router Class Initialized
INFO - 2019-07-10 19:31:18 --> Output Class Initialized
INFO - 2019-07-10 19:31:18 --> Security Class Initialized
DEBUG - 2019-07-10 19:31:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-10 19:31:18 --> Input Class Initialized
INFO - 2019-07-10 19:31:18 --> Language Class Initialized
INFO - 2019-07-10 19:31:18 --> Language Class Initialized
INFO - 2019-07-10 19:31:18 --> Config Class Initialized
INFO - 2019-07-10 19:31:18 --> Loader Class Initialized
DEBUG - 2019-07-10 19:31:18 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-10 19:31:18 --> Helper loaded: url_helper
INFO - 2019-07-10 19:31:18 --> Helper loaded: inflector_helper
INFO - 2019-07-10 19:31:18 --> Helper loaded: string_helper
INFO - 2019-07-10 19:31:18 --> Helper loaded: array_helper
INFO - 2019-07-10 19:31:18 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-10 19:31:18 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-10 19:31:18 --> Database Driver Class Initialized
INFO - 2019-07-10 19:31:18 --> Controller Class Initialized
INFO - 2019-07-10 19:32:44 --> Config Class Initialized
INFO - 2019-07-10 19:32:44 --> Hooks Class Initialized
DEBUG - 2019-07-10 19:32:44 --> UTF-8 Support Enabled
INFO - 2019-07-10 19:32:44 --> Utf8 Class Initialized
INFO - 2019-07-10 19:32:44 --> URI Class Initialized
INFO - 2019-07-10 19:32:44 --> Router Class Initialized
INFO - 2019-07-10 19:32:44 --> Output Class Initialized
INFO - 2019-07-10 19:32:44 --> Security Class Initialized
DEBUG - 2019-07-10 19:32:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-10 19:32:45 --> Input Class Initialized
INFO - 2019-07-10 19:32:45 --> Language Class Initialized
INFO - 2019-07-10 19:32:45 --> Language Class Initialized
INFO - 2019-07-10 19:32:45 --> Config Class Initialized
INFO - 2019-07-10 19:32:45 --> Loader Class Initialized
DEBUG - 2019-07-10 19:32:45 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-10 19:32:45 --> Helper loaded: url_helper
INFO - 2019-07-10 19:32:45 --> Helper loaded: inflector_helper
INFO - 2019-07-10 19:32:45 --> Helper loaded: string_helper
INFO - 2019-07-10 19:32:45 --> Helper loaded: array_helper
INFO - 2019-07-10 19:32:45 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-10 19:32:45 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-10 19:32:45 --> Database Driver Class Initialized
INFO - 2019-07-10 19:32:45 --> Controller Class Initialized
INFO - 2019-07-10 20:03:51 --> Config Class Initialized
INFO - 2019-07-10 20:03:51 --> Hooks Class Initialized
DEBUG - 2019-07-10 20:03:51 --> UTF-8 Support Enabled
INFO - 2019-07-10 20:03:51 --> Utf8 Class Initialized
INFO - 2019-07-10 20:03:51 --> URI Class Initialized
DEBUG - 2019-07-10 20:03:51 --> No URI present. Default controller set.
INFO - 2019-07-10 20:03:51 --> Router Class Initialized
INFO - 2019-07-10 20:03:51 --> Output Class Initialized
INFO - 2019-07-10 20:03:51 --> Security Class Initialized
DEBUG - 2019-07-10 20:03:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-10 20:03:51 --> Input Class Initialized
INFO - 2019-07-10 20:03:51 --> Language Class Initialized
INFO - 2019-07-10 20:03:51 --> Final output sent to browser
DEBUG - 2019-07-10 20:03:51 --> Total execution time: 0.4848
INFO - 2019-07-10 20:07:00 --> Config Class Initialized
INFO - 2019-07-10 20:07:00 --> Hooks Class Initialized
DEBUG - 2019-07-10 20:07:00 --> UTF-8 Support Enabled
INFO - 2019-07-10 20:07:00 --> Utf8 Class Initialized
INFO - 2019-07-10 20:07:00 --> URI Class Initialized
INFO - 2019-07-10 20:07:00 --> Router Class Initialized
INFO - 2019-07-10 20:07:00 --> Output Class Initialized
INFO - 2019-07-10 20:07:00 --> Security Class Initialized
DEBUG - 2019-07-10 20:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-10 20:07:00 --> Input Class Initialized
INFO - 2019-07-10 20:07:00 --> Language Class Initialized
INFO - 2019-07-10 20:07:00 --> Language Class Initialized
INFO - 2019-07-10 20:07:00 --> Config Class Initialized
INFO - 2019-07-10 20:07:00 --> Loader Class Initialized
DEBUG - 2019-07-10 20:07:00 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-10 20:07:00 --> Helper loaded: url_helper
INFO - 2019-07-10 20:07:00 --> Helper loaded: inflector_helper
INFO - 2019-07-10 20:07:01 --> Helper loaded: string_helper
INFO - 2019-07-10 20:07:01 --> Helper loaded: array_helper
INFO - 2019-07-10 20:07:01 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-10 20:07:01 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-10 20:07:01 --> Database Driver Class Initialized
INFO - 2019-07-10 20:07:01 --> Controller Class Initialized
INFO - 2019-07-10 20:19:39 --> Config Class Initialized
INFO - 2019-07-10 20:19:39 --> Hooks Class Initialized
DEBUG - 2019-07-10 20:19:39 --> UTF-8 Support Enabled
INFO - 2019-07-10 20:19:39 --> Utf8 Class Initialized
INFO - 2019-07-10 20:19:39 --> URI Class Initialized
INFO - 2019-07-10 20:19:39 --> Router Class Initialized
INFO - 2019-07-10 20:19:39 --> Output Class Initialized
INFO - 2019-07-10 20:19:40 --> Security Class Initialized
DEBUG - 2019-07-10 20:19:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2019-07-10 20:19:40 --> Input Class Initialized
INFO - 2019-07-10 20:19:40 --> Language Class Initialized
INFO - 2019-07-10 20:19:40 --> Language Class Initialized
INFO - 2019-07-10 20:19:40 --> Config Class Initialized
INFO - 2019-07-10 20:19:40 --> Loader Class Initialized
DEBUG - 2019-07-10 20:19:40 --> Config file loaded: C:\xampp\htdocs\crapi_admin\application\config/site.php
INFO - 2019-07-10 20:19:40 --> Helper loaded: url_helper
INFO - 2019-07-10 20:19:40 --> Helper loaded: inflector_helper
INFO - 2019-07-10 20:19:40 --> Helper loaded: string_helper
INFO - 2019-07-10 20:19:40 --> Helper loaded: array_helper
INFO - 2019-07-10 20:19:40 --> Session: Class initialized using 'files' driver.
DEBUG - 2019-07-10 20:19:40 --> File loaded: C:\xampp\htdocs\crapi_admin\application\modules/api_v1/config/autoload.php
INFO - 2019-07-10 20:19:40 --> Database Driver Class Initialized
INFO - 2019-07-10 20:19:40 --> Controller Class Initialized
