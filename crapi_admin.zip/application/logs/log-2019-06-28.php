<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2019-06-28 00:41:16 --> Helper loaded: language_helper
INFO - 2019-06-28 00:41:16 --> Language file loaded: language/english/general_lang.php
INFO - 2019-06-28 00:41:16 --> Model Class Initialized
INFO - 2019-06-28 00:41:16 --> Model Class Initialized
INFO - 2019-06-28 00:41:16 --> Model Class Initialized
INFO - 2019-06-28 00:41:16 --> Model Class Initialized
INFO - 2019-06-28 00:41:16 --> Final output sent to browser
DEBUG - 2019-06-28 00:41:16 --> Total execution time: 0.2056
